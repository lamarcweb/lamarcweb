//$Id: Converter_LamarcDS.h,v 1.13 2002/06/25 03:17:40 mkkuhner Exp $

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// LamarcDS is a representation of the found seen in a Lamarc Datafile
// Each lamarcDS has the following information.
// Most of it is currently default.
// double coalescenceStartValues;
// string coalescenceMethod;

// MARY ADDS:
// double migrationStartValues;
// string migrationMethod;
// long migrationMaxEvents;

// long coalescenceMaxEvents;
// long replicates;
// double temperatures;
// double swapInterval;  // I have no idea what this is.
// double resimulating;
// long initialNumber;
// long initialSamples;
// long initialDiscard;
// long initialInterval;
// long finalNumber;
// long finalSamples;
// long finalDiscard;
// long finalInterval;
// string verbosity;
// string echo;
// string profile;
// string posterior;
// long seed;
// string parameterFile;
// string outputFile;
// string summaryFile;

// Oh yeah.  It also has some regions containing population data.
// No two regions will have the same name.  If no name is given, give it a unique name.
// The unique name will be in the format 'Region XXXX' where 'X' is a capital letter.
// Every region in a single 'LamarcDS' must have the same populations.  Even if those 
// populations are empty.  If a new region is added, every region in the Datastore will then
// have the union of the old populations and the new populations.  In most cases, these newly
// created populations will be empty, but apparently it helps the program just knowing that 
// these populations exist.

// Some notes on some methods.

// validateRegionName(const string&) will make sure the region name is not just whitespace or empty
// string.  If it is, a unique name is provided for the region.

// string getUniqueName() will provide unique names for regions that are provided without a name.
// The Name will look like 'Region XXXX' where X is a capital letter tween A and Z.

// doesRegionNameExist(const string&) will return true if the region name exists withing this 
// datasource.  False otherwise.

// validateNewRegion(RegionDS&) malongains constralong longegrity through ensuring that every region
// in a datasource always has the same set of populations.

#ifndef CONVERTER_LAMARCDS
#define CONVERTER_LAMARCDS

#include <map>

#include "Converter_DataSourceIf.h"
#include "Converter_RegionDS.h"
#include "Converter_types.h" // for map typedefs


class LamarcDS : public DataSourceIf
{
private:
  double m_coalescenceStartValues;
  string m_coalescenceMethod;
  long m_coalescenceMaxEvents;

// MARY
  double m_migrationStartValues;
  string m_migrationMethod;
  long m_migrationMaxEvents;

  long m_replicates;
  double m_temperatures;
  double m_swapInterval;  // I have no idea what this is.
  double m_resimulating;
  long m_initialNumber;
  long m_initialSamples;
  long m_initialDiscard;
  long m_initialInterval;
  long m_finalNumber;
  long m_finalSamples;
  long m_finalDiscard;
  long m_finalInterval;
  string m_verbosity;
  string m_echo;
  string m_profile;
  string m_posterior;
  long m_seed;
  string m_parameterFile;
  string m_outputFile;
  string m_summaryFile;
  
  RegionMap m_regions;

  // destroy the stored genetic data, used by ReorderUsing()
  void EraseRegions();

  // Validation for LamarcDS
  void validateRegionName(RegionDS& region) const;
  string getUniqueName() const;
  void validateNewRegion(RegionDS& region);


 public:
  //  Note.  Constructors may throw ConverterBaseError's
  LamarcDS();                                // starts with no regions.  huh.
  LamarcDS(RegionDS& region);
  virtual ~LamarcDS();

  //  get an iterator to the regions contained by this lamarc datasource.
  RegionMap::iterator getFirstRegion();
  RegionMap::const_iterator getFirstRegion() const;

  //  get an iterator to the end of the region list.
  RegionMap::iterator getLastRegion();
  RegionMap::const_iterator getLastRegion() const;

  //  add an region
  void addRegion (RegionDS& region);

  //  Merge an existing LamarcDS to this LamarcDS
  //  TODO:  Figure whether the lamarc ref passed should be const.
  void mergeTo(LamarcDS& lamarc);

  //  Reorder the internal data maps according to the given map
  //  Provided for use in the UI.  An InvalidSequenceLengthError
  //  can be thrown, potentially aborting the whole process, no
  //  internal cleanup is performed in this case.
  void ReorderUsing(RegByPopMap newmap);

  //  get the number of regions contained by the LamarcDS
  long numRegions() const;

  //  get the total number of population units contained by
  //  the LamarcDS, used by the UI
  long GetNUnits() const;

  //  originally part of private validation, pulled out for use by
  //  the SpaceConverter to validate the spacing info
  bool doesRegionNameExist(const string& name) const;

  //  is a non-contiguous type of genetic data present?
  bool HasNonContiguousData() const;

  //  are SNPs present in the stored genetic data?
  bool HasSNPs() const;

  //  A whole bunch of methods that allow our dear user to 
  //  set the <forces> information.

  void setCoalescenceStartValues(const double);
  void setCoalescenceMethod(const string&);
  void setCoalescenceMaxEvents(const long);
  void setReplicates(const long);  // unsigned?
  void setTemperatures(const double);
  void setSwapInterval(const long);  // unsigned
  void setResimulating(const double);
  void setInitialNumber(const long);  // unsigned?
  void setInitialSamples(const long);  // unsigned?
  void setInitialDiscard(const long);  // unsigned?
  void setInitialInterval(const long);  // unsigned?
  void setFinalNumber(const long);  // unsigned?
  void setFinalSamples(const long);  // unsigned?
  void setFinalDiscard(const long);  // unsigned?
  void setFinalInterval(const long);  // unsigned?
  void setVerbosity(const string&);  // restrictions?
  void setEcho(const string&);  // boolean?
  void setProfile(const string&);
  void setPosterior(const string&);
  void setSeed(const long);
  void setParameterFile(const string&);
  void setOutputFile(const string&);
  void setSummaryFile(const string&);

  string getXML(unsigned int numTabs) const;   //  From DataSourceIf
};

#endif

