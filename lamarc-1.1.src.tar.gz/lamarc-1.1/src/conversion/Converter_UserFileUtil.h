// $Id: Converter_UserFileUtil.h,v 1.2 2002/06/25 03:17:42 mkkuhner Exp $

// This file contains some useful file i/o functions for use with
// the user interface

#ifndef Converter_UserFileUtil
#define Converter_UserFileUtil

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <fstream>
#include <string>

#include "stringx.h"

using namespace std;

class UserFileUtil {

  public:
  // we accept default ctor, operator=, and copy ctor
  virtual ~UserFileUtil() {};

  bool IsFilePresent(const string& filename) const;

};

#endif
