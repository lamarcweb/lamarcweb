// $Id: Converter_ConverterUI.h,v 1.17 2002/06/27 20:21:59 mkkuhner Exp $

#ifndef CONVERTER_UI
#define CONVERTER_UI

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include <vector>
#include <map>
#include <set>
#include "Converter_types.h"

class LamarcDS;
class PopulationDS;
class ConverterIf;
class UserFileUtil;

bool isInterleaved();
std::string getFileName(const UserFileUtil& fileutil);
std::string getHapFileName(const std::string& regionname,
                      const UserFileUtil& fileutil);
std::string getFormat();
std::string getDataType();
std::string GetMapFileName();
long getInteger(const std::string& name, bool mustbepositive = false);
long getRegionalMapInfo (const std::string& regionName, long& length,
                         long& offset);
// SetRegionLength() is a helper function for SetMapInfo()
void SetRegionLength(RegionMap::iterator region);
void SetMapInfo(LamarcDS& dataStore, const std::string& mapfilename);
void SetHapInfo(LamarcDS& dataStore);

// used in Migrate file conversion, how to read microsats?
bool AreMicrosRegions();

// return true if answer is "yes" and false if answer is "no"
// defaultyes is true if the default, user just carriage returns,
// answer is "yes", false if "no"
bool GetYesOrNo(const std::string& query, bool defaultyes);

int main();

//___________________________________________________________-

// This class stores information on one "unit" (a block of 
// sequences from the same region and population).

class Unit
{
public:
  long regionno;
  std::string region;
  std::string population;
  long tips;
  long markers;
  std::string filename;
  std::string datatype;
  PopMap::iterator m_pop;

  Unit(long no, const std::string& reg, const std::string& pop, long ti,
     long mar, const std::string& filen, const std::string& dtype,
     PopMap::iterator mypop) 
    : regionno(no), region(reg), population(pop), tips(ti), markers(mar),
      filename(filen), datatype(dtype), m_pop(mypop) {}

  void DisplayUnit() const;

  // this operator allows sorting by region, then population
  bool operator<(const Unit& other) const;
  bool IsIn(const std::string& regionname, const std::string& popname) const;
};

//___________________________________________________________-

// This class stores and manages a list of Units, allowing the
// user to assign and validate their population and region 
// relationships

//___________________________________________________________

class PopRegionRelation
{
private:
  std::vector<Unit> units;
  std::set<std::string> GetRegionNames() const;
  std::set<std::string> GetPopulationNames() const;

  // a pair of helper functions for OverallValid()
  bool RegionsValid() const;
  bool PopsValid() const;

public:
  void AddUnit(Unit unit) { units.push_back(unit); };
  // the following is non-const because it sorts the Units
  void DisplayPopRegionRelation();
  void ChangeRegions();
  void ChangePopulations();
  bool OverallValid() const;
  RegByPopMap GetRegionalByPopMap() const;
  
};

#endif
