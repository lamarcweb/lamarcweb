// $Id: Converter_ConverterIf.h,v 1.12 2002/06/25 03:17:39 mkkuhner Exp $

#ifndef Converter_ConverterIf
#define Converter_ConverterIf

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>

#include "Converter_LamarcDS.h"
#include "Converter_ParserUtil.h"
#include "stringx.h"

using namespace std;

class Random;

//  This file is the base class for all the Converter (DS) classes.
//  Its a pure virtual ensuring that each DS class will know how to
//  write itself as XML
//  Added ability to deal with phase unknown data, Jon 2002/02/12
//  Removed phase unknown to new HapConverter class, Jon 2002/03/28

class ConverterIf : public ParserUtil {
 private:

 protected:

 public:
  ConverterIf();
  virtual ~ConverterIf();
  virtual void addConvertedLamarcDS(LamarcDS& lamarc) = 0;

  // A wrapper around the string to long converter, FromString(),
  // to check that the number was parsed correctly.  Throws a
  // a FileFormatError upon failure.
  long FlagCheck(const string& origstring, const string& msg) const;

  virtual string GetDataType() { return ""; };
  virtual void SetDataType(const string&) {};
  virtual void ProcessData() {};

};

#endif
