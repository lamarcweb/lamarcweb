//$Id: Converter_MigrateConverter.h,v 1.10 2002/06/25 03:17:40 mkkuhner Exp $
//  Migrate Converter will take an old style migrate file, and create a lamarcDS out of it.
//  Note that this can throw pretty much any ConverterBaseError.
//  Anytime this is used, one should catch and handle these errors.

#ifndef CONVERTER_MIGRATECONVERTER
#define CONVERTER_MIGRATECONVERTER

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "Converter_ConverterIf.h"
#include "Converter_LamarcDS.h"
#include <fstream.h>

class Random;

//  Namespace here?

class MigrateConverter : public ConverterIf
{
private:
  LamarcDS m_lamarc;
  string m_fileName;
  string m_datatype;
  bool m_interleaved;
  string m_firstLine;  // saves the first line for re-parsing
  ifstream m_inFile;
  bool m_markerstoregions;

  void getInterleavedSequences (ifstream& infile,
				const long numSequences,
				const long sequenceLength,
				const string& popName,
				const string& regionName,
                                const string& datatype);
  
  void getNonInterleavedSequences (ifstream& infile,
				   const long numSequences,
				   const long sequenceLength,
				   const string& popName,
				   const string& regionName,
                                   const string& datatype);

  string getNewName(Random&) const;

  long GetNumPops(istrstream& linestream) const;
  long GetNumLoci(istrstream& linestream) const;
  vector<long> GetSeqLengths(istrstream& linestream, long numLoci) const;
  long GetNumSeqs(istrstream& linestream) const;
  string ReadDataType(istrstream& linestream) const;
  
  void GetMicroSatLoci (ifstream& infile,
                        const long numSequences,
		        const long numLoci,
		        const string& popName,
		        const string& regionName,
                        const string& datatype,
                        const string& delimiter);

 public:
  //  Note.  Constructors may throw ConverterBaseError's
  MigrateConverter(const string& fileName, bool interleaved);

  virtual ~MigrateConverter();

  void addConvertedLamarcDS(LamarcDS&);   //  From ConverterIf

  virtual void SetDataType(const string& dtype) { m_datatype = dtype; };
  virtual string GetDataType() { return m_datatype; };
  virtual void ProcessData();

  void SetMarkersToRegions(bool val);
  
};

#endif

