//$Id
#ifndef Converter_DataSourceIf
#define Converter_DataSourceIf

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>

using namespace std;


//  This file is the base class for all the Datasource (DS) classes.
//  Its a pure virtual ensuring that each DS class will know how to write itself as XML

class DataSourceIf {
 protected:
  virtual void addTabs (int numTabs, string& str) const;
 public:
  virtual ~DataSourceIf();
  virtual string getXML(unsigned int numTabs) const = 0;
};

#endif
