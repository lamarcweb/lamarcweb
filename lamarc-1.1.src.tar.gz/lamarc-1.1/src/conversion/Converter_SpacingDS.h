// $Id: Converter_SpacingDS.h,v 1.7 2002/06/25 03:17:41 mkkuhner Exp $

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// SpacingDS is a representation of the spacing information for a
// region's genetic data.
//
// Each representation owns the following.
//   vector<long> positions;  // a sorted list of marker positions
//   long offset;             // the position of a region's start in the
//                            // user's numbering scheme
//   long map_position;       // the position of the region with respect
//                            // to other regions
//   long length;             // the region's length

// Limited validation is done on construction.  The member function:
// IsConsistentWith(const string& geneticdata) is provided for more
// rigorous validiation.


// Note: when expanding to loci, either add a vector/map layer to
// positions and offset and length, or this becomes a per locus
// describer and the regional map_position will need to move to
// the RegionDS.

#ifndef CONVERTER_SPACINGDS
#define CONVERTER_SPACINGDS

#include <vector>

#include "Converter_DataSourceIf.h"

//  Namespace here?

class SpacingDS : public DataSourceIf
{
private:
  vector<long> m_positions;
  long m_length;
  long m_offset;
  long m_map_position;

  // this is a validator for SpacingDS
  void CheckConsistency(long nmarkers) const;
  
 public:
  //  Note.  Constructors may throw ConverterBaseError's
  SpacingDS();
  SpacingDS(long length, 
            long nmarkers); // this ctor doesn't CheckConsistency as there
                            // is no consistency to check!
  SpacingDS(const vector<long>& positions, 
            long length,
            long nmarkers);
  SpacingDS(const vector<long>& positions,
            long length,
            long offset,
            long map_position,
            long nmarkers);

  // We'll accept the default copy ctor and operator=.

  virtual ~SpacingDS();

  string getXML(unsigned int numTabs) const;   //  From DataSourceIf
};

#endif

