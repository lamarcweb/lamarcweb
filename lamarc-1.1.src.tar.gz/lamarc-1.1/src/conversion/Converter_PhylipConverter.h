// $Id: Converter_PhylipConverter.h,v 1.8 2002/06/25 03:17:41 mkkuhner Exp $

//  Phylip Converter will take an old style phylip file, and create a lamarcDS out of it.
//  Note that this can throw pretty much any ConverterBaseError.
//  Anytime this is used, one should catch and handle these errors.

#ifndef CONVERTER_PHYLIPCONVERTER
#define CONVERTER_PHYLIPCONVERTER

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "Converter_ConverterIf.h"
#include "Converter_LamarcDS.h"
#include <fstream.h>

class Random;

//  Namespace here?

class PhylipConverter : public ConverterIf
{
private:
  LamarcDS m_lamarc;
  string m_fileName;
  string m_datatype;
  bool m_interleaved;
  ifstream m_inFile;

 public:
  //  Note.  Constructors may throw ConverterBaseError's
  PhylipConverter(const string& fileName,
		  const bool interleaved);

  virtual ~PhylipConverter();

  void addConvertedLamarcDS(LamarcDS&);   //  From ConverterIf

  virtual void SetDataType(const string& dtype) { m_datatype = dtype; };
  virtual string GetDataType() { return m_datatype; };
  virtual void ProcessData();

};

#endif

