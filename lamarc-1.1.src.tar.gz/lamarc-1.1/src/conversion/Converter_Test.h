//$Id: Converter_Test.h,v 1.2 2002/06/25 03:17:42 mkkuhner Exp $

//  This file contains the definitions of all the test classes.  You'll see 
//  that they're all pretty damn similar.

#ifndef CONVERTER_TEST
#define CONVERTER_TEST

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "Converter_Sequence.h"
#include "Converter_DataSourceException.h"
#include "Converter_XmlParserUtil.h"

//  Namespace here?

//  Some globals for test
const string validS1 = "aggcttcagg";   // Valid Length 10
const string validS2 = "ag";   // Valid Length 2
const string validS3 = "";      // Valid Length 0

//  And a few invalids
const string invalidS1 = "aggctl";
const string invalidS2 = "agg ctt";


class ConverterTest
{
private:
  //  Don't allow copy construction or assignment
  ConverterTest (const ConverterTest&);
  ConverterTest& operator=(const ConverterTest&);

public:
  // run the tests.
  ConverterTest() { };
  virtual ~ConverterTest() { };
  virtual void runTests() = 0;
};

class SequenceTest : ConverterTest
{
 private:
  void testValidSequence();
  void testInvalidSequence();
  void testAssignment();
  void testAsString();
  void testGetSequenceLength();

public:
  SequenceTest() { };
  ~SequenceTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  IndividualDSTest

class IndividualDSTest : ConverterTest
{
 private:
  void createFromSequence();
  void createFromString();
  void getGuts();

public:
  IndividualDSTest() { };
  ~IndividualDSTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  PopulationDSTest

class PopulationDSTest : ConverterTest
{
 private:
  void createFromIndividual();
  void createFromStrings();
  void addIndividual();
  void addInvalidLengthIndividual();
  void getName();
  void setName();

public:
  PopulationDSTest() { };
  ~PopulationDSTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  ModelDSTest

class ModelDSTest : ConverterTest
{
 private:
  void createModel();
  void changeFreqs();

public:
  ModelDSTest() { };
  ~ModelDSTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  RegionDSTest

class RegionDSTest : ConverterTest
{
 private:
  void createRegion();
  void addNewPopulationToRegion();
  void addNewIndividualToRegion();

public:
  RegionDSTest() { };
  ~RegionDSTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  LamarcDSTest

class LamarcDSTest : ConverterTest
{
 private:
  void createLamarc();
  void addNewRegionToLamarc();

public:
  LamarcDSTest() { };
  ~LamarcDSTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  PhylipConverterTest

class PhylipConverterTest : ConverterTest
{
 private:
  void createConverter();

public:
  PhylipConverterTest() { };
  ~PhylipConverterTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  MigrateConverterTest

class MigrateConverterTest : ConverterTest
{
 private:
  void createConverter();

public:
  MigrateConverterTest() { };
  ~MigrateConverterTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  XmlParserUtilTest

class XmlParserUtilTest : public ConverterTest, XmlParserUtil
{
 private:
  void getTags();

public:
  XmlParserUtilTest() { };
  ~XmlParserUtilTest() { };

  // Run the tests.
  virtual void runTests();
};

//  _____________________________________________________
//  LamarcParserTest

class LamarcParserTest : public ConverterTest
{
 private:
  void testParser();

public:
  LamarcParserTest() { };
  ~LamarcParserTest() { };

  // Run the tests.
  virtual void runTests();
};

#endif

