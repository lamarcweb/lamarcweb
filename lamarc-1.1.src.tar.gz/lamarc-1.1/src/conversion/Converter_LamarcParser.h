//$Id: Converter_LamarcParser.h,v 1.3 2002/06/25 03:17:40 mkkuhner Exp $
//  This will take a filename (in Lamarc format) a LamarcDS and fill it from the file

#ifndef CONVERTER_LAMARCPARSER
#define CONVERTER_LAMARCPARSER

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "xmldb.h"
#include "Converter_LamarcDS.h"
#include <iosfwd>

// class ifstream;

class LamarcParser : public XMLReader
{
private:
void getForcesData(XmlDB*, LamarcDS&);
void getCoalescenceData(XmlDB*, LamarcDS&);
void getChainsData(XmlDB*, LamarcDS&);
void getFormatData(XmlDB*, LamarcDS&);
void getLamarcData(XmlDB*, LamarcDS&);
void getInitialAndFinal(XmlDB*, LamarcDS&, const string&);
void getModelDS (XmlDB*, ModelDS&);
void getPopulationData (XmlDB*, RegionDS&);

 public:
  //  Note.  Constructors may throw ConverterBaseError's
void fillDS(LamarcDS& lamarc,
	    const string& fileName);

 LamarcParser();
 virtual ~LamarcParser();
};

#endif

