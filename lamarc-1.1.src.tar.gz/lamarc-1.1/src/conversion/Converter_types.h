// $Id: Converter_types.h,v 1.2 2002/06/25 03:17:42 mkkuhner Exp $

#ifndef CONVERTER_TYPES
#define CONVERTER_TYPES

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "stringx.h"
#include <map>
#include <set>

class PopulationDS;
class RegionDS;
class IndividualDS;

typedef std::map<std::string, PopulationDS, CIStringCompare> PopMap;
typedef std::map<std::string, RegionDS, CIStringCompare> RegionMap;
typedef std::map<IndividualDS, std::string> IndividualMap;

typedef PopMap::iterator popmapiterator;
typedef std::vector<popmapiterator> PopIterVec;
typedef std::map<std::string, PopIterVec, CIStringCompare> PopIterMap;
typedef std::map<std::string, PopIterMap, CIStringCompare> RegByPopMap;
 
typedef std::map<std::string,std::vector<long>, CIStringCompare> SpaceMap;

typedef std::map<std::string, long, CIStringCompare> MarkerMap;
typedef std::map<std::string, std::string, CIStringCompare> TypeMap;

typedef std::set<std::string, CIStringCompare> PopNameSet;
typedef std::map<std::string, PopNameSet, CIStringCompare> RegPopNameMap;


#endif
