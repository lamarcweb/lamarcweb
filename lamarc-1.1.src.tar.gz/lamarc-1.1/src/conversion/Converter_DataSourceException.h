// $Id: Converter_DataSourceException.h,v 1.5 2002/06/25 03:17:39 mkkuhner Exp $

#ifndef Converter_DataSourceException
#define Converter_DataSourceException

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <exception>
#include <string>

using namespace std;

//  This file contains the exceptions thrown by datasource classes
//  in the converter directory.  This holds exceptions relating to bad 
//  data formats or constraint violations.
//  what() can be called to get a string describing the error.

class ConverterBaseError : public exception {
  public:
  virtual const char* type () const = 0;
};

class ConverterTestError : public ConverterBaseError {
private:
  string _what;
public:
  ConverterTestError(const string& wh): _what (wh) { };
  virtual const char* what () const { return _what.c_str (); };
  virtual const char* type () const { return "ConverterTestError"; };
};

class DataTypeNotFoundError : public ConverterBaseError {
  private:
    string _what;
public:
  DataTypeNotFoundError(const string& wh): _what (wh) { };
  virtual const char* what () const { return _what.c_str (); };
  virtual const char* type () const { return "DataTypeNotFoundError"; };
};

class InvalidNucleotideError : public ConverterBaseError {
private:
  string _what;
public:
  InvalidNucleotideError(const string& wh): _what (wh) { };
  virtual const char* what () const { return _what.c_str (); };
  virtual const char* type () const { return "InvalidNucleotideError"; };
};

class InvalidSequenceLengthError : public ConverterBaseError {
private:
  string _what;
public:
  InvalidSequenceLengthError(const string& wh): _what (wh) { };
  virtual const char* what () const { return _what.c_str (); };
  virtual const char* type () const { return "InvalidSequenceLengthError"; };
};

class InvalidFrequenciesError : public ConverterBaseError {
private:
  string _what;
public:
  InvalidFrequenciesError(const string& wh): _what (wh) { };
  virtual const char* what () const { return _what.c_str (); };
  virtual const char* type () const { return "InvalidFrequenciesError"; };
};

class FileNotFoundError : public ConverterBaseError {
private:
  string _what;
public:
  FileNotFoundError(const string& wh): _what (wh) { };
  virtual const char* what () const { return _what.c_str (); };
  virtual const char* type () const { return "FileNotFoundError"; };
};

class FileFormatError : public ConverterBaseError {
private:
  string _what;
public:
  FileFormatError(const string& wh): _what (wh) { };
  virtual const char* what () const { return _what.c_str (); };
  virtual const char* type () const { return "FileFormatError"; };
};

class InconsistentDataError : public ConverterBaseError {
private:
  string _what;
public:
  InconsistentDataError(const string& wh): _what (wh) { };
  virtual const char* what () const { return _what.c_str (); };
  virtual const char* type () const { return "InconsistentDataError"; };
};

#endif
