//$Id: Converter_ParserUtil.h,v 1.4 2002/06/25 03:17:40 mkkuhner Exp $
#ifndef Converter_ParserUtil
#define Converter_ParserUtil

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>

using namespace std;


//  This file is the base class for all the ParserUtil classes.

class ParserUtil {
 private:
 protected:
  // No creation of just this class.
  ParserUtil();
  virtual ~ParserUtil();

  // Pulls chars until whitespace, newline, or digit is found.
  bool getWord (istream& is, string& buffer) const ;
  // Pulls chars until whitespace, newline is found.
  bool getName (istream& is, string& buffer) const ;
  // Pulls chars until a non digit is found
  bool getNumber (istream& is, string& buffer) const;
  // Pulls chars until a whitespace, newline, or tab is found
  bool getToken (istream& is, string& buffer) const ;
  // Pulls chars until a newline is found
  bool getLine (istream& is, string& buffer) const;
  // Pulls all spaces and newlines until next non whitespace is found
  bool skipWhiteSpace (istream& is) const;
  // Pulls the next N characters (newline, tabs skipped)
  bool getNextNChars (istream& is, string& buffer, const long& n) const;
  // Pulls the next N nonwhitespace characters (tab, newline, space)
  bool getNextNNonWhiteSpace (istream& is, string& buffer, const long& n) const;
  // Pulls chars until the given character is found.
  bool skipToChar (istream& is, int searchChar) const;

  // returns true if the first non-whitespace character is in the
  // search string, false otherwise
  bool isFirstChar(istream& is, const string& searchString) const;
  

 public:
};

#endif
