// $Id: Converter_SpaceConverter.h,v 1.3 2002/06/25 03:17:41 mkkuhner Exp $

// SpaceConverter reads the info from a prepared Converter-Haplotype
// format file and modifies the regions of a LamarcDS.

#ifndef CONVERTER_SPACECONVERTER
#define CONVERTER_SPACECONVERTER

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "Converter_ConverterIf.h"
#include <fstream.h>
#include <map>
#include <vector>
#include "Converter_types.h"  // for map typedefs

class LamarcDS;

class SpaceConverter : public ConverterIf
{
private:
LamarcDS& m_lamarc;

SpaceConverter();                                 // deliberately undefined
SpaceConverter(const SpaceConverter&);            // deliberately undefined
SpaceConverter& operator=(const SpaceConverter&); // deliberately undefined

// May throw a FileFormatError
void ValidateSpaceInfo(const SpaceMap& spaces,
                       const string& filename) const;

public:
SpaceConverter(LamarcDS& lamarc);
virtual ~SpaceConverter();

// may throw a FileFormatError.
SpaceMap ReadSpacingInfo(const string& filename) const;

void addConvertedLamarcDS(LamarcDS& lamarc);

};

#endif
