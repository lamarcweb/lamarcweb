// $Id: Converter_Sequence.h,v 1.10 2002/06/25 03:17:41 mkkuhner Exp $

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// Sequence is a representation of a Nucleotide sequence of any length.
// Each Sequence owns a string that represents the DNA sequence.
// Validation is done on the DNA sequence upon construction.  If any 
// invalid nucleotides or symbols are found, an InvalidNucleotide exception 
// is thrown.  

// The only constructor I'm giving initially is from a string.
// The getLength() method returns the length of the sequence as an int.
// The operator string is not defined, but I'm giving the asString() method.  
// This method returns the sequence as a string..

// Note:  This IS a DataSource.  The naming is unfortunate.  I plan on changing that.

#ifndef CONVERTER_SEQUENCE
#define CONVERTER_SEQUENCE

#include "Converter_DataSourceIf.h"
#include "constants.h" // for definition of DNA literal.
#include <string>
#include <vector>

//  Namespace here?

class Sequence : public DataSourceIf
{
private:
  vector<string> m_sequence;
  string m_dataType;
  string m_name;

  Sequence();                                // undefined
  void validate(const string &src) const;    // does the actual validation
  void trimSequence();          // Trims the leading and trailing
                                // whitespace from the sequence

  vector<string> AsStringVec(const string& src) const;

 public:
  Sequence(const string& sequenceString);
  Sequence(const string& sequenceString,
	   const string& dataType,
           const string& name);
  Sequence(const vector<string>& sequenceString,
	   const string& dataType,
           const string& name);

  virtual ~Sequence();

  // Use the Default Copy Constructor.
  // Create an = operator
  Sequence& operator=(const Sequence& src);

  long getSequenceLength() const;
  string getDataType() const { return m_dataType; };
  string GetName() const { return m_name; };
  string asString() const;
  void setDataType( const string& );
  void setName( const string& name ) { m_name = name; };
  bool IsNamed( const string& name ) const { return (m_name == name); };
  bool HasNonContiguousData() const { return m_dataType != DNA; };
  bool HasSNPs() const { return m_dataType == SNP; };
  
  string getXML(unsigned int numTabs) const;   //  From DataSourceIf
};

#endif

