// $Id: Converter_HapConverter.h,v 1.4 2002/06/25 03:17:40 mkkuhner Exp $

// HapConverter reads the info from a prepared Converter-Haplotype
// format file and uses it to rearrange the innards of a RegionDS.
// Specifically, may consolidate multiple former individuals into a
// single individual as indicated by the read file.

#ifndef CONVERTER_HAPCONVERTER
#define CONVERTER_HAPCONVERTER

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "Converter_ConverterIf.h"
#include "Converter_RegionDS.h"
#include <fstream.h>

typedef vector<IndividualDS> IndDSVec;

class HapConverter : public ConverterIf
{
private:
RegionDS& m_region;
Random& m_random;
long m_nindividuals;
vector<string> m_hapnames;

HapConverter();                               // deliberately undefined
HapConverter(const HapConverter&);            // deliberately undefined
HapConverter& operator=(const HapConverter&); // deliberately undefined


vector<long> ParsePhaseInfo(ifstream& input) const;
vector<string> PopHapNames(long ntopop);

// helper function for ReadHapInfo. The returned container
// will be empty if further processing is necessary.  May
// throw a FileFormatError.
IndDSVec ParseFirstLine(istrstream& firstline,
                        const string& filename,
                        ifstream& filestr);


public:
HapConverter(RegionDS& region, Random& m_random);
virtual ~HapConverter();

// This function can throw a FileFormatError.
IndDSVec ReadHapInfo(const string& filename);

void ReplaceIndividualsWith(IndDSVec& individuals);

void addConvertedLamarcDS (LamarcDS& lamarc);

};

#endif
