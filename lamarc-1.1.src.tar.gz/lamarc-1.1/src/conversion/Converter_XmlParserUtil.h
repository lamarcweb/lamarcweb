//$Id: Converter_XmlParserUtil.h,v 1.2 2002/06/25 03:17:42 mkkuhner Exp $

#ifndef Converter_XmlParserUtil
#define Converter_XmlParserUtil

/* 
 Copyright 2002 Patrick Colacurcio, Peter Beerli, Mary Kuhner, 
                Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "Converter_ParserUtil.h"
#include <string>
#include <vector>
#include <map>

using namespace std;


//  This file is the base class for all the ParserUtil classes.

class XmlParserUtil : public ParserUtil {
 private:
  vector<string> m_tagStack;

  // returns true for a start tag.  false for a end tag.
  // Throws if theres an error.
  bool stripTag(string& tagString, map<string, string>& tagInfo) const;

 protected:
  // No creation of just this class.
  XmlParserUtil();

  // finds the next xml tag.  Returns the text of that tag.  Updates the tagStack.  
  // The tagName will be in 'TagName'.  This is a dumb way to do it, but it should be okay.
  string getNextTag(istream& is, map<string, string>& tagInfo);
  // Gets the value of the current tag (the text between this and the current tags endtag)
  bool getTagValue(istream& is, string& buffer);
  // Returns the particular current dictionary in the xml tree.
  // Format of the string is dict <space> dict <space> etc...
  string getLocation() const;

  // Returns the top level TagName
  string getTopNodeName() const;
 public:

  virtual ~XmlParserUtil();
};

#endif
