// $Id: random.h,v 1.4 2002/06/25 03:17:52 mkkuhner Exp $

#ifndef _RANDOM
#define _RANDOM

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>

#define MAX_RANDOM  4294967296.0    // 2^31

class Random
{
           Random(const Random&);   // undefined
    Random operator=(Random);       // undefined

    long num0, num1, num2, num3;
    long n0, n1, n2, n3;
    long m0, m1, m2, m3;

    virtual void Next();

  public:
    Random();
    void Seed(long);
    void Read(char*);
    void Write(char*);
    void Advance(long);
    long Peek();
    long Integer();
    long Integer(long);
    double Float();
    char Base();
    std::string Name();
};

#endif

