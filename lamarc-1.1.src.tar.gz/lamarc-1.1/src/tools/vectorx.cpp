// $Id: vectorx.cpp,v 1.2 2002/06/25 03:17:53 mkkuhner Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <math.h>
#include "vectorx.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//___________________________________________________________
// maintenance functions

// forward declarations if helper functions of the maintenace functions
double logsave(const double value);
double log0(const double value);

// Take the natural logarithms of all elements in a vector
// and return a new vector. Does not check if an element is
// zero for speed reasons. 
vector <double> LogVec(const vector<double> &in)
{
  vector <double> out(in.size());
  transform(in.begin(),in.end(),out.begin(),log);    
  return out;
}
vector <double> LogVec0(const vector<double> &in)
{
  vector <double> out(in.size());
  transform(in.begin(),in.end(),out.begin(),log0);    
  return out;
}
 
vector <double>  LogVecSave(const vector<double> &in)
{
  vector <double> out(in.size());
  transform(in.begin(),in.end(),out.begin(),logsave);    
  return out;
}


// helper functions of the maintenace functions
double logsave(const double value)
{
  return ((value > 0.) ? log(value) : -DBL_MAX);
}


// helper functions of the maintenace functions
double log0(const double value)
{
  return ((value > 0.) ? log(value) : 0.0);
}

