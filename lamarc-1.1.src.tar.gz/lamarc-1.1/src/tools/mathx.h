// $Id: mathx.h,v 1.5 2002/06/26 19:11:54 lamarc Exp $

#ifndef _MATHX
#define _MATHX
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <math.h>
#include <vector>
#include "vectorx.h"

using std::vector;
double log_gamma(double x);
double my_gamma(double x);
double incompletegamma(double alpha, double x);
double probchi(long df, double chi);
double find_chi(long df, double prob);
DoubleVec1d gamma_rates(double alpha, long ratenum);
double alnorm (double x, int up);

/* obsolete?
class Gamma
{
    double alpha;
    double logAlpha;
    double logAlpha1;
    double invAlpha9;
    double sqrAlpha3;

  public:
                   Gamma();
                   Gamma(double);
    void           SetAlpha(double);
    DoubleVec1d    Calculate(long);         // number of divisions
    double         IncompleteGamma(double alpha, double x);
    double         LogGamma(double);
    double         Tail(double);
    double ProbChi2(long df , double chi);
    double FindChi2(long df, double prob);
};
*/

double SafeDivide(double num, double denom);
double logfac(long n);

#endif
