// $Id: stringx.cpp,v 1.22 2002/06/27 19:49:39 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcdebug.h"
#include <assert.h>
#include "stringx.h"
#include <stdexcept>
#include <functional>

using namespace std;

//_______________________________________________
//_______________________________________________

void UpperCase(string &s)
{
  long length, i;
  length = s.size();
  for (i = 0; i < length; i++)
    s[i] = toupper(s[i]);
}

//_______________________________________________

void LowerCase(string &s)
{
  long length, i;
  length = s.size();
  for (i = 0; i < length; i++)
    s[i] = tolower(s[i]);
}

//_______________________________________________
//_______________________________________________

string ToString(char character)
{
  ostrstream ostr;
  ostr << character << ends;
  string s(ostr.str());
  return s;
}

//_______________________________________________

string ToString(int number)
{
  ostrstream ostr;
  ostr << number << ends;
  string s(ostr.str());
  return s;
}

//_______________________________________________

string ToString(bool tag)
{
  string s;
  if(tag)
    s="Yes";
  else
    s="No";
  return s;
}

//_______________________________________________

string ToString(unsigned int number)
{
  ostrstream ostr;
  ostr << number << ends;
  string s(ostr.str());
  return s;
}

//_______________________________________________

string ToString(unsigned long number)
{
  ostrstream ostr;
  ostr << number << ends;
  string s(ostr.str());
  return s;
}

//_______________________________________________

string ToString(long number)
{
  ostrstream ostr;
  ostr << number << ends;
  string s(ostr.str());
  return s;
}

//_______________________________________________

string ToString(double number)
{
  ostrstream ostr;
  ostr << number << ends;
  string s(ostr.str());
  return s;
}

string ToString(paramlistcondition par)
{
  switch (par) {
    case YES: return "yes"; break;
    case NO: return "no"; break;
    case MIX: return "mix"; break;
    default: assert(false); return ""; break;
  }
}

string ToString(proftype prof)
{
  switch(prof) {
    case percentile: return "percentile"; break;
    case fix: return "fixed"; break;
    case none: return "none"; break;
    default: assert(false); return ""; break;
  }
}

//___________________________________________________

bool CaselessStrCmp(const string& lhs, const string& rhs)
{

  if (lhs.size() != rhs.size()) return false;

  size_t i;
  for (i = 0; i < lhs.size(); ++i) {
    if (toupper(lhs[i]) != toupper(rhs[i])) return false;
  }
  return true;

} /* CaselessStrCmp */

// char* overloads of the preceeding

bool CaselessStrCmp(const string& lhs, const char* rhs)
{
  return CaselessStrCmp(lhs, string(rhs));
} /* CaselessStrCmp */

bool CaselessStrCmp(const char* lhs, const string& rhs)
{
  return CaselessStrCmp(string(lhs), rhs);
} /* CaselessStrCmp */

bool CaselessStrCmp(const char* lhs, const char* rhs) 
{
  return CaselessStrCmp(string(lhs), string(rhs));
} /* CaselessStrCmp */

//____________________________________________________________

// case insensitive string comparison taken from Scott Meyers'
// _Effective STL_ items 19 and 35.

long ciCharCompare(char c1, char c2)
{
  long lc1 = toupper(static_cast<unsigned char>(c1));
  long lc2 = toupper(static_cast<unsigned char>(c2));
  if (lc1 < lc2) return -1;
  if (lc1 > lc2) return 1;
  return 0;
} /* ciCharCompare */

long ciStringCompareImpl(const string& s1, const string& s2) {
  typedef pair<string::const_iterator, string::const_iterator> PSCI;

  PSCI p = mismatch(s1.begin(),s1.end(), s2.begin(),
           not2(ptr_fun(ciCharCompare)));
  if (p.first == s1.end()) {
    if (p.second == s2.end()) return 0;
    else return -1;
  }
  return ciCharCompare(*p.first, *p.second);

} /* ciStringCompareImpl */

long ciStringCompare(const string& s1, const string& s2)
{
  if (s1.size() <= s2.size()) return ciStringCompareImpl(s1,s2);
  else return -ciStringCompareImpl(s2,s1);
} /* ciStringCompare */

bool ciCharLess(char c1, char c2)
{ 
  return
    toupper(static_cast<unsigned char>(c1)) <
    toupper(static_cast<unsigned char>(c2));
} /* ciCharLess */

bool ciStringLess(const string& s1, const string& s2)
{
  return lexicographical_compare(s1.begin(), s1.end(),
                                 s2.begin(), s2.end(),
                                 ciCharLess);
} /* ciStringLess */

bool ciStringEqual(const string& s1, const string& s2)
{ 
  return !ciStringCompare(s1, s2);
} /* ciStringEqual */

//____________________________________________________

// careful: was not able to link this function
// when its name was DoubleVecFromString(..)
bool FromString(const string & in, DoubleVec1d & out)
{
  if (in.empty()) return false;
  
  string whitespace(" \t"), input = in;
  while (!input.empty()) {
    double value;
    unsigned long start = input.find_first_not_of(whitespace);
    if (start == string::npos) break;

    unsigned long end = input.find_first_of(whitespace,start);
    if (end != string::npos) {
      FromString(input.substr(start,end-start),value);
      input = input.substr(end,input.size()-end);
    } else {
      FromString(input,value);
      input.erase();
    }

    out.push_back(value);
  }
 
  return true;

}

bool FromString(const string & in, LongVec1d & out)
{
  if (in.empty()) return false;
  
  string whitespace(" \t"), input = in;
  while (!input.empty()) {
    long value;
    unsigned long start = input.find_first_not_of(whitespace);
    if (start == string::npos) break;

    unsigned long end = input.find_first_of(whitespace,start);
    if (end != string::npos) {
      FromString(input.substr(start,end-start),value);
      input = input.substr(end,input.size()-end);
    } else {
      FromString(input,value);
      input.erase();
    }

    out.push_back(value);
  }

  return true;

}

bool FromString(const string & in, long& out)
{
  if(in.empty())
    return false;
  else
    {
      strstream mystream;
      mystream << in;
      mystream >> out;
    }
  return true;
}

bool FromString(const string & in, double& out)
{
  if(in.empty())
    return false;
  else
    {
      strstream mystream;
      mystream << in;
      mystream >> out;
    }
  return true;
}

//_______________________________________________


//_______________________________________________
//_______________________________________________

string MakeJustified(const string &stuff, long width)
{
long xtraspc = static_cast<long>(abs(width)) - stuff.size();

if (xtraspc <= 0)
   return(stuff.substr(0,abs(width)));

string str;
if (width < 0) {
   str = stuff + str.assign(xtraspc,' ');
} else {
   str = str.assign(xtraspc,' ') + stuff;
}

return(str);

} /* MakeJustified */

//__________________________________________________

string MakeJustified(const char *stuff, long width)
{
string str(stuff);

return(MakeJustified(str,width));

} /* MakeJustified */

//__________________________________________________

string MakeCentered(const string &str, long width,
   long indent, bool trunc)
{
string line;
long strsize = str.size(), numchar = 0, truewidth = width-indent;
long halfsize = strsize/2;

line.assign(indent,' ');
numchar += indent;

if (trunc && (strsize > truewidth)) {
   if (width - indent >= 0) {
      line.append(str.substr(0,truewidth));
      numchar += (str.substr(0,truewidth)).size();
   }
   return(line);
}

if (halfsize < truewidth/2) {
   line.append(truewidth/2-halfsize,' ');
   numchar += truewidth/2-halfsize;
}

line.append(str);
numchar += strsize;

char lastchar = str[strsize-1];
if (static_cast<long>(lastchar) != LINEFEED) {
   line.append(width-numchar,' ');
}

return(line);

} /* MakeCentered */

//__________________________________________________

string MakeCentered(const char *str, long width,
   long indent, bool trunc)
{
const string pstr(str);

return (MakeCentered(pstr,width,indent,trunc));

} /* MakeCentered */

//_______________________________________________
//_______________________________________________

/******************************************
 * function to format a double-precision  *
 * number into a fixed-width field, going *
 * to scientific notation as necessary.   *
 * The width must be greater than 5.  If  *
 * the number is greater than e+99 the    *
 * returned string may be longer than     *
 * the given field width.                 *
 ******************************************/

string Pretty(double p, long w) {
  ostrstream ost;
  if (w < 6) {
     ost << "*" << ends;
     return(string(ost.str()));
  }
  ost.width(w);
  ost.setf(ios::showpoint);

  if (fabs(p) >= 1.0 || p == 0.0) {  //greater than one, or zero
    ost.setf(ios::fixed);
    ost.setf(ios::scientific);
    if (fabs(p) >= pow(10.0,w-4)) ost.precision(w-5);
    else ost.precision(w-1);
  } else {              //less than one
    if (fabs(p) <= pow(0.01,w-4)) {
      ost.setf(ios::scientific);
      ost.unsetf(ios::fixed);
      ost.precision(w-6);
    }  else {
      ost.setf(ios::fixed);
      ost.unsetf(ios::scientific);
      ost.precision(w-2);
    }
  }
  ost << p << ends;
  return(string(ost.str()));
} /* Pretty(double) */

//  Overload of Pretty for long (much simpler!)

string Pretty(long p, long w) {
  ostrstream ost;
  ost.width(w);
  ost << p << ends;
  return(string(ost.str()));
} /* Pretty(long) */

string Pretty(unsigned long p, long w) {
  ostrstream ost;
  ost.width(w);
  ost << p << ends;
  return(string(ost.str()));
} /* Pretty(unsigned long) */

//  Overload of Pretty for string (much simpler!)

string Pretty(string str, long w) {
  if ((long)str.size() == w) return(str);
  if ((long)str.size() > w) return(str.substr(0,w));
/* WARNING warning -- doesn't do padding anymore
  long i;
  for (i = (long)str.size(); i < w; ++i) {
    str += " ";
  }
*/
  return(str);
} /* Pretty(string) */

//_______________________________________________
//_______________________________________________

bool StringCompare(const string &s1, const char *s2, long pos, long n)
{
  string temp = s1.substr(pos, n);
  return (temp == s2);
}

//_______________________________________________

bool StringCompare(const string &s1, const string &s2, long pos, long n)
{
  string temp = s1.substr(pos, n);
  return (temp == s2);
}

//_______________________________________________

bool CompareWOCase(const string& s1, const string& s2)
{
string str1, str2(s2);

transform(s1.begin(),s1.end(),str1.begin(),ptr_fun(tolower));
transform(s2.begin(),s2.end(),str2.begin(),ptr_fun(tolower));

return (str1 == str2);

} /* CompareWOCase(string,string) */

//_______________________________________________

bool CompareWOCase(const char* s1, const string& s2)
{
return CompareWOCase(string(s1),s2);
} /* CompareWOCase(char*,string) */

//_______________________________________________

bool CompareWOCase(const string& s1, const char* s2)
{
return CompareWOCase(s1,string(s2));
} /* CompareWOCase(string,char*) */

//_______________________________________________

bool CompareWOCase(const char* s1, const char* s2)
{
return CompareWOCase(string(s1),string(s2));
} /* CompareWOCase(char*,char*) */

//_______________________________________________
//_______________________________________________

int StringType(const string &s)
{
  long i = 0;
  while(isspace(s[i]))
    i++;

  // Alpha type _______________________________________________

  if (isalpha(s[i]))
    return 1;                                  // Alpha type

  if (s[i] == '_')
  {
    i++;
    while (s[i] == ' ')
      i++;

    if (isalnum(s[i]))
      return 1;                                // Alphanumeric type

    return 3;                                  // Punctuation type
  }

  // Numeric type _____________________________________________

  if (isdigit(s[i]))
    return 2;                                  // Numeric type

  if (s[i] == '.')
  {
    i++;
    if (isdigit(s[i]))
      return 2;                                // Numeric type

    return 3;                                  // Punctuation
  }

  if (s[i] == '-' || s[i] == '+')
  {
    i++;
    if (isdigit(s[i]))
      return 2;                                // Numeric type

    if (s[i] == '.')
    {
      i++;
      if (isdigit(s[i]))
        return 2;                              // Numeric type
    }
  }

  return 3;                                    // Punctuation
}

//_______________________________________________
//_______________________________________________

long GetCharacter(const string &s, char &ch, long posn)
{
  long len = s.size();
  if (posn < 0 || len <= posn)
    return string::npos;

  while(isspace(s[posn]))
    posn++;

  ch = s[posn];
  posn++;

  return posn;
}

//_______________________________________________

long FindToken(const string &s, long &posn)
{
  long len, n;
  char c;

  len = s.size();
  while (posn < len)
  {
    if (!isspace(s[posn]))
      break;

    posn++;
  }

  if (posn == len)
    return string::npos;                              // no more tokens

  n = posn;

  // Alpha-numeric type _______________________________

  c = s[n];
  if (isalpha(c) || c == '_')
  {
    if (c == '_')
    {
      n++;
      while (n < len)
      {
        if (s[n] != '_')
          break;

        n++;
      }

      if (n == len)
        return posn+1;                     // punctuation

      if (!isalnum(s[n]))
        return posn+1;                     // punctuation
    }

    n++;
    while (n < len)
    {
      c = s[n];
      if (!isalnum(c) && c != '_' && c != '-')
        break;

      n++;
    }

    return n;
  }

  // Numeric type _____________________________________

  c = s[n];
  if (isdigit(c) || strchr(".-+", c))
  {
    // Check for initial '+' or '-' sign
    if (c == '-' || c == '+')
    {
      n++;
      if (n == len)
        return posn+1;                     // punctuation

      c = s[n];
      if (!isdigit(c) && c != '.')
        return posn+1;                     // punctuation
    }

    while (n < len)
    {
      if (!isdigit(s[n]))
        break;

      n++;
    }

    if (s[n] == '.')                      // Check for decimal point
    {
      n++;
      if (n == len)
        return n-1;

      if (!isdigit(s[n]))                 // Next character must be a digit
        return n-1;

      n++;
      while (n < len)
      {
        if (!isdigit(s[n]))
          break;

        n++;
      }
    }

    // Check for exponent notation
    c = s[n];
    if (c == 'e' || c == 'E')
    {
      long n2 = n;

      n++;
      if (n < len)
        return n2;

      c = s[n];
      if (!isdigit(c) && c != '-' && c != '+')
        return n2;

      if (c == '-' || c == '+')
      {
        n++;
        if (n == len)
          return n2;

        if (!isdigit(s[n]))
          return n2;
      }

      n++;
      while (n < len)
      {
        while (!isdigit(s[n]))
          break;

        n++;
      }
    }

    return n;
  }

  // Punctuation _____________

  n++;
  return n;
}

//_______________________________________________

long GetToken(const string &src, string &dst, long posn)
{
  unsigned long n = src.size();
  unsigned long position = posn;
  if (position == string::npos) return string::npos;
  if (n <= position) return string::npos;

  n = FindToken(src, posn);
  if (n != string::npos)
    dst = src.substr(posn, n-posn);

  return n;
}

//_______________________________________________

long SkipToken(const string &src, long posn)
{
  unsigned long len = src.size();
  unsigned long p = posn; 
  if (p == string::npos) return string::npos;
  if (len <= p) return string::npos;

  return FindToken(src, posn);
}

//_______________________________________________

long GetToken(const string &src, string &dst, long posn, const string& delimiter, bool include)
{
  unsigned long size, p;

  size = src.size();
  if (posn < 0 || size <= static_cast<unsigned long>(posn))
    return string::npos;

  p = src.find(delimiter, posn);

  if (p == string::npos)
    p = size;
  else
  {
    if (include)
      p += delimiter.size();
  }

  dst = src.substr(posn, p - posn);
  p++;
  return p;
}

//_______________________________________________

long SkipToken(const string &src, long posn, const string& 
  delimiter, bool include)
{
  long size, p;

  size = src.size();
  if (posn < 0 || size <= posn)
    return string::npos;

  p = src.find(delimiter, posn) + 1;
  if (p)
  {
    if (include)
      p += delimiter.size();
  }

  else
    p = size;

  return p;
}


/**********************************************************************
 Linewrap wraps a table (contained in a vector of strings) so that
 it is no longer than the given linelength.  It uses the following
 rules:
 (1) Break at a column in which all entries have spaces or nothing.
 (2) Lines which consist only of dash and space may be broken anywhere.
 (3) If no acceptable break can be found, the original vector will be
 returned.

 It uses the function IsSeparator(const string) as a helper function.
***********************************************************************/

vector<string> Linewrap(vector<string> invec, long linelength) {

// find a suitable location to wrap
long site, line;
long oldsize = invec.size();
bool found = false;
long breakpoint = -1;

for (line = 0; line < oldsize; ++line) {
  if ((long)invec[line].size() > linelength) found = true;
}
if (!found) return(invec);          // didn't need wrapping at all

for (site = linelength; site >=0; site--) {
  found = true;
  for (line = 0; line < oldsize; line++) {
    if ((long)invec[line].size() <= site) continue; // skip short lines
    if (IsSeparator(invec[line])) continue;         // skip separators
    if (invec[line][site] != ' ') {
      found = false;
      break;
    }
  }
  if (found) {
    breakpoint = site;
    break;
  }
}

if (breakpoint == -1)              // never found a breakpoint
  return(invec);                   // give up and don't wrap at all

// cut each line at that location 
vector<string> firstpart;
vector<string> secondpart;
for (line = 0; line < oldsize; ++line) {
  if ((long)invec[line].size() <= breakpoint) {   // line does not need cutting
     firstpart.push_back(invec[line]);
     secondpart.push_back(string(""));
  } else {                            // line does need cutting
     firstpart.push_back(invec[line].substr(0, breakpoint));
     secondpart.push_back(invec[line].substr(breakpoint+1,
       invec[line].size() - breakpoint));
  }
}

//wrap the second part recursively, in case it's very long
secondpart = Linewrap(secondpart, linelength);

//catenate first and second parts
for (line = 0; line < (long)secondpart.size(); ++line) {
  firstpart.push_back(secondpart[line]);
}

return(firstpart);

} /* Linewrap */


//__________________________________________________________________
// Is a string composed solely of dash, underscore and/or space?
bool IsSeparator(const string s) {
  long i;
  for (i = 0; i < (long)s.size(); ++i) {
    if (s[i] != ' ' && s[i] != '-' && s[i] != '_') return (false);
  }
  return(true);
} /* IsSeparator */

//__________________________________________________________________

bool StringToBool(const string& src)
{
  if (src == "true" || src == "TRUE" || src == "True") {
    return true;
  }
  if (src == "false" || src == "FALSE" || src == "False") {
    return false;
  }
  invalid_argument e("Invalid argument to StringToBool");
  throw e;

} /* StringToBool */

//__________________________________________________________

bool IsInteger(const string& src)
{
  long i;
  long end = src.size();
  bool minusfound = false;
  for (i = 0; i < end; ++i) {
    if (isspace(src[i])) continue;  // whitespace is okay
    if (src[i] == '-') {
      if (minusfound) return false;
      else {
        minusfound = true;
        continue;
      }
    }
    if (!isdigit(src[i])) return false;
  }
  return true;
} /* IsInteger */

//__________________________________________________________

bool IsReal(const string& src)
{
  long i;
  long end = src.size();
  bool pointfound = false;
  for (i = 0; i < end; ++i) {
    if (!isdigit(src[i])) {
      if (isspace(src[i])) continue; // whitespace is okay
      if (src[i] == '-') continue; // minus is okay
      if (src[i] != '.') return false;  // neither digit nor point
      if (pointfound) return false;   // a second decimal point?!
      pointfound = true;              // okay, first decimal point
    }
  }
  return true;
} /* IsReal */

//__________________________________________________________
//__________________________________________________________




