// $Id: random.cpp,v 1.4 2002/06/26 19:11:54 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcdebug.h"
#include <iostream>
#include <fstream>
#include <time.h>
#include <assert.h>
#include "random.h"
#include "stringx.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

Random::Random()
{
  num0 = 0;
  num1 = 0;
  num2 = 0;
  num3 = 0;

  n0 = 0;
  n1 = 0;
  n2 = 0;
  n3 = 0;

  m0 = 0;
  m1 = 0;
  m2 = 0;
  m3 = 0;
}

//_______________________________________________________________

void Random::Seed(long seed)
{
  if (seed < 0)
  {
    time_t tm;
    time(&tm);
    seed = tm;
  }

  num0 = seed % 256;
  seed = seed / 256;
  num1 = seed % 256;
  seed = seed / 256;
  num2 = seed % 256;
  seed = seed / 256;
  num3 = seed % 256;
}

//_______________________________________________________________

void Random::Read(char *filename)
{
  long seed;

  ifstream file;
  file.open(filename);
  file >> seed;
  file.close();

  Seed(seed);
}

//_______________________________________________________________

void Random::Write(char *filename)
{
  ofstream file;
  file.open(filename,ios::app);
  file << Float() << endl;
  file.close();
}

//_______________________________________________________________

void Random::Next()
{
  n0 = 5      + num0*13;
  n1 = n0/256 + num1*13 + num0*102;
  n2 = n1/256 + num2*13 + num1*102 + num0*25;
  n3 = n2/256 + num3*13 + num2*102 + num1*25;

  num0 = n0&255;
  num1 = n1&255;
  num2 = n2&255;
  num3 = n3&255;
}

//_______________________________________________________________

void Random::Advance(long n)
{
  long i;

  for (i = 0; i < n; i++)
    Next();
}

//_______________________________________________________________

long Random::Peek()
{
  return ((num3*256 + num2)*256 + num1)*256 + num0;
}

//_______________________________________________________________

long Random::Integer()
{
  Next();

  return ((num3*256 + num2)*256 + num1)*256 + num0;
}

//_______________________________________________________________

long Random::Integer(long m)
{
  Next();

  m0 = m % 256;
  m /= 256;
  m1 = m % 256;
  m /= 256;
  m2 = m % 256;
  m /= 256;
  m3 = m % 256;

  n0 =          num0*m0;
  n1 = n0/256 + num1*m0 + num0*m1;
  n2 = n1/256 + num2*m0 + num1*m1 + num0*m2;
  n3 = n2/256 + num3*m0 + num2*m1 + num1*m2 + num0*m3;
  n0 = n3/256           + num3*m1 + num2*m2 + num1*m3;
  n1 = n0/256                     + num3*m2 + num2*m3;
  n2 = n1/256                               + num3*m3;
  n3 = n2/256;

  n0 %= 256;
  n1 %= 256;
  n2 %= 256;
  n3 %= 256;

  return ((n3*256 + n2)*256 + n1)*256 + n0;
}

//_______________________________________________________________

double Random::Float()
{
  Next();

  return (num3 + (num2 + (num1 + num0/256.0)/256.0)/256.0)/256.0;
}

//_______________________________________________________________

char Random::Base()
{
long whichbase = Integer(4);
if (whichbase == 0) return 'A';
if (whichbase == 1) return 'C';
if (whichbase == 2) return 'G';
if (whichbase == 3) return 'T';

assert(false); // unknown base in Random::Base()
return 'X';

}

//_______________________________________________________________

string Random::Name()
{
string name;

name = ToString(Base()) + ToString(Base()) + ToString(Integer());

return name;

}
