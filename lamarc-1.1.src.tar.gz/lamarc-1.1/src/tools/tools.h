// $Id: tools.h,v 1.1.1.1 2001/12/05 19:37:38 mkkuhner Exp $

// This is just a catch-all include file for all of the program
//    specific extensions to the standard library

#ifndef TOOLS
#define TOOLS

#include "stringx.h"
#include "vectorx.h"

#endif
