// $Id: stringx.h,v 1.13 2002/06/25 03:17:53 mkkuhner Exp $

#ifndef _STRINGX
#define _STRINGX

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include <iostream>
#include <strstream>
#include <math.h>
#include <vector>
#include <iomanip>
#include "constants.h"
#include "vectorx.h"
#include <functional>

// needed in .h because of template functions
#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif


//using std::string;
//using std::vector;
using namespace std;

  const long DEFLINELENGTH=75;
  const long DEFWIDTH=8;
  const long DEFINDENT=0;
  const long LINEFEED=10;

  void   UpperCase(string&);
  void   LowerCase(string&);
  string ToString(char);
  string ToString(int);
  string ToString(long);
  string ToString(double);
  string ToString(unsigned int);
  string ToString(unsigned long);
  string ToString(bool);
  string ToString(paramlistcondition par);
  string ToString(proftype prof);

  bool CaselessStrCmp(const string& lhs, const string& rhs);
  bool CaselessStrCmp(const string& lhs, const char* rhs);
  bool CaselessStrCmp(const char* lhs, const string& rhs);
  bool CaselessStrCmp(const char* lhs, const char* rhs);

//_______________________________________________________________

// Scott Meyers' case-insensitive string comparison code

  long ciCharCompare(char c1, char c2);
  long ciStringCompareImpl(const string& s1, const string& s2);
  long ciStringCompare(const string& s1, const string& s2);
  bool ciCharLess(char c1, char c2);
// Scott called the following ciStringCompare but then there are
// two functions of that name....
  bool ciStringLess(const string& s1, const string& s2);

  struct CIStringCompare : public binary_function<string, string, bool>
  {
    bool operator()(const string& lhs, const string& rhs) const
    { return ciStringLess(lhs, rhs); }
  }; /* CIStringCompare struct */

  bool ciStringEqual(const string& s1, const string& s2);

//_______________________________________________________________

template <class T>
string ToString(T number, int decimals)
{
  ostrstream ostr;
  ostr.precision(decimals);
  ostr << " " << number;
  ostr << ends;
  string s(ostr.str());
  return s;
}

template <class T>
string ToString(vector <T> number, int decimals)
{
  ostrstream ostr;
  ostr.precision(decimals);
  vector <T> :: const_iterator nit;
  for(nit=number.begin(); nit!=number.end(); nit++)
    {
      ostr << " " << *nit;
    }
  ostr << ends;
  string s(ostr.str());
  return s;
}

template <class T>
string ToString(vector <T> number)
{
  int decimals = 2;
  return ToString(number, decimals);
}

// careful: was not able to link this function
// when its name was DoubleVecFromString(..)
bool FromString(const string & in, DoubleVec1d & out);
bool FromString(const string & in, LongVec1d & out);
bool FromString(const string & in, long& out);  
bool FromString(const string & in, double& out);  


string MakeJustified(const string & str, long width=DEFLINELENGTH);
string MakeJustified(const char* str, long width=DEFLINELENGTH);
string MakeCentered(const string& str, long width=DEFLINELENGTH,
		    long indent=DEFINDENT, bool trunc=true);
string MakeCentered(const char* str, long width=DEFLINELENGTH,
		    long indent=DEFINDENT, bool trunc=true);
string Pretty(double number, long width=DEFWIDTH);
string Pretty(long number, long width=DEFWIDTH);
string Pretty(unsigned long number, long width=DEFWIDTH);
string Pretty(string str, long width=DEFWIDTH);

bool   StringCompare(const string&, const char*, long, long);
bool   StringCompare(const string&, const string&, long, long);

bool   CompareWOCase(const string& str1, const string& str2);
bool   CompareWOCase(const char* str1, const string& str2);
bool   CompareWOCase(const string& str1, const char* str2);
bool   CompareWOCase(const char* str1, const char* str2);

int    StringType(const string&);
long   GetCharacter(const string&, char&, long);
long   FindToken(const string&, long&);
long   GetToken(const string&, string&, long);
long   SkipToken(const string&, long);
long   GetToken(const string&, string&, long, const string&, bool include=false);
long   SkipToken(const string&, long, const string&, bool include=false);

// free functions used to wrap tables
vector<string> Linewrap(vector<string> invec, long linelength = 80);
bool           IsSeparator(const string s);

// this one throws an exception if it fails
bool StringToBool(const string& src);

template<class T> bool InBounds(T val, T lower, T upper);

bool IsInteger(const string& src);
bool IsReal(const string& src);
//bool IsBool(const string& src);


template<class T>
bool InBounds(T val, T lower, T upper)
{
  return (lower <= val && val <= upper);
} /* InBounds */

#endif



