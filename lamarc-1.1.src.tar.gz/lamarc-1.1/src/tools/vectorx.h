// Vector utilities 
//
// VECTOR SETTERS
// - Sets n-dimensional vector to an initial value,
//   assumes that the vector has allocated elements
// VECTOR CREATION
// - Creates 1-D and 2-D vectors with an initial value
// VECTOR TYPES
// - Typedefs for n-dimensional vectors
// VECTOR MATH UTILITIES
// - vector = Log(vector) in save and unsave (sic!) versions of it.
// VECTOR TRANSMOGRIFIER
// - turn a 1D into a 2D vector (must be square!)
//
// $Id: vectorx.h,v 1.3 2002/06/25 03:17:53 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#ifndef __VECTORX_H_
#define __VECTORX_H_

#include <vector>
#include <algorithm>
#include <string>
#include "definitions.h"

using std::vector;
using std::string;

// VECTOR CREATION ------------------------------------------------------ 
//    a set of vector of vectors setters:
//    there is no error checking, these will *return* a new vector and

template <class T> 
vector <T>  CreateVec1d(long n, T initial)
{
  vector<T> one(static_cast<vector<T>::size_type> (n),initial);
  return one;
}

template <class T> 
vector < vector <T> > CreateVec2d(long n, unsigned long m, T initial)
{
  vector<T> one(static_cast<vector<T>::size_type> (m),initial);
  vector < vector <T> > two(n,one); 
  return two;
}


// VECTOR DEFINITIONS --------------------------------------------------- 
// Typedefs for commonly used multidimensional vectors
/* WARNING:  At least some version of g++ refuse to accept a 4+
   dimensional vector of vectors unless they have already, in
   compiling that source file, found a smaller vector.  To work
   around this bug it may be necessary to declare a dummy vector.
*/

typedef vector<string>        StringVec1d;
typedef vector<StringVec1d>   StringVec2d;
typedef vector<StringVec2d>   StringVec3d;
typedef vector<StringVec3d>   StringVec4d;
typedef vector<StringVec4d>   StringVec5d;

typedef vector<double>        DoubleVec1d;
typedef vector<DoubleVec1d>   DoubleVec2d;
typedef vector<DoubleVec2d>   DoubleVec3d;
typedef vector<DoubleVec3d>   DoubleVec4d;
typedef vector<DoubleVec4d>   DoubleVec5d;

typedef vector<long>          LongVec1d;
typedef vector<LongVec1d>     LongVec2d;
typedef vector<LongVec2d>     LongVec3d;
typedef vector<LongVec3d>     LongVec4d;
typedef vector<LongVec4d>     LongVec5d;

typedef vector<int>           IntVec1d;
typedef vector<IntVec1d>      IntVec2d;
typedef vector<IntVec2d>      IntVec3d;
typedef vector<IntVec3d>      IntVec4d;
typedef vector<IntVec4d>      IntVec5d;

//__________________________________________________________________
//__________________________________________________________________

/* VectorAppend() puts "vec2" onto the end of "vec1" */
template <class T>
vector<T> VectorAppend(const vector<T>& vec1, const vector<T>& vec2)
{
vector<T> vec = vec1;
vector<T>::const_iterator vit;
for(vit = vec2.begin(); vit != vec2.end(); ++vit)
   vec.push_back(*vit);

return(vec);

} /* VectorAppend */

//__________________________________________________________________
//__________________________________________________________________

// VECTOR MATH UTILITIES ------------------------------------------------------ 
//
vector <double> LogVec(const vector<double> &in);
vector <double> LogVec0(const vector<double> &in);
vector <double> LogVecSave(const vector<double> &in);

//__________________________________________________________________

/* This function takes a linear vector and turns it into
a square two-dimensional vector.  It will throw an exception
if the size of the linear vector is not a perfect square. 
It assumes that diagonal entries ARE PRESENT.

It is templated on the type contained in the vector. */

template<class T>
vector<vector<T> > SquareOffVector(const vector<T>& src)
{

  // this is a funny-looking way to take a square root,
  // necessitated by the fact that the C library only provides
  // floating-point square root, and we don't want to deal with
  // the consequences of rounding error.

  long i;
  long n = src.size();
  long dim = 0;

  for (i = 1; i <= long(n/2); ++i) {
    if (i * i == n) {
      dim = i;
      break;
    }
  }

  if (dim == 0) throw ("Attempt to SquareOff a non-square vector");

  // convert linear matrix into square matrix

  vector<T> vec1D;
  vector<vector<T> > vec2D;
  vector<T>::const_iterator it = src.begin();

  vec1D.reserve(dim);                   // for speed
  vec2D.reserve(dim);

  long j;

  for (i = 0; i < dim; i++)
  {
    for (j = 0; j < dim; ++j, ++it) {
      vec1D.push_back(*it);
    }

    vec2D.push_back(vec1D);
    vec1D.clear();
  }

  return vec2D;

} /* SquareOffVector */ 

#endif





