//$Id: mathx.cpp,v 1.3 2002/06/25 03:17:52 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "vectorx.h"
#include "mathx.h"
#include <math.h>
#include <iostream>
#include <stdio.h>
#include "definitions.h"
#include "errhandling.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

#ifdef HAVE_LGAMMA
#define LGAMMA lgamma
#else
#define LGAMMA mylgamma
#endif
//______________________________________________________________________________
double mylgamma (double z);

//______________________________________________________________________________
// Calculation of rate values following a gamma distribution for
// given probability values.

DoubleVec1d gamma_rates(double alpha, long ratenum)
{
  vector<double> values;
  double x, low, mid, high, xlow, xhigh, freq, inc, mid0;
  long i, j;

  values.reserve(ratenum);

  x    = 10.0;
  inc  = 1.0 / (double)ratenum;
  freq = -inc / 2.0;
  mid0 = incompletegamma(alpha, 10.0);

  for (i = 0; i < ratenum; i++)
  {
    low   = 0;
    mid   = mid0;
    high  = 1.0;
    freq += inc;

    if (freq < mid)
    {
      high  = mid;
      xlow  = 0;
      xhigh = 10.0;
      x     = 5.0;
    }

    else
    {
      low   = mid;
      xlow  = 10.0;
      xhigh = 1e10;
      x     = 1e5;
    }

    for (j = 0; j < 1000 && fabs(low - high) > 0.0001 && x > 0.000000001; j++)
    {
      mid = incompletegamma(alpha, x);
      if (freq < mid)
      {
        high  = mid;
        xhigh = x;
        x     = (x + xlow) / 2.0;
      }

      else
      {
        low  = mid;
        xlow = x;
        x    = (x + xhigh) / 2.0;
      }
    }

    if (x >= 10e10)
    {
      values.clear();
      break;
    }

    values.push_back(x / alpha);
  }

  return values;
}

//______________________________________________________________________________

#define MIN(a,b) (((a)<(b)) ? (b) : (a))

double my_gamma(double x) 
{ 
  return exp(log_gamma(x));
}


double
alnorm (double x, int up)
{
  /* Initialized data */
  /* *** machine dependent constants ????????????? */
  /*static */ double zero = 0.;
  /*static */ double a1 = 5.75885480458;
  /*static */ double a2 = 2.62433121679;
  /*static */ double a3 = 5.92885724438;
  /*static */ double b1 = -29.8213557807;
  /*static */ double b2 = 48.6959930692;
  /*static */ double c1 = -3.8052e-8;
  /*static */ double c2 = 3.98064794e-4;
  /*static */ double c3 = -.151679116635;
  /*static */ double c4 = 4.8385912808;
  /*static */ double c5 = .742380924027;
  /*static */ double one = 1.;
  /*static */ double c6 = 3.99019417011;
  /*static */ double d1 = 1.00000615302;
  /*static */ double d2 = 1.98615381364;
  /*static */ double d3 = 5.29330324926;
  /*static */ double d4 = -15.1508972451;
  /*static */ double d5 = 30.789933034;
  /*static */ double half = .5;
  /*static */ double ltone = 7.;
  /*static */ double utzero = 18.66;
  /*static */ double con = 1.28;
  /*static */ double p = .398942280444;
  /*static */ double q = .39990348504;
  /*static */ double r = .398942280385;

  /*static */ double y, result;

  if (x < zero)
    {
      up = !up;
      x = -x;
    }
  if (x <= ltone || (up && x <= utzero))
    {
      y = half * x * x;
      if (x > con)
	{
	  result =
	    r * exp (-y) / (x + c1 +
			    d1 / (x + c2 +
				  d2 / (x + c3 +
					d3 / (x + c4 +
					      d4 / (x + c5 +
						    d5 / (x + c6))))));
	  return ((!up) ? one - result : result);
	}
      result =
	half - x * (p - q * y / (y + a1 + b1 / (y + a2 + b2 / (y + a3))));
      return ((!up) ? one - result : result);
    }
  else
    {
      return ((!up) ? 1.0 : 0.);
    }
  /*fake */ return -99;
}				/* alnorm */

//  ALGORITHM AS239  APPL. STATIST. (1988) VOL. 37, NO. 3 
//  Computation of the Incomplete Gamma Integral 
//  Auxiliary functions required: LogG() = logarithm of the gamma function,
//  and Tail() = algorithm AS66 
//  In Mathematica, this is GammaRegularized[a,0,x] == Gamma[a,0,x]/Gamma[a]
double incompletegamma (double alpha, double x)
{
  double gama, d_1, d_2, d_3;
  /*static */ double a, b, c, an, rn;
  /*static */ double pn1, pn2, pn3, pn4, pn5, pn6, arg;

  gama = 0.;
  /*  Check that we have valid values for X and P */
  if (alpha <= 0. || x < 0.) {
    logic_error e("Failure in incomplete-gamma calculation");
    throw e;
  }
  if (fabs (x) < DBL_EPSILON)
    return gama;

  /*  Use a normal approximation if P > PLIMIT */
  if (alpha > 1e3)
    {
      pn1 =
	sqrt (alpha) * 3. * (pow (x / alpha, (1. / 3.)) + 1. / (alpha * 9.) -
			     1.);
      gama = alnorm(pn1, false);
      return gama;
    }

  /*  If X is extremely large compared to P then set GAMMAD = 1 */
  if (x > 1e8)
    {
      gama = 1.;
      return gama;
    }

  if (x <= 1. || x < alpha)
    {
      /*  Use Pearson's series expansion. */
      /*  (Note that P is not large enough to force overflow in lgamma()). */
      arg = alpha * log (x) - x - LGAMMA (alpha + 1.);
      c = 1.;
      gama = 1.;
      a = alpha;
      while (c > 1e-14)
	{
	  a += 1.;
	  c = c * x / a;
	  gama += c;
	}
      arg += log (gama);
      gama = 0.;
      if (arg >= -88.)
	{
	  gama = exp(arg);
	}

    }
  else
    {
      /*  Use a continued fraction expansion */
      arg = alpha * log (x) - x - LGAMMA (alpha);
      a = 1. - alpha;
      b = a + x + 1.;
      c = 0.;
      pn1 = 1.;
      pn2 = x;
      pn3 = x + 1.;
      pn4 = x * b;
      gama = pn3 / pn4;
      for (;;)
	{
	  a += 1.;
	  b += 2.;
	  c += 1.;
	  an = a * c;
	  pn5 = b * pn3 - an * pn1;
	  pn6 = b * pn4 - an * pn2;
	  if (fabs (pn6) > 0.)
	    {
	      rn = pn5 / pn6;
	      /* Computing MIN */
	      d_2 = 1e-14, d_3 = rn * 1e-14;
	      if ((d_1 = gama - rn, fabs (d_1)) <= MIN (d_2, d_3))
		{
		  arg += log (gama);
		  gama = 1.;
		  if (arg >= -88.)
		    {
		      gama = 1. - exp (arg);
		    }
		  return gama;
		}
	      gama = rn;
	    }
	  pn1 = pn3;
	  pn2 = pn4;
	  pn3 = pn5;
	  pn4 = pn6;
	  if (fabs (pn5) >= 1e37)
	    {
	      /*  Re-scale terms in continued fraction if terms are large */
	      pn1 /= 1e37;
	      pn2 /= 1e37;
	      pn3 /= 1e37;
	      pn4 /= 1e37;
	    }
	}
    }
  return gama;
}				/* incompletegamma() */


//_______________________________________________________________________
// Uses Lanczos-type approximation to ln(gamma) for z > 0.
//  Reference: Lanczos, C. 'A precision approximation of the gamma function',
//      J. SIAM Numer. Anal., B, 1, 86-96, 1964.
//  Accuracy: About 14 significant digits except for small regions
//      in the vicinity of 1 and 2.
//  Programmer: Alan Miller CSIRO Division of Mathematics & Statistics
//  Latest revision - 17 April 1988

double log_gamma(double z)
{
  if (z <= 0.0)
      return DBL_MAX; // This will kill the receiving calculation.

  long i;
  double result, denom;

  double a[] = { 1.659470187408462e-7, 9.934937113930748e-6,
                -0.1385710331296526,  12.50734324009056,
              -176.6150291498386,    771.3234287757674,
             -1259.139216722289,     676.5203681218835 };

  result = 0.0;
  denom  = z + 7.0;
  for (i = 0; i < 8; i++)
  {
    result += a[i] / denom;
    denom  -= 1.0;
  }  

  result += 0.9999999999995183;
  result = log(result) - (z + 6.5) + (z - 0.5) * log(z + 6.5) + 0.9189385332046727;
  return result;
}


double
find_chi (long df, double prob)
{
  double a, b, m;
  double xb = 200.0;
  double xa = 0.0;
  double xm = 5.;
  a = probchi (df, xa);
  m = probchi (df, xm);
  b = probchi (df, xb);
  while (fabs (m - prob) > EPSILON)
    {
      if (m < prob)
	{
	  b = m;
	  xb = xm;
	}
      else
	{
	  a = m;
	  xa = xm;
	}
      xm = (-(b * xa) + prob * xa + a * xb - prob * xb) / (a - b);	//(xa + xb)/2.;

      m = probchi (df, xm);
    }
  return xm;
}


double
probchi (long df, double chi)
{
  double prob;
  double v = ((double) df) / 2.;
  if (chi > DBL_EPSILON && v > DBL_EPSILON)
    {
      //lg = EXP (LGAMMA (v));
      prob = 1. - incompletegamma (v, chi / 2.);
    }
  else
    prob = 1.0;
  //  printf("prob=%f v=%f chi=%f lg(v/2)=%f  ig(chi/2,v/2)=%f\n",
  //  prob,v,chi,lg, incompletegamma(chi/2.,v/2.));

  return prob;
}


  /*       Uses Lanczos-type approximation to ln(gamma) for z > 0. */
  /*       Reference: */
  /*            Lanczos, C. 'A precision approximation of the gamma */
  /*                    function', J. SIAM Numer. Anal., B, 1, 86-96, 1964. */
  /*       Accuracy: About 14 significant digits except for small regions */
  /*                 in the vicinity of 1 and 2. */
  /*       Programmer: Alan Miller */
  /*                   CSIRO Division of Mathematics & Statistics */
  /*       Latest revision - 17 April 1988 */
  /* translated and modified into C by Peter Beerli 1997 */
double
mylgamma (double z)
{
  double a[9] = { 0.9999999999995183, 676.5203681218835,
    -1259.139216722289, 771.3234287757674, -176.6150291498386,
    12.50734324009056, -0.1385710331296526, 9.934937113930748e-6,
    1.659470187408462e-7
  };
  double lnsqrt2pi = 0.9189385332046727;
  double result;
  long j;
  double tmp;
  if (z <= 0.)
    {
      return DBL_MAX;		/*this will kill the receiving calculation */
    }
  result = 0.;
  tmp = z + 7.;
  for (j = 9; j >= 2; --j)
    {
      result += a[j - 1] / tmp;
      tmp -= 1.;
    }
  result += a[0];
  result = log (result) + lnsqrt2pi - (z + 6.5) + (z - 0.5) * log (z + 6.5);
  return result;
}				/* lgamma */


//______________________________________________________________________________

double SafeDivide(double num, double denom)
{
if (denom) {
   return num/denom;
} else {
   return DBL_BIG;
}

} /* SafeDivide */

//_______________________________________________________________________

double logfac (long n)
{
  /* log(n!) values were calculated with Mathematica
     with a precision of 30 digits */
  switch (n)
    {
    case 0:
      return 0.;
    case 1:
      return 0.;
    case 2:
      return 0.693147180559945309417232121458;
    case 3:
      return 1.791759469228055000812477358381;
    case 4:
      return 3.1780538303479456196469416013;
    case 5:
      return 4.78749174278204599424770093452;
    case 6:
      return 6.5792512120101009950601782929;
    case 7:
      return 8.52516136106541430016553103635;
    case 8:
      return 10.60460290274525022841722740072;
    case 9:
      return 12.80182748008146961120771787457;
    case 10:
      return 15.10441257307551529522570932925;
    case 11:
      return 17.50230784587388583928765290722;
    case 12:
      return 19.98721449566188614951736238706;
    default:
      return LGAMMA (n + 1.);
    }
} /* logfac */

