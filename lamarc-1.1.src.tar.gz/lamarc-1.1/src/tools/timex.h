// $Id: timex.h,v 1.2 2002/06/25 03:17:53 mkkuhner Exp $
#ifndef TIMEX
#define TIMEX    

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <vector>
#include "vectorx.h"
#include <string>
#include "stringx.h"
#include <iostream>
#include <strstream>
#include <math.h>
#include <time.h>

/*****************************************************************
 These functions handle time information.  GetTime retrieves the
 current time as a time_t (seconds since the epoch).  PrintTime
 turns a time_t into a formatted string.
 Mary Kuhner (based on code of Peter Beerli) October 2000
*****************************************************************/

string PrintTime(const time_t mytime, const string format = "%H:%M:%S");

time_t GetTime();

#endif

