// $Id: menu.cpp,v 1.28 2002/06/26 19:11:53 lamarc Exp $

// the base menu is the NON-Interactive "menu"
// derived menus handel the different windowing systems
//  - Curses
//  - Scrolling ASCII console
//  (-graphical GUI etc)
// Peter Beerli

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

const long foo1 = 100;

#include <string>
#include <time.h>
#include "stringx.h"
#include "vectorx.h"
#include "registry.h"
#include "arranger.h"
#include "xml.h"
#include "constants.h"

#include <vector>
#include <algorithm>
#include <functional>
#include <numeric>
#include "menuitem.h"
#include "menu.h"
#include "dialog.h"
#include "parameter.h"
#include "force.h"

extern vector < MenuItem >::const_iterator find_key (vector < MenuItem >
						     &content, string key);

string
progress_to_string (verbosity_type progress)
{
  switch (progress)
    {
    case CONCISE:
      return string ("concise");
    case NORMAL:
      return string ("normal");
    case NONE:
      return string ("none");
    case VERBOSE: 
      return string("verbose");
    default:
      return string ("");
    }
}


Menu::Menu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, Dialog & thisdialog):registry (thisregistry),
datafile (thisdatafile),
datapack (thisdatapack), dialog (thisdialog)
{
  dialog = thisdialog;
  dialog.Initialize ();
}

Menu::~Menu ()
{
  dialog.Cleanup ();
}

// Menu construction ---------------------------------
bool
Menu::AddMenuLine (string key, string text, Menu * handler)
{
  MenuItem menuitem;
  MenuHandlerPtr foo = &Menu::nohandle;
  MenuDisplayPtr goo = &Menu::nodisplay;
  menuitem.SetItem (key, text, handler, foo, goo);
  content.insert (content.end (), menuitem);
  return true;
}

bool
Menu::AddMenuLine (vector < MenuItem > &, string key,
		   string text, Menu * handler)
{
  MenuItem menuitem;
  MenuHandlerPtr foo = &Menu::nohandle;
  MenuDisplayPtr goo = &Menu::nodisplay;
  menuitem.SetItem (key, text, handler, foo, goo);
  content.insert (content.end (), menuitem);
  return true;
}

bool
Menu::AddMenuLine (string key, string text, Menu * handler,
		   MenuHandlerPtr foo, MenuDisplayPtr goo)
{
  MenuItem menuitem;
  menuitem.SetItem (key, text, handler, foo, goo);
  content.insert (content.end (), menuitem);
  return true;
}

bool
Menu::AddMenuLine (string key, string text, Menu * handler,
		   MenuHandlerPtr foo, MenuDisplayPtr goo, long id)
{
  MenuItem menuitem;
  menuitem.SetItem (key, text, handler, foo, goo, id);
  content.insert (content.end (), menuitem);
  return true;
}

bool
Menu::AddMenuLine (vector < MenuItem > &localcontent, string key,
		   string text, Menu * handler, MenuHandlerPtr foo,
		   MenuDisplayPtr goo)
{
  MenuItem menuitem;
  menuitem.SetItem (key, text, handler, foo, goo);
  localcontent.insert (localcontent.end (), menuitem);
  return true;
}

bool
Menu::AddMenuLine (vector < MenuItem > &localcontent, string key,
		   string text, Menu * handler,
		   MenuHandlerPtr foo, MenuDisplayPtr goo, long id)
{
  MenuItem menuitem;
  menuitem.SetItem (key, text, handler, foo, goo, id);
  localcontent.insert (localcontent.end (), menuitem);
  return true;
}

bool
Menu::Show ()
{
  menu_return_type done = NOTFOUND;
  while (done == NOTFOUND)
    {
      dialog.Title (title);
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  return done;
}

menu_return_type
Menu::DoTaskWith (string & input)
{
  vector < MenuItem >::const_iterator menuline;
  menu_return_type done = NOTFOUND;
  menuline = find_key (content, input);
  if (menuline == content.end ())
    {
      Show ();
    }
  else
    {
      done = (menuline->GetHandler ()->*menuline->p) (input);
    }
  return done;
}

menu_return_type
Menu::OnError (string input)
{
  string errorline = "Error: " + input;
  dialog.Title (errorline);
  file_error e(errorline);
  throw e;
  return FAILURE;
}

menu_return_type
Menu::Acknowledge (string &)
{
  //  cout << "+++ " << endl; 
  return SUCCESS;
}

//void Menu::SetChainParameters(ChainParameters & thischainparms)
//{ 
//  chainparms = thischainparms;
//}
//void Menu::SetUserParameters(UserParameters & thisuserparms)
//{ 
//  userparms = thisuserparms;
//}
//void Menu::SetForceSummary(ForceSummary & thisforcesummary)
//{ 
//  forcesummary = thisforcesummary;
//}

DataMenu::DataMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack,
      thisdialog), MAXTRIES(3)
{
  name = string ("DataMenu");
  string
    one =
    "       L A M A R C      Likelihood Analysis with                \n";
  string
    two =
    "                        Metropolis-Hastings algorithms           \n";
  string
    tre =
    "                        using Random Coalescences               \n";
  string
    four =
    "---------------------------------------------------------------------------\n";
  title = one + two + tre + four;

  AddMenuLine (string ("*"),
	       string ("Enter the location of the data file\n"),
           this, &Menu::nohandle, &Menu::makeStringWithDefaultInputFileName);
}

DataMenu::~DataMenu ()
{
  // cout << "data menu died" << endl;
}


string Menu::makeStringWithDefaultInputFileName(long)
{
    string defaultfilename;
    string fname = registry.GetUserParameters().GetDataFileName();
    if(fname == "") 
    {
        defaultfilename = "[No default set]\n";
    }
    else
    {
        defaultfilename = "[Default: "+ fname + "]\n";
    }
    return defaultfilename;
} // Menu::askForInputFileWhileListingDefault

bool
DataMenu::Show ()
{
  menu_return_type done = NOTFOUND;
  long counter = 0;
  string filenotfoundmessage("File not found, try again");
  dialog.Title (title);
  while (done == NOTFOUND && counter++ < MAXTRIES)
    {
      if(counter>1)
      {
        dialog.Title(filenotfoundmessage);
      }
      dialog.Show (content);
      done = dialog.Interact (content);
      if (done == NOTFOUND ) 
      { 
          // erase default file name in userparams 
          registry.GetUserParameters().SetDataFileName ("");
      }
    }
  if (done == NOTFOUND)
    OnError(string("Unable to read or find your file"));
  return done;
}

menu_return_type
DataMenu::DoTask ()
{
  menu_return_type done = NOTFOUND;
  return done;
}

menu_return_type
DataMenu::DoTaskWith (string & input)
{
  if (input.size () != 0)
    registry.GetUserParameters().SetDataFileName (input);
  bool rc = datafile.ReadFile (registry.GetUserParameters().GetDataFileName ());
  return (rc ? SUCCESS : NOTFOUND);
}

menu_return_type
DataMenu::Acknowledge (string &)
{
  string message = "Data file was read successfully\n\n";
// MARY
  message += "Calculating starting values; please be patient";
  dialog.Message (message);
  return SUCCESS;
}




//-----------------------------------------------------------------
/*ParamMenu::ParamMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
  Dialog &thisdialog) 
  : Menu(thisregistry,thisdatafile,thisdatapack,thisdialog)
  {

  name = string("ParamMenu");
  string defaultfilename = userparms.GetParamFileName();
  if(defaultfilename == "")
  defaultfilename = "[No default set]\n";
  else
  defaultfilename = "[Default: "+ defaultfilename + "]\n";
  AddMenuLine(string("*"), string("Enter the location of the parameter file\n"+defaultfilename), this,&Menu::SetParamFileMenu, &Menu::nodisplay);
  }

  ParamMenu::~ParamMenu()
  {
 
  }

  menu_return_type  ParamMenu::DoTask()
  {
  menu_return_type done = NOTFOUND;
  return done;
  }

  menu_return_type ParamMenu::SetParamFileMenu(string & input)
  {
  menu_return_type done;
  done = dialog.Interact(content);
  userparms.SetParamFileName(input);
  bool rc = SUCCESS; //paramfile.ReadFile(userparms.GetParamFileName());
  return (rc ? SUCCESS : FAILURE);
  }
  //menu_return_type ParamMenu::DoTaskWith(string & input)
  //{
  // if(input.size()!=0)
  //  userparms.SetParamFileName(input);
  //bool rc = false ; //paramfile.ReadFile(userparms.GetParamFileName());
  //return (rc ? SUCCESS : FAILURE);
  //}

  menu_return_type  ParamMenu::Acknowledge(string & input)
  {
  string message = "Parameter file was read successfully";
  dialog.Message(message);
  return SUCCESS;
  }
*/


//-----------------------------------------------------------------
DataModelMenu::DataModelMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack,
      thisdialog)
{
  name = string ("DataModelMenu");
  string
    regionname;
  long
    nregions =
    datapack.
    GetNRegions ();
  long
    i,
    id;
  for (i = 0; i < nregions; i++)
    touchedparameters.push_back (false);
  title = string ("Data models");
  if (nregions > 1)
    {
      AddMenuLine (string ("G"),
		   string ("Apply global data model to ALL regions"),
		   this, &Menu::SetDataModelMenu, &Menu::GetDataModelMenu);
      AddMenuLine (string ("P"),
		   string
		   ("Apply global model to untouched regions only"),
		   this, &Menu::SetDataModelMenu, &Menu::GetDataModelMenu);
    }
  for (i = 0, id = 1; i < nregions; i++, id++)
    {
      regionname = datapack.GetRegion (i).GetRegionName ();

      AddMenuLine (ToString (id),
		   string ("Set model for Region ") + ToString (id) + ": " + regionname,
		   this, &Menu::SetDataModelMenu, &Menu::GetDataModelMenu, id);
    }
  AddMenuLine (string ("Y"), string ("Return to Main Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

DataModelMenu::~DataModelMenu ()
{
  //  cout << "data menu died" << endl;
}

menu_return_type
DataModelMenu::DoTask ()
{
  menu_return_type done = NOTFOUND;
  return done;
}

menu_return_type
DataModelMenu::DoTaskWith (string & input)
{
  vector < MenuItem >::const_iterator menuline;
  menu_return_type done = NOTFOUND;
  menuline = find_key (content, input);
  if (menuline == content.end ())
    {
      Show ();
    }
  else
    {
      done = (menuline->GetHandler ()->*menuline->p) (input);
    }
  return done;
}

menu_return_type
DataModelMenu::SetDataModelMenu (string & input)
{
  menu_return_type done = NOTFOUND;
  string localname;
  string localtitle = SetLocalWork (input, localname);
  if (work == GLOBALDATAMODELMENU)
    ResetTouchedParameters ();
  SetLocalContent ();
  dialog.Title (localtitle);
  content.swap (localcontent);
  while (done != SUCCESS)
    {
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  localcontent.swap (content);
  return NOTFOUND;
}


string
DataModelMenu::SetLocalWork (string & input, string & name)
{
  unsigned long i;
  string localtitle;
  char test = getFirstInterestingChar(input);
  string regionlist;

  for (i = 0; i < touchedparameters.size () - 1; i++)
    {
      if (!touchedparameters[i])
	{
	  regionlist.append (datapack.GetRegion (i).GetRegionName ());
	  regionlist.append (string (", "));
	}
    }
  if (!touchedparameters[i])
    regionlist.append (datapack.GetRegion (i).GetRegionName ());
  if (test == 'P')
    {
      if (regionlist.size () == 0)
	test = 'G';
    }
  switch (test)
    {
    case 'G':
      localtitle =
	string
	("Change of all regions [displayed numbers are from first region]");
      name = string ("Global DataModelMenu");
      work = GLOBALDATAMODELMENU;
      cursor = -2;
      break;
    case 'P':
      localtitle = string ("Change of regions that are not touched\n") +
	string ("[") + regionlist + string ("]");
      name = string ("Partial DataModelMenu");
      work = PARTIALDATAMODELMENU;
      cursor = -1;
      break;
    default:
      work = REGIONDATAMODELMENU;
      cursor = atol (input.c_str ()) - 1;
      localtitle =
	string ("Change for Region ") + ToString (cursor + 1) +
	string (": ") + datapack.GetRegion (cursor).GetRegionName ();
      name = string ("Regional DataModelmenu");
      break;
    }
  return localtitle;
}

void
DataModelMenu::SetLocalContent ()
{
  localcontent.clear ();
  AddMenuLine (localcontent, string (" "),
	       string ("                                "), NULL);
  AddMenuLine (localcontent, string ("1"),
	       string ("Data model of region              "),
	       this, &Menu::SetRegionDataModel, &Menu::GetRegionDataModel);

  string datamodeltype(GetRegionDataModel(cursor));
  if (datamodeltype == string("Felsenstein '84"))
    {
      AddMenuLine (localcontent, string ("2"),
	       string ("Transition / Transversion Ratio  "), this,
	       &Menu::SetTTRatio, &Menu::GetTTRatio);
      AddMenuLine (localcontent, string ("3"),
	       string ("Base Frequencies                 "), this,
	       &Menu::SetBaseFrequencies, &Menu::GetBaseFrequencies);
  //  AddMenuLine(localcontent, string("4"), 
  //      string("Fast likelihood calculation"), 
  //      this, &Menu::SetNormalizeLike , 
  //      &Menu::GetNormalize);
      AddMenuLine (localcontent, string ("4"),
	       string ("Rate Categories and Probabilities"),
	       this, &Menu::SetRateCategories, &Menu::GetRateCategories);
      AddMenuLine (localcontent, string ("5"),
	       string ("Normalization"),
	       this, &Menu::SetNormalization, &Menu::GetNormalization);
    }

  if (datamodeltype == string("Stepwise"))
    {
      AddMenuLine (localcontent, string ("2"),
	       string ("Rate Categories and Probabilities"),
	       this, &Menu::SetRateCategories, &Menu::GetRateCategories);
   //   AddMenuLine(localcontent, string("1"), 
   //       string("Fast likelihood calculation"), 
   //       this, &Menu::SetNormalizeLike , 
   //       &Menu::GetNormalize);
    }

  if (datamodeltype == string("Brownian"))
    {
      AddMenuLine (localcontent, string ("2"),
	       string ("Rate Categories and Probabilities"),
	       this, &Menu::SetRateCategories, &Menu::GetRateCategories);
    }

  AddMenuLine (localcontent, string ("Y"),
	       string ("Return to Data Model Menu        "), this,
	       &Menu::Quit, &Menu::Quit2);
}

string
DataModelMenu::GetDataModelMenu (long)
{
  return " ";
}

void
DataModelMenu::ResetTouchedParameters ()
{
  fill (touchedparameters.begin (), touchedparameters.end (), false);
}


long
DataModelMenu::GetFirstNotTouched ()
{
  unsigned long i;

  for (i = 0; i < touchedparameters.size (); i++)
    if (!touchedparameters[i])
      return (long) i;
  return (long) -1;
}

menu_return_type
DataModelMenu::SetRegionDataModel (string & input)
{
  menu_return_type done = NOTFOUND;
  string datatype;
  string quest;

  long which =
    (cursor == -2 ? 0 : (cursor == -1 ? GetFirstNotTouched () : cursor));
  if (which >= 0)
    touchedparameters[which] = true;

  datatype = datapack.GetRegion (which).datatype->GetDataType ();

  quest = string ("Your data looks like ")
    + datatype + "\n" + string ("Choose either\n");
  if (datatype == "DNA Sequence" || datatype == "SNP data")
    quest += string("F  Felsenstein 84 model\n");
  else if (datatype == "Microsatellite")
    quest += string("B  Brownian motion\nS  Stepwise\n");
  input = dialog.AskRead (quest);

  char firstchar = getFirstInterestingChar(input);

  // modified by Mary so that DNA data cannot accidentally be given a
  // microsat model or vice versa

  bool succeeded = false;

  switch (firstchar) {
    case 'B' : 
      if (datatype == "Microsatellite") {
        DataModel_ptr newmodel(new BrownianModel);
        datapack.GetRegion(which).ChangeTo(newmodel);
        succeeded = true;
      } 
      break;
    case 'S':
      if (datatype == "Microsatellite") {
        DataModel_ptr newmodel(new StepwiseModel);
        datapack.GetRegion(which).ChangeTo(newmodel);
        succeeded = true;
      } 
      break;
    case 'F':
      if (datatype == "DNA Sequence" || datatype == "SNP data") {
        // this is not currently necessary since there is only one DNA data model
        DataModel_ptr newmodel(new F84Model);
        datapack.GetRegion(which).ChangeTo(newmodel);
        succeeded = true;
      } 
      break;
    default:
       // do nothing; "succeeded" will remain false
      {}
  }

  // DEBUG give the user some feedback if !succeeded

  //DEBUG here coes the loop over all regions to adjust datatype.
  //What does this comment mean?? --Mary

  return done;
}


string
DataModelMenu::GetRegionDataModel (long)
{
  long which =
    (cursor == -2 ? 0 : (cursor == -1 ? GetFirstNotTouched () : cursor));
  return datapack.GetRegion (which).datamodel->GetDataModelName ();
}

string
DataModelMenu::GetTTRatio (long)
{
  long which =
    (cursor == -2 ? 0 : (cursor == -1 ? GetFirstNotTouched () : cursor));
  DataModel *model = datapack.GetRegion (which).datamodel.get ();
  double ttratio = dynamic_cast < F84Model * >(model)->GetTTratio ();
  return ToString (ttratio);
}

menu_return_type
DataModelMenu::SetTTRatio (string & input)
{
  menu_return_type done = NOTFOUND;
  DataModel *model;

  string quest = string ("Enter the Transition-Transversion ratio");
  double ttratio = 0;
  do
    {
      input = dialog.AskRead (quest);
      ttratio = atof (input.c_str ());
    }
  // MARY change from 0.0 (ttratio <= 0.5 is illegal)
  while (ttratio <= 0.5);
  long nregions = datapack.GetNRegions ();
  long reg;

  switch (work)
    {
    case GLOBALDATAMODELMENU:
      for (reg = 0; reg < nregions; reg++)
	{
	  model = datapack.GetRegion (reg).datamodel.get ();
	  dynamic_cast < F84Model * >(model)->SetTTratio (ttratio);
	}
      break;
    case PARTIALDATAMODELMENU:
      for (reg = 0; reg < nregions; reg++)
	{
	  if (!touchedparameters[reg])
	    {
	      model = datapack.GetRegion (reg).datamodel.get ();
	      dynamic_cast < F84Model * >(model)->SetTTratio (ttratio);
	    }
	}
      break;
    case REGIONDATAMODELMENU:
      model = datapack.GetRegion (cursor).datamodel.get ();
      dynamic_cast < F84Model * >(model)->SetTTratio (ttratio);
      touchedparameters[cursor] = true;
      break;
    }
  return done;
}

string
DataModelMenu::GetBaseFrequencies (long)
{
  string output;
  long which =
    (cursor == -2 ? 0 : (cursor == -1 ? GetFirstNotTouched () : cursor));
  DataModel *model = datapack.GetRegion (which).datamodel.get ();
  vector < double >bases =
    dynamic_cast < F84Model * >(model)->GetBaseFrequencies ();
  return ToString (bases);
}

menu_return_type
DataModelMenu::SetBaseFrequencies (string & input)
{
  menu_return_type done = NOTFOUND;
  bool usebasefreq = false;
  string quest = string ("Enter the base frequencies for A C G T or\n");
  quest += (isalpha (input.c_str ()[0]) ?
	    string
	    ("(g)lobal      to calculate base frequencies from the data\n")
	    : string (""));
  quest +=
    string
    ("(a)utomatic   to calculate the base frequencies for each region\n")
    + string ("(=)           to set them all to 0.25\n");
  string quest2 = quest;
  double sum = 0;
  double diff;
  long touched;
  DoubleVec1d bases (4);
  DoubleVec1d allbases (4);
  DoubleVec1d::iterator ab;
  DoubleVec1d::iterator b;
  while ((diff = fabs (1. - sum)) > 0.01)
    {
      input = dialog.AskRead (quest);
      bases = CheckBases (input);
      sum = accumulate (bases.begin (), bases.end (), 0.0);
      quest =
	string ("Bases do not add up to 1.0: ") + ToString (bases) +
	string (" = ") + ToString (sum) + string ("\n") + quest2;
    }

  // do we want to calculate the basefreq from the data?
  char test = getFirstInterestingChar(input);
  if (strchr ("AG", test))
    usebasefreq = true;

  if (diff != 0.0)
    {
      vector < double >::iterator bit;
      for (bit = bases.begin (); bit != bases.end (); bit++)
	{
	  *bit /= sum;
	}
    }

  vector < Region * >::const_iterator regit;
  deque < bool >::iterator touchit;
  vector < Region * >&regions = datapack.GetAllRegions ();

  switch (work)
    {
    case GLOBALDATAMODELMENU:
      ResetTouchedParameters ();
    case PARTIALDATAMODELMENU:	//remember: touchedparameters.size()===regions.size()
      touched = 0;
      for (touchit = touchedparameters.begin (),
	   regit = regions.begin ();
	   regit != regions.end (); touchit++, regit++)
	{
	  if (!(*touchit))
	    {
	      if (usebasefreq)
		{
		    (*regit)->datamodel->Initialize (**regit);
		  bases =
		    dynamic_cast <
		    F84Model *
		    >((*regit)->datamodel.get ())->GetBaseFrequencies ();
		}
              else
                {
	          dynamic_cast <
       		  F84Model *
		  >((*regit)->datamodel.get ())->SetBaseFrequencies (bases);
                }
	      *touchit = true;
	      if (test == 'G')
		{
		  for (ab = allbases.begin (), b = bases.begin ();
		       ab != allbases.end (); ab++, b++)
		    *ab += *b;
		  touched++;
		}
	    }
	  if (test == 'G')
	    {
	      for (ab = allbases.begin (), b = bases.begin ();
		   ab != allbases.end (); ab++, b++)
		*b = *ab / touched;
	    }
	}
      break;
    case REGIONDATAMODELMENU:
      regit = regions.begin () + cursor;

      if (usebasefreq)
	{
	    (*regit)->datamodel->Initialize (**regit);
	  bases =
	    dynamic_cast <
	    F84Model * >((*regit)->datamodel.get ())->GetBaseFrequencies ();
	}
      dynamic_cast <
	F84Model * >((*regit)->datamodel.get ())->SetBaseFrequencies (bases);
      touchedparameters[cursor] = true;
      break;
    }
  return done;
}

vector < double >
DataModelMenu::CheckBases (string & input)
{
  vector < double >bases;
  vector < char >other;
  char ch;
  double bt;
  strstream iostream;
  iostream << input << ends;
  iostream >> ch;
  if (ch == '=' || toupper (ch) == 'A' || toupper (ch) == 'G')	//automatic is deferred 
    {				// to switch statement in SetBaseFrequencies
      bases.push_back (0.25);
      bases.push_back (0.25);
      bases.push_back (0.25);
      bases.push_back (0.25);
      return bases;
    }
// MARY:  not safe to reuse the stream (don't know why....)
//  iostream.clear();
//  iostream << input << ends;
  
  strstream iostream2;
  iostream2 << input << ends;
  iostream2 >> bt;
  bases.push_back (bt);
  iostream2 >> bt;
  bases.push_back (bt);
  iostream2 >> bt;
  bases.push_back (bt);
  iostream2 >> bt;
  bases.push_back (bt);
  return bases;
}

string
DataModelMenu::GetRateCategories (long)
{
  long which =
    (cursor == -2 ? 0 : (cursor == -1 ? GetFirstNotTouched () : cursor));
  DataModel *model = datapack.GetRegion (which).datamodel.get ();
  long ncategs = model->GetNcategories ();
  return ncategs > 1 ? string ("Multiple Rates") : string ("Single Rate");
}

menu_return_type
DataModelMenu::SetRateCategories (string & input)
{
  const long NCATS = 1;
  DoubleVec1d CATRATES (NCATS, 1.0);
  DoubleVec1d CATPROBS (NCATS, 1.0);
  long which =
    (cursor == -2 ? 0 : (cursor == -1 ? GetFirstNotTouched () : cursor));
  menu_return_type done = NOTFOUND;
  bool finished = false;
  string quest;
  DataModel_ptr datamodel = datapack.GetRegion (which).datamodel;
  long ncategs;
  DoubleVec1d catrates;
  DoubleVec1d catrprobs;
  double autocorr;
  ncategs = datamodel->GetNcategories ();
  catrates = datamodel->GetCatRates ();
  catrprobs = datamodel->GetCatProbabilities ();
  autocorr = 1.0 / datamodel->GetAcratio ();
  while (!finished)
    {
      quest = string ("Current Setting:\n")
	+ string ("Rates                  : ") + ToString (catrates)
	+ string ("\nProbability Defaults   : ")
	+ ToString (catrprobs) + string ("\n");
      if (ncategs > 1)
	quest += string ("Correlation among sites: ")
	  + ToString (autocorr) + string ("\n");
      quest += string ("\nHow many categories [for no change press RETURN]");
      input = dialog.AskRead (quest);
      if (input.size () == 0)
	break;			// no change
      ncategs = atol (input.c_str ());
      if (ncategs < 1)
	continue;
      catrates.assign(ncategs,1.0);
      catrprobs.assign(ncategs,1./ncategs);
      if (ncategs == NCATS)
	{
	  finished = true;
	  break;
	}
      quest = string ("Enter the rates for the categories\n")
	+ string ("[Defaults: ") + ToString (catrates) + string ("]\n");
      input = dialog.AskRead (quest);
      vector < double >::iterator cit;
      strstream instream;
      instream << input;
      for (cit = catrates.begin (); cit != catrates.end (); cit++)
	{
	  instream >> *cit;
	}
      quest = string ("Enter the frequencies for the categories\n")
	+ string ("[They will be scaled to add up to 1.0]\n")
	+ string ("Rates               : ") + ToString (catrates)
	+ string ("\nFrequencies Defaults: ")
	+ ToString (catrprobs) + string ("\n");
      input = dialog.AskRead (quest);
      instream << input;
      double sum = 0.0;
      for (cit = catrprobs.begin (); cit != catrprobs.end (); cit++)
	{
	  instream >> *cit;
	  sum += *cit;
	}
      for (cit = catrprobs.begin (); cit != catrprobs.end (); cit++)
	{
	  *cit /= sum;
	}
      quest = string ("Enter the Correlation among sites\n")
	+
	string
	("[a value of 2 means that two neighboring sites will have similar rates]")
	+ string ("\nAutocorrelation rate Default: ") +
	ToString (autocorr) + string ("\n");
      do
	{
	  input = dialog.AskRead (quest);
	  if(input.size()==0 && autocorr > DBL_EPSILON)
	    break;
	  autocorr = atof (input.c_str ());
	}
      while (autocorr < DBL_EPSILON);
      finished = true;
    }

  vector < Region * >::iterator regit;
  deque < bool >::iterator touchit;
  vector < Region * >&regions = datapack.GetAllRegions ();

  switch (work)
    {
    case GLOBALDATAMODELMENU:
      ResetTouchedParameters ();
    case PARTIALDATAMODELMENU:
      for (touchit = touchedparameters.begin (),
	   regit = regions.begin ();
	   regit != regions.end (); touchit++, regit++)
	{
	  if (!(*touchit))
	    {
	      datamodel = (*regit)->datamodel;
	      datamodel->SetNcategories (ncategs);
	      datamodel->SetCatRates (catrates);
	      datamodel->SetCatProbabilities (catrprobs);
	      datamodel->SetAcratio (autocorr);
	      *touchit = true;
	    }
	}
      break;
    case REGIONDATAMODELMENU:
      datamodel->SetNcategories (ncategs);
      datamodel->SetCatRates (catrates);
      datamodel->SetCatProbabilities (catrprobs);
      datamodel->SetAcratio (autocorr);
      touchedparameters[cursor] = true;
      break;
    }
  return done;
}


string
DataModelMenu::GetNormalization (long)
{
  long which =
    (cursor == -2 ? 0 : (cursor == -1 ? GetFirstNotTouched () : cursor));
  DataModel *model = datapack.GetRegion (which).datamodel.get ();
  bool doNorm = model->ShouldNormalize ();
  return doNorm ? string("ON") : string("OFF");
}

menu_return_type
DataModelMenu::SetNormalization (string & input)
{
    menu_return_type done = NOTFOUND;

    switch (work)
    {
        case GLOBALDATAMODELMENU: 
            // Not implemented
            break;
        case PARTIALDATAMODELMENU:
            // Not implemented
            break;
        case REGIONDATAMODELMENU:
            DataModel * model;
            model = datapack.GetRegion (cursor).datamodel.get ();
            string dataModelName = model->GetDataModelName ();

            bool currNormalizeValue = model->ShouldNormalize();
            bool canNormalize = true; 

            if(dataModelName == "Brownian")
            {
                // should never get here because this is already checked
                // in an including menu
                canNormalize = false;
            }
            if(canNormalize)
            {
                string queryString = string ("Normalize? (Current value is ")
                    + ( currNormalizeValue ? string("ON") : string("OFF") )
                    + string (" [y/n])");
                input = dialog.AskRead(queryString);
                bool doNormalize = (getFirstInterestingChar(input) == 'Y' ) ? true : false;
                datapack.GetRegion (cursor).datamodel.get()->SetNormalize(doNormalize);
                touchedparameters[cursor] = true;
            }
            else
            {
                dialog.Message("Cannot set normalization for this model type");
            }
            break;
    }
    return done;
}

//-----------------------------------------------------------------
ForcesMenu::ForcesMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, ForceSummary & thisforcesummary, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack, thisdialog),
forcesummary (thisforcesummary),
datapack (thisdatapack)
{
  title = string ("Evolutionary Forces\n");
  AddMenuLine (string (" "),
	       string ("                                "), NULL);
  AddMenuLine (string ("C"),
	       string ("Effective population size     "),
	       this, &Menu::SetCoalescenceMenu, &Menu::GetCoalescenceMenu);
  AddMenuLine (string ("G"),
	       string ("Effective growth rate         "),
	       this, &Menu::SetGrowthMenu, &Menu::GetGrowthMenu);
  AddMenuLine (string ("M"), string ("Migration parameters and model"),
	       this, &Menu::SetMigrationMenu, &Menu::GetMigrationMenu);
  AddMenuLine (string ("R"), string ("Recombination parameter       "),
	       this, &Menu::SetRecombinationMenu,
	       &Menu::GetRecombinationMenu);
  AddMenuLine (string ("U"),
	       string ("Undo all changes in Evolutionary Forces"), this,
	       &Menu::Undo, &Menu::Undo2);
  AddMenuLine (string ("Y"), string ("Return to Main Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

ForcesMenu::~ForcesMenu ()
{

}


//Default setup if nothing is there then create a default
void
ForcesMenu::Defaults ()
{
}

//menu_return_type ForcesMenu::DoTask()
//{
//  menu_return_type done = NOTFOUND;
//  return done;
//}

//use the one in base Menu: ForcesMenu::DoTaskWith(string & input)

// THETA material ------------------------------------------------
void
ForcesMenu::SetLocalThetaContent ()
{
  localcontent.clear ();
  localtitle = string ("Coalescence: Starting Theta values");
  AddMenuLine (localcontent, string (" "),
	       string ("                                "), NULL);
  if (datapack.GetNPopulations () > 1)
    {
      AddMenuLine (localcontent, string ("G"),
		   string
		   ("Set all Thetas to the same value                "),
		   this, &Menu::SetThetaGlobal, &Menu::GetThetaGlobal);
    }
  AddMenuLine(localcontent, string("F"), 
      string("Use FST to generate starting Theta values          "), 
      this, &Menu::SetThetaFST , 
      &Menu::GetThetaFST);
  AddMenuLine (localcontent, string ("W"),
	       string
	       ("Use WATTERSON's estimator for Theta values     "),
	       this, &Menu::SetThetaWatterson, &Menu::GetThetaWatterson);

  StringVec1d populationnames = datapack.GetPopulationNames ();
  StringVec1d::const_iterator pid;
  long id;

  for (pid = populationnames.begin (), id = 1;
       pid != populationnames.end (); pid++, id++)
    {
      AddMenuLine (localcontent,
		   ToString (id),
		   string ("Pop. ") + ToString (id) + ": " + (*pid),
		   this, &Menu::SetThetaOWN, &Menu::GetThetaOWN, id);
    }
  AddMenuLine (localcontent, string ("Y"),
	       string ("Return to Evolutionary Forces Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

string
ForcesMenu::GetCoalescenceMenu (long)
{
  if (forcesummary.CheckForce(COAL))
    return string ("ON ");
  else
    return string ("OFF");
}

menu_return_type
ForcesMenu::SetCoalescenceMenu (string &)
{
  menu_return_type done = NOTFOUND;
  SetLocalThetaContent ();
  content.swap (localcontent);
  while (done != SUCCESS)
    {
      dialog.Title (localtitle);
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  localcontent.swap (content);
  return NOTFOUND;
}

string
ForcesMenu::GetThetaGlobal (long)
{
  return " ";
}

menu_return_type
ForcesMenu::SetThetaGlobal (string & input)
{
  DoubleVec1d thetas = forcesummary.GetStartParameters ().GetThetas ();
  unsigned long npop = datapack.GetNPopulations ();
  if (thetas.size () < npop)
    thetas.resize (npop, 0.0);
  DoubleVec1d::iterator tid;
  string quest = string ("Enter a Theta value");
  double theta = -1.;
  while (theta <= 0)
    {
      input = dialog.AskRead (quest);
      strstream iostream;
      iostream << input << ends;
      iostream >> theta;
    }
  for (tid = thetas.begin (); tid != thetas.end (); tid++)
    *tid = theta;
  forcesummary.GetStartParameters ().SetThetas (thetas);
  vector < string > method;
  method.resize (npop, USER);
  forcesummary.SetMethods (COAL, method);
  return NOTFOUND;
}

string
ForcesMenu::GetThetaFST (long)
{
  return " ";
}

menu_return_type
ForcesMenu::SetThetaFST (string &)
{
  long npop = datapack.GetNPopulations ();
  vector < string > method(npop,FST);
  forcesummary.SetMethods (COAL, method);
  DoubleVec1d thetas = (*forcesummary.GetForceByTag(COAL))->QuickCalc(datapack);
  forcesummary.GetStartParameters ().SetThetas (thetas);
  return NOTFOUND;
}

string
ForcesMenu::GetThetaWatterson (long)
{
  return " ";
}

menu_return_type
ForcesMenu::SetThetaWatterson (string &)
{
  // MARY
  string message("Computing Watterson's estimator of Theta\n");
  dialog.Message(message);

  long npop = datapack.GetNPopulations ();
  vector < string > method(npop,WATTERSON);
  forcesummary.SetMethods (COAL, method);
  DoubleVec1d thetas = (*forcesummary.GetForceByTag(COAL))->QuickCalc(datapack);
  forcesummary.GetStartParameters ().SetThetas (thetas);
  return NOTFOUND;
}

string
ForcesMenu::GetThetaOWN (long id)
{
  DoubleVec1d thetas = forcesummary.GetStartParameters ().GetThetas ();
  if (thetas.size () == 0)
    return string (" ");
  return ToString (thetas[id - 1]);
}

menu_return_type
ForcesMenu::SetThetaOWN (string & input)
{
  long pop = atol (input.c_str ()) - 1;
  DoubleVec1d thetas = forcesummary.GetStartParameters ().GetThetas ();
  if (thetas.size () == 0)
    thetas.resize (datapack.GetNPopulations ());

  string populationname = (datapack.GetPopulationNames ())[pop];
  double defaulttheta = thetas[pop];
  string
    quest =
    string ("Enter a Theta value for Population ") +
    input +
    string (": ") +
    populationname +
    string ("\n[Default: ") + ToString (defaulttheta) + string ("]");
  double theta = -1.;
  while (theta <= 0)
    {
      input = dialog.AskRead (quest);
      if (input.size () == 0)
	theta = defaulttheta;
      strstream iostream;
      iostream << input << ends;
      iostream >> theta;

    }
  thetas[pop] = theta;
  forcesummary.GetStartParameters ().SetThetas (thetas);
  forcesummary.SetForce(COAL,datapack);
  vector < string > method = forcesummary.GetMethods (COAL);
  method.resize (thetas.size ());
  method[pop] = USER;
  forcesummary.SetMethods (COAL, method);
  return NOTFOUND;
}

// GROWTH material ------------------------------------------------
void
ForcesMenu::SetLocalGrowthContent (bool allowed)
{
  localcontent.clear ();
  localtitle = string ("Growth: Starting growth rate values\nSpecify G = g/mu, shrinking population migh have a G= -10,\n rapidly growing population G=200");
  AddMenuLine (localcontent, string (" "),
	       string ("                                "), NULL);
  AddMenuLine (localcontent, string ("X"),
	       string ("Allow/Disallow Growth estimation"), this,
	       &Menu::SetGrowthAllow, &Menu::GetGrowthAllow);
  if (allowed)
    {
      if (datapack.GetNPopulations () > 1)
	{
	  AddMenuLine (localcontent, string ("G"),
		       string
		       ("Set all Growth rates to the same value          "),
		       this, &Menu::SetGrowthGlobal, &Menu::GetGrowthGlobal);
	}
      
      StringVec1d populationnames = datapack.GetPopulationNames ();
      StringVec1d::const_iterator pid;
      long id;
      
      for (pid = populationnames.begin (), id = 1;
	   pid != populationnames.end (); pid++, id++)
	{
	  AddMenuLine (localcontent,
		       ToString (id),
		       string ("Pop. ") + ToString (id) + ": " + (*pid),
		       this, &Menu::SetGrowthOWN, &Menu::GetGrowthOWN, id);
	}
    }
  AddMenuLine (localcontent, string ("Y"),
	       string ("Return to Evolutionary Forces Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

string
ForcesMenu::GetGrowthMenu (long)
{
  if (forcesummary.CheckForce(GROW))
    return string ("ON ");
  else
    return string ("OFF");
}

menu_return_type
ForcesMenu::SetGrowthMenu (string &)
{
  menu_return_type done = NOTFOUND;
  SetLocalGrowthContent (forcesummary.CheckForce(GROW));
  content.swap (localcontent);
  while (done != SUCCESS)
    {
      dialog.Title (localtitle);
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  localcontent.swap (content);
  return NOTFOUND;
}


string
ForcesMenu::GetGrowthAllow (long)
{
  if (forcesummary.CheckForce(GROW))
    return string ("Allow");
  else
    return string ("DISAllow");
}

menu_return_type
ForcesMenu::SetGrowthAllow (string &)
{
  if (forcesummary.CheckForce(GROW))
    {
      forcesummary.UnsetForce (GROW);
      localcontent.swap (content);
      SetLocalGrowthContent (false);
      content.swap (localcontent);

    }
  else
    {
      forcesummary.SetForce (GROW, datapack);
      localcontent.swap (content);
      SetLocalGrowthContent (true);
      content.swap (localcontent);
    }
  return NOTFOUND;
}

string
ForcesMenu::GetGrowthGlobal (long)
{
  return " ";
}

menu_return_type
ForcesMenu::SetGrowthGlobal (string & input)
{
  DoubleVec1d growths = forcesummary.GetStartParameters ().GetGrowthRates ();
  unsigned long npop = datapack.GetNPopulations ();
  if (growths.size () < npop)
    growths.resize (npop, 0.0);
  DoubleVec1d::iterator gid;
  string quest = string ("Enter a Growth rate");
  double growth = -1.;
  input = dialog.AskRead (quest);
  strstream iostream;
  iostream << input << ends;
  iostream >> growth;
  for (gid = growths.begin (); gid != growths.end (); gid++)
    *gid = growth;
  forcesummary.GetStartParameters ().SetGrowthRates (growths);
  vector < string > method;
  method.resize (npop, USER);
  forcesummary.SetMethods (GROW, method);
  return NOTFOUND;
}

string
ForcesMenu::GetGrowthOWN (long id)
{
  DoubleVec1d growths = forcesummary.GetStartParameters ().GetGrowthRates ();
  if (growths.size () == 0)
    return string (" ");
  return ToString (growths[id - 1]);
}

menu_return_type
ForcesMenu::SetGrowthOWN (string & input)
{
  long pop = atol (input.c_str ()) - 1;
  DoubleVec1d growths = forcesummary.GetStartParameters ().GetGrowthRates ();
  if (growths.size () == 0)
    growths.resize (datapack.GetNPopulations ());

  string populationname = (datapack.GetPopulationNames ())[pop];
  double defaultgrowth = growths[pop];
  string
    quest =
    string ("Enter a Growth rate for Population ") +
    input +
    string (": ") +
    populationname +
    string ("\n[Default: ") + ToString (defaultgrowth) + string ("]");
  double growth = -1.;
  input = dialog.AskRead (quest);
  if (input.size () == 0)
	growth = defaultgrowth;
  strstream iostream;
  iostream << input << ends;
  iostream >> growth;
  growths[pop] = growth;
  forcesummary.GetStartParameters ().SetGrowthRates (growths);
  forcesummary.SetForce(GROW,datapack);
  vector < string > method = forcesummary.GetMethods (GROW);
  method.resize (growths.size ());
  method[pop] = USER;
  forcesummary.SetMethods (GROW, method);
  return NOTFOUND;
}


// MIGRATION material ------------------------------------------------
void
ForcesMenu::SetLocalMigContent ()
{
  localcontent.clear ();
  localtitle =
    string
    ("Migration: Starting Migration values\nSpecify M=m/mu = 4Nm/Theta\n e.g. M=100 (with Theta=0.01 this result in 4Nm=1)");
  AddMenuLine (localcontent, string (" "),
	       string ("                                "), NULL);
  // We do not allow to change the migration flag: npop>1 ->usemigrate, npop=1 no migration
  //  AddMenuLine(localcontent, string("X"), 
  //          string("Allow/Disallow ALL migrations  "), 
  //          this, &Menu::SetMigrationAllow , 
  //          &Menu::GetMigrationAllow);
  AddMenuLine (localcontent, string ("G"),
	       string ("Starting Migration rates to the same value"),
	       this, &Menu::SetMigrationGlobal, &Menu::GetMigrationGlobal);
  AddMenuLine (localcontent, string ("F"),
	       string ("Start with FST derived migration rates"), this,
	       &Menu::SetMigrationFST, &Menu::GetMigrationFST);

  StringVec1d populationnames = datapack.GetPopulationNames ();
  StringVec1d::const_iterator pid;
  long id;

  for (pid = populationnames.begin (), id = 1;
       pid != populationnames.end (); pid++, id++)
    {
      AddMenuLine (localcontent,
		   ToString (id),
		   string ("Migration INTO Pop. ") + ToString (id) + ": " +
		   (*pid), this, &Menu::SetMigrationOWN,
		   &Menu::GetMigrationOWN, id);
    }
  AddMenuLine (localcontent, string ("L"),
	       string ("Set the Limit of number of migration events"),
	       this, &Menu::SetMigrationLimit, &Menu::GetMigrationLimit);
  AddMenuLine (localcontent, string ("Y"),
	       string ("Return to Evolutionary Forces Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

string
ForcesMenu::GetMigrationMenu (long)
{
  unsigned long npop = datapack.GetNPopulations ();
  // this may change in later versions:  if(usemigrate)
  if (npop > 1)
    return string ("ON ");
  else
    return string ("OFF");
}

menu_return_type
ForcesMenu::SetMigrationMenu (string &)
{
  menu_return_type done = NOTFOUND;
  if (datapack.GetNPopulations () == 1)
    return done;
  SetLocalMigContent ();
  content.swap (localcontent);
  while (done != SUCCESS)
    {
      dialog.Title (localtitle);
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  localcontent.swap (content);
  return NOTFOUND;
}


string
ForcesMenu::GetMigrationAllow (long)
{
  if (forcesummary.CheckForce(MIG))
    return string ("Allow");
  else
    return string ("DISAllow");
}

menu_return_type
ForcesMenu::SetMigrationAllow (string &)
{
  if (forcesummary.CheckForce(MIG))
    {
      forcesummary.UnsetForce (MIG);
    }
  else
    {
      forcesummary.SetForce (MIG, datapack);
    }
  return NOTFOUND;
}

string
ForcesMenu::GetMigrationGlobal (long)
{
  return string (" ");
}

menu_return_type
ForcesMenu::SetMigrationGlobal (string & input)
{
  unsigned long npop = datapack.GetNPopulations ();
  unsigned long npop2 = npop * npop;
  DoubleVec1d migrations = forcesummary.GetStartParameters ().GetMigRates ();
  if (migrations.size () < npop2)
    migrations.resize (npop2, 100.0);
  DoubleVec1d::iterator mit;
  StringVec1d::iterator met;
  string quest = string ("Enter a Migration value");
  double mig = -1.;
  while (mig <= 0)
    {
      input = dialog.AskRead (quest);
      strstream iostream;
      iostream << input << ends;
      iostream >> mig;
    }
  forcesummary.SetForce(MIG,datapack);
  vector < string > method = forcesummary.GetMethods (MIG);
  method.resize (migrations.size ());
  for (mit = migrations.begin (), met = method.begin ();
       mit != migrations.end (); mit++, met++)
    {
      *mit = mig;
      *met = USER;
    }
  forcesummary.GetStartParameters ().SetMigRates (migrations);
  forcesummary.SetMethods (MIG, method);
  return NOTFOUND;
}

string
ForcesMenu::GetMigrationFST (long)
{
  return string (" ");
}

menu_return_type
ForcesMenu::SetMigrationFST (string &)
{
  // MARY
  string message = "Computing FST estimates of migration rates\n";
  dialog.Message(message);
  long npop = datapack.GetNPopulations ();
  vector < string > method;
  method.resize (npop * npop, FST);
  forcesummary.SetMethods (MIG, method);
  DoubleVec1d migrations = (*forcesummary.GetForceByTag(MIG))->QuickCalc(datapack);
  forcesummary.GetStartParameters ().SetMigRates (migrations);
  return NOTFOUND;
}

string
ForcesMenu::GetMigrationOWN (long id)
{
  long npop = datapack.GetNPopulations ();
  DoubleVec1d migrations = forcesummary.GetStartParameters ().GetMigRates ();
  DoubleVec1d::iterator mit;
  string menumessage = "  ";
  long count;
  if (migrations.size () == 0)
    return string (" ");
  for (mit = migrations.begin () + (id - 1) * npop, count = 0;
       (mit != migrations.begin () + id * npop && count < 3); mit++, count++)
    {
      if (count == id - 1)
	menumessage.append (string (" - ") + string (" "));
      else
	menumessage.append (ToString (*mit) + string (" "));
    }
  if (npop > 3)
    menumessage.append (string ("..."));
  return menumessage;
}

menu_return_type
ForcesMenu::SetMigrationOWN (string & input)
{
  long thispop = atol (input.c_str ()) - 1;
  long npop = datapack.GetNPopulations ();
  DoubleVec1d migrations = forcesummary.GetStartParameters ().GetMigRates ();
  if (migrations.size () == 0)
    migrations.resize (npop * npop, 0.0);
  StringVec1d populationnames = datapack.GetPopulationNames ();
  string
    quest =
    string ("Enter the ") +
    ToString (npop - 1) +
    string (" immigration rates into Population") +
    input + string (": ") + populationnames[thispop];
  string
    comment1 = string ("\n[You need to enter M which is m/mu or 4Nm/Theta]");
  string comment2 = string ("\n");
  quest += comment1 + comment2;
  dialog.Title (quest);
  DoubleVec1d::iterator mit;
  forcesummary.SetForce(MIG,datapack);
  vector < string > method = forcesummary.GetMethods (MIG);
  method.resize (migrations.size ());
  StringVec1d::iterator met;
  long pop;
  for (pop = 0, mit = migrations.begin () + thispop * npop,
       met = method.begin () + thispop * npop;
       pop < npop; pop++, mit++, met++)
    {
      if (pop == thispop)
	continue;
      string
	popname =
	string ("FROM ") +
	populationnames[pop] +
	string (" TO ") +
	populationnames[thispop] +
	string ("[") +
	ToString (migrations[thispop * npop + pop]) + string ("]");
      input = dialog.AskRead (popname);
      strstream iostream;
      iostream << input << ends;
      iostream >> *mit;
      *met = USER;
    }
  forcesummary.GetStartParameters ().SetMigRates (migrations);
  forcesummary.SetMethods (MIG, method);

  return NOTFOUND;
}


string
ForcesMenu::GetMigrationLimit (long)
{
  if (forcesummary.CheckForce(MIG))
    {
      long maxevent = forcesummary.GetMaxEvents (MIG);
      return ToString (maxevent);
    }
  else
    return string ("");
}


menu_return_type
ForcesMenu::SetMigrationLimit (string & input)
{
  long npop = datapack.GetNPopulations ();
  string
    quest =
    string ("Enter the maximum number of allowed migration events") +
    string
    ("\n[If this value is too small, results will be underestimated]")
    + string ("\n[Default is 1000 * number of populations = ") +
    ToString (npop * 1000) + string (" ]");
  input = dialog.AskRead (quest);
  // MARY
  long maxevent;
  if (input.size() == 0) maxevent = npop * 1000;
  else maxevent = atol (input.c_str ());
  forcesummary.SetMaxEvents (MIG, maxevent);
  return NOTFOUND;
}



// RECOMBINATION  material ------------------------------------------------
void
ForcesMenu::SetLocalRecContent (bool allowed)
{
  localcontent.clear ();
  localtitle =
    string
    ("Recombination: Starting Recombination values\nSpecify r=C/mu = 4NC/Theta\n e.g. r=0.1 (with Theta=0.01 this results in  4NC=0.001)");
  AddMenuLine (localcontent, string (" "),
	       string ("                                "), NULL);
  AddMenuLine (localcontent, string ("X"),
	       string ("Allow/Disallow Recombination     "), this,
	       &Menu::SetRecombinationAllow, &Menu::GetRecombinationAllow);
  if (allowed)
    {
      //      AddMenuLine (localcontent, string ("W"),
      //		   string ("Use Wakeleys method"),
      //		   this, &Menu::SetRecombinationWAK,
      //		   &Menu::GetRecombinationWAK);
      AddMenuLine (localcontent, string ("1"),
		   string
		   ("Starting Recombination rate                  "),
		   this, &Menu::SetRecombinationOWN,
		   &Menu::GetRecombinationOWN, 1);
      AddMenuLine (localcontent, string ("L"),
		   string
		   ("Set the maximum number of recombination events"),
		   this, &Menu::SetRecombinationLimit,
		   &Menu::GetRecombinationLimit);
    }
  AddMenuLine (localcontent, string ("Y"),
	       string ("Return to Evolutionary Forces Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

string
ForcesMenu::GetRecombinationMenu (long)
{
  if (forcesummary.CheckForce(REC))
    return string ("ON ");
  else
    return string ("OFF");
}

menu_return_type
ForcesMenu::SetRecombinationMenu (string &)
{
  menu_return_type done = NOTFOUND;
  SetLocalRecContent (forcesummary.CheckForce(REC));
  content.swap (localcontent);
  while (done != SUCCESS)
    {
      dialog.Title (localtitle);
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  localcontent.swap (content);
  return NOTFOUND;
}

string
ForcesMenu::GetRecombinationAllow (long)
{
  if (forcesummary.CheckForce(REC))
    return string ("Allow");
  else
    return string ("DISAllow");
}

menu_return_type
ForcesMenu::SetRecombinationAllow (string &)
{
  if (forcesummary.CheckForce(REC))
    {
      forcesummary.UnsetForce (REC);
      localcontent.swap (content);
      SetLocalRecContent (false);
      content.swap (localcontent);

    }
  else
    {
      forcesummary.SetForce (REC, datapack);
      localcontent.swap (content);
      SetLocalRecContent (true);
      content.swap (localcontent);
    }
  return NOTFOUND;
}

string
ForcesMenu::GetRecombinationOWN (long id)
{
  DoubleVec1d
    recombinations = forcesummary.GetStartParameters ().GetRecRates ();
  if (recombinations.size () == 0)
    return string (" ");
  return ToString (recombinations[id - 1]);
}

menu_return_type
ForcesMenu::SetRecombinationOWN (string & input)
{
  DoubleVec1d recrates = forcesummary.GetStartParameters ().GetRecRates ();
  if (recrates.size () == 0)
    recrates.resize (1, 0.0);	//vector must be of size 1
  string
    quest =
    string
    ("Enter the starting Recombination value\n[specify r = rho/mu = 4Nr/Theta\n e.g. r=0.1 (with Theta=0.01 -> 4Nr=0.001");
  dialog.Title (quest);
  input = dialog.AskRead (quest);
  strstream iostream;
  iostream << input << ends;
  iostream >> recrates[0];
  forcesummary.GetStartParameters ().SetRecRates (recrates);
  vector < string > method;
  method.resize (1, USER);
  forcesummary.SetMethods (REC, method);
  return NOTFOUND;
}


string
ForcesMenu::GetRecombinationLimit (long)
{
  if (forcesummary.CheckForce(REC))
    {
      long maxevent = forcesummary.GetMaxEvents (REC);
      return ToString (maxevent);
    }
  else
    return string ("");
}

menu_return_type
ForcesMenu::SetRecombinationLimit (string & input)
{
  string
    quest =
    string ("Enter the maximum number of allowed recombination events")
    +
    string
    ("\n[If this value is too small, results will be underestimated]")
    + string ("\n[Current maximum:") +
    ToString (forcesummary.GetMaxEvents (REC)) + string (" ]");
  long maxevents = 0;
  do
    {
      input = dialog.AskRead (quest);
      // MARY
      if (input.size() == 0) maxevents = forcesummary.GetMaxEvents(REC);
      else maxevents = atol (input.c_str ());
    }
  while (maxevents < 1);
  forcesummary.SetMaxEvents (REC, maxevents);
  return NOTFOUND;
}

void
ForcesMenu::PrepareForceSummary ()
{
  forcesummary.SetForce (COAL, datapack);
  /* EWDEBUG
  forcesummary.SetMaxEvents (COAL, maxcoals);
  */

  if (forcesummary.CheckForce(MIG))
    {
      forcesummary.SetForce (MIG, datapack);
      // when we allow migration to turn off with multiple populations,
      // we will need to adjust the maximum migration events here using
      // forcesummary.SetMaxEvents(MIG,maxmigs)
    }

  if (forcesummary.CheckForce(REC))
    {
      forcesummary.SetForce (REC, datapack);
      /* EWDEBUG
      forcesummary.SetMaxEvents (REC, maxrecs);
      */
    }
  if (forcesummary.CheckForce(GROW))
    {
      forcesummary.SetForce (GROW, datapack);
      /* EWDEBUG
      forcesummary.SetMaxEvents (GROW, maxcoals);
      */
    }
  forcesummary.ReconcilePLForces(datapack);
}

menu_return_type
ForcesMenu::Undo (string &)
{
  forcesummary = registry.GetForceSummary ();
  Defaults ();
  return NOTFOUND;
}

//-----------------------------------------------------------------
StrategyMenu::StrategyMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, ChainParameters & thischainparms, UserParameters & thisuserparms, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack, thisdialog),
rearrangecontent (thisregistry, thisdatafile, thisdatapack,
		  thischainparms, thisuserparms, thisdialog),
searchcontent (thisregistry, thisdatafile, thisdatapack,
	       thischainparms, thisdialog)
{
  Defaults ();

  title = string ("Search and Rearrange Strategy menu\n");
  AddMenuLine (string (" "), string (" "), NULL);
  AddMenuLine (string ("Z"), string ("  Search strategy   "), &searchcontent);
  AddMenuLine (string ("R"), string ("  Rearrange strategy"),
	       &rearrangecontent);
  AddMenuLine (string ("U"),
	       string ("Undo all changes in Search and Rearrange options"), this,
	       &Menu::Undo, &Menu::Undo2);
  AddMenuLine (string ("Y"), string ("Return to Main Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

StrategyMenu::~StrategyMenu ()
{

}

void
StrategyMenu::Defaults ()
{
  rearrangecontent.Defaults ();
}


ChainParameters & StrategyMenu::GetChainParameters ()
{
  searchcontent.SetArrangerFromMenu (rearrangecontent);
  searchcontent.SetTemperaturesFromMenu (rearrangecontent);
  return searchcontent.GetChainParameters ();
}

menu_return_type
StrategyMenu::Undo (string & input)
{
  rearrangecontent.Undo (input);
  searchcontent.Undo (input);
  Defaults ();
  return NOTFOUND;
}


//-----------------------------------------------------------------
RearrangeMenu::RearrangeMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, ChainParameters & thischainparms, UserParameters & thisuserparms, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack, thisdialog),
chainparms (thischainparms),
userparms (thisuserparms),
datapack (thisdatapack)
{
  title = string ("Rearrangement menu\n");
  AddMenuLine (string (" "), string (" "), NULL);
  AddMenuLine(string("1"), string("  Single branch rearrangement"), this, 
	      &Menu::SetDropArranger, &Menu::GetDropArranger);
  if (datapack.CanHapArrange())
    {
  AddMenuLine(string("2"), string("  Haplotype rearrangement   "), this,
  	      &Menu::SetHapArranger, &Menu::GetHapArranger);
  AddMenuLine (string ("3"), string ("  Heated parallel Markov chains"),
	       this, &Menu::SetHeatArranger, &Menu::GetHeatArranger);
  AddMenuLine (string ("4"), string ("  Number of Replicates "), this,
	       &Menu::SetCombineEstimates, &Menu::GetCombineEstimates);
  AddMenuLine (string ("5"), string ("  Random number seed              "),
	       this, &Menu::SetRandomSeed, &Menu::GetRandomSeed);
    }
  else
    {
  AddMenuLine (string ("2"), string ("  Heated parallel Markov chains"),
	       this, &Menu::SetHeatArranger, &Menu::GetHeatArranger);
  AddMenuLine (string ("3"), string ("  Number of Replicates "), this,
	       &Menu::SetCombineEstimates, &Menu::GetCombineEstimates);
  AddMenuLine (string ("4"), string ("  Random number seed              "),
	       this, &Menu::SetRandomSeed, &Menu::GetRandomSeed);
    }
  AddMenuLine (string ("Y"), string ("Return to Strategy Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}


RearrangeMenu::~RearrangeMenu ()
{
}


void
RearrangeMenu::Defaults ()
{
  vector < Arranger * >arrangers = chainparms.GetAllArrangers ();

  //arranger
  if (arrangers.size () < 1)
    {
      Arranger *droparranger = new DropArranger (&(registry.GetRandom ()));
      droparranger->SetTiming (1.0);
      droptiming = 1.0;
      chainparms.AddArranger (droparranger);
      chainparms.SetNReps (1);
      arrangers = chainparms.GetAllArrangers ();
    }
  else
    {
      vector < Arranger * > :: iterator ait;
      for(ait=arrangers.begin(); ait != arrangers.end(); ait++)
	{
	  if((*ait)->IsHapArranger())
	    haptiming = (*ait)->GetTiming();
	  if((*ait)->IsResimArranger())
	    droptiming = (*ait)->GetTiming();
	}
    }
  //Temperature settings
  DoubleVec1d temperatures = chainparms.GetAllTemperatures ();
  if (temperatures.size () < 1)
    {
      long ntemps = 1;
      DoubleVec1d temperatures (ntemps, 1.0);
      chainparms.SetAllTemperatures (temperatures);
    }

  usedroparranger = false;
  usehaparranger = false;

  vector < Arranger * >::const_iterator ait;
  for (ait = arrangers.begin (); ait != arrangers.end (); ait++)
    {
      if (!usedroparranger)
	usedroparranger = (*ait)->IsDropArranger ();
      if (!usehaparranger)
	usehaparranger = (*ait)->IsHapArranger ();
    }
  if (!usedroparranger)
    usedroparranger = true;
}


menu_return_type
RearrangeMenu::SetDropArranger (string &)
{
  // DEBUG version 2  usedroparranger = !usedroparranger;
  usedroparranger = true;
  return NOTFOUND;
}


string
RearrangeMenu::GetDropArranger (long)
{
  if (usedroparranger)
    return string("Frequency: ")+ToString(droptiming);
  else
    return string (" ");
}

menu_return_type
RearrangeMenu::SetHapArranger (string &)
{
  usehaparranger = !usehaparranger;
  if (usehaparranger)
    {
      if (datapack.ShouldPair())
        datapack.SetShouldPair(true);
      usedroparranger = true;
      string questo = string("Give the frequency of calls to the Haplotype arranger\ncompared to the Tree arranger?\n");
      string quest;
      string message = string ("");
      string answer;
      bool done = false;
      while (!done)
	{
	  quest = questo + message;
	  quest += string ("[Current value: ") + ToString (haptiming) + string ("]");
	  answer = dialog.AskRead (quest);
	  if (answer.size () > 0)
	    {
	      haptiming = atof(answer.c_str());
	      done=true;
	      if(haptiming<1.0)
		{
		  droptiming = 1. - haptiming;
		}
	      else
		{
		  haptiming = haptiming / (haptiming + droptiming);
		  droptiming = 1 - haptiming;
		}
	    }
	  else
	    message = "enter a rate bigger than 0. and smaller than 1.\n";
	}
    }
  else
    {
      haptiming = 0.0;
      droptiming = 1.0;
      datapack.SetShouldPair(false);
    }
  // DEBUG Version 2 else
  // DEBUG Version 2  usedroparranger=false;
  return NOTFOUND;
}


string
RearrangeMenu::GetHapArranger (long)
{
  if (usehaparranger)
    return string("Frequency: ")+ToString(haptiming);
  else
    return string (" ");
}

menu_return_type
RearrangeMenu::SetHeatArranger (string &)
{
  DoubleVec1d temperatures = chainparms.GetAllTemperatures ();
  long interval = chainparms.GetTempInterval ();
  string
    questo =
    string
    ("Enter a list of temperatures\n[from coldest to hottest: the coldest chain has\na temperature of 1.0 and the others are higher and unique]\n");
  string quest;
  string message = string ("");
  string answer;
  bool done = false;
  while (!done)
    {
      quest = questo + message;
      quest += string ("[default: ") + ToString (temperatures) + string ("]");
      answer = dialog.AskRead (quest);
      if (answer.size () > 0)
	{
	  FromString (answer, temperatures);
	  sort (temperatures.begin (), temperatures.end ());
	  if (temperatures[0] != 1.0)
	    {
	      message = string
		("\nI have added the coldest temperature for you.\n");
              message += string("Enter return to accept, or type new values\n");
	      temperatures.insert (temperatures.begin (), 1, 1.0);
	      continue;
	    }
	  else
	    break;
	}
      else
	break;
    }
  chainparms.SetAllTemperatures (temperatures);
  quest =
    string
    ("How often will genealogies be swapped between temperatures?\n[Default is 1]");
  answer = dialog.AskRead (quest);
  long defaultinterval = interval;
  FromString (answer, defaultinterval);
  chainparms.SetTempInterval (defaultinterval); 
  quest =
    string
    ("Use adaptive temperatures [YES/NO]\n[the program will adjust the temperatures dependent on swapping rate]\n[Current temperature regime: ") + 
    string(chainparms.GetTempAdapt() ? "ADAPTIVE" : "STATIC")+string("]\n");
  answer = dialog.AskRead (quest);
    bool adapt=true;
  char test = getFirstInterestingChar(answer);
  if(test=='Y' || test=='A')
    adapt=true;
  else
    adapt=false;
  chainparms.SetTempAdapt (adapt);
  return NOTFOUND;
}


string
RearrangeMenu::GetHeatArranger (long)
{
  long temps = chainparms.GetAllTemperatures ().size ();
  if (temps > 1)
    return ToString (temps) + string (" chains");
  else
    return string ("None");
}


string
RearrangeMenu::GetCombineEstimates (long)
{
  return ToString (chainparms.GetNReps ());
}

menu_return_type
RearrangeMenu::SetCombineEstimates (string & input)
{
  long n = -1;
  while (n < 1)
    {
      input = dialog.AskRead (string ("\nHow many replicates:"));
      n = atol (input.c_str ());
    }
  chainparms.SetNReps (n);
  return NOTFOUND;
}

string
RearrangeMenu::GetRandomSeed (long)
{
  return ToString (userparms.GetRandomSeed ());
}

menu_return_type
RearrangeMenu::SetRandomSeed (string & input)
{
  long n = 0;
  string
    quest =
    string ("\nSpecify a random number seed\na = automatic\nor a number > 0");
  string quest2 = quest;
  while (n <= 0)
    {
      input = dialog.AskRead (quest);
      if (getFirstInterestingChar(input) == 'A')
	n = 4 * (time (NULL) / 4) + 1;
      else {
	n = atol (input.c_str ());
        n = 4 * (n / 4) + 1;  // MARY
      }
      quest =
	string ("\nIllegal random number seed number ") + ToString (n) +
	quest2;
    }
  userparms.SetRandomSeed (n);
  return NOTFOUND;
}

menu_return_type
RearrangeMenu::Undo (string &)
{
  chainparms = registry.GetChainParameters ();
  userparms = registry.GetUserParameters ();
  return NOTFOUND;
}


//-----------------------------------------------------------------
SearchMenu::SearchMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, ChainParameters & thischainparms, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack, thisdialog),
  chainparms
  (thischainparms)
{
  title = string ("Search menu\n");
  AddMenuLine (string (" "), string ("Initial Chains"), NULL);
  AddMenuLine (string ("1"), string ("  Number of chains                "),
	       this, &Menu::SetInitialNChain, &Menu::GetInitialNChain);
  AddMenuLine (string ("2"), string ("  Genealogies sampled per chain   "),
	       this, &Menu::SetInitialSamples, &Menu::GetInitialSamples);
  AddMenuLine (string ("3"), string ("  Sampling interval               "),
	       this, &Menu::SetInitialInterval, &Menu::GetInitialInterval);
  AddMenuLine (string ("4"), string ("  Initial genealogies to discard  "),
	       this, &Menu::SetInitialDiscard, &Menu::GetInitialDiscard);
  AddMenuLine (string (" "), string ("Final Chains"), NULL);
  AddMenuLine (string ("5"), string ("  Number of chains                "),
	       this, &Menu::SetFinalNChain, &Menu::GetFinalNChain);
  AddMenuLine (string ("6"), string ("  Genealogies sampled per chain   "),
	       this, &Menu::SetFinalSamples, &Menu::GetFinalSamples);
  AddMenuLine (string ("7"), string ("  Sampling interval               "),
	       this, &Menu::SetFinalInterval, &Menu::GetFinalInterval);
  AddMenuLine (string ("8"), string ("  Final genealogies to discard    "),
	       this, &Menu::SetFinalDiscard, &Menu::GetFinalDiscard);
  AddMenuLine (string ("Y"), string ("Return to Strategy Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

SearchMenu::~SearchMenu ()
{
  //cout << "data menu died" << endl;
}

//menu_return_type SearchMenu::DoTask()
//{
//  menu_return_type done = NOTFOUND;
//  return done;
//}


//menu_return_type SearchMenu::DoTaskWith(string & input)
//{
//  vector <MenuItem> :: const_iterator menuline;
//  menu_return_type done = NOTFOUND;
//  menuline = find_key(content, input);
//  if(menuline==content.end())
//    Show();
//  else
//    {
//      done = (menuline->GetHandler()->*menuline->p)(input);
//    }
//  return done;
//}

void
SearchMenu::SetTemperaturesFromMenu (RearrangeMenu & ra)
{
  DoubleVec1d temperatures = ra.GetChainParameters ().GetAllTemperatures ();
  long interval = ra.GetChainParameters ().GetTempInterval ();
  chainparms.SetAllTemperatures (temperatures);
  chainparms.SetTempInterval (interval);
}

void
SearchMenu::SetArrangerFromMenu (RearrangeMenu & ra)
{
  chainparms.ClearAllArrangers();
  // the drop arranger is always used [version 1]
  //  if (ra.GetUseDropArranger ())
  // {
  Arranger *droparranger = new DropArranger(&(registry.GetRandom ()));
  droparranger->SetTiming(ra.GetDropTiming());
  chainparms.AddArranger(droparranger);
  // }
  if (ra.GetUseHapArranger())
    {
      Arranger *haparranger = new HapArranger (&(registry.GetRandom ()));
      haparranger->SetTiming (ra.GetHapTiming());
      chainparms.AddArranger (haparranger);
    }
}

void
SearchMenu::PrepareChainParameters ()
{
  if (chainparms.GetNSamples (INITIAL) < 1)
    chainparms.SetNSamples (INITIAL, DEF_INIT_NCHAINS);
  if (chainparms.GetNSamples (INITIAL) < 1)
    chainparms.SetNSamples (INITIAL, DEF_INIT_NSAMPLES);
  if (chainparms.GetInterval (INITIAL) < 1)
    chainparms.SetInterval (INITIAL, DEF_INIT_INTERVAL);
  if (chainparms.GetNDiscard (INITIAL) < 1)
    chainparms.SetNDiscard (INITIAL, DEF_INIT_DISCARD);

  if (chainparms.GetNChains (FINAL) < 1)
    chainparms.SetNChains (FINAL, DEF_FINAL_NCHAINS);
  if (chainparms.GetNSamples (FINAL) < 1)
    chainparms.SetNSamples (FINAL, DEF_FINAL_NSAMPLES);
  if (chainparms.GetInterval (FINAL) < 1)
    chainparms.SetInterval (1, DEF_FINAL_INTERVAL);
  if (chainparms.GetNDiscard (FINAL) < 1)
    chainparms.SetNDiscard (FINAL, DEF_FINAL_DISCARD);
  if (chainparms.GetNReps () < 1)
    chainparms.SetNReps (DEF_REPLICATES);
}

menu_return_type
SearchMenu::SetInitialNChain (string & input)
{
  input = dialog.AskRead (string ("\nEnter the number of intitial chains:"));
  long n = atol (input.c_str ());
  chainparms.SetNChains (0, n);
  return NOTFOUND;
}

string
SearchMenu::GetInitialNChain (long)
{
  return ToString (chainparms.GetNChains (0));
}

string
SearchMenu::GetInitialSamples (long)
{
  return ToString (chainparms.GetNSamples (0));
}

menu_return_type
SearchMenu::SetInitialSamples (string & input)
{
  input = dialog.AskRead (string ("\nEnter the number of initial samples:"));
  long n = atol (input.c_str ());
  chainparms.SetNSamples (0, n);
  return NOTFOUND;
}

string
SearchMenu::GetInitialInterval (long)
{
  return ToString (chainparms.GetInterval (0));
}

menu_return_type
SearchMenu::SetInitialInterval (string & input)
{
  input = dialog.AskRead (string ("\nEnter the initial sampling interval:"));
  long n = atol (input.c_str ());
  chainparms.SetInterval (0, n);
  return NOTFOUND;
}

string
SearchMenu::GetInitialDiscard (long)
{
  return ToString (chainparms.GetNDiscard (0));
}

menu_return_type
SearchMenu::SetInitialDiscard (string & input)
{
  input =
    dialog.AskRead (string ("\nEnter the number of initial genealogies to discard:"));
  long n = atol (input.c_str ());
  chainparms.SetNDiscard (0, n);
  return NOTFOUND;
}


menu_return_type
SearchMenu::SetFinalNChain (string & input)
{
  input = dialog.AskRead (string ("\nEnter the number of final chains:"));
  long n = atol (input.c_str ());
  chainparms.SetNChains (1, n);
  return NOTFOUND;
}

string
SearchMenu::GetFinalNChain (long)
{
  return ToString (chainparms.GetNChains (1));
}

string
SearchMenu::GetFinalSamples (long)
{
  return ToString (chainparms.GetNSamples (1));
}

menu_return_type
SearchMenu::SetFinalSamples (string & input)
{
  input = dialog.AskRead (string ("\nEnter the number of final samples:"));
  long n = atol (input.c_str ());
  chainparms.SetNSamples (1, n);
  return NOTFOUND;
}

string
SearchMenu::GetFinalInterval (long)
{
  return ToString (chainparms.GetInterval (1));
}

menu_return_type
SearchMenu::SetFinalInterval (string & input)
{
  input = dialog.AskRead (string ("\nEnter the number of final interval:"));
  long n = atol (input.c_str ());
  chainparms.SetInterval (1, n);
  return NOTFOUND;
}

string
SearchMenu::GetFinalDiscard (long)
{
  return ToString (chainparms.GetNDiscard (1));
}

menu_return_type
SearchMenu::SetFinalDiscard (string & input)
{
  input =
    dialog.AskRead (string ("\nEnter the number of genealogies to discard:"));
  long n = atol (input.c_str ());
  chainparms.SetNDiscard (1, n);
  return NOTFOUND;
}

menu_return_type
SearchMenu::Undo (string &)
{
  chainparms = registry.GetChainParameters ();

  return NOTFOUND;
}


//-----------------------------------------------------------------
ResultMenu::ResultMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, UserParameters & thisuserparms, ForceSummary & thisforcesummary, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack, thisdialog),
userparms (thisuserparms),
forcesummary (thisforcesummary)
{
  // setup and defaults
  {
    ParamVector paramvec(forcesummary);
    currentprofiletype = paramvec.GetAllProfileTypes();
  }
  if(currentprofiletype==none)
    currentprofiletype = DEFAULT_PROFILE;
  title = string ("Input and Output related tasks\n");
  AddMenuLine (string (" "), string (""), NULL);
  AddMenuLine (string ("1"),
	       string ("Progress reports"),
	       this, &Menu::SetProgressMenu, &Menu::GetProgressMenu);
  AddMenuLine (string ("2"),
	       string ("Outfile [filename and options]"),
	       this, &Menu::SetOutfileMenu, &Menu::GetOutfileMenu);
  //  AddMenuLine(string("3"),
  //      string("Parmfile"), 
  //      this, &Menu::SetParamfileMenu, &Menu::GetParamfileMenu);
  //AddMenuLine(string("4"),
  //      string("Intermediate data file"), 
  //      this, &Menu::SetSumfileMenu, &Menu::GetSumfileMenu);
  AddMenuLine (string ("U"),
	       string ("Undo all changes [except data options]"), this,
	       &Menu::Undo, &Menu::Undo2);
  AddMenuLine (string ("Y"), string ("Return to Main Menu"), this,
	       &Menu::Quit, &Menu::Quit2);
}

ResultMenu::~ResultMenu ()
{

}

string
ResultMenu::GetProgressMenu (long)
{
  return progress_to_string (userparms.GetProgress ());
}

/* currently disabled becasue we toggle only between
   normal and no 
menu_return_type ResultMenu::SetProgressMenu(string & input)
{
  long def=2;
  long value = 2;
  string quest2 = string("1     VERBOSE reporting, prints lots of information\n") +
     string("2     NORMAL reporting, prints useful information\n")
    + string("3     NO reporting, prints nothing\n\n")
    + string("[enter a value between 1 and 3]");  
  string quest = quest2;
  do{
    input = dialog.AskRead(quest);
    FromString(input,value);
    if (value < 0) value = def;
    quest = string("You need to enter a value between 1 and 3\n\n") + quest2;
  }  while(value < 1 || value > 3);
  switch(value)
    {
    case 1:  userparms.SetProgress(VERBOSE); break;
    case 3:  userparms.SetProgress(CONCISE); break;
    default: userparms.SetProgress(NORMAL); break;
    }  
  return NOTFOUND;
}
*/
menu_return_type
ResultMenu::SetProgressMenu (string &)
{
  if (userparms.GetProgress () == NONE)
    userparms.SetProgress (NORMAL);
  else
    userparms.SetProgress (NONE);
  return NOTFOUND;
}


menu_return_type
ResultMenu::SetOutfileMenu (string &)
{
  menu_return_type done = NOTFOUND;
  string localname;
  string localtitle = string ("Result related options");
  SetLocalOutfileContent ();
  content.swap (localcontent);
  while (done != SUCCESS)
    {
      dialog.Title (localtitle);
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  localcontent.swap (content);
  return NOTFOUND;
}


string
ResultMenu::GetOutfileMenu (long)
{
  return GetResultsFileMenu (0);
}

void
ResultMenu::SetLocalOutfileContent ()
{
  localcontent.clear ();
  AddMenuLine (localcontent, string (" "),
	       string ("                                "), NULL);
  AddMenuLine (localcontent, string ("1"),
	       string ("Results are written into file"),
	       this, &Menu::SetResultsFileMenu, &Menu::GetResultsFileMenu);
  AddMenuLine (localcontent, string ("2"),
	       string ("Level of reporting (concise/normal)"), this,
	       &Menu::SetOutputLevel, &Menu::GetOutputLevel);
  AddMenuLine (localcontent, string ("3"),
	       string ("Echo the input data"), this,
	       &Menu::SetEchoData, &Menu::GetEchoData);
  //  AddMenuLine (localcontent, string ("4"), string ("Show plots"), this,
  //	       &Menu::SetPlots, &Menu::GetPlots);
  AddMenuLine (localcontent, string ("5"),
	       string ("Calculate profile likelihood tables"), this,
	       &Menu::SetProfile, &Menu::GetProfile);
  AddMenuLine (localcontent, string ("Y"),
	       string ("Return to Output/Input Menu"), this, &Menu::Quit,
	       &Menu::Quit2);

}

void
ResultMenu::SetLocalProfileContent ()
{
  localcontent.clear ();
  AddMenuLine (localcontent, string ("G"),
	       string ("Turn profiling on/off for ALL parameters"),
	       this, &Menu::SetGlobalProfileMenu,
	       &Menu::GetGlobalProfileMenu);
  AddMenuLine (localcontent, string ("P"),
	       string ("Change profile calculation method"), this,
	       &Menu::SetPercentileMenu, &Menu::GetPercentileMenu);

  ParamVector paramvec (forcesummary);

  long id;
  ParamVector :: iterator pit; 
  for (pit = paramvec.begin(), id = 1; pit != paramvec.end(); ++pit)
    {
      if(pit->IsValid())
	{
	  string variablename = pit->GetShortName () + ": " +
	    pit->GetName ();
          // MARY
#if 0
	  AddMenuLine (localcontent, ToString (id),
		       string("(") + ToString (id) + ") " + variablename,
		       this, &Menu::SetGlobalProfileMenu,
		       &Menu::GetGlobalProfileMenu, id);
#endif
	  AddMenuLine (localcontent, ToString (id),
		       variablename,
		       this, &Menu::SetGlobalProfileMenu,
		       &Menu::GetGlobalProfileMenu, id);
          
          // MARY change; we won't update id on invalid parameters
	  // but this produces errors in display the Get..() are using
          // the tag for find ing things. This might need a real change
          // for now I revert to the old things PB
          //++id;
	}
      ++id;
    }
  AddMenuLine (localcontent, string ("Y"), string ("Return to Result Menu"),
	       this, &Menu::Quit, &Menu::Quit2);
}

menu_return_type
ResultMenu::SetGlobalProfileMenu (string & input)
{
  menu_return_type done=NOTFOUND;
  char charcursor = getFirstInterestingChar(input);
  long numcursor = atol (input.c_str ());
  long tag = numcursor - 1;

  string quest1;
  ParamVector paramvec (forcesummary);
  if (charcursor == 'G' || tag < 0)
    {
      switch(paramvec.CheckCalcProfiles())
	{
	case YES: // currently set to yes -> new no
	  paramvec.SetAllProfileTypes(none);
	  break;
	case MIX: // currently set to a mix of yes and no -> new yes
	case NO:  // currently set to no -> new yes
	  paramvec.SetAllProfileTypes(currentprofiletype);
	  break;
	default:
	  assert(false); // never come here
	}
    }
  else
    {
      switch(paramvec[tag].GetProfileType())
	{
	case fix:
	case percentile: // currently set to yes -> new no
	  paramvec[tag].SetProfileType(none);
	  break;
	case none:  // currently set to no -> new yes
	  paramvec[tag].SetProfileType(currentprofiletype);
	  break;
	default:
	  assert(false); // never come here
	}
    }
  return done;
}

string
ResultMenu::GetGlobalProfileMenu (long tag)
{
  ParamVector paramvec (forcesummary);
  if(tag>0)
    return ToString (paramvec[tag-1].GetProfileType ());
  else
    return string("");
}



menu_return_type
ResultMenu::SetPercentileMenu (string &)
{
  string quest = "Change the type of profile calculation\nEnter (P)ercentile, (F)ixed\n[Current setting: " + ToString(currentprofiletype) + string("]\n");
  string answer;
  bool done=false;
  proftype prof = currentprofiletype;
  ParamVector paramvec (forcesummary);
  while(!done)
    {
      answer = dialog.AskRead (quest);
      char test = getFirstInterestingChar(answer);
      switch(test)
	{
	case 'N': //none
	  prof = none;
	  currentprofiletype = DEFAULT_PROFILE;
	  done = true;
	  break;
	case 'P': //percentile 
	  prof = percentile;
	  currentprofiletype = percentile;
	  done = true;
	  break;
	case 'F': //fixed
	  prof = fix;
	  currentprofiletype = fix;
	  done = true;
	  break;
	case '\0': done=true;
	  continue;
	}
      ParamVector :: iterator pit;
      for(pit=paramvec.begin(); pit != paramvec.end(); ++pit)
	{
	  if(pit->IsValid() && pit->GetProfileType()!= none)
	    pit->SetProfileType(prof);
	}
    }
  return NOTFOUND;
}


string
ResultMenu::GetPercentileMenu (long)
{
  ParamVector paramvec(forcesummary);
  return ToString (paramvec.GetAllProfileTypes());
}


void
ResultMenu::SetLocalPlotContent ()
{
  // stub
}


string
ResultMenu::GetOutputLevel (long)
{
  verbosity_type level = userparms.GetVerbosity ();
  return progress_to_string (level);
}

menu_return_type
ResultMenu::SetOutputLevel (string &)
{
  verbosity_type level = userparms.GetVerbosity ();
  switch(level)
    {
    case NORMAL:
      userparms.SetVerbosity (CONCISE);
      break;
    case CONCISE:
    default:
      userparms.SetVerbosity (NORMAL);
    }
  return NOTFOUND;
}

string
ResultMenu::GetEchoData (long)
{
  bool check = userparms.GetEchoData();
  return ToString(check);
}

menu_return_type
ResultMenu::SetEchoData (string &)
{
  if(userparms.GetEchoData())
    userparms.SetEchoData(false);
  else
    userparms.SetEchoData(true);
  return NOTFOUND;
}

string
ResultMenu::GetPlots (long)
{
  bool level = userparms.GetPlotPost ();
  if (level)
    return string ("YES");
  else
    return string ("NO");
}

menu_return_type
ResultMenu::SetPlots (string &)
{
  bool level = userparms.GetPlotPost ();
  level = !level;
  userparms.SetPlotPost (level);
  return NOTFOUND;
}

string
ResultMenu::GetProfile (long tag)
{
  if(tag>0)
    {
      ParamVector paramvec (forcesummary);
      return ToString (paramvec[tag-1].GetProfileType ());
    }
  else
    return string("");
}
  
menu_return_type
ResultMenu::SetProfile (string &)
{
  menu_return_type done = NOTFOUND;
  vector < MenuItem > outputlocal;
  outputlocal = localcontent;
  string outputtitle = localtitle;
  SetLocalProfileContent ();
  localtitle = string ("Profiles likelihood settings");
  content.swap (localcontent);

  while (done != SUCCESS)
    {
      //  cout << "in setprofile()" << endl;
      dialog.Title (localtitle);
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  localcontent.swap (content);
  outputlocal.swap (localcontent);
  localtitle = outputtitle;
  //  cout << "leaving setprofile()" << endl;
  return NOTFOUND;
}



string
ResultMenu::GetResultsFileMenu (long)
{
  string file = userparms.GetResultsFileName ();
  return file;
}

menu_return_type
ResultMenu::SetResultsFileMenu (string & input)
{
  string quest = string ("Enter the location of the parameter file\n");
  string defaultfilename = userparms.GetResultsFileName ();
  if (defaultfilename == "")
    {
      defaultfilename = "outfile";
      userparms.SetResultsFileName (defaultfilename);
    }
  defaultfilename = "[Default: " + defaultfilename + "]\n";
  quest += defaultfilename;
  input = dialog.AskRead (quest);
  if (input.size () != 0)
    userparms.SetResultsFileName (input);
  return NOTFOUND;
}


string
ResultMenu::GetParamfileMenu (long)
{
  string file = userparms.GetParamFileName ();
  return file;
}

menu_return_type
ResultMenu::SetParamfileMenu (string & input)
{
  string quest = string ("Enter the location of the parameter file\n");
  string defaultfilename = userparms.GetParamFileName ();
  if (defaultfilename == "")
    {
      defaultfilename = "parameterfile";
      userparms.SetParamFileName (defaultfilename);
    }
  defaultfilename = "[Default: " + defaultfilename + "]\n";
  quest += defaultfilename;
  input = dialog.AskRead (quest);
  if (input.size () != 0)
    userparms.SetParamFileName (input);
  return NOTFOUND;
}

string
ResultMenu::GetSumfileMenu (long)
{
  string file = userparms.GetTreeSumFileName ();
  return file;
}

menu_return_type
ResultMenu::SetSumfileMenu (string & input)
{
  string quest = string ("Give a name for the tree summary file\n");
  string defaultfilename = userparms.GetTreeSumFileName ();
  if (defaultfilename == "")
    {
      defaultfilename = "treesumfile";
      userparms.SetTreeSumFileName (defaultfilename);
    }
  defaultfilename = "[Default: " + defaultfilename + "]\n";
  quest += defaultfilename;
  input = dialog.AskRead (quest);
  if (input.size () != 0)
    userparms.SetTreeSumFileName (input);
  return NOTFOUND;
}

menu_return_type
ResultMenu::Undo (string &)
{
  userparms = registry.GetUserParameters ();

  return NOTFOUND;
}


  //-----------------------------------------------------------------
PreferenceMenu::PreferenceMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack,
      thisdialog)
{
  //data model menu stub
}

PreferenceMenu::~PreferenceMenu ()
{
  //  cout << "data menu died" << endl;
}

//  menu_return_type PreferenceMenu::DoTask()
//    {
//      menu_return_type done = NOTFOUND;
//      return done;
//    }

//  menu_return_type PreferenceMenu::DoTaskWith(string & input)
//    {
//      menu_return_type done = NOTFOUND;
//      return done;
//    }

  //-----------------------------------------------------------------
  //CurrentMenu::CurrentMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
  //       Dialog &thisdialog) 
  //  : Menu(thisregistry,thisdatafile,thisdatapack,thisdialog)
  //{
  // SetContent();
  //}
CurrentMenu::CurrentMenu (Registry & thisregistry, DataFile & thisdatafile, 
  DataPack & thisdatapack, UserParameters & thisuserparms, 
  ChainParameters & thischainparms, ForceSummary & thisforcesummary, 
  Dialog & thisdialog)
  : Menu (thisregistry, thisdatafile, thisdatapack, thisdialog),
  userparms (thisuserparms), chainparms (thischainparms),
  forcesummary (thisforcesummary)
{
  SetContent ();
}

void
CurrentMenu::SetContent ()
{
  // displays  all settings in Show()
  title = string ("OVERVIEW of current settings [no changes allowed]");
  AddMenuLine (string ("F"), string ("File name overview"), this,
	       &Menu::SetOverFileMenu, &Menu::nodisplay);
  AddMenuLine (string ("D"), string ("Data model overview"), this,
	       &Menu::SetOverDataModelMenu, &Menu::nodisplay);
  AddMenuLine (string ("E"), string ("Evolutionary forces overview"), this,
	       &Menu::SetOverForcesMenu, &Menu::nodisplay);
  AddMenuLine (string ("S"),
	       string ("Search and Rearrange options overview"), this,
	       &Menu::SetOverSearchMenu, &Menu::nodisplay);
  AddMenuLine (string ("R"),
	       string ("Results and Progress options overview"), this,
	       &Menu::SetOverResultMenu, &Menu::nodisplay);
  AddMenuLine (string ("Y"), string ("Leave Overview mode\n"), this,
	       &Menu::Quit, &Menu::Quit2);
}

CurrentMenu::~CurrentMenu ()
{
  //  cout << "data menu died" << endl;
}

menu_return_type
CurrentMenu::SetOverFileMenu (string & input)
{
  string message = string ("Overview of FILE NAMES\n\n");
  message += string("To change these values use the Input and Output menu\n\n");
  //      string parmfile = userparms.GetParamFileName();
  string datafile = userparms.GetDataFileName ();
  string resultfile = userparms.GetResultsFileName ();
  //      string sumfile = userparms.GetTreeSumFileName();

  if (datafile == string (""))
    datafile = string ("YOUR DATA FILE IS NOT SET YET");
  message += string ("Datafile:              ") + datafile;

  if (resultfile == string (""))
    resultfile = string ("YOUR RESULTFILE IS NOT SET");
  message += string ("\nResultfile:            ") + resultfile;

  //      if(parmfile==string(""))
  //        parmfile = string("-");
  //      message += string("\nParameterfile:         ") + parmfile;

  //      if(sumfile==string(""))
  //        sumfile = string("-");
  //      message += string("\nIntermediate Datafile: ") + sumfile;

  message += string ("\n\nHit <Return> to go back\n");
  input = dialog.AskRead (message);
  return NOTFOUND;
}

menu_return_type
CurrentMenu::SetOverDataModelMenu (string & input)
{
  string message = string ("Overview of DATA MODELS\n\n");
  message += string ("To change these values use the Data Options menu\n\n");

  const vector < Region * >regions = datapack.GetAllRegions ();
  vector < Region * >::const_iterator regit;
  for (regit = regions.begin (); regit != regions.end (); regit++)
    {
      DataModel* model = (*regit)->datamodel.get();
      message += "\nParameters of a " + model->GetDataModelName();
      message += " model for the " + (*regit)->GetRegionName();
      message += " region\n";
      StringVec1d rpt = model->CreateDataModelReport();
      StringVec1d::iterator sit;
      for(sit = rpt.begin(); sit < rpt.end(); ++sit)
        message += "   " + (*sit) + "\n";
      message += "\n";
    }
#if 0
  message += MakeJustified (string ("Region"), regionlen) + string ("  ")
    + MakeJustified (string ("Model"), modellen) + string (" ")
    + MakeJustified (string ("t/t "), -ttlen) + string (" ")
    + MakeJustified (string ("Base frequencies"), -baselen) + string (" ");
  const vector < Region * >regions = datapack.GetAllRegions ();
  vector < Region * >::const_iterator regit;
  for (regit = regions.begin (); regit != regions.end (); regit++)
    {
      message += string ("\n")
	+ MakeJustified ((*regit)->GetRegionName (), regionlen)
	+ string ("  ");
      DataModel* model = (*regit)->datamodel.get ();
      message += MakeJustified (model->GetDataModelShortName (), modellen)
	+ string (" ");
      message +=
	Pretty (dynamic_cast < F84Model * >(model)->GetTTratio (),
		ttlen) + string (" ");
      message +=
	ToString (dynamic_cast <
		  F84Model * >(model)->GetBaseFrequencies (), 3);
      long ncategs = model->GetNcategories ();
      if (ncategs > 1)
	{
	  string
	    dummy = string ("                                           ");
	  message += string ("\n");
	  message.append (dummy, 0, -regionlen - modellen);
	  message +=
	    string ("Rates:         ") + ToString (model->GetCatRates (), 2);
	  message += string ("\n");
	  message.append (dummy, 0, -regionlen - modellen);
	  message +=
	    string ("Probabilities: ") +
	    ToString (model->GetCatProbabilities (), 2);
	}
    }
#endif

  message += string ("\n\nHit <Return> to go back\n");
  input = dialog.AskRead (message);
  return NOTFOUND;
}

menu_return_type
CurrentMenu::SetOverForcesMenu (string & input)
{
    const long column1len = -25;
    long npop = datapack.GetNPopulations ();

    /*** Header ***/
    string message = string ("Overview of EVOLUTIONARY FORCES OPTIONS\n\n") 
      + string ("To change these values use the Evolutionary Forces menu\n\n") ;


    /*** List of Forces ***/
    message += MakeJustified (string ("Enabled Forces"), column1len)
      + string ("Maximal number of events\n");
    if (forcesummary.CheckForce (COAL)) 
    { 
        message += MakeJustified (string ("Coalescence"), column1len);
        message += ToString (forcesummary.GetMaxEvents (COAL)) + string ("\n"); 
    } 
    if (forcesummary.CheckForce (MIG)) 
    { 
        message += MakeJustified (string ("Migration"), column1len); 
        message += ToString (forcesummary.GetMaxEvents (MIG)) + string ("\n"); 
    } 
    if (forcesummary.CheckForce (REC)) 
    {
        message += MakeJustified (string ("Recombination"), column1len);
        message += ToString (forcesummary.GetMaxEvents (REC)) + string ("\n"); 
    } 
    message += string ("\n\n"); 


    /*** Starting parameters ***/ 
    message += MakeJustified (string ("Starting parameters"), column1len) + string ("\n\n"); 
    message += MakeJustified (string ("Population"), column1len) + string (" ") + MakeJustified (string ("Theta"), 10); 
    if (npop > 1) 
    { 
        message += string (" ") + string ("M=m/mu"); 
    } 
    message += string ("\n");
    DoubleVec1d thetas = forcesummary.GetStartParameters ().GetThetas ();
    StringVec1d populationnames = datapack.GetPopulationNames ();
    DoubleVec1d migrations = forcesummary.GetStartParameters ().GetMigRates ();
    DoubleVec1d::iterator mit;
    long count;
    long id;
    for (id = 0; id < npop; id++) 
    { 
        message += MakeJustified (populationnames[id], column1len) 
            + string (" ") + MakeJustified (ToString (thetas[id]), 10) 
            + string (" "); 
        if (forcesummary.CheckForce (MIG)) 
        {
            for (mit = migrations.begin () + id * npop, count = 0; 
                    (mit != migrations.begin () + (id + 1) * npop && count < 3); 
                    mit++, count++) 
            { 
                if (count == id) 
                { 
                    message.append (string (" - "));
                } 
                else 
                { 
                    message.append (ToString (*mit));
                } 
                message.append(string(" ")); 
            } 
            if (npop > 3) 
            { 
                message.append (string ("...")); 
            } 
        }
        message.append (string ("\n")); 
    }
    if (npop > 3) 
    { 
        message.append (string ("...")); 
    } 
    message.append (string ("\n")); 
        
    /*** Recombination rate ***/
    if (forcesummary.CheckForce (REC)) 
    { 
        message += string ("\n"); 
        message += MakeJustified (string ("Recombination rate"), column1len) 
            + ToString (forcesummary.GetStartParameters ().GetRecRates ()); 
    } 

    /*** ***/ 
    message += string ("\n\nHit <Return> to go back\n"); 
    input = dialog.AskRead (message); 


    return NOTFOUND;
}


menu_return_type
CurrentMenu::SetOverSearchMenu (string & input)
{
  const long column1len = -25;
  const long column2len = -40;
  const long columnlen = -20;
  string
    message = string ("Overview of SEARCH and REARRANGE OPTIONS\n\n");
  message += string ("To change these values use the Search Strategy menu\n\n");
  message +=
    MakeJustified (string ("  "),
		   column1len) + string ("  ") +
    MakeJustified (string ("Initial Chains"),
		   -columnlen) + string (" ") +
    MakeJustified (string ("Final Chains"), -columnlen) + string ("\n");
  message += MakeJustified (string ("Number of chains"), column1len);
  message +=
    MakeJustified (ToString (chainparms.GetNChains (INITIAL)), -columnlen);
  message +=
    MakeJustified (ToString (chainparms.GetNChains (FINAL)),
		   -columnlen) + string ("\n");

  message += MakeJustified (string ("Sampled Genealogies"), column1len);
  message +=
    MakeJustified (ToString (chainparms.GetNSamples (INITIAL)), -columnlen);
  message +=
    MakeJustified (ToString (chainparms.GetNSamples (FINAL)),
		   -columnlen) + string ("\n");

  message += MakeJustified (string ("Sampling Interval"), column1len);
  message +=
    MakeJustified (ToString (chainparms.GetInterval (INITIAL)), -columnlen);
  message +=
    MakeJustified (ToString (chainparms.GetInterval (FINAL)),
		   -columnlen) + string ("\n");

  message += MakeJustified (string ("Genealogies discarded"), column1len);
  message +=
    MakeJustified (ToString (chainparms.GetNDiscard (INITIAL)), -columnlen);
  message +=
    MakeJustified (ToString (chainparms.GetNDiscard (FINAL)),
		   -columnlen) + string ("\n");
  message += string ("\n\n");
  DoubleVec1d temperatures = chainparms.GetAllTemperatures ();
  long ntemp = temperatures.size ();
  if (ntemp > 1)
    {
      message +=
	MakeJustified (string ("Number of different temperatures"),
		       column2len);
      message += ToString (ntemp) + string ("\n");
      message += MakeJustified (string ("Temperatures"), column2len)
	+ ToString (temperatures, 2) + string ("\n");
      long interval = chainparms.GetTempInterval ();
      message += MakeJustified (string ("Swapping interval"), column2len);
      message += ToString (interval) + string ("\n\n");
    }
  long nreps = chainparms.GetNReps ();
  if (nreps > 1)
    {
      message += MakeJustified (string ("Number of Replicates"), column2len);
      message += ToString (nreps) + string ("\n");
    }
  message += string ("\n\nHit <Return> to go back\n");
  input = dialog.AskRead (message);
  return NOTFOUND;

}

menu_return_type
CurrentMenu::SetOverResultMenu (string & input)
{
  ParamVector paramvec (forcesummary);

  const long column1len = -35;
  string message = string ("Overview of OUTPUT options\n\n");
  message += string ("To change these values use the Input and Output menu\n\n");
  message += MakeJustified (string ("Runtime progress reporting"), column1len);
  string progress = progress_to_string (userparms.GetProgress ());
  message += MakeJustified (progress, column1len) + string ("\n");
  message +=
    MakeJustified (string ("Result options"), column1len) + string ("\n");
  message += MakeJustified (string ("  Output file reporting level "), column1len);
  string verbosity = progress_to_string (userparms.GetVerbosity ());
  message += MakeJustified (verbosity, column1len) + string ("\n");

  message +=
    MakeJustified (string ("  Calculate profile tables"), column1len);
  //      string profiles = forcesummary.CheckCalcProfilesString();
  string profiles = ToString (paramvec.CheckCalcProfiles ());
  message += MakeJustified (profiles, column1len) + string ("\n");

  message += string ("\n\nHit <Return> to go back\n");
  input = dialog.AskRead (message);
  return NOTFOUND;
}

//-----------------------------------------------------------------
RunMenu::RunMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack,
      thisdialog)
{


}

RunMenu::~RunMenu ()
{

}

//  menu_return_type RunMenu::DoTask()
//    {
//      menu_return_type done = NOTFOUND;
//      return done;
//    }

menu_return_type
RunMenu::DoTaskWith (string &)
{
  menu_return_type done = RUN;
  return done;
}

//-----------------------------------------------------------------
QuitMenu::QuitMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack,
      thisdialog)
{

}

QuitMenu::~QuitMenu ()
{

}

menu_return_type QuitMenu::DoTask()
  {
    menu_return_type done = SUCCESS;;
    exit(0);
    return done;
  }

menu_return_type QuitMenu::DoTaskWith(string &)
  {
    menu_return_type done = SUCCESS;
    exit(0);
    return done;
  }



//-----------------------------------------------------------------
MainMenu::MainMenu (Registry & thisregistry, DataFile & thisdatafile, DataPack & thisdatapack, Dialog & thisdialog):Menu (thisregistry, thisdatafile, thisdatapack,
      thisdialog),
  userparms(thisregistry.GetUserParameters()),
  chainparms(thisregistry.GetChainParameters()),
  forcesummary(thisregistry.GetForceSummary()),
  datamodelcontent (thisregistry, thisdatafile, thisdatapack, thisdialog),
  forcescontent (thisregistry, thisdatafile, thisdatapack, forcesummary,
		 thisdialog),
  strategycontent (thisregistry, thisdatafile,
		   thisdatapack, chainparms,
		   userparms, thisdialog),
  resultcontent (thisregistry, thisdatafile, thisdatapack, userparms,
		 forcesummary, thisdialog),
  //    preferencecontent(thisregistry,thisdatafile,thisdatapack,thisdialog),
  currentcontent (thisregistry, thisdatafile, thisdatapack,
		userparms, chainparms, forcesummary, thisdialog),
  runcontent (thisregistry, thisdatafile, thisdatapack, thisdialog),
  quitcontent (thisregistry, thisdatafile, thisdatapack, thisdialog)
{
  title = string ("Main menu");

  forcescontent.Defaults ();

  strategycontent.Defaults ();

  AddMenuLine (string ("D"), string ("Data options"), &datamodelcontent);
  AddMenuLine (string ("E"), string ("Evolutionary forces"), &forcescontent);
  AddMenuLine (string ("S"), string ("Search strategy options"),
	       &strategycontent);
  AddMenuLine (string ("I"), string ("Input and Output related tasks"),
	       &resultcontent);
  //AddMenuLine(string("P"), string("Preferences"), &preferencecontent);
  AddMenuLine (string ("C"), string ("Show current settings"),
	       &currentcontent);
  AddMenuLine (string ("U"),
	       string ("Undo all changes [except data options]"), this,
	       &Menu::Undo, &Menu::Undo2);
  AddMenuLine (string ("G"), string ("Go and Run the program"), &runcontent);
  AddMenuLine (string ("Q"), string ("Quit without running"), &quitcontent);

}

MainMenu::~MainMenu ()
{
  //  cout << "main menu destroyed" << endl;
}

menu_return_type
MainMenu::DoTask ()
{
  menu_return_type done = NOTFOUND;
  return done;
}

  /*menu_return_type MainMenu::DoTaskWith(string & input)
     {
     menu_return_type done = NOTFOUND;
     return done;
     } */

bool
MainMenu::Show ()
{
  menu_return_type done = NOTFOUND;
  while (done != QUIT && done != RUN)
    {
      dialog.Title (title);
      dialog.Show (content);
      done = dialog.Interact (content);
    }
  if (done == RUN)
    {
      //    registry.SetParamContent(paramcontent); 
      // registry.SetDataModel(datamodelcontent); 
      forcescontent.PrepareForceSummary ();
      registry.SetForceSummary (forcescontent.GetForceSummary ());
      registry.SetChainParameters (strategycontent.GetChainParameters ());
      registry.SetUserParameters (userparms);
    }
  return done;
}

menu_return_type
MainMenu::Undo (string & input)
{
  datamodelcontent.Undo (input);
  forcescontent.Undo (input);
  strategycontent.Undo (input);
  strategycontent.Defaults ();
  resultcontent.Undo (input);

  return NOTFOUND;
}


menu_return_type
MainMenu::SetParamFileMenu (string & input)
{
  //  menu_return_type done=NOTFOUND;
  string defaultfilename = userparms.GetParamFileName ();
  if (defaultfilename == "")
    defaultfilename = "[No default set]\n";
  else
    defaultfilename = "[Default: " + defaultfilename + "]\n";

  string
    quest =
    string ("Enter the location of the parameter file\n" + defaultfilename);
  input = dialog.AskRead (quest);
  if (input.size () != 0)
    userparms.SetParamFileName (input);
  bool rc = true;		//paramfile.ReadFile(userparms.GetDataFileName());
  return (rc ? SUCCESS : FAILURE);
}


char getFirstInterestingChar(string & input)
{
    const char * str = input.c_str();
    int length = input.length();
    for(int i=0; i < length; i++)
    {
        if (isalnum(str[i]))
        {
            return toupper(str[i]);
        }
    }
    return '\0';
}
