// menuitem.cpp
// functions to control the menuitem (a single line in a menu)
//
// Peter Beerli
// $Id: menuitem.cpp,v 1.2 2002/06/25 03:17:48 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include <map>
#include "menuitem.h"

class Menu;

MenuItem MenuItem::GetItem() const
{
  return *this;
}

string MenuItem::GetKey() const
{
  return key;
}

string MenuItem::GetText() const
{
  return text;
}

Menu * MenuItem::GetHandler() const
{
  return handler;
}

void MenuItem::SetItem(string thiskey, string thistext, Menu * thishandler,
	       MenuHandlerPtr foo, MenuDisplayPtr goo, long id)
{
  key = thiskey;
  text = thistext;
  handler = thishandler;
  p = foo;
  q = goo;
  keyid = id; 
}

void MenuItem::SetItem(string thiskey, string thistext, Menu *thishandler,
		       MenuHandlerPtr foo,
		       MenuDisplayPtr goo) 
{
  key = thiskey;
  text = thistext;
  handler = thishandler;
  p = foo;
  q = goo;
  keyid = -1;
}

/*void MenuItem::SetItem(string thiskey, string thistext, Menu *thishandler)
{
  key = thiskey;
  text = thistext;
  handler = thishandler;
  keyid = -1;

}

void MenuItem::SetItem(string thistext, Menu *thishandler)
{
  key = "*";
  text = thistext;
  handler = thishandler;
  keyid = -1;
}
*/
 





