// $Id: dialog.h,v 1.4 2002/06/26 19:11:53 lamarc Exp $
#ifndef _DIALOG_H_
#define _DIALOG_H_

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// Dialog is a base class for menu dialogs, with subclasses for
// different menus.
//
// Peter Beerli (March 22 2001)

#include <string>
#include <vector>
#include "menuitem.h"

// obsolete for now
//#define NODIALOG     0
//#define SCROLLDIALOG 1
//#define CURSESDIALOG 2
//#define SHELLDIALOG  3


class Dialog
{
 public:
  Dialog() {};
  virtual ~Dialog(){};
  virtual bool Initialize() = 0;
  virtual bool Cleanup() = 0;
  virtual bool Show( vector <MenuItem> &content) = 0;
  virtual menu_return_type Interact(vector<MenuItem> &content) = 0;
  virtual string AskRead(string) { return string("");};
  virtual bool Title(string) { return false;};
  virtual bool Message(string) {return true;};
  virtual void Prompt() {};
};

class ScrollingDialog : public Dialog
{
 public:
  ScrollingDialog();
  ~ScrollingDialog();
  bool Initialize();
  bool Cleanup();
  bool Title(string title);
  bool Show(vector<MenuItem> &content);
  menu_return_type Interact(vector<MenuItem> &content);
  string AskRead(string text);
  bool Message(string message);
  void Prompt();
};

class ShellDialog : public Dialog
{
 public:
  ShellDialog() {};
  ~ShellDialog(){};
  bool Initialize() {return false; };
  bool Cleanup() {return false;};
  bool Show(vector<MenuItem>&) {return false;};
};

class CursesDialog : public Dialog
{
 public:
  CursesDialog() ;
  ~CursesDialog();
  bool Initialize();
  bool Cleanup();
  bool Title(string title);
  bool Show(vector <MenuItem> &content);
  menu_return_type Interact(vector<MenuItem> &content);
  bool Message(string message);
 protected:
#ifdef CURSES
    Curses screen;
#endif
};

class NoDialog : public Dialog 
{
 public:
  NoDialog() ;
  ~NoDialog();
  bool Initialize();
  bool Cleanup();
  bool Title(string title);
  bool Show(vector <MenuItem> &content);
  menu_return_type Interact(vector<MenuItem> &content);
  bool Message(string message);
};

vector <MenuItem> :: const_iterator  find_key(vector <MenuItem> & content, 
					      string key);


#endif
