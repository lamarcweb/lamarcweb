// $Id: menu.h,v 1.13 2002/06/26 19:11:53 lamarc Exp $
#ifndef _MENU_H_
#define _MENU_H_

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// Menu
//
// the base menu is the NON-Interactive "menu"
// derived menus handle the different windowing systems
//  - Curses
//  - Scrolling ASCII console
//  (-graphical GUI etc)
// Peter Beerli

#include <string>
#include "vectorx.h"
#include "registry.h"
#include "xml.h"
#include <vector>
#include <deque>
#include "menuitem.h"
#include "dialog.h"


enum menu_datatype { GLOBALDATAMODELMENU, PARTIALDATAMODELMENU, REGIONDATAMODELMENU };

class Menu
{
 public:
  Menu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
       Dialog &dialog);
  virtual ~Menu();
  virtual bool Show(); 
  virtual menu_return_type DoTask() {return NOTFOUND;};
  virtual menu_return_type DoTaskWith(string & );
  virtual menu_return_type  Acknowledge(string & );
  virtual menu_return_type OnError(string input);
  //virtual void SetChainParameters(ChainParameters & thischainparms);
  //  virtual void SetUserParameters(UserParameters & thisuserparms);
  //virtual void SetForceSummary(ForceSummary & thisforcesummary);
  virtual menu_return_type nohandle(string & ){return NOTFOUND;};
  virtual string nodisplay(long){return string("") ;};

  // SEARCHMODEL ---------------------------------------
  virtual string GetInitialNChain(long){return string("0") ;};
  virtual menu_return_type SetInitialNChain(string &){return FAILURE;};

  virtual string GetInitialSamples(long){return string("0") ;};
  virtual menu_return_type SetInitialSamples(string &){return FAILURE;};

  virtual string GetInitialInterval(long){return string("0") ;};
  virtual menu_return_type SetInitialInterval(string &){return FAILURE;};

  virtual string GetInitialDiscard(long){return string("0") ;};
  virtual menu_return_type SetInitialDiscard(string &){return FAILURE;};

  virtual menu_return_type SetFinalNChain(string &){return FAILURE;};
  virtual string GetFinalNChain(long){return string("0");};

  virtual string GetFinalSamples(long){return string("0") ;};
  virtual menu_return_type SetFinalSamples(string &){return FAILURE;};

  virtual string GetFinalInterval(long){return string("0") ;};
  virtual menu_return_type SetFinalInterval(string &){return FAILURE;};

  virtual string GetFinalDiscard(long){return string("0") ;};
  virtual menu_return_type SetFinalDiscard(string &){return FAILURE;};

  virtual string GetCombineEstimates(long){return string("No, do not combine") ;};
  virtual menu_return_type SetCombineEstimates(string &){return FAILURE;};

  virtual string GetRandomSeed(long){return string("Automatic") ;};
  virtual menu_return_type SetRandomSeed(string &){return FAILURE;};

  virtual string Undo2(long) { return "";}; 
  virtual menu_return_type Undo(string &) { return FAILURE;}; 

  virtual string Quit2(long) { return "";}; 
  virtual menu_return_type Quit(string &) { return SUCCESS;}; 

  // PARAM FILEMENU ---------------------------------
  virtual menu_return_type SetParamFileMenu(string &) {return SUCCESS;};

  // DATAMODEL ---------------------------------------
  virtual string GetDataModelMenu(long){ return "";};
  virtual menu_return_type SetDataModelMenu(string &){ return SUCCESS;};

  virtual string GetRegionDataModel(long){ return "";};
  virtual menu_return_type SetRegionDataModel(string &){ return SUCCESS;};

  virtual string GetTTRatio(long){ return "";};
  virtual menu_return_type SetTTRatio(string &){ return SUCCESS;};

  virtual string GetBaseFrequencies(long){ return "";};
  virtual menu_return_type SetBaseFrequencies(string &){ return SUCCESS;};

  virtual string GetRateCategories(long){ return "";};
  virtual menu_return_type SetRateCategories(string &){ return SUCCESS;};

  virtual string GetNormalization(long){ return "";};
  virtual menu_return_type SetNormalization(string &){ return SUCCESS;};


  // FORCES Menu-------------------------------------------
  // coalescence  
  virtual string GetCoalescenceMenu(long){return string("0") ;};
  virtual menu_return_type SetCoalescenceMenu(string &){return FAILURE;};

  virtual string GetThetaGlobal(long)  {return string("0") ;};
  virtual menu_return_type SetThetaGlobal(string &){return FAILURE;};

  virtual string GetThetaFST(long)  {return string("0") ;};
  virtual menu_return_type SetThetaFST(string &){return FAILURE;};

  virtual string GetThetaWatterson(long)  {return string("0") ;};
  virtual menu_return_type SetThetaWatterson(string &){return FAILURE;};

  virtual string GetThetaOWN(long)  {return string("0") ;};
  virtual menu_return_type SetThetaOWN(string &){return FAILURE;};

  // growth  
  virtual string GetGrowthMenu(long){return string("0") ;};
  virtual menu_return_type SetGrowthMenu(string &){return FAILURE;};

  virtual string GetGrowthAllow(long){return string("0") ;};
  virtual menu_return_type SetGrowthAllow(string &){return FAILURE;};

  virtual string GetGrowthGlobal(long)  {return string("0") ;};
  virtual menu_return_type SetGrowthGlobal(string &){return FAILURE;};

  virtual string GetGrowthOWN(long)  {return string("0") ;};
  virtual menu_return_type SetGrowthOWN(string &){return FAILURE;};

  // migration
  virtual string GetMigrationMenu(long){return string("0") ;};
  virtual menu_return_type SetMigrationMenu(string &){return FAILURE;};

  virtual string GetMigrationAllow(long){return string("0") ;};
  virtual menu_return_type SetMigrationAllow(string &){return FAILURE;};
  
  virtual string GetMigrationGlobal(long){return string("0") ;};
  virtual menu_return_type SetMigrationGlobal(string &){return FAILURE;};

  virtual string GetMigrationFST(long){return string("0") ;};
  virtual menu_return_type SetMigrationFST(string &){return FAILURE;};
  
  virtual string GetMigrationOWN(long){return string("0") ;};
  virtual menu_return_type SetMigrationOWN(string &){return FAILURE;};
  
  virtual string GetMigrationLimit(long){return string("0") ;};
  virtual menu_return_type SetMigrationLimit(string &){return FAILURE;};


  //recombination
  virtual string GetRecombinationMenu(long){return string("0") ;};
  virtual menu_return_type SetRecombinationMenu(string &){return FAILURE;};

  virtual string GetRecombinationAllow(long){return string("0") ;};
  virtual menu_return_type SetRecombinationAllow(string &){return FAILURE;};
  
  virtual string GetRecombinationOWN(long){return string("0") ;};
  virtual menu_return_type SetRecombinationOWN(string &){return FAILURE;};

  virtual string GetRecombinationLimit(long){return string("0") ;};
  virtual menu_return_type SetRecombinationLimit(string &){return FAILURE;};

  //----------------------------------------------------
  // Rearranger menu
  virtual menu_return_type SetDropArranger(string &){return FAILURE;};
  virtual string GetDropArranger(long){return string("0") ;};
  virtual menu_return_type SetHapArranger(string &){return FAILURE;};
  virtual string GetHapArranger(long){return string("0") ;};
  virtual menu_return_type SetHeatArranger(string &){return FAILURE;};
  virtual string GetHeatArranger(long){return string("0") ;};

  //----------------------------------------------------
  // Output/ menu
  virtual menu_return_type SetProgressMenu(string &){return FAILURE;};
  virtual string GetProgressMenu(long){return string("0") ;};
  virtual menu_return_type SetOutfileMenu(string &){return FAILURE;};
  virtual string GetOutfileMenu(long){return string("0") ;};
  virtual menu_return_type SetResultsFileMenu(string &){return FAILURE;};
  virtual string GetResultsFileMenu(long){return string("0") ;};
  virtual menu_return_type SetParamfileMenu(string &){return FAILURE;};
  virtual string GetParamfileMenu(long){return string("0") ;};
  virtual menu_return_type SetSumfileMenu(string &){return FAILURE;};
  virtual string GetSumfileMenu(long){return string("0") ;};

  virtual menu_return_type SetOutputLevel(string &){return FAILURE;};
  virtual string GetOutputLevel(long){return string("0") ;};
  virtual menu_return_type SetPlots(string &){return FAILURE;};
  virtual string GetPlots(long){return string("0") ;};
  virtual menu_return_type SetProfile(string &){return FAILURE;};
  virtual string GetProfile(long){return string("0") ;};

  virtual menu_return_type SetGlobalProfileMenu(string &){return FAILURE;};
  virtual string GetGlobalProfileMenu(long){return string("0") ;};

  virtual menu_return_type SetPercentileMenu(string &){return FAILURE;};
  virtual string GetPercentileMenu(long){return string("0") ;};

  virtual string GetEchoData (long){ return string("0");};
  virtual menu_return_type SetEchoData (string &){return FAILURE;};

  // Current menu
  virtual menu_return_type SetOverFileMenu(string &){return FAILURE;};
  virtual   menu_return_type SetOverDataModelMenu(string &){return FAILURE;};
  virtual   menu_return_type SetOverSearchMenu(string &){return FAILURE;};
  virtual menu_return_type SetOverResultMenu(string &){return FAILURE;};
  virtual menu_return_type SetOverForcesMenu(string &){return FAILURE;};
 protected:
  // display management
  string name;
  vector <MenuItem> content;
  string title;

  bool AddMenuLine(string key, string text, Menu  * handler);
  bool AddMenuLine(vector <MenuItem> & localcontent, string key, string text, Menu * handler);
  bool AddMenuLine(string key, string text, Menu * handler, 
		   MenuHandlerPtr foo, MenuDisplayPtr goo);
  bool AddMenuLine(vector <MenuItem> &, string key, string text, Menu * handler, 
		   MenuHandlerPtr foo, MenuDisplayPtr goo);
  bool AddMenuLine (string key, string text, Menu * handler,
		    MenuHandlerPtr foo, MenuDisplayPtr goo, long id);
  bool AddMenuLine(vector <MenuItem> &, string key, string text, Menu * handler, 
		   MenuHandlerPtr foo, MenuDisplayPtr goo, long id);

  string makeStringWithDefaultInputFileName(long unused);

  // data management
  Registry & registry; // references the registry for Undo() command;
  DataFile & datafile; // 
  DataPack & datapack; //
  Dialog & dialog;
  //ChainParameters chainparms;
  //UserParameters userparms;
  //ForceSummary forcesummary;  
};


class DataMenu : public Menu
{
 public:
  DataMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
	   Dialog &dialog);
  ~DataMenu();
  bool Show();
  menu_return_type DoTask();
  menu_return_type DoTaskWith(string & input);
  menu_return_type Acknowledge(string & input);
 protected:
  UserParameters userparms;
 private:
  const long MAXTRIES;
};

/*class ParamMenu : public Menu
{
 public:
  ParamMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
	    Dialog &dialog);
  ~ParamMenu();
  //  bool Show();
  menu_return_type OnError();
  menu_return_type DoTask();
  menu_return_type DoTaskWith(string & input);
  menu_return_type Acknowledge(string & input);
 protected:

};
*/


class DataModelMenu : public Menu
{
 public:
  DataModelMenu(Registry &thisregistry, DataFile &thisdatafile, 
		DataPack &thisdatapack, 
		Dialog &dialog);
  ~DataModelMenu();
  //  bool Show();
  bool OnError();
  menu_return_type DoTask();
  menu_return_type DoTaskWith(string & input);

  menu_return_type SetDataModelMenu(string & input);
  string GetDataModelMenu(long);

 protected:
  deque <bool> touchedparameters;
  vector <MenuItem> localcontent;
  menu_datatype work;
  long cursor;

  string SetLocalWork(string &input, string & name);
  void SetLocalContent();
  long GetFirstNotTouched();
  void ResetTouchedParameters();
  string GetRegionDataModel(long);
  menu_return_type SetRegionDataModel(string & input);


  string GetTTRatio(long);
  menu_return_type SetTTRatio(string & input);
  
  string GetBaseFrequencies(long);
  menu_return_type SetBaseFrequencies(string & input);

  string GetRateCategories(long);
  menu_return_type SetRateCategories(string & input);
 
  string GetNormalization(long);
  menu_return_type SetNormalization(string & input);
 
  vector <double> CheckBases(string &input);
};



class ForcesMenu : public Menu
{
 public:
  ForcesMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
	    ForceSummary & thisforcesummary, Dialog &dialog);
  ~ForcesMenu();
  //  bool Show();
  bool OnError();
  //  menu_return_type DoTask();
  void PrepareForceSummary();
  ForceSummary & GetForceSummary() { return forcesummary;};
  void Defaults();

  menu_return_type Undo(string & input);  

 protected:
  ForceSummary & forcesummary;
  DataPack& datapack;  // needed for force enabling

  vector <MenuItem> localcontent;
  string localtitle;

  // coalescence
  string GetCoalescenceMenu(long);
  menu_return_type SetCoalescenceMenu(string & input);
  
  void SetLocalThetaContent();

  string GetThetaGlobal(long);
  menu_return_type SetThetaGlobal(string & input);

  string GetThetaFST(long);
  menu_return_type SetThetaFST(string & input);

  string GetThetaWatterson(long);
  menu_return_type SetThetaWatterson(string & input);

  string GetThetaOWN(long);
  menu_return_type SetThetaOWN(string & input);

  // growth
  string GetGrowthMenu(long);
  menu_return_type SetGrowthMenu(string & input);
  
  void SetLocalGrowthContent(bool);

  string GetGrowthAllow(long);
  menu_return_type SetGrowthAllow(string &);

  string GetGrowthGlobal(long);
  menu_return_type SetGrowthGlobal(string & input);

  string GetGrowthOWN(long);
  menu_return_type SetGrowthOWN(string & input);

  // migration
  string GetMigrationMenu(long);
  menu_return_type SetMigrationMenu(string & input);

  void SetLocalMigContent();
  
  string GetMigrationAllow(long);
  menu_return_type SetMigrationAllow(string & input);
  
  string GetMigrationGlobal(long);
  menu_return_type SetMigrationGlobal(string & input);

  string GetMigrationFST(long);
  menu_return_type SetMigrationFST(string & input);
  
  string GetMigrationOWN(long);
  menu_return_type SetMigrationOWN(string & input);
  
  string GetMigrationLimit(long);
  menu_return_type SetMigrationLimit(string & input);

  // recombination
  string GetRecombinationMenu(long);
  menu_return_type SetRecombinationMenu(string & input);

  void SetLocalRecContent(bool allowed);

  string GetRecombinationAllow(long);
  menu_return_type SetRecombinationAllow(string & input);
  
  string GetRecombinationOWN(long);
  menu_return_type SetRecombinationOWN(string & input);

  string GetRecombinationLimit(long);
  menu_return_type SetRecombinationLimit(string & input);
};



class RearrangeMenu : public Menu
{
 public:
  RearrangeMenu(Registry &thisregistry, DataFile &thisdatafile, 
		DataPack &thisdatapack, 
		ChainParameters & thischainparms, 
		UserParameters & thisuserparms, Dialog &dialog);
  ~RearrangeMenu();
  bool OnError();
  void Defaults();
  bool GetUseDropArranger() { return usedroparranger ; } ;
  string GetDropArranger(long);
  bool GetUseHapArranger() { return usehaparranger ; } ;
  double GetDropTiming() { return droptiming;};
  double GetHapTiming() { return haptiming;};
  ChainParameters & GetChainParameters(){ return chainparms; } ;
  menu_return_type Undo(string & input);
 protected:
  menu_return_type SetDropArranger(string & input);
  menu_return_type SetHapArranger(string & input);
  string GetHapArranger(long);

  menu_return_type SetHeatArranger(string & input);
  string GetHeatArranger(long);

  string GetCombineEstimates(long);
  menu_return_type SetCombineEstimates(string & input);
  
  string GetRandomSeed(long);
  menu_return_type SetRandomSeed(string & input);
  
  ChainParameters & chainparms;
  UserParameters & userparms;
  DataPack & datapack;
  bool usedroparranger;
  bool usehaparranger;
  double haptiming;
  double droptiming;
};

class SearchMenu : public Menu
{
 public:
  SearchMenu(Registry &thisregistry, DataFile &thisdatafile, 
	     DataPack &thisdatapack, 
	     ChainParameters & thischainparms, Dialog &dialog);
  ~SearchMenu();
  bool OnError();
  //  menu_return_type DoTask();
  //  menu_return_type DoTaskWith(string & input);
  void SetArrangerFromMenu(RearrangeMenu & ra);
  void SetTemperaturesFromMenu(RearrangeMenu & ra);
  ChainParameters & GetChainParameters(){ return chainparms; } ;

  string GetInitialNChain(long);
  menu_return_type SetInitialNChain(string & input);

  string GetInitialSamples(long);
  menu_return_type SetInitialSamples(string & input);

  string GetInitialInterval(long);
  menu_return_type SetInitialInterval(string & input);
  
  string GetInitialDiscard(long);
  menu_return_type SetInitialDiscard(string & input);
  
  string GetFinalNChain(long);
  menu_return_type SetFinalNChain(string & input);
  
  string GetFinalSamples(long);
  menu_return_type SetFinalSamples(string & input);

   string GetFinalInterval(long);
   menu_return_type SetFinalInterval(string & input);

   string GetFinalDiscard(long);
   menu_return_type SetFinalDiscard(string & input);

   void PrepareChainParameters();
   menu_return_type Undo(string & input);
 protected:
   ChainParameters & chainparms;

};

class StrategyMenu : public Menu
{
 public:
  RearrangeMenu rearrangecontent;
  SearchMenu    searchcontent;
  StrategyMenu(Registry &thisregistry, DataFile &thisdatafile, 
	       DataPack &thisdatapack, 
	       ChainParameters & thischainparms, 
	       UserParameters & thisuserparms, 
	       Dialog &dialog);
  ~StrategyMenu();
  ChainParameters & GetChainParameters() ;
  void Defaults();
  menu_return_type Undo(string & input);
};


class ResultMenu : public Menu
{
 public:
  ResultMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
	    UserParameters & thisuserparms, ForceSummary & thisforcesummary, Dialog &dialog);
  ~ResultMenu();
  bool OnError();
  menu_return_type Undo(string & input);
 protected:
  void SetLocalOutfileContent();
  void SetLocalProfileContent();
  void SetLocalPlotContent();
  menu_return_type SetProgressMenu(string & input);
  string GetProgressMenu(long);
  menu_return_type SetOutfileMenu(string & input);
  string GetOutfileMenu(long);
  menu_return_type SetResultsFileMenu(string & input);
  string GetResultsFileMenu(long);
  menu_return_type SetParamfileMenu(string & input);
  string GetParamfileMenu(long);
  menu_return_type SetSumfileMenu(string & input);
  string GetSumfileMenu(long);
  
  menu_return_type SetOutputLevel(string & input);
  string GetOutputLevel(long);

  menu_return_type SetPlots(string & input);
  string GetPlots(long);

  menu_return_type SetProfile(string & input);
  string GetProfile(long);

  menu_return_type SetGlobalProfileMenu(string & input);
  string GetGlobalProfileMenu(long tag);

  menu_return_type SetPercentileMenu(string & input);
  string GetPercentileMenu(long tag);

  string GetEchoData (long);
  menu_return_type SetEchoData (string & input);

  UserParameters & userparms;
  ForceSummary & forcesummary;  
  vector <MenuItem> localcontent;
  string localtitle;
  proftype currentprofiletype;
};

class PreferenceMenu : public Menu
{
 public:
  PreferenceMenu(Registry &thisregistry, DataFile &thisdatafile, 
		 DataPack &thisdatapack, 
		  Dialog &dialog);
  ~PreferenceMenu();
  bool OnError();
  //  menu_return_type DoTask();
  //  menu_return_type DoTaskWith(string & input);

 protected:

};

class CurrentMenu : public Menu
{
 public:
  //  CurrentMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
  //    Dialog &dialog);
  CurrentMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
	      UserParameters &thisuserparms, ChainParameters &thischainparms,
	      ForceSummary & thisforcesummary, Dialog &dialog);
  ~CurrentMenu();
  bool OnError();
  menu_return_type SetOverFileMenu(string &input);
  menu_return_type SetOverDataModelMenu(string &input);
  menu_return_type SetOverSearchMenu(string &input);
  menu_return_type SetOverResultMenu(string &input);
  menu_return_type SetOverForcesMenu(string &input);
  void SetContent();
 protected:
  UserParameters & userparms;
  ChainParameters & chainparms;
  ForceSummary & forcesummary;  
};

class RunMenu : public Menu
{
 public:
  RunMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
	    Dialog &dialog);
  ~RunMenu();
  //  bool Show();
  bool OnError();
  //  menu_return_type DoTask();
  menu_return_type DoTaskWith(string & input);

};

class QuitMenu : public Menu
{
 public:
  QuitMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
	    Dialog &dialog);
  ~QuitMenu();
  //  bool Show();
  bool OnError();
  menu_return_type DoTask();
  menu_return_type DoTaskWith(string & input);

 protected:

};

class MainMenu : public Menu
{
 public:
  MainMenu(Registry &thisregistry, DataFile &thisdatafile, DataPack &thisdatapack, 
	    Dialog &dialog);
  ~MainMenu();
  menu_return_type DoTask();
  bool Show();
 protected:
  UserParameters userparms;
  ChainParameters chainparms;
  ForceSummary forcesummary;

  //  ParamMenu paramcontent;
  DataModelMenu datamodelcontent;
  ForcesMenu forcescontent;
  StrategyMenu strategycontent;
  ResultMenu resultcontent;
  // PreferenceMenu preferencecontent;
  CurrentMenu currentcontent;
  RunMenu runcontent;
  QuitMenu quitcontent;

  menu_return_type SetParamFileMenu(string & input);
  menu_return_type Undo(string & input);
};

char getFirstInterestingChar(string & input);
string progress_to_string (verbosity_type progress);
#endif











