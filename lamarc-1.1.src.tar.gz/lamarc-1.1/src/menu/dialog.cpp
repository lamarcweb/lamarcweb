// base class for all dialogs
// + derived classes (these may need to split away from this file
//
// Peter Beerli (March 22 2001)
// $Id: dialog.cpp,v 1.8 2002/06/26 19:11:52 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <vector>
#include <iostream>
#include <algorithm>
#include "stringx.h"
#include "dialog.h"
#include "menu.h"
#include "menuitem.h"


const size_t SCREENWIDTH = 75;
const long   MENUPARAMETERWIDTH=24;
const long   MENUTEXTWIDTH=47;
const long   MENUKEYWIDTH=3;

vector <MenuItem> :: const_iterator  find_key(vector <MenuItem> & content, 
					      string key)
{
  vector <MenuItem> ::const_iterator i;

  if (key.size()==0)
    return content.end();

  UpperCase(key);
  
  for(i=content.begin(); i!=content.end(); i++)
    {
      if(i->GetKey() == key)
	{
	  return i;
	}
    }
  return content.end();
}


// Scrolling dialog ----------------------------------
ScrollingDialog::ScrollingDialog() {};
ScrollingDialog::~ScrollingDialog(){};
bool ScrollingDialog::Initialize() { return true; };
bool ScrollingDialog::Cleanup() { return true; };

bool ScrollingDialog::Title(string title)
{
  string line(SCREENWIDTH,'-');

  cout << "\n" << line << "\n" << title << "\n\n" << endl;
  return true;
}
 
bool ScrollingDialog::Show(vector <MenuItem> &content)
{
  string temptext;
  vector <MenuItem> :: iterator menuline;
  for(menuline=content.begin(); menuline != content.end(); menuline++)
    { 
        string menuKey = menuline->GetKey();
        string storedMenuText = menuline->GetText(); 
        if(menuline->GetHandler()!=NULL) 
        { 
            string generatedMenuText = (menuline->GetHandler()->*menuline->q)(menuline->GetKeyid()); 
            if(menuKey!="*") 
            { 
                cout << MakeJustified(menuKey, MENUKEYWIDTH)  
                    << "  " 
                    << MakeJustified(storedMenuText, -MENUTEXTWIDTH) 
                    << MakeJustified(generatedMenuText, MENUPARAMETERWIDTH) 
                    << endl; 
            } 
            else 
            { 
                cout << storedMenuText << generatedMenuText << endl; 
            } 
        } 
        else 
        { 
            if(menuKey!="*") 
            { 
                cout << menuKey << "  " << storedMenuText << endl; 
            } 
            else 
            { 
                cout << storedMenuText << endl; 
            }
        }
    } 
  return true;
}

void ScrollingDialog::Prompt()
{
  cout << "\n>>> ";
  cout.flush();
}

string ScrollingDialog::AskRead(string text)
{
  char *line = new char[1000];
  Title(text);
  Prompt();
  cin.getline(line,1000);
  string input(line);
  delete line;
  return input;
}

menu_return_type ScrollingDialog::Interact(vector<MenuItem> &content)
{
  char *line = new char[1000];
  menu_return_type rc = NOTFOUND;
  Prompt();
  cin.getline(line,1000);
  string input(line);
  vector <MenuItem> :: const_iterator menuline;
  menuline = content.begin();
  if(content.size()==1)
    {
      rc = menuline->GetHandler()->DoTaskWith(input);
    }
  else
    {
      menuline=find_key(content, input);
      if(menuline != content.end())
	rc = menuline->GetHandler()->DoTaskWith(input);
      else
	rc = NOTFOUND;
    }
  switch(rc)
    {
    case SUCCESS:
      rc = menuline->GetHandler()->Acknowledge(input); break;
    case FAILURE:
      rc = menuline->GetHandler()->OnError(input); break;
    case NOTFOUND: //does nothing
      break;
    case QUIT:
      exit(0);
    case RUN:
      break;
    }
  delete [] line;
  return rc;
}

bool ScrollingDialog::Message(string message)
{
  cout << "\n" << message << "\n\n" << endl;
  return true;
}

// Shell dialog ----------------------------------

// Curses dialog ----------------------------------
CursesDialog::CursesDialog() {};
CursesDialog::~CursesDialog(){};
bool CursesDialog::Initialize() 
{
  //SetDimensions(56, 20);  
  bool done = false;
  
  return done;
};
bool CursesDialog::Cleanup() { return true; };

bool CursesDialog::Title(string)
{
  //SetTitle(title, 3);
  return true;
}
 
bool CursesDialog::Show(vector <MenuItem> &content)
{
  vector <MenuItem> :: iterator menuline;
  for(menuline=content.begin(); menuline != content.end(); menuline++)
    {
      if(menuline->GetKey()!="*")
	cout << "      " << menuline->GetKey() << "     " << menuline->GetText() << endl;
      else
	cout << "      " << menuline->GetText() << endl;
    }
  return true;
}


menu_return_type CursesDialog::Interact(vector<MenuItem> &content)
{
  string input;
  menu_return_type rc = NOTFOUND;
  cin >> input;
  vector <MenuItem> :: const_iterator menuline;
  menuline = content.begin();
  if(content.size()==1)
    {
      rc = menuline->GetHandler()->DoTaskWith(input);
    }
  else
    {
      menuline=find_key(content, input);
      if(menuline != content.end())
	rc = menuline->GetHandler()->DoTask();
      else
	rc = NOTFOUND;
    }
  switch(rc)
    {
    case SUCCESS:
      rc = menuline->GetHandler()->Acknowledge(input); break;
    case FAILURE:
      rc = menuline->GetHandler()->OnError(input); break;
    case NOTFOUND: //does nothing
      break;
    case RUN:
      break;
    case QUIT:
      break; //exit(0);
    }
  return rc;
}

bool CursesDialog::Message(string message)
{
  cout << "\n" << message << "\n\n" << endl;
  return true;
}


// No dialog ----------------------------------
NoDialog::NoDialog(){};
NoDialog::~NoDialog(){};
bool NoDialog::Initialize(){return true;};
bool NoDialog::Cleanup(){return true;};

bool NoDialog::Title(string)
{
  return true;
}
 
bool NoDialog::Show(vector <MenuItem> &)
{
  return true;
}

menu_return_type NoDialog::Interact(vector<MenuItem> &)
{
  return RUN;
}

bool NoDialog::Message(string)
{
  return true;
}







