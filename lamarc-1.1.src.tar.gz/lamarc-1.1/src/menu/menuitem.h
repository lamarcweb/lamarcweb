#ifndef _MENUITEM_H_
#define _MENUITEM_H_

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// Menuitem.h
// is line in the menu and consists of a (key, text, handlerobject)
//
// Peter Beerli
// $Id: menuitem.h,v 1.2 2002/06/25 03:17:49 mkkuhner Exp $
#include <string>
#include <map>

using namespace std;

enum menu_return_type { SUCCESS, FAILURE, NOTFOUND, QUIT, RUN};

class Menu;
class SearchMenu;

typedef menu_return_type (Menu::*MenuHandlerPtr)(string &input);
typedef string (Menu::*MenuDisplayPtr)(long);


class MenuItem
{
 public:
  MenuItem() {};
  ~MenuItem(){};
  MenuItem GetItem() const;
  string GetKey() const;
  long   GetKeyid() const { return keyid; };
  string GetText() const;
  Menu * GetHandler() const;
  void SetItem(string thiskey, string thistext, Menu * thishandler,
	       MenuHandlerPtr foo, MenuDisplayPtr goo, long id);

  void SetItem(string thiskey, string thistext, Menu * thishandler,
	       MenuHandlerPtr foo, MenuDisplayPtr goo);

  void SetItem(string thiskey, string thistext, Menu * thishandler); // used to generate a standard menu
  void SetItem(string thistext, Menu  * thishandler); // use to generate a dialog etc
  // the action is responsible for delegating user input to the correct data parts
  // the action is most likely a function in the menu because thos have access to the
  // dialog machinery ?
  MenuHandlerPtr p;  // tunneling input for variable into display  
  MenuDisplayPtr q;  // tunneling display of variable to display

 protected:
  string key;
  long keyid;
  string text;
  Menu * handler; // handler needs two functions bool = Show() and bool = OnError()
};


#endif











