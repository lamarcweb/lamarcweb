// $Id: treelist.h,v 1.3 2002/06/26 19:11:57 lamarc Exp $

#ifndef _LISTTREE
#define _LISTTREE

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

template <class Dtype>
class TreeList;

template <class Dtype>
struct TLink
{
  TreeList<Dtype> *child;
  TLink<Dtype>    *next;
  Dtype           *pData;
};

//__________________________________________________________________
//__________________________________________________________________

template <class Dtype>
class TreeList
{
  protected:
    TreeList<Dtype> *parent;
    TLink<Dtype>    *head;
    TLink<Dtype>    *cursor;
    long             length;
    int              level;

  public:
                     TreeList();
    virtual          ~TreeList();
    void             Destroy();
    void             Clear();

    int              Level()               { return level; };
    long             Length()              { return length; };
    void             Begin()               { cursor = head; };
    void             Next()                { cursor = cursor->next; };
    bool             InRange()             { return cursor->next != NULL; };
    bool             HasChild()            { return cursor->next->child != NULL; };

    void             MakeChild(TreeList<Dtype>* list);
    void             Append(Dtype*);
    void             DeleteContents();  // assumes that we own pData!

    Dtype           *Get();
    Dtype           *Get(long);
    TreeList<Dtype> *GetParent()           { return parent; };
    TreeList<Dtype> *GetChild();
};

//__________________________________________________________________

template <class Dtype>
TreeList<Dtype>::TreeList()
{
  parent      = NULL;
  head        = new TLink<Dtype>;
  head->child = NULL;
  head->next  = NULL;
  head->pData = NULL;
  cursor      = head;
  length      = 0;
  level       = 0;
}

//__________________________________________________________________

template <class Dtype>
TreeList<Dtype>::~TreeList()
{
  while (head != NULL)
  {
    cursor = head->next;
    delete head->child;
    delete head;
    head = cursor;
  }
}

//__________________________________________________________________
//__________________________________________________________________

template <class Dtype>
void TreeList<Dtype>::Clear()
{
  while (head->next != NULL)
  {
    cursor = head->next->next;
    delete head->next->child;
    delete head->next;
    head->next = cursor;
  }

  cursor = head;
  length = 0;
}

//__________________________________________________________________

// Mary's function:  deletes all pData entries in a TreeList.
// It is disasterous to call this unless pData contains
// owning pointers (and all empty ones contain NULL).

template <class Dtype>
void TreeList<Dtype>::DeleteContents()
{
  while (head->next != NULL) {
    cursor = head->next->next;
    if (head->next->child != NULL) {
      head->next->child->DeleteContents();
      delete head->next->child;
      head->next->child = NULL;
    }

    delete head->next->pData;
    head->next->pData = NULL;
    delete head->next;
    head->next = cursor;
  }

  cursor = head;
  length = 0;

} /* DeleteContents */

//__________________________________________________________________

template <class Dtype>
void TreeList<Dtype>::Destroy()
{
  while (head->next != NULL)
  {
    cursor = head->next->next;
    if (head->next->child != NULL)
    {
      head->next->child->Destroy();
      delete head->next->child;
    }

    delete head->next;
    head->next = cursor;
  }

  cursor = head;
  length = 0;
}

//__________________________________________________________________
//__________________________________________________________________

template <class Dtype>
void TreeList<Dtype>::Append(Dtype *data)
{
  for ( ; cursor->next != NULL; cursor = cursor->next)
     {};

  cursor->next = new TLink<Dtype>;
  cursor->next->child = NULL;
  cursor->next->next  = NULL;
  cursor->next->pData = data;
  length++;
}

//__________________________________________________________________

template <class Dtype>
void TreeList<Dtype>::MakeChild(TreeList<Dtype>* list)
{
//  TreeList<Dtype> *list = new TreeList<Dtype>;
  cursor->next->child = list;

  list->parent = this;
  list->level  = level+1;

//  return list;
}

//__________________________________________________________________

template <class Dtype>
Dtype *TreeList<Dtype>::Get()
{
  if (cursor->next != NULL)
    return cursor->next->pData;

  return NULL;
}

//__________________________________________________________________

template <class Dtype>
Dtype *TreeList<Dtype>::Get(long posn)
{
  if (posn < 0 || length <= posn)
    return NULL;

  long n;
  for (cursor = head, n = 0; n < posn; cursor = cursor->next, n++)
     ;

  return cursor->next->pData;
}

//__________________________________________________________________

template <class Dtype>
TreeList<Dtype> *TreeList<Dtype>::GetChild()
{
  if (cursor->next == NULL)
    return NULL;

  return cursor->next->child;
}

#endif

