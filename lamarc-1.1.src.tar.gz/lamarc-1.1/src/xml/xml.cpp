//$Id: xml.cpp,v 1.27 2002/06/26 20:26:07 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "xml.h"
// to obtain the singletons and fill them up
#include "registry.h"
// to set the datatype of a region and use it to proofread data
#include "datatype.h"
#include "types.h"  // for access to DataType's auto_ptr type
#include <iostream>
#include "chainparam.h"
#include "userparam.h"
#include "forcesummary.h"
#include "dlmodel.h"
#include "arranger.h"
#include <limits.h>   // for numeric limits info
#include "stringx.h"
#include "force.h"

using namespace std;

// mock macro variables....
const long initial = 0;
const long final = 1;

//__________________________________________________________

DataFile::DataFile(Registry& reg)
 : XMLReader(), registry(reg), datapack(reg.GetDataPack()),
   pCurrRegion(NULL), dlmodel(NULL), globaldlmodel(NULL)
{
  xmlDB = new XmlDB;
} /* constructor */

//__________________________________________________________

DataFile::~DataFile()
{
  // if a global data model was created, we own it and
  // need to delete it
  delete globaldlmodel;
  
  delete xmlDB;
  xmlDB = NULL;
} /* destructor */

//__________________________________________________________
//__________________________________________________________

bool DataFile::ReadFile(const string& filename)
{

  // read the data file
  if (!Read(filename)) {
    // errorMessage.append("Data file not found");
    // ThrowFileError(errorMessage);
    // error handling is being done in the menu
    // all 2001/11/26
    return false;
  }

  // Close the file -- we're done with it
  Close();

  // check for the lamarc tag
  DBElement* dbe = xmlDB->Get();
  if(dbe == (DBElement*)NULL) {
      ThrowDataError("Input does not appear to be an XML file");
  }
  if (dbe->tag != "lamarc") ThrowDataError("Lamarc tag not found");

  // process the contents
  XmlDB* childlist = xmlDB->GetDBChild();
  CheckContent(childlist);

  // WARNING:  you must check for global DL model before checking
  // for regional DL models
  if (childlist->FindFirstTag("model")) {
    DoDLModel(childlist);
    globaldlmodel = dlmodel;
  }

// NB:  The order of these calls is not arbitrary.  In particular,
// you *must* call DoData before the others, as they all tend to
// depend on npops.

  // data is obligatory
  if (childlist->FindFirstTag("data")) DoData(childlist);
  else ThrowDataError("Data tag not found");

  // all other sections are optional
  if (childlist->FindFirstTag("chains")) DoChainParams(childlist);

  if (childlist->FindFirstTag("format")) DoUserParams(childlist);

  if (childlist->FindFirstTag("forces")) DoForces(childlist);

  return true;

} /* ReadFile */

//__________________________________________________________

void DataFile::DoData(XmlDB* xmllist) {

  string tag = "data";
  SetTag(tag);
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);
  DoRegions(childlist);
  ClearTag();

} /* DoData */

//__________________________________________________________


void DataFile::DoRegions(XmlDB* xmllist) {

  string tag = "region";

  SetTag(tag);
  if (xmllist->FindFirstTag(tag)) { // labeled regions
    bool done;
    for (done = xmllist->FindFirstTag(tag); done;
         done = xmllist->FindNextTag(tag)) {
      // set up a region 
      pCurrRegion = new Region(datapack);
      datapack.SetRegion(pCurrRegion);
      pCurrRegion->SetRegionName(ReadName(xmllist));
      currindno = 0;

      XmlDB* childlist = xmllist->GetDBChild();
      CheckContent(childlist);
      // Use local data model if it exists, else use global one,
      // else put in a NULL
      if (!DoDLModel(childlist)) {
        if (!globaldlmodel) {
//          ThrowDataError("Neither local nor global data model found");
        }
        else 
          dlmodel = globaldlmodel->Clone();
      }
      DataModel_ptr dptr(dlmodel);
      pCurrRegion->datamodel = dptr;
      DoPopulations(childlist);
      if (childlist->FindFirstTag("spacing")) DoSpacing(childlist);
      else DoSpacing(NULL);
      string errorString;
      if (!pCurrRegion->IsValid(errorString)) 
        ThrowDataError("Inconsistent specifications in region " + 
          ToString(pCurrRegion->GetID() + 1)
          + string(": ") + errorString);
    }
  }
  else { // no labeled regions; assume only one
    // set up a region 
    pCurrRegion = new Region(datapack);
    datapack.SetRegion(pCurrRegion);
    DoDLModel(xmllist);
    // Use local data model if it exists, else use global one
    if (!DoDLModel(xmllist)) {
      if (!globaldlmodel)
        ThrowDataError("Neither local nor global data model found");
      else dlmodel = globaldlmodel->Clone();
    }
    DataModel_ptr dptr(dlmodel);
    pCurrRegion->datamodel = dptr;
    DoPopulations(xmllist);
    if (xmllist->FindFirstTag("spacing")) DoSpacing(xmllist);
    else DoSpacing(NULL); 
    string errorString;
    if (!pCurrRegion->IsValid(errorString)) 
      ThrowDataError("Inconsistent specifications in region" + 
        ToString(pCurrRegion->GetID() + 1)
          + string(": ") + errorString);
  }
  ClearTag();

} /* DoRegions */

//__________________________________________________________

void DataFile::DoPopulations(XmlDB* xmllist) {
  string tag = "population";

  SetTag(tag);
  if (xmllist->FindFirstTag(tag)) { // labeled populations
    bool done;
    for (done = xmllist->FindFirstTag(tag); done;
         done = xmllist->FindNextTag(tag)) {
      // identify the population
      // DEBUG this line needs error checking on return value!
      currpopulation = datapack.AddPopulation(ReadName(xmllist));
      XmlDB* childlist = xmllist->GetDBChild();
      // rather than CheckContent here, we check for null
      // but allow it--a population may contain nothing!
      if (childlist != NULL) {
        DoIndividuals(childlist);
      }
    }
  } else { // no labeled populations; assume only one
    // identify the population
    currpopulation = datapack.AddPopulation(string("Default Population"));
    if (currpopulation != 0) 
      ThrowDataError("Multiple populations with no population labels.");
    DoIndividuals(xmllist);
  }
  ClearTag();
} /* DoPopulations */

//__________________________________________________________

void DataFile::DoIndividuals(XmlDB* xmllist) {

  string tag = "individual";

  SetTag(tag);

  if (xmllist->FindFirstTag(tag)) { // labeled individuals
    bool done;
    for (done = xmllist->FindFirstTag(tag); done;
         done = xmllist->FindNextTag(tag), currindno++) {
      // set up an individual here
      currIndividual.SetId(currindno);
      string name = ReadName(xmllist);
      if (name.empty()) name = ToString(currindno);
      currIndividual.SetName(name);
      XmlDB* childlist = xmllist->GetDBChild();
      CheckContent(childlist);
      DoSamples(childlist);
      // NB:  DoPhase *must* come after DoSamples so that the
      // number of markers will be known
      LongVec1d phases = DoPhase(childlist);
      currIndividual.SetPhaseMarkers(phases);
      pCurrRegion->AddIndividual(currIndividual);
    }
  } else { // no labeled individuals; assume all samples are independent
    currIndividual.SetId(0L);
    currIndividual.SetName("noname");
    DoSamples(xmllist);
    // NB:  DoPhase *must* come after DoSamples so that the
    // number of markers will be known
    currIndividual.SetPhaseMarkers(DoPhase(xmllist));
    pCurrRegion->AddIndividual(currIndividual);
  }
  ClearTag();
} /* DoIndividuals */

//__________________________________________________________

void DataFile::DoSamples(XmlDB* xmllist) {
  string tag = "sample";

  SetTag(tag);
  // samples are obligatory!
  bool done;
  for (done = xmllist->FindFirstTag(tag); done;
       done = xmllist->FindNextTag(tag)) {

    // set up a sample 
    string name = ReadName(xmllist);
    if (name.empty()) name = currIndividual.GetName() + 
                           ToString(registry.GetRandom().Integer());
    XmlDB* childlist = xmllist->GetDBChild();
    tipdata.label = name;
    tipdata.population = currpopulation;
    tipdata.individual = currIndividual.GetId();

    // get the contents
    CheckContent(childlist);
    DoDataBlock(childlist);

    // put this tip into the storehouse
    pCurrRegion->SetTipData(tipdata);
  }
  ClearTag();
} /* DoSamples */

//__________________________________________________________

void DataFile::DoDataBlock(XmlDB* xmllist) {
  string tag = "datablock";
  string typetag = "type";
  string datatype;

  SetTag(tag);
  xmllist->FindFirstTag(tag);

  // Read the data type
  DBElement* dbe = xmllist->Get();
  dbe->GetAttribute(typetag, datatype);
  // DEBUG needs error checking!!  Lots of it!
  pCurrRegion->datatype.reset(CreateDataType(datatype));

#if 0
  // Read the name, if any
  // I can't use ReadName here because I've already called
  // xmllist->Get() once, and daren't call it again!

// currently datablocks do not have names!
  string name;
  dbe->GetAttribute(string("name"), name);
  if (name.empty()) name = currIndividual.GetName() + 
                           ToString(registry.GetRandom().Integer());
#endif
  
  // Read the data
  tipdata.data.clear();
  string baddata;
  bool good_data = pCurrRegion->datatype->Proofread(dbe->content, tipdata.data, baddata);
  if (!good_data) {
    string problem = "Invalid genetic data in population " + ToString(currpopulation)
                   + " sample " + tipdata.label + "\n";  
    problem += "Offending allele: " + baddata;
    ThrowDataError(problem);
  }
  long len = tipdata.data.size();

  try 
  {
      pCurrRegion->SetNmarkers(len);
  }
  catch (exception& e) 
  { 
      long expectedNmarkers = pCurrRegion->GetNmarkers(); 
      long localLineNumber = dbe->GetLineNumber();
      string tagName = dbe->GetTag();
      string message = string ("Data element \"" + tagName + "\" at input line ") 
          + ToString(localLineNumber) + string( " has ") + ToString(len);
      message += " data elements but previous has " + ToString(expectedNmarkers);
      ThrowDataError (message);
  }

  ClearTag();

} /* DoDataBlock */

//__________________________________________________________

// The following routines are used to establish the map
//__________________________________________________________

void DataFile::DoSpacing(XmlDB* xmllist)
{
  string tag = "spacing";
  SetTag(tag);
  if (xmllist == NULL) {
    // no spacing info given, so we set up defaults                   
    long nmarkers = pCurrRegion->GetNmarkers();
    vector<long> positions(nmarkers,0L);
    long i;
    for (i = 0; i < nmarkers; ++i) positions[i] = i;
    pCurrRegion->SetPositions(positions);
    // all other spacing parameters are set by default in constructor
  } else {
    // spacing info is available
    XmlDB* childlist = xmllist->GetDBChild();
    if (childlist == NULL) ThrowDataError("Empty spacing information");
    if (childlist->FindFirstTag("block")) DoBlocks(childlist);
  }
  ClearTag();

} /* DoSpacing */

//__________________________________________________________

void DataFile::DoBlocks(XmlDB* xmllist)
{
  string tag = "block";
  SetTag(tag);
  bool done;
  for (done = xmllist->FindFirstTag(tag); done;
       done = xmllist->FindNextTag(tag)) {

    XmlDB* childlist = xmllist->GetDBChild();
    if (childlist->FindFirstTag("offset")) DoOffset(childlist);
    else DoOffset(NULL);
    if (childlist->FindFirstTag("map_position")) DoMapPosition(childlist);
    if (childlist->FindFirstTag("length")) DoLength(childlist);
    if (childlist->FindFirstTag("locations")) DoLocations(childlist);
  }
  ClearTag();

} /* DoBlocks */

//__________________________________________________________

void DataFile::DoMapPosition(XmlDB* xmllist)
{
  string tag = "map-position";
  SetTag(tag);

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  if (!IsInteger(content)) ThrowDataError("Illegal map position");
  pCurrRegion->SetMapposition(atol(content.c_str()));
  ClearTag();

} /* DoMapPosition */

//__________________________________________________________

void DataFile::DoLength(XmlDB* xmllist)
{
  string tag = "length";
  SetTag(tag);
  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  if (!IsInteger(content)) ThrowDataError("Illegal data length");
  long length = atol(content.c_str());
  if (!InBounds(length, 1L, MAXLONG)) ThrowDataError("Illegal data length");
  pCurrRegion->SetNsites(length);

  ClearTag();

} /* DoLength */

//__________________________________________________________

void DataFile::DoLocations(XmlDB* xmllist)
{
  string tag = "locations";
  SetTag(tag);
  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  vector<long> locations;
  unsigned long result = 0;
  long tokennumber = 0;
  string token;
  long offset = pCurrRegion->GetOffset();

  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    // we subtract the offset here, making all positions
    // relative to zero
    long pos = atoi(token.c_str()) - offset;
    if (pos < 0) ThrowDataError("Illegal marker location in region "
      + ToString(pCurrRegion->GetID()));
    locations.push_back(pos);
  }
  pCurrRegion->SetPositions(locations);

  ClearTag();

} /* DoLocations */

//__________________________________________________________

void DataFile::DoOffset(XmlDB* xmllist) 
{
  string tag = "offset";
  SetTag(tag);
  if (xmllist == NULL) { // no offset; assume 0
    pCurrRegion->SetOffset(0);
  } else {
    DBElement* dbe = xmllist->Get();
    string content = dbe->content;
    if (!IsInteger(content)) ThrowDataError("Illegal map offset");
    long offset = atol(content.c_str());
    pCurrRegion->SetOffset(offset);
  }

  ClearTag();

} /* DoOffset */

//__________________________________________________________

LongVec1d DataFile::DoPhase(XmlDB* xmllist)
// read information about sites of known/unknown phase
// attribute "unknown" means that this is a list of phase-unknown
// sites (to be stored as-is) whereas attribute "known" means that
// this is a list of phase-known sites (and we store the
// inverse, the phase-unknown sites).
{
  string tag = "phase";
  string typetag = "type";
  string phasetype;
  LongVec1d phasemarkers;
  string token;
  long tokennumber = 0;
  unsigned long result = 0; 
  long known;
  long unknown;

  SetTag(tag);
  if (xmllist->FindFirstTag(tag)) {  // phase information found
    DBElement* dbe = xmllist->Get();
    string content = dbe->content;

    dbe->GetAttribute(typetag, phasetype);
    phasetype = Strip(phasetype);
    if (phasetype == "unknown") {  // put sites into array directly
      while (1) {
        result = GetToken(content, token, tokennumber);
        if (result == string::npos) break;
        tokennumber = result;
        phasemarkers.push_back(atoi(token.c_str()));
      }

    } else if (phasetype == "known") {  // put inverse of sites into array
      unknown = 0;
      while (1) {
        result = GetToken(content, token, tokennumber);
        if (result == string::npos) break;
        tokennumber = result;
        known = atoi(token.c_str());
        for ( ; unknown < known; ++unknown) {
          phasemarkers.push_back(unknown);
        }
        unknown = known+1;
      }
      known = pCurrRegion->GetNmarkers();
      for ( ; unknown < known; ++unknown) {
        phasemarkers.push_back(unknown);
      }

    } else {  
      ThrowDataError("Unknown type of phase information " + phasetype);
    }
  }
  // if there is no phase information, we set the PhaseMarkers
  // to an empty vector (implying that phase is known for all sites)
  // using flowthrough logic.

  ClearTag();
  return phasemarkers;
} /* DoPhase */

//----------------------------------------------------------
// Tagline handling routines
//__________________________________________________________

void DataFile::SetTag(const string& tag)
// call at start of each XML parsing level
{
  CheckTags(tag);
  taglines.push_back(make_pair(tag, 0L));

} /* SetTag */

//__________________________________________________________

void DataFile::CheckTags(const string& tag)
// does the current tag duplicate one already in effect?
// if so, log error and throw.
{
  TagLine tagline;
  long end = taglines.size();
  long i;

  if (taglines.empty()) return;

  for (i = 0; i < end; ++i) {
    tagline = taglines[i];
    if (tagline.first == tag) {
      errorMessage.append("XML ERROR: Nested <");
      errorMessage.append(tag);
      errorMessage.append("> tags encountered.");
      ThrowXMLError(errorMessage);
    }
  }
} /* CheckTags */

//__________________________________________________________

void DataFile::ClearTag()
// call at end of each XML parsing level
{
  taglines.pop_back();
} /* ClearTag */

//__________________________________________________________

void DataFile::CheckContent(XmlDB* xmllist)
{
  if (xmllist == NULL)
  {
    TagLine tagline = taglines.back();
    errorMessage.append("DATA ERROR: Missing content between <");
    errorMessage.append(tagline.first);
    errorMessage.append("> tags.\n");
    ThrowDataError(errorMessage);
  }

} /* CheckContent */

//__________________________________________________________

string DataFile::ReadName(XmlDB* xmllist)
{
  string attrib = "name";
  string name;
  DBElement* dbe = xmllist->Get();
  dbe->GetAttribute(attrib, name);
  return name;
} /* ReadName */

//__________________________________________________________

string DataFile::Strip(const string& target)
{
// trim all whitespace from string
unsigned long i;
string result;
for (i = 0; i < target.size(); ++i) {
  if (!isspace(target[i])) result += target[i];
}

return result;

} /* Strip */

//__________________________________________________________

bool DataFile::DoDLModel(XmlDB* xmllist)
{

  string tag = "model";
  if (xmllist->FindFirstTag(tag)) {
    SetTag(tag);

    string attrib = "name";
    string name;
    DBElement* dbe = xmllist->Get();
    dbe->GetAttribute(attrib, name);

    // DEBUG:  This should eventually call code to
    // check for datatype/datamodel mismatch such as
    // using F84 on microsatellites.

    dlmodel = CreateDataModel(name);
    if (name == "F84") DoF84Model(xmllist);
    else if (name == "Stepwise") DoStepwiseModel(xmllist);
    else if (name == "Brownian") DoBrownianModel(xmllist);
    else ThrowDataError("Unknown data model " + name);

    ClearTag();
    return true;
  }

  return false;  // no local data model; use the global one

} /* DoDLModel */

//__________________________________________________________

void DataFile::DoF84Model(XmlDB* xmllist)
{
  
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "base-freqs";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoBaseFreqs(childlist);
    ClearTag();
  }
  
  tag = "ttratio";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoTTRatio(childlist);
    ClearTag();
  }

  tag = "categories";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoCategories(childlist);
    ClearTag();
  }

  tag = "normalize";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoNormalize(childlist);
    ClearTag();
  }

  if (!dlmodel->IsValid())
    ThrowDataError("F84 Data Model is inconsistent.");

} /* DoF84Model */

//__________________________________________________________

void DataFile::DoStepwiseModel(XmlDB* xmllist)
{
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "normalize";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoNormalize(childlist);
    ClearTag();
  }

  tag = "categories";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoCategories(childlist);
    ClearTag();
  }

  if (!dlmodel->IsValid())
    ThrowDataError("Stepwise Data Model is inconsistent.");

} /* DoStepwiseModel */

//__________________________________________________________

void DataFile::DoBrownianModel(XmlDB* xmllist)
{
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "categories";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoCategories(childlist);
    ClearTag();
  }

  if (!dlmodel->IsValid())
    ThrowDataError("Brownian Data Model is inconsistent.");

} /* DoBrownianModel */

//__________________________________________________________

void DataFile::DoBaseFreqs(XmlDB* xmllist) 
{
  long tokennumber = 0;
  string token;
  unsigned long result;
  vector<double> basefreqs;

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  double totalfreqs = 0.0;

  F84Model* f84model = dynamic_cast<F84Model*>(dlmodel);

  while (1) {
    result = GetToken(content, token, tokennumber);
    if (token == "calculated") {   // calculate them from data instead
      f84model->SetFreqsFromData(true);
      return;
    }
    if (result == string::npos) break;
    tokennumber = result;
    if (!IsReal(token)) ThrowDataError("Illegal base frequencies");
    double freq = atof(token.c_str());
    if (!InBounds(freq, 0.0, 1.0))
      ThrowDataError("Illegal base frequency");
    basefreqs.push_back(freq);
    totalfreqs += freq;
  }

  if (basefreqs.size() != 4) ThrowDataError("Wrong number of base frequencies");

  if (fabs(1.0 - totalfreqs) > EPSILON) 
    ThrowDataError("Base frequences do not add to 1");

  f84model->SetBaseFrequencies(basefreqs);
  f84model->SetFreqsFromData(false);

} /* DoBaseFreqs */

//__________________________________________________________

void DataFile::DoTTRatio(XmlDB* xmllist)
{
  DBElement* dbe = xmllist->Get();
  string content = dbe->content;

  if (!IsReal(content)) ThrowDataError("Illegal transition/transversion ratio");
  
  F84Model* f84model = dynamic_cast<F84Model*>(dlmodel);
  double ttratio = atof(content.c_str());
  if (!InBounds(ttratio, 0.5, DBL_MAX))
    ThrowDataError("Transition/transversion ratio out of range");
  f84model->SetTTratio(ttratio);

} /* DoTTRatio */

//__________________________________________________________

void DataFile::DoCategories(XmlDB* xmllist)
{

  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "num-categories";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoNumCategories(childlist);
    ClearTag();
  }

  tag = "rates";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoCatRates(childlist);
    ClearTag();
  }

  tag = "probabilities";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoCatProbs(childlist);
    ClearTag();
  }

  tag = "autocorrelation";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoAutoCorr(childlist);
    ClearTag();
  }

} /* DoCategories */

//__________________________________________________________

void DataFile::DoNumCategories(XmlDB* xmllist)
{
  DBElement* dbe = xmllist->Get();
  string content = dbe->content;

  if (!IsInteger(content)) ThrowDataError("Illegal number of categories");
  long cats = atol(content.c_str());
  if (!InBounds(cats, 1L, LONG_MAX)) 
    ThrowDataError("Number of categories out of bounds");
  dlmodel->SetNcategories(cats);

} /* DoNumCategories */

//__________________________________________________________

void DataFile::DoCatRates(XmlDB* xmllist)
{
  long tokennumber = 0;
  string token;
  unsigned long result;
  DoubleVec1d rates;

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;

  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    if (!IsReal(token)) ThrowDataError("Illegal category rates");
    double rate = atof(token.c_str());
    if (!InBounds(rate, 0.0, DBL_MAX))
      ThrowDataError("Category rates out of bounds");
    rates.push_back(rate);
  }

  dlmodel->SetCatRates(rates);

} /* DoCatRates */

//__________________________________________________________

void DataFile::DoCatProbs(XmlDB* xmllist)
{
  long tokennumber = 0;
  string token;
  unsigned long result;
  DoubleVec1d probs;

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;

  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    if (!IsReal(token)) ThrowDataError("Illegal category probabilities");
    double prob = atof(token.c_str());
    if (!InBounds(prob, 0.0, 1.0)) 
      ThrowDataError("Category probability out of bounds");
    probs.push_back(atof(token.c_str()));
  }

  dlmodel->SetCatProbabilities(probs);

} /* DoCatProbs */

//____________________________________________________________________

void DataFile::DoAutoCorr(XmlDB* xmllist)
{
  DBElement* dbe = xmllist->Get();
  string content = dbe->content;

  if (!IsReal(content)) ThrowDataError("Illegal autocorrelation");
  double ratio = atof(content.c_str());
  if (!InBounds(ratio, 0.0, DBL_MAX)) 
    ThrowDataError("Autocorrelation out of bounds");
  dlmodel->SetAcratio(ratio);

} /* DoAutoCorr */

//__________________________________________________________

void DataFile::DoNormalize(XmlDB* xmllist)
{
  DBElement* dbe = xmllist->Get();
  bool norm = false;  // fake initialization to quiet a warning
  try {
    norm = StringToBool(Strip(dbe->content));
    dlmodel->SetNormalize(norm);
  }
  catch (exception& e) {
    ThrowDataError("Illegal normalization setting " + norm);
  }

} /* DoNormalize */

//__________________________________________________________
//__________________________________________________________

void DataFile::DoChainParams(XmlDB* xmllist)
{
  string tag = "chains";
  SetTag(tag);
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  tag = "replicates";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoReplicates(childlist);
    ClearTag();
  }

  tag = "heating";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoHeating(childlist);
    ClearTag();
  }

  tag = "strategy";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoStrategy(childlist);
    ClearTag();
  }

  tag = "initial";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoChains(childlist, initial);
    ClearTag();
  }

  tag = "final";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoChains(childlist, final);
    ClearTag();
  }

  // check for validity
  ChainParameters& chainparm = registry.GetChainParameters();
  if (!chainparm.IsValid()) 
    ThrowDataError("Chain parameters are inconsistent");

  ClearTag();

} /* DoChainParams */

//__________________________________________________________

void DataFile::DoReplicates(XmlDB* xmllist)
{
  ChainParameters& chainparm = registry.GetChainParameters();

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  if (!IsInteger(content)) ThrowDataError("Illegal number of replicates");
  long reps = atol(content.c_str());
  if (!InBounds(reps, 1L, LONG_MAX)) 
    ThrowDataError("Number of replicates out of bounds");
  chainparm.SetNReps(reps);

} /* DoReplicates */

//__________________________________________________________

void DataFile::DoHeating(XmlDB* xmllist)
{

  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "temperatures";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoTemperatures(childlist);
    ClearTag();
  }

  tag = "swap-interval";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoSwapInterval(childlist);
    ClearTag();
  }

  tag = "heating-strategy";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoHeatingstrategy(childlist);
    ClearTag();
  }

} /* DoHeating */

//__________________________________________________________

void DataFile::DoTemperatures(XmlDB* xmllist)
{
  long tokennumber = 0;
  string token;
  unsigned long result;
  vector<double> temperatures;

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    if (!IsReal(token)) ThrowDataError("Illegal temperature");
    double tem = atof(token.c_str());
    if (!InBounds(tem, 1.0, DBL_MAX)) 
      ThrowDataError("Temperature out of bounds");
    temperatures.push_back(tem);
  }

  ChainParameters& chainparm = registry.GetChainParameters();
  chainparm.SetAllTemperatures(temperatures);

} /* DoTemperatures */

//__________________________________________________________

void DataFile::DoSwapInterval(XmlDB* xmllist)
{
  long tokennumber = 0;
  string token;
  unsigned long result;
  long interval;

// this does things unnecessarily obtusely because this
// scalar variable used to be a vector.
  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    if (!IsInteger(token)) ThrowDataError("Illegal swap interval");
    long swp = atol(token.c_str());
    if (!InBounds(swp, 1L, LONG_MAX))
      ThrowDataError("Swap interval out of bounds");
    interval = swp ;
  }

  ChainParameters& chainparm = registry.GetChainParameters();
  chainparm.SetTempInterval(interval);

} /* DoTemperatures */


void DataFile::DoHeatingstrategy(XmlDB* xmllist)
{
  long tokennumber = 0;
  string token;
  unsigned long result;

// this does things unnecessarily obtusely because this
// scalar variable used to be a vector.
  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  const string adaptiveheat("ADAPTIVE");
  const string staticheat("STATIC");
  bool adapt = false;
  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    UpperCase(token);
    if((token.find(adaptiveheat) >= token.size()) && 
       (token.find(staticheat) >= token.size()))
      ThrowDataError("Illegal heating strategy");
    else
      adapt = (token.find(adaptiveheat) < token.size()) ?  true : false ;
  }

  ChainParameters& chainparm = registry.GetChainParameters();
  chainparm.SetTempAdapt (adapt);
} /* DoHeatingStrategy */

//__________________________________________________________

void DataFile::DoStrategy(XmlDB* xmllist)
{
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "resimulating";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoResimulating(childlist);
    ClearTag();
  }

  tag = "haplotyping";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoHaplotyping(childlist);
    ClearTag();
  }

} /* DoStrategy */

//__________________________________________________________

void DataFile::DoResimulating(XmlDB* xmllist)
{
  DBElement* dbe = xmllist->Get();
  string p = dbe->content;
  if (IsReal(p)) {
    double prob = atof(p.c_str());
    if (InBounds(prob, 0.0, 1.0)) {
      Arranger* arranger = new DropArranger(&(registry.GetRandom()));
      ChainParameters& chainparm = registry.GetChainParameters();
      arranger->SetTiming(prob);
      chainparm.AddArranger(arranger);
      return;
    }
  }

  ThrowDataError("Invalid resimulating arranger specification");

} /* DoResimulating */

//__________________________________________________________

void DataFile::DoHaplotyping(XmlDB* xmllist)
{
  DBElement* dbe = xmllist->Get();
  string p = dbe->content;
  if (IsReal(p)) {
    double prob = atof(p.c_str());
    if (InBounds(prob, 0.0, 1.0)) {
      Arranger* arranger = new HapArranger(&(registry.GetRandom()));
      ChainParameters& chainparm = registry.GetChainParameters();
      arranger->SetTiming(prob);
      chainparm.AddArranger(arranger);
      return;
    }
  }

  ThrowDataError("Invalid haplotyping arranger specification");

} /* DoHaplotyping */

//__________________________________________________________

void DataFile::DoChains(XmlDB* xmllist, long chaintype)
{
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "number";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoChainNumber(childlist, chaintype);
    ClearTag();
  }

  tag = "samples";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoChainSamples(childlist, chaintype);
    ClearTag();
  }

  tag = "interval";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoChainInterval(childlist, chaintype);
    ClearTag();
  }

  tag = "discard";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoChainDiscard(childlist, chaintype);
    ClearTag();
  }

} /* DoChains */

//__________________________________________________________

void DataFile::DoChainNumber(XmlDB* xmllist, long chaintype)
{
  ChainParameters& chainparm = registry.GetChainParameters();

  DBElement* dbe = xmllist->Get();
  string numch = dbe->content;
  if (IsInteger(numch)) {
    long numchains = atol(numch.c_str());
    if (InBounds(numchains, 0L, LONG_MAX)) {
      chainparm.SetNChains(chaintype, numchains);
      return;
    }
  }

  ThrowDataError("Illegal number of chains");

} /* DoChainNumber */

//__________________________________________________________

void DataFile::DoChainSamples(XmlDB* xmllist, long chaintype)
{
  ChainParameters& chainparm = registry.GetChainParameters();

  DBElement* dbe = xmllist->Get();
  string ns = dbe->content;
  if (IsInteger(ns)) {
    long numsamples = atol(ns.c_str());
    if (InBounds(numsamples, 0L, LONG_MAX)) {
      chainparm.SetNSamples(chaintype, numsamples);
      return;
    }
  }

  ThrowDataError("Illegal number of trees to sample");

} /* DoChainSamples */

//__________________________________________________________

void DataFile::DoChainInterval(XmlDB* xmllist, long chaintype)
{
  ChainParameters& chainparm = registry.GetChainParameters();

  DBElement* dbe = xmllist->Get();
  string intr = dbe->content;
  if (IsInteger(intr)) {
    long interval = atol(intr.c_str());
    if (InBounds(interval, 1L, LONG_MAX)) {
      chainparm.SetInterval(chaintype, interval);
      return;
    }
  }

  ThrowDataError("Invalid sampling interval");

} /* DoChainInterval */

//__________________________________________________________

void DataFile::DoChainDiscard(XmlDB* xmllist, long chaintype)
{
  ChainParameters& chainparm = registry.GetChainParameters();

  DBElement* dbe = xmllist->Get();
  string dis = dbe->content;
  if (IsInteger(dis)) {
    long discard = atol(dis.c_str());
    if (InBounds(discard, 0L, LONG_MAX)) {
      chainparm.SetNDiscard(chaintype, discard);
      return;
    }
  }

  ThrowDataError("Invalid discard values");

} /* DoChainDiscard */

//__________________________________________________________

void DataFile::DoUserParams(XmlDB* xmllist)
{
  string tag = "format";
  SetTag(tag);
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  tag = "verbosity";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoVerbosity(childlist);
    ClearTag();
  }

  tag = "progress-reports";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoProgress(childlist);
    ClearTag();
  }

  tag = "echo";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoEcho(childlist);
    ClearTag();
  }

  tag = "plotting";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoPlotSpecs(childlist);
    ClearTag();
  }

  tag = "seed";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoRandomSeed(childlist);
    ClearTag();
  }

  tag = "parameter-file";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoParamFileName(childlist);
    ClearTag();
  }

  tag = "results-file";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoResultsFileName(childlist);
    ClearTag();
  }

  tag = "summary-file";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoSummaryFileName(childlist);
    ClearTag();
  }
  ClearTag();

} /* DoUserParams */

//__________________________________________________________

void DataFile::DoVerbosity(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  string verbosity = Strip(dbe->content);
  if (verbosity == "concise") {
    userparm.SetVerbosity(CONCISE);
    return;
  }
  if (verbosity == "normal") {
    userparm.SetVerbosity(NORMAL);
    return;
  }
  if (verbosity == "verbose") {
    userparm.SetVerbosity(VERBOSE);
    return;
  }
  ThrowDataError("Illegal verbosity setting " + verbosity);

} /* DoVerbosity */

//__________________________________________________________

void DataFile::DoProgress(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  string verbosity = Strip(dbe->content);
  if (verbosity == "none") {
    userparm.SetProgress(NONE);
    return;
  }
  if (verbosity == "concise") {
    userparm.SetProgress(CONCISE);
    return;
  }
  if (verbosity == "normal") {
    userparm.SetProgress(NORMAL);
    return;
  }
  if (verbosity == "verbose") {
    userparm.SetProgress(VERBOSE);
    return;
  }
  ThrowDataError("Illegal progress-report setting " + verbosity);

} /* DoProgress */

//__________________________________________________________

void DataFile::DoEcho(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  bool echo;
  try {
    echo = StringToBool(Strip(dbe->content));
    userparm.SetEchoData(echo);
  }
  catch (exception& e) {
    ThrowDataError("Illegal data-echo setting " + dbe->content);
  }

} /* DoEcho */

//__________________________________________________________

void DataFile::DoPlotSpecs(XmlDB* xmllist)
{
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "posterior";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoPosterior(childlist);
    ClearTag();
  }

#if 0
  tag = "profile";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoProfile(childlist);
    ClearTag();
  }
#endif

} /* DoPlotSpecs */

//__________________________________________________________

void DataFile::DoPosterior(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  bool posterior;
  try {
    posterior = StringToBool(Strip(dbe->content));
    userparm.SetPlotPost(posterior);
  }
  catch (exception& e) {
    ThrowDataError("Illegal posterior-likelihood display option " + dbe->content);
  }

} /* DoPosterior */

//__________________________________________________________

#if 0
void DataFile::DoProfile(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  bool profile;
  try {
    profile = StringToBool(Strip(dbe->content));
  }
  catch (exception& e) {
    ThrowDataError("Illegal profiling option " + dbe->content);
  }
  userparm.SetPlotPost(profile);

} /* DoProfile */
#endif

//__________________________________________________________

void DataFile::DoRandomSeed(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  string sd = dbe->content;
  if (IsInteger(sd)) {
    long seed = atol(sd.c_str());
    // long seed = static_cast<long>(time(NULL))/4 + 1;
    userparm.SetRandomSeed(seed);
// we will do this in lamarc.cpp instead
//    registry.GetRandom().Seed(seed);
    return;
  }

  ThrowDataError("Illegal random seed " + sd);

} /* DoRandomSeed */

//__________________________________________________________

void DataFile::DoParamFileName(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  string name = Strip(dbe->content);
  userparm.SetParamFileName(name);
} /* DoParamFileName */

//__________________________________________________________

void DataFile::DoResultsFileName(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  string name = Strip(dbe->content);
  userparm.SetResultsFileName(name);
} /* DoResultsFileName */

//__________________________________________________________

void DataFile::DoSummaryFileName(XmlDB* xmllist)
{
  UserParameters& userparm = registry.GetUserParameters();
  DBElement* dbe = xmllist->Get();
  string name = Strip(dbe->content);
  userparm.SetTreeSumFileName(name);
} /* DoSummaryFileName */

//----------------------------------------------------------
// Force parameter functions
//__________________________________________________________

void DataFile::DoForces(XmlDB* xmllist)
{
  string tag = "forces";
  SetTag(tag);
  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);
  DoForceIfPresent(childlist,"coalescence",COAL);
  DoForceIfPresent(childlist,"migration",MIG);
  DoForceIfPresent(childlist,"recombination",REC);
  DoForceIfPresent(childlist,"growth",GROW);

  registry.GetForceSummary().SetStartParameters(startparam);

  ClearTag();
} /* DoForces */


//__________________________________________________________

void DataFile::DoForceIfPresent(XmlDB* xmllist, const string& forcetag, const string& forcetype)
{

  if(xmllist->FindFirstTag(forcetag))
  {
    string valueRetrieved;
    SetTag(forcetag); 
    DBElement* dbe = xmllist->Get(); 
    bool foundValue = dbe->GetAttribute("value", valueRetrieved);
    if (foundValue && (valueRetrieved == "off")) 
    {
      TurnOffForce(forcetype);
    }
    else
    {
      DoForce(xmllist,forcetype);
    }
    ClearTag();
  }
}

void DataFile::TurnOffForce(const string& forcetype)
{
  registry.GetForceSummary().UnsetForce(forcetype);
}

//__________________________________________________________

void DataFile::DoForce(XmlDB* xmllist, const string& forcetype) 
{

  registry.GetForceSummary().SetForce(forcetype,registry.GetDataPack());

  XmlDB* childlist = xmllist->GetDBChild();
  CheckContent(childlist);

  string tag = "method";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoMethod(childlist, forcetype);
    ClearTag();
  } 

  tag = "start-values";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoStartValues(childlist, forcetype);
    ClearTag();
  }

  tag = "max-events";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoMaxEvents(childlist, forcetype);
    ClearTag();
  }

  tag = "profiles";
  if (childlist->FindFirstTag(tag)) {
    SetTag(tag);
    DoProfiles(childlist, forcetype);
    ClearTag();
  }

} /* DoForce */

//__________________________________________________________

void DataFile::DoMethod(XmlDB* xmllist, const string& forcetype)
{
  unsigned long tokennumber = 0;
  string token;
  unsigned long result;
  StringVec1d startmethods;
  ForceSummary& forcesumm = registry.GetForceSummary();

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;

  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    ForceVec::const_iterator fit;
    fit = forcesumm.GetForceByTag(forcetype);
    transform(token.begin(), token.end(), token.begin(), toupper);
    if (token == "-") {
      startmethods.push_back("USER");
      continue;
    }
    if ((*fit)->IsValidMethod(token)) {
      startmethods.push_back(token);
    } 
    else 
    {
        ThrowDataError("Invalid method " + token + " for force " + forcetype);
    }
  }
  forcesumm.SetMethods(forcetype, startmethods);

} /* DoMethod */

//__________________________________________________________

void DataFile::DoStartValues(XmlDB* xmllist, const string& forcetype)
{
  long tokennumber = 0;
  string token;
  unsigned long result;
  DoubleVec1d startvalues;
  const ForceSummary& forcesumm = registry.GetForceSummary();

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;

  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    if (token == "-") {
      startvalues.push_back(0.0);
      continue;
    }
    if (!IsReal(token)) { 
      ThrowDataError("Invalid starting values for force " + forcetype);
    }
    double startval = atof(token.c_str());
    ForceVec::const_iterator fit;
    fit = forcesumm.GetForceByTag(forcetype);
    if ((*fit)->IsValidParameterValue(startval)) {
      startvalues.push_back(startval);
    }
    else ThrowDataError("Invalid starting values for force " + forcetype);
  }

  startparam.SetParametersByTag(forcetype, startvalues);

} /* DoStartValues */

//__________________________________________________________

void DataFile::DoMaxEvents(XmlDB* xmllist, const string& forcetype)
{
  DBElement* dbe = xmllist->Get();
  string content = dbe->content;
  if (IsInteger(content)) {
    long events = atol(content.c_str());
    if (InBounds(events, 0L, LONG_MAX)) {
      registry.GetForceSummary().SetMaxEvents(forcetype, events);
      return;
    }
  }

  // something failed
  ThrowDataError("Invalid maximum events for force " + forcetype);

} /* DoMaxEvents */

//__________________________________________________________

void DataFile::DoProfiles(XmlDB* xmllist, const string& forcetype)
{
  long tokennumber = 0;
  string token;
  unsigned long result;
  vector<proftype> profiles;

  DBElement* dbe = xmllist->Get();
  string content = dbe->content;

  while (1) {
    result = GetToken(content, token, tokennumber);
    if (result == string::npos) break;
    tokennumber = result;
    if (token == "percentile") profiles.push_back(percentile);
    else if (token == "fixed") profiles.push_back(fix);
    else if (token == "none" || token == "-") profiles.push_back(none);
    else ThrowDataError("Illegal profile type " + token + " for force "
       + forcetype);
  }

  vector<Force*>::iterator fit = registry.GetForceSummary().GetForceByTag(forcetype);
  if (static_cast<long>(profiles.size()) != (*fit)->GetNParams()) {
    ThrowDataError("Inappropriate number of profile types for force " + forcetype);
  }
  (*fit)->SetProfileTypes(profiles);

} /* DoProfiles */

//__________________________________________________________
// Error functions
//__________________________________________________________

void DataFile::ThrowDataError(const string& reason)
{
  errorMessage.append("Data Error: " + reason);
  incorrect_data e(errorMessage);
  throw e;
} /* ThrowDataError */

//__________________________________________________________

void DataFile::ThrowFileError(const string& reason)
{
  errorMessage.append("Data Error: " + reason);
  file_error e(errorMessage);
  throw e;
} /* ThrowFileError */


//__________________________________________________________

void DataFile::ThrowXMLError(const string& reason) 
{
  errorMessage.append("XML Error: " + reason);
  incorrect_xml e(errorMessage);
  throw e;
} /* ThrowXMLError */

//__________________________________________________________

