//$Id: xml.h,v 1.9 2002/06/25 03:11:28 mkkuhner Exp $

#ifndef DATAFILE
#define DATAFILE

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "xmldb.h"
#include "types.h"
#include "individual.h"
#include "errhandling.h"
#include "forceparam.h"
// the following gives us TipData member
#include "datapack.h"  

/******************************************************************
 This class reads the data file, including both molecular data and
 option settings.  It is derived from XMLReader and uses member
 functions and variables of that class to handle the actual mechanics
 of the XML parsing. 

 The tagline vector contains tags indicating the sequence of
 XML tags currently being processed, for error reporting. 

 DEBUG: This class is currently both bloated and buggy; the distinction
 between required and optional arguments is not made in a clean
 fashion, and error checking is not very complete.

 Based on a class by Jim Sloan, rewritten by Mary Kuhner.
*********************************************************************/

class Registry;
class DataPack;
class Region;
class DataModel;

class DataFile : public XMLReader
{
private:

  Registry&   registry;
  DataPack&   datapack;
  Region*     pCurrRegion;
  long        currpopulation;
  long        currindno;
  Individual  currIndividual;
  ForceParameters startparam;
  DataModel*  dlmodel;
  DataModel*  globaldlmodel;
  TipData     tipdata;

  // purposely not implemented, this class is meant to be a singleton
  DataFile();
  DataFile(const DataFile&);
  DataFile& operator=(const DataFile&);

  // main line data reading routines
  void        DoData(XmlDB* xmllist);       
  void        DoRegions(XmlDB* xmllist);    
  void        DoPopulations(XmlDB* xmllist);
  void        DoIndividuals(XmlDB* xmllist);
  void        DoSamples(XmlDB* xmllist);
  void        DoDataBlock(XmlDB* xmllist);

  // auxillary map location information
  void        DoSpacing(XmlDB* xmllist);
  void        DoBlocks(XmlDB* xmllist);
  void        DoMapPosition(XmlDB* xmllist);
  void        DoLength(XmlDB* xmllist);
  void        DoLocations(XmlDB* xmllist);
  void        DoOffset(XmlDB* xmllist);

  // auxiliary data reading routines
  LongVec1d   DoPhase(XmlDB* xmllist);  // DoSamples *must* be called first!
  string      ReadName(XmlDB* xmllist);
  string      Strip(const string& target);

  // main line data-model reading routines
  bool        DoDLModel(XmlDB* xmllist);  // return value is "found one?"
  void        DoF84Model(XmlDB* xmllist);
  void        DoStepwiseModel(XmlDB* xmllist);
  void        DoBrownianModel(XmlDB* xmllist);
  void        DoBaseFreqs(XmlDB* xmllist);
  void        DoTTRatio(XmlDB* xmllist);
  void        DoCategories(XmlDB* xmllist);
  void        DoNumCategories(XmlDB* xmllist);
  void        DoCatRates(XmlDB* xmllist);
  void        DoCatProbs(XmlDB* xmllist);
  void        DoAutoCorr(XmlDB* xmllist);
  void        DoNormalize(XmlDB* xmllist);

  // main line chain parameter reading routines
  void        DoChainParams(XmlDB* xmllist);
  void        DoReplicates(XmlDB* xmllist);
  void        DoHeating(XmlDB* xmllist);
  void        DoTemperatures(XmlDB* xmllist);
  void        DoSwapInterval(XmlDB* xmllist);
  void        DoHeatingstrategy(XmlDB* xmllist);
  void        DoStrategy(XmlDB* xmllist);
  void        DoResimulating(XmlDB* xmllist);
  void        DoHaplotyping(XmlDB* xmllist);
  void        DoChains(XmlDB* xmllist, long chaintype);
  void        DoChainNumber(XmlDB* xmllist, long chaintype);
  void        DoChainSamples(XmlDB* xmllist, long chaintype);
  void        DoChainInterval(XmlDB* xmllist, long chaintype);
  void        DoChainDiscard(XmlDB* xmllist, long chaintype);

  // main line user parameter reading routines
  void        DoUserParams(XmlDB* xmllist);
  void        DoVerbosity(XmlDB* xmllist);
  void        DoProgress(XmlDB* xmllist);
  void        DoEcho(XmlDB* xmllist);
  void        DoPlotSpecs(XmlDB* xmllist);
//  void        DoProfile(XmlDB* xmllist);
  void        DoPosterior(XmlDB* xmllist);
  void        DoRandomSeed(XmlDB* xmllist);
  void        DoParamFileName(XmlDB* xmllist);
  void        DoResultsFileName(XmlDB* xmllist);
  void        DoSummaryFileName(XmlDB* xmllist);

  // main line force parameter reading routines
  void        DoForces(XmlDB* xmllist);
  void        DoForceIfPresent(XmlDB* xmllist, const string& forcetag, const string& forcetype);
  void        DoForce(XmlDB* xmllist, const string& forcetype);
  void        TurnOffForce(const string& forcetype);
  void        DoStartValues(XmlDB* xmllist, const string& forcetype);
  void        DoMethod(XmlDB* xmllist, const string& forcetype);
  void        DoMaxEvents(XmlDB* xmllist, const string& forcetype);
  void        DoProfiles(XmlDB* xmllist, const string& forcetype);

  // error handling mechanism
  vector<TagLine> taglines;   

  void        SetTag(const string& tag);
  void        CheckTags(const string& tag);
  void        ClearTag();
  void        CheckContent(XmlDB* xmllist);
  void        ThrowDataError(const string& reason);
  void        ThrowFileError(const string& reason);
  void        ThrowXMLError(const string& reason);

public:

              DataFile(Registry& reg);
              ~DataFile();
  bool        ReadFile(const string& filename);

};

#endif
