// $Id: filereader.h,v 1.2 2002/06/25 03:11:27 mkkuhner Exp $

#ifndef _FILEREADER
#define _FILEREADER

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <iostream>
#include <fstream>
#include <string.h>
#include <string>

using namespace::std;

#define BUFFER_SIZE 32768

class FileReader
{
  protected:
    char *scanbuffer;
    char *readbuffer;
    char *readend;
    char *cursor;

    long bufferSize;
    long base;

    ifstream file;

  public:
                 FileReader();
    virtual      ~FileReader();
#if 0
            bool Open(const char*);
#endif
            bool Open(const string&);
            void Close();
    virtual void Read();
    virtual void Parse() = 0;
};

#endif

