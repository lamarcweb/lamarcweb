// $Id: xmldb.cpp,v 1.7 2002/06/26 19:11:57 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcdebug.h"
#include "xmldb.h"
#include "stringx.h"
// DEBUG needed only for debug statements
#include <iostream>
#include <assert.h>

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

DBElement::DBElement(long lineNo)
{
  tag        = "";
  attributes = "";
  content    = "";
  lineNumber = lineNo;
}

//__________________________________________________________________

bool DBElement::GetAttribute(const string& key, string &value)
{
  string token;
  unsigned long posn;

  posn = attributes.find(key);
  if (posn == string::npos)
    return false;

  posn = SkipToken(attributes, posn);
  if (posn == string::npos)
    return false;

  posn = GetToken(attributes, token, posn);
  if (posn == string::npos || token != "=")
    return false;

  posn = GetToken(attributes, token, posn);
  if (posn == string::npos || (token != "\'" && token != "\""))
    return false;

  posn = GetToken(attributes, value, posn, token);
  if (posn == string::npos)
    return false;

  return true;
}

//_______________________________________________________________________

long DBElement::GetLineNumber()
{
    return lineNumber;
}

//_______________________________________________________________________

string DBElement::GetTag()
{
    return tag;
}

//_______________________________________________________________________
//_______________________________________________________________________

XmlDB::~XmlDB()
{
 // Destroy();
 DeleteContents();
}

//__________________________________________________________________

bool XmlDB::FindTag(const string &src)
{
  for ( ; cursor->next != NULL; cursor = cursor->next)
  {
    if (cursor->next->pData->tag == src)
      return true;
  }

  return false;
}

//__________________________________________________________________

bool XmlDB::FindFirstTag(const string &src)
{
  cursor = head;
  return FindTag(src);
}

//__________________________________________________________________

bool XmlDB::FindNextTag(const string &src)
{
  if (cursor->next == NULL)
    return false;

  cursor = cursor->next;
  return FindTag(src);
}

//_________________________________________________________________

XmlDB* XmlDB::GetDBChild()
{
  
    XmlDB* child = dynamic_cast<XmlDB*>(GetChild());
//    assert(child);  No, there may really not be one!
    return child;
//  return static_cast<XmlDB*>(TreeList<DBElement>::GetChild());

} /* GetDBChild */

//_______________________________________________________________________________________
//_______________________________________________________________________________________

XMLReader::XMLReader()
{
  xmlDB        = NULL;
  entityRefs   = "&&amp;<&lt;>&gt;\"&quot;'&apos;";
  status       = LOOKING_FOR_TAG;
  startTag     = false;
  lineNumber   = 1;
  errorMessage = "";
}

//__________________________________________________________________

XMLReader::XMLReader(XmlDB *xml)
{
  xmlDB        = xml;
  entityRefs   = "&&amp;<&lt;>&gt;\"&quot;'&apos;";
  status       = LOOKING_FOR_TAG;
  startTag     = false;
  lineNumber   = 1;
  errorMessage = "";
}

//__________________________________________________________________

void XMLReader::SetDataBase(XmlDB *xml)
{
  delete xmlDB;
  xmlDB = xml;
}

//__________________________________________________________________

bool XMLReader::Read(const string& filename)
{
  if (Open(filename))
  {
    FileReader::Read();
    return true;
  }

  return false;
}

//__________________________________________________________________

void XMLReader::Parse()
{
  while (cursor < readend)
  {
    switch(status)
    {
      case LOOKING_FOR_TAG:
        SkipText();
        continue;

      case IN_TAG:
        ReadTag();
        continue;

      case IN_CONTENT:
        ReadContent();
        continue;

      case IN_COMMENT:
        ReadComment();
    }
  }
}

//__________________________________________________________________

void XMLReader::SkipText()
{
  if (ReadText('<', false))
    status = IN_TAG;
}

//__________________________________________________________________

void XMLReader::ReadTag()
{
  DBElement *dbe;
  unsigned long n;

  // Check for comment
  if (*cursor == '!' && *(cursor+1) == '-' && *(cursor+2) == '-')
  {
    cursor += 3;
    ReadComment();
    return;
  }

  if (ReadText('>', true))
  {
    if (StringCompare(text, "/", 0, 1))
    {
      text.erase(0, 1);
      if (tagStack.empty())
      {
        complainMismatchedTag(text);
      }
      string t = *(tagStack.back());
      tagStack.pop_back();
      if (t.compare(text))
      {
        complainMismatchedTag(text);
      }

      if (!startTag) {
        xmlDB = dynamic_cast<XmlDB*>(xmlDB->GetParent());
        assert(xmlDB != NULL);
//        xmlDB = (XmlDB*)xmlDB->GetParent();
      }

      status = LOOKING_FOR_TAG;
    }

    else
    {
      dbe = new DBElement(lineNumber);         // New tag

      n = text.size()-1;
      if (StringCompare(text, "/", n, 1))      // Empty tag
      {
        /* -- don't erase the text because you may have a tag of form <tag key="value"/>
        text.erase(n);
        */
        status = LOOKING_FOR_TAG;
      }

      else
        status = IN_CONTENT;

#if 0
      if ((n = text.find(" ", 1)) != -1)
#endif
      if ((n = text.find(" ", 1)) != string::npos)
      {
        dbe->tag = text.substr(0, n);
        dbe->attributes = text.substr(n+1);
      }

      else
        dbe->tag = text;

      if (startTag) {
        XmlDB* newxmlDB = new XmlDB;
//        xmlDB = (XmlDB*)xmlDB->MakeChild();
        xmlDB->MakeChild(newxmlDB);
        xmlDB = newxmlDB;
      }

      xmlDB->Append(dbe);

      if (status != LOOKING_FOR_TAG)
        tagStack.push_back(&dbe->tag);
    }

    if (status != LOOKING_FOR_TAG)
      startTag = true;

    else
      startTag = false;

    text.erase();
  }
}

//__________________________________________________________________

void XMLReader::ReadContent()
{
  if (ReadText('<', true))
  {
    if (text.size())
    {
      DBElement *dbe = xmlDB->Get();
      dbe->content = text;
      text.erase();
    }

    status = IN_TAG;
  }
}

//__________________________________________________________________

bool XMLReader::ReadText(char delimiter, bool save)
{
  long posn;
  char *start;

  for (start = cursor; *cursor; cursor++)
  {
    if (*cursor == delimiter)
      break;

    if (*cursor == '\n')
      lineNumber++;
  }

  posn = cursor - start;
  if (posn)
  {
    if (save)
      text.append(start, 0, posn);

    if (!*cursor)
      return false;

    unsigned long n1 = text.find("&");
    if (n1 != string::npos)
    {
      string seg, ts;
      unsigned long n2 = 0;
      unsigned long n3 = 0;

      n1 = 0;
      while ((n2 = text.find("&", n1)) != string::npos)
      {
        seg = ts.substr(n1, n2);
        ts.append(seg);
        n1 = n2;
        if ((n2 = text.find(";", n1)) == string::npos)
        {
          errorMessage.append("Invalid entity reference in line ");
          DoError();
        }

        seg = text.substr(n1, n2);
        if ((n3 = entityRefs.find(seg, n3)) == string::npos)
        {
          errorMessage.append("Invalid entity reference in line ");
          DoError();
        }

        n3--;
        seg = entityRefs.substr(n3, n3);
        ts.append(seg);
        n1 = n2 + 1;
      }

      seg = text.substr(n1);
      ts.append(text);
      text = ts;
    }
  }

  cursor++;
  return true;
}

//__________________________________________________________________

void XMLReader::ReadComment()
{
  for ( ; *cursor; cursor++)
  {
    if (*cursor == '-' && *(cursor+1) == '-' && *(cursor+2) == '>')
    {
      cursor += 3;
      break;
    }

    if (*cursor == '\n')
      lineNumber++;
  }

  if (*cursor)
    status = LOOKING_FOR_TAG;

  else
    status = IN_COMMENT;
}

//__________________________________________________________________

void XMLReader::DoError()
{
  errorMessage.append(ToString(lineNumber));
  errorMessage.append(".");
  incorrect_data e(errorMessage);
  throw e;
}

void XMLReader::complainMismatchedTag(string tagText)
{
    errorMessage.append("Mismatched </");
    errorMessage.append(tagText);
    errorMessage.append("> tag in line ");
    DoError();
}

//_______________________________________________________________________________________
//_______________________________________________________________________________________

#if 0
bool XMLWriter::Open(const char *fileName)
#endif
bool XMLWriter::Open(const string& fileName)
{
  file.open(fileName.c_str());
  if (file)
    return true;

  return false;
}

//__________________________________________________________________

void XMLWriter::Close()
{
  file.close();
}

//__________________________________________________________________

void XMLWriter::Write(XmlDB *xmlDB)
{
/*
  DBElement *dbe;
  Str tag, text;
  Str *pTag;
  bool newlist;
  int level, m, n;

  for (xmlDB->Begin(); xmlDB->InRange(); xmlDB->Next())
  {
    level = xmlDB->Level();

    if (level > m)
    {
      for ( ; m < level; level--)
      {
        for (n = 1; n < level; n++)
          file << "  ";

        pTag = tagStack.Pop();
        file << "</" << *pTag << '>' << endl;
      }
    }

    level = m;
    for (n = 0; n < level; n++)
      file << "  ";

    dbe = xmlDB->Get();
    tag = dbe->tag;
    if (newlist)
    {
      pTag = new Str(tag);
      tagStack.Push(pTag);
    }

    file << '<' << tag;
    text = dbe->attributes;
    if (text.Length())
      file << ' ' << text;

    text = dbe->content;
    if (text.Length() || newlist)
    {
      file << '>';

      if (text.Length())
      {
        if (text.Contains('\n'))
          file << '\n';

        file << text;
      }

      if (!newlist)
        file << "</" << tag << '>';

      file << endl;
    }

    else
      file << "/>" << endl;
  }

  for ( ; level; level--)
  {
    for (n = 1; n < level; n++)
      file << "  ";

    pTag = tagStack.Pop();
    file << "</" << *pTag << '>' << endl;
  }
*/
}

//__________________________________________________________________

bool XMLWriter::Write(XmlDB *xmlDB, const string& filename)
{
  if (Open(filename))
  {
    Write(xmlDB);
    return true;
  }

  return false;
}

