// $Id: xmldb.h,v 1.5 2002/06/25 03:11:28 mkkuhner Exp $

#ifndef _XMLDB
#define _XMLDB

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <ctype.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "stringx.h"
#include "treelist.h"
#include "filereader.h"
#include "errhandling.h"

using std::string;
using std::vector;


class DBElement
{
  public:
    string tag;
    string attributes;
    string content;
    long lineNumber;

    DBElement(long lineNumber);
    bool GetAttribute(const string&, string&); 
    string GetTag();
    long GetLineNumber();
};

//_____________________________________________________________________

class XmlDB : public TreeList<DBElement>
{
  public:
    virtual  ~XmlDB();

    bool FindTag(const string&);
    bool FindFirstTag(const string&);
    bool FindNextTag(const string&);

    // DEBUG this function was added by Mary to encapsulate a
    // worrisome static_cast.  Eventually we should eliminate the
    // static_cast and this function then goes away.
    XmlDB* GetDBChild();
};

//_____________________________________________________________________

enum xmlReaderStatus { LOOKING_FOR_TAG, IN_TAG , IN_CONTENT, IN_COMMENT };

class XMLReader : public FileReader
{
  protected:
    XmlDB           *xmlDB;
    vector<string*>  tagStack;
    string           text;
    xmlReaderStatus  status;
    bool             startTag;
    string           entityRefs;
    long             lineNumber;
    string           errorMessage;

    void DoError();

  public:
         XMLReader();
    virtual ~XMLReader() {};
         XMLReader(XmlDB*);
    void SetDataBase(XmlDB*);
    bool Read(const string&);
    void Parse();
    void SkipText();
    void ReadTag();
    void ReadContent();
    bool ReadText(char, bool);
    bool IsComment();
    void ReadComment();
  protected:
    void complainMismatchedTag(string);

};

//_____________________________________________________________________

class XMLWriter
{
    vector<string*> tagStack;
    string text;

    string entityRefs;

    ofstream file;

  public:
    bool Open(const string&);
    void Close();
    void Write(XmlDB*);
    bool Write(XmlDB*, const string&);
};

#endif

