// $Id: filereader.cpp,v 1.2 2002/06/25 03:11:27 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "filereader.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

FileReader::FileReader()
{
  bufferSize = BUFFER_SIZE;
  scanbuffer = new char [2*bufferSize + 1];
  readbuffer = NULL;
  readend    = NULL;
  cursor     = NULL;
}

//_______________________________________________________________________

FileReader::~FileReader()
{
  delete [] scanbuffer;
}

//_______________________________________________________________________

bool FileReader::Open(const string& filename)
{
  file.open(filename.c_str());
  if (file)
    return true;

  return false;
}

//_______________________________________________________________________

void FileReader::Close()
{
  file.close();
}

//_______________________________________________________________________

void FileReader::Read()
{
  int  count;

  readbuffer = scanbuffer;
  file.read(readbuffer, bufferSize);
  cursor     = scanbuffer;
  count      = file.gcount();
  base       = 1;

  if (count == bufferSize)
  {
    readbuffer = scanbuffer + bufferSize;
    readend = readbuffer;
    *(readbuffer+bufferSize) = '\0';
    file.read(readbuffer, bufferSize);
    count = file.gcount();

    while (count == bufferSize)
    {
      Parse();
      memcpy(scanbuffer, readbuffer, count);
      cursor -= bufferSize;
      base   += bufferSize;
      file.read(readbuffer, bufferSize);
      count = file.gcount();
    }
  }

  readend  = readbuffer + count;
  *readend = '\0';
  Parse();
}

