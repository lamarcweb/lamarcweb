#ifndef _MAXIMIZER_CLASS_
#define  _MAXIMIZER_CLASS_
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// Maximizer Class ----------------------------------------------
//   $Id: maximizer.h,v 1.3 2002/06/26 19:11:54 lamarc Exp $
//   
//   Maximizer for likelihood function (see likelihood::Calculate()) 
//   using the Broyden-Fletcher-Shanno-Goldfarb method
//   other methods (e.g. Newton-Raphson) can be easily incorporated 
//   by adding another Maximizer::Calculate()
//
//
//   calculates the maximum of the likelihood function and returns
//   the parameters as a vector  at the ML.
//
//   Call sequence and existence through run
//      foreach(locus) 
//      {
//         likelihood = SinglePostLike(forces)
//         Maximizer(likelihood) 
//         foreach(replicate) [independent replicates, if any]
//         {
//             foreach(single_chains)
//                Calculate(data) uses data and MLE
//             foreach(long_chain)
//                Calculate(data)
//          }
//         ~Maximizer()
//         likelihood = ReplicatePostLike(forces)
//         Maximizer(likelihood)
//         ~Maximizer() 
//      }
//      if(locus>1)
//      { 
//         likelihood = RegionPostLike(forces)
//         Maximizer(likelihood) 
//         ~Maximizer()
//         likelihood = GammaRegionPostLike(forces)
//         Maximizer(likelihood) 
//         ~Maximizer()
//       }
//   STILL TODO 
//     Line() is not yet implemented
//     
//
#include <vector>
#include <algorithm>
#include <functional>
#include <numeric>
#include <math.h>
#include <iostream>

#include "definitions.h"
#include "vectorx.h"
#include "likelihood.h"

using
  std::vector;

#ifdef MEMDEBUG
#include "memdebug.h"
#endif

// declarations --------------------------------------------
class
  Maximizer
{
public:
  Maximizer (long thisNparam);
  ~Maximizer ();
  void    Setup (PostLike * thispostlike);
  double  Calculate (DoubleVec1d & thisparam);
  DoubleVec1d  GetParameters() { return param; };
  double GetLastLikelihood() { return lastlikelihood;};
  PostLike *LikePtr ()
  {
    return likelihood;
  };

  PostLike *  likelihood;			// analyzer needs access to this?
  double GetLastNorm();
private:
  Maximizer ()
  {
  };
  double Line_search (DoubleVec1d & dv, DoubleVec1d & gxv, 
		      DoubleVec1d & thisparam, DoubleVec1d & thislparam, 
		      DoubleVec1d & oldparam, double & oldL);
  double CalcDirGrad();
  double lastnormd;

protected:
  double lastlikelihood;
  long
    nparam;
  long
    nloci;
  long
    nrep;
  double
    normd;			// stop criterium
  DoubleVec1d    param;			// parameters
  DoubleVec1d    lparam;			// log parameters
  DoubleVec1d    oldparam;			// parameters
  DoubleVec1d    gradient;			// gradient
  DoubleVec1d    oldgradient;		// old gradient
  DoubleVec1d
    paramdelta;			// parameter difference
  DoubleVec1d
    gradientdelta;		// first derivative difference
  DoubleVec1d
    direction;			// direction
  vector < DoubleVec1d >    second; // approx second derivative

  // MARY  -- temporary storage, kept as class variables for speed
  DoubleVec1d newparam;
  DoubleVec1d newlparam;
  DoubleVec1d temp;
  DoubleVec2d dd;

  double
  Norm (const DoubleVec1d&d);	//calculate stop criterium

  void
  SetParam (DoubleVec1d&thisparam, DoubleVec1d&thislparam, const DoubleVec1d&oldparam, const DoubleVec1d&oldlparam, const double &lambda);	// calculates the new parameter

#if 0
// this version is not working yet; it's meant for growth
  void
  SetParam (DoubleVec1d&thisparam, DoubleVec1d&thislparam, const DoubleVec1d&oldparam, const DoubleVec1d&oldlparam, const long &lambda, const char &type);	// version for log and non-log settings
#endif

  void
  ResetSecond ();		//resets the second derivative matrix
  void
  CalcDelta (const DoubleVec1d&one, const DoubleVec1d&two, DoubleVec1d&result);	//difference
  void
  CalcSecond ();		// calculate approximative second derivatives
  void
  CalcDirection ();		// calculate the direction of change 
  double
  Line (DoubleVec1d & thisparam);	// Line() functions
  double
  Line (DoubleVec1d &thisparam, double a, double b, double c);
  double
  Psi (DoubleVec1d&thisparam, DoubleVec1d&thislparam,
       const DoubleVec1d&oldparam, double &lambda);

  // template <class T> vector < vector <T> > Matrix(long & n, long & m, T& initial = 0.0);
};

void 
replace_with (int mode, double *a, double *b, double *c, double m,
	      double *la, double *lb, double *lc, double ll);
	      
double
quadratic_lamda (double lamda,
		 double a, double b, double c, double la, double lb, double lc);
		 
#endif








