// Broyden-Fletcher-Shanno maximizer implementation
//
// started 2000 Peter Beerli
// 
// $Id: maximizer.cpp,v 1.8 2002/06/26 19:13:10 mkkuhner Exp $
//
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

//#undef __VECTORX_H_
#include "lamarcdebug.h"
#include "vectorx.h"
#include "maximizer.h"
#include <assert.h>

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

#define TWO -2 
#define NEWLIKESTART (-(DBL_MAX - 1.0));
using namespace std;

#define NTRIALS 1000
#define BIGEPSILON 0.0001
#define MIN3(a,b,c) (((a)<(b))&&((a)<(c)) ? (a) : (((b)<(c)) ? (b) : (c)))
#define MAX3(a,b,c) (((a)>(b))&&((a)>(c)) ? (a) : (((b)>(c)) ? (b) : (c)))
#define LAMBDA_ 1
#define M_      0


const double  LAMBDA_EPSILON = 10. * DBL_EPSILON;

void
replace_with (int mode, double *a, double *b, double *c, double m,
	      double *la, double *lb, double *lc, double ll)
{
  double ma, mb, mc;
  if (mode == LAMBDA_)
    {
      ma = *la;
      mb = *lb;
      mc = *lc;
    }
  else
    {
      ma = ll - *la;
      mb = ll - *lb;
      mc = ll - *lc;
    }
  if (ma > mb)
    {
      if (ma > mc)
	{
	  *a = m;
	  *la = ll;
	}
      else
	{
	  *c = m;
	  *lc = ll;
	}
    }
  else
    {
      if (mb > mc)
	{
	  *b = m;
	  *lb = ll;
	}
      else
	{
	  *c = m;
	  *lc = ll;
	}
    }
}
/*
double
psil (double (*func) (double lamda, nr_fmt * nr),
double a, double b, nr_fmt * nr, double *gxv, double *dv, double oldL,
      double *val1, double *val2)
{
  long i;
  long nn = nr->partsize;
  double value = 0.0;

  if (a == 0.0 && b == 0)
    {
      for (i = 0; i < nn; i++)
	{
	  value += dv[i] // gxv[i] ;
	}
      *val1 = -oldL;
      *val2 = -oldL;
      return value;
    }
  else
    {
      if (a == 0)
	value = (((*val2) = (*func) (b, nr)) - ((*val1) = -oldL)) / b;
      else
	{
	  if (b == 0)
	    value = (((*val2) = -oldL) - ((*val1) = (*func) (a, nr))) / (-a);
	  else
	    value =
	      (((*val2) = (*func) (b, nr)) -
	       ((*val1) = (*func) (a, nr))) / (b - a);
	}
      return value;
    }
}
*/
double
quadratic_lamda (double lamda,
		 double a, double b, double c, double la, double lb, double lc)
{
  double alpha, beta, gama;
  double aa, bb, cc;
  aa = a * a;
  bb = b * b;
  cc = c * c;
  alpha =
    ((c - b) * la + (a - c) * lb +
     (b - a) * lc) / ((b - a) * (c - a) * (c - b));
  beta =
    ((cc - bb) * la + (aa - cc) * lb +
     (bb - aa) * lc) / ((b - a) * (b - c) * (c - a));
  gama =
    (b * cc * la - bb * c * la + aa * c * lb - a * cc * lb - aa * b * lc +
     a * bb * lc) / ((b - a) * (c - a) * (c - b));


  return alpha * lamda * lamda + beta * lamda + gama;
}

// maximizer class -------------------------------------------------
// 
// maximizer initialization, depending on 
Maximizer::Maximizer (long thisNparam)
{
  likelihood = NULL;
  long nparam = thisNparam;
  double zero = 0.0;
  param = CreateVec1d (nparam, zero);	// parameters to maximize
  lparam = CreateVec1d (nparam, zero);	// parameters to maximize
  oldparam = CreateVec1d (nparam, zero);	// parameters
  gradient = CreateVec1d (nparam, zero);	// first derivatives
  oldgradient = CreateVec1d (nparam, zero);	// old first derivatives
  paramdelta = CreateVec1d (nparam, zero);	// parameter difference
  gradientdelta = CreateVec1d (nparam, zero);	// first derivative difference
  direction = CreateVec1d (nparam, zero);	// direction to jump uphill
  second = CreateVec2d (nparam, nparam, zero);	// approx second derivative

  newparam = CreateVec1d (nparam, zero);        // temporary storage
  newlparam = CreateVec1d (nparam, zero);       // for speeding up
  temp = CreateVec1d (nparam, zero);
  dd = CreateVec2d (nparam, nparam, zero);
}

Maximizer::~Maximizer ()
{
}

void
Maximizer::Setup (PostLike * thispostlike)
{
  likelihood = thispostlike;
}

// find optimum using  Broyden-Fletcher-Goldfarb-Shanno
// mechanism
// returns log(likelihood)
// replaces param with the result param
double
Maximizer::Calculate (vector < double >&thisparam)
{
  copy (thisparam.begin (), thisparam.end (), param.begin ());
  lparam = LogVec0 (param);
  double oldlike = likelihood->Calculate (param, lparam);
  double lambda;
  double newlike;
  double normd = DBL_MAX;
  double normd20 = 0;		//start different to normd
  ResetSecond ();		//initialize the second derivative matrix;
  oldparam = lparam;
  likelihood->DCalculate (param, gradient);
  direction = gradient;
  oldgradient = gradient;

  long i = 0;
  long count = 0;
  while (normd > NORMEPSILON && count++ < 1000)
    {
      normd = Norm (gradient);
      //      lambda = Line (param, -1., 0.1, 1.);	//bad version
      lambda = Line_search(direction, gradient, 
			   param, lparam, 
			   oldparam, oldlike);
      newlike = NEWLIKESTART;
      i = 0;
      while ((newlike < oldlike || isnan (newlike)) &&
	     fabs (lambda) > LAMBDA_EPSILON)
	{
	  SetParam (newparam, newlparam, param, lparam, lambda);
	  newlike = likelihood->Calculate (newparam, newlparam);
	  //DEBUG START
	  //	  	    cout << "norm=" << normd << " oldlike=" << oldlike << " newlike=" <<
	  //      newlike << " lambda=" << lambda << " i=" << i++ << endl;
          //DEBUG END
	  lambda /= TWO;
	}

#ifdef MAC
      eventloop();  // Mac OS 9 system action check
#endif

      if (count % 20 == 0)
	{
	  if (fabs (normd - normd20) < NORMEPSILON)
	    lambda = 0.0;
	  else
	    normd20 = normd;
	}

      if (fabs (lambda) > LAMBDA_EPSILON && (fabs (oldlike - newlike) > 0.0))
	{
          newparam.swap(param);
          newlparam.swap(lparam);
	  oldlike = newlike;
	  newlike = NEWLIKESTART;
	}
      else
	{
	  ResetSecond ();
          gradient.swap(direction);
	  continue;
	}
      likelihood->DCalculate (param, gradient);

      CalcDelta (lparam, oldparam, paramdelta);
      CalcDelta (gradient, oldgradient, gradientdelta);

      CalcSecond ();
      CalcDirection ();

      copy (gradient.begin (), gradient.end (), oldgradient.begin ());
      copy (lparam.begin (), lparam.end (), oldparam.begin ());

      // NO!!! gradient.swap(oldgradient); this destroys gradient
      // NO!!! lparam.swap(oldparam);  this destroys lparam for next cycle

    }
  lastnormd = normd;
  lastlikelihood = oldlike;
  return oldlike;
}

// calculates the norm of the first derivative,
// sqrt(sum(x**2)) 
double
Maximizer::Norm (const DoubleVec1d & d)
{
  lastnormd = sqrt (inner_product (d.begin (), d.end (), d.begin (), 0.0));
  return lastnormd;
}

double Maximizer::GetLastNorm()
{
  return lastnormd;
}

double
Maximizer::Psi (DoubleVec1d & thisparam,
		DoubleVec1d & thislparam,
		const DoubleVec1d & oldparam, double &lambda)
{
  SetParam (thisparam, thislparam, param, oldparam, lambda);
  return -likelihood->Calculate (thisparam, thislparam);
}
/*
// line search
double Maximizer::Line(DoubleVec1d thisparam)
{
  bool done=false;
  double thislambda;
  double theta;
  DoubleVec1d lineparam(thisparam.size());
  double a = 0;
  double b = 0;
  double c = 1.;
  double la = Psi(lineparam, oldparam, a);
  double lb = la;
  double lc = Psi(lineparam, oldparam, c);


  while(!done)
    {
      if(mPsi(lineparam,a,b,c)>0)
	{
	  theta = (double temp=mPsi(lineparam,a,b))/(temp-mPsi(lineparam,b,c));
	  lambda_ = 0.5 ((a+b)*(1-theta) + (b+c)* theta);
	  if(lambda_ >= upper_bound)
	    {
	      Replace_furthest(a,b,c,upper_bound);
	      continue;
	    }
	  lambda_ = Psi(lineparam,oldparam,lambda_);
	  
	}
      else
	{
	  Replace_furthest(a,b,c,upper_bound);
	  continue;
	}
    } // while not done
  return lambda_;
} 

*/

// line searcher
// finds the maximum in a direction
// this should be replaced with something more efficient.
#define PP 0.61803399
#define QQ 0.38196601
#define MOVE3(a,b,c,d) (a)=(b);(b)=(c);(c)=(d)
double
Maximizer::Line (DoubleVec1d & thisparam, double a, double b, double c)
{
  DoubleVec1d lineparam = thisparam;
  DoubleVec1d llineparam;
  llineparam = LogVec0 (lineparam);
  /* a < b < c AND psia > psib < psic */
#if 0
  assert (a < b);
  assert (b < c);
  assert (Psi (lineparam, llineparam, oldparam, a) >
	  Psi (lineparam, llineparam, oldparam, b));
  assert (Psi (lineparam, llineparam, oldparam, c) >
	  Psi (lineparam, llineparam, oldparam, b));
#endif
  double d, psib, psic;
  d = c;
  if (fabs (c - b) > fabs (b - a))
    {
      c = b + QQ * (c - b);
    }
  else
    {
      c = b;
      b = b - QQ * (b - a);
    }
  psib = Psi (lineparam, llineparam, oldparam, b);
  psic = Psi (lineparam, llineparam, oldparam, c);
  while (fabs (d - a) > NORMEPSILON * (fabs (b) + fabs (c)))
    {
      if (psic < psib)
	{
	  MOVE3 (a, b, c, PP * b + QQ * d);
	  psib = psic;
	  psic = Psi (lineparam, llineparam, oldparam, c);
	}
      else
	{
	  MOVE3 (d, c, b, PP * c + QQ * a);
	  psic = psib;
	  psib = Psi (lineparam, llineparam, oldparam, b);
	}
    }
  if (psib < psic)
    {
      return b;
    }
  else
    {
      return c;
    }
}



// Sets parameters for maximizer trial cycle
// exists in two version (4 and 3 parameters)
// for standard and for Log-param-derivatives
// (3 parameters) new_param = old_param * exp(-lamda * direction)
void
Maximizer::SetParam (DoubleVec1d & thisparam,
		     DoubleVec1d & thislparam,
		     const DoubleVec1d & oldparam,
		     const DoubleVec1d & oldlparam, const double &lambda)
{
  DoubleVec1d::iterator p;
  DoubleVec1d::iterator lp;
  DoubleVec1d::const_iterator op;
  DoubleVec1d::const_iterator olp;
  DoubleVec1d::const_iterator d;
  for (p = thisparam.begin (),
       lp = thislparam.begin (),
       op = oldparam.begin (),
       olp = oldlparam.begin (),
       d = direction.begin ();
       p != thisparam.end (); ++p, ++lp, ++op, ++olp, ++d)
    {
      if (*op > 0.0)
	{
	  (*lp) = (*olp) - lambda * (*d);
	  if (*lp < EXPMIN)
	    (*p) = 0.0;
	  else if (*lp > EXPMAX)
	    (*p) = DBL_BIG;
	  else
	    (*p) = exp (*lp);
	  if (*p < DBL_EPSILON)
	    *p = DBL_EPSILON;
	}
    }
}

#if 0
// WARNING DEBUG
// First draft of a version that can handle growth, but not
// functional yet (handling of variable lp is wrong).

// (4 parameter) case type in
//       'l') new_param = old_param * exp(-lamda * direction)
//       *)   new_param = old_param - lamda * direction
void
Maximizer::SetParam (DoubleVec1d & thisparam,
		     DoubleVec1d & thislparam,
		     const DoubleVec1d & oldparam,
		     const DoubleVec1d & oldlparam,
		     const long &lambda, const char &type)
{
  DoubleVec1d::iterator p;
  DoubleVec1d::iterator lp;
  DoubleVec1d::const_iterator olp;
  DoubleVec1d::const_iterator d;

  if (type != 'l')
    {
      for (p = thisparam.begin (), olp = oldlparam.begin (), d =
	   direction.begin (); d != direction.end (); ++p, ++olp, ++d)
	{
	  (*p) = (*olp) + lambda * (*d);
	  (*lp) = log (*p);
	}
    }
  else
    {
      for (p = thisparam.begin (), olp = oldlparam.begin (), d =
	   direction.begin (); d != direction.end (); ++p, ++olp, ++d)
	{
	  (*lp) = (*olp) - lambda * (*d);
	  (*p) = exp (*lp);
	}
    }
}
#endif

// calculates differences between two arrays
// result = one - two
void
Maximizer::CalcDelta (const DoubleVec1d & one,
		      const DoubleVec1d & two, DoubleVec1d & result)
{
  transform (one.begin (), one.end (), two.begin (),
	     result.begin (), minus < double >());
}

// calculates the direction for the Broyden-Fletcher-Shanno algorithm
// direction = second  .  gradient
void
Maximizer::CalcDirection ()
{
  DoubleVec1d::iterator dir;
  DoubleVec2d::iterator h;
  for (dir = direction.begin (), h = second.begin ();
       dir != direction.end (); dir++, h++)
    (*dir) =
      inner_product ((*h).begin (), (*h).end (), gradient.begin (), 0.0);
}

// updates approximative second derivative matrix
void
Maximizer::CalcSecond ()
{
  long i, j, k;
  long n = paramdelta.size ();
  double t, dtg;
//  DoubleVec1d temp;
  DoubleVec2d::iterator h;
  DoubleVec1d::iterator tt;
//  DoubleVec2d dd;

//  temp = CreateVec1d (n, 0.0);
//  dd = CreateVec2d (n, n, 0.0);

  // paramdelta^T . gradientdelta
  dtg = inner_product (paramdelta.begin (), paramdelta.end (),
		       gradientdelta.begin (), 0.0);
  if (dtg != 0)
    dtg = 1. / dtg;
  else
    {
      ResetSecond ();
      return;
    }
  // temp = gradientdelta^T . second 
  for (tt = temp.begin (), h = second.begin (); tt != temp.end (); tt++, h++)
    (*tt) = inner_product (gradientdelta.begin (), gradientdelta.end (),
			   (*h).begin (), 0.0);
  // t = temp . gradientdelta
  t = inner_product (temp.begin (), temp.end (), gradientdelta.begin (), 0.0);
  // t = (1 + (gradientdelta^T . second . gradientdelta) * dtg) * dtg 
  t = (1. + t * dtg) * dtg;
  // paramdelta . gradientdelta^T . second
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++) {
      dd[i][j] = 0.0;
      for (k = 0; k < n; k++)
	dd[i][j] += paramdelta[i] * gradientdelta[k] * second[k][j];
    }

  // temp = second . gradientdelta
  for (tt = temp.begin (), h = second.begin (); tt != temp.end (); tt++, h++)
    (*tt) = inner_product ((*h).begin (), (*h).end (),
			   gradientdelta.begin (), 0.0);
  // second_new = second + paramdelta . paramdelta^T t 
  //                 - (dd + temp*gradientdelta^T) 
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      second[i][j] += paramdelta[i] * paramdelta[j] * t
	- (dd[i][j] + temp[i] * paramdelta[j]) * dtg;

}

void
Maximizer::ResetSecond ()
{
  unsigned long i;
  unsigned long j;
  unsigned long nsecond = second.size ();	//second derivatives is square
  for (i = 0; i < nsecond; ++i)
    {
      second[i][i] = 1.0;
      for (j = 0; j < i; ++j)
	{
	  second[i][j] = 0.0;
	  second[j][i] = 0.0;
	}
    }
}


/*
 line_search returns LAMBDA (how far to jump in the search direction)
   needed in the the multilocus broyden-fletcher-shanno maximizer

   DV    search direction
   GXV   first derivatives of function to minimize
   FUNC  the function to minimize
   NR    all additional variables needed to calculate FUNC
   OLDL  -log(likelihood) of FUNC with LAMBDA=0 (previously calculated)

   needs functions: psil, replace_with, quadratic_lamda
*/ 
double 
Maximizer::Line_search (DoubleVec1d & dv, DoubleVec1d & gxv, DoubleVec1d & thisparam, 
	     DoubleVec1d & thislparam, DoubleVec1d & oldparam, double & oldL)
{
  long trials = 0;
  double locallamda, ql;
  double a, b, c;
  double psiabc;
  double ll, la, lb, lc;
  double m = 1.0;
  a = 0.0;
  b = 0.000001;
  la = -oldL;
  DoubleVec1d lineparam = thisparam;
  DoubleVec1d llineparam = thislparam;
  lb = Maximizer::Psi (lineparam, llineparam, oldparam, b);
  c = CalcDirGrad();
  lc = Maximizer::Psi (lineparam, llineparam, oldparam, c);
  while (trials++ < NTRIALS)
    {
      locallamda = (c * c * (lb - la) + b * b * (la - lc) +
		    a * a * (lc - lb)) / 
	(2. * (b * la - c * la - a * lb + c * lb + a * lc - b * lc));
      psiabc = ((la - lb)/(-a + b) + (la - lc)/(a - c))/(-b + c);
      if ((psiabc <= 0.0) || (locallamda >= m))
	{
	  if ((a == m || b == m || c == m))
	    return m;
	  else
	    {
	      ll = Maximizer::Psi (lineparam, llineparam, oldparam, m);
	      replace_with (static_cast<long>(m), &a, &b, &c, m, &la, &lb, &lc, ll);
	      continue;
	    }
	}
      ll = Maximizer::Psi (lineparam, llineparam, oldparam, locallamda);
      ql = quadratic_lamda (locallamda, a, b, c, la, lb, lc);
      if ((fabs (ll - MIN3 (la, lb, lc)) <= BIGEPSILON)
	  || (fabs (ll - ql) <= BIGEPSILON))
	return locallamda;
      else
	{
	  /*  if(((a<b<c) || (c<b<a)) && (lb < MIN(la,lc)))
	     return locallamda;
	     if(((b<a<c) || (c<a<b)) && (la < MIN(lb,lc)))
	     return locallamda;
	     if(((a<c<b) || (b<c<a)) && (lc < MIN(la,lb)))
	     return locallamda; */
	  replace_with (LAMBDA_, &a, &b, &c, locallamda, &la, &lb, &lc, ll);
	  m = MAX3 (a, b, c);
	}
    }
// MARY change:  sometimes it *is* a number, but not a happy one, so
// we will return 1 and let the halving-back algorithm deal with it.
//  assert(isnan(locallamda));
//  return locallamda;
    return 1.0;
}

double Maximizer::CalcDirGrad()
{
  return inner_product (direction.begin (),
			direction.end (), gradient.begin (), 0.0);
}




