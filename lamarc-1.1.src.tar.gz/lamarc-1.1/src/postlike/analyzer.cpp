// analyzer.cpp
//
// the analyzer generates
// - profiles  [the code is in profile.cpp] 
// - likelihood surfaces
// - likelihood ratio tests
// 
// Peter Beerli November 2000
// $Id: analyzer.cpp,v 1.7 2002/06/26 19:11:53 lamarc Exp $
//
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/


#include "analyzer.h"
#include "forcesummary.h"

//////////////////////////////////////////////////////////////////
// Instantiate the Analyzer
// using the "last" postlike object, the Analyzer assumes that the 
// Prob(G|parameter_0) are already computed 
// [in likelihood.h:....PostLike::Setup()

Analyzer::Analyzer (ForceSummary &fs, RunReport &rr, const ParamVector& params):
forcesummary (fs),
runreport (rr)
{
  maximizer = NULL;
  profiles.reserve(params.size());
  newparam = CreateVec1d(params.size(), static_cast<double>(0.0));
}

Analyzer::Analyzer (PostLike * thispostlikelihood,
		    ForceSummary& fs,
                    RunReport& rr,
		    vector < double >thisMLEparam):
forcesummary (fs),
runreport (rr)
{
  maximizer = NULL;
  postlikelihood = thispostlikelihood;
  MLEparam = thisMLEparam;
  MLElparam = LogVec0 (MLEparam);
  ParamVector paramvec(fs);
  profiles.reserve(paramvec.size());
  newparam = CreateVec1d(paramvec.size(), static_cast<double>(0.0));
}

Analyzer::Analyzer (Maximizer * thismaximizer,
		    ForceSummary& fs,
                    RunReport& rr,
		    vector < double >thisMLEparam):
forcesummary (fs),
runreport (rr)
{
  maximizer = thismaximizer;
  postlikelihood = maximizer->LikePtr ();
  MLEparam = thisMLEparam;
  MLElparam = LogVec0 (MLEparam);
  ParamVector paramvec(fs);
  profiles.reserve(paramvec.size());
  newparam = CreateVec1d(paramvec.size(), static_cast<double>(0.0));
}

Analyzer::~Analyzer ()
{
};

//////////////////////////////////////////////////////////////////
// Plotting likleihood surfaces
// returns a structure containing all possible plots
// according to ParamStruct *toDolist
// the ouput contains the parameter pair and the plotplane data
vector < PlotStruct > *Analyzer::CalcPlots ()
{
  ParamVector toDolist(forcesummary);
  long
    size =
    toDolist.
    size ();
  size = size * (size - 1);
  vector < PlotStruct > *planes;
  planes = new vector < PlotStruct > (size);

  ParamVector::iterator i;
  ParamVector::iterator j;

  vector < PlotStruct >::iterator plane;

  long    ii, jj;

  ParamVector::const_iterator toDolist_end = toDolist.end();  // optimization

  for (i = toDolist.begin (),
       plane = planes->begin (), ii = 0; i != toDolist_end; ++i, ++ii)
    {
      for (j = i + 1, jj = ii + 1; j != toDolist_end; ++j, ++jj, ++plane)
	{
	  if (i->IsValid() && j->IsValid())
	    {
	      plane->xaxis = &(*i);
	      cout << "x:" << ii << " " << plane->xaxis->GetName();
	      plane->yaxis = &(*j);
	      cout << " y:" << jj << " " << plane->yaxis->GetName() << endl;
	      plane->plane = CalcPlane (*i, ii, *j, jj);
	    }
	  else
	    {
	      // do not do anything the printing routine needs to test 
	      // for plane.empty() for the invalid comparisons.
	    }
	}
    }
  return planes;
}

// Calculates the PostLikelihoods at each gridpoint
DoubleVec2d
  Analyzer::CalcPlane (const Parameter & xx, const long &xpos,
		       const Parameter & yy, const long &ypos)
{
  vector < double >param;
  vector < double >lparam;
  DoubleVec2d plane;
  double xstart = xx.GetPlotStart(), ystart = yy.GetPlotStart(),
         xend = xx.GetPlotEnd(), yend = yy.GetPlotEnd();
  long xpoints = xx.GetPlotPoints(), ypoints = yy.GetPlotPoints();
  plane = CreateVec2d (xpoints, ypoints, 0.0);
  vector < vector < double > >::iterator i;
  vector < double >::iterator j;
  double x, y;
  double xstep = 0.0;
  double ystep = 0.0;

  // WARNING DEBUG Log case will not work....

  if (xx.GetPlotStyle() == linear)
    xstep = (xend - xstart) / xpoints;
  else assert(false);  // no code yet for other plots

  if (yy.GetPlotStyle() == linear)
    ystep = (yend - ystart) / ypoints;
  else assert(false);  // no code yet for other plots

  for (i = plane.begin (), x = xstart;
       i != plane.end (); ++i, x += xstep)
    {
      for (j = i->begin (), y = ystart; j != i->end (); ++j, y += ystep)
	{
	  param = MLEparam;
	  lparam = MLElparam;
	  param[xpos] = x;
	  param[ypos] = y;
	  lparam[xpos] = log (x);
	  lparam[ypos] = log (y);
	  // the likelihood calculator assumes that there
	  // already exist probg and probg0 WITH values
	  // they are precalculated in PostLike::Setup()
	  // are normally present when the CalcPlot is called
	  *j = postlikelihood->Calculate (param, lparam);
	}
    }
  return plane;
}

void
Analyzer::printPlanes (ofstream * of, vector < PlotStruct > *planes)
{
  vector < PlotStruct >::iterator plane;
  *of << "{";
  for (plane = planes->begin (); plane != planes->end (); ++plane)
    {
      printPlane (of, (*plane));
    }
  *of << "}\n";
}

void
Analyzer::printPlane (ofstream * of, PlotStruct & plane)
{
  vector < vector < double > >::iterator x;
  vector < double >::iterator y;

  *of << "{labely=\"" << plane.yaxis->GetName() << "\"},\n{";
  for (x = plane.plane.begin (); x != plane.plane.end (); ++x)
    {
      *of << "{";
      for (y = x->begin (); y != x->end (); ++y)
	{
	  if (y != x->end () - 1)
	    *of << (*y) << ",";
	  else
	    *of << (*y) << "}";
	}
      *of << "\n";
    }
  *of << "}\n";
}



//////////////////////////////////////////////////////////////////
// Likelihood ratio test
//
// several unsolved questions:
// - where are the test parameters, or the teststrings
// - how to present the result
// - calculations of test boundaries
//

#if 0
void LRT()
{



}
#endif

//  double perc_like = h0like - find_chi(df, (percent > 0.5 ? (1. - percent)*2. : percent * 2.))/2.;
long difference(DoubleVec1d param1, DoubleVec1d param2)
{
  DoubleVec1d :: iterator p1;
  DoubleVec1d :: iterator p2;
  assert(param1.size() != param2.size());
  long diff=0;
  for(p1=param1.begin(), p2 = param2.begin(); p1 != param1.end(); p1++, p2++)
    diff += ((p1 == p2) ? 0 : 1 );
  return diff;
}


// worker function for LRT 
LRTStruct Analyzer::LRT(DoubleVec1d h1param)
{
  LRTStruct lrt;
  lrt.h0like = maximizer->Calculate(newparam); 
  newparam = maximizer->GetParameters(); //this is perhaps unnecessary
  //  likelihood.constrain(h1param
  lrt.h1like = maximizer->Calculate(h1param);
  lrt.lr = -2 * (lrt.h1like - lrt.h0like) ;
  lrt.df = difference(newparam, h1param);
  lrt.prob = probchi(lrt.df, lrt.lr);
  // lr.probb = probchi(df, testchi, BOUNDARY); <to come>
  return lrt;
}

// h1paramstring should contain numpop**2 strings
// each from a set of 
// "MEAN", "ZERO", "SYMMETRICNM", "SYMMETRICM", "any number of size double"
//
void Analyzer::LRT(StringVec1d h1paramstring)
{
  LRTStruct lrt;
  vector <double> h1param;
  //  LRTH1convert(h1param, h1paramstring);
  lrt = LRT(h1param);
  //fill outputcontainer analyzer::lrts with lrt
  lrts.push_back(lrt);
}




