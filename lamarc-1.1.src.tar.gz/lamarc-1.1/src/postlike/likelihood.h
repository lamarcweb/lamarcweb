#ifndef __LIKELIHOOD_H__
#define __LIKELIHOOD_H__
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// likelihood class --------------------------------------------------
// $Id: likelihood.h,v 1.6 2002/06/25 03:17:49 mkkuhner Exp $
//
// PostLike 
//     --> SinglePostLike    [single region, single chain]
//     --> ReplicatePostLike [single region, multiple replicate]
//     --> RegionPostLike    [multiple region, multiple replicate]
//            --> GammaRegionPostLike [multiple region with gamma
//                      deviated region-mutation rate, multiple replicate]
//
// chainmanager calls PostLike and sticks it into 
//          maximizer (see maximizer.h) [e.g. Maximizer(&postlike)]
//          plot      (see ...)
//          profiler  (see ...)
// 
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <numeric>
#include <math.h>
#include "plforces.h"
#include "vectorx.h"
#include "plotstat.h"
#include "forcesummary.h"

#ifdef MEMDEBUG
#include "memdebug.h"
#endif

// parameter likelihood calculations
// works on treesumaries supplied through chains or chainmanager
// base class 


//typedef double (PLForces::*PLForcesFPtr) ();
//typedef double (PLForces::*DerivativePLForcesFPtr) (long &);

class ParamVector;
class TreeSummary;
class ChainSummary;

class PostLike
{

private:

  // Simple Init is here because nobody should call it


protected:
  // Data ------------------------------------------------------
  long nRegions;
  long nReplicate;
  long nPop;
  long rep;
  long locus;
  long nParam;
  long nForces;
  vector <string> forcestags;
  IntVec1d saveguides;
  IntVec1d guides;
  // PLforces objects
  // non-owning pointers (objects are owned by Force class)
    vector < PLForces * >forces;
  // functions -------------------------------------------------
  //


  // vectors of functions that operate on the treesummary data
  // these functions are called many many times
  //  PLForcesFPtr * waitfuncs;
  //vector < PLForcesFPtr > pointfuncs;
  //vector < DerivativePLForcesFPtr > dwaitfuncs;
  //vector < DerivativePLForcesFPtr > dpointfuncs;

  // fills the forces classes into the forces vector
  void FillForces (const ForceVec &thisforces);

  // calculates the probability of genealogy given the parameters
  double Calcprob (const DoubleVec1d & param,
		   const DoubleVec1d & lparam, const TreeSummary * treedata);
  // its derivative
  double DCalcprob (const DoubleVec1d & param,
		    const TreeSummary * treedata, const long &whichparam);

  // all waiting time parts in P(G|param) and derivatives
  double Waitingtime (const DoubleVec1d & param,
		      const TreeSummary * treedata);
  double DWaitingtime (const DoubleVec1d & param,
		       const TreeSummary * treedata, const long &whichparam);

  // all point prob parts in P(G|param) and derivatives
  double Pointprob (const DoubleVec1d & lparam, const TreeSummary * treedata);
  double DPointprob (const DoubleVec1d & param,
		     const TreeSummary * treedata, const long &whichparam);

public:
    PostLike (void);
    PostLike (const ForceVec &thisforces,
	      const long thisNpop,
	      const long thisNregion,
	      const long thisNreplicate, const long thisNParam);
    virtual ~ PostLike (void);
  virtual likelihoodtype GetTag() = 0;
  // Sets up data connection
  virtual long GetNparam (void)
  {
    return nParam;
  };
  virtual DoubleVec1d GetMeanParam0 () = 0;
  virtual void SetParam0 () = 0;
  // sets up guides and manages them for the gradients
  void GradientGuideSetup (const ParamVector &thisToDolist);
  void ProfileGuideRestore ();
  void ProfileGuide (long guide);

  // changes the many vector parameter list into a 1-D vector
  DoubleVec1d Linearize (const ForceParameters * forceParameters);  
// changes the 1-D vector back in the n-D notation.
  void Unlinearize (const vector < double >&param,
		    ForceParameters * forceParameters);
  // calculates log(like)
  virtual double Calculate (const DoubleVec1d & param,
			    const DoubleVec1d & lparam) = 0;
  double Calculate (const DoubleVec1d & param,
		    const DoubleVec1d & lparam,
		    const DoubleVec1d & probg0,
		    DoubleVec1d & probg,
		    double &sumprobg, const vector < TreeSummary * >*data);

  // calculates derivates 
  virtual void DCalculate (const DoubleVec1d & param,
			   DoubleVec1d & gradient) = 0;
  double DCalculate (const DoubleVec1d & param,
		     const DoubleVec1d & probg,
		     const vector < TreeSummary * >*treedata,
		     const long &whichparam);
  //  double  DCalculate(const DoubleVec1d& param, 
  //         const TreeSummary * treedata, 
  //         const long & whichparam,
  //         const double & constantfactor);

  //Maintenance functions
};

//////////////////////////////////////////////////////////////////
class SinglePostLike:public PostLike
{
private:
  double sumcpoint;
  // main hook into the treesummary data
  ChainSummary *data;
  DoubleVec1d param0;
  DoubleVec1d lparam0;
  DoubleVec1d probg0;		//this remains constant through maximization
  DoubleVec1d probg;		//this NOT! It is constant for a specific param
  double probgmax;
  double sumprobg;

public:
    SinglePostLike (const ForceVec &thisforces,
		    const long thisNpop,
		    const long thisNregion,
		    const long thisNreplicate, const long thisNParam);
   ~SinglePostLike ();
  virtual likelihoodtype GetTag() { return ssingle; };
  void SetParam0 ();
  void Setup (ChainSummary * treedata);
  double Calculate (const DoubleVec1d & param, const DoubleVec1d & lparam);
  void DCalculate (const DoubleVec1d & param, DoubleVec1d & gradient);
  DoubleVec1d GetMeanParam0 ();
};

//////////////////////////////////////////////////////////////////
class ReplicatePostLike:public PostLike
{
private:
  DoubleVec1d sumcpoint;
  DoubleVec2d param0;
  DoubleVec2d lparam0;
    vector < ChainSummary * >*data;
  DoubleVec2d probg0;
  DoubleVec2d probg;
  DoubleVec1d probgmax;
  DoubleVec1d sumprobg;

public:
    ReplicatePostLike (const ForceVec &thisforces,
		       const long thisNpop,
		       const long thisNregion,
		       const long thisNreplicate, const long thisNParam);
  //~ReplicatePostLike(){};
  virtual likelihoodtype GetTag() { return replicate; };
  void SetParam0 ();
  void CreateProbG0();

  void Setup (vector < ChainSummary * >*treedata);
  double Calculate (const DoubleVec1d & param, const DoubleVec1d & lparam);
  void DCalculate (const DoubleVec1d & param, DoubleVec1d & gradient);
  DoubleVec1d GetMeanParam0 ();
};

//////////////////////////////////////////////////////////////////
class RegionPostLike:public PostLike
{
protected:
  DoubleVec2d sumcpoint;
  DoubleVec3d param0;
  DoubleVec3d lparam0;
    vector < vector < ChainSummary * > >*data;
  DoubleVec3d probg0;
  DoubleVec3d probg;
  DoubleVec2d probgmax;
  DoubleVec2d sumprobg;

public:
    RegionPostLike (const ForceVec &thisforces,
		    const long thisNpop,
		    const long thisNregion,
		    const long thisNreplicate, const long thisNParam);
  //~RegionPostLike(){};
  virtual likelihoodtype GetTag() { return region; };
  void SetParam0 ();
  void Setup (vector < vector < ChainSummary * > >*treedata);
  double Calculate (const DoubleVec1d & param, const DoubleVec1d & lparam);
  void DCalculate (const DoubleVec1d & param, DoubleVec1d & gradient);
  DoubleVec1d GetMeanParam0 ();
};

///////////////////////////////////////////////////////////
class GammaRegionPostLike:public RegionPostLike
{
private:
  double alpha;

public:
    GammaRegionPostLike (const ForceVec &thisforces,
			 const long thisNpop,
			 const long thisNregion,
			 const long thisNreplicate, const long thisNParam);
  virtual likelihoodtype GetTag() { return gammaregion; };
  double Calculate (const DoubleVec1d & param, const DoubleVec1d & lparam);
  void DCalculate (const DoubleVec1d & param, DoubleVec1d & gradient);
};

#endif /*__LIKELIHOOD_H__*/
