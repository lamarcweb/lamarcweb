// derivatives of parameter likelihood
// $Id: derivatives.cpp,v 1.5 2002/06/25 03:17:49 mkkuhner Exp $
// 
// call sequence is in maximizer.cpp
//
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "likelihood.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

///////////////////////////////////////////////////////////
// Abstract Likelihood Derivatives 
//
// calculates derivatives of the parameter-likelihood
// and returns a derivative for the function and log(param)
double
PostLike::DCalculate (const vector < double >&param,
		      const vector < double >&probg,
		      const vector < TreeSummary * >*treedata,
		      const long &whichparam)
{
  double wait, point, eee;
  long i = 0;
  double grad = 0.0;
  vector < TreeSummary * >::const_iterator tt;
  vector < TreeSummary * >::const_iterator treedata_end = treedata->end(); // OPTIMIZE
  vector < double >::const_iterator pr;


  for (tt = treedata->begin (), pr = probg.begin (), i = 0;
       tt != treedata_end; ++tt, ++pr, ++i)
    {
      wait = DWaitingtime (param, *tt, whichparam);
      point = DPointprob (param, *tt, whichparam);
      eee = exp (*pr) * (wait + point);
      grad += (*tt)->GetNCopies() * eee;
    }
  return grad;
}

double
PostLike::DWaitingtime (const vector < double >&param,
			const TreeSummary * treedata, const long &whichparam)
{
  vector < PLForces * >::const_iterator i;
  vector < PLForces * >::const_iterator forces_end = forces.end(); // OPTIMIZE

  double wait = 0;
  for (i = forces.begin (); i != forces_end; ++i)
    {
      wait += (*i)->DWait (param, treedata, whichparam);
    }
  return wait;
}


double
PostLike::DPointprob (const vector < double >&param,
		      const TreeSummary * treedata, const long &whichparam)
{
  vector < PLForces * >::const_iterator i;
  vector < PLForces * >::const_iterator forces_end = forces.end(); // OPTIMIZE
  double point = 0.;
  for (i = forces.begin (); i != forces_end; ++i)
    {
      point += (*i)->DPoint (param, treedata, whichparam);
    }
  return point;
}


///////////////////////////////////////////////////////////
// Single locus derivatives
//
void
SinglePostLike::DCalculate (const vector < double >&param,
			    vector < double >&gradient)
{
  vector < double >::const_iterator p;
  vector < double >::const_iterator param_end = param.end(); // OPTIMIZE
  vector < int >::const_iterator guideIt;
  vector < double >::iterator g;
  long whichparam = 0;
  for (p = param.begin (), g = gradient.begin (), guideIt = guides.begin ();
       p != param_end; ++p, ++g, ++whichparam, ++guideIt)
    {
      if (*guideIt == 0)	//guide is 0 if the greadient does not need to be calculated
	(*g) = 0.0;
      else
	(*g) =
	  (*p) > 0.0 ? -(*p) / sumprobg * PostLike::DCalculate (param, probg,
								&data->
								treeSummaries,
								whichparam) :
	  0.0;
    }
}



///////////////////////////////////////////////////////////
// Replicated locus derivatives
//
void
ReplicatePostLike::DCalculate (const vector < double >&param,
			       vector < double >&gradient)
{
  vector < double >::const_iterator sumprobIt;
  vector < double >::const_iterator p;
  vector < double >::const_iterator param_end = param.end(); // OPTIMIZE
  vector < int >::const_iterator guideIt;
  vector < vector < double > >::const_iterator prob;
  vector < ChainSummary * >::const_iterator rep;
  vector < double >::iterator g;
  long whichparam = 0;

  for (p = param.begin (), g = gradient.begin (), guideIt = guides.begin ();
       p != param_end; ++p, ++g, ++whichparam, ++guideIt)
    {
      (*g) = 0.0;
      if (*guideIt != 0)	//guide is 0 if the greadient does not need to be calculated
	{
	  for (rep = data->begin (), prob = probg.begin (),
	       sumprobIt = sumprobg.begin ();
	       rep != data->end (); ++rep, ++prob, ++sumprobIt)
	    (*g) +=
	      PostLike::DCalculate (param, *prob, &((*rep)->treeSummaries),
				    whichparam) / *sumprobIt;
	  (*g) *= -(*p);
	}
    }
}

///////////////////////////////////////////////////////////
// Multiple Region derivatives
//
void
RegionPostLike::DCalculate (const vector < double >&param,
			    vector < double >&gradient)
{
  vector < double >::const_iterator spIt;
  vector < double >::const_iterator p;
  vector < int >::const_iterator guideIt;
  vector < vector < vector < double > > >::const_iterator probr;
  vector < vector < double > >::const_iterator sumprobIt;
  vector < vector < double > >::const_iterator prob;
  vector < vector < ChainSummary * > >::const_iterator chain;
  vector < ChainSummary * >::const_iterator ch;
  vector < double >::iterator g;
  long whichparam = 0;
  for (p = param.begin (), g = gradient.begin (), guideIt = guides.begin ();
       p != param.end (); ++p, ++g, ++whichparam, ++guideIt)
    {
      (*g) = 0.0;
      if (*guideIt != 0)	//guide is 0 if the greadient does not need to be calculated
	{
	  for (chain = data->begin (), probr = probg.begin (),
	       sumprobIt = sumprobg.begin ();
	       chain != data->end (); ++chain, ++probr, ++sumprobIt)
	    {
	      for (ch = chain->begin (), prob = probr->begin (),
		   spIt = sumprobIt->begin ();
		   ch != chain->end (); ++ch, ++prob, ++spIt)
		(*g) +=
		  PostLike::DCalculate (param, *prob, &((*ch)->treeSummaries),
					whichparam) / *spIt;
	    }
	  (*g) *= -(*p);
	}
    }
}

///////////////////////////////////////////////////////////
// Gamma deviated multiple loci derivatives
//
void
GammaRegionPostLike::DCalculate (const vector < double >&param,
				 vector < double >&gradient)
{
  double grad = 0.;
  //  vector <int> :: const_iterator guideIt;
  grad += 0.;			//needs integration
}
