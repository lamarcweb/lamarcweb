#ifndef __PLFORCES_H__
#define __PLFORCES_H__
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// PLforces class --------------------------------------------------
// 
// know how to calculate waiting times and point probabilities 
// of the parameters
//
// $Id: plforces.h,v 1.7 2002/06/25 03:17:50 mkkuhner Exp $

#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <numeric>
#include <math.h>
#include "mathx.h"
#include "treesum.h"
#include "chainsum.h"
//#include "parameters.h"

#ifdef MEMDEBUG
#include "memdebug.h"
#endif

class PLForces
{
protected:
  PLForces(const PLForces& src) :
    nPop(src.nPop), treedata(src.treedata), start(src.start),
    end(src.end)
  {
  };

public:
  long nPop;
  TreeSummary *treedata;    // non-owning pointer
  long start;        //offsets into the param vector that does not yet exist
  long end;

    PLForces ()
 {
  };

  PLForces (long thisnpop)
  {
    nPop = thisnpop;
    start = 0;
    end = 0;
  };

  virtual ~ PLForces ()
  {
  };

  virtual PLForces* Clone() const = 0;

  virtual double Wait (const vector < double >&param,
		       const TreeSummary * treedata) = 0;
  virtual double Point (const vector < double >&lparam,
			const TreeSummary * treedata) = 0;
  virtual double DWait (const vector < double >&param,
			const TreeSummary * treedata,
			const long &whichparam) = 0;
  virtual double DPoint (const vector < double >&param,
			 const TreeSummary * treedata,
			 const long &whichparam) = 0;

  virtual long GetNparam() { return nPop; };

  vector < double >Linearize (const ForceParameters forceParameters);

};

class CoalescePL:public PLForces
{
protected:
  CoalescePL(const CoalescePL& src) :
    PLForces(src)
  {
  };

public:
  // coalescence related wait, and point functions
  // and derivatives of them
  CoalescePL ()
  {
  };
  ~CoalescePL ()
  {
  };
  CoalescePL (long thisnpop)
  {
    nPop = thisnpop;
  };
  virtual PLForces* Clone() const
  {
    return new CoalescePL(*this);
  };
  double Wait (const vector < double >&param, const TreeSummary * treedata);
  double Point (const vector < double >&lparam, const TreeSummary * treedata);
  double DWait (const vector < double >&param,
		const TreeSummary * treedata, const long &whichparam);
  double DPoint (const vector < double >&param,
		 const TreeSummary * treedata, const long &whichparam);
};

// subclass of CoalescePL that uses long form with growth
class CoalesceGrowPL:public CoalescePL
{
protected:
  CoalesceGrowPL(const CoalesceGrowPL& src) :
    CoalescePL(src), growthstart(src.growthstart)
  {
  };

public:
  long growthstart; //we need to know where the growth parameters are stored
  // coalescence related wait, and point functions
  // and derivatives of them
  ~CoalesceGrowPL ()
  {
    growthstart = 0L;
  };

  CoalesceGrowPL (long thisnpop)
  {
    nPop=thisnpop;
  };
  virtual PLForces* Clone() const
  {
    return new CoalesceGrowPL(*this);
  };

  double Wait (const vector < double >&param, const TreeSummary * treedata);
  double Point (const vector < double >&lparam, const TreeSummary * treedata);
  double DWait (const vector < double >&param,
		const TreeSummary * treedata, const long &whichparam);
};


//
class GrowPL:public PLForces
{
protected:
  GrowPL(const GrowPL& src) :
    PLForces(src), thetastart(src.thetastart)
  {
  };

public:
  // exponential growth coalescence related wait, and point functions
  // and derivatives of them
  long thetastart;

  GrowPL ()
  {
    thetastart = 0L;
  };

  ~GrowPL ()
  {
  };

  GrowPL (long thisnpop)
  {
    nPop = thisnpop;
    thetastart = 0;
  };

  virtual PLForces* Clone() const
  {
    return new GrowPL(*this);
  };

  double Wait (const vector < double >&param, const TreeSummary * treedata);
  double Point (const vector < double >&lparam, const TreeSummary * treedata);
  double DWait (const vector < double >&param,
		const TreeSummary * treedata, const long &whichparam);
  double DPoint (const vector < double >&param,
		 const TreeSummary * treedata, const long &whichparam);
};

class MigratePL:public PLForces
{
public:
  // migration related wait, and point functions
  // and derivatives of them
  MigratePL ()
  {
  };

  MigratePL (long thisnpop)
  {
    nPop = thisnpop;
    msum = CreateVec1d(nPop, static_cast<double>(0.0));
  };
  ~MigratePL ()
  {
  };
  virtual PLForces* Clone() const
  {
    return new MigratePL(*this);
  };
  double Wait (const vector < double >&param, const TreeSummary * treedata);
  double Point (const vector < double >&param, const TreeSummary * treedata);
  double DWait (const vector < double >&param,
		const TreeSummary * treedata, const long &whichparam);
  double DPoint (const vector < double >&param,
		 const TreeSummary * treedata, const long &whichparam);

protected:
  DoubleVec1d msum;
  MigratePL(const MigratePL& src) :
    PLForces(src), msum(src.msum)
  {
  };

  
};
class MigrateGrowPL:public MigratePL
{
public:
  // migration related wait, and point functions
  // and derivatives of them
  MigrateGrowPL ()
  {
  };

  MigrateGrowPL (long thisnpop)
  {
    nPop = thisnpop;
    msum = CreateVec1d(nPop, static_cast<double>(0.0));
  };
  ~MigrateGrowPL ()
  {
  };
  virtual PLForces* Clone() const
  {
    return new MigrateGrowPL(*this);
  };
  double Wait (const vector < double >&param, const TreeSummary * treedata);
  double Point (const vector < double >&param, const TreeSummary * treedata);
  double DWait (const vector < double >&param,
		const TreeSummary * treedata, const long &whichparam);
  double DPoint (const vector < double >&param,
		 const TreeSummary * treedata, const long &whichparam);

protected:
  MigrateGrowPL(const MigrateGrowPL& src) :
    MigratePL(src)
  {
  };

private:

};

class RecombinePL:public PLForces
{
public:
  // recombination related wait, and point functions
  // and derivatives of them
  RecombinePL ()
  {
  };
  ~RecombinePL ()
  {
  };
  virtual PLForces* Clone() const
  {
    return new RecombinePL(*this);
  };
  double Wait (const vector < double >&param, const TreeSummary * treedata);
  double Point (const vector < double >&param, const TreeSummary * treedata);
  double DWait (const vector < double >&param,
		const TreeSummary * treedata, const long &whichparam);
  double DPoint (const vector < double >&param,
		 const TreeSummary * treedata, const long &whichparam);

protected:
  RecombinePL(const RecombinePL& src) :
    PLForces(src)
  {
  };

};

class SelectPL:public PLForces
{
public:
  // selection related wait, and point functions
  // and derivatives of them
  virtual PLForces* Clone() const
  {
    return new SelectPL(*this);
  };
  double Wait (const vector < double >&param, const TreeSummary * treedata);
  double Point (const vector < double >&param, const TreeSummary * treedata);
  double DWait (const vector < double >&param,
		const TreeSummary * treedata, const long &whichparam);
  double DPoint (const vector < double >&param,
		 const TreeSummary * treedata, const long &whichparam);

protected:
  SelectPL(const SelectPL& src) :
    PLForces(src)
  {
  };

};
#endif





