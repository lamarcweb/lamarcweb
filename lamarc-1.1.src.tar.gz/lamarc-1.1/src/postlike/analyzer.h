#ifndef _ANALYZER_H_
#define _ANALYZER_H_
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// analyzer.h
//
// the analyzer generates 
// - likelihood surfaces for all pair of parameters
// - profiles  [code will be in profile.cpp]
// - LRT
// 
// Peter Beerli November 2000
// $Id: analyzer.h,v 1.5 2002/06/26 19:11:54 lamarc Exp $
//
#include <vector>
#include "vectorx.h"
#include "maximizer.h"
#include "likelihood.h"
#include "plotstat.h"
#include <iostream>
#include <fstream>
#include "parameter.h"

#ifdef MEMDEBUG
#include "memdebug.h"
#endif

class ForceSummary;
class RunReport;
struct LRTStruct
{
  double h0like;
  double h1like;
  double lr;
  long   df;
  double prob;
  double probb; // for probability taking boundary conditions into account
};

long difference(DoubleVec1d param1, DoubleVec1d param2);

class Analyzer
{
public:
  // Instantiate the Analyzer
  // using the "last" postlike object or "last" maximizer object, 
  // the Analyzer assumes that the 
  // Prob(G|parameter_0) are already computed 
  // [in likelihood.h:....PostLike::Setup()
  Analyzer (ForceSummary &fs, RunReport &rr, const ParamVector &params);
  Analyzer (PostLike * thispostlikelihood,
	    ForceSummary &fs, RunReport &rr,
	    vector < double >thisMLEparam);
  Analyzer (Maximizer * thismaximizer,
	    ForceSummary &fs, RunReport &rr,
	    vector < double >thisMLEparam);
  ~Analyzer ();

  void SetMaximizer(Maximizer *thismaximizer) { maximizer = thismaximizer;};

  void SetPostLike() { postlikelihood = maximizer->LikePtr();};

  vector < PlotStruct > *CalcPlots ();
  // returns a structure containing all possible plots
  // according to ParamStruct *toDolist
  // the ouput contains the parameter pair and the plotplane data
  
  // calculate the profiles and put them into class variable profiles
  void CalcProfiles ();

  vector <ProfileStruct> & GetProfiles() {return profiles;};

  // Calculates the likelihood ratio test
  void CalcLRT();
  vector <LRTStruct> & GetLRTs() {return lrts;};

  // DEBUG function
  void printPlanes (ofstream * of, vector < PlotStruct > *planes);

private:
  DoubleVec1d  MLEparam;	// holds MLE parameters
  DoubleVec1d  MLElparam;	// holds the log(MLEparam)
  Maximizer *maximizer;		// holds the maximizer [for profiles]
  PostLike *postlikelihood;	// pointer to the PostLike [for plots]
  double likelihood;            // holds the L of the last maximization
  const ForceSummary &forcesummary;
  RunReport &runreport;         // not const so it can store time info
  vector < double >modifier;    // for calculation of percentiles or fixed 
  vector < ProfileStruct > profiles; // holds all profiles for further use
  vector < LRTStruct>      lrts; // holds all lrts
  // Temporary variables as an optimization
  DoubleVec1d newparam;

  // Calculates the PostLikelihoods at each gridpoint
  DoubleVec2d CalcPlane (const Parameter & xx, const long &xpos,
			 const Parameter & yy, const long &ypos);

  // Calculates a single Profile table
  void CalcProfile (ParamVector::iterator guide, long pos);
  void CalcProfileFixed (ParamVector::iterator guide, long pos);
  void CalcProfilePercentile (ParamVector::iterator guide, long pos);

  // Calculates the likelihood ratio test for 
  // against a  specified set of parameters.
  void CalcLRT(DoubleVec1d h1param);
  // a vector of known abbreviations
  void CalcLRT(string h1parmstring);
  //plain function that needs more fiddling
  LRTStruct LRT(DoubleVec1d h1param);
  void LRT(StringVec1d h1paramstring);
  // DEBUG print plot planes
  void printPlane (ofstream * of, PlotStruct & plane);

};

#endif




