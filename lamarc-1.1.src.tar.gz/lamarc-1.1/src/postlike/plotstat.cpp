// $Id: plotstat.cpp,v 1.5 2002/06/26 19:11:54 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcdebug.h"
#include <vector>
#include <assert.h>
#include "plotstat.h"

//__________________________________________________________________
//__________________________________________________________________


const ProfileLineStruct& ProfileStruct::GetProfileLine(double percentile) const
 {
   vector<ProfileLineStruct>::const_iterator prof;
   for(prof = profilelines.begin(); prof != profilelines.end(); ++prof)
     if (percentile == prof->percentile)
       return *prof;
 
   assert(false);
   return(*prof);
 }
