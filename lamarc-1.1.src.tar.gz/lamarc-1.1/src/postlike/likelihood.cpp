// parameter likelihood calculation
//
// <Single | Multi | Replicate >PostLikeCalculate() is the main player and  
// and calls the abstract base class function PostLike:Calculate()
// started April 2000 (PB)
// $Id: likelihood.cpp,v 1.10 2002/06/25 03:41:42 mkkuhner Exp $
//
//////////////////////////////////////////////////////////////////
//
// Calling sequence and life:
//
// SinglePostLike gets passed into a Maximizer constructor
//          the data-pointer is set, but there is no data yet.
// after a single chain Maximizer::Calculate() uses SinglePostLike::Calculate()
// if Replication: creation of ReplicatePostLike
// if more than 1 Region creation of RegionPostLike
// at the end of program RegionPostLike dies
//
//   GradientGuideSetup(thisToDolist); assigns zeroes and ones to a
//           vector that allows the gradient calculator to skip
//           over parameters that should not be maximized.
//
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "vectorx.h"
#include "likelihood.h"
#include "forceparam.h"
#include "force.h"
#include "forcesummary.h"
#include "definitions.h"
#include "parameter.h"   // for GradientGuideSetup()
#include "treesum.h"
#include "chainsum.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

const long NUMBER_RECOMB_PARAMETER = 1;
const long NUMBER_SELECT_PARAMETER = 1;

using namespace std;

//////////////////////////////////////////////////
// construction and destruction of single locus
// likelihood calculation


PostLike::PostLike (void)
{
}

PostLike::~PostLike (void)
{
#if 0
  // we don't do this--we don't own those pointers anymore!
  vector < PLForces * >::iterator fit;
  for (fit = forces.begin (); fit != forces.end (); ++fit)
    {
      delete *fit;
    }
#endif
}

PostLike::PostLike (const ForceVec &thisforces,
		    const long thisNpop,
		    const long thisNregion,
		    const long thisNreplicate, const long thisNParam)
{
  nForces = thisforces.size ();
  nRegions = thisNregion;
  nReplicate = thisNreplicate;
  nPop = thisNpop;
  locus = 0;
  rep = 0;
  nParam = thisNParam;
  ForceVec :: const_iterator fit;
  for(fit=thisforces.begin();fit!=thisforces.end(); ++fit)
    forcestags.push_back((*fit)->GetTag());
  FillForces (thisforces);
  //guides.push_back(1);
  //saveguides.push_back(1);
}

void
PostLike::FillForces (const ForceVec& thisforces)
{
  ForceVec::const_iterator fit;
  vector < PLForces * >::iterator last;

  bool hasgrowth=false;
  long growthstart = 0L;
  long thetastart = 0L;
  PLForces *forceptr = NULL;
  PLForces *coalptr = NULL;
  PLForces *growptr = NULL;
  long end = 0L;

  for (fit = thisforces.begin (); fit != thisforces.end (); ++fit)
    {
      forceptr = (*fit)->GetPLForceFunction();
      forces.push_back (forceptr);
      last = forces.end () - 1;
      (*last)->start = end;
      (*last)->end = (*last)->start + (*fit)->GetPLForcepnum();
      end  = (*last)->end;
      //DEBUG
      //      cerr << (*fit)->GetTag() << " start=" << (*last)->start << " end=" << (*last)->end << endl;
      if((*fit)->GetTag()==GROW)
	{
	  growthstart = (*last)->start;
	  hasgrowth = true;
	  growptr = forceptr;
	}
      if((*fit)->GetTag()==COAL)
	{
	  thetastart = (*last)->start;
	  coalptr = forceptr;
	}
    }
  if(hasgrowth)
    {
      CoalesceGrowPL *temp = (dynamic_cast<CoalesceGrowPL *>(coalptr));
      temp->growthstart = growthstart;
      GrowPL *temp2 = (dynamic_cast<GrowPL *>(growptr));
      temp2->thetastart = thetastart;
    }
}


DoubleVec1d PostLike::Linearize (const ForceParameters * forceParameters)
{
  DoubleVec1d
  param (nParam);
  vector <string>::const_iterator fit;
  DoubleVec1d::iterator pit = param.begin ();
  for (fit = forcestags.begin (); fit != forcestags.end (); ++fit)
    {
      if (*fit == COAL)
	{
	  DoubleVec1d thetas = forceParameters->GetThetas ();
	  copy (thetas.begin (), thetas.end (), pit);
	  pit += thetas.size ();
	}
      if (*fit == MIG)
	{
	  DoubleVec1d migrations = forceParameters->GetMigRates ();
	  copy (migrations.begin (), migrations.end (), pit);
	  pit += migrations.size ();
	}
      if (*fit == REC)
	{
	  double recRate = forceParameters->GetRecRates ().front ();
	  *pit = recRate;
	  pit++;
	}
      if(*fit == GROW)
	{
	  DoubleVec1d growths = forceParameters->GetGrowthRates();
	  copy (growths.begin (), growths.end (), pit);
	  pit += growths.size ();
	}
    }
  return param;
}

void
PostLike::Unlinearize (const vector < double >&param,
		       ForceParameters * forceParameters)
{
  vector < string >::const_iterator fit;
  vector < PLForces * >::const_iterator fo;
  for (fit = forcestags.begin (),
       fo = forces.begin (); fit != forcestags.end (); ++fit, ++fo)
    {
      if (*fit == COAL)
	{
	  vector < double >thetas (nPop);
	  vector < double >::const_iterator x =
	    (param.begin () + (*fo)->start);
	  vector < double >::const_iterator y = (param.begin () + (*fo)->end);
	  copy (x, y, thetas.begin ());
	  forceParameters->SetThetas (thetas);
	}
      if (*fit == MIG)
	{
	  vector < double >migrations (nPop * nPop);
	  vector < double >::const_iterator x =
	    (param.begin () + (*fo)->start);
	  vector < double >::const_iterator y = (param.begin () + (*fo)->end);
	  copy (x, y, migrations.begin ());
	  forceParameters->SetMigRates (migrations);
	}
      if (*fit == REC)
	{
	  DoubleVec1d RecRate;
	  RecRate.push_back (*(param.begin () + (*fo)->start));
	  forceParameters->SetRecRates (RecRate);
	}
    }
}

void
PostLike::GradientGuideSetup (const ParamVector &thisToDolist)
{
  // defines behavior in the gradient calculations
  // Type              Label [this gets used in gradient()]
  // c = constant   -> 0.
  // * = maximize   -> 1.
  ParamVector::const_iterator doListItem;
  guides.clear ();
  for (doListItem = thisToDolist.begin ();
       doListItem != thisToDolist.end (); ++doListItem)
    {
      switch (doListItem->GetValidity())
	{
	case invalid:
	case constant:
	  guides.push_back (0);
	  break;
	default:
	  guides.push_back (1);
	}
    }
  saveguides = guides;
}

void
PostLike::ProfileGuideRestore ()
{
  guides = saveguides;
}

void
PostLike::ProfileGuide (long guide)
{
  guides[guide] = 0;		// gradient treat this as a constant 
}

double
PostLike::Calculate (const DoubleVec1d & param,
		     const DoubleVec1d & lparam,
		     const DoubleVec1d & probg0,
		     DoubleVec1d & probg,
		     double &sumprobg, const vector < TreeSummary * >*data)
{
  vector < double >::const_iterator i;
  vector < double >::iterator j;
  vector < TreeSummary * >::const_iterator z;
  vector < TreeSummary * >::const_iterator d;

  long numtrees = 0;
  double probgmax = -(DBL_MAX - 1.0);
  for (d = data->begin (), i = probg0.begin (), j = probg.begin ();
       d != data->end (); ++i, ++d, ++j)
    {
      *j = Calcprob (param, lparam, (*d)) - *i;
      if (*j > probgmax)
	probgmax = *j;
    }

  for (j = probg.begin (), z = data->begin (); z != data->end (); ++j, ++z)
    {
      *j -= probgmax;
      sumprobg += (*z)->GetNCopies() * exp (*j);
      numtrees += (*z)->GetNCopies();
    }
  return probgmax + log (sumprobg) - log (numtrees);
}

// calculation of waiting times
// we stay in logs, they will be transformed after normalizing
// in Calculate(x,y)
double
PostLike::Waitingtime (const DoubleVec1d & param,
		       const TreeSummary * treedata)
{
  //  vector < double (PostLike::*)
  //(DoubleVec1d &, long &, TimeSummary &) >::iterator i; 
  vector < PLForces * >::const_iterator i;
  double wait = 0;
  //  cout << "Wait ";
  for (i = forces.begin (); i != forces.end (); ++i)
    {
      wait += (*i)->Wait (param, treedata);
      //  cout << wait << " " ;
    }
  //cout << endl;
  return wait;
}

double
PostLike::Pointprob (const DoubleVec1d & lparam, const TreeSummary * treedata)
{
  vector < PLForces * >::const_iterator i;
  double point = 0.;
  //  cout << "Point: ";
  for (i = forces.begin (); i != forces.end (); ++i)
    {
      point += (*i)->Point (lparam, treedata);
      //      cout << point << " ";
    }
  //  cout << endl;
  return point;
}

double
PostLike::Calcprob (const DoubleVec1d & param,
		    const DoubleVec1d & lparam, const TreeSummary * treedata)
{
  double tmp, tmp1, tmp2;
  tmp1 = Waitingtime (param, treedata);
  tmp2 = Pointprob (lparam, treedata);
  tmp = tmp2 - tmp1;
  //  cout << tmp << "=" << tmp1 << "+" << tmp2 << endl;
  return tmp;
}


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Single locus, single chain likelihood
SinglePostLike::SinglePostLike (const ForceVec &thisforces, const long thisNpop, const long thisNregion, const long thisNreplicate, const long thisNParam):PostLike (thisforces, thisNpop, thisNregion, thisNreplicate,
	  thisNParam)
{
  sumprobg = 0.;
}

SinglePostLike::~SinglePostLike ()
{
}

void
SinglePostLike::SetParam0 ()
{
  param0 = Linearize (&(data->forceParameters));
  lparam0 = LogVec0 (param0);
}

void
SinglePostLike::Setup (ChainSummary * treedata)
{
  vector < TreeSummary * >::iterator i;
  DoubleVec1d::iterator pr;
  data = treedata;
  vector < TreeSummary * >trees = data->treeSummaries;
  if (probg0.size () < trees.size ())
    {
      probg0.resize (trees.size (), 0.0);
      probg.resize (trees.size (), 0.0);
    }
  SetParam0 ();
  for (i = trees.begin (), pr = probg0.begin (); i != trees.end (); ++i, ++pr)
    {
      *pr = (Calcprob (param0, lparam0, (*i)));
    }
}

double
SinglePostLike::Calculate (const DoubleVec1d & param,
			   const DoubleVec1d & lparam) 
{
  double like = 0;
  sumprobg = 0.;
  like =
    PostLike::Calculate (param, lparam, probg0, probg, sumprobg,
			 &data->treeSummaries);
  return like;
}

DoubleVec1d SinglePostLike::GetMeanParam0 ()
{
  return param0;
}


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Replicated likelihood
ReplicatePostLike::ReplicatePostLike (const ForceVec &thisforces, const long thisNpop, const long thisNregion, const long thisNreplicate, const long thisNParam):PostLike (thisforces, thisNpop, thisNregion, thisNreplicate,
	  thisNParam)
{
  sumprobg = CreateVec1d (thisNreplicate, 0.0);
}


void
ReplicatePostLike::SetParam0 ()
{
  vector < ChainSummary * >::iterator rep;
  for (rep = data->begin (); rep != data->end (); ++rep)
    {
      param0.push_back (Linearize (&((*rep)->forceParameters)));
      lparam0.push_back ((LogVec0 (*(param0.end () - 1))));
    }
}

void
ReplicatePostLike::CreateProbG0()
{
    vector < ChainSummary * >::const_iterator rep;
    DoubleVec2d :: iterator p0;
    DoubleVec2d :: iterator lp0;
    DoubleVec2d :: iterator pr;
    DoubleVec1d :: iterator prr;
    vector < TreeSummary * >::const_iterator i;

  for (rep = data->begin (), pr = probg0.begin (), 
	 p0 = param0.begin (), lp0 = lparam0.begin (); 
       rep != data->end (); 
       ++rep, ++pr, ++p0, ++lp0)
    {
      for (i = (*rep)->treeSummaries.begin (), prr = (*pr).begin ();
	   i != (*rep)->treeSummaries.end (); ++i, ++prr)
	{
	  // we are doing this now:
	  // prog0[rep][tree] = CalcProb(param0[rep],lparam0[rep],
	  //                           data[rep][tree])
	  *prr = Calcprob (*p0, *lp0, (*i));
	}
    }
}

void
ReplicatePostLike::Setup (vector < ChainSummary * >*treedata)
{
  data = treedata;
  vector < ChainSummary * >::const_iterator rep;

  SetParam0 ();

  for(rep = data->begin(); rep<data->end(); rep++)
    {
      DoubleVec1d tmp_probg0((*rep)->treeSummaries.size());
      probg0.push_back(tmp_probg0);
      probg.push_back(tmp_probg0);
    }

  DoubleVec1d::iterator newlike;
  DoubleVec1d::iterator diff;
  long nreps = data->size();
  DoubleVec1d nlvec(nreps);
  DoubleVec1d olvec(nreps, DBL_MAX);
  DoubleVec1d difference(nreps);
  DoubleVec1d oldifference(nreps, 99.0); 
  bool alldone = false;
  bool diffdone = false;
  long count = 0;
  unsigned long r;
  double delta = DBL_MAX;
  while (!alldone && count++ < 10000)
    {
      alldone = true;
      CreateProbG0();
      for(rep = data->begin(), newlike = nlvec.begin(),
	    diff = difference.begin(), r=0; 
	  rep<data->end(); 
	  ++rep, ++newlike, ++diff, ++r)
	{
	  *newlike = PostLike::Calculate (param0[r], lparam0[r], 
					  probg0[r], probg[r], sumprobg[r],
					  &((*rep)->treeSummaries));
	  *diff = fabs (*newlike - olvec[r]);
	  if (delta < *diff)
	    delta = *diff;
	  if (delta > EPSILON)
	    alldone = false;
	}
      //DEBUG
	if (count % 100 == 0 )
	  cout << "Iteration " << count << " biggest difference = " << 
	    delta << endl;
	olvec.swap(nlvec);
	diffdone = true;
	for(r=0; r < data->size(); r++)
	{
	  if (fabs (oldifference[r] - difference[0]) > EPSILON)
	    {
	      diffdone = false;
	      break;
	    }
	}
      if (diffdone)
	break;
      else
	oldifference.swap(difference);
      delta = difference[0];
    }
  // DEBUG
  if (delta < EPSILON)
    cout << "Reweighting of chains finished in " << count << "cycles" << endl;
  else
    {
      cout << "Reweighting operation converged to\n" <<
	" constant multiplier " << delta << "in " << count << " cycles"
	   << endl;
    }
}


double
ReplicatePostLike::Calculate (const DoubleVec1d & param,
			      const DoubleVec1d & lparam)
{
  double like = 0;
  DoubleVec1d::iterator spg;
  DoubleVec2d::const_iterator p0;
  DoubleVec2d::iterator p;
  vector < ChainSummary * >::const_iterator d;

  // sumprobg.assign(sumprobg.size(),0.0);
  fill (sumprobg.begin (), sumprobg.end (), 0.0);

  for (p0 = probg0.begin (), p = probg.begin (),
       d = data->begin (), spg = sumprobg.begin ();
       p0 != probg0.end (); ++p0, ++p, ++d, ++spg)
    like +=
      PostLike::Calculate (param, lparam, *p0, *p, *spg,
			   &((*d)->treeSummaries));
  return like;
}


DoubleVec1d ReplicatePostLike::GetMeanParam0 ()
{
  long
    size =
    param0.
    size ();
  DoubleVec1d
  meanparam0 ((*(param0.begin ())).size ());
  DoubleVec2d::iterator p0;
  DoubleVec1d::iterator i;
  for (p0 = param0.begin (); p0 != param0.end (); ++p0)
    {
      transform (meanparam0.begin (), meanparam0.end (),
		 (*p0).begin (), meanparam0.begin (), plus < double >());
    }
  for (i = meanparam0.begin (); i != meanparam0.end (); ++i)
    {
      (*i) /= size;
    }
  return meanparam0;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Locilikelihood
RegionPostLike::RegionPostLike (const ForceVec &thisforces, const long thisNpop, const long thisNregion, const long thisNreplicate, const long thisNParam):PostLike (thisforces, thisNpop, thisNregion, thisNreplicate,
	  thisNParam)
{
  sumprobg = CreateVec2d (thisNregion, thisNreplicate, 0.0);
}


void
RegionPostLike::SetParam0 ()
{
  vector < vector < ChainSummary * > >::const_iterator region;
  vector < ChainSummary * >::const_iterator rep;
  DoubleVec3d::iterator p0;
  DoubleVec3d::iterator lp0;

  for (region = data->begin (), p0 = param0.begin (), lp0 = lparam0.begin ();	//over region
       region != data->end (); ++region, ++p0, ++lp0)
    {
      DoubleVec2d tmpParam0;
      DoubleVec2d tmpLParam0;
      for (rep = region->begin (); rep != region->end (); ++rep)
	{
	  DoubleVec1d p00 = Linearize (&((*rep)->forceParameters));
	  tmpParam0.push_back (p00);
	  tmpLParam0.push_back (LogVec0 (p00));
	}
      param0.push_back (tmpParam0);
      lparam0.push_back (tmpLParam0);
    }
}
//}


void
RegionPostLike::Setup (vector < vector < ChainSummary * > >*treedata)
{
  data = treedata;
  vector < vector < ChainSummary * > >::const_iterator region;
  vector < ChainSummary * >::const_iterator rep;
  vector < TreeSummary * >::const_iterator i;
  long reg, repl;
#if 0
  DoubleVec3d::iterator pr;
  DoubleVec2d::iterator pr2;
#endif
  SetParam0 ();
  for (region = data->begin (), reg = 0; region != data->end ();
       ++region, ++reg)
    {
      DoubleVec2d regionvals;
      for (rep = region->begin (), repl = 0; rep != region->end ();
	   ++rep, ++repl)
	{
	  DoubleVec1d replicatevals;
	  for (i = (*rep)->treeSummaries.begin ();
	       i != (*rep)->treeSummaries.end (); ++i)
	    {
	      replicatevals.
		push_back (Calcprob
			   (param0[reg][repl], lparam0[reg][repl], (*i)));
	    }
	  regionvals.push_back (replicatevals);
	}
      probg0.push_back (regionvals);
      probg.push_back (regionvals);	// this is just to get probg to the
      // proper dimensions, the values are
      // garbage
    }
#if 0
  for (region = data->begin (), pr = probg0.begin ();	//over region
       region != data->end (); ++region, ++pr)
    {
      for (rep = region->begin (), pr2 = pr->begin ();	//over replicate
	   rep != region->end (); ++rep, ++pr2)
	{
	  for (i = (*rep)->treeSummaries.begin ();
	       i != (*rep)->treeSummaries.end (); ++i)
	    {
	      (*pr2).push_back (Calcprob (param0, lparam0, (*i)));
	    }
	}
    }
#endif
}

double
RegionPostLike::Calculate (const DoubleVec1d & param,
			   const DoubleVec1d & lparam)
{
  double like = 0;
  DoubleVec3d::const_iterator p00;
  DoubleVec3d::iterator pp;
  vector < vector < ChainSummary * > >::const_iterator dd;
  DoubleVec2d::const_iterator p0;
  DoubleVec2d::iterator p;
  DoubleVec2d::iterator spg0;
  DoubleVec1d::iterator spg;
  vector < ChainSummary * >::const_iterator d;

  DoubleVec1d temp (sumprobg[0].size (), 0.0);
  // sumprobg.assign(sumprobg.size(),temp);
  fill (sumprobg.begin (), sumprobg.end (), temp);


  for (p00 = probg0.begin (), pp = probg.begin (),
       dd = data->begin (), spg0 = sumprobg.begin ();
       p00 != probg0.end (); ++p00, ++pp, ++dd, ++spg0)
    {
      for (p0 = p00->begin (), p = pp->begin (), d = dd->begin (), spg =
	   spg0->begin (); p0 != p00->end (); ++p0, ++p, ++d, ++spg)
	like +=
	  PostLike::Calculate (param, lparam, *p0, *p, *spg,
			       &((*d)->treeSummaries));
    }
  return like;
}


DoubleVec1d
RegionPostLike::GetMeanParam0 ()
{
  long size = 0;
  DoubleVec1d meanparam0 ((*(*(param0.begin ())).begin ()).size ());
  DoubleVec3d::iterator p00;
  DoubleVec2d::iterator p01;
  DoubleVec1d::iterator i;
  for (p00 = param0.begin (); p00 != param0.end (); ++p00)
    {
      size += (*p00).size ();
      for (p01 = (*p00).begin (); p01 != (*p00).end (); ++p01)
	transform (meanparam0.begin (), meanparam0.end (),
		   (*p01).begin (), meanparam0.begin (), plus < double >());
    }
  for (i = meanparam0.begin (); i != meanparam0.end (); ++i)
    {
      (*i) /= size;
    }
  return meanparam0;
}



//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Gamma-deviated Locilikelihood

GammaRegionPostLike::GammaRegionPostLike (const ForceVec &thisforces, const long thisNpop, const long thisNregion, const long thisNreplicate, const long thisNParam):RegionPostLike (thisforces, thisNpop, thisNregion, thisNreplicate,
		thisNParam)
{

}

double
GammaRegionPostLike::Calculate (const DoubleVec1d & param,
				const DoubleVec1d & lparam)
{
  double like = 0;
  long i;

  for (i = 0; i < nRegions; ++i)
    like += 1;			//Integrate over exp(f(x) +ReplicatePostLike::Calculate(&param, &data[i]));
  return like;
}
