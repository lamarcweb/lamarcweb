// $Id: plforces.cpp,v 1.8 2002/06/25 03:17:50 mkkuhner Exp $
//
// Posterior Likelihood forces classes
// - CoalescePL
//   - coalesce with no-growth [using compressed summaries]
// - CoalesceGrowPL
//   - coalesce with exponential growth [using non-compressed summaries]
// - GrowPL
//   - coalesce with exponential growth [using non-compressed summaries]
// - MigratePL
// - RecombinePL
// - SelectPL [stubs]
///////////////////////////////////////////////////////    
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "plforces.h"
#include "vectorx.h"
#include "summary.h"

#ifdef DMALLOC_FUNC_CHECK
#include <dmalloc.h>
#endif

using namespace std;

const double LOG2 = 0.69314718055994530942;

//-----------------------------------------------------
// MigratePL: migration forces specific waiting time and 
//            point probabilites and its derivatives
double
MigratePL::Wait (const vector < double >&param, const TreeSummary * treedata)
{
//  vector < double > msum(nPop);
  vector < double >::iterator i;
  vector < double >::const_iterator pstart;
  vector < double >::const_iterator pend;
//  msum = CreateVec1d (nPop, 0.0);
  // SM_j = sum_i(M[i,j])

  const vector<double>& mWait = treedata->GetMigSummary()->GetShortWait();

  for (i = msum.begin (),
       pstart = param.begin () + start,
       pend = param.begin () + start + nPop;
       i != msum.end (); ++i, pstart += nPop, pend += nPop)
    {
      (*i) = accumulate (pstart, pend, 0.0);
    }
  // sum_pop(SM_pop *kt)
  return inner_product (mWait.begin (),
			mWait.end (), msum.begin (), 0.0);
}

double
MigratePL::Point (const vector < double >&lparam,
		  const TreeSummary * treedata)
{
  //  Sum_j(Sim_i(migevent[j,i] * log(M[j,i]))
  const vector<double>& nmig = treedata->GetMigSummary()->GetShortPoint();
  return inner_product (nmig.begin (), nmig.end (), lparam.begin () + start,
			0.0);
}

double
MigratePL::DWait (const vector < double >&param,
		  const TreeSummary * treedata, const long &whichparam)
{
  long which = (whichparam - start) / nPop;
  if (whichparam >= start && whichparam < end) {
    const vector<double>& mWait = treedata->GetMigSummary()->GetShortWait();
    return -mWait[which];
  }
  else
    return 0.0;
}

double
MigratePL::DPoint (const vector < double >&param,
		   const TreeSummary * treedata, const long &whichparam)
{
  long which = whichparam - start;
  if (whichparam >= start && whichparam < end) {
      const vector<double>& nmig = treedata->GetMigSummary()->GetShortPoint();
//      return nmig[which] / param[whichparam];
      return SafeDivide (nmig[which], param[whichparam]);
  }
  else
      return 0.0;
}

//-----------------------------------------------------
// CoalescePL: coalecsence forces specific waiting time and 
//             point probabilites and its derivatives
// COMPRESSED DATA SUMMARIES
double
CoalescePL::Wait (const vector < double >&param, const TreeSummary * treedata)
{
  // result = sum_pop(k(k-1)t/theta_pop)
  const vector<double>& cWait = treedata->GetCoalSummary()->GetShortWait();
  return inner_product (cWait.begin (), cWait.end (),
			param.begin () + start,
			0.0, plus < double >(), divides < double >());
}

double
CoalescePL::Point (const vector < double >&lparam,
		   const TreeSummary * treedata)
{
  //  in general it is Sum_j(coalesceevent[j] * (log(2) - log(theta_j)))
  //  sumcpoint = Sum_j(coalesceevent[j] * log(2)) 
  //   - Sum_j(coalesceevent[j] * log(theta_j)) 
  const vector<double>& ncoal = treedata->GetCoalSummary()->GetShortPoint();
  return (LOG2 *
	  accumulate (ncoal.begin (), ncoal.end (), 0.0) - 
            inner_product (ncoal.begin (), ncoal.end (), lparam.begin () + start, 0.0));
  
}

double
CoalescePL::DWait (const vector < double >&param,
		   const TreeSummary * treedata, const long &whichparam)
{
  long which = whichparam - start;
  if (whichparam >= start && whichparam < end) {
    const vector<double>& cWait = treedata->GetCoalSummary()->GetShortWait();
    return cWait[which] / (param[whichparam] * param[whichparam]);
  }
  else
    return 0.0;
}

double
CoalescePL::DPoint (const vector < double >&param,
		    const TreeSummary * treedata, const long &whichparam)
{
  long which = whichparam - start;
  const vector<double>& ncoal = treedata->GetCoalSummary()->GetShortPoint();
  if (whichparam >= start && whichparam < end)
    return -ncoal[which] / param[whichparam];
  else
    return 0.;
}


double
CoalesceGrowPL::Wait (const vector < double >&param, const TreeSummary * treedata)
{
  const list<Interval>& treesum=treedata->GetCoalSummary()->GetLongWait();
  list <Interval> :: const_iterator tit;
  vector < double > :: const_iterator pit = param.begin() + start;
  vector < double > :: const_iterator pend = param.begin () + start + nPop;
  vector < double > :: const_iterator git = param.begin() + growthstart;
  long pop = 0;

  double result = 0.0;
  // calculates result = sum_pop(k(k-1)t/(exp(-gu) theta_pop))
  for( ; pit != pend; ++pit, ++git, ++pop)
    {
      tit = treesum.begin();
      for( ; tit != treesum.end(); ++tit)
	{
	  result += (exp(*git * (*tit).starttime)-exp(*git * (*tit).endtime))
	    * (*tit).poplines[pop] * ( (*tit).poplines[pop] - 1.)
	    / ((*git) * (*pit));
	}
    }
  return result;
}


double
CoalesceGrowPL::Point (const vector < double >&lparam,
		   const TreeSummary * treedata)
{
  //  in general it is Sum_j(coalesceevent[j] * (log(2) - log(theta_j_o exp[- g te])))
  //  sumcpoint = Sum_j(coalesceevent[j] * log(2)) 
  //   - Sum_j(coalesceevent[j] * log(theta_j)) 
  const Interval * treesum = treedata->GetCoalSummary()->GetLongPoint();
  const Interval * tit;
  vector < double > :: const_iterator pit = lparam.begin() + start;
  vector < double > :: const_iterator pend = lparam.begin () + start + nPop;
  vector < double > :: const_iterator git = lparam.begin() + growthstart;
  long pop = 0 ;

  double result = 0.0;
  for( ; pit != pend; ++pit, ++git, ++pop)
    {
      //needs changes to jump only between the specific coalescence
      for(tit= treesum; tit != NULL; tit = tit->next)
	  result +=   LOG2 + (*git) * (*tit).endtime - (*pit);
    }
  return result;
}

double
CoalesceGrowPL::DWait (const vector < double >&param,
		   const TreeSummary * treedata, const long &whichparam)
{
  if (whichparam >= start && whichparam < end) 
    {
      const list<Interval>& treesum = treedata->GetCoalSummary()->GetLongWait();
      list <Interval> :: const_iterator tit=treesum.begin();
      double result = 0.0;
      long which = whichparam - start;
      double growth = param[whichparam+growthstart];
      double param2 = (param[whichparam] * param[whichparam] * growth);
      for( ; tit != treesum.end(); ++tit)
	{
	  result += (exp(growth * (*tit).starttime)-exp(growth * (*tit).endtime))
	    * (*tit).poplines[which] * ((*tit).poplines[which] - 1) / param2;
	}
      return result;
    }
  else
    return 0.0;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// CoalesceGrowPL::DPoint (const vector < double >&param,
//		    const TreeSummary * treedata, const long &whichparam)
// handled through CoalescePL::DPoint()
// assumes that longsummaries = longsummaries PLUS shortsummaries
//              shortsummaries = shortsummaries 


//-----------------------------------------------------
// GrowPL: exponential growth forces specific waiting time (=0) and 
//              point probabilites and its derivatives
// UN-compressed DATA SUMMARIES
double
GrowPL::Wait (const vector < double >&param, const TreeSummary * treedata)
{
  //growth is a modifier of theta -> no own waiting time
  return 0;
}

double
GrowPL::Point (const vector < double >&lparam,
		   const TreeSummary * treedata)
{
  // modifier of theta -> now own waiting time
  return 0;
}

double
GrowPL::DWait (const vector < double >&param,
		   const TreeSummary * treedata, const long &whichparam)
{
  long whichg = whichparam;
  long whicht = whichparam - thetastart;
  if (whichparam >= start && whichparam < end)
    {
      const list<Interval>& treesum = treedata->GetCoalSummary()->GetLongWait();
      list <Interval> :: const_iterator tit = treesum.begin(); 


      double result = 0.0;


      double g = param[whichg]; //growth
      double param1 = param[whicht] * g * g;
      double te;
      double ts;
      double gts;
      double gte;
      for( ; tit != treesum.end(); ++tit)
	{
	  ts = (*tit).starttime;
	  te = (*tit).endtime;
	  gte = g * te;
	  gts = g * ts;
	  result += (exp(gte) * (1. - gte) + exp(gts) * (gts - 1.) 
		     * (*tit).poplines[whicht] * ( (*tit).poplines[whicht] - 1.))
	    / param1;
	}
      return result;
    }
  else
    return 0.0;
}

double
GrowPL::DPoint (const vector < double >&param,
		    const TreeSummary * treedata, const long &whichparam)
{
  if (whichparam >= start && whichparam < end)
    {      
      const list<Interval>& treesum = treedata->GetCoalSummary()->GetLongWait();
      list <Interval> :: const_iterator tit = treesum.begin();
      double result = 0.0;
      for( ; tit != treesum.end(); ++tit)
	result += (*tit).endtime;
      return result;
    }
  else
    return 0.0;
}


//-----------------------------------------------------
// RecombinePL: recombination forces specific waiting time and 
//              point probabilites and its derivatives
double
RecombinePL::Wait (const vector < double >&param,
		   const TreeSummary * treedata)
{
  const vector<double>& rWait = treedata->GetRecSummary()->GetShortWait();
  return rWait[0] * *(param.begin () + start);
}

double
RecombinePL::Point (const vector < double >&lparam,
		    const TreeSummary * treedata)
{
  //  Sum_j(recevents * log(r))
  const vector<double>& nrec = treedata->GetRecSummary()->GetShortPoint();
  return nrec[0] * *(lparam.begin () + start);
}

double
RecombinePL::DWait (const vector < double >&param,
		    const TreeSummary * treedata, const long &whichparam)
{
  if (whichparam >= start && whichparam < end) {
    const vector<double>& rWait = treedata->GetRecSummary()->GetShortWait();
    return -rWait[0];
  }
  return 0.0;
}

double
RecombinePL::DPoint (const vector < double >&param,
		     const TreeSummary * treedata, const long &whichparam)
{
  if (whichparam >= start && whichparam < end) {
    const vector<double>& nrecs = treedata->GetRecSummary()->GetShortPoint();
    return nrecs[0] / *(param.begin () + start);
  }
  else
    return 0.;
}




//-----------------------------------------------------
// SelectPL: selection forces specific waiting time and 
//              point probabilites and its derivatives
double
SelectPL::Wait (const vector < double >&param, const TreeSummary * treedata)
{
  return 0.;
}

double
SelectPL::Point (const vector < double >&lparam, const TreeSummary * treedata)
{
  return 0.;
}

double
SelectPL::DWait (const vector < double >&param, const TreeSummary * treedata,
		 const long &whichparam)
{
  return 0.;
}

double
SelectPL::DPoint (const vector < double >&param, const TreeSummary * treedata,
		  const long &whichparam)
{
  return 0.;
}












