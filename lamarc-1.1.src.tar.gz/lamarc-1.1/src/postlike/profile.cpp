// profile.cpp [part of the analyzer module]
//
// - profiles (fixed and percentile)
//
// 
// Peter Beerli November 2000
// $Id: profile.cpp,v 1.5 2002/06/25 03:17:50 mkkuhner Exp $
//

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "analyzer.h"
#include "maximizer.h"
#include "parameter.h"
#include "constants.h"
#include <vector>
#include "vectorx.h"
#include "runreport.h"
#include "forcesummary.h"
#include "types.h"

const double INVALID = -1.;
const double SMALLVALUE = 1e-20;
const double LARGEVALUE = 1e20;

// returns a structure containing all possible profiletables
// according to ParamStruct *toDolist
void Analyzer::CalcProfiles ()
{
  ParamVector toDolist(forcesummary);
  ParamVector::iterator i;
  long ii;

  // setup and save the guides for the gradients
  MLEparam = maximizer->GetParameters();
  MLElparam = LogVec0 (MLEparam);
  likelihood = maximizer->GetLastLikelihood();
  profiles.clear();

  // crank up runtime progress reports
  long numprofiles = toDolist.NumValidParameters();
  runreport.RecordProfileStart();
  long thisprofile = 0;

  for (i = toDolist.begin (),	//over all parameters in toDo list
       ii = 0; i != toDolist.end (); ++i, ++ii)
    {
      if(i->IsValid())
	{
	  //restore guides for gradient from saved
	  maximizer->likelihood->ProfileGuide(ii);
	  CalcProfile (i, ii);
	  maximizer->likelihood->ProfileGuideRestore ();
          runreport.PrognoseProfiles(thisprofile, numprofiles);
          ++thisprofile;
	}
    }
}




// returns a structure containing a single profile table
// according to ParamStruct *toDolist
// 
void Analyzer::CalcProfile (ParamVector::iterator guide, long pos)
{

  switch(guide->GetProfileType())
  {
    case percentile :
      modifier = forcesummary.GetModifiers();
      CalcProfilePercentile (guide, pos);
      break;
    case fix :
      modifier = forcesummary.GetModifiers();
      CalcProfileFixed (guide, pos);
      break;
    case none :
    {
      ProfileStruct emptyprofile ;
      guide->AddProfile(emptyprofile,maximizer->likelihood->GetTag());
      break;
    }
    default :
      assert(false);
      break;
  }

}

void
  Analyzer::CalcProfileFixed (ParamVector::iterator guide, long pos)
{
  ProfileStruct theprofile;
  newparam = MLEparam;

  vector < double >::const_iterator fix;
  for (fix = modifier.begin ();
       fix != modifier.end (); ++fix)
    {
      ProfileLineStruct profileline;
      newparam[pos] = (*fix) * MLEparam[pos];
      maximizer->likelihood->ProfileGuide (pos);
      profileline.loglikelihood = maximizer->Calculate (newparam);
      maximizer->likelihood->ProfileGuideRestore ();
      profileline.profilevalue = newparam[pos];
      profileline.profparam = maximizer->GetParameters();
      profileline.percentile = (*fix); 
      theprofile.profilelines.push_back(profileline);
      // DEBUG printing:
      //      cout << (*fix) << " > " << maximizer->GetLastLikelihood() << " " << maximizer->GetLastNorm() << endl;
    }
  guide->AddProfile(theprofile,maximizer->likelihood->GetTag());
}

void
  Analyzer::CalcProfilePercentile (ParamVector::iterator guide, long pos)
{
  ProfileStruct theprofile;
  newparam = MLEparam;
  bool firstlow = true;
  bool firsthigh = true;
  double lastxm = FLAGDOUBLE;  // set to avoid compiler warning
  double percent;

  DoubleVec1d percents(modifier);

  vector <ProfileLineStruct> localprofiles;
  unsigned long p;
  unsigned long centerp = 0;  // set to avoid compiler warning
  double maxlike = likelihood;
  long df;
  double perc_like;
  for (p=0; p < modifier.size(); p++) 
    {
      percent = percents[p];
      ProfileLineStruct localprofile;
      if(percent>0.5 && firsthigh)
	{
	  centerp = p;
	  reverse(percents.begin()+p,percents.end());
	  percent = percents[p];
	}

      if(percent!=0.5)
	{
	  df = 1; //degree of freedom is one for profiles
	  perc_like = maxlike  
	    - find_chi(df, (percent > 0.5 ? (1. - percent)*2. : percent * 2.))/2.;
	  double a, m;
	  double xa = 0.0;
	  if(percent < 0.5)
	    {
	      if(firstlow)
		{
		  xa = 1e-20;
		  firstlow=false;
		}
	      else
		xa = lastxm;
	    }
	  else
	    {
	      if(firsthigh)
		{
		  xa = 1e20;
		  firsthigh=false;
		}
	      else
		xa = lastxm ;
	    }
	  newparam[pos] = xa;
	  a = maximizer->Calculate(newparam);
          long counter = 0, MAXCOUNT = 1001;
	  while(a > perc_like && counter++ < 5)
	  {
	    if(percent<0.5)
	      xa /= 1000;
	    else
	      xa *= 1000; 
	    newparam[pos] = xa;
	    a = maximizer->Calculate(newparam);
	  }
	  if(counter>=5)
	    {
	      lastxm = percent < 0.5 ? 1e-20 : 1e20 ;
	      localprofile.loglikelihood = a;
	      localprofile.profilevalue = 0.0;
	      localprofile.profparam = maximizer->GetParameters();
	      localprofile.percentile = percent;
	      localprofiles.push_back(localprofile);
	      // DEBUG printing:
	      //cout << percent << "***" << maximizer->GetLastLikelihood() << " " << maximizer->GetLastNorm() << endl;
	      continue;
	    }
	  double xb = MLEparam[pos];
	  double b = maxlike;
	  double xm = (xb + xa ) / 2.;
	  newparam[pos] = xm;
	  m = maximizer->Calculate(newparam);
	  
// using 2.0*DBL_EPSILON because of "xm = (xb+xa)/2.0"
          const double TWICE_DBL_EPSILON = 10.0 * DBL_EPSILON;
	  while (fabs (m - perc_like) > PERCENTILE_EPSILON && 
                 fabs (xb - xa) > TWICE_DBL_EPSILON &&
		 counter++ < MAXCOUNT)
	    {

		  if (m < perc_like)
		    {
		      a = m;
		      xa = xm;
		    }
		  else
		    {
		      b = m;
		      xb = xm;
		    }

		  xm = (-(a * xb) + perc_like * xb + b * xa - perc_like * xa) / (b - a); 
		  if(fabs(xm-xb)<TWICE_DBL_EPSILON || fabs(xm-xa)<TWICE_DBL_EPSILON)
		    xm = (xb+xa)/2.;
		  newparam[pos] = xm;
		  m = maximizer->Calculate(newparam);
		  //DEBUG printing:  
		  // cout << xm << " " << m << " " << (m-perc_like) << endl;
	    }
	  lastxm = xm;
	  localprofile.loglikelihood = m;
	  localprofile.profilevalue = xm;
          localprofile.profparam = maximizer->GetParameters();
	  localprofile.percentile = percent;
	  localprofiles.push_back(localprofile);
	  // DEBUG printing:
	  //	  cout << percent << " > " << maximizer->GetLastLikelihood() << " " << maximizer->GetLastNorm() << endl;
	}
    }
  reverse(localprofiles.begin()+centerp,localprofiles.end());
  theprofile.profilelines = localprofiles;
  guide->AddProfile(theprofile,maximizer->likelihood->GetTag());
}







