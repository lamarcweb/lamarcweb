// $Id: individual.h,v 1.3 2002/06/25 03:17:56 mkkuhner Exp $

// This files defines the class that stores "individual" specific
// information.

#ifndef INDIVIDUAL
#define INDIVIDUAL

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <vector>
#include <string>
#include "vectorx.h"

class Branch;

class Individual
{
private:
long            id;
LongVec1d       phasemarkers;
string          name;
vector<Branch*> tips;

void CopyAllMembers(const Individual& src);


public:
Individual()                                  {};
~Individual()                                 {};
Individual& operator=(const Individual& src);
Individual(const Individual& src);

LongVec1d       GetPhaseMarkers() const       {return phasemarkers;};
string          GetName()         const       {return name;};
vector<Branch*> GetAllTips()      const       {return tips;};
StringVec1d     GetAllTipNames()  const;
long            GetId()           const       {return id;};
bool            AnyPhaseUnknownSites() const  {return !phasemarkers.empty();};

void            PruneSamePhaseUnknownSites();

void SetPhaseMarkers(const LongVec1d& pm)     {phasemarkers = pm;};
void SetName(const string& newname)           {name = newname;};
void SetTips(vector<Branch*> tps)             {tips = tps;};
void AddTip(Branch* tip)                      {tips.push_back(tip);};
void SetId(long newid)                        {id = newid;};

};

typedef vector<Individual> IndVec;

#endif

