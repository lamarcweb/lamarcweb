//$Id: arranger.cpp,v 1.13 2002/06/26 19:11:55 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "arranger.h"
#include "event.h"
#include "tree.h"
#include "force.h"
#include "forceparam.h"
#include "forcesummary.h"
#include "random.h"

using namespace std;

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif
//___________________________________________________________________________________
//___________________________________________________________________________________

Arranger::Arranger(Random *rs)
{
  randomSource = rs;
  tree         = NULL;
  timing       = 1.0;
} /* Arranger::Arranger */

//__________________________________________________________________

Arranger::Arranger(const Arranger& src)
{
  randomSource = src.randomSource;
  timing = src.timing;
  tree = NULL;
} /* Arranger::Arranger */

//___________________________________________________________________________________
//___________________________________________________________________________________

ResimArranger::~ResimArranger()
{
  ClearEventVec();

} /* ResimArranger::~ResimArranger */

//__________________________________________________________________

ResimArranger::ResimArranger(const ResimArranger& src) : Arranger(src)
{
  vector<Event*>::const_iterator event = src.eventvec.begin();
  vector<Event*>::const_iterator end = src.eventvec.end();
  Event* newevent;
  for( ; event != end; ++event) {
     newevent = (*event)->Clone();
     newevent->SetArranger(*this);
     eventvec.push_back(newevent);
  }   

  nPopulations = src.nPopulations;
  actives = src.actives;
  inactives = src.inactives;
} /* ResimArranger::ResimArranger */

//__________________________________________________________________

void ResimArranger::ClearEventVec()
{

  vector<Event*>::iterator it = eventvec.begin();
  vector<Event*>::iterator end = eventvec.end();
  for ( ; it != end; ++it) {
    delete *it;
  }
  eventvec.clear();

} /* ClearEventVec */

//___________________________________________________________________________________

void ResimArranger::SetForces(const ForceSummary& fs) 
{
  ClearEventVec();
  vector<Force*> forces = fs.GetAllForces();
  vector<Force*>::iterator it = forces.begin();
  vector<Force*>::iterator end = forces.end();

  // get events from each Force

  for ( ; it != end; ++it) {
    vector<Event*> events = (*it)->MakeEvents();
    eventvec.insert(eventvec.end(), events.begin(), events.end());
  }

  // allow each Force to modify the events of other Forces
  // (currently used by Growth, a no-op in other cases)

  for (it = forces.begin(); it != end; ++it) {
    (*it)->ModifyEvents(eventvec);
  }

  // inform each Event of the Arranger for callbacks

  vector<Event*>::iterator event = eventvec.begin();
  vector<Event*>::iterator eventend = eventvec.begin();
  for ( ; event != eventend; ++event) {
    (*event)->SetArranger(*this);
  }

} /* SetEventVec */

//__________________________________________________________________

void ResimArranger::SetParameters(const ForceSummary &forces,
  const ForceParameters& starts)
{

  assert(eventvec.size() != 0);      // *some* events must be possible!

  nPopulations = tree->GetNPopulations();                 

  vector<Event*>::iterator it = eventvec.begin();
  vector<Event*>::iterator end = eventvec.end();

  for ( ; it != end; ++it) {
    (*it)->InstallParameters(forces, starts); 
  }

} /* SetParameters */

//__________________________________________________________________

double ResimArranger::EventTime(Event*& returnevent, double eventT)
{
  actives = tree->ActiveBranches();
  inactives = tree->ContemporaryBranches();

  double time = 0.0;

  vector<Event*>::iterator event;
  map<double,Event *> times;

  for (event = eventvec.begin(); event != eventvec.end(); ++event) {
    time = (*event)->PickTime();
    if (time >= 0.0) times.insert(make_pair(time,*event));
  }

  // the first element in the map is now the smallest, since maps
  // are intrinsically sorted

  if (!times.empty()) {
    map<double,Event*>::const_iterator mapit = times.begin();
    returnevent = (*mapit).second;
    return (*mapit).first;
  } else {
  // there is no way to call an event, so return flags
    returnevent = NULL;     
    return FLAGLONG;
  }

}  /* EventTime */

//__________________________________________________________________

void ResimArranger::DropAll(double eventT)
{
  double time;
  Event* eventptr = NULL;

  while (tree->ActiveSize() > 1)
  {
    time = EventTime(eventptr, eventT);
    if (time > 0.0) {
      assert(eventptr != NULL);
      eventT += time;
      eventptr->DoEvent(eventT);
    }
  }

  tree->AttachBase();
} /* DropAll */

//__________________________________________________________________

void ResimArranger::DeNovoTree()
{
  tree->ActivateTips();
  DropAll(0.0);
} /* DeNovoTree */

//__________________________________________________________________

double ResimArranger::Activate()
{
  return tree->ActivateBranch()->eventtime;

} /* Activate */

//__________________________________________________________________

void ResimArranger::Resimulate(double eventT)
{
  double nextT, time;
  Event* eventptr;

  double rootT = tree->GetTimeList().Root()->eventtime;
  nextT = tree->FirstInterval(eventT);

// The following loop resimulates lineages down the tree.
// It will terminate when the Event objects agree that no
// more events are possible, or when the root is reached,
// at which point DropAll is invoked.

  while (1) {

    // poll the Event objects to see if we're done yet

    if (StopNow()) return;       

    time = EventTime(eventptr, eventT);

    // if an event is possible, we test to see if it happens
    // and carry it out if so.  If an event happens
    // we return to the top of the loop while remaining in the
    // same interval, since further events may occur.

    if (time > 0.0) {
      eventT += time;
      if (eventT < nextT) {          
        eventptr->DoEvent(eventT);
        continue;
      }
    }

    // if we are at the root, finish up using DropAll()

    if (nextT == rootT) {
      tree->ActivateRoot();
      DropAll(rootT);
      return;
    }
  
    // otherwise go on to the next interval

    eventT = nextT;
    nextT = tree->NextInterval();
  }

} /* Resimulate */

//__________________________________________________________________

bool ResimArranger::StopNow() const
{

  // Poll the Events to see if they are Done().  If any are
  // not, return false.

  vector<Event*>::const_iterator event = eventvec.begin();
  vector<Event*>::const_iterator end = eventvec.end();
 
  for ( ; event != end; ++event) {
    if (!(*event)->Done()) return false;
  }

  return true;

} /* StopNow */

//__________________________________________________________________

void ResimArranger::Rearrange()
// This is a "template method" giving the steps of rearrangement 
{
  double eventT = Activate();
  Resimulate(eventT);
  tree->Prune();
  assert(tree->IsLegal());

} /* Rearrange */

//__________________________________________________________________

bool ResimArranger::Accept(Tree *oldtree, double temperature, bool badtree)
// WARNING:  We assume that the tips of the tree were not changed, and
// thus we only accept/reject the body of the tree.
{

  if (badtree) {  // reject this tree immediately
    tree->CopyBody(oldtree);
    return false;
  }

  double test = (tree->GetDLValue() - oldtree->GetDLValue()) / temperature;
  test += log(static_cast<double>(oldtree->GetTimeList().GetNCuttable()-1)/
                      (tree->GetTimeList().GetNCuttable()-1));

  if (test < 0.0)
  {
    if (test < log(randomSource->Float())) {   // rejection
      tree->CopyBody(oldtree);
      return false;
    }
  }

  oldtree->CopyBody(tree); // acceptance

  return true;
} /* Accept */

//________________________________________________________________________________
//________________________________________________________________________________

Arranger* DropArranger::Clone() const
{
  Arranger* arr = new DropArranger(*this);
  return arr;

} /* DropArranger::Clone */

//___________________________________________________________________________________
//___________________________________________________________________________________

Arranger* HapArranger::Clone() const
{
  Arranger* arr = new HapArranger(*this);
  return arr;

} /* HapArranger::Clone */

//___________________________________________________________________________________

void HapArranger::SetParameters(const ForceSummary &, const
   ForceParameters&)
{
  // WARNING:  This seems to be a no-op, but is it really?
}

//__________________________________________________________________

void HapArranger::DeNovoTree()
{
  // This routine does not exist, and may never exist.  The first
  // arranger in a set of arrangers must be one capable of making
  // a denovo tree, and this one isn't.

  assert(false);
} /* DeNovoTree */

//__________________________________________________________________

void HapArranger::Rearrange()
{
  tree->SwapSiteDLs();
  assert(tree->IsLegal());
}

//__________________________________________________________________

bool HapArranger::Accept(Tree *oldtree, double temperature, bool badtree)
// We copy the full tree, as we may have changed the tips as well
// as the state of internal nodes (i.e. by changing DLCells).
{

  if (badtree) {   // reject this tree immediately
    tree->CopyTips(oldtree);
    tree->CopyBody(oldtree);
    return false;
  }

  double test = (tree->GetDLValue() - oldtree->GetDLValue()) / temperature;

  if (test < 0.0)
  {
    if (test < log(randomSource->Float())) {
      tree->CopyTips(oldtree);
      tree->CopyBody(oldtree);
      return false;
    }
  }

  oldtree->CopyTips(tree);
  oldtree->CopyBody(tree);
  return true;
}

//___________________________________________________________________________________
//___________________________________________________________________________________

#if 0
// DEBUG WARNING commented out by Mary; see explanation in .h

Arranger* TimeArranger::Clone() const
{
  Arranger* arr = new TimeArranger(*this);
  return arr;

} /* TimeArranger::Clone */

//___________________________________________________________________________________

void TimeArranger::SetParameters(const ForceSummary& forces, const
  ForceParameters& starts)
{
  // DEBUG not filled in yet
}

//___________________________________________________________________________________
//___________________________________________________________________________________

Arranger* RecSiteArranger::Clone() const
{
  Arranger* arr = new RecSiteArranger(*this);
  return arr;

} /* RecSiteArranger */

#endif
