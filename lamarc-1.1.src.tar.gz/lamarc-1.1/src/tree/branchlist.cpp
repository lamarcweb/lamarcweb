// $Id: branchlist.cpp,v 1.12 2002/06/25 03:17:54 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "branchlist.h"
#include "stringx.h" // for access to Pretty() in Printtimelist()
                     //     also for ToString() in Printtreelist()
#include <set>       // for Printtreelist()

using namespace std;

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif
//____________________________________________________________________________
//____________________________________________________________________________
// TimeList constructor

TimeList::TimeList()
{
base.eventtime = DBL_MAX;
lasttip        = branches.begin();

// DEBUG debug WARNING warning
ntips = ncuttable = 0;

} /* TimeList::TimeList */

//____________________________________________________________________________

TimeList::TimeList(const TimeList& src)
{

CopyTips(src);
CopyBody(src);

} /* TimeList copy ctor */

//____________________________________________________________________________

TimeList& TimeList::operator=(const TimeList& src)
{

CopyTips(src);
CopyBody(src);

return *this;

} /* TimeList::operator= */

//____________________________________________________________________________

TimeList::~TimeList()
{
Branchiter brit;

for(brit = branches.begin(); brit != branches.end(); ++brit)
   delete *brit;

} /* TimeList::~TimeList */

//____________________________________________________________________________

void TimeList::Clear()
{
Branchiter brit;

for(brit = branches.begin(); brit != branches.end(); ++brit)
   delete *brit;

branches.clear();
lasttip = branches.begin();

// DEBUG debug WARNING warning
ntips = ncuttable = 0;
ClearBranchCount();

} /* TimeList::Clear */

//____________________________________________________________________________

void TimeList::ClearBody()
{
Branchiter brit;

ClearBranchCount();    // clears all branches from counter
for(brit = branches.begin(); brit != BeginBody(); ++brit) {
   (*brit)->parent[0] = (*brit)->parent[1] = NULL;
   CountBranch((*brit)->Event());    // re-introduces tips only
}

for( ; brit != branches.end(); ++brit)
   delete *brit;

branches.erase(BeginBody(),branches.end());
ncuttable = branches.size();

} /* TimeList::ClearBody */

//____________________________________________________________________________

#if 0
-- will be in v2 as an optimization
void TimeList::ClearPartialBody(branchiter firstinvalid)
{

Branchiter brit;
long ch, pa;

// set all parent pointers pointing to dying branches to NULL
for (brit = firstinvalid; brit != branches.end(); ++brit) {
  Branch* thebranch = *brit;
  for (ch = 0; ch < NELEM; ++ch) {
    Branch* thischild = thebranch->child[ch];
    if (thischild) { // the child exists
      for (pa = 0; pa < NELEM; ++pa) {
        Branch* thisparent = thischild->parent[pa];
        if (thisparent == thebranch) thischild->parent[pa] = NULL;
      }
    }
  }
}

// delete the dying branches.  (We don't do this on the previous
// pass because we might dereference a deleted branch.)
for (brit = firstinvalid; brit != branches.end(); ++brit) {
  delete *brit;
  *brit = NULL;
}

// erase deleted entries
branches.erase(firstinvalid, branches.end());

// re-count the remaining branches
 
ClearBranchCount();
for (brit = branches.begin(); brit != branches.end(); ++brit) {
  CountBranch((*brit)->Event());
}

} /* ClearPartialBody */

#endif
//____________________________________________________________________________

TBranch* TimeList::CreateTip()
{
TBranch *ptip = new TBranch;
branches.push_front(ptip);
if (branches.size() == 1) {
   lasttip = branches.begin();
}
++ntips;
ncuttable += ptip->Cuttable();
CountBranch(ptip->Event());

return ptip;

} /* TimeList::CreateTip */

//____________________________________________________________________________

TBranch* TimeList::GetTip(string tipname) const
{
TBranch* ptip = NULL;

Branchconstiter brit;
for(brit = branches.begin(); brit != branches.end(); ++brit) {
   if ((*brit)->Event() != TIP) continue;
   ptip = dynamic_cast<TBranch*>(*brit);
   if (ptip->label == tipname) break;
}

assert(brit != branches.end());

return ptip;

} /* TimeList::GetTip */

//____________________________________________________________________________

void TimeList::CopyTips(const TimeList &src)
{
this->Clear();
Branchconstiter brit;

for(brit = src.GetLastTip(); brit != src.Begin(); --brit) {
   branches.push_front((*brit)->Clone());
   this->CountBranch((*brit)->Event());
   if (brit == src.GetLastTip())
      lasttip = Begin();
}
// the reverse iteration doesn't get the very first tip....
branches.push_front((*brit)->Clone());
this->CountBranch((*brit)->Event());

ntips = src.ntips;

} /* TimeList::CopyTips */

//____________________________________________________________________________

// assuming the srclist == newlist, search for the source child
// in the source list, then return the new list equivalent of that
// child.

// WARNING:  This routine assumes that the srclist and newlist are
// in the exact same order!

Branch* TimeList::FindEquivChild(const Branch* child,
   const Branchlist& srclist, Branchlist& newlist)
{
Branchconstiter srcit;
Branchiter newit;
for(srcit = srclist.begin(), newit = newlist.begin();
    srcit != srclist.end(); ++srcit, ++newit)
   if (child == *srcit) return *newit;

assert(false);

return NULL;

} /* TimeList::FindEquivChild */

//____________________________________________________________________________

// CopyBody() assumes that the tips of src and *this are identical!
// It also assumes that no internal node of the tree has both, 2 parents
// and 2 children.
void TimeList::CopyBody(const TimeList &src)
{
ClearBody();

Branch *newbranch;
Branchconstiter brit = src.BeginBody();

// if the src tree has no body, we will not attempt to copy it
// nor to hook up the Base.  Given an incomplete tree, we return
// an incomplete tree.  Mary August 2001

if (brit != src.End()) {
   for(brit = src.BeginBody(); brit != src.End(); ++brit) {
      newbranch = (*brit)->Clone();
      Branch* srcchild = (*brit)->child[0];

      Branch* newchild = FindEquivChild(srcchild,src.branches,branches);
      newbranch->child[0] = newchild;

      if (srcchild->parent[0] == *brit) {
         newchild->parent[0] = newbranch;
         srcchild = (*brit)->child[1];
         if (srcchild) {
            newchild = FindEquivChild(srcchild,src.branches,branches);
            newbranch->child[1] = newchild;
            newchild->parent[0] = newbranch;
         }
      } else
         newchild->parent[1] = newbranch;

      branches.push_back(newbranch);
   }

   base.child[0] = newbranch;
   newbranch->parent[0] = &base;
}

ncuttable = src.ncuttable;
branchmap = src.branchmap;

} /* TimeList::CopyBody */

//____________________________________________________________________________

#if 0
-- will be in v2 as a speed optimization
void TimeList::CopyPartialBody(const TimeList &src)
{
// This differs from CopyBody in that it only copies the part of the 
// TimeList that differs between this and src, as an optimization.

ClearBody();

Branch *newbranch;
Branchconstiter brit = src.BeginBody();

// if the src tree has no body, we will not attempt to copy it
// nor to hook up the Base.  Given an incomplete tree, we return
// an incomplete tree.  Mary August 2001

if (brit != src.End()) {
   for(brit = src.BeginBody(); brit != src.End(); ++brit) {
      newbranch = (*brit)->Clone();
      Branch* srcchild = (*brit)->child[0];

      Branch* newchild = FindEquivChild(srcchild,src.branches,branches);
      newbranch->child[0] = newchild;

      if (srcchild->parent[0] == *brit) {
         newchild->parent[0] = newbranch;
         srcchild = (*brit)->child[1];
         if (srcchild) {
            newchild = FindEquivChild(srcchild,src.branches,branches);
            newbranch->child[1] = newchild;
            newchild->parent[0] = newbranch;
         }
      } else
         newchild->parent[1] = newbranch;

      branches.push_back(newbranch);
   }

   base.child[0] = newbranch;
   newbranch->parent[0] = &base;
}

ncuttable = src.ncuttable;
branchmap = src.branchmap;

} /* TimeList::CopyBody */

#endif

//____________________________________________________________________________

void TimeList::AddAfter(Branchiter here, Branch* newbranch)
{
++here;
branches.insert(here,newbranch);
ncuttable += newbranch->Cuttable();
CountBranch(newbranch->Event());

} /* TimeList::AddAfter */

//____________________________________________________________________________

void TimeList::Collate(Branch* newbranch)
{

// Degenerate collate into an empty list
if (branches.empty()) {
  branches.push_front(newbranch);
  ncuttable = newbranch->Cuttable();
  ClearBranchCount();
  CountBranch(newbranch->Event());
  return;
}

// Regular collate
Branchiter br = branches.begin();

// Catch insertion before the first entry
if ((*br)->eventtime > newbranch->eventtime) {
  branches.push_front(newbranch);
  ncuttable += newbranch->Cuttable();
  CountBranch(newbranch->Event());
  return;
}

// Insertion after an entry
Branchiter end = branches.end();
Branchiter previous = br;
br++;      // first entry has been taken care of already

for ( ; br != end; ++br) {
  if ((*br)->eventtime > newbranch->eventtime) break;
  previous = br;
} 

// we rely on flowthrough for the case where this will be the
// new bottommost branch.

AddAfter(previous, newbranch);

} /* TimeList::Collate */

//____________________________________________________________________________

void TimeList::Remove(Branch* badbranch)
{

branches.remove(badbranch);
ncuttable -= badbranch->Cuttable();
UncountBranch(badbranch->Event());
delete badbranch;

} /* TimeList::Remove */

//____________________________________________________________________________

void TimeList::Prune()
{
// Excise marked branches.
Branchiter brit;
for(brit = BeginBody(); brit != End();) {
   Branch* pbranch = *brit;
   if (pbranch->marked) {
      Branch* pparent = pbranch->parent[0];
      pparent->ReplaceChild(pbranch,pbranch->child[0]);
      SetUpdateDLs(pparent);

      pparent = pbranch->parent[1];
      if (pparent) {
         pparent->ReplaceChild(pbranch,pbranch->child[0]);
         SetUpdateDLs(pparent);
      }
      ++brit;
      Remove(pbranch);  // deletes what pbranch points to
      continue;
   }
   ++brit;
}

// Check for loops in the root.
long nbranches = 2*ntips;
for(brit = BeginBody(); ;++brit) {
   nbranches += (*brit)->CountDown();
   if (nbranches <= 2) break;
}
if (*brit != Root()) {
   base.child[0]     = *brit;
   (*brit)->parent[0] = &base; 
   (*brit)->parent[1] = NULL;

   //branches.erase_after(brit,branches.end());
   for(++brit; brit != branches.end(); ) {
      Branch* pbranch = *brit;
      ++brit;
      Remove(pbranch);
   }
}

} /* TimeList::Prune */

//____________________________________________________________________________

void TimeList::SetUpdateDLs(Branch *pBranch)
{

if (pBranch->Event() == BASE) return;  // the base terminates recursion

if (!pBranch->GetUpdateDL()) {
   pBranch->SetUpdateDL();
   SetUpdateDLs(pBranch->parent[0]);
   if (pBranch->parent[1])
      SetUpdateDLs(pBranch->parent[1]);
}

} /* TimeList::SetUpdateDLs */

//____________________________________________________________________________

void TimeList::SetAllUpdateDLs()
// marks the entire tree as needing updating--a debug function.
{
  Branchiter brit;
  for (brit = branches.begin(); brit != branches.end(); ++brit)
    (*brit)->SetUpdateDL();

} /* SetAllUpdateDLs() */

//____________________________________________________________________________

void TimeList::ClearUpdateDLs()
{
Branchiter brit;
for(brit = branches.begin(); brit != branches.end(); ++brit)
   (*brit)->ClearUpdateDL();

} /* TimeList::ClearUpdateDLs */

//____________________________________________________________________________

void TimeList::Printtimelist()
{

cout << endl;
cout << " New tree start " << endl;
vector<Branch*> endbranch;
vector<Branch*>::iterator br;
Branchiter branch;
double tyme = 0.0;
bool newinterval = true;
for(branch = Begin(); branch != End();) {
   if (newinterval) cout << Pretty(tyme) << ": branch(s) ";
   if ((*branch)->eventtime == tyme) {
      cout << (*branch)->ID[0] << (*branch)->ID[1];
      cout << (*branch)->Event();
      (*branch)->range.PrintActives();
      (*branch)->range.PrintNewActives();
      cout << (*branch)->GetUpdateDL();
      cout << " ";
      long site;
      cout << endl;
      if ((*branch)->Event() == TIP) {
      for(site = 0; site < 4; ++site) {
         DNACell* pcell = dynamic_cast<DNACell*>((*branch)->dlcell[0].get());
         cout << "   " << Pretty(pcell->GetSiteDLs(site)[0][baseA]);
         cout << "   " << Pretty(pcell->GetSiteDLs(site)[0][baseC]);
         cout << "   " << Pretty(pcell->GetSiteDLs(site)[0][baseG]);
         cout << "   " << Pretty(pcell->GetSiteDLs(site)[0][baseT]);
         cout << endl;
      }
      }
      newinterval = false;
   } else {
      cout << "start" << endl;
      newinterval = true;
      if (!endbranch.empty()) {
         cout << "      branch(s) ";
         for(br = endbranch.begin(); br != endbranch.end(); ++br) {
            if (*br != NULL) {
               cout << (*br)->ID[0] << (*br)->ID[1];
               cout << (*br)->Event();
               (*br)->range.PrintActives();
               (*br)->range.PrintNewActives();
               cout << (*br)->GetUpdateDL();
               cout << " ";
            }
         }
         cout << " end" << endl;
      }
      endbranch = (*branch)->child;
      tyme = (*branch)->eventtime;
      continue;
   }
   ++branch;
}

// catch the branches that end at the root
cout << endl << "      branch(s) ";
for(br = endbranch.begin(); br != endbranch.end(); ++br) {
   if (*br != NULL) {
      cout << (*br)->ID[0] << (*br)->ID[1];
      cout << (*br)->Event();
      (*br)->range.PrintActives();
      (*br)->range.PrintNewActives();
      cout << (*br)->GetUpdateDL();
      cout << " ";
   }
}
cout << " end at the root" << endl;

} /* TimeList::Printtimelist */

//____________________________________________________________________________

void TimeList::Printtreelist()
{
set<string> branches;

Branchconstiter branch = Begin();
cout << ToString((*branch)->ID[0])+ToString((*branch)->ID[1]);
cout << (*branch)->Event() << "/" << (*branch)->eventtime << ":";
for(branch = Begin(); branch != BeginBody(); ++branch) {
   string id = ToString((*branch)->ID[0])+ToString((*branch)->ID[1]);
   branches.insert(id);
   cout << " " << id;
}
cout << endl;

for(branch = BeginBody(); branch != End(); ++branch) {
   string id = ToString((*branch)->ID[0])+ToString((*branch)->ID[1]);
   string event = (*branch)->Event();
   cout << id << event << "/" << (*branch)->eventtime;

   string chid = ToString((*branch)->child[0]->ID[0])
                + ToString((*branch)->child[0]->ID[1]);
   branches.erase(chid);
   branches.insert(id);

   if (event == COAL) {
         cout << ":";
         chid = ToString((*branch)->child[1]->ID[0])
               + ToString((*branch)->child[1]->ID[1]);
         branches.erase(chid);
    } else if (event == REC) {
         ++branch;
         id = ToString((*branch)->ID[0])+ToString((*branch)->ID[1]);
         event = (*branch)->Event();
         cout << "/" << id << event << ":";
         branches.insert(id);
    } else if (event == MIG) {
         cout << ":";
    } else assert(false); // unknown branch type
   set<string>::iterator br;
   for(br = branches.begin(); br != branches.end(); ++br)
      cout << " " << *br;
   cout << endl;
}

cout << "End of Tree" << endl;

} /* TimeList::Printtreelist() */

//____________________________________________________________________________

void TimeList::Printtips()
{
cout << endl;
cout << " The tips are " << endl;
Branchiter branch;
for(branch = Begin(); branch != BeginBody(); ++branch) {
   TBranch* tip = dynamic_cast<TBranch*>(*branch);
   cout << "   " << tip->label << " with id#";
   LongVec1d::iterator num;
   for(num = tip->ID.begin(); num != tip->ID.end(); ++num)
      cout << *num;
   cout << endl;
}
cout << "End tips" << endl;


} /* TimeList::Printtips */

//____________________________________________________________________________

void TimeList::MakeCoalescent(double theta)
{
assert (HowMany(MIG) == 0);

long nbranches = GetNTips();

Branchiter branch;
for(branch = BeginBody(); branch != End(); ++branch) {
   assert(nbranches > 0);

   (*branch)->eventtime = theta/(nbranches * (nbranches-1));
   --nbranches;
}

} /* TimeList::MakeCoalescent */

//____________________________________________________________________________

string TimeList::DLCheck(const TimeList& other) const
{

long ncoals = HowMany(COAL), otherncoals = other.HowMany(COAL);
if (ncoals != otherncoals)
   return string("The trees differ in number of coalescences!\n");

string problems;
Branchconstiter branch, otherbranch;
for(branch = Begin(), otherbranch = other.Begin();
    branch != End() && otherbranch != other.End();
    ++branch, ++otherbranch) {
   problems += (*branch)->DLCheck(**otherbranch);
}

return problems;

} /* TimeList::DLCheck */

//____________________________________________________________________________
// The following functions manage the counters for branches of each
// type.
//____________________________________________________________________________

void TimeList::CountBranch(const string& tag) 
{
  BranchMap::iterator it = branchmap.find(tag);
  if (it == branchmap.end()) {     // entry not found
    branchmap.insert(make_pair(tag, 1L));
  } else {
    (*it).second++;
  }

} /* CountBranch */

//____________________________________________________________________________

void TimeList::UncountBranch(const string& tag)
{
  BranchMap::iterator it = branchmap.find(tag);
  assert(it != branchmap.end());  // why are we trying to remove
                                  // a branch type that isn't there?
  (*it).second--;
  assert((*it).second >= 0);      // why are we trying to remove
                                  // a branch that isn't there?
} /* UncountBranch */

//____________________________________________________________________________

void TimeList::ClearBranchCount()
{
// we don't get rid of entries, since they may be useful
// later when the same kind of branch comes round again.

  BranchMap::iterator it = branchmap.begin();
  BranchMap::iterator end = branchmap.end();

  for ( ; it != end; ++it) {
    (*it).second = 0L;
  }

} /* ClearBranchCount */

//____________________________________________________________________________

long TimeList::HowMany(const string& tag) const
{
  BranchMap::const_iterator it = branchmap.find(tag);
  if (it == branchmap.end()) // entry not found
    return 0L;
  else return (*it).second;

} /* HowMany */

//____________________________________________________________________________

bool TimeList::operator==(const TimeList& src) const
{
  if (branchmap != src.branchmap) return false;
  if (ntips != src.ntips) return false;
  if (ncuttable != src.ncuttable) return false;

  if (branches.size() != src.branches.size()) return false;

  Branchconstiter mybr = branches.begin();
  Branchconstiter srcbr = src.branches.begin();

  for ( ; mybr != branches.end(); ++mybr, ++srcbr) {
    if (**mybr != **srcbr) return false;
  }

  return true;

} /* operator== */

//____________________________________________________________________________
//____________________________________________________________________________

BranchBuffer::BranchBuffer(long npops)
{

long zero = 0;
branchpops = CreateVec1d(npops,zero);

} /* BranchBuffer::BranchBuffer */

//____________________________________________________________________________

void BranchBuffer::Clear()
{
branches.clear();

// branchpops.assign(branchpops.size(),0L);
fill(branchpops.begin(),branchpops.end(),0L);

} /* BranchBuffer::Clear */

//____________________________________________________________________________

void BranchBuffer::Append(Branch* newbranch)
{

// OPTIMIZE -- should we change to list push_back?
branches.insert(branches.end(),newbranch);

assert(newbranch->population >= 0 && newbranch->population < 
  static_cast<long>(branchpops.size()));

branchpops[newbranch->population]++;

} /* BranchBuffer::Append */

//____________________________________________________________________________

void BranchBuffer::AddAfter(Branchiter here, Branch* newbranch)
{

// debug DEBUG warning WARNING--assume that we can keep time sorted
//    ordering by simple append after here.
++here;
branches.insert(here,newbranch);
branchpops[newbranch->population]++;

} /* BranchBuffer::AddAfter */

//____________________________________________________________________________

void BranchBuffer::Collate(Branch* newbranch)
{

// Degenerate collate into an empty list
if (branches.empty()) {
  branches.push_front(newbranch);
  branchpops[newbranch->population]++;
  return;
}

// Regular collate
Branchiter br = branches.begin();

// Catch insertion before the first entry
if ((*br)->parent[0]->eventtime > newbranch->parent[0]->eventtime) {
  branches.push_front(newbranch);
  branchpops[newbranch->population]++;
  return;
}

// Insertion after an entry
Branchiter end = branches.end();
Branchiter previous = br;
br++;      // first entry has been taken care of already

for ( ; br != end; ++br) {
  if ((*br)->parent[0]->eventtime > newbranch->parent[0]->eventtime) break;
  previous = br;
}

// we rely on flowthrough for the case where this will be the
// new bottommost branch.

AddAfter(previous, newbranch);

} /* BranchBuffer::Collate */

//____________________________________________________________________________

void BranchBuffer::Remove(Branchiter here)
{
branchpops[(*here)->population]--;
branches.erase(here);

} /* BranchBuffer::Remove */

//____________________________________________________________________________

Branch* BranchBuffer::GetFirst()
{
return branches.front();

} /* BranchBuffer::GetFirst */

//____________________________________________________________________________

Branch* BranchBuffer::RemoveFirst()
{
Branch* pbranch = GetFirst();
branches.pop_front();
branchpops[pbranch->population]--;

return pbranch;

} /* BranchBuffer::RemoveFirst */

//____________________________________________________________________________

Branch* BranchBuffer::RemoveBranch(long pop, double rnd)
{
long count = static_cast<long>(rnd * branchpops[pop]);

Branchiter brit;
for(brit = branches.begin(); brit != branches.end(); ++brit)
   if ((*brit)->population == pop) {
      if (!count) break;
      --count;
   }

assert(count == 0); // didn't find a branch

// branches.remove(*brit); but need operator== for branch
Branchlist temp;
temp.splice(temp.end(),branches,brit);
branchpops[pop]--;

return *brit;

} /* BranchBuffer::RemoveBranch */

//____________________________________________________________________________

double BranchBuffer::IntervalBottom()
{
return GetFirst()->parent[0]->eventtime;

} /* BranchBuffer::IntervalBottom() */
