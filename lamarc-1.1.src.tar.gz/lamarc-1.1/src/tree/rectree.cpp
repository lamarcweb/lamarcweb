//$Id: rectree.cpp,v 1.6 2002/06/25 03:17:57 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "tree.h"
#include "range.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//___________________________________________________________________________

RecTree::RecTree(Random *rs, long npop) : Tree(rs, npop)
{
  activeLinks = 0;
  openLinks   = 0;
}

//____________________________________________________________________________

RecTree::RecTree(const RecTree &tree, bool makestump) : Tree(tree, makestump)
{
  activeLinks = 0;
  openLinks   = 0;
}

//____________________________________________________________________________

Tree *RecTree::Clone() const
{
  RecTree *tree = new RecTree(*this,false);
  return tree;
}

//____________________________________________________________________________

Tree *RecTree::MakeStump() const
{
  RecTree *tree = new RecTree(*this,true);
  return tree;
}

//____________________________________________________________________________

void RecTree::Clear()
{
  Tree::Clear();
  activeLinks = 0;
  openLinks   = 0;
}

//____________________________________________________________________________

void RecTree::CopyTips(const Tree *tree)
{
  Tree::CopyTips(tree);
  activeLinks = 0;
  openLinks   = 0;
}

//____________________________________________________________________________

void RecTree::CopyBody(const Tree *tree)
{
  Tree::CopyBody(tree);
  activeLinks = 0;
  openLinks   = 0;
}

//____________________________________________________________________________

void RecTree::RecurseBreak(Branch *pBranch)
{
  Branch* pParent = pBranch->parent[0];

  if (pParent->CanRemove(pBranch))
  {
    RecurseBreak(pParent);                                  // Recursion
    timelist.Remove(pParent);

    pParent = pBranch->parent[1];
    if (pParent)
    {
      RecurseBreak(pParent);                                // Recursion
      timelist.Remove(pParent);
    }
  }

}

//____________________________________________________________________________

void RecTree::Break(Branch *pBranch)
{
  Branch* pParent = pBranch->parent[0];

  // now update the activesite and newlyactivesite information
  if (pParent->Event() != COAL)
    pParent->UpdateRange(nsites);
  else {
    Branch* br = dynamic_cast<CBranch*>(pParent)->OtherChild(pBranch);
    pParent->range.UpdateMRange(br->range,nsites);
  }
  UpdateRange(pParent);

  if (pParent->CanRemove(pBranch))
  {
    RecurseBreak(pParent);
    timelist.Remove(pParent);

    pParent = pBranch->parent[1];
    if (pParent)
    {
      RecurseBreak(pParent);
      timelist.Remove(pParent);
    }
  }

}

//____________________________________________________________________________

void RecTree::ActivateTips()
{
  Tree::ActivateTips();
  activeLinks = timelist.GetNTips() * (nsites - 1);  // -1 because there is
                                                     // no link after last site
  openLinks = 0;
}

//____________________________________________________________________________

Branch *RecTree::ActivateBranch()
{
  Branch *pActive = Tree::ActivateBranch();
  activeLinks += pActive->range.ActiveLinks();
  return pActive;
}

//____________________________________________________________________________

Branch *RecTree::ActivateRoot()
{
  Branch *pRoot = Tree::ActivateRoot();
  activeLinks += pRoot->range.ActiveLinks();
  openLinks = 0;
  return pRoot;
}

//____________________________________________________________________________

void RecTree::AttachBase()
{
  Tree::AttachBase();
  activeLinks = 0;
}

//____________________________________________________________________________

void RecTree::UpdateRange(Branch *pBranch)
{
  Branch *pParent = pBranch->parent[0];
  if (pParent == timelist.Base())
    return;

  if (pParent->UpdateRange(nsites))
    UpdateRange(pParent);

  pParent = pBranch->parent[1];
  if (pParent)
    if (pParent->UpdateRange(nsites))
      UpdateRange(pParent);
}

//____________________________________________________________________________

double RecTree::FirstInterval(double eventT)
{
  Branch *pBranch;

  double nextT = Tree::FirstInterval(eventT);

  // Initialize the count of open links.
  Branchiter brit;
  for (brit = intervallist.Begin(); brit != intervallist.End(); ++brit)
  {
    pBranch = *brit;
    openLinks += pBranch->range.NewActiveLinks();
  }

  // Update the the site ranges in the lineage below the break.
  for (brit = timelist.BeginBody(); brit != timelist.End(); ++brit)
  {
    pBranch = *brit;
    if (pBranch->marked)
    {
      if (pBranch->UpdateRange(nsites))
        UpdateRange(pBranch);
    }
  }
  return nextT;
}

//____________________________________________________________________________

double RecTree::NextInterval()
{
  // Remove first branch from contemporary list.
  Branch *pBranch = intervallist.RemoveFirst(); 

  // Insert the parent into the contemporary list.
  Branch *pParent = pBranch->parent[0];
  intervallist.Collate(pParent);  

  openLinks -= pParent->child[0]->range.NewActiveLinks();
  openLinks += pParent->range.NewActiveLinks();

  // if the branch has a sibling, remove it
  if (pParent->child[1])       
  {
    intervallist.RemoveFirst();  
    openLinks -= pParent->child[1]->range.NewActiveLinks();
  }

  // if the branch has a second parent, insert it
  else if (pBranch->parent[1])             
  {
    pParent = pBranch->parent[1];
    intervallist.Collate(pParent);        
    openLinks += pParent->range.NewActiveLinks();
  }

  // Return the time at the bottom of the current interval.
  return intervallist.IntervalBottom();
}

//____________________________________________________________________________

void RecTree::Prune()
{
  Branch *pBranch, *pChild;

  openLinks = 0;

  Branchiter brit;
  for (brit = timelist.BeginBody(); brit != timelist.End(); )
  {
    // Remove branches that have no active sites
    pBranch = *brit;
    // clean up old range information
    rangeset emptyrange;
    pBranch->range.SetOldsites(emptyrange);
    pBranch->range.SetNewactivesites(emptyrange);

    if (pBranch->range.NoActivesites())
    {
      pChild = pBranch->child[0];
      if (pChild->parent[0] == pBranch)
        pChild->parent[0] = pChild->parent[1];
      pChild->parent[1] = NULL;
      pChild->parent[0]->marked = true;
      RecurseBreak(pBranch);     // must be called in the order
      ++brit;                    // RecurseBreak() then iterator set then
      timelist.Remove(pBranch);  // list removal since RecurseBreak() may
    }                            // invalidate iterators

    else
    {
      pBranch->range.ClearOldSites();
      ++brit;
    }
  }

  Tree::Prune();

}

//____________________________________________________________________________

Branch* RecTree::CoalesceActive(double eventT, long pop, long
  maxEvents)
{
  Branch *pBranch = Tree::CoalesceActive(eventT, pop, maxEvents);

  pBranch->range.SetCRange(pBranch->child[0]->range,
                           pBranch->child[1]->range);
  rangeset emptyset;
  pBranch->range.SetNewactivesites(emptyset);

  activeLinks -= pBranch->child[0]->range.ActiveLinks();
  activeLinks -= pBranch->child[1]->range.ActiveLinks();
  activeLinks += pBranch->range.ActiveLinks();
  return pBranch;
}

//____________________________________________________________________________

Branch *RecTree::CoalesceInactive(double eventT, long pop, long
  maxEvents)
{
  Branch *pBranch = Tree::CoalesceInactive(eventT, pop, maxEvents);

  pBranch->range.SetCRange(pBranch->child[0]->range,
                           pBranch->child[1]->range);

  pBranch->range.SetOldsites(pBranch->child[0]->range, nsites);

  if (!pBranch->HasSameActive(*(pBranch->child[0])))
  {
    UpdateRange(pBranch);
  }

  openLinks   -= pBranch->child[0]->range.NewActiveLinks();
  activeLinks -= pBranch->child[1]->range.ActiveLinks();
  openLinks   += pBranch->range.NewActiveLinks();
  return pBranch;
}

//____________________________________________________________________________

Branch *RecTree::Migrate(double eventT, long frompop, long topop,
  long maxEvents)
{
  Branch *pBranch = Tree::Migrate(eventT, frompop, topop, maxEvents);

  pBranch->range.SetMRange(pBranch->child[0]->range);

  // a migration does not change the active or newly active links
  rangeset emptyset;
  pBranch->range.SetNewactivesites(emptyset);

  return pBranch;
}

//____________________________________________________________________________

Branch *RecTree::RecombineActive(double eventT, long maxEvents)
{
  Branch *pActive;                       // Active branch chosen for recombination
  Branch *pParentA, *pParentB;           // Two new parents of the active branch
  long    pop, rec, rn, n;

  if (timelist.HowMany(REC) >= maxEvents) {
    rec_overrun e;
    throw e;
  }

  // Pick an active branch and recombination site at random.
  rn = randomSource->Integer(activeLinks);
  Branchiter brit;
  for (brit = activelist.Begin(); ; ++brit)
  {
    pActive = *brit;
    n = pActive->range.ActiveLinks();
    if (n > rn) break;   // found it!
    rn -= n;
  }

  activelist.Remove(brit);
  pop = pActive->population;
  rec = pActive->range.GetFirstActivesite() + rn;

  // Create the left parent of the active branch.  ---------------
  rangepair recSite;

  pParentA = new RBranch;
  AssignID(pParentA);
  pParentA->eventtime  = eventT;              // Set the event time.
  pParentA->population = pop;
  pParentA->child[0]    = pActive;
  pActive->parent[0]    = pParentA;
  recSite.first        = 0;
  recSite.second       = rec + 1;             // half open interval
  assert(recSite.first < recSite.second);
  pParentA->range.SetRRange(pActive->range, recSite);
  rangeset emptyset;
  pParentA->range.SetNewactivesites(emptyset);

  // Create the right parent of the active branch.  ---------------
  pParentB = new RBranch;
  AssignID(pParentB);
  pParentB->eventtime  = eventT;              // Set the event time.
  pParentB->population = pop;
  pParentB->child[0]    = pActive;
  pActive->parent[1]    = pParentB;
  recSite.first         = rec + 1;            // half open interval
  recSite.second        = nsites;
  assert(recSite.first < recSite.second);
  pParentB->range.SetRRange(pActive->range, recSite);
  pParentB->range.SetNewactivesites(emptyset);

  timelist.Collate(pParentA);
  timelist.Collate(pParentB);
  activelist.Append(pParentA);                // Append this parent to the active list.
  activelist.Append(pParentB);                // Append this parent to the active list.

  activeLinks -= pActive->range.ActiveLinks();
  activeLinks += pParentA->range.ActiveLinks();
  activeLinks += pParentB->range.ActiveLinks();
  return pActive;
}

//____________________________________________________________________________

Branch *RecTree::RecombineInactive(double eventT, long maxEvents)
{
  Branch *pBranch = NULL;                     // Inactive branch chosen for recombination
  Branch *pParentA, *pParentB;                // Two new parents of the inactive branch
  long    pop, ndx, rn, n, s1, s2;
  long    rec = 0;

  if (timelist.HowMany(REC) >= maxEvents) {
    rec_overrun e;
    throw e;
  }

  // Pick an open branch and recombination site at random.
  rn = randomSource->Integer(openLinks);
  Branchiter brit;
  for (brit = intervallist.Begin(); ; ++brit)
  {
    pBranch = *brit;
    n = pBranch->range.NewActiveLinks();
    if (n > rn) break;      // found it!
    rn -= n;
  }

  // at this point "rn" contains the index, counting from 0, of the
  // desired site on branch pBranch

  assert(pBranch != NULL);  // we didn't find a branch?

  intervallist.Remove(brit);
  pop = pBranch->population;

  // Find the recombination site.
  rangeset opensites = pBranch->range.GetNewactivesites();
  rangeset::iterator rit;
  for(rit = opensites.begin(); rit != opensites.end(); ++rit) {
     s1 = rit->first;
     s2 = rit->second;
     rec = s1 + rn;
     if (rec < s2) break;   // found it!
     rn -= (s2 - s1);
  }

  ndx = randomSource->Integer(2);

  pParentA = new RBranch;
  AssignID(pParentA);
  pParentA->eventtime  = eventT;
  pParentA->population = pop;
  pParentA->child[0]    = pBranch;
  pBranch->parent[0]->ReplaceChild(pBranch, pParentA);
  pBranch->parent[0]    = pParentA;
  if (pBranch->parent[1])
  {
    pBranch->parent[1]->ReplaceChild(pBranch, pParentA);
    pBranch->parent[1] = NULL;
  }

  rangepair recSite;

  recSite.first = 0; 
  recSite.second = nsites;
  if (ndx) recSite.second = rec + 1;   // the site after the recombination
  else recSite.first = rec + 1;
  assert(recSite.first < recSite.second);

  pParentA->range.SetRRange(pBranch->range, recSite);
  pParentA->range.SetOldsites(pBranch->range, nsites);
  UpdateRange(pParentA);

  pParentB = new RBranch;
  AssignID(pParentB);
  pParentB->eventtime  = eventT;
  pParentB->population = pop;
  pParentB->child[0]    = pBranch;
  pBranch->parent[1]    = pParentB;

  recSite.first = 0; 
  recSite.second = nsites;
  if (ndx) recSite.first = rec + 1;
  else recSite.second = rec + 1;
  assert(recSite.first < recSite.second);
  pParentB->range.SetRRange(pBranch->range, recSite);
  rangeset emptyset;
  pParentB->range.SetNewactivesites(emptyset);

  timelist.Collate(pParentA);
  timelist.Collate(pParentB);
  intervallist.Collate(pParentA); 
  activelist.Append(pParentB);          // Append this parent to the active list.

  openLinks   -= pBranch->range.NewActiveLinks();
  openLinks   += pParentA->range.NewActiveLinks();
  activeLinks += pParentB->range.ActiveLinks();
  return pBranch;
}

//______________________________________________

rangevector RecTree::GetSubtrees() const
{
  // Create a (sorted) set containing all recombination breakpoints
  
  set<long> breakpt;
  breakpt.insert(0);
  breakpt.insert(nsites);

  Branchconstiter brit;
  long site;
  for (brit = timelist.BeginBody(); brit != timelist.End(); ++brit)
  {
    site = (*brit)->GetRecSite();
    if (site != FLAGLONG)    // FLAGLONG means there is no recombination here
      breakpt.insert(site+1);// inserting site+1 because of open interval 
  }                          // conventions

  // Push rangepairs representing each breakpoint into subtree vector.
  // The (pt + 1) avoids creating a rangepair starting at the last site.
  // The strange iterator manuver is because (pt + 1) is not allowed in g++.
  // (We do not risk an empty set; we know it contains at least 2 elements.)

  rangevector subtrees;
  set<long>::const_iterator pt = breakpt.begin();
  set<long>::const_iterator nextpt = pt;
  ++nextpt;

  for ( ; nextpt != breakpt.end(); ++pt, ++nextpt) {
    subtrees.push_back(rangepair(*pt, *nextpt));
  }
  return subtrees;
}

