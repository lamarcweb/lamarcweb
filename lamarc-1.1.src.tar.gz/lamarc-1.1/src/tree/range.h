// $Id: range.h,v 1.4 2002/06/26 19:11:56 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// Range implements an ordered set of half-open site ranges (open at the
// end).  This class is meant to be embedded within a branch to allow
// for the possibility of recombination events.
//
// It tracks two different ranges, the active sites and the newly-active
// sites; plus the derived quantities number of active links and number of
// newly-active links.  Finally, for a recombinant branch, it notes
// which site is associated with the recombination event (i.e. the site
// before the cut link).
//
// It provides getter/setter pairs for all of its internal variables.
// 
// Range provides IsSiteActive() which answers whether the passed site
// is active on the owning branch.
//
// Range also provides a set of functions (1 per force) for
// handling active and newly-active site management during rearrangement.
// These functions are currently: 
//    UpdateCRange(), UpdateMRange() and UpdateRRange() plus
//    SetCRange(), SetMRange() and SetRRange().

#ifndef RANGE
#define RANGE

#include "lamarcdebug.h"
#include <stdlib.h>
#include <algorithm>
#include <assert.h>
#include <iostream>
#include "constants.h"
#include "types.h"

//____________________________________________________________________
//____________________________________________________________________

class Range
{
private:
rangeset oldsites, activesites, newactivesites;
long recsite, nlinks, newlinks;

void     ORAppend(rangepair newrange, rangeset& oldranges);
bool     ANDAppend(rangepair newrange, rangeset& oldranges);
rangeset OR(const rangeset& set1, const rangeset& set2);
rangeset AND(const rangeset& set1, const rangeset& set2);
rangeset NEG(const rangeset& set1, long nsites);
long     Span(const rangeset& sites) const;
void     UpdateNewLinks(long nsites);


public:
Range();
Range& operator=(const Range& src);
Range(const Range& src)                     {*this = src;};
Range(const rangeset& src)                  {activesites = src;};

void ClearAllSites();
void ClearOldSites()                        {oldsites.erase(oldsites.begin(),
                                                            oldsites.end());};


void SetActivesites(const rangeset& src);
void SetNewactivesites(const rangeset& src);
void SetOldsites(const rangeset& src)       {oldsites = src;};
void SetOldsites(const Range& src, long nsites);
void SetRecsite(long src)                   {recsite = src;};
rangeset GetActivesites()             const {return activesites;};
rangeset GetNewactivesites()          const {return newactivesites;};
rangeset GetOldsites()                const {return oldsites;};
long GetRecsite()                     const {return recsite;};
long GetFirstActivesite()             const {return 
                                             activesites.begin()->first;};
long ActiveLinks()                    const {assert(nlinks == Span(activesites));
                                             assert(nlinks >= 0);
                                             return nlinks;};
long NewActiveLinks()                 const {assert(newlinks >= 0);
                                             return newlinks;};

bool IsSiteActive(long site)          const;
bool SameActive(const rangeset& src)  const {return activesites == src;};
bool NoActivesites()                  const {return activesites.empty();};

void SetCRange(const Range& father, const Range& mother);
void SetMRange(const Range& mother);
void SetRRange(const Range& mother, const rangepair& newsites);

bool UpdateCRange(const Range& father, const Range& mother, long nsites);
bool UpdateMRange(const Range& mother, long nsites);
bool UpdateRRange(const Range& mother, long nsites);

void PrintActives();
void PrintNewActives();

};

#endif

