//$Id: forcesummary.cpp,v 1.10 2002/06/25 03:17:56 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "forcesummary.h"
#include "forceparam.h"
#include "tree.h"
#include "summary.h"
#include "force.h"
#include "datapack.h"
#include "plotstat.h"
#include "chainout.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif
//___________________________________________________________________________
//___________________________________________________________________________



ForceSummary::ForceSummary() 
{
// yup, it's empty
} /* ForceSummary constructor */

//___________________________________________________________________________

ForceSummary::ForceSummary(const ForceSummary& src) 
{
  CopyAllMembers(src);

} /* ForceSummary copy constructor */

//___________________________________________________________________________

ForceSummary& ForceSummary::operator=(const ForceSummary& src)
{

  if (&src != this) {  // test for self assignment
    CopyAllMembers(src);
  }

  return *this;

} /* ForceSummary operator= */

//___________________________________________________________________________

void ForceSummary::CopyAllMembers(const ForceSummary& src)
{
  // Discard previous forcevec contents and make new ones
  // using polymorphic copy constructor of Force class

  ClearForceVec();   
  ClearBackupForceVec();   
  ForceVec::const_iterator it;
  for (it = src.forcevec.begin(); it != src.forcevec.end(); ++it) {
    forcevec.push_back((*it)->Clone());
  }
  for (it = src.backupforcevec.begin(); it != src.backupforcevec.end(); ++it) {
    backupforcevec.push_back((*it)->Clone());
  }

  startParameters = src.startParameters;
  calcParameters = src.calcParameters;
  parameters_modified = src.parameters_modified;
  llikemles = src.llikemles;
  overallLlikemle = src.overallLlikemle;

} /* CopyAllMembers */

//___________________________________________________________________________

void ForceSummary::ClearForceVec()
{

  ForceVec::iterator fit;
  for (fit = forcevec.begin(); fit != forcevec.end(); ++fit)
    delete(*fit);
  forcevec.clear();

} /* ClearForceVec */

//___________________________________________________________________________
void ForceSummary::ClearBackupForceVec()
{

  ForceVec::iterator fit;
  for (fit = backupforcevec.begin(); fit != backupforcevec.end(); ++fit)
    delete(*fit);
  backupforcevec.clear();

} /* ClearBackupForceVec */

//___________________________________________________________________________

ForceSummary::~ForceSummary() 
{

  ClearForceVec();
  ClearBackupForceVec();

} /* ForceSummary destructor */

//___________________________________________________________________________

vector<Parameter> ForceSummary::GetAllParameters()
// a private function; public users should create a ParamVector
{
  ForceVec::iterator force;
  vector<Parameter> result;

  for (force = forcevec.begin(); force != forcevec.end(); ++force) {
    vector<Parameter>& tempvec = (*force)->GetParameters();
    result.insert(result.end(), tempvec.begin(), tempvec.end());
  }

  return result;

} /* GetAllParameters */

//___________________________________________________________________

void ForceSummary::SetAllParameters(const vector<Parameter>& src)
// a private function; public users should create a ParamVector
{
  ForceVec::iterator force;
  vector<Parameter>::const_iterator startparam = src.begin();
  vector<Parameter>::const_iterator endparam;
  for (force = forcevec.begin(); force != forcevec.end(); ++force) {
     endparam = startparam + (*force)->GetNParams();
     vector<Parameter> result(startparam, endparam);
     (*force)->SetParameters(result);
     startparam = endparam;
  }
  
} /* SetAllParameters */

//___________________________________________________________________________

void ForceSummary::SummarizeData(DataPack& dpack)
{

  ForceVec::iterator fit; // declared here because used multiple times
  parameters_modified = false;

  long nregions = dpack.GetNRegions();
  vector<ForceParameters> regparams(nregions);
  long reg;
  for(reg = 0; reg != nregions; ++reg) {
    Region& region = dpack.GetRegion(reg);
    for(fit = forcevec.begin(); fit != forcevec.end(); ++fit)
      (*fit)->QuickCalc(region);
    regparams[reg] = region.regiontheta;
  }

  calcParameters.SetToMeanOf(regparams,*this);

  for(fit = forcevec.begin(); fit != forcevec.end(); ++fit) {
     deque<bool> useparam = (*fit)->UseCalculatedValues();
     DoubleVec1d params = (*fit)->RetrieveParameters(calcParameters);
     DoubleVec1d uparams = (*fit)->RetrieveParameters(startParameters);

     unsigned long param;
     for(param = 0; param < params.size(); ++param) {
        // hack hack
        if (uparams.empty()) {
          if (!useparam[param]) {
            params[param] = (*fit)->GetDefaultValue();
            parameters_modified = true;
            continue;
          }
        }
        if (!useparam[param]) params[param] = uparams[param];
// warning WARNING -- this should be handled in a force and datatype
// specific manner, not implemented at the moment.
// Maybe use dpack.region.datatype.default_value?
        if (params[param] == FLAGDOUBLE) {
           params[param] = (*fit)->GetDefaultValue();
           parameters_modified = true;
        } else {
           double trimvalue = (*fit)->Truncate(params[param]);
           if (trimvalue != params[param]) {
              params[param] = trimvalue;
              parameters_modified = true;
           }
        }
     }
     (*fit)->PutParameters(params,startParameters);
  }

} /* SummarizeData */

//___________________________________________________________________________

Tree *ForceSummary::CreateProtoTree(Random *rnd, long npops)
{
  Tree *tree;

  if (CheckForce(string(REC)))
  {
    tree = new RecTree(rnd,npops);
  }

  else
  {
    tree = new PlainTree(rnd,npops);
  }

  return tree;
}

//___________________________________________________________________________

TreeSummary* ForceSummary::CreateProtoTreeSummary(long npops) const
{
  bool shortform = true;

  // if growth is in effect, short form summaries cannot be used
  if (CheckForce(GROW)) {
    shortform = false;
  }

  // if recombination is in effect, a recombinant summary must be
  // created
  TreeSummary* treesum;
  if (CheckForce(REC)) {
    treesum = new RecTreeSummary();
  } else {
    treesum = new TreeSummary();
  }

  IntervalData& interval = treesum->GetIntervalData();

  ForceVec::const_iterator fit = forcevec.begin();
  for ( ; fit != forcevec.end(); ++fit) {
    Summary* sum = (*fit)->CreateSummary(interval, npops, shortform);
    if (sum) { 
      treesum->AddSummary((*fit)->GetTag(), sum);
    }
  }

  return treesum;

} /* CreateProtoIntervalData */

//------------------------------------------------------------------------
// reconciling plforces pointers in case of growth or not.
// PB
void ForceSummary::ReconcilePLForces(const DataPack &dpack)
{
  bool isgrow = CheckForce(GROW);
  long  npop = dpack.GetNPopulations();
  if(isgrow)
    {
      dynamic_cast<CoalForce *>((*GetForceByTag(COAL)))->ChangetoCoalGrowPL(npop);
      //      dynamic_cast<MigForce>((*GetForceByTag(MIG)))->ChangeMigPL(npop * npop);
    }
  else
    {
      dynamic_cast<CoalForce *>((*GetForceByTag(COAL)))->ChangetoCoalPL(npop);
    }
}






//___________________________________________________________________________

ForceVec::iterator ForceSummary::GetForceByTag(const string& tag) 
{ 
  // returns an iterator to the element, or end() if none is found
  ForceVec::iterator it;
  for (it = forcevec.begin(); it != forcevec.end(); ++it) {
    if ((*it)->GetTag() == tag) return (it);
  }
  return (forcevec.end());

} /* GetForceByTag */

//___________________________________________________________________________

ForceVec::const_iterator ForceSummary::GetForceByTag(const string& tag) const
{ 
  // returns an iterator to the element, or end() if none is found
  ForceVec::const_iterator it;
  for (it = forcevec.begin(); it != forcevec.end(); ++it) {
    if ((*it)->GetTag() == tag) return (it);
  }
  it = forcevec.end();
  return (it);

} /* GetForceByTag */

//___________________________________________________________________________


ForceVec::iterator ForceSummary::GetBackupForceByTag(const string& tag) 
{ 
  // returns an iterator to the element, or end() if none is found
  ForceVec::iterator it;
  for (it = backupforcevec.begin(); it != backupforcevec.end(); ++it) {
    if ((*it)->GetTag() == tag) return (it);
  }
  it = backupforcevec.end();
  return (it);

} /* GetBackupForceByTag */

//___________________________________________________________________________

ForceVec::const_iterator ForceSummary::GetBackupForceByTag(const string& tag) const
{ 
  // returns an iterator to the element, or end() if none is found
  ForceVec::const_iterator it;
  for (it = backupforcevec.begin(); it != backupforcevec.end(); ++it) {
    if ((*it)->GetTag() == tag) return (it);
  }
  it = backupforcevec.end();
  return (it);

} /* GetBackupForceByTag */

//___________________________________________________________________________
long ForceSummary::GetForceIndexByTag(const string& tag)
{
  long index, nforces = GetNForces();
  for(index = 0; index < nforces; ++index)
     if (forcevec[index]->GetTag() == tag) return index;

  return FLAGLONG;

} /* ForceSummary::GetForceIndexByTag */

//___________________________________________________________________________

long ForceSummary::GetForceIndexByTag(const string& tag) const
{
  long index, nforces = GetNForces();
  for(index = 0; index < nforces; ++index)
     if (forcevec[index]->GetTag() == tag) return index;

  return FLAGLONG;

} /* ForceSummary::GetForceIndexByTag */

//___________________________________________________________________________

void ForceSummary::SetForce(const string& tag, const DataPack& dpack)
{
  // return quickly if the force is already set
  if(GetForceByTag(tag) != forcevec.end()) return;

  // restore the force from the backup vector if it has been set
  ForceVec::iterator backupIt = GetBackupForceByTag(tag);
  if(backupIt == backupforcevec.end())
  {
      // didn't find it, so create it
      Force * newForce = CreateForce(tag,dpack);
      forcevec.push_back(newForce); 
      InitializeForce(tag,dpack);
  } else {
      // it was in the backup, so switch it
      forcevec.push_back(*backupIt); 
      backupforcevec.erase(backupIt);
  }
}

//___________________________________________________________________________

void ForceSummary::UnsetForce(const string& tag)
{
  ForceVec::iterator backupIt = GetBackupForceByTag(tag);
  if (backupIt != backupforcevec.end()) 
  { 
      // get rid of the old backup
      delete *backupIt; 
      backupforcevec.erase(backupIt);
  }

  ForceVec::iterator it = GetForceByTag(tag);
  if (it != forcevec.end()) {
      // move current force to the backup vector
      backupforcevec.push_back(*it); 
      forcevec.erase(it);
  }

}

//___________________________________________________________________________

bool ForceSummary::CheckForce(const string& tag) const
{
  if (GetForceByTag(tag) == forcevec.end()) return false;
  return true;

} /* CheckForce */

//___________________________________________________________________________

void ForceSummary::SetMaxEvents(const string& tag, long events)
{
  ForceVec::iterator it = GetForceByTag(tag);
  assert(it != forcevec.end());
  (*it)->SetMaximum(events);

} /* SetMaxEvents */

//___________________________________________________________________________

long ForceSummary::GetMaxEvents(const string& tag) const
{
  ForceVec::const_iterator it = GetForceByTag(tag);
  assert(it != forcevec.end());
  return((*it)->GetMaximum());
} /* GetMaxEvents */

//___________________________________________________________________________

void ForceSummary::SetMethods(const string& tag, const vector<string> meth)
{
  ForceVec::iterator it = GetForceByTag(tag);
  assert(it != forcevec.end());
  (*it)->SetMethods(meth);

} /* SetMethods */

//___________________________________________________________________________

void ForceSummary::SetStartParameters(const ForceParameters& fp)
{
  startParameters = fp;

} /* SetStartParameters */

//___________________________________________________________________________

void ForceSummary::SetCalcParameters(const ForceParameters& fp)
{
  calcParameters = fp;

} /* SetStartParameters */

//___________________________________________________________________________

void ForceSummary::SetRegionMLEs(const ChainOut& chout) 
{  
  // we do this by way of the ParamVector linearized form; it's easier

  ParamVector paramvec(*this);
  vector<double> estimates = chout.GetEstimates().GetParameters(*this);

  assert(estimates.size() == paramvec.size());  // need one estimate per parameter

  ParamVector::iterator param;
  vector<double>::const_iterator est = estimates.begin();

  for (param = paramvec.begin(); param != paramvec.end(); ++param, ++est) {
    if (param->IsValid()) param->AddMLE(*est);
  }

  llikemles.push_back(chout.GetLlikemle());

} /* SetRegionMLEs */

//___________________________________________________________________________

void ForceSummary::SetOverallMLE(const ChainOut& chout)
{
  ParamVector paramvec(*this);
  vector<double> estimates = chout.GetEstimates().GetParameters(*this);

  assert(estimates.size() == paramvec.size());  // need one estimate per parameter

  ParamVector::iterator param;
  vector<double>::const_iterator est = estimates.begin();

  for (param = paramvec.begin(); param != paramvec.end(); ++param, ++est) {
    if (param->IsValid()) param->AddOverallMLE(*est);
  }

  overallLlikemle = chout.GetLlikemle();

} /* SetOverallMLEs */

//___________________________________________________________________________

vector<string> ForceSummary::GetMethods(const string& tag) const
{
  ForceVec::const_iterator it = GetForceByTag(tag);
  assert(it != forcevec.end());
  return (*it)->GetMethods();

} /* GetMethods */

//___________________________________________________________________________

#if 0
// DEBUG not implemented yet  -- V2
StringVec2d ForceSummary::Get2DModel(const string& tag) const
{
  ForceVec::const_iterator it = GetForceByTag(tag);
  StringVec2d result = SquareOffVector((*it)->GetModel());
  return result;
}
#endif

//___________________________________________________________________________

StringVec2d ForceSummary::Get2DMethods(const string& tag) const
{
  ForceVec::const_iterator it = GetForceByTag(tag);
  assert(it != forcevec.end());
  StringVec2d result = SquareOffVector((*it)->GetMethods());
  return result;
} /* Get2DMethods */

//___________________________________________________________________________

long ForceSummary::GetNParameters(const string& tag) const
{
  ForceVec::const_iterator it = GetForceByTag(tag);
  assert(it != forcevec.end());
  return (*it)->GetNParams();
} /* GetNParameters */

//___________________________________________________________________________

long ForceSummary::GetAllNParameters() const
{
  long total = 0;
  ForceVec::const_iterator it;
  for(it = forcevec.begin(); it != forcevec.end(); ++it)
     total += (*it)->GetNParams();
  return total; 
} /* ForceSummary::GetAllNParameters */

//___________________________________________________________________________

StringVec1d ForceSummary::GetForceString() const
{
  StringVec1d forces;
  ForceVec::const_iterator it;
  for(it = forcevec.begin(); it != forcevec.end(); ++it)
     forces.push_back((*it)->GetTag());
  return forces;
} /* ForceSummary::GetForceString */

//___________________________________________________________________________

vector<double> ForceSummary::GetModifiers() const
{
  // V2 -- eventually these will be set by data reading, but for now
  // we hard-wire them.

  ParamVector paramvec(*this, true);  // read-only copy
  ParamVector::iterator it;
  proftype profiletype = none;
  vector<double> results;

  // diagnose whether we have fixed or percentile profiles.
  // WARNING:  This code absolutely assumes that either parameters
  // are fixed/none or they are percentile/none, but never both
  // fixed and percentile in the same run.

  for (it = paramvec.begin(); it != paramvec.end(); ++it) {
    if (it->GetProfileType() != none) {
      profiletype = it->GetProfileType();
      break;
    }
  }

  if (profiletype == none) return results;  // no profiles, hence no modifiers

  if (profiletype == percentile) {   // percentile
    results.push_back (0.005);
    results.push_back (0.025);
    results.push_back (0.05);
    results.push_back (0.125);
    results.push_back (0.25);
    results.push_back (0.5);
    results.push_back (0.75);
    results.push_back (0.875);
    results.push_back (0.95);
    results.push_back (0.975);
    results.push_back (0.995);
    return results;
  } else {                         // fixed
    results.push_back (0.005);
    results.push_back (0.01);
    results.push_back (0.05);
    results.push_back (0.1);
    results.push_back (0.5);
    results.push_back (1.0);
    results.push_back (5.0);
    results.push_back (10.0);
    results.push_back (50.0);
    results.push_back (100.0);
    results.push_back (500.0);
    return results;
  }

} /* GetModifiers */

//___________________________________________________________________________

proftype ForceSummary::GetOverallProfileType() const
{
unsigned long i;
for (i = 0; i < forcevec.size(); ++i) {
  proftype mytype = forcevec[i]->SummarizeProfTypes();
  if (mytype != none) return mytype;
}

return none;

} /* GetOverallProfileType */

//___________________________________________________________________________

bool ForceSummary::IsValid() const
{
  // Some parameters must be present!
  // if (nparams == 0) return false;

  // unsigned long npops = nparams;

  // Coalescent force
  // REQUIRED
  bool iscoal = CheckForce(COAL);
  if (!iscoal) return false;;
  //if (startParameters.GetThetas().size() != npops) return false;
  //if (calcParameters.GetThetas().size() != npops) return false;

  // Migration force
  // bool ismig = CheckForce(MIG);
  // FORBIDDEN IF ONE POPULATION
  // if (npops == 1 && ismig) return false;

  // REQUIRED IF MULTIPLE POPULATIONS
  // if (npops > 1) {
    // if (!ismig) return false;
    // if (startParameters.GetMigRates().size() != npops * npops) return false;
    // if (calcParameters.GetMigRates().size() != npops * npops) return false;
  // }

  // Recombination force
  // OPTIONAL
  bool isrec = CheckForce(REC);
  if (isrec) {
    if (startParameters.GetRecRates().size() != 1) return false;
  }

  // WARNING DEBUG should check validity of the parameterlist
  // (but I don't know how) -- Mary

  return true;
} /* IsValid */



//___________________________________________________________________________

void
ForceSummary::InitializeForce(const string& tag, const DataPack& dpack)
{
    if(tag == MIG)  return InitializeMigration(dpack);
    if(tag == COAL) return InitializeCoalescence(dpack);
    if(tag == GROW) return InitializeGrowth(dpack);
    if(tag == REC)  return InitializeRecombination(dpack);
    assert(false);

}

void
ForceSummary::InitializeCoalescence(const DataPack& dpack)
{

    //theta setup
    unsigned long npop = dpack.GetNPopulations ();
    DoubleVec1d thetas = GetStartParameters ().GetThetas ();
    if (thetas.size () < npop) thetas.resize (npop, DEFAULTTHETA);
    GetStartParameters ().SetThetas (thetas);
    // savety net in case we have no force object set
    // if the object exists nothing is done 
    vector <string> method = GetMethods (COAL);
    method.resize (npop, USER);
    SetMethods (COAL, method);
    method.clear (); 
}


void
ForceSummary::InitializeMigration(const DataPack& dpack)
{

  unsigned long npop = dpack.GetNPopulations ();
  if (npop > 1)
    {
      unsigned long npop2 = npop * npop;
      DoubleVec1d migrations = GetStartParameters ().GetMigRates ();
      if (migrations.size () < npop2) migrations.resize (npop2, DEFAULTMIGRATION);
      GetStartParameters ().SetMigRates (migrations);
      vector <string> method = GetMethods (MIG);
      method.resize (npop * npop, USER);
      SetMethods (MIG, method);
      method.clear ();
    }

}

void
ForceSummary::InitializeGrowth(const DataPack& dpack)
{

  unsigned long npop = dpack.GetNPopulations ();
  DoubleVec1d growths = GetStartParameters ().GetGrowthRates ();
  if (growths.size () < npop) growths.resize (npop, DEFAULTGROWTH);
  GetStartParameters ().SetGrowthRates (growths);
  vector <string> method = GetMethods (GROW);
  method.resize (npop, USER);
  SetMethods (GROW, method);
  method.clear ();
}

void
ForceSummary::InitializeRecombination(const DataPack& dpack)
{
    //recombination rate setup
    DoubleVec1d recrates;
    recrates = GetStartParameters ().GetRecRates ();
    if (recrates.size () == 0) 
        recrates.resize (1, DEFAULTRECOMBINATIONRATE);	//vector must be of size 1
    if (GetMaxEvents (REC) < 0) 
        SetMaxEvents (REC, DEFAULTRECEVENTS);
    GetStartParameters ().SetRecRates (recrates);
    //check if force is present or then add
    vector <string> method = GetMethods (REC);
    method.resize (1, USER);
    SetMethods (REC, method);
    method.clear ();

}


// This is a free function for approximate comparison of doubles.
// It is used to help find the correct profile modifier value in
// the face of rounding error.

bool CloseEnough(double a, double b) {
  double test = fabs(a - b);
  if (test < 0.000001) return true;
  else return false;
  
} /* CloseEnough */


//___________________________________________________________________________
