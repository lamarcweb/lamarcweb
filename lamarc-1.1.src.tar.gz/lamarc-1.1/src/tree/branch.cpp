// $Id: branch.cpp,v 1.15 2002/06/26 19:11:55 lamarc Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "branch.h"
#include <algorithm>
#include "treesum.h"
#include "summary.h"

#ifdef DMALLOC_FUNC_CHECK
#include <dmalloc.h>
#endif

using namespace std;

Branch* NOBRANCH = NULL;

//_________________________________________________

Branch::Branch()
: ID(NELEM,0L), parent(NELEM,NOBRANCH), child(NELEM,NOBRANCH)

{
eventtime   = 0.0;
population  = 0;
updateDL    = false;
marked      = false;

} /* Branch::Branch */

//_________________________________________________

Branch::~Branch()
{
  // no need to delete due to use of shared_ptr
} /* Branch destructor */

//_________________________________________________

Branch::Branch(const Branch& src)
: ID(NELEM,0L), parent(NELEM,NOBRANCH), child(NELEM,NOBRANCH)
{

CopyAllMembers(src);

} /* Branch::Branch */

//_________________________________________________

void Branch::CopyAllMembers(const Branch& src)
{
Branch* pbr = NULL;
fill(parent.begin(),parent.end(),pbr);
fill(child.begin(),child.end(),pbr);


ID         = src.ID;
eventtime  = src.eventtime;
population = src.population;
updateDL   = src.updateDL;
marked     = src.marked;
range      = src.range;

// NB:  we do not copy the dlcell member, as it may not be
// wanted:  only a very few branches have dlcells.

} /* Branch::CopyAllMembers */

//_________________________________________________

Branch& Branch::operator=(const Branch& src)
{
CopyAllMembers(src);

return *this;

} /* Branch::operator= */

//_________________________________________________

void Branch::MarkParentsForDLCalc()
{

// evil kludge necessary because we force parents/children
// to always have two spaces even when empty!
if (parent[0] != NOBRANCH) {
   parent[0]->SetUpdateDL();
   parent[0]->MarkParentsForDLCalc();
}

if (parent[1] != NOBRANCH) {
   parent[1]->SetUpdateDL();
   parent[1]->MarkParentsForDLCalc();
}

} /* Branch::MarkParentsForDLCalc */

//_________________________________________________

void Branch::ReplaceChild(Branch*, Branch* newchild)
{
newchild->parent[0] = this;
child[0]            = newchild;

} /* Branch::ReplaceChild */

//_________________________________________________

bool Branch::HasSameActive(const Branch& br)
{
return range.SameActive(br.range.GetActivesites());

} /* Branch::HasSameActive */

//_________________________________________________

double Branch::HowFarTo(Branch& br)
{
return fabs(br.eventtime - eventtime);

} /* Branch::HowFarTo */

//_________________________________________________

Branch* Branch::GetValidChild(Branch* br, long whichpos)
{

Branch *pChild = br->GetActiveChild(whichpos);
if (pChild)
   br = GetValidChild(pChild,whichpos);

return br;

} /* Branch::GetValidChild */

//_________________________________________________

bool Branch::DiffersInDLFrom(Branch* branch, long marker) const
{
// WARNING DEBUG This is something of a hack; it assumes that
// the first DLCell is the "real" one, and it uses get().

return !(dlcell[0]->IsSameAs(branch->dlcell[0].get(),marker));

} /* Branch::DiffersInDLFrom */

//_________________________________________________

bool Branch::CheckInvariant() const
{
// check correct time relationships among parents and offspring
long index;
for (index = 0; index < NELEM; ++index) {
  // if the child exists it must be earlier
  if (child[index])
    if (child[index]->eventtime > eventtime) return false;
  // if the parent exists it must be later
  if (parent[index])
    if (parent[index]->eventtime < eventtime) return false;
}

return true;

} /* CheckInvariant */

//_________________________________________________

bool Branch::operator==(const Branch& src) const
{
  if (Event() != src.Event()) return false;
  if (population != src.population) return false;
  if (eventtime != src.eventtime) return false;
  
  return true;

} /* operator== */

//_________________________________________________

string Branch::DLCheck(const Branch& other) const
{
unsigned long ncells = dlcell.size();
if (ncells != other.dlcell.size())
   return string("   Bad branch comparison--error\n");

string problems;
if (dlcell.empty()) return problems;

unsigned long ind;
for (ind = 0; ind < ncells; ++ind) {
   long badmarker = dlcell[ind]->DiffersFrom(other.dlcell[ind]);
   if (badmarker == FLAGLONG) continue;

   problems += "   Branch " + ToString(ID[0]) + ToString(ID[1]);
   problems += " differs from other branch " + ToString(other.ID[0]);
   problems += ToString(other.ID[1]) + " at marker " + ToString(badmarker);
   problems += "\n";
}

return problems;

} /* Branch::DLCheck */

//_________________________________________________
//_________________________________________________

Branch* BBranch::Clone()
{
BBranch* newbranch = new BBranch(*this);
return newbranch;

} /* BBranch::Clone */

//_________________________________________________

void BBranch::ScoreEvent(TreeSummary&, LongVec1d&) const
{
  assert(false);  // I don't think this should ever be called
} /* BBranch::ScoreEvent */

//_________________________________________________

void BBranch::ScoreEvent(TreeSummary&, LongVec1d&, long&) const
{
  assert(false);  // I don't think this should ever be called
} /* BBranch::ScoreEvent */

//_________________________________________________

bool BBranch::CheckInvariant() const
{

  // Base branches have no parents...
  long index;
  for (index = 0; index < NELEM; ++index) {
    if (parent[index]) return false;
  }

  // ...and one child
  if (!child[0]) return false;
  if (child[1]) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________
//_________________________________________________

TBranch& TBranch::operator=(const TBranch& src)
{
assert(this != &src);
Branch::operator=(src);

dlcell.clear();
unsigned long i;
for (i = 0; i < src.dlcell.size(); ++i) {
  dlcell.push_back(Cell_ptr(src.dlcell[i]->Copy()));
}
label  = src.label;

return *this;

} /* TBranch::operator= */

//_________________________________________________

Branch* TBranch::Clone()
{
TBranch *pBranch = new TBranch(*this);
return pBranch;

} /* TBranch::Clone */

//_________________________________________________

bool TBranch::CheckInvariant() const
{

  // Tip branches have no children...
  long index;
  for (index = 0; index < NELEM; ++index) {
    if (child[index]) return false;
  }

  // ...and at least one parent
  if (!parent[0]) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________

bool TBranch::operator==(const Branch& src) const
{

return ((*this == src) && (label == dynamic_cast<const TBranch&>(src).label));

} /* operator== */

//_________________________________________________

void TBranch::ScoreEvent(TreeSummary&, LongVec1d&) const
{
  assert(false); // I don't think this should ever be called

} /* TBranch::ScoreEvent */

//_________________________________________________

void TBranch::ScoreEvent(TreeSummary&, LongVec1d&, long&) const
{
  assert(false); // I don't think this should ever be called

} /* TBranch::ScoreEvent */

//_________________________________________________
//_________________________________________________

CBranch& CBranch::operator=(const CBranch& src)
{
assert(this != &src);
Branch::operator=(src);

dlcell.clear();
unsigned long i;
for (i = 0; i < src.dlcell.size(); ++i) {
  dlcell.push_back(Cell_ptr(src.dlcell[i]->Copy()));
}
return *this;

} /* CBranch::operator= */

//_________________________________________________

Branch* CBranch::Clone()
{
CBranch *pBranch = new CBranch(*this);
return pBranch;

} /* CBranch::Clone */

//_________________________________________________

bool CBranch::CanRemove(Branch* checkchild)
{
if (marked) return true;

marked = true;
if (child[0] == checkchild) child[0] = child[1];
child[1] = NULL;
return false;

} /* CBranch::CanRemove */

//_________________________________________________

bool CBranch::UpdateRange(long nsites)
{
if (marked) return range.UpdateMRange(child[0]->range,nsites);

return range.UpdateCRange(child[0]->range,child[1]->range,nsites);

} /* CBranch::UpdateRange */

//_________________________________________________

void CBranch::ReplaceChild(Branch* pOldChild, Branch* pNewChild)
{
if (child[0] == pOldChild) child[0] = pNewChild;
else child[1] = pNewChild;

pNewChild->parent[0] = this;

} /* CBranch::ReplaceChild */

//_________________________________________________

Branch* CBranch::OtherChild(Branch* badchild)
{
if (child[0] == badchild) return child[1];

return child[0];

} /* CBranch::OtherChild */

//_________________________________________________

// If both children are active return NULL to signal a stop,
// otherwise return the child that is active.
Branch* CBranch::GetActiveChild(long site)  const
{
if (child[0]->range.IsSiteActive(site)) {
   if (child[1]->range.IsSiteActive(site)) return NULL;
   return child[0];
} else
   return child[1];

} /* CBranch::GetActiveChild */

//_________________________________________________

void CBranch::ScoreEvent(TreeSummary& summary, LongVec1d& ks) const
{
  // fetch the CoalSummary
  CoalSummary* csum = dynamic_cast<CoalSummary*>(summary.GetSummary(COAL));

  assert(csum);  // forces have become inconsistent!

  // score the event
  csum->AddInterval(eventtime, ks, FLAGLONG, population, FLAGLONG, FLAGLONG);

  // adjust the branch counts per population
  long i;
  for (i = 0; i < NELEM; ++i) {
    --ks[child[i]->population];
  }
  ++ks[population];
  
} /* CBranch::ScoreEvent */

//_________________________________________________

void CBranch::ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const
{
  // fetch the CoalSummary
  CoalSummary* csum = dynamic_cast<CoalSummary*>(summary.GetSummary(COAL));

  assert(csum);  // forces have become inconsistent!

  // score the event
  csum->AddInterval(eventtime, ks, s, population, FLAGLONG, FLAGLONG);

  // adjust the branch counts per population
  long i;
  for (i = 0; i < NELEM; ++i) {
    --ks[child[i]->population];
    s -= child[i]->range.ActiveLinks();
  }
  ++ks[population];
  s += range.ActiveLinks();
  
} /* CBranch::ScoreEvent */

//_________________________________________________

bool CBranch::CheckInvariant() const
{

  // Coalescent branches have two children...
  if (!child[0]) return false;
  if (!child[1]) return false;

  //...and at least one parent
  if (!parent[0]) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________
//_________________________________________________

Branch* MBranch::Clone()
{
MBranch *pBranch = new MBranch(*this);
return pBranch;

} /* MBranch::Clone */

//_________________________________________________

bool MBranch::UpdateRange(long nsites)
{
return range.UpdateMRange(child[0]->range,nsites);

} /* MBranch::UpdateRange */

//_________________________________________________

void MBranch::ScoreEvent(TreeSummary& summary, LongVec1d& ks) const
{
  // fetch the MigSummary
  MigSummary* msum = dynamic_cast<MigSummary*>(summary.GetSummary(MIG));

  assert(msum); // forces have become inconsistent!

  // score the event
  msum->AddInterval(eventtime, ks, FLAGLONG, population, child[0]->population, FLAGLONG);

  // adjust the lineages per population
  assert(!child[1]);   // too many children??
  --ks[child[0]->population];
  ++ks[population];

  // we do not adjust active sites; they cannot possibly change
  
} /* MBranch::ScoreEvent */

//_________________________________________________

void MBranch::ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const
{
  // fetch the MigSummary
  MigSummary* msum = dynamic_cast<MigSummary*>(summary.GetSummary(MIG));

  assert(msum); // forces have become inconsistent!

  // score the event
  msum->AddInterval(eventtime, ks, s, population, child[0]->population, FLAGLONG);

  // adjust the lineages per population
  assert(!child[1]);   // too many children??
  --ks[child[0]->population];
  ++ks[population];

  // we do not adjust active sites; they cannot possibly change
  
} /* MBranch::ScoreEvent */

//_________________________________________________

bool MBranch::CheckInvariant() const
{

  // Migrant branches have one child...
  if (!child[0]) return false;
  if (child[1]) return false;

  //...and at least one parent
  if (!parent[0]) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________
//_________________________________________________

Branch* RBranch::Clone()
{
RBranch *pBranch = new RBranch(*this);
return pBranch;

} /* RBranch::Clone */

//_________________________________________________

bool RBranch::UpdateRange(long nsites)
{
return range.UpdateRRange(child[0]->range,nsites);

} /* RBranch::UpdateRange */

//_________________________________________________

void RBranch::ReplaceChild(Branch* oldchild, Branch* newchild)
{
child[0] = newchild;

if (oldchild->parent[0] == this) newchild->parent[0] = this;
else newchild->parent[1] = this;

} /* RBranch::ReplaceChild */

//_________________________________________________

void RBranch::ScoreEvent(TreeSummary&, LongVec1d&) const
{
  assert(false);  // this should never be called
} /* Rbranch::ScoreEvent */

//_________________________________________________

void RBranch::ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const
{
  // One interval with a recombination at the top involves *two*
  // RBranches.  Only one will be summarized into the TreeSummary.
  // Thus, this peculiar-looking code only calls AddInterval if
  // the RBranch in question is its Child's *first* Parent, though
  // it does clean-up bookkeeping in any case.

  if (dynamic_cast<RBranch*>(child[0]->parent[0]) == this) {
  
    // fetch the RecSummary
    RecSummary* rsum = dynamic_cast<RecSummary*>(summary.GetSummary(REC));

    assert(rsum); // forces have become inconsistent!

    // score the event
    rsum->AddInterval(eventtime, ks, s, FLAGLONG, FLAGLONG, GetRecSite());

    // adjust the branch counts and activesite counts
    // for removal of the child
    --ks[child[0]->population];
    s -= child[0]->range.ActiveLinks();
  }

  // adjust the branch and activesite counts for addition of this branch
  ks[population] += 1;
  s += range.ActiveLinks();
  
} /* RBranch::ScoreEvent */

//_________________________________________________

bool RBranch::CheckInvariant() const
{

  // Recombinant branches have one child...
  if (!child[0]) return false;
  if (child[1]) return false;

  //...and at least one parent
  if (!parent[0]) return false;

  if (!Branch::CheckInvariant()) return false;
  return true;
} /* CheckInvariant */

//_________________________________________________

