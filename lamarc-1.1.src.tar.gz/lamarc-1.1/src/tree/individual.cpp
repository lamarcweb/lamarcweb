// $Id: individual.cpp,v 1.4 2002/06/25 03:17:56 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "individual.h"
#include "branch.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

//____________________________________________________________

Individual& Individual::operator=(const Individual& src)
{

CopyAllMembers(src);
return *this;

} /* Individual::Individual */

//____________________________________________________________

Individual::Individual(const Individual& src)
{
CopyAllMembers(src);
}

//____________________________________________________________

void Individual::CopyAllMembers(const Individual& src) 
{
  id = src.id;
  phasemarkers = src.phasemarkers;
  name = src.name;
  tips = src.tips;

} /* CopyAllMembers */

//____________________________________________________________

StringVec1d Individual::GetAllTipNames() const
{
StringVec1d names;
vector<Branch*>::const_iterator tip;

for(tip = tips.begin(); tip != tips.end(); ++tip)
   names.push_back(dynamic_cast<TBranch*>(*tip)->label);

return names;

} /* GetAllTipNames */

//____________________________________________________________

void Individual::PruneSamePhaseUnknownSites()
{
LongVec1d newphase;

LongVec1d::iterator marker;
for(marker = phasemarkers.begin(); marker != phasemarkers.end(); ++marker) {
   Branch* firsttip = tips.front();
   vector<Branch*>::const_iterator tip = tips.begin();
   for(++tip; tip != tips.end(); ++tip)
      if (firsttip->DiffersInDLFrom(*tip,*marker)) {
         newphase.push_back(*marker);
         break;
      }
}

phasemarkers = newphase;

} /* Individual::PruneSamePhaseUnknownSites */

//____________________________________________________________
