// $Id: branchlist.h,v 1.7 2002/06/25 03:17:54 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// This files defines two kinds of time ordered container of Branch*,
// TimeList and BranchBuffer.  The TimeList is a list of all Branch
// derived things associated with a particular tree.  The BranchBuffer
// is a storage buffer used during rearrangement to store active and
// inactive branches.  Both of these objects are implemented as wrappers
// around a STL::container, slist.
//
// Sets and Maps were not used because the current usage of these
// containers should naturally give the correct places to do 
// insertion/deletion at.
//
// IMPORTANT NOTE: TimeList owns the branches that it points at!  No
// one else may delete these!

#ifndef TREELISTS
#define TREELISTS

#include <vector>
#include "vectorx.h"
#include <map>
#include "definitions.h"
#include "types.h"
#include "branch.h"

// #include "branch.h"--to create the "base" branch, TimeList constructor
//                      to create a Tbranch, CreateTip
//                      to initialize branch innards, both of the above
//                      to maintain tree child & parent relationships
//                         in CopyBody()
//                      to track ncuttable via branch.Cuttable()
//                      to track marked status via branch.marked,
//                         branch.SetUpdateDL()

class Branch;
class TBranch;

//_______________________________________________________________________

class TimeList
{
private:
BBranch base;
Branchiter lasttip;
Branchlist branches;                 // TimeList owns the branches!!!
BranchMap branchmap;                 // counts branches of each type

// DEBUG debug warning WARNING--probably move to tree
long ntips, ncuttable;

Branch* FindEquivChild(const Branch* child, const Branchlist& srclist, 
                       Branchlist& newlist);

void CountBranch(const string& tag);
void UncountBranch(const string& tag);
void ClearBranchCount();

public:

TimeList();
TimeList(const TimeList& src);
TimeList& operator=(const TimeList& src);
~TimeList();
void Clear();
void ClearBody();
void CopyTips(const TimeList& src);  // destroys previous elements
void CopyBody(const TimeList& src);  // destroys previous elements,
                                     // "copies" tree linkage as well,
                                     // assumes tips are already identical
                                     // assumes nodes have either
                                     //   2 parents or 2 children

long HowMany(const string& tag) const;  // how many branchs of type 'tag'?

void AddAfter(Branchiter here, Branch* newbranch);
void Collate(Branch* newbranch);
void Remove(Branch* badbranch);

Branchiter       Begin()           {return branches.begin();};
Branchconstiter  Begin()     const {return branches.begin();};
Branchiter       End()             {return branches.end();};
Branchconstiter  End()       const {return branches.end();};
Branchiter       BeginBody()       {Branchiter bdy = lasttip; return ++bdy;};
Branchconstiter  BeginBody() const {Branchiter bdy = lasttip; return ++bdy;};
Branch*          Base()            {return &base;};
const Branch*    Base()      const {return &base;};
Branch*          Root()      const {return base.child[0];};
Branchconstiter  GetLastTip() const {return lasttip;};

// DEBUG debug warning WARNING--probably move to tree
long          GetNTips()     const {return ntips;};
long          GetNCuttable() const {return ncuttable;};
TBranch*      CreateTip();
TBranch*      GetTip(string name) const;
void          Prune();
void          SetUpdateDLs(Branch*);
void          ClearUpdateDLs();
void          SetAllUpdateDLs();

bool operator==(const TimeList& src) const;
bool operator!=(const TimeList& src) const { return !(*this == src); };

// debug functions
void Printtimelist();
void Printtreelist();
void Printtips();
void MakeCoalescent(double theta);
string DLCheck(const TimeList& other) const;

};

//_______________________________________________________________________
//_______________________________________________________________________

class BranchBuffer
{
private:
Branchlist branches;      // we do not own these branches!
LongVec1d branchpops;                             // dim: population

BranchBuffer();                                   // undefined
BranchBuffer(const BranchBuffer& src);            // undefined
BranchBuffer& operator=(const BranchBuffer& src); // undefined


public:
BranchBuffer(long npops);
~BranchBuffer()                            {};
void Clear();
LongVec1d GetBranchPops()            const {return branchpops;};
void Append(Branch* newbranch);
void AddAfter(Branchiter here, Branch* newbranch);
void Collate(Branch* newbranch);
long Size()                          const {return branches.size();};
Branchiter Begin()                         {return branches.begin();};
Branchiter End()                           {return branches.end();};
void       Remove(Branchiter here);
Branch* GetFirst();
Branch* RemoveFirst();
Branch* RemoveBranch(long pop, double rnd);

// meant to only be used on tree::intervallist().
double  IntervalBottom();

};


#endif
