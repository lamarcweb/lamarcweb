//$Id: event.h,v 1.8 2002/06/26 19:11:56 lamarc Exp $

#ifndef EVENT
#define EVENT

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <vector>
#include "vectorx.h"
#include "tree.h" 
#include "arranger.h" 

// #include "forceparam.h"  ForceParameters functions used in .cpp

class ForceParameters;
class ForceSummary;

/***************************************************************
  This class contains expertese needed to handle one type of
  "event" in the rearrangment process.  Events are things such
  as a migration, a recombination on an active lineage, a
  recombination on an inactive lineage, etc.  The PickTime()
  routine calculates the time of the next such event.  The DoEvent() 
  routine calls Tree code needed to actually implement the event.  
  The Done() routine indicates whether resimulation needs to continue; 
  only if all events are Done() will resimulation terminate before
  the end of the tree is reached.

  The class is polymorphic on event type, which is related
  to Force, but more than one event type can be associated
  with the same Force (for example, the two types of recombination). 

  Events must be initialized with the parameters of the current
  chain via a call to InstallParameters() before they are used. 

  Written by Mary Kuhner
  March 2002--revised to enable Growth force

***************************************************************/

class Event
{
  public:
                   Event() { ar = NULL; }; 
                   Event(const Event& src) : ar(src.ar) {};
    virtual        ~Event() {};

    virtual double PickTime() = 0;
    virtual void   DoEvent(double eventT) = 0;
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts) = 0;
    virtual bool   Done() const;
    virtual Event* Clone() const = 0;
    virtual string Type() const = 0;   // RTII
            void   SetArranger(ResimArranger& newowner) { ar = &newowner; };

  protected:
    ResimArranger* ar;         // points back to owning arranger
    long           maxEvents;  // maximum for this force

  private:
            Event& operator=(const Event& src);  // not defined

}; /* Event class */ 

//______________________________________________________________________

class ActiveCoal : public Event
{
  public:
                   ActiveCoal() {};
                   ActiveCoal(const ActiveCoal& src);

    virtual double PickTime();
    virtual void   DoEvent(double eventT); 
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual string Type() const { return "ActiveCoal"; };   // RTII

  private:                      // these are set up by InstallParameters
    vector<double> invTheta;    // precomputed 1/Theta array
    long           chosenpop;  // population of current event

}; /* ActiveCoal Event */

//______________________________________________________________________

// The growth-aware version of the above

class ActiveGrowCoal : public Event 
{
  public:
                   ActiveGrowCoal() {};
                   ActiveGrowCoal(const ActiveGrowCoal& src);

    virtual double PickTime();
    virtual void   DoEvent(double eventT); 
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual string Type() const { return "ActiveGrowCoal"; };   // RTII

  private:                      // these are set up by InstallParameters
    vector<double> Theta;       // precomputed Theta array
    vector<double> g;           // growth rates
    long           chosenpop;   // population of current event

}; /* ActiveGrowCoal Event */

//______________________________________________________________________

class InactiveCoal : public Event
{
  public:
                   InactiveCoal() {};
                   InactiveCoal(const InactiveCoal& src);

    virtual double PickTime();
    virtual void   DoEvent(double eventT);
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual string Type() const { return "InactiveCoal"; };   // RTII

  private:                      // these are set up by InstallParameters
    vector<double> inv2Theta;  // precomputed 2/Theta array
    long           chosenpop;  // population of current event

}; /* InactiveCoal Event */

//______________________________________________________________________

// the growth-aware version of the above

class InactiveGrowCoal : public Event
{
  public:
                   InactiveGrowCoal() {};
                   InactiveGrowCoal(const InactiveGrowCoal& src);

    virtual double PickTime();
    virtual void   DoEvent(double eventT);
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual string Type() const { return "InactiveGrowCoal"; };   // RTII

  private:                      // these are set up by InstallParameters
    vector<double> Theta;       // precomputed Theta array
    vector<double> g;           // growth rates
    long           chosenpop;   // population of current event

}; /* InactiveGrowCoal Event */

//______________________________________________________________________

class MigEvent : public Event
{
  public:
                   MigEvent() {};
                   MigEvent(const MigEvent& src);

    virtual double PickTime();
    virtual void   DoEvent(double eventT);
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual string Type() const { return "MigEvent"; };   // RTII

  private:                      // these are set up by InstallParameters
    DoubleVec2d    rescaledMigRates;  // rescaled parameters
    DoubleVec1d    immigrationRates;  // combined over source populations
    long           frompop;
    long           topop;

}; /* MigEvent */

//______________________________________________________________________

// the growth-aware version of the above

class MigGrowEvent : public Event
{
  public:
                   MigGrowEvent() {};
                   MigGrowEvent(const MigGrowEvent& src);

    virtual double PickTime();
    virtual void   DoEvent(double eventT);
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual string Type() const { return "MigGrowEvent"; };   // RTII

  private:                      // these are set up by InstallParameters
    DoubleVec2d    rescaledMigRates;  // rescaled parameters
    DoubleVec1d    immigrationRates;  // combined over source populations
    DoubleVec1d    g;                 // growth rates
    long           frompop;
    long           topop;

}; /* MigGrowEvent */

//______________________________________________________________________

class ActiveRec : public Event
{
  public:
                   ActiveRec() {};
                   ActiveRec(const ActiveRec& src);

    virtual double PickTime();
    virtual void   DoEvent(double eventT);
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual string Type() const { return "ActiveRec"; };   // RTII

  private:                      // these are set up by InstallParameters
    double  recrate;  // recombination rate

}; /* ActiveRec Event */

//______________________________________________________________________

class InactiveRec : public Event
{
  public:
                   InactiveRec() {};
                   InactiveRec(const InactiveRec& src);

    virtual double PickTime();
    virtual void   DoEvent(double eventT); 
    virtual void   InstallParameters(const ForceSummary& forces,
                      const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual string Type() const { return "InactiveRec"; };   // RTII

// In the absence of a more correct algorithm for detecting upcoming
// InactiveRecombinations, we presume that resimulation must continue
// to the bottom of the tree.

    virtual bool   Done() const           { return false; };

  private:                      // these are set up by InstallParameters
    double  recrate;  // recombination rate

}; /* InactiveRec Event */

#endif
