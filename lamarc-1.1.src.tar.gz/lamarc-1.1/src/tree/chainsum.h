//$Id: chainsum.h,v 1.3 2002/06/25 03:17:55 mkkuhner Exp $
#ifndef CHAINSUMMARY
#define CHAINSUMMARY

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/************************************************************************
Class ChainSummary.
A managed container of TreeSummaries.  Outside the maximizer, no one 
but ChainSummary needs to deal with TreeSummaries directly; call 
ChainSummary routines to summarize a tree or note the presence of a 
run of identical trees.

ChainSummary owns its TreeSummaries and deletes them in its destructor.
No copy constructor or op= are provided as they would be very expensive
(ChainSummary objects are huge).

Both classes have public members for possible speed savings in the
maximizer, as they are used by speed-critical code.

The AdjustSummaries functions are used to "nudge" the event counts
upwards slightly when they are zero, thereby avoiding attraction to
an estimate of zero.  The strategy adopted is to increase the 
recombination event count by 1 unit, and the migration event counts
by a total of 1 unit (divided across all migration rates).
This mechanism ABSOLUTELY requires that all TreeSummaries present
in a ChainSummary are of the same kind.  AdjustSummaries() should
only be called on a completed chain.

InspectSummaries() is a helper function used by ChainSummary::AdjustSummaries().

Written by Jim Sloan, revised by Mary Kuhner
   added debug printers Jon Yamato 2001/04/23
   added AdjustSummaries Mary Kuhner 2001/07/05
   massively refactored Mary Kuhner 2002/04/18 (and hey, it's snowing today!)
   [Mary are you clairvoyant???? then today is the 2002/04/05 PB] 
**********************************************************************/

// a ForceParameters is included as a member
#include "forceparam.h"

class TreeSummary;

class ChainSummary
{
                  ChainSummary(const ChainSummary&);   // undefined
    ChainSummary& operator=(const ChainSummary&);      // undefined

  public:
    ForceParameters      forceParameters; // parameters at which chain was run
    vector<TreeSummary*> treeSummaries;

         ChainSummary()  {};
         ~ChainSummary();
    void Clear();
    void SummarizeTree(const Tree& tree);
    void AddCopy()             { treeSummaries.back()->AddCopy(); };
    void AdjustSummaries();

    void PrintSummaries();
    
};

#endif




