//$Id: parameter.cpp,v 1.4 2002/06/25 03:17:57 mkkuhner Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "parameter.h"
#include "forcesummary.h"

using namespace std;

//___________________________________________________________________________

double ResultStruct::GetMLE(long region) const
{
  assert(region >= 0 && static_cast<unsigned long>(region) < mles.size());
  return mles[region];
} /* GetMLE */

//___________________________________________________________________________

double ResultStruct::GetOverallMLE() const
{
// if there is exactly one region, we will return the regional
// mle as the overall mle.  If there are multiple regions and
// no overall mle, something is wrong.

  assert(!(overallmle.empty() && mles.size() != 1));

  if (overallmle.empty()) return mles[0];
  else return overallmle[0];
} /* GetOverallMLE */

//___________________________________________________________________________

DoubleVec1d ResultStruct::GetAllMLEs()  const
{
  assert(!mles.empty());
  DoubleVec1d result = mles;
  if (!overallmle.empty()) result.push_back(overallmle[0]);
  return result;
} /* GetAllMLEs */

//___________________________________________________________________________

const ProfileStruct& ResultStruct::GetProfile(long region) const
{
  assert(region >= 0 && static_cast<unsigned long>(region) < profiles.size());
  return profiles[region];
} /* GetProfile */

//___________________________________________________________________________

const ProfileStruct& ResultStruct::GetOverallProfile() const
{
// if there is exactly one region, we will return its profile.
// otherwise, it is an error to ask for overalls if there aren't
// any.

  assert(!(overallprofile.empty() && profiles.size() != 1));

  if (overallprofile.empty()) return profiles[0];
  else return overallprofile[0];
} /* GetOverallProfile */

//___________________________________________________________________________

vector<ProfileStruct> ResultStruct::GetAllProfiles() const
{
  assert(!profiles.empty());
  vector<ProfileStruct> result = profiles;
  result.push_back(overallprofile[0]);
  return result;
} /* GetAllProfiles */

//___________________________________________________________________________

const PlotStruct& ResultStruct::GetPlot(long param) const
{
  Plotmap::const_iterator it = plots.find(param);
  assert(it == plots.end());
  return (*it).second;
  
} /* GetPlot */

//___________________________________________________________________________

void ResultStruct::AddPlot(long param, const PlotStruct& plot) 
{
#ifndef NDEBUG
  Plotmap::const_iterator it = plots.find(param);
  assert(it != plots.end());
#endif
  plots.insert(make_pair(param, plot));

} /* AddPlot */

//___________________________________________________________________________
//___________________________________________________________________________


Parameter::Parameter(paramstatus isvalid, const string sname, const string lname, 
                     proftype prof)
: validity(isvalid),
 shortname(sname),
  name(lname),
  profiletype(prof),
  // DEBUG these will eventually be settable, but are currently
  // hard-wired
  plotstart(0.0001),
  plotend(1000.0),
  plotpoints(36),
  style(log_ten)
{
  // no code yet
} /* Parameter constructor */

//___________________________________________________________________________

vector<centilepair> Parameter::GetPriorLikes(long region) const
{

  assert(IsValid());
  vector<centilepair> answer;

  const ProfileStruct& profile = results.GetProfile(region);
  vector<ProfileLineStruct>::const_iterator it;

  for (it = profile.profilelines.begin();
       it != profile.profilelines.end();
       ++it)
  {
    centilepair newpair(it->percentile, it->loglikelihood);
    answer.push_back(newpair);
  }
  return answer;
  
} /* GetPriorLikes */

//___________________________________________________________________________

vector<centilepair> Parameter::GetOverallPriorLikes() const
{
  assert(IsValid());

  vector<centilepair> answer;

  const ProfileStruct& profile = results.GetOverallProfile();
  vector<ProfileLineStruct>::const_iterator it;

  for (it = profile.profilelines.begin();
       it != profile.profilelines.end();
       ++it)
  {
    centilepair newpair(it->percentile, it->loglikelihood);
    answer.push_back(newpair);
  }
  return answer;
  
} /* GetOverallPriorLikes */

//___________________________________________________________________________

vector<vector<centilepair> > Parameter::GetProfiles(long region) const
{
  assert(IsValid());

  const ProfileStruct& profile = results.GetProfile(region);
  vector<ProfileLineStruct>::const_iterator line;

  vector<vector<centilepair> > answer;
  vector<centilepair> answerline;

  long parameter;
  long numparams = 0;
  // hack, sorry
  for (line = profile.profilelines.begin(); line != profile.profilelines.end();
       ++line) {
    if (!line->profparam.empty()) {
      numparams = line->profparam.size();
      break;
    }
  }

  // if this assert fires, profiles have been requested but none
  // whatsoever can be found....
  assert(numparams > 0);

  //long numparams = profile.profilelines[0].profparam.size();

  for (parameter = 0; parameter < numparams; ++parameter)
  {
    for (line = profile.profilelines.begin();
         line != profile.profilelines.end();
         ++line) 
    {
      double thisparam = line->profparam[parameter];
      centilepair newpair(line->percentile, thisparam);
      answerline.push_back(newpair);
    }
    answer.push_back(answerline);
    answerline.clear();
  }

  return answer;

} /* GetProfiles */

//___________________________________________________________________________

vector<vector<centilepair> > Parameter::GetOverallProfile() const
{
  assert(IsValid());

  vector<vector<centilepair> > answer;
  vector<centilepair> answerline;

  const ProfileStruct& profile = results.GetOverallProfile();
  vector<ProfileLineStruct>::const_iterator line;

  long parameter;
  // hack, sorry
  long numparams = profile.profilelines[0].profparam.size();

  for (parameter = 0; parameter < numparams; ++parameter)
  {
    for (line = profile.profilelines.begin();
         line != profile.profilelines.end();
         ++line) 
    {
      double thisparam = line->profparam[parameter];
      centilepair newpair(line->percentile, thisparam);
      answerline.push_back(newpair);
    }
    answer.push_back(answerline);
    answerline.clear();
  }

  return answer;

} /* GetOverallProfile */

//___________________________________________________________________________

vector<centilepair> Parameter::GetCIs(long region) const
{
  assert(IsValid());

  vector<centilepair> answer;

  const ProfileStruct& profile = results.GetProfile(region);
  vector<ProfileLineStruct>::const_iterator it;

  for (it = profile.profilelines.begin();
       it != profile.profilelines.end();
       ++it) 
  {
    centilepair newpair(it->percentile, it->profilevalue);
    answer.push_back(newpair);
  }
  return answer;

} /* GetCIs */

//___________________________________________________________________________

vector<centilepair> Parameter::GetOverallCIs() const
{
  assert(IsValid());

  vector<centilepair> answer;

  const ProfileStruct& profile = results.GetOverallProfile();
  vector<ProfileLineStruct>::const_iterator it;

  for (it = profile.profilelines.begin();
       it != profile.profilelines.end();
       ++it) 
  {
    centilepair newpair(it->percentile, it->profilevalue);
    answer.push_back(newpair);
  }
  return answer;

} /* GetOverallCIs */

//___________________________________________________________________________

void Parameter::AddProfile(const ProfileStruct& prof, likelihoodtype like) const
{
  assert(IsValid());
  switch (like) {
    case ssingle: 
      results.AddProfile(prof);
      break;
    case replicate:
      results.AddProfile(prof);
      break;
    case region:
      results.AddOverallProfile(prof);
      break;
    default:
      assert(false); // should never get here
  }
  
} /* AddProfile */

//___________________________________________________________________________
//___________________________________________________________________________

// Initialization of static variable, needs to be in .cpp
bool ParamVector::locked = false;

//___________________________________________________________________________

// This constructor makes a read/write ParamVector

ParamVector::ParamVector(const ForceSummary& fs)
: forcesum(const_cast<ForceSummary&>(fs))
{
  assert(!locked);        // attempt to check out a second set of parameters!
  parameters = forcesum.GetAllParameters();
  locked = true;
  readonly = false;
} /* ParamVector */

//___________________________________________________________________________

// This constructor can make a read-only ParamVector 

ParamVector::ParamVector(const ForceSummary& fs, bool rd)
: forcesum(const_cast<ForceSummary&>(fs))
{
  if (rd) {
    parameters = forcesum.GetAllParameters();
    readonly = true;
  } else {
    assert(!locked);        // attempt to check out a second set of parameters!
    parameters = forcesum.GetAllParameters();
    locked = true;
    readonly = false;
  }

} /* ParamVector */

//___________________________________________________________________________

ParamVector::~ParamVector()
{
  if (readonly) return;

  assert(locked);        // how did it get unlocked before destruction??
  forcesum.SetAllParameters(parameters);
  locked = false;

} /* ParamVector destructor */

//___________________________________________________________________________

Parameter& ParamVector::operator[](long index)
{
  assert(ParamVector::locked);        // how'd it get unlocked??

  // bounds checking
  assert(index >= 0);
  assert(index < static_cast<long>(parameters.size()));

  return parameters[index];

} /* ParamVector operator[] */

//___________________________________________________________________________

const Parameter& ParamVector::operator[](long index) const
{
  assert(index >= 0);
  assert(index < static_cast<long>(parameters.size()));

  return parameters[index];

} /* ParamVector operator[] const */

//___________________________________________________________________________

paramlistcondition ParamVector::CheckCalcProfiles() const
{
  vector <Parameter> :: const_iterator pit;
  long ok=0;
  long nok=0;
  for(pit=parameters.begin(); pit != parameters.end(); pit++)
    {
      if(pit->IsValid())
        {
          switch(pit->GetProfileType())
            {
            case fix:
            case percentile:
              ok++;
              break;
            case none:
            default:
              nok++;
              continue;
            }
        }
    }
  long sum = ok + nok;
  if(nok==sum)
    return NO;
  else
    {
      if(ok==sum)
        return YES;
      else
        return MIX;
    }
}

//___________________________________________________________________________

paramlistcondition ParamVector::CheckCalcPProfiles() const
{
  vector <Parameter> :: const_iterator pit;
  long fok=0;
  long pok=0;
  long nok=0;
  for(pit=parameters.begin(); pit != parameters.end(); pit++)
    {
      if(pit->IsValid())
        {
          switch(pit->GetProfileType())
            {
            case fix:
              fok++;
              break;
            case percentile:
              pok++;
              break;
            case none:
            default:
              nok++;
              continue;
            }
        }
    }
  long sum = fok + pok + nok;
  if(nok==sum)
    return NO;
  else
    {
      if(pok==sum)
        return YES;
      else
        return MIX;
    }
}

//___________________________________________________________________________

void ParamVector::SetAllProfileTypes(proftype prof)
{
  vector<Parameter>::iterator it;

  for (it = parameters.begin(); it != parameters.end(); ++it) {
    (*it).SetProfileType(prof);
  }
} /* SetAllProfileTypes */

//___________________________________________________________________________

proftype ParamVector::GetAllProfileTypes() const
{
  vector<Parameter>::const_iterator it;
  proftype test=none;
  for (it = parameters.begin(); it != parameters.end(); ++it) {
    if((test=(*it).GetProfileType())!=none)
       return test;
  }
    return none;
} /* GetAllProfileTypes */

//___________________________________________________________________________

long ParamVector::NumValidParameters() const
{
  vector<Parameter>::const_iterator it;

  long result = 0;

  for (it = parameters.begin(); it != parameters.end(); ++it) {
    if (it->IsValid()) ++result;
  }

  return result;
} /* NumValidParameters */
//___________________________________________________________________________

