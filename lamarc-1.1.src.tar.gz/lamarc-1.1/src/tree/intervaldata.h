//$Id: intervaldata.h,v 1.6 2002/06/25 03:17:57 mkkuhner Exp $

#ifndef INTERVAL
#define INTERVAL

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "vectorx.h"
#include <map>
#include <list>

// #include "summary.h" for management of summaries

/*
   This file contains two closely related classes used in storing
   TreeSummaries.  The first class, Interval, represents all data
   gathered from one time interval in a given tree.  It holds a
   pair of pointers to the previous and next Intervals *of a given
   event type* (for example, a coalescent Interval, one with a 
   coalescence event at the bottom, will hold a pointer to the previous
   and next coalescent event).  These pointers are NULL when there
   is no such event.

   Intervals are meant to be kept within an ordered std::list that 
   keeps them in time order; the previous/next system is independent of
   that and is used by maximizer code that requires lightning-fast
   access to the next event of the same type.

   The second class, IntervalData, contains and manages Intervals
   and also contains and manages the force-specific Summary objects
   that offer access to them.

   Written by Mary Kuhner
*/

class Summary;

typedef std::map<string, Summary*> Summap;

struct Interval
{
  double endtime;  //the backward-time te
  double starttime; // the start time ts today --- ts ---- te --- root
  LongVec1d poplines; // length is npop
  long activesites;  // used only for recombination
  long frompop;   // used for the single pop in a coalescence
  long topop;     // used only for migration
  long recsite;   // used only for recombination
  Interval* previous;
  Interval* next;

  Interval(Interval* prev, double etime, const LongVec1d& lines, long actives,
      long fpop, long tpop, long rsite)
    : endtime(etime), poplines(lines), activesites(actives), frompop(fpop),
      topop(tpop), recsite(rsite),
      previous(prev), next(NULL) {}

  // believe it or not, we accept the default copy constructor and
  // operator=.  The pointers are NOT owning, and copying them is okay.
}; 

//___________________________________________________________________
//___________________________________________________________________

class IntervalData
{
private:
  IntervalData& operator=(const IntervalData&); // not defined
  IntervalData(const IntervalData& src);        // not defined

public:

  // the following is a List for iterator stability
  std::list<Interval> intervals;

  // we must define the default constructor, since we disallow
  // the copy constructor and that prevents compiler generation of it
  IntervalData() {};

  Interval* AddInterval(Interval* prev, double time, const LongVec1d& k, 
    long s, long frompop, long topop, long recsite);

  unsigned long size() { return intervals.size(); };

  std::list<Interval>::iterator begin() { return intervals.begin(); };
  std::list<Interval>::const_iterator begin() const { return intervals.begin(); };
  std::list<Interval>::iterator end() { return intervals.end(); };
  std::list<Interval>::const_iterator end() const { return intervals.end(); };
  void clear() { intervals.clear(); };

  // debug function
  void PrintIntervalData() const;

};

#endif
