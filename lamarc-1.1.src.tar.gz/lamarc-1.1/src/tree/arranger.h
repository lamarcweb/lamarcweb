// $Id: arranger.h,v 1.9 2002/06/25 03:17:54 mkkuhner Exp $

#ifndef ARRANGER
#define ARRANGER

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <math.h>
#include <vector>
#include <string>

// #include "event.h"    uses Event methods in .cpp
// #include "force.h"   uses Forces::MakeEvents() in SetForces()
// #include "tree.h"
// #include "forceparam.h"
// #include "forcesummary.h"
// #include "random.h"

using namespace std;

class Event;
class Tree;
class ForceParameters;
class Random;
class ForceSummary;

/*******************************************************************
 The Arranger class transforms a tree and decides whether the new
 tree should be accepted or rejected.  It provides a routine 
 DeNovoTree() to make an independent tree, and a routine Rearrange to 
 make a tree based on a previous tree.

 Subclasses of Arranger carry out different types of transformation.

 Written by Jim Sloan, revised by Mary Kuhner
********************************************************************/

class Arranger
{
  private:
                     Arranger();                 // undefined
           Arranger& operator=(const Arranger&); // undefined

  protected:      
    Arranger(const Arranger& src);

    double  timing, savetiming;

  public:
            Tree   *tree;       // public for speedy access by Event subclasses
                                // also set by Chain::StartRegion()
    Random *randomSource;

                    Arranger(Random* rs);
    virtual         ~Arranger()                            {};

    // does not copy the tree pointer!
    virtual Arranger* Clone() const                       = 0; 
            
    // Arrangement functions 
    virtual void    SetParameters(const ForceSummary& forces, const
                                    ForceParameters& starts) = 0;
    virtual void    DeNovoTree()                          = 0;
    virtual void    Rearrange()                           = 0;
    virtual bool    Accept(Tree* oldtree, double temperature, bool badtree) = 0;

    // Getter/Setters
            Tree*   GetTree() const             { return tree; };
            double  GetTiming() const           { return timing; };
    virtual string  GetName() const             { return "Base-Arranger"; };  

            void    SetTree(Tree *t)            { tree = t; };
            void    SetTiming(double t)         { timing = t; };
            void    SetSaveTiming()             { savetiming = timing; };
            void    RestoreTiming()             { timing = savetiming; };

    // Most arrangers don't much care about forces, but some do.
    virtual void    SetForces(const ForceSummary&)    {};

    // what arranger am I? base class set all queries to false
    // but implementation sets it to true
    virtual bool    IsResimArranger() const   { return false;};
    virtual bool    IsDropArranger() const    { return false;};
    virtual bool    IsHapArranger() const     { return false;};
    virtual bool    IsTimeArranger() const    { return false;};
    virtual bool    IsRecSiteArranger() const { return false;};
};

//____________________________________________________________________

/*********************************************************************
 ResimArranger is an abstract base class for Arrangers which do any 
 form of resimulation of lineages downward through the tree.  It is 
 tightly coupled with the Event class, which provides expertese needed 
 in resimulation.  The eventvec is a vector of all possible types of 
 Events (depending on forces and other strategy details) which 
 ResimArranger polls to conduct its resimulation.
***********************************************************************/
  
class ResimArranger : public Arranger
{
  protected:
    vector<Event*> eventvec;    // code for various event types
    
    // helper functions
                   ResimArranger(const ResimArranger& src);
    void           ClearEventVec();
    virtual void   DropAll(double eventT);
    virtual double EventTime(Event*& returnevent, double eventT);
    virtual double Activate();
    virtual void   Resimulate(double eventT);
    virtual bool   StopNow() const;

  public:

    // The following variables are helpers for use by the subclasses
    // of Event.  They are public because otherwise Event would have to be a
    // friend, and this would tie Arranger to the specific subclasses of Event.

    long           nPopulations;
    vector<long>   actives;
    vector<long>   inactives;

                   ResimArranger(Random* rs) : Arranger(rs) {};
    virtual        ~ResimArranger() = 0;  // "implemented pure virtual"

    // Arrangement functions
    virtual void   SetParameters(const ForceSummary& forces, const
                                 ForceParameters& starts);
    virtual void   DeNovoTree();
    virtual void   Rearrange();
    virtual bool   Accept(Tree* oldtree, double temperature, bool badtree);

    // Getters/Setters
    virtual void   SetForces(const ForceSummary& fs);
    virtual bool   IsResimArranger() const { return true;}
    virtual string GetName() const { return "Resim-Arranger"; };
};

//________________________________________________________________

class DropArranger: public ResimArranger
{
  protected:
                       DropArranger(const DropArranger& src) :
                         ResimArranger(src) {};

  public:
                       DropArranger(Random* rs) : ResimArranger(rs) {};
    virtual           ~DropArranger() {};
    virtual Arranger*  Clone() const;
    virtual bool       IsDropArranger() const { return true;};
    virtual string     GetName() const { return "Drop-Arranger"; };

};

//________________________________________________________________

class RecSiteArranger : public ResimArranger
{
  protected:
                      RecSiteArranger(const RecSiteArranger& src)
                      : ResimArranger(src) {};

  public:
                      RecSiteArranger(Random *rs) : ResimArranger(rs) {};
    virtual           ~RecSiteArranger() {};
    virtual Arranger* Clone() const;

    virtual void      Rearrange()                                {};
    virtual bool      Accept(Tree*, double, bool badtree)      
                         { return badtree; };
    virtual bool      IsRecSiteArranger() const { return true; };
    virtual string    GetName() const { return "RecSite-Arranger"; };
};

//________________________________________________________________

class HapArranger : public Arranger
{
  protected:
                      HapArranger(const HapArranger& src)
                      : Arranger(src) {};

  public:
                      HapArranger(Random *rs) : Arranger(rs)   {};
    virtual void      SetParameters(const ForceSummary &forces,
                         const ForceParameters& starts);
    virtual void      Rearrange();
    virtual bool      Accept(Tree* oldtree, double temperature, bool badtree);
    virtual Arranger* Clone() const;
    virtual void      DeNovoTree();
    virtual bool      IsHapArranger() const { return true;};
    virtual string    GetName() const { return "Hap-Arranger"; };
};

//________________________________________________________________
//________________________________________________________________

#if 0
// DEBUG WARNING This code is commented out because:
// (a) it's not done yet
// (b) this class has a mysterious compile error on the Mac
//     with O2 optimization, and Mary is trying to find it.
// [NB Feb 2002:  this is news to Mary!]

class TimeArranger : public Arranger
{
  protected:
                      TimeArranger(const TimeArranger& src)
                      : Arranger(src) {};

  public:
                      TimeArranger(Random *rs) : Arranger(rs)  {};
    virtual void      SetParameters(const ForceSummary &forces,
                         const ForceParameters& starts);
    virtual void      Rearrange()                              {};
    virtual bool      Accept(Tree*, double, bool badtree)  
                        { return badtree; };
    virtual Arranger* Clone() const;
    virtual void      DeNovoTree() { /* DEBUG not done yet! */ };
    virtual bool      IsTimeArranger() const { return true;};
    virtual string    GetName() const { return "Time-Arranger"; };
};

//________________________________________________________________
//________________________________________________________________

#endif

#endif
