// $Id: force.cpp,v 1.24 2002/06/26 19:11:56 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "force.h"
#include "forcesummary.h"
#include "plforces.h"
#include "event.h"
#include "userparam.h"
#include "chainpack.h"
#include "datapack.h"
#include <math.h>
#include <numeric> // for stl::accumulate
#include "summary.h"
#include "registry.h"
#include "constants.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

//___________________________________________________________

Force::Force(const Force& src) 
 : tag(src.tag),
   name(src.name),
   fullname(src.fullname),
   parmname(src.parmname),
   parameters(src.parameters),
   axisname(src.axisname),
   sectitle(src.sectitle),
   maximum(src.maximum),
   defvalue(src.defvalue),
   paramsPerDimension(src.paramsPerDimension),
   plforcepnum(src.plforcepnum)
{
  if (src.plforceptr) plforceptr = src.plforceptr->Clone();
  else plforceptr = NULL;
  
} /* Force copy constructor */

//___________________________________________________________

DoubleVec1d Force::PopParameters(DoubleVec1d& valuelist)
{
// chew off as many values from the front of "valuelist"
// as this force has parameters, and return them.
// The passed vector is reduced in size.
  DoubleVec1d tempvec;
  DoubleVec1d::iterator start = valuelist.begin();
  DoubleVec1d::iterator end = start + parameters.size();

  tempvec.insert(tempvec.end(), start, end);
  valuelist.erase(start, end);
  return tempvec;

} /* PopParameters */

//___________________________________________________________

DoubleVec2d Force::GetMles() const
{
  assert(parameters.size() != 0);  // if there are no Parameters 
                                   // yet it's too early to call this!

  vector<Parameter>::const_iterator it;
  DoubleVec2d result;
  DoubleVec1d empty;

  for (it = parameters.begin(); it != parameters.end(); ++it) {
    if (it->IsValid()) result.push_back((*it).GetRegionMLEs());
    else result.push_back(empty);
  }
  return result;

} /* GetMles */

//___________________________________________________________

DoubleVec1d Force::GetPopmles() const
{
  assert(parameters.size() != 0);  // if there are no Parameters 
                                   // yet it's too early to call this!

  vector<Parameter>::const_iterator it;
  DoubleVec1d result;

  for (it = parameters.begin(); it != parameters.end(); ++it) {
    if (it->IsValid()) result.push_back((*it).GetOverallMLE());
    else result.push_back(0.0);
  }
  return result;

} /* GetPopmles */

//___________________________________________________________

StringVec1d Force::GetMethods() const
{
  assert(parameters.size() != 0);  // if there are no Parameters 
                                   // yet it's too early to call this!

  vector<Parameter>::const_iterator it;
  StringVec1d result;

  for (it = parameters.begin(); it != parameters.end(); ++it) {
    result.push_back((*it).GetMethod());
  }
  return result;

} /* GetMethods */

//___________________________________________________________

long Force::GetNParameters() const
{
long count = 0;
vector<Parameter>::const_iterator param;
for(param = parameters.begin(); param != parameters.end(); ++param)
   count += param->IsValid();

return count;

} /* GetNParameters */

//___________________________________________________________

proftype Force::SummarizeProfTypes() const
{
vector<Parameter>::const_iterator param;
for(param = parameters.begin(); param != parameters.end(); ++param)
   if (param->GetProfileType() != none) return param->GetProfileType();

return none;

} /* SummarizeProfTypes */

//___________________________________________________________

bool Force::AnyNoneProfTypes() const
{
vector<Parameter>::const_iterator param;
for(param = parameters.begin(); param != parameters.end(); ++param) {
   if (!param->IsValid()) continue;
   if (param->GetProfileType() == none) return true;
}

return false;

} /* AnyNoneProfTypes */

//___________________________________________________________

void Force::SetMethods(const StringVec1d& meth)
{
  assert(meth.size() == parameters.size());  // too few or many methods?

  vector<Parameter>::iterator param = parameters.begin();
  StringVec1d::const_iterator method = meth.begin();

  for ( ; param != parameters.end(); ++param, ++method) {
    param->SetMethod(*method);
  } 
  
} /* SetMethods */

//___________________________________________________________

void Force::SetProfileTypes(const vector<proftype>& prof)
{
  assert (prof.size() == parameters.size());  // too few or many?

  vector<Parameter>::iterator param = parameters.begin();
  vector<proftype>::const_iterator profile = prof.begin();

  for ( ; param != parameters.end(); ++param, ++profile) {
    param->SetProfileType(*profile);
  } 
  
} /* SetProfileTypes */

//___________________________________________________________

deque<bool> Force::UseCalculatedValues() const
{
deque<bool> howtouse;

vector<Parameter>::const_iterator it;
for (it = parameters.begin(); it != parameters.end(); ++it) {
   howtouse.push_back((*it).GetMethod() != USER);
}
  
return howtouse;

} /* Force::UseCalculatedValues */

//__________________________________________________________________

DoubleVec1d Force::QuickCalc(DataPack& datapack) const
{
DoubleVec1d answ(GetNParams(),0.0);

long reg, nregs = datapack.GetNRegions();
for(reg = 0; reg != nregs; ++reg) {
   QuickCalc(datapack.GetRegion(reg));
   DoubleVec1d params = datapack.GetRegion(reg).
      regiontheta.GetParametersByTag(GetTag());
   transform(answ.begin(),answ.end(),params.begin(),answ.begin(),
             plus<double>());
}

transform(answ.begin(),answ.end(),answ.begin(),
          bind2nd(divides<double>(),static_cast<double>(nregs)));

return answ;

} /* QuickCalc */

//___________________________________________________________
//___________________________________________________________

CoalForce::CoalForce(const DataPack& dpack) : Force() 
{
  tag = COAL;
  name = "Coal";
  fullname = "Coalescence";
  parmname = "Theta";
  fullparmname = "Theta";
  axisname.push_back(string("Population"));
  axisname.push_back(string("Region"));
  maximum = MAXLONG;                         // practically unlimited
  defvalue = DEFAULTTHETA;

 // Create the Parameters
  long npop = dpack.GetNPopulations();
  
  long pop;
  string sname, lname;
  
  sectitle = dpack.GetPopulationNames();

  StringVec1d popnames = dpack.GetPopulationNames();
  for (pop = 0; pop < npop; ++pop) {
     sname = "Theta" + ToString(pop+1);
     lname = "Theta for " + Pretty(popnames[pop],10);
     Parameter p(valid, sname, lname, DEFAULT_PROFILE);
     parameters.push_back(p); 
  }
  paramsPerDimension.push_back(npop);

  StringVec1d defmethods(npop, THETAMETHOD);
  SetMethods(defmethods);

  // setting up the coalescePL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  plforceptr = new CoalescePL (npop);
  // number of parameters used for this force
  // here it can easily be calculated 
  plforcepnum = npop;
} /* CoalForce constructor */ 

//___________________________________________________________

CoalForce::CoalForce(const CoalForce& src) : Force(src)
{
  // deliberately blank
} /* CoalForce copy constructor */

//___________________________________________________________
void CoalForce::ChangetoCoalGrowPL(long nparam)
{ 
      delete plforceptr;
      plforcepnum = nparam;
      plforceptr = new CoalesceGrowPL(plforcepnum);
}
//___________________________________________________________
void CoalForce::ChangetoCoalPL(long nparam)
{ 
      delete plforceptr;
      plforcepnum = nparam;
      plforceptr = new CoalescePL(plforcepnum);
}
//___________________________________________________________

double CoalForce::CalcWatterson(const Region& reg, long pop) const
{
  long seq, nseqs = reg.GetNTips(pop);
  long nsites = reg.GetNsites();
  long nvarmarkers = (reg.CalcNVariableMarkers())[pop];

  double estimate = 0.0;
  for(seq = 1; seq < nseqs; ++seq) estimate += 1.0/seq;
  estimate = nvarmarkers/(nsites*estimate);

  if (!estimate) estimate = GetDefaultValue();

  return estimate;

} /* CoalForce::CalcWatterson */

//___________________________________________________________

double CoalForce::CalcFst(const Region& reg, long pop) const
{
  double estimate = 0.0;
  DoubleVec1d fw = reg.datatype->CalcFw(reg);
  DoubleVec1d fb = reg.datatype->CalcFb(reg);


  long index1;
  long otherpop, npops = fw.size();

  for(otherpop = 0; otherpop < npops; ++otherpop) {
     if (otherpop == pop) continue;
     index1 = pop * npops + otherpop;  // position in linear vector
     double fb12 = fb[index1];
     double numer = -2.0 * fb12 + fw[pop] + fw[otherpop];
     double denom = -2.0 * fb12 *fb12 + fw[pop] + fw[otherpop] + 
                    fw[pop] * fw[pop];

     if (denom != 0.0)
        estimate += (numer * (1.0 - fw[pop])) / denom;
  }

  if (estimate <= 0.0) {
     estimate = GetDefaultValue();
  } else {
     estimate /= npops;
  }

  return estimate;

} /* CoalForce::CalcFst */

//___________________________________________________________

StringVec1d CoalForce::MakeStartParamReport()
{
  StringVec1d rpt;
  verbosity_type verbose = registry.GetUserParameters().GetVerbosity(); 

  if (verbose == VERBOSE) {
     string line = fullparmname;
     StringVec1d meth = registry.GetForceSummary().GetMethods(COAL);
     DoubleVec1d start = registry.GetForceSummary().GetStartParameters().GetThetas();
     if (parameters.size() > 1UL) {                               
        line += " (USR = user, WAT = watterson, FST = FST)";
        rpt.push_back(line);
        line = "Population";
        unsigned long param;
        for(param = 0; param < parameters.size(); ++param) {
           line += " "+ToString(param+1)+" "+ShortenName(meth[param]);
           line += " "+Pretty(start[param],12);
           rpt.push_back(line);
           line.assign(10,' ');
        }
     } else {
        line += " (" + meth[0] + ")";
        line = MakeJustified(line,-25);
        line += MakeJustified(Pretty(start[0]),25);
        rpt.push_back(line);
     }
  }

  return(rpt);
} /* CoalForce::MakeStartParamReport */

//___________________________________________________________

StringVec1d CoalForce::MakeChainParamReport(const ChainOut& chout)
{
    return(Tabulate(chout.GetEstimates().GetThetas(), 8));
} /* CoalForce::MakeChainParamReport */

//__________________________________________________________________

void CoalForce::InsertParameters(DoubleVec1d& v, ForceParameters& fp)
{
  fp.SetThetas(PopParameters(v));

} /* InsertParameters */ 

//__________________________________________________________________

vector<Event*> CoalForce::MakeEvents() const
{
  vector<Event*> tempvec;
  tempvec.push_back(new ActiveCoal);
  tempvec.push_back(new InactiveCoal);
  return tempvec;
} /* MakeEvents */

//__________________________________________________________________

inline Summary* CoalForce::CreateSummary(IntervalData& interval, long numpop, bool
  shortness) const
{
  return new CoalSummary(interval, numpop, shortness);
} /* CreateSummary */

//__________________________________________________________________

void CoalForce::QuickCalc(Region& reg) const
{
DoubleVec1d thetas(parameters.size());
unsigned long pop;
for(pop = 0; pop < parameters.size(); ++pop) {
   thetas[pop] = CalcWatterson(reg,pop);

   string method = parameters[pop].GetMethod();

   if (method == WATTERSON) {
      /* already done, do nothing */
   } else if (method == USER) {
      /* don't need to do anything here */
   } else if (method == FST) {
      thetas[pop] = CalcFst(reg,pop);
   }// else {
   //  assert(false);
   // }
}

reg.regiontheta.SetThetas(thetas);

} /* QuickCalc */

//___________________________________________________________

bool CoalForce::IsValidParameterValue(double paramval) const 
{
  // Theta must be strictly greater than zero

  return (paramval > 0);  
} /* IsValidParameterValue */

//___________________________________________________________

bool CoalForce::IsValidMethod(const string& meth) const 
{
  if (meth == USER || meth == WATTERSON || meth == FST) return true;
  return false;
} /* IsValidMethod */

//___________________________________________________________
//___________________________________________________________

MigForce::MigForce(const DataPack& dpack) : Force()
{
  tag = MIG;
  name = "Mig";
  fullname = "Migration";
  parmname = "Mig";
  fullparmname = "Migration Rate";
  axisname.push_back(string("Population"));
  axisname.push_back(string("Region"));
  maximum = DEFAULTMIGEVENTS;
  defvalue = DEFAULTMIGRATION;

  long npop = dpack.GetNPopulations();

  long pop1, pop2;
  string sname, lname;
  StringVec1d popnames = dpack.GetPopulationNames();
  for (pop1 = 0; pop1 < npop; ++pop1) {
    for (pop2 = 0; pop2 < npop; ++pop2) {
      if (pop1 == pop2) {
         Parameter p(invalid); // a placeholder Parameter
         parameters.push_back(p);
         continue;
      } else {
         sname = "M" + ToString(pop2+1) + ToString(pop1+1);
         lname = "MigRate from " + Pretty(popnames[pop2],10)
                 + " to " + Pretty(popnames[pop1],10);
         Parameter p(valid, sname, lname, DEFAULT_PROFILE);
         parameters.push_back(p);
         string stitle("From");
         stitle += " "+popnames[pop2];
         stitle += " to "+popnames[pop1];
         sectitle.push_back(stitle);
      }
    }
  }

  StringVec1d defmethods(npop*npop, MIGMETHOD);
  SetMethods(defmethods);

  // MigRate is two-dimensional with npop parameters per dimension
  paramsPerDimension.push_back(npop);
  paramsPerDimension.push_back(npop);

  // setting up the coalescePL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  plforceptr = new MigratePL (npop);
  // number of parameters used for this force
  // here it can easily be calculated 
  plforcepnum = npop * npop;

} /* MigForce constructor */ 

//___________________________________________________________

MigForce::MigForce(const MigForce& src) : Force(src)
{

// deliberately blank

} /* MigForce copy constructor */

//___________________________________________________________
void MigForce::ChangetoMigGrowPL(long nparam)
{ 
      delete plforceptr;
      plforcepnum = nparam;
      // WARNING DEBUG Hey, commenting this out is disasterous!
      //      plforceptr = new MigrateGrowPL(plforcepnum);
      assert(false);  // this code ain't ready to be called!
}
//___________________________________________________________
void MigForce::ChangetoMigPL(long nparam)
{ 
      delete plforceptr;
      plforcepnum = nparam;
      plforceptr = new MigratePL(plforcepnum);
}

//___________________________________________________________

StringVec1d MigForce::MakeStartParamReport()
{
  StringVec1d rpt;
  verbosity_type verbose = registry.GetUserParameters().GetVerbosity(); 

  if (verbose == VERBOSE) {
     string line = fullparmname+" (USR = user, FST = FST)";
     rpt.push_back(line);
     StringVec2d meth = registry.GetForceSummary().Get2DMethods(MIG);
     DoubleVec2d start = registry.GetForceSummary().GetStartParameters().Get2DMigRates();
     long npops = registry.GetDataPack().GetNPopulations();
     long colwidth1 = 9, colwidth2 = 14;
     long totlength = npops * colwidth2 + colwidth1;
     line = MakeCentered("to",totlength);
     rpt.push_back(line);
     line = MakeJustified("Pop",colwidth1);
     long pop;
     for(pop = 0; pop < npops; ++pop)
        line += MakeCentered(ToString(pop+1),colwidth2);
     rpt.push_back(line);
     line = MakeJustified("from 1",colwidth1);
     for(pop = 0; pop < npops; ++pop) {
        long ipop;
        for(ipop = 0; ipop < npops; ++ipop) {
           string name = ShortenName(meth[pop][ipop]);
           if (pop == ipop) name = "-";
           if (name == "-") line += MakeCentered(name,colwidth2);
           else line += 
                    MakeCentered(name+" "+Pretty(start[pop][ipop],colwidth1),
                                 colwidth2);
        }
        rpt.push_back(line);
        line.erase();
        line = MakeJustified(ToString(pop+2),colwidth1);
     }
  }
  
  return(rpt);

} /* MigForce::MakeStartParamReport */

//___________________________________________________________

StringVec1d MigForce::MakeChainParamReport(const ChainOut& chout)
{
    return(Tabulate(chout.GetEstimates().Get2DMigRates(), 8));
} /* MigForce::MakeChainParamReport */

//__________________________________________________________________

void MigForce::InsertParameters(DoubleVec1d& v, ForceParameters& fp)
{
fp.SetMigRates(PopParameters(v));

} /* InsertParameters */ 

//__________________________________________________________________

vector<Event*> MigForce::MakeEvents() const
{
  vector<Event*> tempvec;
  tempvec.push_back(new MigEvent);
  return tempvec;
} /* MakeEvents */

//__________________________________________________________________

inline Summary* MigForce::CreateSummary(IntervalData& interval, long numpop, 
  bool shortness) const
{
  return new MigSummary(interval, numpop, shortness);
} /* CreateSummary */

//__________________________________________________________________

DoubleVec1d MigForce::CalcFst(const Region& reg) const
{
  DoubleVec1d estimate(parameters.size(),0.0);
  DoubleVec1d fw = reg.datatype->CalcFw(reg);
  DoubleVec1d fb = reg.datatype->CalcFb(reg);


  long index1, index2;
  long pop1, pop2, npops = fw.size();
  assert(parameters.size() ==  static_cast<unsigned long>(npops * npops));

  for(pop1 = 0; pop1 < npops; ++pop1) {
     for(pop2 = pop1+1; pop2 < npops; ++pop2) {
        index1 = pop1 * npops + pop2;  // position in linear vector
        double fb12 = fb[index1];
        double denom = -2.0 * fb12 + fw[pop1] + fw[pop2];
        if (denom == 0.0) estimate[index1] = GetDefaultValue();
        else estimate[index1] = 2.0 * fb12 / denom;
        if (estimate[index1] < 0.0) estimate[index1] = GetDefaultValue();
        index2 = pop2 * npops + pop1;  // lower triangle
        estimate[index2] = estimate[index1];
     }
  }

  return estimate;
} /* CalcFst */

//__________________________________________________________________

void MigForce::QuickCalc(Region& reg) const
{
  DoubleVec1d migs;
  bool invalid_pop = false;

  // Mary change:  we mustn't try to calculate FST if there are
  // populations with less than 2 sequences sampled
  long pop;
  long npops = static_cast<long>(sqrt(parameters.size()));
  for (pop = 0; pop < npops; ++pop) {
    if (reg.GetNTips(pop) < 2) invalid_pop = true;
  }

  if (!invalid_pop) migs = CalcFst(reg);
  else {  // assign FLAGDOUBLE to off-diagonal elements
    long pop2;
    for (pop = 0; pop < npops; ++pop) {
      for (pop2 = 0; pop2 < npops; ++pop2) {
        if (pop == pop2) migs.push_back(0.0);
        else migs.push_back(FLAGDOUBLE);
      }
    }
  }

  reg.regiontheta.SetMigRates(migs);

} /* QuickCalc */

//___________________________________________________________

bool MigForce::IsValidParameterValue(double paramval) const
{
  // Migration rates must be greater than or equal to zero

  return (paramval >= 0);  
} /* IsValidParameterValue */

//___________________________________________________________

bool MigForce::IsValidMethod(const string& meth) const
{
  if (meth == USER) return true;
  if (meth == FST) return true;
  return false;
} /* IsValidMethod */

//___________________________________________________________
//___________________________________________________________

RecForce::RecForce(const DataPack&) : Force()
{
  tag = REC;
  name = "Rec";
  fullname = "Recombination";
  parmname = "Rec";
  fullparmname = "Recombination Rate";
  axisname.push_back(string(""));
  axisname.push_back(string("Region"));
  sectitle.clear();
  sectitle.push_back(string(" "));
  maximum = DEFAULTRECEVENTS;
  defvalue = DEFAULTRECOMBINATIONRATE;

  string sname = "Rec";
  string lname = "RecRate";
  Parameter p(valid, sname, lname, DEFAULT_PROFILE);
  parameters.push_back(p);

  StringVec1d defmethods(1, RECMETHOD);
  SetMethods(defmethods);

  // There is only ever one RecRate parameter
  paramsPerDimension.push_back(1);

  // setting up the recombinePL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  plforceptr = new RecombinePL ();
  plforcepnum = 1;

} /* RecForce constructor */ 

  
//___________________________________________________________

RecForce::RecForce(const RecForce& src) : Force(src)
{
  // deliberately blank
} /* RecForce copy constructor */

//___________________________________________________________

StringVec1d RecForce::MakeStartParamReport() 
{
  StringVec1d rpt;
  verbosity_type verbose = registry.GetUserParameters().GetVerbosity(); 

  if (verbose == VERBOSE) {
     string line = fullparmname + " (";
     line += registry.GetForceSummary().GetMethods(REC)[0] + ")  ";
     line = MakeJustified(line,-35);
     double rec = registry.GetForceSummary().GetStartParameters().
                  GetRecRates()[0];
     line += MakeJustified(Pretty(rec),15);
     rpt.push_back(line);
  }

  return(rpt);

} /* RecForce::MakeStartParamReport */

//___________________________________________________________

StringVec1d RecForce::MakeChainParamReport(const ChainOut& chout)
{
  return(Tabulate(chout.GetEstimates().GetRecRates(), 8));
} /* RecForce::MakeChainParamReport */

//__________________________________________________________________

void RecForce::InsertParameters(DoubleVec1d& v, ForceParameters& fp)
{
fp.SetRecRates(PopParameters(v));

} /* InsertParameters */ 

//__________________________________________________________________

vector<Event*> RecForce::MakeEvents() const
{
  vector<Event*> tempvec;
  tempvec.push_back(new ActiveRec);
  tempvec.push_back(new InactiveRec);
  return tempvec;
} /* MakeEvents */

//__________________________________________________________________

inline Summary* RecForce::CreateSummary(IntervalData& interval, long numpop, 
  bool shortness) const
{
  // as far as we know, RecSummaries are always short.
  return new RecSummary(interval, numpop, true);
} /* CreateSummary */

//__________________________________________________________________

void RecForce::QuickCalc(Region& reg) const
{
DoubleVec1d estimate(1L,DEFAULTRECOMBINATIONRATE);

string method = parameters[0].GetMethod();

assert(method == USER);  // no other methods currently available!

reg.regiontheta.SetRecRates(estimate);

} /* QuickCalc */

//___________________________________________________________

bool RecForce::IsValidParameterValue(double paramval) const
{
  // Recombination rate must be greater than or equal to zero

  return (paramval >= 0);  
} /* IsValidParameterValue */

//___________________________________________________________

bool RecForce::IsValidMethod(const string& meth) const 
{
  if (meth == USER) return true;
  return false;
} /* IsValidMethod */

//___________________________________________________________
//___________________________________________________________

GrowthForce::GrowthForce(const DataPack& dpack) : Force()
{
  tag = GROW;
  name = "Grow";
  fullname = "Growth";
  parmname = "Growth";
  fullparmname = "Growth Rate";
  axisname.push_back(string("Population"));
  axisname.push_back(string("Region"));
  maximum = MAXLONG;                         // practically unlimited
  defvalue = DEFAULTGROWTH;

  // Create the Parameters
  long npop = dpack.GetNPopulations();
  long pop;
  string sname, lname;

  sectitle = dpack.GetPopulationNames();

  StringVec1d popnames = dpack.GetPopulationNames();
  for (pop = 0; pop < npop; ++pop) {
     sname = parmname + ToString(pop+1);
     lname = parmname + " for " + Pretty(popnames[pop],10);
     Parameter p(valid, sname, lname, DEFAULT_PROFILE);
     parameters.push_back(p); 
  }
  StringVec1d defmethods(npop, GROWMETHOD);
  SetMethods(defmethods);

  paramsPerDimension.push_back(npop);

  // setting up the recombinePL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  plforceptr = new GrowPL (npop);
  plforcepnum = npop;

} /* GrowthForce::ctor */

//___________________________________________________________

GrowthForce::GrowthForce(const GrowthForce& src) : Force(src)
{
  // no non-base class members to copy, so deliberately blank
} /* GrowthForce::copy ctor */

//___________________________________________________________

StringVec1d GrowthForce::MakeStartParamReport()
{
  StringVec1d report;
  verbosity_type verbose = registry.GetUserParameters().GetVerbosity();

  if (verbose == VERBOSE) {
     string line = fullparmname;
     StringVec1d meth = registry.GetForceSummary().GetMethods(GROW);
     DoubleVec1d start = registry.GetForceSummary().GetStartParameters().
                           GetGrowthRates();
     if (parameters.size() > 1UL) {
        line += " (USR = user)";
        report.push_back(line);
        line = "Population";
        unsigned long param;
        for(param = 0; param < parameters.size(); ++param) {
           line += " "+ToString(param+1)+" "+ShortenName(meth[param]);
           line += " "+Pretty(start[param],12);
           report.push_back(line);
           line.assign(10,' ');
        }
     } else {
        line += " (" + meth[0] + ")";
        line = MakeJustified(line,-25);
        line += MakeJustified(Pretty(start[0]),25);
        report.push_back(line);
     }

  }

  return report;

} /* GrowthForce::MakeStartParamReport */

//___________________________________________________________

StringVec1d GrowthForce::MakeChainParamReport(const ChainOut& chout)
{
  return(Tabulate(chout.GetEstimates().GetGrowthRates(), 8));
} /* GrowthForce::MakeChainParamReport */

//___________________________________________________________

void GrowthForce::InsertParameters(DoubleVec1d& v, ForceParameters& fp)
{
  fp.SetGrowthRates(PopParameters(v));

} /* GrowthForce::InsertParameters */

//___________________________________________________________

vector<Event*> GrowthForce::MakeEvents() const
{
  vector<Event*> tempvec;  // yes this returns an empty vector
  return tempvec;

} /* GrowthForce::MakeEvents() */

//__________________________________________________________________

inline Summary* GrowthForce::CreateSummary(IntervalData& interval, long numpop, 
  bool shortness) const
{
  return NULL;  // yes, we have no summary of our own

} /* CreateSummary */

//___________________________________________________________

void GrowthForce::ModifyEvents(vector<Event*>& events) const
{

  // This routine does a search-and-replace on the target
  // vector of Events.  It removes CoalActive, CoalInactive
  // and MigEvent Events and replaces them with growth versions.
  // ActiveRec and InactiveRec Events are definitely unaffected.
  // If you add another Event, you must decide if it is affected.

  vector<Event*>::iterator it = events.begin();
  vector<Event*>::iterator end = events.end();

  for ( ; it != end; ++it) {
    Event* oldevent = *it;
    if (oldevent->Type() == "ActiveCoal") {
       Event* newevent = new ActiveGrowCoal;
       delete oldevent;
       *it = newevent;
       continue;
    }
    if ((*it)->Type() == "InactiveCoal") {
       Event* newevent = new InactiveGrowCoal;
       delete oldevent;
       *it = newevent;
       continue;
    }
    if ((*it)->Type() == "MigEvent") {
       Event* newevent = new MigGrowEvent;
       delete oldevent;
       *it = newevent;
       continue;
    }
  }

} /* GrowthForce::MakeEvents() */

//___________________________________________________________

void GrowthForce::QuickCalc(Region& reg) const
{
DoubleVec1d estimate(reg.mydatapack.GetNPopulations(),DEFAULTGROWTH);

string method = parameters[0].GetMethod();
assert (method == USER);  // no other methods currently available

reg.regiontheta.SetGrowthRates(estimate);

} /* GrowthForce::QuickCalc */

//___________________________________________________________

bool GrowthForce::IsValidParameterValue(double parmval) const
{
  return true;  // All doubles are valid values of growth
} /* GrowthForce::IsValidParameterValue */

//___________________________________________________________

bool GrowthForce::IsValidMethod(const string& meth) const
{
  if (meth == USER) return true;
  return false;
} /* GrowthForce::IsValidMethod */

//___________________________________________________________
//___________________________________________________________

// Free functions in Force interface

Force* CreateForce(string tag, const DataPack& dpack)
{
  if (tag == MIG) return (new MigForce(dpack));
  if (tag == REC) return (new RecForce(dpack));
  if (tag == COAL) return (new CoalForce(dpack));
  if (tag == GROW) return (new GrowthForce(dpack));
  assert(false);   // encountered unknown force
  return NULL;     // this statement should never be reached

} /* CreateForce free function */

//___________________________________________________________

StringVec1d Tabulate(double params, long width=7)
{
  StringVec1d str;
  str.push_back(Pretty(params,width));
  return(str);
} /* Tabulate(double) */

//___________________________________________________________

StringVec1d Tabulate(const DoubleVec1d& params, long width=7)
{
  StringVec1d str;
  long i;
  for (i = 0; i < (long)params.size(); ++i) str.push_back(Pretty(params[i],width));
  return(str);
} /* Tabulate(DoubleVec1d) */

//___________________________________________________________

StringVec1d Tabulate(const DoubleVec2d& params, long width=7)
{
  StringVec1d str;
  long i;
  long j;
  for (i = 0; i < static_cast<long>(params.size()); ++i) {
    string tempstr = "";
    for (j = 0; j < static_cast<long>(params[0].size()); ++j) {
      if (j != 0) tempstr += " ";
      if (j != i) tempstr += Pretty(params[i][j],width);
      else {
        long k;
        for (k = 0; k < width; ++k) tempstr += "-";
      }
      tempstr += " ";
    }
    str.push_back(tempstr);
  }
  return(str);
} /* Tabulate(DoubleVec2d) */

//___________________________________________________________

string ShortenName(const string& str)
{

string upperstring(str);
transform(str.begin(), str.end(), upperstring.begin(), toupper);

if (upperstring == "USER") return string("USR");
if (upperstring == "WATTERSON") return string("WAT");
if (upperstring == "FST") return string("FST");
// if (str == "wakeley" || str == "Wakeley") return string("WAK");
if (upperstring == " " || upperstring == "-" || upperstring == "") return string("-");
return string("UNK"); // Unknown method!

} /* ShortenName */

//___________________________________________________________
//___________________________________________________________
