//$Id: forcesummary.h,v 1.9 2002/06/26 19:11:56 lamarc Exp $

#ifndef FORCESUMM
#define FORCESUMM

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************** 
 ForceSummary is the governing object for polymorphism along force lines.
 It creates the basic tree and manages other force-specific objects.

 It is not polymorphic along force lines, but it contains forcevec, a 
 vector of pointers to Force objects, which are polymorphic and 
 can be used as a run-down of which forces are in effect in the program.
 This information is used in maximization and in output reporting.

 ForceSummary owns the things that its forcevec points to, and will
 delete them in its destructor.  No one else deletes these objects!
 When a ForceSummary is copied, a new set of Force objects is
 created for it to point to. 

 Written by Jim Sloan, heavily revised by Mary Kuhner

Jon Yamato:
 added SummarizeData(datapack) 
Peter Beerli:
 added parameterlist class variable and 
 several Getters and Setters for it (8/30/01)
Mary Kuhner:
 took them out again, created the ParamVector class to remove
 the need for them (October 2001)
********************************************************************/

#include "lamarcdebug.h"
#include <vector>
#include <map>
#include "vectorx.h"
#include <string>
#include <stdlib.h>
#include "constants.h"
#include "forceparam.h"   
#include "plotstat.h"
#include "types.h"
#include <assert.h>

// Used by the .cpp file:
// #include "tree.h"         to create Tree objects
// #include "force.h"  to create Force objects
// #include "datapack.h" for access to Region functions in SummarizeData()

class Random;
class Force;
class Tree;
class TreeSummary;
class ForceParameters;
class ChainPack;
class DataPack;
class Parameter;
class ParamVector;
class ChainOut;
class Summary;

typedef vector<Force*> ForceVec;

//____________________________________________________________________
//____________________________________________________________________

class ForceSummary
{

  private:

    ForceVec forcevec;     // info on each force in use
    ForceVec backupforcevec;    // holds forces that have been unset

    ForceParameters startParameters;   // Starting values of the force parameters.
    ForceParameters calcParameters;    // Calculated values of the f.p.
    bool parameters_modified;          // Did we have to adjust these values?

    DoubleVec1d llikemles;             // likelihoods at the MLEs
    double      overallLlikemle;

//  vector<string>  migModel;      // ??? array of migration constraint codes -V2

    // Helper functions for handling forcevec

    void                     ClearForceVec();          // deletes contents of forcevec
    void                     ClearBackupForceVec();    // deletes contents of forcevec
    void                     CopyAllMembers(const ForceSummary& src);

    // mechanism for accessing the Parameters as a linearized vector using
    // a check-in/check-out scheme
    friend class ParamVector;
    vector<Parameter>        GetAllParameters();
    void                     SetAllParameters(const vector<Parameter>& src);

    // internal methods to look through list of cached unset force objects
    ForceVec::iterator       GetBackupForceByTag(const string& tag);
    ForceVec::const_iterator GetBackupForceByTag(const string& tag) const;

    // these methods are kind of bogus -- they're here because
    // they rely on access to the ForceSummary to do the
    // initialization -- ewalkup
    void InitializeForce(const string& tag,const DataPack& dpack);
    void InitializeCoalescence(const DataPack& dpack);
    void InitializeMigration(const DataPack& dpack);
    void InitializeGrowth(const DataPack& dpack);
    void InitializeRecombination (const DataPack& dpack);

  public:

                  ForceSummary();
                  ForceSummary(const ForceSummary& src);  
    ForceSummary& operator=(const ForceSummary& src);           
                  ~ForceSummary();

    // Data postprocessing -- quick estimators
    void          SummarizeData(DataPack& dpack); 
    // this function is not const because it sets:
    //    this->calcParameters
    //    dpack.GetAllRegions().regiontheta
           
    // Posterior output setup
    void          SetupPosteriors(const ChainPack& chpack,
                     const DataPack& dpack) const;

    // Factory Functions
    Tree*          CreateProtoTree(Random* rnd, long npops);
    TreeSummary*   CreateProtoTreeSummary(long npops) const;

    // reconciling plforces pointers in case of growth or not.
    void ReconcilePLForces(const DataPack & dpack);

    // Set Functions
    void  SetForce(const string& tag, const DataPack& dpack);
    void  UnsetForce(const string& tag);

    void  SetMaxEvents(const string& tag, long events);
    void  SetMethods(const string& tag, const vector<string> m);

    void SetStartParameters(const ForceParameters& fp);
    void SetCalcParameters(const ForceParameters& fp);

    void SetRegionMLEs(const ChainOut& chout);
    void SetOverallMLE(const ChainOut& chout);

    // Get Functions
    bool             AreParametersModified()  const { return parameters_modified; };
    long             GetNForces()             const { return forcevec.size(); };
    long             GetForceIndexByTag(const string& tag);
    long             GetForceIndexByTag(const string& tag) const;
    bool             CheckForce(const string& tag)   const; // is this force active?
    ForceVec::iterator       GetForceByTag(const string& tag);
    ForceVec::const_iterator GetForceByTag(const string& tag) const;

    long             GetMaxEvents(const string& tag) const;
    vector<string>   GetMethods(const string& tag)   const;

//  vector<string>   GetMigModel()            const { return migModel; }; -V2

    const ForceParameters& GetStartParameters()     const { return startParameters; };
    const ForceParameters& GetCalcParameters()      const { return calcParameters; };
    ForceParameters& GetStartParameters()                 { return startParameters; };
    ForceParameters& GetCalcParameters()                  { return calcParameters; };

    double GetLlikeMle(long region) const   {
                    assert(static_cast<unsigned>(region) < llikemles.size());
                                               return llikemles[region]; };

    double GetOverallLlikeMle()     const    { double mle = 
                   ((llikemles.size() == 1)
                    ? llikemles[0] : overallLlikemle); 
                    return mle; };

    // it is a ghastly error to call the next two functions unless
    // the underlying model actually is 2D (and square).  They
    // will throw an exception if you try.

//  StringVec2d      Get2DModel(const string& tag)   const;  -V2
    StringVec2d      Get2DMethods(const string& tag) const;

    ForceVec&        GetAllForces()          { return forcevec; }; 
    const ForceVec&  GetAllForces() const    { return forcevec; };

    long             GetNParameters(const string& tag) const;
    long             GetAllNParameters() const;
    StringVec1d      GetForceString() const;
    vector<double>   GetModifiers() const;
    proftype         GetOverallProfileType() const;

    // If you need to check out a set of Parameters as a linearized
    // vector, declare a variable of type ParamVector with a constructor
    // argument of this ForceSummary.  You can treat the ParamVector as
    // a vector<Parameter> for most purposes, and on its destruction it will
    // check the Parameters back in for you.


    // Validation
    bool IsValid()                          const;

};

// Free function used as helper:

bool CloseEnough(double a, double b);

#endif
