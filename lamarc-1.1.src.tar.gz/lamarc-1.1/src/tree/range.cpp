//$Id: range.cpp,v 1.4 2002/06/25 03:17:57 mkkuhner Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "range.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//_______________________________________________________________
//_______________________________________________________________

Range::Range()
{
nlinks = newlinks = recsite = FLAGLONG;

} /* Range::Range */

//_______________________________________________________________

void Range::ORAppend(rangepair newrange, rangeset& oldranges)
{

if (oldranges.empty()) {
   oldranges.insert(newrange);
   return;
}

rangeset::iterator last = --oldranges.end();

assert(newrange.first >= last->first); // expect sequential,
                                       // sorted input

// new is contained in old
if (newrange.second <= last->second) return;

// new is after old
if (newrange.first > last->second) {
   oldranges.insert(oldranges.end(),newrange);
   return;
}

// new starts within old and extends past it
newrange.first = last->first;
oldranges.erase(last);
oldranges.insert(oldranges.end(),newrange);
return;

} /* Range::ORAppend */

//_______________________________________________________________
// The return value is "is_range_overlapping?"
bool Range::ANDAppend(rangepair newrange, rangeset& oldranges)
{

if (oldranges.empty()) {
   oldranges.insert(newrange);
   return false;
}

rangeset::iterator last = --oldranges.end();

assert(newrange.first >= last->first); // expect sequential,
                                       // sorted input

// new is after old
if (newrange.first >= last->second) return false;

// new is contained in old
if (newrange.second <= last->second) {
   oldranges.erase(last);
   oldranges.insert(oldranges.end(),newrange);
   return true;
}

// new start within old and extends past it
newrange.second = last->second;
oldranges.erase(last);
oldranges.insert(oldranges.end(),newrange);
return true;

} /* Range::ANDAppend */

//_______________________________________________________________

rangeset Range::OR(const rangeset& set1, const rangeset& set2)
{

if (set1.empty()) return set2;
if (set2.empty()) return set1;

rangeset mergeset;
merge(set1.begin(),set1.end(),set2.begin(),set2.end(),
      inserter(mergeset,mergeset.begin()));

rangeset newset;
rangeset::iterator rit;
for(rit = mergeset.begin(); rit != mergeset.end(); ++rit)
   ORAppend(*rit,newset);

return newset;

} /* Range::OR */

//_______________________________________________________________

rangeset Range::AND(const rangeset& mother, const rangeset& father)
{

  rangeset::const_iterator m = mother.begin();
  rangeset::const_iterator f = father.begin();

  rangeset result;
  rangepair newpair;

  if (mother.empty() || father.empty()) return result;

  while (true) {
    newpair.first = max((*m).first, (*f).first);
    newpair.second = min((*m).second, (*f).second);

    if (newpair.first < newpair.second)
      result.insert(result.end(),newpair);

    if ((*m).second < (*f).second) ++m;
    else ++f;

    if (m == mother.end() || f == father.end()) return result;
  }

} /* Range::AND */

//_______________________________________________________________

rangeset Range::NEG(const rangeset& oldset, long nsites)
{
rangeset negset;

if (oldset.empty()) {
   negset.insert(rangepair(0L,nsites));
   return negset;
}

// We assume no adjacent range pairs (i.e. the pairs 1-3 and 3-6
// will always be instead represented as 1-6).
long start = 0;
rangeset::const_iterator rit;
for(rit = oldset.begin(); rit != oldset.end(); ++rit) {
   if (rit->first != 0) negset.insert(rangepair(start,rit->first));
   start = rit->second;
}
if (start != nsites) negset.insert(rangepair(start,nsites));

return negset;

} /* Range::NEG */

//_______________________________________________________________

long Range::Span(const rangeset& sites) const
{
if (sites.empty()) return 0L;

long start = sites.begin()->first;
long end = (--sites.end())->second;

return end - start - 1;

} /* Range::Span */

//_______________________________________________________
// At the end of this function, Range::newactives
// should contain the sites that span newly active links,
// and Range::newlinks should contain a count of those links.

void Range::UpdateNewLinks(long nsites)
{

// We dismiss some simple cases first, as a speedup.
assert(!oldsites.empty());  

newactivesites.clear();
newlinks = 0;

// If there are no active sites, there are no newly active links
if(activesites.empty()) return;

// Calculate the sites spanning the old active links and
// the sites spanning the current active links

long newstart = activesites.begin()->first;
long newend = (--activesites.end())->second;
long oldstart = oldsites.begin()->first;
long oldend = (--oldsites.end())->second;

// if all links used to be active, none can be newly active, OR
// if there is only 1 active site, there are no active links
if ((oldstart == 0 && oldend == nsites) || (newstart == newend-1))
   return;

// Find the sites spanning the old *inactive* links
rangeset deadlinks;
if (oldstart > 0) deadlinks.insert(rangepair(0,oldstart));
if (oldend < nsites) deadlinks.insert(rangepair(oldend-1,nsites-1));

assert(!deadlinks.empty());

rangeset livelinks;
livelinks.insert(rangepair(newstart,newend-1));

// Calculate the intersection of old dead links and current
// live links; these are newly active links
newactivesites = AND(deadlinks, livelinks);

// Compute the number of links involved
rangeset::iterator i = newactivesites.begin();
for ( ; i != newactivesites.end(); ++i) {
  newlinks += i->second - i->first;
}

} /* Range::UpdateNewLinks */

//_______________________________________________________________

Range& Range::operator=(const Range& src)
{
activesites = src.activesites;
newactivesites = src.newactivesites;
recsite = src.recsite;
nlinks = src.nlinks;
newlinks = src.newlinks;

return *this;

} /* Range::operator= */

//_________________________________________________

void Range::ClearAllSites()
{
activesites.erase(activesites.begin(),activesites.end());
newactivesites.erase(newactivesites.begin(),newactivesites.end());
nlinks = newlinks = 0;

} /* Range::ClearAllSites */

//_________________________________________________

void Range::SetActivesites(const rangeset& src)
{
activesites = src;
nlinks = Span(src);

} /* Range::SetActivesites */

//_________________________________________________

void Range::SetNewactivesites(const rangeset& src)
{
newactivesites = src;
newlinks = Span(src);

} /* Range::SetNewactivesites */

//_________________________________________________

void Range::SetOldsites(const Range& src, long nsites)
{
// As an optimization, src.oldsites may not exist if it
// has never been relevant; if so our old active sites
// are simply src's active sites.

if (src.oldsites.empty()) oldsites = src.activesites;
else oldsites = src.oldsites;

UpdateNewLinks(nsites);

} /* Range::SetOldsites */

//_________________________________________________

bool Range::IsSiteActive(long site) const
{
if (activesites.empty()) return false;

rangeset::const_iterator range;
for(range = activesites.begin(); range != activesites.end(); ++range) {
   if (range->second <= site) continue;

   if (range->first <= site) return true;
   break;
}

return false;

} /* Range::IsSiteActive */

//_________________________________________________

void Range::SetCRange(const Range& father, const Range& mother)
{
activesites = OR(father.activesites,mother.activesites);
nlinks = Span(activesites);

} /* Range::SetCRange */

//_________________________________________________

void Range::SetMRange(const Range& mother)
{
activesites = mother.activesites;
nlinks = Span(activesites);

} /* Range::SetMRange */

//_________________________________________________

void Range::SetRRange(const Range& mother, const rangepair& newsites)
{
rangeset newset;
newset.insert(newsites);
activesites = AND(mother.activesites,newset);
nlinks = Span(activesites);
recsite = ((newsites.first) ? newsites.first-1 : newsites.second-1);

} /* Range::SetRRange */

//_________________________________________________

bool Range::UpdateCRange(const Range& father, const Range& mother,
   long nsites)
{
rangeset newsites = OR(father.activesites,mother.activesites);

if (newsites == activesites) return false;

if (oldsites.empty()) oldsites = activesites;

activesites = newsites;
nlinks = Span(activesites);

UpdateNewLinks(nsites);

return true;

} /* Range::UpdateCRange */

//_________________________________________________

bool Range::UpdateMRange(const Range& mother, long nsites)
{
if (activesites == mother.activesites) return false;

if (oldsites.empty()) oldsites = activesites;

activesites = mother.activesites;
nlinks = Span(activesites);

UpdateNewLinks(nsites);

return true;

} /* Range::UpdateMRange */

//_________________________________________________

bool Range::UpdateRRange(const Range& mother, long nsites)
{
if (oldsites.empty()) oldsites = activesites;

rangeset recrange;
if (oldsites.begin()->first <= recsite)
   recrange.insert(rangepair(0L,recsite+1));
else
   recrange.insert(rangepair(recsite+1,nsites));

activesites = AND(mother.activesites,recrange);
nlinks = Span(activesites);
UpdateNewLinks(nsites);

return true;

} /* Range::UpdateRRange */

//_________________________________________________

void Range::PrintActives()
{
rangeset::iterator range;
cout << "[";
for(range = activesites.begin(); range != activesites.end(); ++range) {
   if (range != activesites.begin()) cout << ", ";
   cout << range->first << "-" << range->second;
}
cout << "]";

} /* Range::PrintActives */

//_________________________________________________

void Range::PrintNewActives()
{
rangeset::iterator range;
cout << "[";
for(range = newactivesites.begin(); range != newactivesites.end(); ++range) {
   if (range != newactivesites.begin()) cout << ", ";
   cout << range->first << "-" << range->second;
}
cout << "]";

} /* Range::PrintNewActives */

//_________________________________________________
