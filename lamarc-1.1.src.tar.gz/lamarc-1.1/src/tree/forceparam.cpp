//$Id: forceparam.cpp,v 1.3 2002/06/25 03:17:56 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "forceparam.h"
#include "forcesummary.h"
#include "force.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//___________________________________________________________________________
//___________________________________________________________________________

ForceParameters::ForceParameters(const ForceParameters &fp)
{
  CopyAllMembers(fp);
}

//___________________________________________________________________________

ForceParameters& ForceParameters::operator=(const ForceParameters& fp)
{
  CopyAllMembers(fp);
  return *this;

} /* operator= */

//___________________________________________________________________________

void ForceParameters::CopyAllMembers(const ForceParameters& fp)
{
  thetas = fp.thetas;
  migrates = fp.migrates;
  recrates = fp.recrates;
  growths = fp.growths;

} /* ForceParameters::CopyAllMembers */

//___________________________________________________________________________

void ForceParameters::SetParametersByTag(const string& tag, 
  const vector<double>& v)
{
  if (tag == COAL) SetThetas(v);
  if (tag == MIG) SetMigRates(v);
  if (tag == REC) SetRecRates(v);
  if (tag == GROW) SetGrowthRates(v);

} /* SetParametersByTag */

//___________________________________________________________________________

void ForceParameters::SetToMeanOf(const vector<ForceParameters>& params,
   const ForceSummary& fsumm)
{
  unsigned long pos, npos = params[0].GetParameters(fsumm).size();
  DoubleVec1d total(npos,0.0);
  vector<ForceParameters>::const_iterator param;
  for(param = params.begin(); param != params.end(); ++param) {
    DoubleVec1d pars = param->GetParameters(fsumm);
    for(pos = 0; pos < npos; ++pos)
       total[pos] += pars[pos];
  }
  for(pos = 0; pos < npos; ++pos)
     total[pos] /= params.size();

  SetParameters(total,fsumm);

} /* SetToMeanOf */

//___________________________________________________________________________

void ForceParameters::SetThetas(const vector<double>& v)
{
  thetas = v;

} /* SetThetas */

//___________________________________________________________________________

void ForceParameters::SetMigRates(const vector<double>& v)
{
  // get the dimensions of the square array, allowing for
  // rounding error

  double dblrowsize = sqrt(static_cast<double>(v.size()));
  long rowsize = static_cast<long>(dblrowsize + DBL_EPSILON);

  // put the given values into migrates, but never put a
  // non-zero value into the diagonal entries!

  long i, j;
  long index = 0;
  migrates.clear();
  for (i = 0; i < rowsize; ++i) {
    for (j = 0; j < rowsize; ++j) {
      if (i == j) migrates.push_back(0.0);
      else migrates.push_back(v[index]);
      ++index;
    }
  }
  
} /* SetMigRates */

//___________________________________________________________________________

void ForceParameters::SetRecRates(const vector<double>& v)
{
  assert(static_cast<long> (v.size()) == 1);  // program supports only 1 rec rate
  recrates = v;

} /* SetRecRates */

//___________________________________________________________________________

void ForceParameters::SetGrowthRates(const vector<double>& v)
{
  growths = v;
} /* SetGrowths */

//___________________________________________________________________________

void ForceParameters::SetParameters(vector<double> v, const ForceSummary&
  fsumm)
{
  const vector<Force*>& forces = fsumm.GetAllForces();
  vector<Force*>::const_iterator it;

  for (it = forces.begin(); it != forces.end(); ++it) {
    (*it)->InsertParameters(v, *this);
  }
} /* SetParameters */

//___________________________________________________________________________

void ForceParameters::ClearParameters()
{
  thetas.clear();
  migrates.clear();
  recrates.clear();
  growths.clear();
} /* ClearParameters */

//___________________________________________________________________________

vector<double> ForceParameters::GetParameters(const ForceSummary& fsumm) const
{
  vector<Force*> forces = fsumm.GetAllForces();
  vector<Force*>::iterator it;

  vector<double> tempvec;
  vector<double> resultvec;

  for (it = forces.begin(); it != forces.end(); ++it) {
    tempvec = (*it)->RetrieveParameters(*this);
    resultvec.insert(resultvec.end(), tempvec.begin(), tempvec.end());
  }
  return resultvec;

} /* GetParameters */

//___________________________________________________________________________

vector<double> ForceParameters::GetParametersByTag(const string& tag) const
{
  if (tag == COAL) return GetThetas();
  if (tag == MIG) return GetMigRates();
  if (tag == REC) return GetRecRates();
  if (tag == GROW) return GetGrowthRates();
  assert(false); // is a force missing?
  // we failed, return an empty vector
  vector<double> d;
  return d;
} /* GetParametersByTag */

//___________________________________________________________________________

DoubleVec2d ForceParameters::Get2DMigRates() const
{
  return SquareOffVector(migrates);
}

