//$Id: summary.h,v 1.9 2002/06/25 03:17:58 mkkuhner Exp $

#ifndef SUMMARY
#define SUMMARY

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "vectorx.h"
#include <list>
#include "constants.h"
#include "intervaldata.h"

/*
   This is a Force-polymorphic class which works with the IntervalData
   class (non-polymorphic) to provide needed summary information about
   a tree.  It can provide either Short or Long forms of its summary,
   depending on the presence or absence of perturbing forces like Growth
   (if Growth is in effect Long forms are necessary).

   Written by Mary Kuhner
*/

class Interval;

class Summary
{
private:
  Summary(const Summary&); // not defined
  Summary& operator=(const Summary&); // not defined

protected:
  IntervalData& intervalData;
  DoubleVec1d shortpoint;    // pre-computed ShortPoint results
                             // dimensioned by # of parameters
  DoubleVec1d shortwait;     // pre-computed ShortWait results
                             // dimensioned by # of parameters
  long npop;
  bool shortness;
  IntervalData fakeIntervals;

  // pointers into the linked list in IntervalData, or possibly
  // into fakeIntervals instead
  Interval* front;   // front interval of our type
  Interval* back;    // most recently added interval of our type

  virtual void ComputeShortPoint() = 0;
  virtual void ComputeShortWait() = 0;

public:

  Summary(IntervalData& interval, long numpops, bool shortform) 
    : intervalData(interval), npop(numpops), shortness(shortform),
      front(NULL), back(NULL) {};
  virtual ~Summary() {};

  virtual Summary* Clone(IntervalData& interval) const = 0;

  const DoubleVec1d& GetShortPoint() const; // nCoalescences, etc.
  const DoubleVec1d& GetShortWait() const;  // k(k-1)t, etc.

  Interval const * GetLongPoint() const;
  const std::list<Interval>& GetLongWait() const;

  void AddInterval(double time, LongVec1d k, long s, long frompop, 
    long topop, long recsite);

  virtual void AdjustSummary(const DoubleVec1d& totals) = 0;

  bool Compress();

  virtual string GetType() const = 0;
};

//_____________________________________________________________

class CoalSummary : public Summary
{
private:

  virtual void ComputeShortPoint();  // nCoalescences, etc.
  virtual void ComputeShortWait();   // k(k-1)t, etc.

public:

  CoalSummary(IntervalData& interval, long numpops, bool shortform) 
    : Summary(interval, numpops, shortform) {};
  virtual ~CoalSummary() {};
  virtual Summary* Clone(IntervalData& interval) const;
  virtual void AdjustSummary(const DoubleVec1d& totals);
  virtual string GetType() const { return COAL; };

};

//_____________________________________________________________

class MigSummary : public Summary
{
private:

  virtual void ComputeShortPoint(); 
  virtual void ComputeShortWait(); 

public:

  MigSummary(IntervalData& interval, long numpops, bool shortform) 
    : Summary(interval, numpops, shortform) {};
  virtual ~MigSummary() {};
  virtual Summary* Clone(IntervalData& interval) const;
  virtual void AdjustSummary(const DoubleVec1d& totals);
  virtual string GetType() const { return MIG; };

};

//_____________________________________________________________

class RecSummary : public Summary
{

private:

  virtual void ComputeShortPoint(); 
  virtual void ComputeShortWait(); 

public:
  RecSummary(IntervalData& interval, long numpops, bool shortform) 
    : Summary(interval, numpops, shortform) {};
  virtual ~RecSummary() {};
  virtual Summary* Clone(IntervalData& interval) const;
  virtual void AdjustSummary(const DoubleVec1d& totals);
  virtual string GetType() const { return REC; };

};

#endif
