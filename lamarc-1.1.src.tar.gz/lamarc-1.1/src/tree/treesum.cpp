//$Id: treesum.cpp,v 1.13 2002/06/25 03:17:58 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "treesum.h"
#include "tree.h"
#include "forcesummary.h"
#include "summary.h"
#include <map>
#include <iostream> 
#include <fstream>
#include <strstream>
#include "registry.h"
#include <iterator>

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

typedef std::map<char, DoubleVec1d> Eventmap;
typedef std::map<char, DoubleVec1d>::iterator Eventiter;

//____________________________________________________
//____________________________________________________
//____________________________________________________

// This copy constructor produces a usable EMPTY
// TreeSummary *even if its target was a full one*.
// No method is provided to copy the contents of a
// TreeSummary; it is considered too expensive.

TreeSummary::TreeSummary(const TreeSummary& src) 
: intervalData(),
  nCopies(0)
{
  Sumconst_iter it = src.summaries.begin();
  for ( ; it != src.summaries.end(); ++it) {
    Summary* sum = (*it).second->Clone(intervalData);
    summaries.insert(make_pair((*it).first, sum));
  }
  CacheSummaries();
} /* Copy ctor */

//____________________________________________________

TreeSummary* TreeSummary::Clone() const
{
  return new TreeSummary(*this);
} /* Clone */

//____________________________________________________

TreeSummary::~TreeSummary()
{
  Sumiter it = summaries.begin();
  for ( ; it != summaries.end(); ++it) {
    delete (*it).second;
  }
} /* dtor */
//____________________________________________________

void TreeSummary::Compress()
{
  Summap::iterator it = summaries.begin();
  bool allshort = true;

  for ( ; it != summaries.end(); ++it) {
    allshort = (*it).second->Compress() && allshort;
  }
  if (allshort) intervalData.clear();

} /* Compress */

//____________________________________________________

void TreeSummary::Summarize(const Tree& tree)
{

#if STATIONARIES
  ofstream of;
  of.open(INTERVALFILE.c_str(),ios::app);
#endif

  nCopies = 1;
  long nPop = tree.GetNPopulations();

  const TimeList& timeList = tree.GetTimeList();

// Tally up populations of tips into lineages vector

  LongVec1d lineages(nPop, 0L);
  Branchconstiter brit;
  Branchconstiter beginBody = timeList.BeginBody();

  for (brit = timeList.Begin(); brit != beginBody; ++brit)
    lineages[(*brit)->population]++;

// Traverse body of tree collecting information

#if STATIONARIES
  long interval = 0;
  double topTime = 0.0;
  double bottomTime = 0.0;
#endif

  for (brit = beginBody; brit != timeList.End(); ++brit)
  {
    // score the branch
    Branch* pBranch = *brit;

#if STATIONARIES
    double bottomTime = pBranch->eventtime;
    of << "int" << interval << " " << bottomTime - topTime << endl;
    ++interval;
    topTime = bottomTime;
#endif

    // This call adjusts lineages as a side effect

    pBranch->ScoreEvent(*this, lineages);
  }

// clean up if possible
  Compress();
  CacheSummaries();

#if STATIONARIES
  of.close();
#endif

} /* Summarize */

//____________________________________________________
// This is OPTIMIZATION code which supports the
// specialized GetMigSummary and so forth functions.
// It's ugly and force-specific but a significant
// speedup over calling GetSummary(MIG).
 
void TreeSummary::CacheSummaries()
{
  coalsummary = GetSummary(COAL);
  migsummary = GetSummary(MIG);
  recsummary = GetSummary(REC);
  growsummary = GetSummary(GROW);

} /* CacheSummaries */

//____________________________________________________

StringVec1d TreeSummary::PrintSummary() const
{
StringVec1d out;
#if 0
string line = "ncopy=";
line += ToString(nCopies) + " ";
out.push_back(line);

DoubleVec1d::const_iterator counts;
DoubleVec1d::const_iterator waits;

line = "   #coals ";
string line2 = "   waittm ";
for(counts = nCoalescences.begin(), waits = cWait.begin();
    counts != nCoalescences.end();
    ++counts, ++waits) {
   line += ToString(*counts) + " ";
   line2 += ToString(*waits) + " ";
}
out.push_back(line);
out.push_back(line2);

line = "   #migs  ";
line2 = "   waittm ";
for(counts = nMigrations.begin(), waits = mWait.begin();
    counts != nMigrations.end();
    ++counts, ++waits) {
   line += ToString(*counts) + " ";
   if (waits != mWait.end()) line2 += ToString(*waits) + " ";
   else --waits;
}
out.push_back(line);
out.push_back(line2);

#endif
return out;

} /* TreeSummary::PrintSummary */

//____________________________________________________

map<string, DoubleVec1d> TreeSummary::InspectSummary() const
{
// for each force, get a vector containing the number of events
// for each parameter; return them in a map indexed by force

  Summap::const_iterator summary;
  map<string, DoubleVec1d> counts;

  for (summary = summaries.begin(); summary != summaries.end(); ++summary) {
    counts.insert(make_pair(summary->first, summary->second->GetShortPoint()));
  }
  return counts;

} /* InspectSummary */

//____________________________________________________

void TreeSummary::AdjustSummary(const map<string, DoubleVec1d>& counts)
{

map<string, DoubleVec1d>::const_iterator fit;

for (fit = counts.begin(); fit != counts.end(); ++fit) {
  Summary* sum = GetSummary((*fit).first);
  assert(sum);  // no summary?!
  sum->AdjustSummary((*fit).second);
}

} /* AdjustSummary */

//____________________________________________________

Summary* TreeSummary::GetSummary(const string& type)
{

  // Returning NULL is not necessarily indicative of an error
  // state--some forces, notably Growth, do not have corresponding
  // Summaries.

  Sumiter it = summaries.find(type);
  if (it == summaries.end()) return NULL;
  else return (*it).second;

} /* GetSummary */

//____________________________________________________

Summary const* TreeSummary::GetSummary(const string& type) const
{

  // Returning NULL is not necessarily indicative of an error
  // state--some forces, notably Growth, do not have corresponding
  // Summaries.

  Sumconst_iter it = summaries.find(type);
  if (it == summaries.end()) return NULL;
  else return (*it).second;

} /* GetSummary const */

//____________________________________________________________

void TreeSummary::AddSummary(const string& type, Summary* sum)
{
  // we should not be adding an already present type!
  assert(summaries.find(type) == summaries.end());

  summaries.insert(make_pair(type, sum));

} /* AddSummary */

//____________________________________________________
//____________________________________________________

TreeSummary* RecTreeSummary::Clone() const
{
  return new RecTreeSummary(*this);
} /* Clone */

//____________________________________________________

void RecTreeSummary::Summarize(const Tree& tree)
{
#if STATIONARIES
  ofstream of;
  of.open(INTERVALFILE.c_str(), ios::app);
#endif

  nCopies = 1;
  long nPop = tree.GetNPopulations();
  LongVec1d lineages(nPop, 0L);

  const TimeList& timeList = tree.GetTimeList();

// Tally up populations of tips into lineages vector

  Branchconstiter brit;
  Branchconstiter beginBody = timeList.BeginBody();
  long activelinks = 0;

  for (brit = timeList.Begin(); brit != beginBody; ++brit)
  {
    lineages[(*brit)->population]++;
    activelinks += (*brit)->range.ActiveLinks();
  }

// Traverse tree collecting information

#if STATIONARIES
  long interval = 0;
  double topTime = 0.0;
  double bottomTime = 0.0;
#endif

  for (brit = beginBody; brit != timeList.End(); ++brit)
  {
    Branch* pBranch = *brit;
    pBranch->ScoreEvent(*this, lineages, activelinks);

#if STATIONARIES
    bottomTime = pBranch->eventtime;
    of << "int" << interval << " " << bottomTime - topTime << endl;
    ++interval;
    topTime = bottomTime;
#endif
  }

  // clean up if possible
  Compress();
} /* Summarize */

//____________________________________________________

StringVec1d RecTreeSummary::PrintSummary() const
{
StringVec1d out;
#if 0
string line = "ncopy=";
line += ToString(nCopies) + " ";
out.push_back(line);

DoubleVec1d::const_iterator counts;
DoubleVec1d::const_iterator waits;

line = "   #coals";
string line2 = "   waittm";
for(counts = nCoalescences.begin(), waits = cWait.begin();
    counts != nCoalescences.end();
    ++counts, ++waits) {
   line += ToString(*counts) + " ";
   line2 += ToString(*waits) + " ";
}
out.push_back(line);
out.push_back(line2);

line = "   #migs";
line2 = "   waittm";
for(counts = nMigrations.begin(), waits = mWait.begin();
    counts != nMigrations.end();
    ++counts, ++waits) {
   line += ToString(*counts) + " ";
   if (waits != mWait.end()) line2 += ToString(*waits) + " ";
   else --waits;
}
out.push_back(line);
out.push_back(line2);

line = "nrecs=" + ToString(nRecombinations);
line += " waittm=" + ToString(rWait);
out.push_back(line);

#endif
return out;

} /* RecTreeSummary::PrintSummary */

//________________________________________________________________________
//________________________________________________________________________
