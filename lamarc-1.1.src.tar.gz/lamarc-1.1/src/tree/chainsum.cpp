//$Id: chainsum.cpp,v 1.5 2002/06/25 03:17:55 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "treesum.h"
#include "chainsum.h"
#include "tree.h"
#include <fstream>
#include <algorithm>
#include <functional>

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//________________________________________________________________________
//________________________________________________________________________

void ChainSummary::Clear()
{
  long end, i;
  end = treeSummaries.size();
  for (i = 0; i < end; i++)
    delete treeSummaries[i];
  treeSummaries.clear();

} /* Clear */

//____________________________________________________

ChainSummary::~ChainSummary()
{
  Clear();
} /* ChainSummary destructor */

//____________________________________________________

void ChainSummary::SummarizeTree(const Tree& tree)
{
  treeSummaries.push_back(tree.SummarizeTree());
}

//____________________________________________________

void ChainSummary::PrintSummaries()
{
ofstream of;
of.open("summ.out",ios::app);

long index=0;
vector<TreeSummary*>::iterator treesum;
for(treesum = treeSummaries.begin(); treesum != treeSummaries.end();
    ++treesum) {
   cout << ToString(index) << ":";
   of << ToString(index) << ":";
   StringVec1d printsummary = (*treesum)->PrintSummary();
   StringVec1d::iterator line;
   for(line = printsummary.begin(); line != printsummary.end(); ++line) {
      cout << *line << endl;
      of << *line << endl;
   }
   cout << endl;
   of << endl;
   ++index;
}

of.close();

} /* ChainSummary::PrintSummaries */

//____________________________________________________

void ChainSummary::AdjustSummaries()
{
  vector<TreeSummary*>::iterator treesum = treeSummaries.begin();
  map<string, DoubleVec1d> totals;
  map<string, DoubleVec1d>::iterator totit;
  map<string, DoubleVec1d>::iterator newit;

  assert(treesum != treeSummaries.end());   // no trees?!

  // accumulate, over all treesummaries, total events for each force
  totals = (*treesum)->InspectSummary();   // first summary establishes vector size
  ++treesum;

  for (; treesum != treeSummaries.end(); ++treesum) {
    map<string, DoubleVec1d> newtot = (*treesum)->InspectSummary();
    assert(totals.size() == newtot.size());  // different number of forces?!
    for (totit = totals.begin(), newit = newtot.begin();
         totit != totals.end();
         ++totit, ++newit) {
      assert(totit->second.size() == newit->second.size());  // different n. of parameters?!
      // this line assumes that forces are in same order everywhere!
      transform(totit->second.begin(), totit->second.end(),
              newit->second.begin(), 
              totit->second.begin(),
              plus<double>());
    }
  }

  // We adjust the bin counts in the first tree summary.  This is
  // an arbitrary choice; as far as I know any tree summary would do.
  // The first tree might be atypical anyway, and therefore messing it 
  // up is relatively harmless.

  // This call will do nothing if all parameters have at least one
  // event, but that condition cannot be detected here because of 
  // legitimate zero entries on the diagonal for some forces

  treeSummaries.front()->AdjustSummary(totals);

} /* AdjustSummaries */

//____________________________________________________
