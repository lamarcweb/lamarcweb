// $Id: event.cpp,v 1.10 2002/06/26 19:11:55 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <algorithm>
#include "event.h"
#include "forceparam.h"
#include "forcesummary.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//____________________________________________________________________________
//____________________________________________________________________________

bool Event::Done() const
{ 
// As far as this event knows, we are Done if there are no more active 
// lineages.

  if (ar->tree->ActiveSize() == 0) return true;
  else return false;

} /* Done */

//____________________________________________________________________________
//____________________________________________________________________________

ActiveCoal::ActiveCoal(const ActiveCoal& src) 
 : Event(src)
{
  invTheta = src.invTheta;

} /* ActiveCoal copy constructor */

//____________________________________________________________________________

Event* ActiveCoal::Clone() const
{
  ActiveCoal* event = new ActiveCoal(*this);
  return event;

} /* ActiveCoal::Clone */

//____________________________________________________________________________

void ActiveCoal::InstallParameters(const ForceSummary& forces,
  const ForceParameters& starts)
{
  invTheta = starts.GetThetas();
  vector<double>::iterator it = invTheta.begin();
  
  for ( ; it != invTheta.end(); ++it) {
    *it = 1.0 / (*it);                 // we store 1/Theta for speed
  }
  maxEvents = forces.GetMaxEvents(COAL);
  
} /* InstallParameters */

//____________________________________________________________________________

double ActiveCoal::PickTime()
{
  map<double, long> times;
  double newtime;
  long i;

  for (i = 0; i < ar->nPopulations; ++i) {

    // if there are at least two active lineages in this population...
    if (ar->actives[i] > 1) {  

      // compute the time of the next coalescence
      newtime = - log(ar->randomSource->Float()) / 
        (invTheta[i] * ar->actives[i] * (ar->actives[i] - 1.0));

      // insert it into map (for sorting)
      times.insert(make_pair(newtime, i));
    }
  }

  if (times.empty()) { // no event is possible
    chosenpop = FLAGLONG;
    return FLAGDOUBLE;
  } else {
    // the first map entry is the smallest, and thus chosen, time
    map<double, long>::const_iterator mapit = times.begin();
    chosenpop = (*mapit).second;
    return (*mapit).first;
  }

} /* ActiveCoal::PickTime */

//____________________________________________________________________________

void ActiveCoal::DoEvent(double eventT)
{
  ar->tree->CoalesceActive(eventT, chosenpop, maxEvents);
} /* DoEvent */

//____________________________________________________________________________
//____________________________________________________________________________

ActiveGrowCoal::ActiveGrowCoal(const ActiveGrowCoal& src) 
 : Event(src)
{
  Theta = src.Theta;
  g = src.g;

} /* ActiveGrowCoal copy constructor */

//____________________________________________________________________________

Event* ActiveGrowCoal::Clone() const
{
  ActiveGrowCoal* event = new ActiveGrowCoal(*this);
  return event;

} /* ActiveCoal::Clone */

//____________________________________________________________________________

void ActiveGrowCoal::InstallParameters(const ForceSummary& forces,
  const ForceParameters& starts)
{
  Theta = starts.GetThetas();
  g = starts.GetGrowthRates();
  maxEvents = forces.GetMaxEvents(COAL);
  
} /* InstallParameters */

//____________________________________________________________________________

double ActiveGrowCoal::PickTime()
{
  map<double, long> times;
  double newtime = 0.0;
  long i;

  // compute coalescence terms per population
  for (i = 0; i < ar->nPopulations; ++i) {
    // if there are at least two active lineages in this population...
    if (ar->actives[i] > 1) {

      // compute the time of the next coalescence

      // first do computation in "magic time"
      newtime =  - log(ar->randomSource->Float()) / 
        (ar->actives[i] * (ar->actives[i] - 1.0) / Theta[i]);

      // now convert to "real time"
      if (g[i] != 0) {
        newtime = log(1.0 + g[i] * newtime)/g[i];
      }

      // insert it into map (for sorting)
      times.insert(make_pair(newtime, i));
    }
  }

  if (times.empty()) { // no event is possible
    chosenpop = FLAGLONG;
    return FLAGDOUBLE;
  } else {
    // the first map entry is the smallest, and thus chosen, time
    map<double, long>::const_iterator mapit = times.begin();
    chosenpop = (*mapit).second;
    return (*mapit).first;
  }

} /* ActiveGrowCoal::PickTime */

//____________________________________________________________________________

void ActiveGrowCoal::DoEvent(double eventT)
{
  ar->tree->CoalesceActive(eventT, chosenpop, maxEvents);
} /* DoEvent */

//____________________________________________________________________________
//____________________________________________________________________________

InactiveCoal::InactiveCoal(const InactiveCoal& src) 
 : Event(src)
{
  inv2Theta = src.inv2Theta;

} /* InactiveCoal copy constructor */

//____________________________________________________________________________

Event* InactiveCoal::Clone() const
{
  InactiveCoal* event = new InactiveCoal(*this);
  return event;

} /* InactiveCoal::Clone */

//____________________________________________________________________________

void InactiveCoal::InstallParameters(const ForceSummary& forces,
  const ForceParameters& starts)
{
  inv2Theta = starts.GetThetas();
  vector<double>::iterator it = inv2Theta.begin();

  for ( ; it != inv2Theta.end(); ++it) {
    *it = 2.0 / (*it);              // We store 2/Theta for speed
  }
  maxEvents = forces.GetMaxEvents(COAL);

} /* InstallParameters */

//____________________________________________________________________________

double InactiveCoal::PickTime()
{
  map<double, long> times;
  double newtime = 0.0;
  long i;

  for (i = 0; i < ar->nPopulations; ++i) {
    if (ar->actives[i] > 0 && ar->inactives[i] > 0) {
      newtime = - log (ar->randomSource->Float()) /
        (inv2Theta[i] * ar->actives[i] * ar->inactives[i]);
      times.insert(make_pair(newtime,i));
    }
  }

  if (times.empty()) { // no event is possible
    chosenpop = FLAGLONG;
    return FLAGDOUBLE;
  } else {
    // the first map entry is the smallest, and thus chosen, time
    map<double, long>::const_iterator mapit = times.begin();
    chosenpop = (*mapit).second;
    return (*mapit).first;
  }

} /* InactiveCoal::PickTime */

//____________________________________________________________________________

void InactiveCoal::DoEvent(double eventT)
{
  ar->tree->CoalesceInactive(eventT, chosenpop, maxEvents);
} /* DoEvent */

//____________________________________________________________________________
//____________________________________________________________________________

InactiveGrowCoal::InactiveGrowCoal(const InactiveGrowCoal& src) 
 : Event(src)
{
  Theta = src.Theta;

} /* InactiveGrowCoal copy constructor */

//____________________________________________________________________________

Event* InactiveGrowCoal::Clone() const
{
  InactiveGrowCoal* event = new InactiveGrowCoal(*this);
  return event;

} /* InactiveGrowCoal::Clone */

//____________________________________________________________________________

void InactiveGrowCoal::InstallParameters(const ForceSummary& forces,
  const ForceParameters& starts)
{
  Theta = starts.GetThetas();
  maxEvents = forces.GetMaxEvents(COAL);
  g = starts.GetGrowthRates();

} /* InstallParameters */

//____________________________________________________________________________

double InactiveGrowCoal::PickTime()
{
  map<double, long> times;
  double newtime;
  long i;

  for (i = 0; i < ar->nPopulations; ++i) {
    if (ar->actives[i] > 0 & ar->inactives[i] > 0) {

      // first do calculation in "magic time"
      newtime = - log(ar->randomSource->Float()) /
        ((2.0 / Theta[i]) * ar->actives[i] * ar->inactives[i]);

      // then convert to "real time"
      if (g[i] != 0) {
        newtime = log(1.0 + g[i] * newtime)/g[i];
      }

      // insert into map (for sorting)
      times.insert(make_pair(newtime,i));
    }
  }

  if (times.empty()) { // no event is possible
    chosenpop = FLAGLONG;
    return FLAGDOUBLE;
  } else {
    // the first map entry is the smallest, and thus chosen, time
    map<double, long>::const_iterator mapit = times.begin();
    chosenpop = (*mapit).second;
    return (*mapit).first;
  }

} /* InactiveGrowCoal::PickTime */

//____________________________________________________________________________

void InactiveGrowCoal::DoEvent(double eventT)
{
  ar->tree->CoalesceInactive(eventT, chosenpop, maxEvents);
} /* DoEvent */

//____________________________________________________________________________
//____________________________________________________________________________

MigEvent::MigEvent(const MigEvent& src) 
 : Event(src)
{
  rescaledMigRates = src.rescaledMigRates;
  immigrationRates = src.immigrationRates;

} /* MigEvent copy constructor */

//____________________________________________________________________________

Event* MigEvent::Clone() const
{
  MigEvent* event = new MigEvent(*this);
  return event;

} /* MigEvent::Clone */

//____________________________________________________________________________

void MigEvent::InstallParameters(const ForceSummary& forces,
  const ForceParameters& starts)
{
  vector<vector<double> > migRates = starts.Get2DMigRates();
  vector<double> indRate;

  rescaledMigRates.clear();
  immigrationRates.clear();

  double totalMig;
  long i, j;

  // computes cumulative migration rates in "rescaledMigRates"
  // and total immigration into a population in "immigrationRates"

  for (i = 0; i < ar->nPopulations; ++i) {
    totalMig = 0.0;
    indRate.clear();
    for (j = 0; j < ar->nPopulations; ++j) {
       totalMig += migRates[i][j];
       indRate.push_back(totalMig);     // cumulative rate
    }

    // normalize cumulative rates to total
    if (totalMig > 0) {
      for (j = 0; j < ar->nPopulations; ++j) {
        indRate[j] /= totalMig;   
      }
    }

    rescaledMigRates.push_back(indRate);      // cumulative rates
    immigrationRates.push_back(totalMig);     // total immigration
  }
  maxEvents = forces.GetMaxEvents(MIG);

} /* InstallParameters */

//____________________________________________________________________________

double MigEvent::PickTime()
{
  map<double, long> times;
  double newtime;
  long i;

  for (i = 0; i < ar->nPopulations; ++i) {
    if (ar->actives[i] > 0) {
      newtime = -log (ar->randomSource->Float()) /
        (immigrationRates[i] * ar->actives[i]);
      times.insert(make_pair(newtime, i));
    }  
  }

if (times.empty()) { // no event is possible
    frompop = FLAGLONG;
    topop = FLAGLONG;
    return FLAGDOUBLE;
  } else {
    // the first map entry is the smallest, and thus chosen, time
    map<double, long>::const_iterator mapit = times.begin();
    frompop = (*mapit).second;
    double rn = ar->randomSource->Float();
    for (topop = 0; rescaledMigRates[frompop][topop] < rn; topop++) {};
    return (*mapit).first;
  }

} /* MigEvent::PickTime */

//____________________________________________________________________________

void MigEvent::DoEvent(double eventT)
{
  assert(frompop >= 0 && topop >= 0);
  ar->tree->Migrate(eventT, frompop, topop, maxEvents);
} /* DoEvent */
    
//____________________________________________________________________________
//____________________________________________________________________________


MigGrowEvent::MigGrowEvent(const MigGrowEvent& src)
 : Event(src)
{
  rescaledMigRates = src.rescaledMigRates;
  immigrationRates = src.immigrationRates;
  g = src.g;

} /* MigGrowEvent copy constructor */

//____________________________________________________________________________

Event* MigGrowEvent::Clone() const
{
  MigGrowEvent* event = new MigGrowEvent(*this);
  return event;

} /* MigGrowEvent::Clone */

//____________________________________________________________________________

void MigGrowEvent::InstallParameters(const ForceSummary& forces,
  const ForceParameters& starts)
{
  vector<vector<double> > migRates = starts.Get2DMigRates();
  vector<double> indRate;

  rescaledMigRates.clear();
  immigrationRates.clear();

  double totalMig;
  long i, j;

  // computes cumulative migration rates in "rescaledMigRates"
  // and total immigration into a population in "immigrationRates"

  for (i = 0; i < ar->nPopulations; ++i) {
    totalMig = 0.0;
    indRate.clear();
    for (j = 0; j < ar->nPopulations; ++j) {
       totalMig += migRates[i][j];
       indRate.push_back(totalMig);     // cumulative rate
    }

    // normalize cumulative rates to total
    if (totalMig > 0) {
      for (j = 0; j < ar->nPopulations; ++j) {
        indRate[j] /= totalMig;
      }
    }

    rescaledMigRates.push_back(indRate);      // cumulative rates
    immigrationRates.push_back(totalMig);     // total immigration
  }
  maxEvents = forces.GetMaxEvents(MIG);
  g = starts.GetGrowthRates();

} /* InstallParameters */

//____________________________________________________________________________

double MigGrowEvent::PickTime()
{

  map<double, long> times;
  double newtime;
  long i;

  for (i = 0; i < ar->nPopulations; ++i) {
    if (ar->actives[i] > 0) {
      newtime = -log (ar->randomSource->Float()) /
        (immigrationRates[i] * ar->actives[i]);
      times.insert(make_pair(newtime, i));
    }
  }

if (times.empty()) { // no event is possible
    frompop = FLAGLONG;
    topop = FLAGLONG;
    return FLAGDOUBLE;
  } else {
    // the first map entry is the smallest, and thus chosen, time
    map<double, long>::const_iterator mapit = times.begin();
    frompop = (*mapit).second;
    double rn = ar->randomSource->Float();
    for (topop = 0; rescaledMigRates[frompop][topop] < rn; topop++) {};
    return (*mapit).first;
  }

} /* MigGrowEvent::PickTime */

//____________________________________________________________________________

void MigGrowEvent::DoEvent(double eventT)
{
  assert(frompop >= 0 && topop >= 0);
  ar->tree->Migrate(eventT, frompop, topop, maxEvents);
} /* DoEvent */

//____________________________________________________________________________
//____________________________________________________________________________

ActiveRec::ActiveRec(const ActiveRec& src) 
 : Event(src)
{
  recrate = src.recrate;

} /* ActiveRec copy constructor */

//____________________________________________________________________________

Event* ActiveRec::Clone() const
{
  ActiveRec* event = new ActiveRec(*this);
  return event;

} /* ActiveRec::Clone */

//____________________________________________________________________________

void ActiveRec::InstallParameters(const ForceSummary& forces,
  const ForceParameters& starts)
{
  assert(starts.GetRecRates().size() == 1);  // only one rec rate!
  recrate = starts.GetRecRates()[0];
  maxEvents = forces.GetMaxEvents(REC);

} /* InstallParameters */

//____________________________________________________________________________

double ActiveRec::PickTime()
{
  RecTree* tr = dynamic_cast<RecTree*>(ar->tree);
  assert(!(tr->ActiveLinks() > 0 && tr->ActiveSize() == 0));  // active sites w/o lineages
  if (tr->ActiveLinks() > 0) {
    return -log(ar->randomSource->Float()) / (recrate * tr->ActiveLinks());
  } else {
    return FLAGDOUBLE;
  }

} /* ActiveRec::PickTime */

//____________________________________________________________________________

void ActiveRec::DoEvent(double eventT)
{
  RecTree* tr = dynamic_cast<RecTree*>(ar->tree);
  tr->RecombineActive(eventT, maxEvents); 
} /* DoEvent */
    
//____________________________________________________________________________
//____________________________________________________________________________

InactiveRec::InactiveRec(const InactiveRec& src) 
 : Event(src)
{
  recrate = src.recrate;

} /* InactiveRec copy constructor */

//____________________________________________________________________________

Event* InactiveRec::Clone() const
{
  InactiveRec* event = new InactiveRec(*this);
  return event;

} /* InactiveRec::Clone */

//____________________________________________________________________________

void InactiveRec::InstallParameters(const ForceSummary& forces,
  const ForceParameters& starts)
{
  assert(starts.GetRecRates().size() == 1); // only one rec rate!
  recrate = starts.GetRecRates()[0];
  maxEvents = forces.GetMaxEvents(REC);

} /* InstallParameters */

//____________________________________________________________________________

double InactiveRec::PickTime()
{
  RecTree* tr = dynamic_cast<RecTree*>(ar->tree);
  if (tr->OpenLinks() > 0) {
    return -log(ar->randomSource->Float()) / (recrate * tr->OpenLinks());
  } else {
    return FLAGDOUBLE;
  }

} /* InactiveRec::PickTime */

//____________________________________________________________________________

void InactiveRec::DoEvent(double eventT)
{
  dynamic_cast<RecTree*>(ar->tree)->RecombineInactive(eventT, maxEvents);
} /* DoEvent */
    
//____________________________________________________________________________
