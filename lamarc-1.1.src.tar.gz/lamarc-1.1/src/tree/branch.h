// $Id: branch.h,v 1.10 2002/06/25 03:17:54 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/*******************************************************************
 Class Branch represents a branch in the tree, and is polymorphic
 on the type of event at its top (a coalescence, migration, etc.)
 It contains auxiliary objects--a Range and a DLCell--to manage
 likelihood and site information.

 A Branch's parents and children are represented by vectors of Branch*.
 There may be 0, 1 or 2 parents and 0, 1 or 2 children; other
 values are illegal.

 As Branches are polymorphic, they are only put in containers as
 pointers.  To copy a Branch use the Clone() function, which will
 create a new Branch of appropriate subtype.

 Written by Jim Sloan, heavily revised by Jon Yamato
 -- dlcell turned into a container Mary 2002/05/28
********************************************************************/

#ifndef BRANCH
#define BRANCH

#include <math.h>
#include <string>
#include <vector>
#include "vectorx.h"
#include "constants.h"
#include "range.h"
#include "dlcell.h"

class TreeSummary;

class Branch
{
protected:
bool updateDL;

virtual void CopyAllMembers(const Branch& src);
Branch& operator=(const Branch& src);

public:
long population;
double eventtime;
bool marked;

LongVec1d       ID;
vector<Branch*> parent;
vector<Branch*> child;

Range   range;

// We own what these point to
//Cell* dlcell;
vector<Cell_ptr> dlcell;

Branch();
Branch(const Branch& src);
virtual ~Branch();

virtual string  Event()                   const = 0;
virtual Branch* Clone()                         {return NULL;};

// arrangement helpers
virtual long    Cuttable()                const {return 0;};
virtual bool    CanRemove(Branch*)              {return true;};
virtual long    CountDown()               const {return 0;};
virtual bool    UpdateRange(long)               {return false;};
// the following routine is a no-op except in a branch where updateDL is
// allowed to be true, in which case it will be overridden.
virtual void    SetUpdateDL()                   {};  
        void    ClearUpdateDL()                 {updateDL = false; };
        bool    GetUpdateDL()             const {return updateDL; };
        void    MarkParentsForDLCalc();
virtual void    ReplaceChild(Branch* oldchild, Branch* newchild);
virtual bool    HasSameActive(const Branch& br);

// subtree maker helper
virtual long    GetRecSite()              const {return FLAGLONG;};

// likelihood calculation helpers
virtual double  HowFarTo(Branch& br);
virtual bool    CanCalcDL(long)           const {return false;};
virtual bool    ShouldCalcDL(long)        const {return false;};
virtual Branch* GetActiveChild(long)      const {return child[0];};
Branch* GetValidChild(Branch* br, long whichpos);

// haplotyping helpers
virtual bool    DiffersInDLFrom(Branch* branch, long marker) const;

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks) const = 0;
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const = 0;

// invariant checking
virtual bool    CheckInvariant()          const;
virtual bool    operator==(const Branch& src) const;
        bool    operator!=(const Branch& src) const {return !(*this == src); };

// debugging
virtual string  DLCheck(const Branch& other)    const;

};

//_________________________________________________________________
//_________________________________________________________________

class BBranch : public Branch
{
public:
BBranch() : Branch()                           {};
BBranch& operator=(const BBranch& src)         {Branch::operator=(src);
                                                return *this;};
BBranch(const BBranch& src)                    {*this = src;};
virtual Branch* Clone();
virtual string  Event()                  const {return BASE;};

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const;

virtual bool    CheckInvariant()          const;
};

//_________________________________________________________________
//_________________________________________________________________

class TBranch : public Branch
{
public:
string  label;

TBranch() : Branch()                            {};
TBranch& operator=(const TBranch& src);
TBranch(const TBranch& src)                     {*this = src;}; 
virtual Branch* Clone();
virtual string Event()                      const {return TIP;};

virtual long Cuttable()                   const {return 1;};
virtual Branch* GetActiveChild(long)      const {return NULL;};

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const;

virtual bool    CheckInvariant()          const;
virtual bool    operator==(const Branch& src) const;
};

//_________________________________________________________________
//_________________________________________________________________

class CBranch : public Branch
{
public:
CBranch() : Branch()                              {};
CBranch& operator=(const CBranch& src);
CBranch(const CBranch& src)                       {*this = src;};
virtual Branch* Clone();
virtual string  Event()                     const {return COAL;};

virtual long    Cuttable()                  const {return 1;};
virtual bool    CanRemove(Branch* checkchild);
virtual long    CountDown()                 const {return -2;};
virtual bool    UpdateRange(long nsites);
virtual void    SetUpdateDL()                     {updateDL = true;};
virtual void    ReplaceChild(Branch* oldchild, Branch* newchild);
virtual Branch* OtherChild(Branch* badchild);


virtual bool CanCalcDL(long site)           const {return
                                    child[0]->range.IsSiteActive(site) && 
                                    child[1]->range.IsSiteActive(site);};
virtual bool ShouldCalcDL(long site)        const {return updateDL &&
                                                   CanCalcDL(site);};
virtual Branch* GetActiveChild(long site) const;

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const;

virtual bool    CheckInvariant()          const;
};

//_________________________________________________________________
//_________________________________________________________________

class MBranch : public Branch
{
public:
MBranch() : Branch()                         {};
MBranch& operator=(const MBranch& src)       {Branch::operator=(src);
                                              return *this;};
MBranch(const MBranch& src)                  {*this = src;};
virtual Branch* Clone();
virtual string  Event()                const {return MIG;};

virtual long    Cuttable()             const {return 0;};
virtual bool    UpdateRange(long nsites);

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const;

virtual bool    CheckInvariant()          const;
};

//_________________________________________________________________
//_________________________________________________________________

class RBranch : public Branch
{
public:
RBranch() : Branch()                         {};
RBranch& operator=(const RBranch& src)       {Branch::operator=(src);
                                              return *this;};
RBranch(const RBranch& src)                  {*this = src;};
virtual Branch* Clone();
virtual string  Event()                const {return REC;};

virtual long    Cuttable()             const {return 1;};
virtual long    CountDown()            const {return 1;};
virtual bool    UpdateRange(long nsites);
virtual void    ReplaceChild(Branch* oldchild, Branch* newchild);

virtual long    GetRecSite()           const {return range.GetRecsite();};

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, LongVec1d& ks, long& s) const;

virtual bool    CheckInvariant()          const;
};


#endif
