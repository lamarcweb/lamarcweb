// $Id: chain.h,v 1.6 2002/06/26 19:11:55 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/*******************************************************************
  Chain is a helper class of the ChainManager whose main
  responsiblities are to choose the right arranger to use, call that
  arranger, then manage tree sampling using Arranger::Accept() and
  ChainSummary::SummarizeTree() as appropriate.  It also manages the
  runtime progress bar using RunReport expertise.  Finally it tracks
  some summary statistics on a chain such as the number of
  rearrangements accepted.
  
  Each Chain owns a Tree representing the chain's previous state,
  (Chain::oldtree); and a stable of arrangers used in the rearrangement
  process (Chain::arrangers).
  
  The member Tree objects are kept as pointers to allow for fast
  swapping in heated chains. [needs to be reconciled with text below]
  
  To use a Chain, you must call StartRegion() and StartReplicate()
  (in that order) and SetChainType() (at any point before Start())
  to initialize the Chain.  Then the functions Start(), Do(), and
  End() run the actual single chain.
  
  Statistics on the run are passed back in the form of a ChainOut by
  End().

  Written by Jon Yamato
  
  Changes:
  Mary:  changed from swapping Trees (expensive, and I can't
  swap the pointers without rewriting a lot of code) to swapping
  temperatures and associated variables.  This fixes a bug in
  heating, and will also make parallelization easier.

********************************************************************/

#ifndef CHAIN
#define CHAIN

#include <vector>
#include "chainout.h"

// #include "random.h"--needed for Float() in Do().
// #include "arranger.h"--needed for Clone()/construction in constructor,
//                        and for DeNovoTree() in StartReplicate(),
//                        and for Rearrange() and Accept() in Do(). 
// #include "treesum.h"--needed for SummarizeTree() and AddCopy() in Do(),
//                       and for Clear() in Start().
// #include "chainparam.h"--needed for ChainParameters access,
//                          everywhere.
// #include "runreport.h"--needed for PrintBar() in Do() and End().
// #include <algorithm>--to use std::swap in SwapTrees().

class Tree;
class Arranger;
class ChainParameters;
class RunReport;
class Random;
class ChainSummary;
class ForceSummary;

class Chain
{
private:

// This set of variables is part of a Chain's "temperature 
// identity" and will be swapped if the Chain's temperature is
// swapped.

long nsample, naccepted;            // how many samples/accepted samples?
long badtrees;                      // number of trees exceeding MAXEVENTS
bool shouldsample;                  // is this the coldest chain?
double temperature;                 // MCMCMC "temperature" for heating
ChainOut chainout;                  // results
long samplestep;                    // where are we in sampling process?

// This set of variables is not part of "temperature identity"
// and remains the same when temperatures are swapped.

long samplenow;
long nsamples, ndiscard, chaintype, sampleinterval;
long realstep;                       // what step of the chain are we on?
bool barprinter;
bool newtree;                        // is tree different from previous?
 long swapcount;                     // counts how often the chain has swapped, is reset in adjusttemp..
ChainSummary* treesums;              // not owning
Tree* tree;                          // not owning
Tree* oldtree;                       // we own this
vector<Arranger*> arrangers;         // we own these 
Random& randomsource;
RunReport& runreport;


Chain();                              // undefined

void CopyMembers(const Chain& src);
Arranger* ChooseArranger(double rnd);
void SwapTemperatures(Chain& other);


public:
Chain(Random& rnd, RunReport& runrep, const ChainParameters& chainparm, 
    double temper);
Chain(const Chain& src);
~Chain();
Chain& operator=(const Chain& src);

void SetSampling(bool sample)      {shouldsample = sample;};
void SetBarprinting(bool printer)  {barprinter = printer;};
void SetChainType(long chtype, const ChainParameters& chparm);

void SetTemperature(double n)    { temperature = n; };
 void SetSwapcount(long n) { swapcount = n; };


double GetCurrentDataLlike();
double GetTemperature()      const { return temperature; };
long  GetSwapcount()      const { return swapcount; };

void StartRegion(Tree* regiontree);
void EndRegion();

// must call StartRegion() before calling
void StartReplicate(ChainSummary* trsums, const ForceSummary& forcesum); 
void EndReplicate()                {};

// must call SetChainType() before calling
void Start(long chnumber, long chtype, const ForceSummary& forces, 
  const ForceParameters& starts); 
void Do(long nsteps);
ChainOut End();

// for heating
bool SwapTrees(Chain& hot);
bool IsCold() const { return shouldsample; };

};

#endif

