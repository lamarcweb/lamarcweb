//$Id: parameter.h,v 1.5 2002/06/26 19:11:56 lamarc Exp $

#ifndef PARAMETER
#define PARAMETER

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcdebug.h"
#include <assert.h>
#include <vector>
#include <string>
#include <map>
#include "plotstat.h"
#include "constants.h"
#include "types.h"

/*************************************************************************
   The Parameter class and its helper ResultStruct are used to store
   information about individual parameters of the force model.  For
   example, a single Parameter object might represent the migration
   rate from population 2 to population 1.

   Parameters contain information needed to describe a parameter in
   input/output, and also store information about results for that
   parameter, such as its MLE, profiles, and plots.  Every plot has
   an X-axis and a Y-axis parameter (for example, a plot might show
   Theta1 versus RecRate); the plot is stored in its X-axis Parameter
   (Theta1 in this case).

   Because everything about a parameter except its results is fixed
   after the user-input phase, normally const Parameters are used in later
   phases.  To allow us to put the results in as they become available, the
   ResultStruct is "mutable" even in a const Parameter object.
   This is why it's a separate object.

   A Parameter has an IsValid() method establishing its validity.  No
   other field in an invalid Parameter should be used!  Invalid
   Parameters are used as placeholders, for example representing the
   non-existent "migration rate from 1 to 1".

   DEBUG: Plotting is not yet supported.

**

  The ParamVector class is a structure that holds a "checked out" set
  of all Parameters.  This is done so that parts of the program which
  need rapid, read-write access to all Parameters can get it.  One
  creates a ParamVector to "check out" the Parameters and destroys it
  (or lets it go out of scope) to automatically "check in" your changes.
  It is a an error, and will throw a runtime exception, to check out
  a second ParamVector while the first is still out.

  If you want only read access to a ParamVector, use the two-argument
  constructor with an argument of "true" (meaning read-only).  This
  ParamVector will not attempt a checkin.  It is fine to have as many
  read-only ParamVectors as you like.  However, bear in mind that if
  you check out a writable one and write to it, the read-only ones will
  present a stale view (they are never updated).

  NB:  There may be invalid Parameters in a ParamVector (such as
  the nonexistent migration rates along the diagonal).  It is a fatal
  mistake to try to extract results, names, etc. from such a Parameter.

Written by Mary Kuhner October 1 2001
****************************************************************************/

class ForceSummary;

//____________________________________________________________________________________

struct ResultStruct 
{
  typedef std::map<long, PlotStruct> Plotmap;

private:
  DoubleVec1d mles;                // dim: regions
  DoubleVec1d overallmle;          // vector of one element
  vector<ProfileStruct> profiles;        // dim: regions
  vector<ProfileStruct> overallprofile;  // vector of one element

  // dimension of the following is approximately over the number
  // of parameters, except that only cases where this Parameter is
  // the x-axis are included (i.e. it's a half-diagonal matrix)
  Plotmap plots;             

public:

  // Creation and Destruction
  // ResultStruct();                         // we accept the default
  // ResultStruct(const ResultStruct& src);  // we accept the default
  // ~ResultStruct();                                    // we accept the default
  // ResultStruct& operator=(const ResultStruct& src);   // we accept the default

  // Getters (mostly not inline due to error checking code)
  double GetMLE(long region) const;
  DoubleVec1d GetRegionMLEs() const { return mles; };
  double GetOverallMLE() const;
  DoubleVec1d GetAllMLEs() const;

  const ProfileStruct& GetProfile(long region) const;
  const vector<ProfileStruct>& GetRegionProfiles() const { return profiles; };
  const ProfileStruct& GetOverallProfile() const;
  vector<ProfileStruct> GetAllProfiles() const;

  const PlotStruct& GetPlot(long param) const;

  // Setters
  void AddMLE(double mle)                          
           { mles.push_back(mle); };
  void AddOverallMLE(double mle)      
           { overallmle.push_back(mle); };

  void AddProfile(const ProfileStruct& profile)    
           { profiles.push_back(profile); };
  void AddOverallProfile(const ProfileStruct& profile) 
           { overallprofile.push_back(profile); };

  void AddPlot(long param, const PlotStruct& plot);
  
}; /* ResultStruct definition */

//____________________________________________________________________________________

class Parameter 
{
private:
  paramstatus validity;          // if this is "invalid" nothing else matters
  string shortname;
  string name;
  mutable ResultStruct results;  // change to pointer if "mutable" isn't portable
  string method;                 // method used to calculate this parameter
  proftype profiletype;

  // plotting variables
  double plotstart;
  double plotend;
  long plotpoints;
  plottype style;
  
  Parameter();                                // not defined
  // Parameter(const Parameter& src);            // we accept the default
  // Parameter& operator=(const Parameter& src); // we accept the default

public:

  // Creation and destruction
  Parameter(paramstatus isvalid, const string sname = "", const string lname = "", 
            proftype prof = none);
  ~Parameter() {};

  // Getters
  paramstatus GetValidity() const { return validity; };
  bool IsValid()            const { return (validity != invalid); };
  string GetShortName()     const { assert (IsValid()); return shortname; };
  string GetName()          const { assert (IsValid()); return name; };
  proftype GetProfileType() const { return profiletype; };
  bool IsProfiled()         const { return (profiletype != none); };
  string GetMethod()        const { return method; };
  double GetPlotStart()     const { return plotstart; };
  double GetPlotEnd()       const { return plotend; };
  long GetPlotPoints()      const { return plotpoints; };
  plottype GetPlotStyle()   const { return style; };

  // MLEs
  double GetMLE(long region) const 
                 { assert (IsValid()); return results.GetMLE(region); };
  DoubleVec1d GetRegionMLEs() const
                 { assert (IsValid()); return results.GetRegionMLEs(); };
  double GetOverallMLE() const  
                 { assert (IsValid()); return results.GetOverallMLE(); };
  DoubleVec1d GetAllMLEs() const  
                 { assert (IsValid()); return results.GetAllMLEs(); };

  // Profiles
  vector<centilepair> GetPriorLikes(long region) const;
  vector<centilepair> GetOverallPriorLikes() const;
  vector<vector<centilepair> > GetProfiles(long region) const;
  vector<vector<centilepair> > GetOverallProfile() const;
  vector<centilepair> GetCIs(long region) const;
  vector<centilepair> GetOverallCIs() const;
  
  // Setters
  // no setters for the names and validity--they are always set in the constructor
  void SetProfileType(proftype prof)  { profiletype = prof; };
  void SetMethod(string meth)         { method = meth; };

  // the following are "const" even though they change the object,
  // because they don't change its essential state
  // MLEs
  void AddMLE(double mle)  const       { assert (IsValid()); results.AddMLE(mle); };
  void AddOverallMLE(double mle) const { assert (IsValid()); results.AddOverallMLE(mle); };

  // Profiles
  void AddProfile(const ProfileStruct& prof, likelihoodtype like) const;

}; 


class ParamVector 
{
private:

  // This class is a lock.  NO COPYING ALLOWED.  Don't define these.
  ParamVector(const ParamVector&);              // not defined
  ParamVector& operator=(const ParamVector&);   // not defined

  static bool locked;
  bool readonly;
  ForceSummary& forcesum;      // to allow check-in in destructor

  // not very private, as we hand out references....
  vector<Parameter> parameters;

public:

  // The constructor checks out the Parameters and the destructor checks them
  // back in.
                 ParamVector(const ForceSummary& fs);
                 ParamVector(const ForceSummary& fs, bool rd);
                 ~ParamVector();

  // vector emulation routines
  typedef vector<Parameter>::iterator iterator;
  typedef vector<Parameter>::const_iterator const_iterator;
  Parameter&     operator[](long index);
  const Parameter&     operator[](long index) const;
  unsigned long  size()  const { return parameters.size(); };
  bool           empty() const { return parameters.empty(); };
  iterator       begin()       { return parameters.begin(); };
  const_iterator begin() const { return parameters.begin(); };
  iterator       end()         { return parameters.end(); };
  const_iterator end()   const { return parameters.end(); };

  paramlistcondition CheckCalcProfiles() const;
  paramlistcondition CheckCalcPProfiles() const;
  proftype           GetAllProfileTypes() const;
  void           SetAllProfileTypes(proftype prof);
  long           NumValidParameters() const;
};

#endif



