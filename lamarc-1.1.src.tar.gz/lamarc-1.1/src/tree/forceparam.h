//$Id: forceparam.h,v 1.3 2002/06/25 03:17:56 mkkuhner Exp $

#ifndef FORCEPARAMETERS
#define FORCEPARAMETERS

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************** 
 ForceParameters is a collection class used for internal communication
 throughout Lamarc.

 ForceParameters is a package of information about the values of
 all force parameters (for all forces--it is not polymorphic).
 Any routine which wishes to pass or return a bundle of force
 parameters should use this class.  It is normally passed by
 value. 

 Internally, the parameters are kept in separate vectors.  The
 object can present them as one big vector, but it needs access to
 a ForceSummary object to determine their order in that vector.

 Written by Jim Sloan, revised by Mary Kuhner

 Jon Yamato:
    added SetToMeanOf(vector<forceparameters>)
********************************************************************/

#include <vector>
#include "vectorx.h"
#include <stdlib.h>
#include "constants.h"

// #include "forcesummary.h"
// #include "force.h"

class ForceSummary;

class ForceParameters
{
  private:

    // the parameter vectors.  recrates is a vector of one element, for
    // consistency of interface.
    vector<double> thetas;
    vector<double> migrates;
    vector<double> recrates;
    vector<double> growths;

    void CopyAllMembers(const ForceParameters& src);

  public:
                     ForceParameters()        {};
                     ForceParameters(const ForceParameters& src);
    ForceParameters& operator=(const ForceParameters& src);

    // Setters
    void  SetThetas(const vector<double>& v);
    void  SetMigRates(const vector<double>& v);
    void  SetRecRates(const vector<double>& v);
    void  SetGrowthRates(const vector<double>& v);
    void  SetParameters(vector<double> v, const ForceSummary& fsumm);
    void  SetParametersByTag(const string& tag, const vector<double>& v);
    void  SetToMeanOf(const vector<ForceParameters>& params,
             const ForceSummary& fsumm);

    // Get rid of an unwanted set of parameters completely
    void  ClearThetas()          { thetas.clear(); };
    void  ClearMigRates()        { migrates.clear(); };
    void  ClearRecRates()        { recrates.clear(); }; 
    void  ClearGrowthRates()     { growths.clear(); };
    void  ClearParameters();

    // Getters
    vector<double>  GetThetas()        const  { return thetas; };
    vector<double>  GetMigRates()      const  { return migrates; };
    vector<double>  GetRecRates()      const  { return recrates; };
    vector<double>  GetGrowthRates()   const  { return growths; };
    vector<double>  GetParameters(const ForceSummary& fsumm)    const;
    vector<double>  GetParametersByTag(const string& tag)       const; 

    DoubleVec2d Get2DMigRates() const;
};

#endif
