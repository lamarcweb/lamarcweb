//$Id: tree.h,v 1.12 2002/06/25 03:17:58 mkkuhner Exp $

#ifndef TREE
#define TREE

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/*******************************************************************
 Class Tree represents a genealogy (not necessarily a "tree" in the
 recombinant cases).  It has two subtypes, a PlainTree (no 
 recombination) and a RecTree (with recombination) because the
 recombination machinery is too expensive to carry if you don't need
 it.

 Normally all Trees used during rearrangement come from either
 copying an existing tree or copying the prototype tree in Registry.

 DEBUG:  This class is a monster.  Anything to make it simpler
 would be good.

 Written by Jim Sloan, heavily revised by Mary Kuhner
*******************************************************************/

#include <math.h>
#include "random.h"
#include "branchlist.h"
#include "individual.h"
#include <vector>
#include "vectorx.h"
#include "treesum.h" // for use in Tree::SummarizeTree();
#include "constants.h"
#include <memory>
#include "errhandling.h"
#include "definitions.h"
#include "smart_ptr.h"
#include "dlcalc.h"  // for inline shared_ptr routine
#include "registry.h"
#include "types.h"

// in tree.cpp
// #include "dlcalc.h"  to Clone() the DLCalculator
// #include "dlcell.h" for the Swap functions
// #include "range.h" for range manipulations

class Region;
class Cell;

typedef boost::shared_ptr<DLCalculator> DLCalc_ptr;

class Tree
{
private:
         Tree();                         // undefined
         Tree(const Tree&);              // undefined
  Tree&  operator=(const Tree&);         // undefined

protected:
  Random       *randomSource;            // non-owning pointer
  long          nPopulations;
  long          nsites;
  double        dlValue;
  long          ID[IDSIZE];              // for assigning Branch IDs

  TimeList      timelist;                // all lineages
  BranchBuffer  activelist;              // currently active lineages
  BranchBuffer  intervallist;            // currently inactive lineages
  IndVec        individuals;             // associates tips from same individual

  Range         protoRange;              // prototypical range of active sites;
                                         // this will eventually be a vector over loci

  // The tree owns what these pointers point to
  // These will eventually be vectors over loci
  vector<Cell_ptr>    protoCell;      // created by factory
  DLCalc_ptr    dlCalculator;     // created by factory

  vector<Cell_ptr> CopyDLCell(const vector<Cell_ptr> src); // deep copy the DLCell vector

  // Protected rearrangement primitives
  virtual void    Break(Branch* pBranch);

public:

  // Creation and destruction
                    Tree(Random* rs, long npops);
                    Tree(const Tree& tree, bool makestump);
  virtual           ~Tree();
  virtual Tree     *Clone()                 const = 0;
  virtual Tree     *MakeStump()             const = 0;
  virtual void      Clear();
  virtual void      CopyTips(const Tree* tree);
  virtual void      CopyBody(const Tree* tree);
//  virtual void      CopyPartialBody(const Tree* tree);  -- in v2 as a speed optimization
          TBranch  *CreateTip();
          void      AssignID(Branch* pBranch);

  // Getters
          long      GetNsites()             const { return nsites; };
          long      GetNPopulations()       const { return nPopulations; };
          double    GetDLValue()            const { return dlValue; };
          TimeList& GetTimeList()                 { return timelist; };
    const TimeList& GetTimeList()           const { return timelist; };
          Individual& GetIndividual(long ind)       { return individuals[ind]; };
    const Individual& GetIndividual(long ind) const { return individuals[ind]; };
  virtual rangevector GetSubtrees() const;
          vector<Branch*> GetTips(StringVec1d& names)  const;
          bool      NoPhaseUnknownSites()              const;
          
  // Setters
          void      SetProtoRange(const Range& src)    { protoRange = src; };
          void      SetProtoCell(vector<Cell_ptr> src)        { protoCell = src; };
          void      SetDLCalculator(DLCalculator* src) { dlCalculator.reset(src); };
          void      SetNsites(long nsite)              { nsites = nsite; };
          void      SetDLValue(double v)               { dlValue = v; };
          void      SetIndividualsWithTips(const vector<Individual>& indvec);

  // Likelihood manipulation
          void      CalculateDataLikes();

  // Active and contemporary list management
          long      ActiveSize()            const { return activelist.Size(); };
          LongVec1d ActiveBranches()        const 
                    { return activelist.GetBranchPops(); };
          LongVec1d ContemporaryBranches()  const      
                    { return intervallist.GetBranchPops(); };

  // Rearrangement primitives
  virtual void      ActivateTips();
  virtual Branch   *ActivateBranch();
  virtual Branch   *ActivateRoot();
  virtual void      AttachBase();
  virtual double    FirstInterval(double eventT);
  virtual double    NextInterval();
  virtual void      Prune();
          void      SwapSiteDLs();
          void      MarkForDLRecalc(Branch* br);

  // Force-specific rearrangement primitives
  virtual Branch   *CoalesceActive(double eventT, long pop, long maxEvents);
  virtual Branch   *CoalesceInactive(double eventT, long pop, long maxEvents);
  virtual Branch   *Migrate(double eventT, long frompop, long topop, 
                      long maxEvents);

  // TreeSummaryFactory;
  TreeSummary* SummarizeTree() const;

  // Invariant checking
          bool      IsLegal()          const;   // check invariants
          bool      operator==(const Tree& src) const;  // compare trees
          bool      operator!=(const Tree& src) const {return !(*this == src); };

  // Debugging code
  // MakeCoalescent strips all migration nodes from the tree and
  // forces all remaining coalescences to their expectation times.
  // DO NOT use with migration!
    void MakeCoalescent(double theta) {timelist.MakeCoalescent(theta);};

  // DLCheck returns an error message with the first marker each
  // branch pair differs at, unmentioned branches don't differ.
    void DLCheck(const Tree& other) const 
       { cout << timelist.DLCheck(other.GetTimeList()) << endl; };

};

//________________________________________________________________________________
//________________________________________________________________________________

class PlainTree : public Tree
{
  public:

    // Creation and destruction
                      PlainTree(Random* rs, long npops) :
                        Tree(rs, npops)  {};
                      PlainTree(const Tree& tree, bool makestump) :
                        Tree(tree,makestump)       {};
    virtual          ~PlainTree()        {};
    virtual Tree     *Clone()                 const;
    virtual Tree     *MakeStump()             const;

    // Yes, everything else is the same as Tree.

};

//________________________________________________________________________________
//________________________________________________________________________________

class RecTree : public Tree
{
private:

    long      activeLinks;
    long      openLinks;

    void      UpdateRange(Branch* pBranch);
    void      RecurseBreak(Branch* pBranch);

protected:

    virtual  void     Break(Branch* branch);

public:
    // Creation and destruction
                      RecTree(Random* rs, long npops);
                      RecTree(const RecTree& tree, bool makestump);
                      ~RecTree()                        {};

    virtual  Tree    *Clone()     const;
    virtual  Tree    *MakeStump() const;
    virtual  void     Clear();
    virtual  void     CopyTips(const Tree* tree);
    virtual  void     CopyBody(const Tree* tree);
//    virtual  void     CopyPartialBody(const Tree* tree);  -- in v2 as a speed optimization

    // Getters
    virtual  rangevector GetSubtrees() const;
             long     ActiveLinks() const           { return activeLinks; };
             long     OpenLinks() const             { return openLinks; };

    // Rearrangement primitives
    virtual  void     ActivateTips();
    virtual  Branch  *ActivateBranch();
    virtual  Branch  *ActivateRoot();
    virtual  void     AttachBase();
    virtual  double   FirstInterval(double eventT);
    virtual  double   NextInterval();
    virtual  void     Prune();

    // Force-specific rearrangement primitives
    virtual  Branch  *CoalesceActive(double eventT, long pop, long maxEvents);
    virtual  Branch  *CoalesceInactive(double eventT, long pop, long maxEvents);
    virtual  Branch  *Migrate(double eventT, long frompop, 
                        long topop, long maxEvents);
             Branch  *RecombineActive(double eventT, long maxEvents);
             Branch  *RecombineInactive(double eventT, long maxEvents);

};

#endif
