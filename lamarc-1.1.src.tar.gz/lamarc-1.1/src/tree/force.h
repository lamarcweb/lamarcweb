// $Id: force.h,v 1.7 2002/06/25 03:17:55 mkkuhner Exp $

#ifndef FORCES
#define FORCES

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "stringx.h"
#include <vector>
#include "vectorx.h"
#include <deque>
#include "constants.h"
#include "types.h"
#include "forceparam.h"    // for GetFooRates() and SetFooRates() in
                           //    Foo::RetrieveParameters() and 
                           //    Foo::PutParameters()
#include "parameter.h"     // for Parameter member object
#include "plotstat.h"
#include "plforces.h"      // for PLForces classes
class Event;
class Registry;
class ChainPack;
class ChainOut;
class DataPack;
class ForceSummary;
class Region;
class UserParameters;
class Parameter;
class Summary;
class IntervalData;

// in .cpp
// #include "forcesummary.h"   for forcesummary getter functions
// #include "event.h"          to set up Event vectors in arrangers

/******************************************************************
 The Force class defines a polymorphic object which embodies 
 information about one of the evolutionary forces active in the
 program.  It has four main functions:

 (1)  To indicate, by its presence in the ForceSummary, that the
 force is active.

 (2)  To manage the parameters associated with its force (for
 example, the theta values associated with Coalescence).  It maintains
 a vector of Parameter objects for this purpose. 

 (3)  To provide information to the rest of the program about
 its force (quickestimate, name, dimensionality, table headers, etc.)

 (4)  To act as a factory for the Event objects (representing concepts
 such as "a coalescence of two active lineages") used by the Arrangers,
 and for the Summary objects (representing presence of a force) used
 by the TreeSummary.

 A fifth main function, handling force-specific math, may be
 added when we integrate the posterior-likelihood module.

 The only place Force objects normally exist is inside of the
 (singular) ForceSummary object, which owns them.

 To create a new Force (for example, when the user turns one on
 in the menu) call the free function CreateForce() with the appropriate
 tag and a reference to the DataPack.  The code receiving the
 Force assumes ownership.

 Written by Mary Kuhner and Jon Yamato
 * 04/04/02 Peter Beerli added PLforces objects
******************************************************************/

class Force
{
private:

protected:

  string      tag;           // identifying tag of force
  string      name;          // concise name of the force
  string      fullname;      // full name of the force
  string      parmname;      // concise name of the parameter type
  string      fullparmname;  // full name of the parameter type

  vector<Parameter> parameters;  // all parameters related to this force

  StringVec1d axisname;      // name of each table axis
  StringVec1d sectitle;      // name of table section; may go into Parameter eventually

  long maximum;              // maximum "events" of this force allowed per tree
  double defvalue;           // default value of parameters for this force

  // these need to be defined because of the owning pointer:
             Force(const Force& src);  
  Force&     operator=(const Force& src); 

  // The following can only be set after data reading, when npop is known
  LongVec1d  paramsPerDimension; // parameters per dimension

  // postlike forces related objects that contain functions that are called by 
  // point() and wait() in the post-likelihood calculation
  PLForces * plforceptr;    // holds force object; OWNING POINTER
  long       plforcepnum;   // holds numbers of parameters used in force

  // Utility function used by InsertParameters
  DoubleVec1d PopParameters(DoubleVec1d& parameters);


public:

  virtual Force* Clone() const = 0;     // virtual copy constructor
          Force() : plforceptr(NULL) {};
  virtual ~Force() { delete plforceptr; };

  // Report writing functions
  virtual StringVec1d    MakeStartParamReport() = 0;
  virtual StringVec1d    MakeChainParamReport(const ChainOut& chout)  = 0;

  // Getters
          string         GetTag()           const {return tag;};
          string         GetFullparmname()  const {return fullparmname;};
          string         GetShortparmname() const {return parmname;};
          long           GetDimensions()    const {return paramsPerDimension.size();};
          vector<long>   GetParamsPerDimension() const { return paramsPerDimension; };
          StringVec1d    GetAxisname()      const {return axisname;};
          StringVec1d    GetSectitle()      const {return sectitle;};
          DoubleVec2d    GetMles()          const;
          DoubleVec1d    GetPopmles()       const;

          long           GetMaximum()       const {return maximum;};
          double         GetDefaultValue()  const { return defvalue; };
          StringVec1d    GetMethods()       const;
          long           GetNParams()       const {return parameters.size(); };
// GetNParameters() returns the number of valid (real) parameters
          long           GetNParameters()   const;
 
          vector<Parameter>& GetParameters()  { return parameters; };
          const vector<Parameter>& GetParameters() const {return parameters; };

	  //PLforces related
	  // returns the number of parameters in force, used to calculate 
	  // offset in forces vector in Postlike
	  long GetPLForcepnum() { return plforcepnum; };
	  // returns pointer to PLForces object [that holds the force specific
	  // wait() and point() functions
	  PLForces * GetPLForceFunction() { return plforceptr; };

	  // SummarizeProfTypes--used by ReportPage::SetupColhdr()
	  // AnyNoneProfTypes--used by MlePage::Show()
          proftype       SummarizeProfTypes() const;
          bool           AnyNoneProfTypes() const;

  // Setters
  // No setters for intrinsic class qualities like name, as these
  // are built into the subclasses.
          void        SetMaximum(long m)                  { maximum = m; };
          void        SetMethods(const StringVec1d& meths);
          void        SetProfileTypes(const vector<proftype>& profs);
          void        SetParameters(const vector<Parameter>& src) 
                                              { parameters = src; };


  // used by ForceSummary::SummarizeData()
          deque<bool> UseCalculatedValues() const;
  virtual double      Truncate(double target) const = 0;

  // generally interface into a ForceParameters object
  virtual DoubleVec1d RetrieveParameters(const ForceParameters& fp) const = 0;
  virtual void        PutParameters(const DoubleVec1d& params, 
                         ForceParameters& fp) const = 0;

  // The following functions are helpers for "all one big vector" version of
  // ForceParameters getting and setting.
  virtual void           InsertParameters(DoubleVec1d& v, ForceParameters& fp) = 0;

  // The following functions manage the Events associated with a particular
  // force.  Events are owned by the recipient (an Arranger).
  virtual vector<Event*> MakeEvents()                  const = 0;
  virtual void           ModifyEvents(vector<Event*>&) const {};

  // The following is a factory function to make Summary objects for the
  // TreeSummary
  virtual Summary* CreateSummary(IntervalData& interval, long numpops, bool 
    shortness) const = 0;

  // QuickCalc() runs the quickcalculator for the force (if any).
  // The DataPack& form calculates the overall estimate and returns it.
  // The Region& form just calculates the regional estimate.
  // Both forms change Region::regiontheta (either all of them for
  // the overall, or just the passed region).
  // Force::QuickCalc(Region&) will perform a no-op.
  virtual void QuickCalc(Region&) const {};
          DoubleVec1d QuickCalc(DataPack&) const;

  // Error checking functions used to validate input data

  virtual bool IsValidParameterValue(double paramval) const = 0;
  virtual bool IsValidMethod(const string& meth) const = 0;

}; /* Force */

//___________________________________________________________________________

class RecForce : public Force
{
private:
// OBSOLETE
//          double         CalcWakeley(Region& reg) const;
//          double         CalcFST(Region& reg) const;

protected:
                         RecForce(const RecForce& src);

public:
                         RecForce(const DataPack& dpack);
  virtual Force*         Clone() const  { return new RecForce(*this); };
  virtual                ~RecForce() {};

  virtual StringVec1d    MakeStartParamReport();
  virtual StringVec1d    MakeChainParamReport(const ChainOut& chout);
  virtual DoubleVec1d    RetrieveParameters(const ForceParameters& fp)
                           const { return fp.GetRecRates(); };
  virtual void           PutParameters(const DoubleVec1d& params,
                           ForceParameters& fp) const
                           { fp.SetRecRates(params); };
  virtual void           InsertParameters(DoubleVec1d& v, ForceParameters& fp);

  virtual vector<Event*> MakeEvents()       const;
  virtual Summary*       CreateSummary(IntervalData& interval, long numpops, bool
                            shortness) const;
  virtual void           QuickCalc(Region& reg) const;
  virtual double         DefaultValue() const { return DEFAULTRECOMBINATIONRATE; };
  virtual double         Truncate(double target) const { return std::min(MAX_RECRATE, target); };

  virtual bool IsValidParameterValue(double paramval) const;
  virtual bool IsValidMethod(const string& meth) const;

}; /* RecForce */

//___________________________________________________________________________

class MigForce : public Force
{
private:
          DoubleVec1d    CalcFst(const Region& reg) const;

protected:
                         MigForce(const MigForce& src);

public:
                         MigForce(const DataPack& dpack);
  virtual Force*        Clone() const { return new MigForce(*this); };
  virtual                ~MigForce() {};
  virtual void           ChangetoMigGrowPL(long nparam);
  virtual void           ChangetoMigPL(long nparam);
  virtual StringVec1d    MakeStartParamReport();
  virtual StringVec1d    MakeChainParamReport(const ChainOut& chout);
  virtual DoubleVec1d    RetrieveParameters(const ForceParameters& fp)
                           const { return fp.GetMigRates(); };
  virtual void           PutParameters(const DoubleVec1d& params,
                           ForceParameters& fp) const
                           { fp.SetMigRates(params); };
  virtual void           InsertParameters(DoubleVec1d& v, ForceParameters& fp);

  virtual vector<Event*> MakeEvents()       const;
  virtual Summary*       CreateSummary(IntervalData& interval, long numpops, bool
                            shortness) const;
  virtual void           QuickCalc(Region& reg) const;
  virtual double         DefaultValue() const { return DEFAULTMIGRATION; };
  virtual double         Truncate(double target) const { return std::min(MAX_MIGRATE, target); };

  virtual bool IsValidParameterValue(double paramval) const;
  virtual bool IsValidMethod(const string& meth) const;

}; /* MigForce */

//___________________________________________________________________________

class CoalForce : public Force
{
private:
          double         CalcFst(const Region& reg, long pop) const;
          double         CalcWatterson(const Region& reg, long pop) const;

protected:
                         CoalForce(const CoalForce& src);

public:
                         CoalForce(const DataPack& dpack);
  virtual Force*         Clone() const  { return new CoalForce(*this); };
  virtual                ~CoalForce() {};
  virtual void           ChangetoCoalGrowPL(long nparam);
  virtual void           ChangetoCoalPL(long nparam);

  virtual StringVec1d    MakeStartParamReport();
  virtual StringVec1d    MakeChainParamReport(const ChainOut& chpack);
  virtual DoubleVec1d    RetrieveParameters(const ForceParameters& fp)
                           const { return fp.GetThetas(); };
  virtual void           PutParameters(const DoubleVec1d& params,
                           ForceParameters& fp) const
                           { fp.SetThetas(params); };
  virtual void           InsertParameters(DoubleVec1d& v, ForceParameters& fp);

  virtual vector<Event*> MakeEvents()       const;
  virtual Summary*       CreateSummary(IntervalData& interval, long numpops, bool
                            shortness) const;

  virtual void           QuickCalc(Region& reg) const;
  virtual double         DefaultValue() const { return DEFAULTTHETA; };
  virtual double         Truncate(double target) const { return std::min(MAX_THETA, target); };

  virtual bool IsValidParameterValue(double paramval) const;
  virtual bool IsValidMethod(const string& meth) const;

}; /* CoalForce */

//___________________________________________________________________________

class GrowthForce : public Force
{
private:
// there exists no quickcalculator equivalent for growth

protected:
                     GrowthForce(const GrowthForce& src);

public:
                     GrowthForce(const DataPack& dpack);
virtual Force*       Clone() const {return new GrowthForce(*this); };
virtual              ~GrowthForce() {};

virtual StringVec1d  MakeStartParamReport();
virtual StringVec1d  MakeChainParamReport(const ChainOut& chpack);
virtual DoubleVec1d  RetrieveParameters(const ForceParameters& fp)
                           const { return fp.GetGrowthRates(); };
virtual void         PutParameters(const DoubleVec1d& params,
                           ForceParameters& fp) const
                           { fp.SetGrowthRates(params); };
virtual void         InsertParameters(DoubleVec1d& v, ForceParameters& fp);

virtual vector<Event*> MakeEvents()       const;
virtual void           ModifyEvents(vector<Event*>& events) const;


virtual Summary*       CreateSummary(IntervalData& interval, long numpops, bool
                            shortness) const;

virtual void           QuickCalc(Region& reg) const;
virtual double         DefaultValue() const { return DEFAULTGROWTH; };
virtual double         Truncate(double target) const 
                          { return std::min(MAX_GROWRATE, target); };

virtual bool         IsValidParameterValue(double paramval) const;
virtual bool         IsValidMethod(const string& meth) const;

}; /* GrowthForce */

//___________________________________________________________________________
//___________________________________________________________________________

// The following is a free function used to make, on demand, the
// appropriate subclass of Force--essentially a polymorphic
// constructor.  It returns objects created by new, and the
// requesting code takes on the responsibility to delete them.

// If you add a new force you must update this function.

Force* CreateForce(string tag, const DataPack& dpack);

// These free functions pretty-print a matrix of various dimensions

StringVec1d Tabulate(double params, long width);
StringVec1d Tabulate(const DoubleVec1d& params, long width);
StringVec1d Tabulate(const DoubleVec2d& params, long width);

// This free function shortens a quick-calculator method name
string      ShortenName(const string& str); 

#endif
