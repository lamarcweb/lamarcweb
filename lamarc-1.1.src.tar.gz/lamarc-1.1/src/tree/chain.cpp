// $Id: chain.cpp,v 1.15 2002/06/26 19:11:55 lamarc Exp $ 

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "chain.h"
#include "random.h"
#include "tree.h"
#include "arranger.h"
#include "treesum.h"
#include "chainsum.h"
#include "chainparam.h"
#include "runreport.h"
#include "vectorx.h"
#include "errhandling.h"
#include "forcesummary.h"
#include <algorithm>
#include "constants.h"
#include "types.h"
#include <map>
#include <iostream> 
#include <fstream> 

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//____________________________________________________

Chain::Chain (Random & rnd, RunReport & runrep,
	      const ChainParameters & chainparm, double temper)
 : temperature(temper),
   tree (NULL), 
   oldtree (NULL), 
   randomsource (rnd), 
   runreport (runrep)
{
  vector < Arranger * >arrs = chainparm.GetAllArrangers ();
  vector < Arranger * >::iterator arranger;
  for (arranger = arrs.begin (); arranger != arrs.end (); ++arranger)
    {
      Arranger *
	newarranger = (*arranger)->Clone ();
      arrangers.push_back (newarranger);
    }

  shouldsample = false;
  barprinter = false;
  swapcount = 0; // for Chainmanager::adjustTemperature()
}				/* Chain::Chain */

//____________________________________________________

Chain::Chain (const Chain & src):
randomsource (src.randomsource), runreport (src.runreport)
{
  oldtree = NULL;
  CopyMembers (src);

}				/* Chain::Chain */

//____________________________________________________

Chain::~Chain ()
{
  vector < Arranger * >::iterator arr;
  for (arr = arrangers.begin (); arr != arrangers.end (); ++arr)
    delete * arr;

  delete oldtree;

}				/* Chain::~Chain */

//____________________________________________________

Chain & Chain::operator = (const Chain & src)
{
  if (&src != this) {  // self assignment test
    vector < Arranger * >::iterator arr;
    for (arr = arrangers.begin (); arr != arrangers.end (); ++arr)
      delete * arr;
    arrangers.clear ();

    delete oldtree;
    oldtree = NULL;

    CopyMembers (src);
  }

  return *this;

}				/* Chain::operator= */

//____________________________________________________
// Does not set the reference members, Chain::randomsource and
// Chain::runreport.
void
Chain::CopyMembers (const Chain & src)
{
  samplestep = src.samplestep;
  samplenow = src.samplenow;
  nsample = src.nsample;
  naccepted = src.naccepted;
  newtree = src.newtree;

  nsamples = src.nsamples;
  ndiscard = src.ndiscard;
  chaintype = src.chaintype;
  sampleinterval = src.sampleinterval;
  badtrees = src.badtrees;
  shouldsample = src.shouldsample;
  barprinter = src.barprinter;

  tree = src.tree;
  chainout = src.chainout;
  treesums = src.treesums;

  assert (arrangers.empty () && oldtree == NULL);

  if (tree)
    oldtree = tree->Clone();

  vector < Arranger * >::const_iterator arr;
  for (arr = src.arrangers.begin (); arr != src.arrangers.end (); ++arr)
    arrangers.push_back ((*arr)->Clone ());

  temperature = src.temperature;
  swapcount = src.swapcount; 
}				/* Chain::CopyMembers */

//____________________________________________________

Arranger *
Chain::ChooseArranger (double rnd)
{
  if (arrangers.size () == 1)
    return arrangers[0];

  double
    total = 0.0;
  vector < Arranger * >::iterator arr;
  for (arr = arrangers.begin (); arr != arrangers.end (); ++arr)
    {
      total += (*arr)->GetTiming ();
      if (total >= rnd)
	return *arr;
    }

// due to rounding, it is possible for rnd to be greater than
// the total probability of all arrangers; in this case return
// first arranger with non-zero timing.

  for (arr = arrangers.begin (); arr != arrangers.end (); ++arr) {
     if ((*arr)->GetTiming() != 0) break;
  }
  return *arr;

}				/* Chain::ChooseArranger */

//____________________________________________________

void
Chain::SetChainType (long chtype, const ChainParameters & chparm)
{
  chaintype = chtype;
  nsamples = chparm.GetNSamples (chtype);
  ndiscard = chparm.GetNDiscard (chtype);
  sampleinterval = chparm.GetInterval (chtype);

}				/* Chain::ToChainType */

//____________________________________________________

double Chain::GetCurrentDataLlike() {
  return tree->GetDLValue();
} /* GetCurrentDataLike */

//____________________________________________________

void
Chain::StartRegion (Tree * regiontree)
{
  if (DENOVO)
     cout << endl << "Running denovo case--no rearrangement!" << endl;
  tree = regiontree;
  bool nohap = tree->NoPhaseUnknownSites();
  double xtratime = 0.0;
  vector < Arranger * >::iterator arr;
  for (arr = arrangers.begin (); arr != arrangers.end (); ++arr) {
    (*arr)->tree = regiontree;
    (*arr)->SetSaveTiming();
    if (nohap && (*arr)->IsHapArranger()) {
       xtratime = (*arr)->GetTiming() / (arrangers.size()-1);
       (*arr)->SetTiming(0.0);
    }
  }
  if (xtratime)
    for (arr = arrangers.begin (); arr != arrangers.end (); ++arr)
      if (!(*arr)->IsHapArranger())
        (*arr)->SetTiming((*arr)->GetTiming() + xtratime);
  delete oldtree;
  oldtree = tree->MakeStump ();
  oldtree->CopyTips (tree);

}				/* Chain::StartRegion */

//____________________________________________________

void Chain::EndRegion()
{
// in case we turned haplotyping off in a previous region, turn it
// back on.
vector < Arranger * >::iterator arr;
for (arr = arrangers.begin (); arr != arrangers.end (); ++arr)
   (*arr)->RestoreTiming();

} /* Chain::EndRegion */

//____________________________________________________
// StartRegion() must be called before StartReplicate()
void
Chain::StartReplicate (ChainSummary * trsums, const ForceSummary& forcesum)
{
  bool tree_is_bad = false;
  long bad_denovo = 0;

  arrangers[0]->SetParameters (forcesum, forcesum.GetStartParameters());
  do {
     tree_is_bad = false;
     try {
        arrangers[0]->DeNovoTree ();
     }
     catch (overrun_error& e) {
        tree_is_bad = true;
        ++bad_denovo;
        if (bad_denovo > TOO_MANY_DENOVO) {
          string errorMessage = "Unable to create denovo tree, perhaps ";
          errorMessage += "\n due to extreme starting parameter values";
          denovo_failure e(errorMessage);
          throw e;
        }
        // don't increment badtrees! ++badtrees;
        tree->CopyBody(oldtree); // perform cleanup
     }
  } while(tree_is_bad);

  tree->CalculateDataLikes ();
  oldtree->CopyBody (tree);
  treesums = trsums;

}				/* Chain::StartReplicate */

//____________________________________________________
// SetChainType() must be called before Start()
void
Chain::Start (long chainnumber, long chaintype, const ForceSummary& 
  forces, const ForceParameters& starts)
{
  if (barprinter) {
    long nsteps = nsamples * sampleinterval + ndiscard;
    runreport.SetBarParameters (nsteps, ndiscard, chainnumber, chaintype);
    runreport.PrintBar (0L);	// initialize printed bar
  }
  realstep = 0;
  nsample = 0;
  samplestep = 0;
  naccepted = 0;
  newtree = true;
  badtrees = 0;
  samplenow = ndiscard + sampleinterval;

  vector < Arranger * >::iterator arr;
  for (arr = arrangers.begin (); arr != arrangers.end (); ++arr)
    (*arr)->SetParameters (forces, starts);

  chainout.SetStarttime ();
  treesums->Clear();

  // the following two lines reset the per-arranger acceptance rates
  ratemap empty;
  chainout.SetAllAccrates(empty);

} /* Chain::Start */

//____________________________________________________

void Chain::Do (long nsteps)
{
long step;
bool tree_is_bad;

ratemap acceptances;
ratemap::iterator mapit;

// if this is the coldest chain, keep track of per-arranger
// acceptance rates
if (shouldsample) {
  acceptances = chainout.GetAllAccrates();
}

for (step = 0; step < nsteps; ++step) {

#ifdef MAC
   eventloop();   // allow OS9 to check for interrupts
#endif
   tree_is_bad = false;
   Arranger * arranger = ChooseArranger (randomsource.Float ());

   if (shouldsample) {
     ++samplestep;
     // record this arranger in the acceptance map
     string arrangername = arranger->GetName();
     mapit = acceptances.find(arrangername);
     if (mapit == acceptances.end()) {  // new arranger
       acceptances.insert(make_pair(arrangername, make_pair(0, 0)));
       mapit = acceptances.find(arrangername);
     } 
   }

   try {
#if !DENOVO
      arranger->Rearrange ();
#endif
#if DENOVO
      arranger->DeNovoTree ();
#endif
   }
   catch (overrun_error& e) {
      tree_is_bad = true;
      badtrees++;
   }

#if !DENOVO
#if !STATIONARIES
   if (!tree_is_bad) tree->CalculateDataLikes ();
#endif
#if STATIONARIES
   // we set the new tree's likelihood equal to the old
   tree->SetDLValue(oldtree->GetDLValue());
#endif

   if (arranger->Accept(oldtree, temperature, tree_is_bad)) {
      newtree = true;
      // we don't count acceptances until burnin is over
      if (realstep >= ndiscard) { 
        ++naccepted;
        if (shouldsample) mapit->second.first++;
      }
   }

   if (shouldsample && realstep >= ndiscard) mapit->second.second++;

#if LIKETRACK
ofstream of;
of.open("likes1",ios::app);
of << newtree << endl;
of.close();
#endif

#endif

#if DENOVO
// In the DENOVO case, we always accept unless the tree was bad.
// If the tree was bad, we "accept" another copy of its predecessor.
// WARNING:  The following code assumes that to accept a tree means
// copying its Body only.  It will be incorrect if used with a
// haplotyping Arranger which also needs to modify the tips.  We
// permit this potential bug because DENOVO is mainly a developer
// tool, but if a DENOVO-capable version is ever created,
// the bug should be fixed.  (I suggest having three forms of
// Arranger->Accept:  ConditionalAccept, AlwaysAccept, Reject.)

    newtree = true;
    ++naccepted;   

    if (!tree_is_bad) {
       oldtree->CopyBody(tree);
    } else {
       tree->CopyBody(oldtree);
    }
#endif

#if STATIONARIES
    newtree = true;
#endif

    if (samplestep == samplenow) {
       if (shouldsample) {
          if (newtree) {
             treesums->SummarizeTree(*tree);
             newtree = false;
          } else {
             treesums->AddCopy();
          }
       }
       samplestep = 0;
       samplenow = sampleinterval;
       ++nsample;
   }

   ++realstep;
   if (barprinter) {
      runreport.PrintBar(realstep);
   }
}

if (shouldsample) chainout.SetAllAccrates(acceptances);

} /* Chain::Do */

//____________________________________________________

ChainOut
Chain::End ()
{
  chainout.SetNumBadTrees (badtrees);
  chainout.SetLlikedata(tree->GetDLValue());
  double totaltrees = nsamples * sampleinterval;     // prevent integer truncation!
  chainout.SetAccrate (naccepted / totaltrees);
  chainout.SetEndtime ();

  return chainout;

}				/* Chain::End */

//____________________________________________________

/* Swap trees between two different-temperature Chains, if
   appropriate.  The equation is:

   hotlike ^ (1/coldtemp) * coldlike ^ (1/hottemp)
   -----------------------------------------------
   hotlike ^ (1/hottemp) * coldlike ^ (1/coldtemp)

   but we use log units for flow-protection reasons.
   This is a Chain function in order to use private parts of 
   Chain; it is actually symmetrical in its two Chain arguments.

   We actually swap the temperatures (and associated variables)
   between the Chains, not the Trees, as it's easier to
   parallelize this way.

   NB:  The equation above uses likelihoods; the code below
   uses log likelihoods.
*/

bool Chain::SwapTrees(Chain& hot) 
{
  Chain& cold = *this;

  double hottemp = hot.GetTemperature();
  double coldtemp = cold.GetTemperature();

  // these are log likelihoods
  double hotlike = hot.tree->GetDLValue();
  double coldlike = cold.tree->GetDLValue();

  double test = (hotlike/coldtemp) + (coldlike/hottemp) -
    ((hotlike/hottemp) + (coldlike/coldtemp));

  if (test >= 0.0) {   // always accept improvements
//    std::swap(hot.tree, cold.tree);
    cold.SwapTemperatures(hot);
    // swapping counts as a "new tree"
    hot.newtree = true;
    cold.newtree = true;
    cold.swapcount += 1; //used to adjust the temperatures
    return true;
  }

  // conditionally accept non-improvements
  double comparison = log(randomsource.Float());
  if (test < comparison) return false;
  else {
//    std::swap(hot.tree, cold.tree);
    cold.SwapTemperatures(hot);
    // swapping counts as a "new tree"
    hot.newtree = true;
    cold.newtree = true;
    cold.swapcount += 1 ; //used to adjust the temperatures
    return true;
  }
  
} /* SwapTrees */

//____________________________________________________

void Chain::SwapTemperatures(Chain& other)
{
  // We swap only the "temperature identity" variables.

  std::swap(nsample, other.nsample);
  std::swap(naccepted, other.naccepted);
  std::swap(badtrees, other.badtrees);
  std::swap(shouldsample, other.shouldsample);
  std::swap(temperature, other.temperature);
  std::swap(chainout, other.chainout);
  std::swap(samplestep, other.samplestep);
}
//____________________________________________________
