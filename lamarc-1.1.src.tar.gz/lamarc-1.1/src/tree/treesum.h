// $Id: treesum.h,v 1.8 2002/06/25 03:17:58 mkkuhner Exp $

#ifndef TREESUMMARY
#define TREESUMMARY

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <vector>
#include <map>
#include "vectorx.h"
#include "intervaldata.h"
#include <string> 

#include "stringx.h" // debug function include
#include <iostream>  // debug function include

// #include "tree.h" in .cpp for generalized access to trees in 
//     TreeSummary::Summarize(), RecTreeSummary::Summarize, and
//     ChainSummary::SummarizeTree();

class Tree;
class ForceSummary;
class Registry;
class Summary;

typedef map<string, Summary*> Summap;
typedef map<string, Summary*>::iterator Sumiter;
typedef map<string, Summary*>::const_iterator Sumconst_iter;

/*********************************************************************
Class TreeSummary.
Summarizes the information from a single tree (or run of identical 
trees) for the use of the maximizer.  There is a polymorphic form of 
TreeSummary for recombinant trees and there will need to be
a more drastically polymorphic form for trees with growth.

Written by Jim Sloan, revised by Mary Kuhner
   added debug printers Jon Yamato 2001/04/23
   added AdjustSummary Mary Kuhner 2001/07/05
   massively refactored Mary Kuhner 2002/04/18 (and hey, it's snowing today!)
   ChainSummary moved to own file Mary Kuhner 2002/04/19
**********************************************************************/

class TreeSummary
{
private:
  TreeSummary& operator=(const TreeSummary& src);     // undefined

protected:

  // speed optimization caches
  Summary* coalsummary;
  Summary* migsummary;
  Summary* recsummary;
  Summary* growsummary;

  IntervalData intervalData; // the actual stored stuff; we own this
  Summap       summaries;    // helper objects for interpreting intervalData
  long         nCopies;      // number of identical trees

  void Compress();           // reduce storage space, if possible
  void CacheSummaries();     // cache summary locations

public:

                       TreeSummary() {};  // used only to prototype
                       TreeSummary(const TreeSummary& src);
  virtual TreeSummary* Clone() const;
  virtual              ~TreeSummary();

  virtual void Summarize(const Tree& tree);
          void AddCopy() { ++nCopies; };
          long GetNCopies() const { return nCopies; }; 

  virtual StringVec1d PrintSummary() const;
          map<string, DoubleVec1d> InspectSummary() const;
  virtual void AdjustSummary(const map<string, DoubleVec1d>& counts);

  Summary*       GetSummary(const string& type);
  Summary const* GetSummary(const string& type) const;
  void           AddSummary(const string& type, Summary* sum);

  IntervalData& GetIntervalData() { return intervalData; };

  // speed optimized routines which duplicate GetSummary for
  // the given force, but much more quickly.

  Summary const* GetCoalSummary() const { return coalsummary; };
  Summary const* GetMigSummary() const { return migsummary; };
  Summary const* GetRecSummary() const { return recsummary; };
  Summary const* GetGrowSummary() const { return growsummary; };

};

//____________________________________________________________________

class RecTreeSummary : public TreeSummary
{
public:
                       RecTreeSummary() : TreeSummary() {};
                       RecTreeSummary(const TreeSummary& src) : TreeSummary(src) {};
  virtual TreeSummary* Clone() const;
  virtual              ~RecTreeSummary()  {};

  virtual void Summarize(const Tree& tree);

  virtual StringVec1d PrintSummary() const;

};

#endif









