//$Id: intervaldata.cpp,v 1.5 2002/06/25 03:17:56 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "intervaldata.h"
#include "summary.h"
#include <iostream>

using namespace std;

//____________________________________________________________

Interval* IntervalData::AddInterval(Interval* prev, double time, const
  LongVec1d& k, long s, long frompop, long topop, long recsite)
{
  // Intervals are assumed to be in time-sorted order

  Interval interval(prev, time, k, s, frompop, topop, recsite);
  intervals.push_back(interval);
  Interval* thisinterval = &(intervals.back());
  if (prev) 
    {
      prev->next = thisinterval;
      thisinterval->starttime = prev->endtime ;
    }
  else
    thisinterval->starttime = 0.;
  return thisinterval;
} /* AddInterval */

//____________________________________________________________

void IntervalData::PrintIntervalData() const
{
  list<Interval>::const_iterator it;
  for (it = intervals.begin(); it != intervals.end(); ++it) {
    const Interval& inter = *it;
    cout << "time " << inter.endtime << " activesites " << inter.activesites << " frompop " << 
      inter.frompop << " topop " << inter.topop << " recsite " << inter.recsite << endl;
    cout << "lines are ";
    unsigned long i;
    for (i = 0; i < inter.poplines.size(); ++i) cout << inter.poplines[i] << " ";
    cout << endl;
    cout << "Prev is " << inter.previous << " and next is " << inter.next << endl;
  }
} /* PrintIntervalData */

//____________________________________________________________
