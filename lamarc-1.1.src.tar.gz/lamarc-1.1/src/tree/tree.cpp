// $Id: tree.cpp,v 1.18 2002/06/26 19:11:56 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcdebug.h"
#include "tree.h"
#include "dlcell.h"
#include "datapack.h"
#include <assert.h>

#include <fstream> 

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

Tree::Tree(Random *rs, long npops)
: randomSource(rs),
  nPopulations(npops),
  nsites(0),
  dlValue(0.0),
  activelist(npops),
  intervallist(npops),
  dlCalculator(NULL)
{
  ID[0]         = 0;
  ID[1]         = 1;
}

//_______________________________________________________________________________

Tree::~Tree()
{

// deliberately blank due to shared_ptr auto cleanup

} /* Tree destructor */

//_______________________________________________________________________________

// NB This copy constructor does *not* copy the activelist and
// intervallist; it only initializes them (empty).

Tree::Tree(const Tree &tree, bool makestump)
: randomSource(tree.randomSource),
  nPopulations(tree.nPopulations),
  nsites(tree.nsites),
  dlValue(tree.dlValue),
  activelist(tree.nPopulations),     // not copied!
  intervallist(tree.nPopulations),   // not copied!
  individuals(tree.individuals),
  protoRange(tree.protoRange)
{

  ID[0]         = tree.ID[0];
  ID[1]         = tree.ID[1];
  
  protoCell = CopyDLCell(tree.protoCell);

  if (tree.dlCalculator.get()) 
    dlCalculator.reset(tree.dlCalculator->Clone());    // deep copy!

if (!makestump) {
// also need to deep copy the branchlist
   timelist = tree.timelist;

// now setup the tip pointers in the individuals correctly, since the
// individual copy ctor only makes empty containers of tips.
   unsigned long indiv;
   for(indiv = 0; indiv < individuals.size(); ++indiv) {
      StringVec1d tipnames = tree.individuals[indiv].GetAllTipNames();
      vector<Branch*> itips = GetTips(tipnames);
      individuals[indiv].SetTips(itips);
   }
}


}

//_______________________________________________________________________________

void Tree::AssignID(Branch *pBranch)
{
  // we simply assign the next available ID, wrapping around if
  // necessary, except that in the case of wrapping around in the
  // higher-order bin (ID[0]) we restart at tips+1, not at 0, in
  // case there are some very old tips still hanging around.

  ID[1]++;
  if (ID[1] == MAXLONG) {
    ID[1] = 0;
    ID[0]++;
    if (ID[0] == MAXLONG) {
      ID[0] = 0;
      ID[1] = timelist.GetNTips();
    }
  }
  pBranch->ID[0] = ID[0];
  pBranch->ID[1] = ID[1];
}

//_______________________________________________________________________________

void Tree::Clear()
{
  activelist.Clear();
  intervallist.Clear();
  timelist.Clear();
  ID[0] = 0;
  ID[1] = 0;

  protoCell.clear();
  dlCalculator.reset();
}

//_______________________________________________________________________________

void Tree::CopyTips(const Tree *tree)
{
  timelist.CopyTips(tree->timelist);
  nPopulations = tree->nPopulations;

  // Copy the ID counter.
  ID[0] = tree->ID[0];
  ID[1] = tree->ID[1];

//  protoCell.reset(tree->protoCell->Clone());   // deep copy
  protoCell = CopyDLCell(tree->protoCell);

  dlCalculator.reset(tree->dlCalculator->Clone());  // deep copy

individuals = tree->individuals;
// now setup the tip pointers in the individuals correctly
unsigned long indiv;
for(indiv = 0; indiv < individuals.size(); ++indiv) {
   StringVec1d tipnames = tree->individuals[indiv].GetAllTipNames();
   vector<Branch*> itips = GetTips(tipnames);
   individuals[indiv].SetTips(itips);
}
  
} 

//_______________________________________________________________________________

void Tree::CopyBody(const Tree *tree)
{
  activelist.Clear();
  intervallist.Clear();
  timelist.CopyBody(tree->timelist);

  dlValue = tree->dlValue;
} 

//_______________________________________________________________________________

TBranch *Tree::CreateTip()
{
  TBranch *pTip = timelist.CreateTip();

  AssignID(pTip);
//  pTip->dlcell = protoCell->Clone();
  pTip->dlcell = CopyDLCell(protoCell);
  pTip->range = protoRange;

  return pTip;
}

//_______________________________________________________________________________

void Tree::SetIndividualsWithTips(const vector<Individual>& indvec)
{
  individuals = indvec;
  unsigned long ind, ninds = indvec.size();
  for(ind = 0; ind < ninds; ++ind)
     individuals[ind].SetTips(indvec[ind].GetAllTips());

} /* SetIndividualsWithTips */

//_______________________________________________________________________________

TreeSummary* Tree::SummarizeTree() const
{
  TreeSummary* treesum = registry.GetProtoTreeSummary().Clone();
  treesum->Summarize(*this);
  return treesum;
} /* SummarizeTree */

//_______________________________________________________________________________

void Tree::CalculateDataLikes()
{
  // V2 -- will become a loop over vector of loci
  dlCalculator->Calculate();

#if LIKETRACK
ofstream of;
of.open("likes1",ios::app);
of << dlValue << " ";
of.close();
#endif

#ifndef NDEBUG
  // This code tests a full likelihood recalculation against
  // the time-saving partial recalculation.  Slow but sure.
  double oldlike = dlValue;
  timelist.SetAllUpdateDLs();
  dlCalculator->Calculate();
  assert(dlValue == oldlike);
#endif
  timelist.ClearUpdateDLs();         // reset the updating flags

} /* CalculateDataLikes */

//_______________________________________________________________________________

void Tree::ActivateTips()
{
  Branch *pTip;

  timelist.ClearBody();

  Branchiter brit;
  for (brit = timelist.Begin(); brit != timelist.End(); ++brit)
  {
    pTip = *brit;
    activelist.Append(pTip);
  }

  ID[0] = timelist.GetNTips();
  ID[1] = 0;

}

//_______________________________________________________________________________

Branch *Tree::ActivateBranch()
{
  // NCuttable-1 because the root branch is of a cuttable type but is
  // not, in fact, a cuttable branch.

  // + 1 because it's helpful to count cuttable branches from 1, not 0.

  long rn = randomSource->Integer(timelist.GetNCuttable()-1) + 1;

  Branchiter brit;
  Branch *pActive = NULL;

  for (brit = timelist.Begin(); rn > 0; ++brit)
  {
    pActive = *brit;
    rn -= pActive->Cuttable();
  }

  assert(pActive != NULL);  // we didn't find any cuttable branches?

  Break(pActive);
  pActive->parent[0] = NULL;
  pActive->parent[1] = NULL;
  activelist.Append(pActive);
  return pActive;
}

//_______________________________________________________________________________

#if 0
// unfinished code for twiddle
Branch* Tree::ReassignRecombination()
{
  long numrecs = timelist.HowMany(REC);
  if (numrecs == 0) return NULL;    // we can't do it!

  long rn = randomSource->Integer(numrecs) + 1;

  Branchiter brit;

  for (brit = timelist.Begin(); rn > 0; ++brit) 
  {
    if (*brit->Event() == REC) {
      --rn;
    }
  }

  Branch* pBranch = *brit;
}
#endif

//_______________________________________________________________________________

Branch *Tree::ActivateRoot()
{
  intervallist.Clear();               // Remove all remaining contemporary branches.
  Branch *pBase   = timelist.Base();  // Get the tree base and root.
  Branch *pRoot   = pBase->child[0];
  pBase->child[0]  = NULL;             // Disconnect them.
  pRoot->parent[0] = NULL;
  activelist.Append(pRoot);           // Append the root to the active list.
  return pRoot;
}

//_______________________________________________________________________________

void Tree::AttachBase()
{
  Branch *pBase     = timelist.Base();          // Get the tree base.
  Branch *pBranch   = activelist.RemoveFirst(); // Remove the root from the active list.
  pBase->child[0]    = pBranch;                 // Link the root to the base.
  pBranch->parent[0] = pBase;
}

//_______________________________________________________________________________

double Tree::FirstInterval(double eventT)
{
  Branch *pBranch;

  Branchiter brit;
  for (brit = timelist.Begin(); brit != timelist.End(); ++brit)
  {
    pBranch = *brit;
    if (eventT < pBranch->eventtime)
       break;

    if (pBranch->parent[0])
    {
      if (eventT < pBranch->parent[0]->eventtime)
        intervallist.Collate(pBranch);
    }
  }

  return intervallist.IntervalBottom();
}

//_______________________________________________________________________________

double Tree::NextInterval()
{
  // Remove first branch from contemporary list
  Branch *pBranch = intervallist.RemoveFirst();

  // Insert its parent into contemporary list
  Branch *pParent = pBranch->parent[0];
  intervallist.Collate(pParent);        

  if (pParent->child[1])                    // If the branch has a sibling,
    intervallist.RemoveFirst();             // remove it from the contemporary list also.

  // Get the time at the bottom of the current interval.
  return intervallist.IntervalBottom();
}
//_______________________________________________________________________________

void Tree::Break(Branch *pBranch)
{
  Branch* pParent = pBranch->parent[0];

  if (pParent->CanRemove(pBranch))
  {
    Break(pParent);                                  // Recursion
    timelist.Remove(pParent);

    pParent = pBranch->parent[1];
    if (pParent)
    {
      Break(pParent);                                // Recursion
      timelist.Remove(pParent);
    }
  }
}

//_______________________________________________________________________________

void Tree::Prune()
{
  intervallist.Clear();
  timelist.Prune();
}

//_______________________________________________________________________________

Branch *Tree::CoalesceActive(double eventT, long pop, long
  maxEvents)
{
  Branch *pActive1, *pActive2;   // Active branches for coalescence
  Branch *pParent;               // New parent of the active branches
  double  rn;

  if (timelist.HowMany(COAL) >= maxEvents) {
    coal_overrun e;
    throw e;
  }

  // Pick two active branches from the population at random.
  rn = randomSource->Float();
  pActive1 = activelist.RemoveBranch(pop, rn);

  rn = randomSource->Float();
  pActive2 = activelist.RemoveBranch(pop, rn);

  // Create the parent of the two branches.
  pParent = new CBranch;
  AssignID(pParent);
  pParent->eventtime  = eventT;
  pParent->population = pop;

  pParent->child[0]    = pActive1;
  pParent->child[1]    = pActive2;
  pActive1->parent[0]  = pParent;
  pActive2->parent[0]  = pParent;

  pParent->dlcell   = CopyDLCell(protoCell);
  pParent->range    = protoRange;
  pParent->SetUpdateDL();    // mark this branch for updating

  timelist.Collate(pParent);
  activelist.Append(pParent);    // Append the parent to the active list.
  return pParent;
}

//_______________________________________________________________________________
 
Branch* Tree::CoalesceInactive(double eventT, long pop, long
  maxEvents)
{
  Branch *pActive;               // Active branch for coalescence
  Branch *pInactive;             // Inactive branch for coalescence
  Branch *pParent;               // New parent of the active branch
  double  rn;

  if (timelist.HowMany(COAL) >= maxEvents) {
    coal_overrun e;
    throw e;
  }

  // Pick an active branch and a contemporary inactive branch from the population at random.
  rn = randomSource->Float();
  pActive = activelist.RemoveBranch(pop, rn);

  rn = randomSource->Float();
  pInactive = intervallist.RemoveBranch(pop, rn);

  // Create the parent of the two branches.
  pParent = new CBranch;
  AssignID(pParent);
  pParent->eventtime  = eventT;
  pParent->population = pop;

  // Hook children to parent
  pParent->child[0]    = pInactive;
  pParent->child[1]    = pActive;

  // Hook pInactive's old parent up to new parent
  pInactive->parent[0]->ReplaceChild(pInactive, pParent);
  pInactive->parent[0]   = pParent;
  if (pInactive->parent[1])
  {
    pInactive->parent[1]->ReplaceChild(pInactive, pParent);
    pInactive->parent[1] = NULL;
  }

  pActive->parent[0] = pParent;

  pParent->dlcell = CopyDLCell(protoCell);
  pParent->range = protoRange;
  timelist.SetUpdateDLs(pParent);               // Set the update data likelihood flag.

  timelist.Collate(pParent);
  intervallist.Collate(pParent);
  return pParent;
}

//_______________________________________________________________________________

Branch* Tree::Migrate(double eventT, long pop2, long pop, long maxEvents)
{
  Branch *pActive;
  Branch *pParent;
  double  rn;                    // random number

  if (timelist.HowMany(MIG) >= maxEvents) {
    mig_overrun e;
    throw e;
  }

  // Pick an active branch from the population at random.
  rn = randomSource->Float();
  pActive = activelist.RemoveBranch(pop2, rn);

  pParent = new MBranch;
  AssignID(pParent);
  pParent->eventtime  = eventT;
  pParent->population = pop;

  pParent->child[0]    = pActive;
  pActive->parent[0]   = pParent;

  pParent->range = protoRange;

  timelist.Collate(pParent);
  activelist.Append(pParent);      // Append the parent to the active list.
  return pParent;
}

//____________________________________________________________________________

void Tree::SwapSiteDLs()
{
  Individual ind;
  Branch *pTip1, *pTip2;
  long rnd1, rnd2, posn, size;
  LongVec1d phasemarkers;

  // Pick an individual with phase-unknown sites at random.
  do {
    rnd1 = randomSource->Integer(individuals.size());
    ind  = individuals[rnd1];
    phasemarkers = ind.GetPhaseMarkers();
  } while (phasemarkers.size() == 0);

  // Pick a phase marker at random.
  rnd1 = randomSource->Integer(phasemarkers.size());
  posn = phasemarkers[rnd1];

  // Pick two tips in the individual at random.
  vector<Branch*> haps = ind.GetAllTips();
  size = haps.size();
  rnd1 = randomSource->Integer(size);
  rnd2 = randomSource->Integer(size-1);
  if (rnd1 <= rnd2)
    rnd2++;

  pTip1   = haps[rnd1];
  pTip2   = haps[rnd2];

  // NB: Swap first DLCell only!

  assert(pTip1->dlcell.size() == pTip2->dlcell.size());

  // Get the data likelihood arrays.
  Cell_ptr dlcell1 = pTip1->dlcell[0], dlcell2 = pTip2->dlcell[0];

  // Swap the cells at the marker position.
  dlcell1->SwapDLs(dlcell2.get(),posn);

  MarkForDLRecalc(pTip1);
  MarkForDLRecalc(pTip2);

} /* Tree::SwapSiteDL */

//____________________________________________________________________________

void Tree::MarkForDLRecalc(Branch* markbr)
{

markbr->SetUpdateDL();
markbr->MarkParentsForDLCalc();

} /* Tree::MarkForDLRecalc */

//____________________________________________________________________________

rangevector Tree::GetSubtrees() const
{
  rangevector subtrees;
  subtrees.push_back(rangepair(0, nsites));  // half open interval
  return subtrees;
}

//____________________________________________________________________________

vector<Branch*> Tree::GetTips(StringVec1d& tipnames) const
{
vector<Branch*> tips;
StringVec1d::iterator tname;
for(tname = tipnames.begin(); tname != tipnames.end(); ++tname)
   tips.push_back(timelist.GetTip(*tname));

return tips;

} /* GetTips */

//____________________________________________________________________________

bool Tree::NoPhaseUnknownSites() const
{
IndVec::const_iterator ind;
for(ind = individuals.begin(); ind != individuals.end(); ++ind)
   if (ind->AnyPhaseUnknownSites()) return false;

return true;

} /* Tree:NoPhaseUnknownSites */

//____________________________________________________________________________

bool Tree::IsLegal() const
{
  // NB:  This can only be called on a completed tree, not one
  // in mid-rearrangement.

  // each Branch validates itself
  Branchconstiter brit = timelist.Begin();
  for ( ; brit != timelist.End(); ++brit) {
    if (!(*brit)->CheckInvariant()) return false;
  }

  return true;
} /* IsLegal */

//____________________________________________________________________________

bool Tree::operator==(const Tree& src) const
{
  if (nPopulations != src.nPopulations) return false;
  if (nsites != src.nsites) return false;
  if (dlValue != src.dlValue) return false;
  if (timelist != src.timelist) return false;

  // DEBUG I don't guarantee these are the same tree, especially if
  // we are in mid-rearrangement, but they are at least very similar. --Mary
  return true;

} /* operator== */
 
//____________________________________________________________________________

vector<Cell_ptr> Tree::CopyDLCell(const vector<Cell_ptr> src)
{

// deep copy!

vector<Cell_ptr> cells;
unsigned long i;
for (i = 0; i < src.size(); ++i) {
  Cell_ptr newcell(src[i]->Clone());
  cells.push_back(newcell);
}

return cells;
  
} /* CopyDLCell */

//____________________________________________________________________________
//____________________________________________________________________________

Tree* PlainTree::Clone() const
{
  return new PlainTree(*this,false);

} /* PlainTree constructor */

//____________________________________________________________________________

Tree* PlainTree::MakeStump() const
{
  return new PlainTree(*this,true);
} /* PlainTree stump maker */
