//$Id: summary.cpp,v 1.10 2002/06/26 19:11:56 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcdebug.h"
#include "summary.h"
#include "constants.h"
#include "intervaldata.h"
#include <cmath>
#include <assert.h>

using namespace std;

//____________________________________________________________
//____________________________________________________________

const DoubleVec1d& Summary::GetShortPoint() const
{
  return shortpoint;

} /* Summary::ShortPoint */

//____________________________________________________________

const DoubleVec1d& Summary::GetShortWait() const
{
  return shortwait;
} /* Summary::ShortWait */

//____________________________________________________________

Interval const * Summary::GetLongPoint() const
{
  assert(!shortness);  // tried to get long-form inappropriately?
  return front;
} /* Summary::LongPoint */

//____________________________________________________________

const list<Interval>& Summary::GetLongWait() const
{
  assert(!shortness);  // tried to get long-form inappropriately?
  return intervalData.intervals;
}  /* Summary::LongWait */

//____________________________________________________________


void Summary::AddInterval(double time, LongVec1d k, long s, long frompop,
  long topop, long recsite)
{
  // add interval, retaining a pointer to it
  Interval* thisinterval = intervalData.AddInterval(back, time, k, s, frompop,
    topop, recsite);
  // put that pointer in appropriate place(s)
  if (!front) front = thisinterval;
  back = thisinterval;

} /* Summary::AddInterval */

//____________________________________________________________

bool Summary::Compress()
{
  ComputeShortWait();
  ComputeShortPoint();
  return shortness;
} /* Summary::Compress */

//____________________________________________________________
//____________________________________________________________

Summary* CoalSummary::Clone(IntervalData& interval) const
{
  // NB:  This takes a reference to the IntervalData to which
  // the new Summary will belong.  It does *not* copy the
  // contents of the old Summary; only the type, npop and shortness.

  return new CoalSummary(interval, npop, shortness);
} /* Clone */

//____________________________________________________________

void CoalSummary::ComputeShortPoint()
{ 
  // set up the recipient vector
  shortpoint.assign(npop, 0.0);

  Interval* in;

  for (in = front; in != NULL; in = in->next) {
    ++shortpoint[in->frompop];
  }

} /* CoalSummary::ComputeShortPoint */

//____________________________________________________________

void CoalSummary::ComputeShortWait()
{
  // set up the recipient vector
  shortwait.assign(npop, 0.0);

  list<Interval>::const_iterator interval = intervalData.begin();
  list<Interval>::const_iterator end = intervalData.end();
  long pop;
  double starttime = 0.0;
  
  for ( ; interval != end; ++interval) {
    double deltaTime = (*interval).endtime - starttime;
    for (pop = 0; pop < npop; ++pop) {
      // OPT:  pre-calculate k(k-1) in storage routines....
      double k = (*interval).poplines[pop];
      shortwait[pop] += deltaTime * k * (k - 1);
    }
    starttime = (*interval).endtime;
  }

} /* CoalSummary::ComputeShortWait */

//____________________________________________________________

void CoalSummary::AdjustSummary(const DoubleVec1d& totals)
{
  // The following code shows how this *would* be done, but
  // we don't do it!--having no coalescences in a particular
  // population is considered acceptable.

#if 0
  assert(totals.size() != 0);  // inconsistent forces?!
  unsigned long param;
  Interval* fakefront = NULL;
  Interval* fakeback = NULL;
  LongVec1d fake_k(totals.size(), 0L);
  bool didadjust = false;
  
  for (param = 0; param != totals.size(); ++param) {
    if (totals[param] == 0.0) {  // no events of this type
      didadjust = true;

      // add fake interval
      Interval* newinterval = 
        fakeIntervals.AddInterval(fakeback, 0.0, fake_k, 0, param,
        FLAGLONG, FLAGLONG);
      if (!fakefront) fakefront = newinterval;
      fakeback = newinterval;

      // adjust short-form summary statistics
      shortpoint[param] += 1.0;
    }
  }

  if (didadjust) {
    // hook fake intervals onto front of real intervals
    fakeback->next = front;
    front = fakefront;
  }
#endif
} /* CoalSummary::AdjustSummary */

//____________________________________________________________
//____________________________________________________________

Summary* MigSummary::Clone(IntervalData& interval) const
{
  // NB:  This takes a reference to the IntervalData to which
  // the new Summary will belong.  It does *not* copy the
  // contents of the old Summary; only the type, npop and shortness.

  return new MigSummary(interval, npop, shortness);
} /* Clone */

//____________________________________________________________

void MigSummary::ComputeShortPoint()
{ 
  // set up the recipient vector
  shortpoint.assign(npop * npop, 0.0);

  Interval* in;

  for (in = front; in != NULL; in = in->next) {
    ++shortpoint[npop * in->frompop + in->topop];
  }

} /* MigSummary::ComputeShortPoint */

//____________________________________________________________

void MigSummary::ComputeShortWait()
{
  // set up the recipient vector
  shortwait.assign(npop, 0.0);

  list<Interval>::const_iterator interval = intervalData.begin();
  list<Interval>::const_iterator end = intervalData.end();
  long pop;
  double starttime = 0.0;

  for ( ; interval != end; ++interval) {
    double deltaTime = (*interval).endtime - starttime;
    for (pop = 0; pop < npop; ++pop) {
      double k = (*interval).poplines[pop];
      shortwait[pop] += deltaTime * k;
    }
    starttime = (*interval).endtime;
  }

} /* MigSummary::ComputeShortWait */

//____________________________________________________________

void MigSummary::AdjustSummary(const DoubleVec1d& totals)
{
  assert(totals.size() != 0);  // inconsistent forces?!
  Interval* fakefront = NULL;
  Interval* fakeback = NULL;

  unsigned long npops = static_cast<unsigned long>(sqrt(totals.size()));
  assert(totals.size() == npops * npops);  // not square?!
 
  LongVec1d fake_k(npops, 0L);
  bool didadjust = false;
  
  unsigned long frompop, topop;
  
  for (frompop = 0; frompop != npops; ++frompop) {
    for (topop = 0; topop != npops; ++topop) {

      // no adjustment to diagonal entries
      if (frompop == topop) continue;

      long param = frompop * npops + topop;   // index into linearized vector

      if (totals[param] == 0.0) {  // no events of this type
        didadjust = true;

        // add fake interval
        Interval* newinterval = 
          fakeIntervals.AddInterval(fakeback, 0.0, fake_k, 0, frompop,
          topop, FLAGLONG);
        if (!fakefront) fakefront = newinterval;
        fakeback = newinterval;

        // adjust short-form summary statistics
        shortpoint[param] += 1.0;
      }
    }
  }

  if (didadjust) {
    // hook fake intervals onto front of real intervals
    fakeback->next = front;
    front = fakefront;
  }
} /* MigSummary::AdjustSummary */

//____________________________________________________________
//____________________________________________________________

Summary* RecSummary::Clone(IntervalData& interval) const
{
  // NB:  This takes a reference to the IntervalData to which
  // the new Summary will belong.  It does *not* copy the
  // contents of the old Summary; only the type, npop and shortness.

  return new RecSummary(interval, npop, shortness);
} /* Clone */

//____________________________________________________________

void RecSummary::ComputeShortPoint()
{ 
  // set up the recipient vector
  shortpoint.assign(1, 0.0);

  Interval* in;
  for (in = front; in != NULL; in = in->next) {
    ++shortpoint[0];
  }

} /* RecSummary::ComputeShortPoint */

//____________________________________________________________

void RecSummary::ComputeShortWait()
{
  // set up the recipient vector
  shortwait.assign(1, 0.0);

  list<Interval>::const_iterator interval = intervalData.begin();
  list<Interval>::const_iterator end = intervalData.end();
  double starttime = 0.0;

  for ( ; interval != end; ++interval) {
    double deltaTime = (*interval).endtime - starttime;
    shortwait[0] += deltaTime * (*interval).activesites;
    starttime = (*interval).endtime;
  }

} /* RecSummary::ComputeShortWait */

//____________________________________________________________

void RecSummary::AdjustSummary(const DoubleVec1d& totals)
{
  assert(totals.size() == 1);  // inconsistent forces?!
  Interval* fakefront = NULL;
  Interval* fakeback = NULL;
  LongVec1d fake_k;
  bool didadjust = false;
  
  long param = 0;

  if (totals[param] == 0.0) {  // no events of this type
    didadjust = true;

    // add fake interval
    Interval* newinterval = 
      fakeIntervals.AddInterval(fakeback, 0.0, fake_k, 0, FLAGLONG,
      FLAGLONG, 0);
    if (!fakefront) fakefront = newinterval;
    fakeback = newinterval;

    // adjust short-form summary statistics
    shortpoint[param] += 1.0;
  }

  if (didadjust) {
    // hook fake intervals onto front of real intervals
    fakeback->next = front;
    front = fakefront;
  } 
} /* RecSummary::AdjustSummary */

//____________________________________________________________
//____________________________________________________________
