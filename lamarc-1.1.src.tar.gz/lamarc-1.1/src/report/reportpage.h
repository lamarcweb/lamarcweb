// $Id: reportpage.h,v 1.2 2002/06/25 03:17:51 mkkuhner Exp $

#ifndef REPORTPAGE
#define REPORTPAGE

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************
 The base class ReportPage represents a single page of the output
 report; subclasses produce specific pages.
 
 Written by Jon Yamato
*******************************************************************/

#include <iostream>
#include <fstream>
#include <strstream>
#include <ctype.h>
#include <vector>
#include <string>
#include <algorithm>
#include <functional>
#include "constants.h"
#include "stringx.h"
#include "force.h"
#include <time.h>
#include "timex.h"
#include "runreport.h"
#include "definitions.h"

//#include "registry.h"
//#include "postoutpack.h"

//#include "dlmodel.h"    // for CreateDataModelReport() in DataPage::Show()
//#include "parameter.h"   // for Parameter member access in
                          //    LikePage::MakePlot()

using std::ofstream;
class PlotStruct;
class Parameter;

const long DEFLENGTH=-1;
const char DEFDLM='=';

//__________________________________________________

class ReportPage
{

private:
ReportPage();  // deliberately undefined

protected:
ofstream &outf;
const Registry& registry;
const ChainPack& chainpack;
vector<string> pagetitle;
char titledlm;
long pagelength, pagewidth;
verbosity_type verbosity;

virtual void CopyAllMembers(const ReportPage &src);

string MakeLineOf(const char ch, long length=DEFLINELENGTH,
   long indent=DEFINDENT);
string MakePageBreak();
string MakeBlankLine();
vector<string> MakeTitle();
virtual vector<string> MakeTableTitle(const string &title);
virtual vector<string> MakeTableTitle(const char *title);
virtual string MakeSimpleRow(vector<long>& colwdth, vector<string>& contents);
virtual string MakeTwoCol(const vector<long>& colwdth, const string& col1,
   const string& col2);
virtual string MakeTwoCol(const vector<long>& colwdth, const string& col1,
   const char* col2);
virtual string MakeTwoCol(const vector<long>& colwdth, const char* col1,
   const string& col2);
virtual string MakeTwoCol(const vector<long>& colwdth, const char* col1,
   const char* col2);

virtual string MakeSectionBreak(const char dlm=DEFDLM, 
   long width=DEFLINELENGTH, long indent=DEFINDENT);
virtual vector<string> MakeTable(vector<string> &colhdr, StringVec2d &rowhdr,
   vector<long> &colwdth, long hdrindent, StringVec3d &innards);

void PrintTitle();
void PrintLineOf(const char ch, long length=DEFLINELENGTH,
   long indent=DEFINDENT);
void PrintPageBreak();
void PrintBlankLine();

virtual void PrintSimpleRow(vector<long> &colwdth, vector<string> &contents);
virtual void PrintTwoCol(const vector<long> &colwdth, const string &col1,
   const string &col2);
virtual void PrintTwoCol(const vector<long> &colwdth, const char *col1,
   const string &col2);
virtual void PrintTwoCol(const vector<long> &colwdth, const string &col1,
   const char *col2);
virtual void PrintTwoCol(const vector<long> &colwdth, const char *col1,
   const char *col2);
virtual void PrintCenteredString(const string &str, long width=DEFLINELENGTH,
   long indent=DEFINDENT, bool trunc = true);
virtual void PrintCenteredString(const char *str, long width=DEFLINELENGTH,
   long indent=DEFINDENT, bool trunc = true);
virtual void PrintTableTitle(const string &title);
virtual void PrintTableTitle(const char *title);
virtual void PrintSectionBreak(const char dlm=DEFDLM, 
   long width=DEFLINELENGTH, long indent=DEFINDENT);
virtual void PrintTable(vector<string> &colhdr, StringVec2d &rowhdr,
   vector<long> &colwdth, long hdrindent, StringVec3d &innards);

// helper functions for the MlePage and ProfPage
virtual double GetCentile(const vector<centilepair>& centiles,
   double pcent);

public:
ReportPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
ReportPage(const ReportPage &src);
virtual ~ReportPage() {};
virtual ReportPage &operator=(const ReportPage &src);

virtual void Setup(vector<string> &title, long pglength=DEFLENGTH,
   long pgwidth=DEFLINELENGTH, char tdlm=DEFDLM);
virtual void Setup(string &title, long pglength=DEFLENGTH,
   long pgwidth=DEFLINELENGTH, char tdlm=DEFDLM);
virtual void Setup(const char *title, long pglength=DEFLENGTH,
   long pgwidth=DEFLINELENGTH, char tdlm=DEFDLM);
virtual void Show();

};

//__________________________________________________
//__________________________________________________

class MlePage : public ReportPage
{
protected:
const long hdrindent;
long npops, ncols;
LongVec1d colwidth;
StringVec2d collabels;

virtual void CopyMembers(const MlePage &src);
virtual StringVec1d SetupColhdr(const Force &forces, bool lowerpers);
virtual StringVec2d SetupRowhdr(const Force &forces);
virtual StringVec3d SetupInnards(const Force &forces, bool lowerpers);

public:
MlePage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
MlePage(const MlePage &src);
virtual ~MlePage() {};
virtual MlePage &operator=(const MlePage &src);

virtual void Show();

};

//__________________________________________________
//__________________________________________________

class ProfPage : public ReportPage
{
protected:
LongVec1d colwidth;
long totalwidth;

virtual void CopyAllMembers(const ProfPage& src);
virtual StringVec1d SetupColhdr(const Parameter& param, bool lowerpers);
virtual StringVec2d SetupRowhdr(const ParamVector& params,
   const Parameter& param);
        StringVec1d MakeInnardsLineFrom(const vector<centilepair>& numbers,
   const DoubleVec1d& modifiers);
virtual StringVec3d SetupInnards(const ParamVector& params, 
   unsigned long pindex, long region, bool lowerpers);
virtual void DisplayParameters(const ParamVector& params, long region);

public:
ProfPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
ProfPage(const ProfPage& src);
virtual ~ProfPage() {};
virtual ProfPage& operator=(const ProfPage& src);

virtual void Show();
};

//__________________________________________________
//__________________________________________________

class UsrPage : public ReportPage
{
protected:
long npops;
vector<long> colwidth;

virtual void CopyMembers(const UsrPage &src);

public:
UsrPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
UsrPage(const UsrPage &src);
virtual ~UsrPage() {};
virtual UsrPage &operator=(const UsrPage &src);

virtual void Show();
};

//__________________________________________________
//__________________________________________________

class DataPage : public ReportPage
{

private:
const long table1, table2;
long npops;
vector<long> colwidth;

protected:
virtual void CopyMembers(const DataPage &src);
virtual vector<string> SetupColhdr(long whichtable);
virtual StringVec2d SetupRowhdr(long whichtable);
virtual StringVec3d SetupInnards(long whichtable);

public:
DataPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
DataPage(const DataPage &src);
virtual ~DataPage() {};
virtual DataPage &operator=(const DataPage &src);

virtual void Show();
};

//__________________________________________________
//__________________________________________________

class RunPage : public ReportPage
{

private:
vector<long> colwidth;

protected:
virtual void CopyMembers(const RunPage &src);

public:
RunPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
RunPage(const RunPage &src);
virtual ~RunPage() {};
virtual RunPage &operator=(const RunPage &src);

virtual void Show();
};

//__________________________________________________
//__________________________________________________

class LikePage : public ReportPage
{
private:
bool Divides(long x, long y);
bool EmptyPlot(PlotStruct& plot);

protected:
virtual void CopyMembers(const LikePage &src);

public:
LikePage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
LikePage(const LikePage &src);
virtual ~LikePage() {};
virtual LikePage &operator=(const LikePage &src);

string MakeBorder(long points, long breaks = 4);
vector<string> MakeInnards(const DoubleVec2d& likes);
vector<string> MakeLikePlot(const StringVec1d& innards,
   const Parameter& parmX, const Parameter& parmY, long breaks = 4);
DoubleVec2d AddGraphs(const DoubleVec2d& a, const DoubleVec2d& b);

virtual void Show();
};

#endif
