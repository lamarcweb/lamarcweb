// $Id: outputfile.cpp,v 1.2 2002/06/25 03:17:51 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <exception>
#include "outputfile.h"
#include "errhandling.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//__________________________________________________

OutputFile::OutputFile(const Registry& reg, const ChainPack& chpack) :
registry(reg), chainpack(chpack)
{

outf.open(registry.GetUserParameters().
          GetResultsFileName().c_str());

if (!outf) {
   file_error e("Unable to open output file\n");
   throw e ;
}

} /* OutputFile */

//__________________________________________________

void OutputFile::AddReport(ReportPage &report)
{

reports.push_back(&report);

} /* AddReport */

//__________________________________________________

void OutputFile::ShowReports()
{
vector<ReportPage *>::iterator rpit;
for(rpit = reports.begin(); rpit != reports.end(); ++rpit)
   (*rpit)->Show();

} /* ShowReports */

//__________________________________________________

void OutputFile::Display()
{
verbosity_type verbosity = registry.GetUserParameters().GetVerbosity();

MlePage page1(outf,registry,chainpack);
page1.Setup("ML Estimates of Parameters");
AddReport(page1);

ProfPage page2(outf,registry,chainpack);
page2.Setup("Profile Likelihoods");

UsrPage page3(outf,registry,chainpack);
page3.Setup("User Specified Options");

DataPage page4(outf,registry,chainpack);
page4.Setup("Data summary");

RunPage page5(outf,registry,chainpack);
page5.Setup("Run Reports by Region");

#if 0
LikePage page6(outf,registry,chainpack);
page6.Setup("Log Likelihood surfaces");
#endif

if (verbosity != CONCISE) {
   AddReport(page2);
   AddReport(page3);
   AddReport(page4);
   AddReport(page5);
#if 0
   AddReport(page6);
#endif
} else if (registry.GetUserParameters().GetEchoData())
   AddReport(page4);


ShowReports();

} /* Run */

//__________________________________________________
