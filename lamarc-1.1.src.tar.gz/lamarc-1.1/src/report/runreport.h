// $Id: runreport.h,v 1.3 2002/06/25 03:17:52 mkkuhner Exp $
#ifndef RUNREPORT
#define RUNREPORT

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <vector>
#include "vectorx.h"
#include <string>
#include "stringx.h"
#include <iostream>
#include <strstream>
#include <math.h>
#include <time.h>
#include "timex.h"
#include "constants.h"

class ChainOut;
class ChainPack;
class Force;
class ForceSummary;

/******************************************************************
This class manages runtime reports and provides runtime-report
information to the output manager.  It takes input from the
chain manager.  Key routines are PrintBar, meant to be called
repeatedly by the chain itself (for the scrolling bar);
MakeReport, which constructs a chain summary report, and 
FormatReport, which prints it.  (The two are separate
so that the output reporter can take the results of MakeReport and
reformat them to its liking.)

Mary Kuhner       October 2000

Added prognosis of profiles October 2001 -- Mary Kuhner

******************************************************************/

class RunReport {
  public:

  RunReport(const ForceSummary& fs, const StringVec1d& pnames,
    verbosity_type progress=NORMAL) : 
    level(progress), forcesum(fs), popnames(pnames) {};
  ~RunReport() {};
  void SetBarParameters(long totsteps, long burn, long chno, long chtype);
  void PrintBar(long steps);
  void Prognose(const ChainPack& chpack, long steps, long total);
  void MakeReport(const ChainOut& chout) const;
  vector<string> FormatReport(const ChainOut& chout, bool current,
    long linelength) const;
  void DisplayReport(const ChainOut& chout);
  void RecordProfileStart();
  void PrognoseProfiles(long thisprof, long totprofs);

  private:

  verbosity_type level;
  // the following three are mutable so that a report can be prepared
  // and stored internally even in a const RunReport object
  mutable string       scalars;            // these three store run reports
  mutable string       tabheaders;
  mutable StringVec1d  tables;
  const ForceSummary& forcesum;
  StringVec1d  popnames;           // population names
  time_t       profilestart;       // time at which profiling began

// these are used to control the scrolling bar
  long         totalsteps;
  long         chainno;
  string       chaintype;
  long         burnin;
  double       burnpercent;

}; /* RunReport */

#endif
