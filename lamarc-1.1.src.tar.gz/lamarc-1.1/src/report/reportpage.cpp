// $Id: reportpage.cpp,v 1.10 2002/06/25 03:17:51 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// All versions of SetupColhdr() used for PrintTable() must
//   put "\n" at EOL for each line.  PrintTable() will not do it!
//
// UserOptions
//    infilenames, if > 1, print ugly

#include "reportpage.h"
#include "registry.h"
#include "dlmodel.h"
#include "parameter.h"
#include "chainpack.h"
#include "types.h"
#include "plotstat.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//__________________________________________________

ReportPage::ReportPage(ofstream& pf, const Registry& reg, 
   const ChainPack& chpack, long pglngth, long pgwdth) :
outf(pf), registry(reg), chainpack(chpack)
{

verbosity = registry.GetUserParameters().GetVerbosity();
pagelength = pglngth;
pagewidth = pgwdth;

} /* ReportPage::ReportPage */

//__________________________________________________

void ReportPage::CopyAllMembers(const ReportPage &src)
{

pagetitle = src.pagetitle;
titledlm = src.titledlm;
pagelength = src.pagelength;
pagewidth = src.pagewidth;
verbosity = src.verbosity;

} /* ReportPage::CopyAllMembers */

//__________________________________________________

ReportPage::ReportPage(const ReportPage &src) :
outf(src.outf), registry(src.registry), chainpack(src.chainpack)
{

CopyAllMembers(src);

} /* ReportPage::ReportPage */

//__________________________________________________

ReportPage &ReportPage::operator=(const ReportPage &src)
{

CopyAllMembers(src);

return *this;

} /* ReportPage::operator= */

//__________________________________________________

string ReportPage::MakeLineOf(const char ch, long length, long indent)
{
string line;
long pos;

for(pos = 0; pos < indent; ++pos)
   line += " ";

for( ; pos < length; ++pos)
   line += ch;

line += string("\n");

return(line);

} /* ReportPage::MakeLineOf */

//__________________________________________________

string ReportPage::MakePageBreak()
{

string line = string("\n");

return(line);

} /* ReportPage::MakePageBreak */

//__________________________________________________

string ReportPage::MakeBlankLine()
{

return(string("\n"));

} /* ReportPage::MakeBlankLine */

//__________________________________________________

string ReportPage::MakeSimpleRow(vector<long>& colwdth,
   vector<string>& contents)
{
string line;
long col, ncols = colwdth.size();
for(col = 0; col < ncols; ++col) {
   line += MakeJustified(contents[col],colwdth[col]);
}
line += "\n";

return(line);

} /* ReportPage::MakeSimpleRow */
//__________________________________________________

string ReportPage::MakeTwoCol(const vector<long>& colwdth,
   const string& col1, const string& col2)
{
// Left column; left justified
string line = MakeJustified(col1,-1*colwdth[0]);
// Right column; right justified
line += MakeJustified(col2,colwdth[1]);
line += "\n";

return(line);

} /* ReportPage::MakeTwoCol */
//__________________________________________________

string ReportPage::MakeTwoCol(const vector<long>& colwdth,
   const string& col1, const char* col2)
{

return(MakeTwoCol(colwdth,string(col1),string(col2)));

} /* ReportPage::MakeTwoCol */
//__________________________________________________

string ReportPage::MakeTwoCol(const vector<long>& colwdth,
   const char* col1, const string& col2)
{

return(MakeTwoCol(colwdth,string(col1),string(col2)));

} /* ReportPage::MakeTwoCol */
//__________________________________________________

string ReportPage::MakeTwoCol(const vector<long>& colwdth,
   const char* col1, const char* col2)
{

return(MakeTwoCol(colwdth,string(col1),string(col2)));

} /* ReportPage::MakeTwoCol */
//__________________________________________________

void ReportPage::PrintLineOf(const char ch, long length, long indent)
{

outf << MakeLineOf(ch,length,indent);

} /* ReportPage::PrintLineOf */

//__________________________________________________

void ReportPage::PrintBlankLine()
{

outf << MakeBlankLine();

} /* ReportPage::PrintBlankLine */

//__________________________________________________

void ReportPage::PrintSimpleRow(vector<long> &colwdth, 
   vector<string> &contents)
{

outf << MakeSimpleRow(colwdth,contents);

} /* ReportPage::PrintSimpleRow */

//__________________________________________________

void ReportPage::PrintTwoCol(const vector<long> &colwdth, const string &col1,
   const string &col2)
{

outf << MakeTwoCol(colwdth, col1, col2);

} /* ReportPage::PrintTwoCol */

//__________________________________________________

void ReportPage::PrintTwoCol(const vector<long> &colwdth, const char *col1,
   const string &col2)
{

outf << MakeTwoCol(colwdth, col1, col2);

} /* ReportPage::PrintTwoCol */

//__________________________________________________

void ReportPage::PrintTwoCol(const vector<long> &colwdth, const string &col1,
   const char *col2)
{

outf << MakeTwoCol(colwdth, col1, col2);

} /* ReportPage::PrintTwoCol */

//__________________________________________________

void ReportPage::PrintTwoCol(const vector<long> &colwdth, const char *col1,
   const char *col2)
{

outf << MakeTwoCol(colwdth, col1, col2);

} /* ReportPage::PrintTwoCol */

//__________________________________________________

void ReportPage::PrintPageBreak()
{

outf << "\n";

} /* ReportPage::PrintPageBreak */

//__________________________________________________

void ReportPage::Setup(vector<string> &title, long pglength,
   long pgwidth, char tdlm)
{

pagetitle = title;
titledlm = tdlm;
pagelength = pglength;
pagewidth = pgwidth;

} /* ReportPage::Setup */

//__________________________________________________

void ReportPage::Setup(string &title, long pglength,
   long pgwidth, char tdlm)
{
vector<string> title1;

title1.push_back(title);
pagetitle = title1;
titledlm = tdlm;
pagelength = pglength;
pagewidth = pgwidth;

} /* ReportPage::Setup */

//__________________________________________________

void ReportPage::Setup(const char *title, long pglength,
   long pgwidth, char tdlm)
{
vector<string> title1;
string chartitle(title);

title1.push_back(chartitle);
pagetitle = title1;
titledlm = tdlm;
pagelength = pglength;
pagewidth = pgwidth;

} /* ReportPage::Setup */

//__________________________________________________

vector<string> ReportPage::MakeTitle()
{
vector<string> title = pagetitle;
vector<string>::iterator sit;

// add linefeeds to the end of each element of title.
for(sit = title.begin(); sit != title.end(); ++sit)
   *sit += "\n";

// put title delimiter lines at begin and end of title
title.insert(title.begin(),MakeLineOf(titledlm,pagewidth));
title.push_back(MakeLineOf(titledlm,pagewidth));

return(title);

} /* ReportPage::MakeTitle */

//__________________________________________________

vector<string> ReportPage::MakeTableTitle(const string &title)
{
vector<string> titlelines;
titlelines.push_back(title+":\n");
titlelines.push_back(MakeLineOf('-',title.size()+1));

return(titlelines);

} /* ReportPage::MakeTableTitle */

//__________________________________________________

vector<string> ReportPage::MakeTableTitle(const char *title)
{

return(MakeTableTitle(string(title)));

} /* ReportPage::MakeTableTitle */

//__________________________________________________

void ReportPage::PrintTitle()
{

PrintLineOf(titledlm,pagewidth);
vector<string>::iterator sit;
for(sit = pagetitle.begin(); sit != pagetitle.end(); ++sit) {
   outf << *sit << "\n";
}
PrintLineOf(titledlm,pagewidth);

} /* ReportPage::PrintTitle */

//__________________________________________________

void ReportPage::PrintCenteredString(const string &str, long width,
   long indent, bool trunc)
{

string chunk = MakeCentered(str,width,indent,trunc);

outf << chunk;

} /* ReportPage::PrintCenteredString */

//__________________________________________________

void ReportPage::PrintCenteredString(const char *str, long width,
   long indent, bool trunc)
{
const string pstr(str);

PrintCenteredString(pstr,width,indent,trunc);

} /* ReportPage::PrintCenteredString */

//__________________________________________________

void ReportPage::PrintTableTitle(const string &title)
{
vector<string> titlelines = MakeTableTitle(title);
vector<string>::iterator tit;

for(tit = titlelines.begin(); tit != titlelines.end(); ++tit)
   outf << *tit;

} /* ReportPage::PrintTableTitle */

//__________________________________________________

void ReportPage::PrintTableTitle(const char *title)
{

PrintTableTitle(string(title));

} /* ReportPage::PrintTableTitle */

//__________________________________________________

string ReportPage::MakeSectionBreak(const char dlm, long width,
   long indent)
{

return(MakeLineOf(dlm,width,indent));

} /* ReportPage::PrintSectionBreak */

//__________________________________________________

void ReportPage::PrintSectionBreak(const char dlm, long width,
   long indent)
{

outf << MakeSectionBreak(dlm,width,indent);

} /* ReportPage::PrintSectionBreak */

//__________________________________________________

// colhdr is dimensioned: line
// rowhdr is dimensioned: section X row
// colwdth is dimensioned: col
// innards is dimensioned: section X row X col

vector<string> ReportPage::MakeTable(StringVec1d& colhdr, 
   StringVec2d& rowhdr, LongVec1d& colwdth, long indent,
   StringVec3d& innards)
{
StringVec1d table;
long hdrwdth = colwdth[0], hdrindent = indent;

long ncols = colwdth.size();
long totlength = 0;
for(long col = 0; col < ncols; ++col)
   totlength += colwdth[col];

vector<string>::iterator lit;
for(lit = colhdr.begin(); lit != colhdr.end(); ++lit)
   table.push_back(*lit);
//table.push_back(MakeLineOf('-',totlength));

long sect, nsect = innards.size(), sectindent=3;
for(sect = 0; sect < nsect; ++sect) {
   if (sect != 0) 
      table.push_back(MakeSectionBreak('-',totlength,sectindent));
   table.push_back(rowhdr[sect][0]+"\n");
   long line, nlines = rowhdr[sect].size();
   for(line = 1; line < nlines; ++line) {
      string tline;
      tline = MakeCentered(rowhdr[sect][line],hdrwdth,hdrindent);
      long col, ncols = innards[sect][line].size();
      for(col = 0; col < ncols; ++col) {
         tline += MakeCentered(innards[sect][line][col],colwdth[col+1]);
      }
      table.push_back(tline + "\n");
   }
}

table.push_back(MakeLineOf('-',totlength));

return(table);

} /* ReportPage::MakeTable */

//__________________________________________________


// colhdr is dimensioned: line
// rowhdr is dimensioned: section X row
// colwdth is dimensioned: col
// innards is dimensioned: section X row X col

void ReportPage::PrintTable(vector<string> &colhdr, StringVec2d &rowhdr,
   vector<long> &colwdth, long indent, StringVec3d &innards)
{
vector<string> table = MakeTable(colhdr,rowhdr,colwdth,indent,innards);
vector<string>::iterator line;

for(line = table.begin(); line != table.end(); ++line)
   outf << *line;

} /* ReportPage::PrintTable */

//__________________________________________________

double ReportPage::GetCentile(const vector<centilepair>& centiles,
   double pcent)
{

vector<centilepair>::const_iterator cent;
for(cent = centiles.begin(); cent != centiles.end(); ++cent) {
   if (!CloseEnough(cent->first, pcent)) continue;
   return cent->second;
}

assert(false);  // never found a needed centile!
return FLAGDOUBLE;

} /* ReportPage::GetCentile */

//__________________________________________________

void ReportPage::Show()
{

PrintTitle();
PrintPageBreak();

} /* ReportPage::Show */

//__________________________________________________
//__________________________________________________

MlePage::MlePage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth, long pgwdth)
: ReportPage(pf,reg,chpack,pglngth,pgwdth), hdrindent(3)
{

ncols = ((verbosity == CONCISE) ? 4 : 7);
npops = registry.GetDataPack().GetNPopulations();
colwidth.push_back(13);
long col;
for(col = 0; col < ncols-1; ++col)
   colwidth.push_back(11);

StringVec1d tmp;
if (verbosity == CONCISE) {
   tmp.push_back(string("0.025"));
   tmp.push_back(string("0.975"));
   collabels.push_back(tmp);
} else {
   tmp.push_back(string("0.005"));
   tmp.push_back(string("0.025"));
   tmp.push_back(string("0.05"));
   tmp.push_back(string("0.125"));
   tmp.push_back(string("0.25"));
   collabels.push_back(tmp);
   tmp.clear();
   tmp.push_back(string("0.75"));
   tmp.push_back(string("0.875"));
   tmp.push_back(string("0.95"));
   tmp.push_back(string("0.975"));
   tmp.push_back(string("0.995"));
   collabels.push_back(tmp);
}

} /* MlePage::MlePage */

//__________________________________________________

void MlePage::CopyMembers(const MlePage &src)
{
ReportPage::CopyAllMembers(src);

colwidth = src.colwidth;
npops = src.npops;
ncols = src.ncols;

} /* MlePage::CopyMembers */

//__________________________________________________

MlePage::MlePage(const MlePage &src)
: ReportPage(src.outf,src.registry,src.chainpack,src.pagelength,src.pagewidth),
   hdrindent(3)
{

CopyMembers(src);

} /* MlePage::MlePage */

//__________________________________________________

MlePage &MlePage::operator=(const MlePage &src)
{

CopyMembers(src);

return *this;

} /* MlePage::operator= */

//__________________________________________________

vector<string> MlePage::SetupColhdr(const Force &ftable, bool lowerpers)
{
string line, tmp;
vector<string> colhdr, axisname = ftable.GetAxisname();
proftype ptype = ftable.SummarizeProfTypes();

long hdrlength = 0, col;

if (ptype == none || ptype == fix) {
   colhdr.push_back(line);
} else {
   for(col = 2; col < ncols; ++col)
      hdrlength += colwidth[col];

   line.assign(colwidth[0]+colwidth[1],' ');
   if (verbosity != CONCISE)
      tmp += ((lowerpers) ? "Lower " : "Upper ");

   tmp += ((ptype == percentile) ? "percentiles\n" : "multipliers\n");
   line.append(MakeCentered(tmp,hdrlength));
   colhdr.push_back(line);
}

line = MakeJustified(axisname[0],-colwidth[0]);
line.append(MakeCentered(ftable.GetShortparmname(),colwidth[1]));
line.append(MakeLineOf('-',hdrlength));
colhdr.push_back(line);

bool oneregion = (registry.GetDataPack().GetNRegions() == 1);
line = ((verbosity == CONCISE || oneregion) ? MakeJustified(" ",-colwidth[0]) :
               "   " + MakeJustified(axisname[1],-(colwidth[0]-3)));
line += MakeCentered("Estimate",colwidth[1]);

if (ptype == percentile) {
   StringVec1d::iterator label = ((lowerpers) ? collabels[0].begin() :
                                                collabels[1].begin());
   for(col = 2; col < ncols; ++col, ++label)
      line += MakeCentered(*label,colwidth[col]);
   line += "\n";
   colhdr.push_back(line);
}

colhdr.push_back(MakeLineOf('-',colwidth[0]+colwidth[1]+hdrlength));

return(colhdr);

} /* MlePage::SetupColhdr */

//__________________________________________________

StringVec2d MlePage::SetupRowhdr(const Force &ftable)
{
const DataPack& datap = registry.GetDataPack();
bool oneregion = (datap.GetNRegions() == 1);
vector<string> secttitle = ftable.GetSectitle();
StringVec2d rowhdr;

long npopinsect, nsects = MAX(static_cast<long>(secttitle.size()),1L);
if (nsects > npops) {
   npopinsect = npops-1;
} else {
   npopinsect = 1;
}
long sect, sectcnt = npopinsect-1;
for(sect = 0; sect < nsects; ++sect) {
   vector<string> section;
   if (!secttitle.empty())
      section.push_back(secttitle[sect]);
   if (verbosity != CONCISE && !oneregion) {
      long reg, nregs = datap.GetNRegions();
      for(reg = 0; reg < nregs; ++reg) {
         section.push_back(datap.GetRegion(reg).GetRegionName());
      }
      section.push_back(string("Overall"));
   } else
      section.push_back(string(" "));
   if (sect == sectcnt) {
      sectcnt += npopinsect;
   }
   rowhdr.push_back(section);
}

return(rowhdr);

} /* MlePage::SetupRowhdr */
   
//__________________________________________________

StringVec3d MlePage::SetupInnards(const Force &ftable, bool lowerpers)
{
const DataPack& datap = registry.GetDataPack();
bool oneregion = (datap.GetNRegions() == 1);
DoubleVec2d mles = ftable.GetMles(); 
DoubleVec1d popmles = ftable.GetPopmles();
StringVec3d innards;
StringVec2d section;
bool allprofilesbad = false;

if (ftable.SummarizeProfTypes() != percentile) allprofilesbad = true;

const vector<Parameter>& parameters = ftable.GetParameters();
vector<Parameter>::const_iterator param;

DoubleVec1d modifiers = registry.GetForceSummary().GetModifiers();

// WARNING DEBUG This is not very flexible at the moment....
unsigned long nlowermodifiers = 5;

if (lowerpers)
   modifiers.erase(modifiers.begin()+nlowermodifiers,modifiers.end());
else
   modifiers.erase(modifiers.begin(),modifiers.begin()+nlowermodifiers+1);

long totlength = colwidth[0] + colwidth[1], col;
if (!allprofilesbad)
   for (col = 2; col < ncols; ++col)
      totlength += colwidth[col];

for (param = parameters.begin(); param != parameters.end(); ++param) {
  if (!(param->IsValid())) continue;  // no report on the invalid!
  proftype ptype = param->GetProfileType();
  StringVec1d tmp;
  section.push_back(tmp);
  if (verbosity != CONCISE) {    // for CONCISE we will do only overalls
    // regional MLEs and CIs
    long reg, nregs = datap.GetNRegions();
    for (reg = 0; reg < nregs; ++reg) {
      tmp.push_back(Pretty(param->GetMLE(reg),colwidth[1]-3));

      if (!allprofilesbad) {
         vector<centilepair> percentiles = param->GetCIs(reg);
         for (col = 2; col < ncols; ++col) {
            if (ptype == none) {
               tmp.push_back(MakeCentered("-",colwidth[col]));
               continue;
            }
            tmp.push_back(Pretty(GetCentile(percentiles,modifiers[col-2]),
                                 colwidth[col]-3));
         }
      }
      section.push_back(tmp);
      tmp.clear();
    }
  }
  // overall MLEs and CIs
  if (!oneregion) {
    tmp.push_back(Pretty(param->GetOverallMLE(),colwidth[1]-3));
    if (!allprofilesbad) {
      vector<centilepair> percentiles = param->GetOverallCIs();
      for (col = 2; col < ncols; ++col) {
         if (ptype == none) {
            tmp.push_back(MakeCentered("-",colwidth[col]));
            continue;
         }
         tmp.push_back(Pretty(GetCentile(percentiles,modifiers[col-2]),
                              colwidth[col]-3));
      }
    }
  }
  section.push_back(tmp);
  tmp.clear();

  // finish up the table
  section.push_back(tmp);
  if (param != parameters.end()-1) {
    string t;
    tmp.push_back(t);
    section.push_back(tmp);
  }
  innards.push_back(section);
  section.clear();
}

return(innards);

} /* MlePage::SetupInnards */

//__________________________________________________

void MlePage::Show()
{

// General Progam header goes here for now
   {
   long shortlinelength = 60;
   string line;

   PrintLineOf('*',shortlinelength);
   line.assign("LAMARC:  Maximum Likelihood Parameter Estimation\n");
   PrintCenteredString(line,shortlinelength);
   line.assign("using Hastings-Metropolis Markov Chain Monte Carlo\n");
   PrintCenteredString(line,shortlinelength);
   PrintLineOf('*',shortlinelength);
   outf << "version " << VERSION << "\n";
   PrintBlankLine();
   PrintBlankLine();
   line = "Program started on " + PrintTime(chainpack.GetStartTime(),"%c") 
           + "\n";
   PrintCenteredString(line,shortlinelength);
   line = "finished on " + PrintTime(chainpack.GetEndTime(),"%c") + "\n";
   PrintCenteredString(line,shortlinelength,3L);
   PrintBlankLine();
   }

// Begin actual MlePage output
PrintTitle();
PrintBlankLine();
PrintBlankLine();

// print a MLE table for each force
const ForceVec forces = registry.GetForceSummary().GetAllForces();
ForceVec::const_iterator fit;
for(fit = forces.begin(); fit != forces.end(); ++fit) {
   StringVec1d colhdr;
   StringVec2d rowhdr;
   StringVec3d innards;

   PrintTableTitle((*fit)->GetFullparmname());
   if (verbosity == CONCISE)
      outf << "only multi-region estimate shown\n" << endl;

   colhdr = SetupColhdr(**fit,true);
   rowhdr = SetupRowhdr(**fit);
   innards = SetupInnards(**fit,true);
   PrintTable(colhdr,rowhdr,colwidth,hdrindent,innards);

   if (verbosity != CONCISE && (*fit)->SummarizeProfTypes() == percentile) {
      PrintBlankLine(); 
      colhdr = SetupColhdr(**fit,false);
      rowhdr = SetupRowhdr(**fit);
      innards = SetupInnards(**fit,false);
      PrintTable(colhdr,rowhdr,colwidth,hdrindent,innards);
   }

   if ((*fit)->SummarizeProfTypes() == percentile && 
       (*fit)->AnyNoneProfTypes())
      outf << "a \"-\" means no value was computed" << endl;

   PrintBlankLine();
   PrintBlankLine();
}

PrintPageBreak();

} /* MlePage::Show */

//__________________________________________________
//__________________________________________________

ProfPage::ProfPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth, long pgwdth)
: ReportPage(pf,reg,chpack,pglngth,pgwdth)
{
colwidth.push_back(13);
colwidth.insert(colwidth.end(),6,11);
totalwidth = 79;

} /* ProfPage::constructor */

//__________________________________________________

ProfPage::ProfPage(const ProfPage& src)
: ReportPage(src.outf,src.registry,src.chainpack,src.pagelength,src.pagewidth)
{
CopyAllMembers(src);

} /* ProfPage::copy-constructor */

//__________________________________________________

void ProfPage::CopyAllMembers(const ProfPage& src)
{
ReportPage::CopyAllMembers(src);

colwidth = src.colwidth;
totalwidth = src.totalwidth;

} /* ProfPage::CopyAllMembers */

//__________________________________________________

ProfPage& ProfPage::operator=(const ProfPage& src)
{
CopyAllMembers(src);

return *this;

} /* ProfPage::operator= */

//__________________________________________________

StringVec1d ProfPage::SetupColhdr(const Parameter& param, bool lowerpers)
{
StringVec1d colhdr;

colhdr.push_back(MakeLineOf('-',totalwidth));
string tmp = ((lowerpers) ? "Lower" : "Upper");
tmp += (param.GetProfileType() == fix) ? " multipliers\n" : " percentiles\n";
colhdr.push_back(MakeCentered(tmp));

DoubleVec1d modifiers = registry.GetForceSummary().GetModifiers();
unsigned long nlowermodifiers = 5;
if (lowerpers)
   modifiers.erase(modifiers.begin()+nlowermodifiers,modifiers.end());
else
   modifiers.erase(modifiers.begin(),modifiers.begin()+nlowermodifiers+1);
tmp.assign(colwidth[0],' ');
if (!lowerpers) tmp += MakeCentered("MLE",colwidth[1]);
unsigned long mod, nmods = modifiers.size();
for(mod = 0; mod < nmods ; ++mod)
   tmp += MakeCentered(ToString(modifiers[mod]),colwidth[mod+1]);
if (lowerpers) tmp += MakeCentered("MLE",colwidth[1]);
tmp += "\n";
colhdr.push_back(tmp);

colhdr.push_back(MakeLineOf('-',totalwidth));

return colhdr;

} /* ProfPage::SetupColhdr */

//__________________________________________________

StringVec2d ProfPage::SetupRowhdr(const ParamVector& params,
   const Parameter& param)
{
StringVec2d rowhdr; // dim: section X row
StringVec1d section;

section.push_back("");
section.push_back("Ln(L)");
rowhdr.push_back(section);
section.clear();

section.push_back("");
section.push_back(param.GetShortName());
section.push_back(" ");
ParamVector::const_iterator par;
for(par = params.begin(); par != params.end(); ++par) {
   if (!par->IsValid() || param.GetShortName() == par->GetShortName())
      continue;
   section.push_back(par->GetShortName());
}
rowhdr.push_back(section);

return rowhdr;

} /* ProfPage::SetupRowhdr */

//__________________________________________________

// if numbers.empty() is true, then a line of single dashes will be
// made.
StringVec1d ProfPage::MakeInnardsLineFrom(const vector<centilepair>& numbers,
   const DoubleVec1d& modifiers)
{
StringVec1d line;
DoubleVec1d::const_iterator perc;
for(perc = modifiers.begin(); perc != modifiers.end(); ++perc)
   if (numbers.empty()) line.push_back("-");
   else line.push_back(Pretty(GetCentile(numbers,*perc),colwidth[1]-3));

return line;

} /* ProfPage::MakeInnardsLineFrom */

//__________________________________________________

StringVec3d ProfPage::SetupInnards(const ParamVector& params, 
   unsigned long pindex, long region, bool lowerpers)
{
StringVec3d innards; // dim: section X row X col
StringVec2d section;
StringVec1d row;

const ForceSummary& fs = registry.GetForceSummary();
DoubleVec1d modifiers = fs.GetModifiers();
const long nlowermodifiers = 5;
if (lowerpers)
   modifiers.erase(modifiers.begin()+nlowermodifiers,modifiers.end());
else
   modifiers.erase(modifiers.begin(),modifiers.begin()+nlowermodifiers+1);

const Parameter param = params[pindex];

section.push_back(row);  // a blank row for section titles

if (region == FLAGLONG)
   row = MakeInnardsLineFrom(param.GetOverallPriorLikes(),modifiers);
else
   row = MakeInnardsLineFrom(param.GetPriorLikes(region),modifiers);

double mlelike = ((region != FLAGLONG) ? fs.GetLlikeMle(region) : 
                             fs.GetOverallLlikeMle());
if (lowerpers) row.push_back(Pretty(mlelike,colwidth[1]-3));
else row.insert(row.begin(),Pretty(mlelike,colwidth[1]-3));
section.push_back(row);
innards.push_back(section);
section.clear();

row.clear();
section.push_back(row);  // a blank row for section titles

vector<vector<centilepair> > 
   centiles = ((region != FLAGLONG) ? param.GetProfiles(region) :
                                      param.GetOverallProfile());
// print the fixed variable
row = MakeInnardsLineFrom(centiles[pindex],modifiers);
double mle = ((region != FLAGLONG) ? param.GetMLE(region) : 
                                     param.GetOverallMLE());
if (lowerpers) row.push_back(Pretty(mle,colwidth[1]-3));
else row.insert(row.begin(),Pretty(mle,colwidth[1]-3));
section.push_back(row);
// print a blank line
row.clear();
section.push_back(row);

unsigned long whichparam, nparams = params.size();
for(whichparam = 0; whichparam < nparams; ++whichparam) {
   if (whichparam == pindex || !params[whichparam].IsValid()) continue;
   row = MakeInnardsLineFrom(centiles[whichparam],modifiers);
   double mle = ((region != FLAGLONG) ? params[whichparam].GetMLE(region) : 
                                        params[whichparam].GetOverallMLE());
   if (lowerpers) row.push_back(Pretty(mle,colwidth[1]-3));
   else row.insert(row.begin(),Pretty(mle,colwidth[1]-3));
   section.push_back(row);
}
innards.push_back(section);

return innards;

} /* ProfPage::SetupInnards */

//__________________________________________________

// "region" is zero if the overall profiles are being asked for
// "region" is the region number, numbering from one, of the region
//    being profiled.
void ProfPage::DisplayParameters(const ParamVector& params, long region)
{
unsigned long pindex, nparams = params.size();
for(pindex = 0; pindex < nparams; ++pindex) {
   const Parameter param = params[pindex];
   if (!param.IsValid() || param.GetProfileType() == none) continue;
   string line = ((region == FLAGLONG) ? "Overall" :
                  registry.GetDataPack().GetRegion(region).GetRegionName());
   line += ": " + param.GetName() + " (" + param.GetShortName() + ")";
   PrintTableTitle(line);
   outf << "Parameters are evaluated at ";
   outf << ((param.GetProfileType() == fix) ?
           "fixed points" : "percentiles");
   outf << endl;

   // print the lower percentile table
   StringVec1d colhdr = SetupColhdr(param,true);
   StringVec2d rowhdr = SetupRowhdr(params,param);
   StringVec3d innards = SetupInnards(params,pindex,region,true);
   PrintTable(colhdr,rowhdr,colwidth,0L,innards);

   // print the upper percentile table
   colhdr = SetupColhdr(param,false);
   rowhdr = SetupRowhdr(params,param);
   innards = SetupInnards(params,pindex,region,false);
   PrintTable(colhdr,rowhdr,colwidth,0L,innards);

   PrintBlankLine();
   PrintBlankLine();
}

} /* ProfPage::DisplayParameters */

//__________________________________________________

void ProfPage::Show()
{
const ForceSummary& forcesummary = registry.GetForceSummary();
const ParamVector params(forcesummary,true);

if (params.GetAllProfileTypes() == none) return;

PrintTitle();
PrintBlankLine();
// outf << "Parameters are evaluated assuming complete independence.";
outf << endl << "The first listed parameter is the ";
outf << "parameter held constant." << endl;
PrintBlankLine();

PrintLineOf('=');
outf << MakeCentered("Overall Profile Tables") << endl;
PrintLineOf('=');
PrintBlankLine();

DisplayParameters(params,FLAGLONG); // print the overall profiles

if (verbosity == VERBOSE) {
   PrintLineOf('=');
   outf << MakeCentered("Regional Profile Tables") << endl;
   PrintLineOf('=');
   PrintBlankLine();
   long region, nregions = registry.GetDataPack().GetNRegions();
   for(region = 0; region < nregions; ++region) {
      PrintBlankLine(); 
      outf << "****** Estimates for region ";
      outf << registry.GetDataPack().GetRegion(region).GetRegionName();
      outf << "******" << endl << endl;
      DisplayParameters(params,region);
   }
}

PrintPageBreak();

} /* ProfPage::Show */

//__________________________________________________
//__________________________________________________

UsrPage::UsrPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
    long pglngth, long pgwdth)
: ReportPage(pf,reg,chpack,pglngth,pgwdth)
{

npops = registry.GetDataPack().GetNPopulations();

} /* UsrPage::UsrPage */

//__________________________________________________

void UsrPage::CopyMembers(const UsrPage &src)
{
ReportPage::CopyAllMembers(src);

npops = src.npops;
colwidth = src.colwidth;

} /* UsrPage::CopyMembers */

//__________________________________________________

UsrPage::UsrPage(const UsrPage &src)
: ReportPage(src.outf,src.registry,src.chainpack,src.pagelength,src.pagewidth)
{

CopyMembers(src);

} /* UsrPage::UsrPage */

//__________________________________________________

UsrPage &UsrPage::operator=(const UsrPage &src)
{

CopyMembers(src);

return *this;

} /* UsrPage::UsrPage */

//__________________________________________________

void UsrPage::Show()
{
const ForceSummary& forcesum = registry.GetForceSummary();
vector<string>::iterator sit;

PrintTitle();
PrintBlankLine();

string line = "Force specific options";
PrintTableTitle(line);

if (verbosity != CONCISE) {
   outf << "Starting Parameters:\n";
   PrintBlankLine();

   const ForceVec forces = forcesum.GetAllForces();
   ForceVec::const_iterator fit;
   for(fit = forces.begin(); fit != forces.end(); ++fit) {
      vector<string> str = Linewrap(
                           (*fit)->MakeStartParamReport(),pagewidth);

      for(sit = str.begin(); sit != str.end(); ++sit)
         outf << sit->c_str() << endl;
      PrintBlankLine();
   }
   PrintBlankLine();
}


#if 0
// not until migration models are added -- held over to V2
long npops = registry.GetDataPack().GetNPopulations();
if (npops > 1) { 
   // vector<string> migmodel = forcesum.GetMigModel();
   // string migmodelname = forcesum.GetMigModelName();
   // outf << "Migration Model: "+migmodelname << endl;
   // if (!migmodelname.compare("user")) {
      /* DEBUG debug warning WARNING -- unfinished? */
   // }
}
#endif

const ChainParameters& chainparms = registry.GetChainParameters();
PrintBlankLine();
PrintBlankLine();
line.assign("Search Strategy");
PrintTableTitle(line);
outf << "Markov Chain Parameters:\n";
colwidth.clear();
colwidth.push_back(18);
colwidth.push_back(16);
colwidth.push_back(16);
vector<string> strvec;
strvec.push_back(" ");
strvec.push_back("Initial");
strvec.push_back("Final");
PrintSimpleRow(colwidth,strvec);
strvec.clear();
strvec.push_back("Number of Chains");
strvec.push_back(ToString(chainparms.GetNChains(0)));
strvec.push_back(ToString(chainparms.GetNChains(1)));
PrintSimpleRow(colwidth,strvec);
strvec.clear();
strvec.push_back("Trees Sampled");
strvec.push_back(ToString(chainparms.GetNSamples(0)));
strvec.push_back(ToString(chainparms.GetNSamples(1)));
PrintSimpleRow(colwidth,strvec);
strvec.clear();
strvec.push_back("Sampling Increment");
strvec.push_back(ToString(chainparms.GetInterval(0)));
strvec.push_back(ToString(chainparms.GetInterval(1)));
PrintSimpleRow(colwidth,strvec);
strvec.clear();
strvec.push_back("Trees Discarded");
strvec.push_back(ToString(chainparms.GetNDiscard(0)));
strvec.push_back(ToString(chainparms.GetNDiscard(1)));
PrintSimpleRow(colwidth,strvec);
PrintBlankLine();

// all remaining entries are 2 column entries with this format
colwidth.clear();
colwidth.push_back(30);
colwidth.push_back(20);

DoubleVec1d chtemps = chainparms.GetAllTemperatures();
long temp, ntemps = chtemps.size();
if (ntemps > 1) {
   line.erase();
   for (temp = 0; temp < ntemps; ++temp) {
      line += " "+ToString(chtemps[temp]);
      if (temp == ntemps-1) continue;
      if (temp == ntemps-2) {
         line += " and";
         continue;
      }
      line += ',';
   }
   PrintTwoCol(colwidth,"Chain Temperatures",line);
}
/* WARNING warning -- No haplotype model interface stuff yet
line.assign(iobag.GetHapmodel());
if (line != "none") {
   PrintTwoCol(colwidth,"Haplotype rearrangement",line);
}
*/
const UserParameters& userparms = registry.GetUserParameters();
line = ToString(userparms.GetRandomSeed());
PrintTwoCol(colwidth,"Random number seed",line);
PrintBlankLine();
PrintBlankLine();

if (verbosity != CONCISE) {
   PrintTableTitle("File options");
#if 0 // no reporting of program settings file(s) till V2
   vector<string> fnames;
   if (!(userparms.GetParamFileName().empty()))
      fnames.push_back(userparms.GetParamFileName());
   if (!(userparms.GetDataFileName().empty()))
      fnames.push_back(userparms.GetDataFileName());
   if (!(fnames.empty())) {
      line.assign("Read settings from file");
      if (fnames.size() > 1)
         line += 's';
      line += ':';
      string line2;
      for(sit = fnames.begin(); sit != fnames.end(); ++sit)
         line2 += ' '+(*sit);
      PrintTwoCol(colwidth,line,line2);
   }
#endif
   line.assign("Read data from file:");
   PrintTwoCol(colwidth,line,userparms.GetDataFileName());
#if 0 // debug DEBUG -- delay til version 2
   line.assign(userparms.GetTreeSumFileName());
   if (!(line.empty())) {
      line = "Yes, in "+line;
      PrintTwoCol(colwidth,"Saved data for later analysis?",line);
   }
#endif
   PrintBlankLine();
   PrintBlankLine();
   
   PrintTableTitle("Output summary options");
   line = ((userparms.GetEchoData()) ? "Yes" : "No");
   PrintTwoCol(colwidth,"Echo data?",line);

   ParamVector paramvec(registry.GetForceSummary());
#if 0 // no plotting of likelihood curves yet, 2001/11/12
   paramlistcondition test = paramvec.CheckCalcPProfiles();
   line = (test==NO ? "No" : "Yes");
   PrintTwoCol(colwidth, "Plot likelihood curves?", line);
#endif
   paramlistcondition test = paramvec.CheckCalcProfiles();
   line = (test==NO ? "None" : 
           ((paramvec.GetAllProfileTypes()==fix) ? "Fixed" : "Percentile")
          );
   PrintTwoCol(colwidth, "Calculate profile likelihoods?", line);
}

PrintPageBreak();

} /* UsrPage::Show */

//__________________________________________________
//__________________________________________________

DataPage::DataPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth, long pgwdth)
: ReportPage(pf,reg,chpack,pglngth,pgwdth), 
  table1(1), table2(2)
{

npops = reg.GetDataPack().GetNPopulations();

} /* DataPage::DataPage */

//__________________________________________________

void DataPage::CopyMembers(const DataPage &src)
{
ReportPage::CopyAllMembers(src);

npops = src.npops;
colwidth = src.colwidth;

} /* DataPage::CopyMembers */

//__________________________________________________

DataPage::DataPage(const DataPage &src)
: ReportPage(src.outf,src.registry,src.chainpack,src.pagelength,src.pagewidth),
   table1(1), table2(2)
{

CopyMembers(src);

} /* DataPage::DataPage */

//__________________________________________________

DataPage &DataPage::operator=(const DataPage &src)
{

CopyMembers(src);

return *this;

} /* DataPage::DataPage */

//__________________________________________________

vector<string> DataPage::SetupColhdr(long whichtable)
{
long totlength=0;
string line;
vector<string> hdr;
vector<long>::iterator lit;

for(lit = colwidth.begin(); lit != colwidth.end(); ++lit)
   totlength += *lit;

/* loci omitted for 1st release--column headers are wrong!
if (whichtable == table1) {
   line = MakeCentered("Population\n",totlength);
   hdr.push_back(line);
   line = "Region";
   line.append(colwidth[0]-line.size(),' ');
   long pop;
   string line2;
   for(pop = 0; pop < npops; ++pop) {
      line2.append(MakeCentered(ToString(pop+1),colwidth[pop+1]));
   }
   line += line2+"\n";
   hdr.push_back(line);
}
*/

if (whichtable == table2) {
   line = MakeJustified("Population",-1*colwidth[0]);
   line += MakeCentered("Variable",colwidth[1]);
   line += MakeCentered("Relative",colwidth[2]);
   line += MakeCentered("Relative",colwidth[2]);
   line += MakeCentered("Pairwise",colwidth[3]);
   line += MakeCentered("Sample",colwidth[4]);
   line += "\n";
   hdr.push_back(line);
   line = "   ";
   line += MakeJustified("Region",-1*(colwidth[0]-3));
   line += MakeCentered("markers",colwidth[1]);
   line += MakeCentered("Ne",colwidth[2]);
   line += MakeCentered("rec rate",colwidth[2]);
   line += MakeCentered("theta",colwidth[3]);
   line += MakeCentered("size",colwidth[4]);
   line += "\n";
   hdr.push_back(line);
}

return(hdr);

} /* DataPage::SetupColhdr */

//__________________________________________________

StringVec2d DataPage::SetupRowhdr(long whichtable)
{
const DataPack& datap = registry.GetDataPack();
long nreg = datap.GetNRegions(), totlength = 0;
string line;
vector<string> vecline;
StringVec2d hdr;
vector<long>::iterator lit;

for(lit = colwidth.begin(); lit != colwidth.end(); ++lit)
   totlength += *lit;

#if 0
/* DEBUG debug No loci for 1st release -- hold to V2 */
if (whichtable == table1) {
   LongVec1d locreg = iobag.GetLociregion(); // changed to 1d vector
   long reg;
   for(reg = 0; reg < nreg; ++reg) {
      vecline.clear();
      vecline.push_back(ToString(reg+1));
      long loc;
      for(loc = 1; loc < locreg[reg]; ++loc)
         vecline.push_back(" ");
      }
      hdr.push_back(vecline);
   }
}
#endif

if (whichtable == table2) {
   vector<string> popn = datap.GetPopulationNames();
   long pop, reg;
   for(pop = 0; pop < npops; ++pop) {
      vecline.clear();
      line = ToString(pop+1)+" "+popn[pop];
      vecline.push_back(line);
      for(reg = 0; reg < nreg; ++reg) {
         line = ToString(reg+1)+" "+datap.GetRegion(reg).GetRegionName();
         vecline.push_back(line);
      }
      hdr.push_back(vecline);
   }
}

return(hdr);

} /* DataPage::SetupRowhdr */

//__________________________________________________

StringVec3d DataPage::SetupInnards(long whichtable)
{
string tmp;
vector<string> line;
StringVec2d line2;
StringVec3d innards;

#if 0
/* No loci for 1st release */
if (whichtable == table1) {
   LongVec1d locreg = iobag.GetLociregion(); // changed to 1d vector
   StringVec1d locn = iobag.GetLocusname();  // changed to 1d vector
   long reg, nreg = iobag.GetNumreg();
   for(reg = 0; reg < nreg; ++reg) {
      line2.clear();
      long loc;
      for(loc = 0; loc < locreg[reg]; ++loc) {
         tmp = ToString(loc+1)+" ("+locn[loc]+")";
         line.push_back(tmp);
         line.push_back(/* locus datatype goes here*/"SQUIB");
         line.push_back(/* relative murate goes here*/"100.01");
         line2.push_back(line);
         line.clear();
      }
      innards.push_back(line2);
      line2.clear();
      line2.push_back(line);
      innards.push_back(line2);
   }
}
#endif

if (whichtable == table2) {
   const DataPack& datapack = registry.GetDataPack();
   long pop, reg, nreg = datapack.GetNRegions();
   for(pop = 0; pop < npops; ++pop) {
      line2.clear();
      line2.push_back(line);
      for(reg = 0; reg < nreg; ++reg) {
         const Region& regs = datapack.GetRegion(reg);
         DoubleVec1d qtheta = regs.regiontheta.GetThetas();
         line.push_back(ToString((regs.CalcNVariableMarkers())[pop]));
         line.push_back(/* region relative Ne goes here */"1.0"); 
         line.push_back(/* region relative rec-rate goes here*/"1.0");
         line.push_back(ToString(qtheta[pop]));
         line.push_back(ToString(regs.GetNTips(pop)));
         // line.push_back(ToString(regs.GetNIndividuals()));
         line2.push_back(line);
         line.clear();
      }
      innards.push_back(line2);
   }
}

return(innards);

} /* DataPage::SetupInnards */

//__________________________________________________

void DataPage::Show()
{
const DataPack& datapack = registry.GetDataPack();
long nreg = datapack.GetNRegions();
// long nloci = iobag.GetNumloci();

PrintTitle();
PrintBlankLine();

if (verbosity != CONCISE) {
   colwidth.clear();
   colwidth.push_back(22);
   colwidth.push_back(38);
   string line = ToString(npops);
   PrintTwoCol(colwidth,"Number of populations:",line);
   line = ToString(nreg);
   PrintTwoCol(colwidth,"Number of regions:",line);
   //line = ToString(nloci);  No loci in 1st release
   //PrintTwoCol(colwidth,"Number of loci:",line);
   colwidth.clear();
   colwidth.push_back(42);
   colwidth.push_back(18);
   line = "Total number of samples in all regions";
   long totindiv = 0;
   long pop;
   for(pop = 0; pop < npops; ++pop) {
      long reg;
      for(reg = 0; reg < nreg; ++reg) {
         totindiv += datapack.GetRegion(reg).GetNTips(pop);
      }
   }
   string line1 = ToString(totindiv);
   PrintTwoCol(colwidth,line,line1);
   PrintBlankLine();
   PrintBlankLine();
   
   /* no loci in 1st release version
   PrintTableTitle("Linked-loci by region and population");
   colwidth.clear();
   colwidth.push_back(6);
   for(pop = 0; pop < npops; ++pop)
      colwidth.push_back(18);
   vector<string> colhdr = SetupColhdr(table1);
   StringVec2d rowhdr = SetupRowhdr(datapack,table1);
   StringVec3d innards = SetupInnards(table1);
   long hdrindent=0;
   PrintTable(colhdr,rowhdr,colwidth,hdrindent,innards);
   PrintBlankLine();
   PrintBlankLine();
   */
   
   PrintTableTitle("Region summary");
   colwidth.clear();
   colwidth.push_back(15); // col for names
   colwidth.push_back(10); // col for # variable sites
   colwidth.push_back(10); // col for relative population size
   colwidth.push_back(10); // col for relative recombination rate
   colwidth.push_back(10); // col for simple theta value
   colwidth.push_back(10); // col for # of individuals
   vector<string> colhdr = SetupColhdr(table2);
   StringVec2d rowhdr = SetupRowhdr(table2);
   StringVec3d innards = SetupInnards(table2);
   long hdrindent = 3;
   PrintTable(colhdr,rowhdr,colwidth,hdrindent,innards);
   PrintBlankLine();
   PrintBlankLine();
   
   PrintTableTitle("Summary of Data Model Parameters");
   PrintBlankLine();
   PrintLineOf('-');
   long reg;
   for(reg = 0; reg < nreg; ++reg) {
      const Region& region = datapack.GetRegion(reg);
      const DataModel_ptr datamodel = region.datamodel;
      vector<string> out = datamodel->CreateDataModelReport();
      vector<string>::iterator sit;
      PrintBlankLine();
      outf << "Parameters of a " + datamodel->GetDataModelName();
      outf << " model for the " + region.GetRegionName() << " region";
      outf << endl;
      for(sit = out.begin(); sit != out.end(); ++sit)
         outf << (*sit).c_str() << endl;
      PrintLineOf('-');
   }
}

bool echodata = registry.GetUserParameters().GetEchoData();

if (echodata) {
   const unsigned long basesperline = 60;
   PrintBlankLine();
   outf << "Input Genetic Data" << endl;
   long reg, nregs = datapack.GetNRegions();
   for(reg = 0; reg < nregs; ++reg) {
      PrintLineOf('-');
      const Region& region = datapack.GetRegion(reg);
      outf << "   For the " << region.GetRegionName() << " region" << endl;
      PrintLineOf('-');
      long tip, ntips = region.GetNTips();
      StringVec1d geneticdata;
      string outstring;
      for(tip = 0; tip < ntips; ++tip) {
         string dlm = region.datatype->GetDelimiter();
         geneticdata.push_back(region.GetTipData(tip).GetFormattedData(dlm));
         string datalabel = MakeJustified(region.GetTipData(tip).label,-10);
         outf << "      " << datalabel << " ";
         outf << geneticdata[tip].substr(0,basesperline) << endl;
         if (geneticdata[tip].size() > basesperline) {
           string subtip = geneticdata[tip].substr(basesperline);
           geneticdata[tip] = subtip; 
         } else {
           geneticdata[tip].erase();
         }
      }
      PrintBlankLine();
// WARNING warning -- use of [0] assumes all data are same length
      while (geneticdata[0].size() > basesperline) {
         for(tip = 0; tip < ntips; ++tip) {
            outf << "      " << geneticdata[tip].substr(0,basesperline);
            outf << endl;
            if (basesperline < geneticdata[tip].size()) {
              string subtip = geneticdata[tip].substr(basesperline);
              geneticdata[tip] = subtip; 
            }
         }
         PrintBlankLine();
      }
// WARNING warning -- use of [0] assumes all data are same length
      if (!geneticdata[0].empty())
         for(tip = 0; tip < ntips; ++tip)
            outf << "      " << geneticdata[tip] << endl;
   }
   PrintLineOf('-');
}

PrintPageBreak();

} /* DataPage::Show */

//__________________________________________________
//__________________________________________________

RunPage::RunPage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth, long pgwdth)
: ReportPage(pf,reg,chpack,pglngth,pgwdth)
{

} /* RunPage::RunPage */

//__________________________________________________

void RunPage::CopyMembers(const RunPage &src)
{
ReportPage::CopyAllMembers(src);

colwidth = src.colwidth;

} /* RunPage::CopyMembers */

//__________________________________________________

RunPage::RunPage(const RunPage &src)
: ReportPage(src.outf,src.registry,src.chainpack,src.pagelength,src.pagewidth)
{

CopyMembers(src);

} /* RunPage::RunPage */

//__________________________________________________

RunPage &RunPage::operator=(const RunPage &src)
{

CopyMembers(src);

return *this;

} /* RunPage::RunPage */

//__________________________________________________

void RunPage::Show()
{
const DataPack& datapack = registry.GetDataPack();
const ChainParameters& chainparms = registry.GetChainParameters();
const RunReport& runreport = registry.GetRunReport();

long nregs = datapack.GetNRegions();
long totchains = chainparms.GetNChains(0) + chainparms.GetNChains(1);

PrintTitle();
PrintBlankLine();
outf << "\"Accepted\" is the observed rate at which any change ";
outf << "to the proposal\ntrees ";
bool multitemps = (((chainparms.GetAllTemperatures()).size() > 1) ? true : false);
if (multitemps)
   outf << "in the coldest chain ";
outf << "was accepted.\n";

StringVec1d chainreport;
long chain, reg, rep;
unsigned long line;
long nreps = chainparms.GetNReps();
bool initialchains;

for(reg = 0; reg < nregs; ++reg) {
  if (nregs > 1) {
    outf << "\nRegion " << reg + 1 << ": ";
    outf << datapack.GetRegion(reg).GetRegionName() << "\n"; 
  }
  for (rep = 0; rep < nreps; ++rep) { 
     if (nreps > 1) outf << "Replicate " << rep + 1 << "\n";
     for (chain = 0; chain < totchains; ++chain) {
        ChainOut chout = chainpack.GetChain(reg, rep, chain);
        runreport.MakeReport(chout);
        chainreport = runreport.FormatReport(chout, false, pagewidth);
        initialchains = (chain < chainparms.GetNChains(0));
        if (initialchains) outf << "Initial ";
        else outf << "Final ";
        outf << "Chain " << chain+1 << "\n";
        for (line = 0; line < chainreport.size(); ++line) {
          outf << chainreport[line] << "\n";
        }
        PrintBlankLine();
     }
  }
}

PrintPageBreak();

} /* RunPage::Show */

//__________________________________________________
//__________________________________________________

LikePage::LikePage(ofstream& pf, const Registry& reg, const ChainPack& chpack,
   long pglngth, long pgwdth)
: ReportPage(pf,reg,chpack,pglngth,pgwdth)
{

} /* LikePage::LikePage */

//__________________________________________________

void LikePage::CopyMembers(const LikePage &src)
{
ReportPage::CopyAllMembers(src);

} /* LikePage::CopyMembers */

//__________________________________________________

LikePage::LikePage(const LikePage &src)
: ReportPage(src.outf,src.registry,src.chainpack,src.pagelength,src.pagewidth)
{

CopyMembers(src);

} /* LikePage::LikePage */

//__________________________________________________

LikePage &LikePage::operator=(const LikePage &src)
{

CopyMembers(src);

return *this;

} /* LikePage::LikePage */

//__________________________________________________

vector<string> LikePage::MakeInnards(const DoubleVec2d& likes)
{
  typedef pair<double, string> sympair;

  long x, y;
  double maxlike = likes[0][0];

  // find highest value in table
  for (x = 0; x < (long) likes.size(); ++x) {
    for (y = 0; y < (long) likes[x].size(); ++y) {
      if (likes[x][y] > maxlike) maxlike = likes[x][y];
    }
  }

  // establish critical values
  long i;
  vector<sympair> critvalues;

  critvalues.push_back(sympair(maxlike, string("X")));
  critvalues.push_back(sympair(maxlike - DF, string("*")));
  critvalues.push_back(sympair(maxlike - 2*DF, string("+")));
  critvalues.push_back(sympair(maxlike - 3*DF, string("-")));
  critvalues.push_back(sympair(NEG_MAX, string(" ")));

  // fill up table with symbols

  StringVec1d innards;
  string line;

  for (x = 0; x < (long) likes.size(); ++x) {
    for (y = 0; y < (long) likes[x].size(); ++y) {
      for (i = 0; i < (long) critvalues.size(); ++i) {
        if (likes[x][y] >= critvalues[i].first) {
          line += critvalues[i].second;
          break;
        }
      }
    }
    innards.push_back(line);
    line.erase();
  }

  return(innards);

} /* LikePage::MakeInnards */

//__________________________________________________

StringVec1d LikePage::MakeLikePlot(const StringVec1d& innards, const
  Parameter& parmX, const Parameter& parmY, long breaks)
{

  StringVec1d plot;
#if 0
  // not till V2
  string line;
  long v, x, y;
  long linelength = 4 + parmX.plotpoints;

// make figure legplotend
// header lines
  line = "          X Axis    Y Axis";
  plot.push_back(Pretty(line, linelength));
  line = Pretty("    Tick",10);
  line += Pretty(parmX.name, 10);
  line += Pretty(parmY.name, 10);
  plot.push_back(Pretty(line, linelength));

  line = "          ";
  if (parmX.style == log_ten) line += "(log10)   ";
  else line += "(linear)  ";

  if (parmY.style == log_ten) line += "(log10)   ";
  else line += "(linear)  ";
  plot.push_back(Pretty(line, linelength));

// value lines
  double val;
  long xvals = parmX.plotpoints/breaks;
  long yvals = parmY.plotpoints/breaks;
  long maxvals;
  if (xvals > yvals) maxvals = xvals;
  else maxvals = yvals;

  for (v = 0; v < maxvals; ++v) {
    line = Pretty(v+1L);
    if (v <= xvals) {    // print x values
      val = parmX.plotstart +
        (double)v * (parmX.plotend - parmX.plotstart) / (double) parmX.plotpoints;
      if (parmX.style == log_ten) val = pow(10.0, val);
      line += "  " + Pretty(val);
    } else line += "          ";
    if (v <= yvals) {    // print y values
      val = parmY.plotstart +
        (double)v * (parmY.plotend - parmY.plotstart) / (double) parmY.plotpoints;
      if (parmY.style == log_ten) val = pow(10.0, val);
      line += "  " + Pretty(val);
    } else line += "          ";
    plot.push_back(Pretty(line, linelength));
  }

  line.erase();

// make actual figure
  plot.push_back(MakeBorder(parmX.plotpoints));
  for (x = 0; x < (long) innards.size(); ++x) {
    if (Divides(x+1, breaks)) line += ToString(breaks/parmY.plotpoints - x + 1) + " +";
    else line += "  |";
    for (y = 0; y < (long) innards[x].size(); ++y) {
      line += innards[x][y];
    }
    if (Divides(x+1, breaks)) line += "+";
    else line += "|";
    plot.push_back(line);
    line.erase();
  }
  plot.push_back(MakeBorder(parmX.plotpoints));
  line.erase();
  for (x = 0; x < parmX.plotpoints; ++x) {
    if (Divides(x+1, breaks)) line += ToString(x+1);
    else line += " ";
  }
  plot.push_back(line);
#endif
  return(plot);

}  /* LikePage::MakeLikePlot */

//__________________________________________________

bool LikePage::Divides(long x, long y) {
  return (x/y * y == x);
} /* LikePage::Divides */

//__________________________________________________

string LikePage::MakeBorder(long points, long breaks) {
 
  string line;
  long i;
  line += "+";                            // left border
  for (i = 0; i < points; ++i) {
    if (Divides(i+1, breaks)) line += "+";
    else line += "-";
  }

  line += "+";                            // right border
  return(line);
 
} /* LikePage::MakeBorder */

//__________________________________________________

DoubleVec2d LikePage::AddGraphs(const DoubleVec2d& a, const
  DoubleVec2d& b)
{
  // Find highest value in either graph
  assert(a.size() == b.size());
  assert(a[0].size() == b[0].size()); // can't add graphs of different sizes

  double maxlike = a[0][0];
  long i, j;
  for (i = 0; i < (long) a.size(); ++i) {
    for (j = 0; j < (long) a[0].size(); ++j) {
      if (a[i][j] > maxlike) maxlike = a[i][j];
      if (b[i][j] > maxlike) maxlike = b[i][j];
    }
  }

  DoubleVec2d newgraph;
  DoubleVec1d newline;
  double aval, bval, newval = 0.0;

  // Normalize all values to the maximum
  for (i = 0; i < (long) a.size(); ++i) {
    for (j = 0; j < (long) a.size(); ++j) {
      aval = a[i][j] - maxlike;
      bval = b[i][j] - maxlike;
      if (aval > EXP_MIN) newval += exp(aval);
      if (bval > EXP_MIN) newval += exp(bval);
      if (newval != 0) newline.push_back(log(newval));
      else newline.push_back(EXP_MIN);
      newval = 0.0;
    }
    newgraph.push_back(newline);
    newline.clear();
  }
  return(newgraph);

} /* LikePage::AddGraphs */

//__________________________________________________

bool LikePage::EmptyPlot(PlotStruct& plot)
{

return(plot.plane.empty());

} /* LikePage::EmptyPlot */

//__________________________________________________

void LikePage::Show()
{

#if 0    // DEBUG !!  not till V2
PrintTitle();
PrintBlankLine();

ParamVector parameters(registry.GetForceSummary());

// DEBUG vector<PlotStruct> plots = registry.GetPostoutPack().GetPriorgraphs();

ParamVector::iterator pit;

for(pit = parameters.begin(); pit != parameters.end(); ++pit) {
   if (!(pit->IsValid())) continue;

   DoubleVec2d data = pit->plane;
   Parameter& xaxis = *(pit->xaxis);
   Parameter& yaxis = *(pit->yaxis);
   bool twoplots = false;
   StringVec1d innards = MakeInnards(data);
   StringVec1d plot = MakeLikePlot(innards, xaxis, yaxis);
   StringVec1d plot2;

   ++pit;
   if (pit != plots.end()) {
      data = pit->plane;
      innards = MakeInnards(data);
      plot2 = MakeLikePlot(innards, xaxis, yaxis);
      twoplots = true;
   }

   if (twoplots) {
      long line;
      for (line = 0; line < (long)plot.size(); ++line)
         cout << plot[line] << "  " << plot2[line] << endl;
    } else {
      long line;
      for (line = 0; line < (long)plot.size(); ++line)
         cout << plot[line] << endl;
    }
}

PrintPageBreak();

#endif

} /* LikePage::Show */

//__________________________________________________
