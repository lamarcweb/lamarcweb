// $Id: runreport.cpp,v 1.7 2002/06/25 03:17:51 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "runreport.h"
#include "chainout.h"
#include "chainpack.h"
#include "force.h"
#include "forcesummary.h"
#include "types.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

/****************************************************************
   This function predicts the end of the chain process, given
   the number of steps so far and the total required number of 
   steps.  It is meant to be called by the chain manager. 
*****************************************************************/
void RunReport::Prognose(const ChainPack& chpack, long steps, long total)
{

if (level == CONCISE || level == NONE) return;

string timestr;

#ifdef NOTIME_FUNC
// system does not provide a clock so no prognosis can be made
  timestr = "unknown";
#else
  time_t tnow = GetTime();
  time_t tstart = chpack.GetStartTime();   // start of the whole thing
  if (steps == 0) timestr = "unknown";
  else {
    double proportion = double(total) / double(steps);
    time_t predict = (time_t) ((tnow-tstart) * proportion) + tstart;
    timestr = PrintTime(predict,string("%c"));
  }
#endif

cout << PrintTime(tnow) << 
   "  Predicted end of last chain:  " << timestr << endl;
cout << endl;

} /* Prognose */

//___________________________________________________________________

// This functions are used to predict the end of the profile
// process and print a report on progress so far.  When first
// beginning a profile, call RecordProfileStart() to set the time;
// then call PrognoseProfiles to report on progress.

void RunReport::RecordProfileStart()
{
// don't even try if there is no system clock
#ifndef NOTIME_FUNC
  profilestart = GetTime();
  string timestamp = PrintTime(profilestart);
#else
  string timestamp = "          ";
#endif
  if (level != NONE)
    cout << timestamp << "  Beginning profiling, please be patient" << endl;

} /* RecordProfileStart */

//___________________________________________________________________

void RunReport::PrognoseProfiles(long thisprof, long totprofs) 
{
  if (level == NONE || level == CONCISE) return;

  string timestr;
  string skiptimestamp = "          ";

  long profile = thisprof + 1;   // elsewhere they are counted starting from 0

#ifdef NOTIME_FUNC
  timestr = "unknown"; 
#else
  time_t tnow = GetTime();
  double proportion = double(totprofs) / double(profile);
  time_t predict = (time_t) ((tnow - profilestart) * proportion) + profilestart;
  timestr = PrintTime(predict, string("%c"));
#endif
  cout << PrintTime(tnow) << "  Profile " << profile << " of " << totprofs << endl;
  if (thisprof != totprofs)   // don't predict on final profile
    cout << skiptimestamp << "Predicted end of profiling:  " << timestr << endl;
  cout << endl;

} /* PrognoseProfiles */

/**************************************************************
   This function prints the "moving bar" which shows progress
   of the run.  It is meant to be called by the chain.
   You must call SetBarParameters before calling this.  Also,
   for PrintBar to work properly it must be called for the
   first time with steps=0 and for the last time with steps=
   totalsteps.
**************************************************************/

void RunReport::PrintBar(long steps)  
{
#ifdef EMACS
  return;
#else
if (level == CONCISE || level == NONE) return;

long i;
static long previous = 0;
long width = 12;

if (steps==0) { // Initial display of bar
  cout << "\n" << PrintTime(GetTime()) << "  ";
  cout << MakeJustified(chaintype + string(" chain "),-14) << Pretty(chainno + 1L, 3) << ":  ";
  cout << "[|                   ] ";
  cout << Pretty(steps + 1L, width);
  cout.flush();
  previous = 0;
  return;
}
 
long percent = static_cast<long>(100.0 * static_cast<double>(steps) /
                                         static_cast<double>(totalsteps));
if (percent > previous && (percent/5) * 5 == percent) {
  for (i = 0; i < width+22; i++) cout << "\b";   // back up
  for (i = 0; i < percent/5; i++) {
    cout << "=";
  }
  if (percent != 100) cout << "|";
  for (i = 0; i < 19-(percent/5); i++) cout << " ";
  cout << "] ";
} else {
  for (i = 0; i < width; ++i) cout << "\b";
}
cout << Pretty(steps - burnin, width);
if (steps == totalsteps) cout << " steps " << endl;
cout.flush();
previous = percent;
#endif      
} /* PrintBar */

//_____________________________________________________________________________

void RunReport::MakeReport(const ChainOut& chout) const
{
// Prepare header lines
  unsigned long i, j;

  // Prepare tables of chain MLEs
    scalars.erase();
    tabheaders.erase();
    tables.clear();

    const vector<Force *>& forces = forcesum.GetAllForces();
    long columnlength = 0;

    for (i = 0; i < forces.size(); ++i) {  // fill up all tables
      if ((forces[i]->GetParamsPerDimension())[0] == 1) {  // scalar
        scalars += MakeJustified(forces[i]->GetShortparmname(), -10) + "  ";
        scalars += forces[i]->MakeChainParamReport(chout)[0] + "  ";
      } else {                                    // tabular
        if (tables.size() == 0) {  // first entry in table
          tables = forces[i]->MakeChainParamReport(chout);
          for (j = 0; j < tables.size(); ++j) {
            // j+1 to come out in "human numbers"
            tables[j] = MakeJustified(popnames[j], -10) + "  " + tables[j];
          }
          columnlength = tables[0].size() * 10;
          tabheaders = "Pop         " + MakeCentered(forces[i]->GetShortparmname(), -columnlength) 
             + "  ";
        } else {                   // subsequent entries
          StringVec1d temptable = forces[i]->MakeChainParamReport(chout);
          for (j = 0; j < tables.size(); ++j) {
            tables[j] += "  " + temptable[j];
          }
          columnlength = tables[0].size() * 10;
          tabheaders += MakeCentered(forces[i]->GetShortparmname(), -columnlength) + "  ";
        }
      }
    }
    // if heating, make swapping report
    long numtemps = chout.GetNumtemps();
    if (numtemps > 1) {
      DoubleVec1d swaprates = chout.GetSwaprates();
      DoubleVec1d temperatures = chout.GetTemperatures();
      string tableline = "Temperature:";
      tables.push_back(tableline);
      tableline = "Swapping ";
      long temp;
      for (temp = 1; temp < numtemps; ++temp) {
	//        tableline += Pretty(temp+1) + " ";
        tableline += Pretty(temperatures[temp],7) + "  ";
      }
      tables.push_back(tableline);
      for (temp = 0; temp < numtemps-1; ++temp) {
	//        tableline = Pretty(temp+1,7) + "   ";
        tableline = Pretty(temperatures[temp],7) + "  ";
        long temp2;
        for (temp2 = 1; temp2 < numtemps; ++temp2) {
          if (temp2 > temp) {
            tableline += Pretty(100.0 * swaprates[temp * numtemps + temp2],6);
            tableline += "%  ";
          }
          else tableline += "         ";
        }
        tables.push_back(tableline);
      }
    }
} /* MakeReport */

//_____________________________________________________________________________

vector<string> RunReport::FormatReport(const ChainOut& chout, bool current, 
  long linelength) const
{
  string skiptimestamp;
  if (current) skiptimestamp = "          ";
  else skiptimestamp = "";

  vector<string> report;
  vector<string> temptable;

// header
  string tempstring = "";
  if (current) tempstring = PrintTime(GetTime()) + "  ";
  tempstring += "Accepted ";
  tempstring += MakeJustified(ToString(100.0 * chout.GetAccrate()), 5);
  tempstring += "% | Prior lnL " + Pretty(chout.GetLlikemle(), 10);
  tempstring += " | Data lnL " + Pretty(chout.GetLlikedata(), 10);
#if 0
  tempstring += "Accepted " + Pretty(100.0 * chout.GetAccrate(), 7) + "%";
  tempstring += " | Prior lnL " + Pretty(chout.GetLlikemle());
  tempstring += " | Data lnL " + Pretty(chout.GetLlikedata());
#endif
  report.push_back(tempstring);
  long badtrees = chout.GetNumBadTrees();
//  if (badtrees > 0) {
    report.push_back("Trees discarded due to too many events: " + 
      Pretty(badtrees));
//  }

// If multiple Arrangers, print an Arranger report
  ratemap arrates = chout.GetAllAccrates();
  ratemap::const_iterator rate;
  if (arrates.size() > 1) {
    for (rate = arrates.begin(); rate != arrates.end(); ++rate) {
      report.push_back(rate->first + " accepted " + Pretty(rate->second.first)
        + "/" + Pretty(rate->second.second) + " proposals");
    }
  }

// Actually print the tables
  if (scalars.size()) {
    report.push_back(skiptimestamp + scalars);
  }
  if (tabheaders.size()) {
    temptable.push_back(tabheaders);
  }
  long i;
  string line = "";
  for (i = 0; i < (long)tables.size(); ++i) {
    line = tables[i];
    temptable.push_back(line);
  }

  temptable = Linewrap(temptable, linelength);
  for (i = 0; i < static_cast<long>(temptable.size()); ++i) {
    report.push_back(skiptimestamp + temptable[i]);
  }

  return(report);
} /* FormatReport */

//_____________________________________________________________________________

void RunReport::DisplayReport(const ChainOut& chout) {
if (level == NORMAL || level == VERBOSE) {
  MakeReport(chout);
  vector<string> rpt = FormatReport(chout,true,80);
  long it;
  for (it = 0; it < (long) rpt.size(); ++it)
    cout << rpt[it] << endl;
}
} /* DisplayReport*/

//_____________________________________________________________________________

void RunReport::SetBarParameters(long totsteps, long burn, long chno, long chtype)
{
  totalsteps = totsteps;
  chainno = chno;
  burnin = burn;
  burnpercent = 100.0 * static_cast<double>(burn)/static_cast<double>(totsteps);
  switch (chtype) {
    case 0: chaintype = "Initial";
            break;
    case 1: chaintype = "Final";
            break;
    default:  assert(false);
            break;
  }  
} /* SetBarParameters */

//_____________________________________________________________________________


