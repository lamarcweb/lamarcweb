// $Id: outputfile.h,v 1.2 2002/06/25 03:17:51 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// This class is the main driver for the output report.  It
// summarizes information from many collection objects into a
// report and then prints/displays it.  There is normally only one
// instance of the OutputFile object.
//
// Note that this class cannot be directly placed into any container,
// or be passed by value!!!!

#ifndef OUTPUTFILE
#define OUTPUTFILE

#include <iostream>
#include <fstream>
#include <strstream>
#include <ctype.h>
#include <vector>
#include <string>
#include <algorithm>
#include <math.h>
#include "stringx.h"
#include "reportpage.h"
#include "constants.h"
#include "chainout.h"

#include "registry.h"

class OutputFile
{

private:
// these are deliberately never implemented
OutputFile();  
OutputFile(const OutputFile &src);
OutputFile &operator=(const OutputFile &src);

ofstream outf;
const Registry& registry;
const ChainPack& chainpack;
vector<ReportPage *> reports; // this points at local variables of Display()

void AddReport(ReportPage &report);
void ShowReports();


public:
OutputFile(const Registry& reg, const ChainPack& chpack);
~OutputFile() { outf.close(); };

void Display();

};

#endif
