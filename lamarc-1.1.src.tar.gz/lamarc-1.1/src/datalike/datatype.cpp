//$Id: datatype.cpp,v 1.14 2002/06/25 03:17:46 mkkuhner Exp $ 

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "datatype.h"
#include "dlcalc.h"    
#include "dlcell.h"   
#include "dlmodel.h"
#include "datapack.h"
#include "errhandling.h"
#include "stringx.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//___________________________________________________________________________
//___________________________________________________________________________

long DataType::GetPairwiseMarkers(const Region& region) const
{
return region.GetNmarkers();

} /* DataType::GetPairwiseMarkers */

//___________________________________________________________________________

double DataType::DifferenceWithinPop(StringVec2d::const_iterator
  begin1, StringVec2d::const_iterator end) const
{
double ndiffs = 0.0;
// half triangular matrix
StringVec2d::const_iterator group1 = begin1;
StringVec2d::const_iterator group2;

for ( ; group1 != end; ++group1) {
   group2 = group1;
   ++group2;  // workaround for compilers that don't have += for iterators
   for ( ; group2 != end; ++group2) {
      StringVec1d::const_iterator site1, site2;
      for (site1 = group1->begin(), site2 = group2->begin();
           site1 != group1->end();
           ++site1, ++site2) 
      {
         if (!IsEquivalent(*site1, *site2)) ++ndiffs;
      }
   } 
}

return ndiffs;

} /* DifferenceWithinPop */

//___________________________________________________________________________

double DataType::DifferenceBetweenPops(StringVec2d::const_iterator begin1,
  StringVec2d::const_iterator end1, StringVec2d::const_iterator begin2,
  StringVec2d::const_iterator end2) const
{
double ndiffs = 0.0;
StringVec2d::const_iterator group1 = begin1;
StringVec2d::const_iterator group2 = begin2;

for ( ; group1 != end1; ++group1) {
  for ( ; group2 != end2; ++group2) {
      StringVec1d::const_iterator site1, site2;
      for (site1 = group1->begin(), site2 = group2->begin();
           site1 != group1->end();
           ++site1, ++site2) 
      {
         if (!IsEquivalent(*site1, *site2)) ++ndiffs;
      }
   }
}
return ndiffs;

} /* DifferenceBetweenPops */

//___________________________________________________________________________

DoubleVec1d DataType::CalcFw(const Region& region) const
{
StringVec3d data(region.GetAllGeneticData());
DoubleVec1d fwithin(data.size(),0.0);

DoubleVec1d::iterator fw;
StringVec3d::const_iterator pop;
for(pop = data.begin(), fw = fwithin.begin(); pop != data.end(); ++pop, ++fw) {

// WARNING warning -- what if the 1st population is a ghost population?
// nn = nmarkers * (ntips * ntips - ntips) / 2.0
   double nn = GetPairwiseMarkers(region) * 
               (pop->size()*pop->size() - pop->size())/2.0;

   double within = DifferenceWithinPop(pop->begin(), pop->end());
   if (nn > 0.0) within /= nn;
                   
   *fw = 1.0 - within;
}

return fwithin;

} /* NucleotideType::CalcFw */

//___________________________________________________________________________

DoubleVec1d DataType::CalcFb(const Region& region) const
{
StringVec3d data(region.GetAllGeneticData());
long npops = data.size();
DoubleVec1d fbetween(npops*npops,0.0);

long pop1, pop2;
for(pop1 = 0; pop1 < npops; ++pop1) {
   for(pop2 = pop1 + 1; pop2 < npops; ++pop2) {

      // WARNING warning -- nmarkers may be wrong because of ghost populations
      // nn = nmarkers * ntips[pop1] * ntips[pop2]
      double nn = GetPairwiseMarkers(region) * 
                  data[pop1].size() * data[pop2].size();

      double between = DifferenceBetweenPops(data[pop1].begin(),
                       data[pop1].end(), data[pop2].begin(),
                       data[pop2].end());
      if (nn > 0.0) between /= nn;
      fbetween[pop1 * npops + pop2] = 1.0 - between;
      fbetween[pop2 * npops + pop1] = 1.0 - between;
   }
}

return fbetween;

} /* NucleotideType::CalcFb */

//___________________________________________________________________________

DataModel* NucleotideType::DefaultDataModel()
{
  return new F84Model;

} /* DefaultDataModel */

//___________________________________________________________________________

long DataType::CalcNVarMarkers(const StringVec2d& data) const
{
  long nvarmarkers = 0;
  long marker, nmarkers = data[0].size();
  for (marker = 0; marker < nmarkers; ++ marker) {
    bool varying = false;
    long indiv, nindiv = data.size();
    for(indiv = 1; indiv < nindiv && !varying; ++indiv)
       if (!IsEquivalent(data[0][marker],data[indiv][marker]))
         varying = true;
    if (varying) ++nvarmarkers;
  }

  return nvarmarkers;

} /* CalcNVarMarkers */

//___________________________________________________________________________

wakestats DataType::CalcNPairDiffs(const StringVec2d& data) const
{
  wakestats sums(0L,0L);
  StringVec2d::const_iterator indiv1;
  for(indiv1 = data.begin(); indiv1 != data.end(); ++indiv1) {
     StringVec2d::const_iterator indiv2;
     for(indiv2 = indiv1+1; indiv2 != data.end(); ++indiv2) {
        assert(indiv1->size() == indiv2->size());
        long pos, npos = indiv1->size(), count = 0;
        for(pos = 0; pos < npos; ++pos)
           count += ((IsEquivalent((*indiv1)[pos],(*indiv2)[pos])) ?
                     0L : 1L);
        sums.first += count;
        sums.second += count * count;
     }
  }

  return sums;
  
} /* CalcNPairDiffs */

//___________________________________________________________________________

bool DataType::IsEquivalent(const string& data1, const string& data2) const
{
  return (data1 == data2);

} /* IsEquivalent */

//___________________________________________________________________________
//___________________________________________________________________________

bool NucleotideType::Proofread(const string &raw, StringVec1d &clean,
                               string& baddata) const
{
  long rawsize, position;
  char ch;

  clean.clear();
  rawsize = raw.size();

  for (position = 0; position < rawsize; ++position) {
    ch = toupper(raw[position]);
    if (isspace(ch))
      continue;

    if (!strchr("ACGTUMRWSYKVHDBNOX?-", ch)) {
      baddata = ToString(ch);
      return false;
    }

    string cleanstr;
    cleanstr += ch;
    clean.push_back(cleanstr);
  }

  return true;
}

//___________________________________________________________________________

bool NucleotideType::IsEquivalent(const string& data1, const string& data2) const
{

  if (CaselessStrCmp(data1, data2)) return true;

  // otherwise, they might still be equivalent due to code ambiguities

  string unknowns = "NOXnox?-";  // all of these mean 'unknown'

  bool isunknown1 = (data1.find_first_of(unknowns) != string::npos);
  bool isunknown2 = (data2.find_first_of(unknowns) != string::npos);

  if (isunknown1 && isunknown2) return true;

  string ts = "TUtu";            // all of these mean T

  bool ist1 = (data1.find_first_of(ts) != string::npos);
  bool ist2 = (data2.find_first_of(ts) != string::npos);

  if (ist1 && ist2) return true;

  return false;
  
} /* NucleotideType::IsEquivalent */

//___________________________________________________________________________
//___________________________________________________________________________

DNASeqType::DNASeqType()
{
  m_name = "DNA Sequence";
}

//___________________________________________________________________________

vector<Cell_ptr> DNASeqType::CreateDLCell(const Region& region) const
{
  long len = region.GetNmarkers();
  long cat = region.datamodel->GetNcategories();

  vector<Cell_ptr> newcells;
  Cell_ptr cell(new DNACell(region.datamodel, len, cat));
  newcells.push_back(cell);
  return newcells;
}

//___________________________________________________________________________

DLCalculator* DNASeqType::CreateDLCalculator(const Region& region, Tree* tree)
  const
{
  DNACalculator* dlcalc = new DNACalculator(tree,region);
  return dlcalc;

}

//___________________________________________________________________________
//___________________________________________________________________________

SNPDataType::SNPDataType()
{
  m_name = "SNP data";
}

//___________________________________________________________________________

long SNPDataType::GetPairwiseMarkers(const Region& region) const
{
return region.GetNsites();

} /* SNPDataType::GetPairwiseMarkers */

//___________________________________________________________________________

vector<Cell_ptr> SNPDataType::CreateDLCell(const Region& region) const
{
  long len = region.GetNmarkers();
  int  cat = region.datamodel->GetNcategories();
  vector<Cell_ptr> newcells;

  // A SNP data type actually has *two* DLCells, one for variable and one
  // for non-variable sites

  Cell_ptr variant(new DNACell(region.datamodel, len, cat));

  Cell_ptr invariant(new SNPCell(region.datamodel, 5, cat));

  newcells.push_back(variant);
  newcells.push_back(invariant);
  return newcells;
}

//___________________________________________________________________________

DLCalculator* SNPDataType::CreateDLCalculator(const Region& region, Tree* tree)
  const
{
  SNPCalculator* dlcalc = new SNPCalculator(tree,region);
  return dlcalc;
}

//___________________________________________________________________________
//___________________________________________________________________________

MSType::MSType()
: AlleleType()
{
  m_name = "Microsatellite";
}

//___________________________________________________________________________

bool MSType::Proofread(const string &raw, StringVec1d &clean,
                       string& baddata) const
{
  unsigned long index;
  char c;
  string allele;

  for (index = 0; index < raw.size(); ++index) {
    c = raw[index];
    if (!isspace(c)) allele += c;
    else {
      if (!allele.empty()) clean.push_back(allele);
      allele.erase(); 
    }
  }

  // needed in case the last allele is not followed by spaces....
  if (!allele.empty()) clean.push_back(allele);

  // error checking:  microsat data must be either an integer or ?

  for (index = 0; index < clean.size(); ++index) {
    if (clean[index] == "?") continue;  // means unknown data
    if (!IsInteger(clean[index])) {
      baddata = clean[index];
      return false;  // illegal data found
    }
  }

  return true;
}

//___________________________________________________________________________

vector<Cell_ptr> MSType::CreateDLCell(const Region& region) const
{
  long len = region.GetNmarkers();
  long cat = region.datamodel->GetNcategories();
  long bins = region.datamodel->GetNbins();
  vector<Cell_ptr> newcells;
  Cell_ptr cell(new MSCell(region.datamodel, len, cat, bins));
  newcells.push_back(cell);
  return newcells;
}

//___________________________________________________________________________

DLCalculator* MSType::CreateDLCalculator(const Region& region, Tree* tree)
  const
{
  MSCalculator* dlcalc = new MSCalculator(tree, region);
  return dlcalc;
}

//___________________________________________________________________________

DataModel* MSType::DefaultDataModel()
{
  return new StepwiseModel;

} /* DefaultDataModel */

//___________________________________________________________________________
//___________________________________________________________________________

// Free helper function

DataType* CreateDataType(const string tag)
{
  if (tag == DNA) return new DNASeqType;
  if (tag == SNP) return new SNPDataType;
  if (tag == MICROSAT) return new MSType;
  data_error e("Unknown data type encountered: " + tag);
  throw e;

} /* CreateDataType */

