//$Id: dlcalc.h,v 1.12 2002/06/25 03:17:47 mkkuhner Exp $

#ifndef DLCALCULATOR
#define DLCALCULATOR

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <math.h>
#include <vector>
#include "vectorx.h"
#include "constants.h"
#include "types.h"

/*********************************************************************
 DLCalculator manages the calculation of data likelihoods on
 a given region and tree specified at constructor time.  Call
 the member function Calculate() to perform the actual calculation.
 Calculate() makes use of DataModel member functions
 ComputeExponentials(), ComputeSiteDLs() and ComputeTreeDL().  The
 resulting likelihood will be stored using a member function of
 Tree, SetDLValue().
 
 The class is polymorphic on data type (not data model).

 We assume that we start with a correct tree with all update flags set
 appropriately.  We end with a tree with correct likelihoods.  This
 class does NOT reset the update flags after updating the likelihood,
 as the flags may be needed by subsequent calculations.

 Written by Jon Yamato, revised by Jim Sloan, revised by Jon Yamato
 2002/01/28 added microsatellite support -- Mary Kuhner
            moved markerweights to base class

**********************************************************************/

// The following are used in the .cpp code:
// #include "datapack.h" for access to
//    datamodel, GetMarkerweights(), GetDataLength(), GetNTips()
// #include "dlmodel.h" for access to
//    Finalize(), ComputeExponentials(), ComputeSiteDLs(),
//    ComputeTreeDLs()
// #include "tree.h" for access to
//    timelist, SetDLValue()
// #include "branchlist.h" for access to
//    Begin(), Next(), GetBranch(), BeginBody(), InRange()

class Region;
class Tree;
class DataModel;
class Cell;
class NucModel;


//____________________________________________________________________________
//____________________________________________________________________________

class DLCalculator
{
private:
  DLCalculator();                               // undefined
  DLCalculator& operator=(const DLCalculator&); // undefined

protected:
  Tree*      tree;                              // not owning
  DataModel& datamodel;
  const DoubleVec1d markerweights;

  DLCalculator(const DLCalculator& src);        // internal use

  virtual rangepair SitePairToMarkerPair(rangepair sites) { return sites; };

public:
  DLCalculator(Tree* tr, const Region& region);
  virtual ~DLCalculator()            {};
  virtual DLCalculator* Clone() const = 0;
  virtual void Calculate()            = 0;

};

//____________________________________________________________________________
//____________________________________________________________________________

class NucCalculator : public DLCalculator
{
protected:
  typedef double** SiteDL;

  long aliasmemsize, nmarkers;

  // the following are new'ed pointers for memcpy purposes
  long* permalias;
  long* newalias;   // scratchpad for recalculating permalias;
                    // kept as member variable as speed optimization

  NucCalculator(const NucCalculator& src);    // internal use
  virtual void CalculateSite(Cell_ptr child1, Cell_ptr child2,
     Cell_ptr newcell, long pos, long alias);

public:
  NucCalculator(Tree* tr, const Region& region);
  virtual ~NucCalculator() { delete [] permalias; delete [] newalias; };

};

//____________________________________________________________________________
//____________________________________________________________________________

class DNACalculator : public NucCalculator
{
private:
  void Breakalias(long* newaliases, const rangevector& subtrees);

protected:
  DNACalculator(const DNACalculator& src) : NucCalculator(src) {};

public:
  DNACalculator(Tree* tr, const Region& region)
   : NucCalculator(tr,region) {};
  virtual ~DNACalculator() {};
  virtual DLCalculator* Clone() const;
  virtual void Calculate();
  void AccumulateNorms(Cell_ptr my, Cell_ptr child1, Cell_ptr child2,
   long pos, long alias);

};

//____________________________________________________________________________
//____________________________________________________________________________

class SNPCalculator : public NucCalculator
{
private:
  LongVec1d markerpos;
  NucModel* invarmodel;

  void Breakalias(long* newaliases, const rangevector& subtrees);
  void CalculateInvarSite(Cell_ptr child1, Cell_ptr child2,
     Cell_ptr newcell, long pos);


protected:
  SNPCalculator(const SNPCalculator& src);

  virtual rangepair SitePairToMarkerPair(rangepair sites);

public:
  SNPCalculator(Tree* tr, const Region& region);
  virtual ~SNPCalculator();
  virtual DLCalculator* Clone() const;
  virtual void Calculate();

};

//____________________________________________________________________________
//____________________________________________________________________________

class AlleleCalculator : public DLCalculator
{
protected:
  AlleleCalculator(const AlleleCalculator& src) : DLCalculator(src) {}; // internal use

public:
  AlleleCalculator(Tree* tr, const Region& region); 
  virtual ~AlleleCalculator() {};

};

//____________________________________________________________________________
//____________________________________________________________________________


class MSCalculator : public AlleleCalculator
{
private:
  LongVec1d markerpos;

protected:
  MSCalculator(const MSCalculator& src);
  virtual rangepair SitePairToMarkerPair(rangepair sites);

public:
  MSCalculator(Tree* tr, const Region& region);
  virtual ~MSCalculator()             {};
  DLCalculator* Clone() const;
  virtual void Calculate();

};

#endif

