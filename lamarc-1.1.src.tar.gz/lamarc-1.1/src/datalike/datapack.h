//$Id: datapack.h,v 1.15 2002/06/26 19:11:52 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// This file defines 3 storage classes: TipData, Region and DataPack.
// In general, a DataPack owns a container of pointer to Regions, which
// in turn owns a container of TipData.
//
// TipData--a storage class, used to hold the linked genetic data for a
//    tip in a tree of haplotypes.  It also stores, for the tip, its
//    population membership, individual membership, and name.
//
//
// Region--a storage class, containing data information that applies
//    to the genetic info of that region (regional quick theta estimate,
//    counts of the number of haplotypes and variable markers, marker map
//    positions, marker weights for the HMMC for data-likelihood, region
//    name).
//
//    In addition, Region serves as the bridge between the data and the
//    tree via Region::CreateTree().  CreateTree() copies the prototype
//    tree and finishes tree construction (creates the tips and individuals,
//    sets the site ranges) and enables data likelihood calculation (creates
//    the data likelihood calculator).  It returns an owning pointer to
//    the newly created tree.
//
//
// DataPack--a storage class, with a container of pointers to all
//    Regions programwide.  DataPack owns what the pointers point to.
//    It also tracks some population level data, number of populations
//    and population names.  It does not track any migration specific
//    info (which is handled by class ForceSummary).
//
// Written by Jim Sloan, heavily revised by Jon Yamato
// 2002/01/03 changed Tipdata::data to a vector for generality--Mary Kuhner

// NB  This code distinguishes between "markers" and "sites".  A marker
// is a site for which we have data.  In SNP data, for example, every base
// pair is a site, but only the SNPs are markers.  Data likelihoods are
// calculated on markers; recombination probabilities are calculated on
// sites.  Please keep these straight!

#ifndef DATAPACK
#define DATAPACK

#include "lamarcdebug.h"
#include <vector>
#include "vectorx.h"
#include <string>
#include <stdlib.h>
#include "constants.h"
#include "forceparam.h"
#include "types.h"
#include "individual.h" // for SetPhaseMarkers() in Region::CreateTree()
                        //     IndVec declaration for Region
#include <memory>

#include "datatype.h"
#include "dlmodel.h"

#include <assert.h>

class Registry;
class Tree;

// in .cpp, for use by tree creation factory:
// #include "registry.h"  to get the protoTree
// #include "branch.h"
// #include "branchlist.h" 
// #include "tree.h"
// #include "datatype.h"
// #include "dlcell.h" to clear the dlcell freestore


const long FLAGIND = -1;

//____________________________________________________________________
//____________________________________________________________________

class TipData
{
private:

void CopyAllMembers(const TipData& src);


public:
long population, individual;
string label;
vector<string> data;  // one string per marker

TipData();
TipData(const TipData& src);
TipData& operator=(const TipData& src);

string GetFormattedData(const string& dlm) const;

};

//____________________________________________________________________
//____________________________________________________________________

class DataPack;

class Region
{
private:
Region();                              // not defined
Region(const Region& src);             // not defined
Region& operator=(const Region& src);  // not defined

vector<TipData> tipdata;
IndVec individuals;

// most of these variables will need to be vectors over loci in V2
long            nmarkers;    // number of actual markers in data
bool            haveSetNmarkers;    // have seen at least one SetNmarkers call
long            nsites;      // number of positions spanned by data
long            mapposition; // map position of first site (not marker!)
long            offset;      // offset is applied to positions to get
LongVec1d       positions;   // the actual positions of the markers


DoubleVec1d     markerweights; 
string          regionname;
//StringVec1d     locusnames;       -- V2 
long            id;         // region number


public:
DataType_ptr    datatype;   // this will probably be a vector
DataModel_ptr   datamodel;  // this will probably parallel "Region::dataype"

ForceParameters regiontheta;
DataPack&       mydatapack;

Region(DataPack& mydatap);
~Region();

// Access
void AddIndividual(const Individual& newind) {individuals.push_back(newind);};
void SetID(long newid)                       {id = newid; };
void SetTipData(const TipData& td)           {tipdata.push_back(td);};
void SetNmarkers(long n);
void SetMapposition(long n)                  {mapposition = n;};
void SetOffset(long n)                       {offset = n;};
void SetPositions(const LongVec1d& pos)      {positions = pos;};
void SetNsites(long numsites)                {nsites = numsites;};
void SetMarkerweights(const DoubleVec1d& weights) {markerweights = weights;};
void SetRegionName(const string& n)          {regionname = n;};
//void SetLocusNames(const StringVec1d& n)   {locusnames = n;};    -- V2
void ChangeTo(const DataModel_ptr dlmodel)   {datamodel = dlmodel;};

// Potentially expensive Forces::QuickCalc() helper functions
LongVec1d    CalcNVariableMarkers() const;  // user CoalForce, dim: by pop
                                            // addt'l users DataPage
vector<wakestats> CalcNPairMarkerDiffs() const; // user RecForce, dim: by pop
bool         NoPhaseUnknownSites() const;

long         GetID()               const {return id;};
long         GetNTips()            const {return tipdata.size();};
long         GetNTips(long whichpopulation) const;
TipData      GetTipData(long n)    const {return tipdata[n];};
vector<TipData> GetAllTipData()    const {return tipdata;};
StringVec3d  GetAllGeneticData()   const;
long         GetNmarkers()         const {return nmarkers;};
long         GetMapposition()      const {return mapposition;};
long         GetOffset()           const {return offset;};
LongVec1d    GetPositions()        const {return positions;};
long         GetNsites()           const;
long         GetNIndividuals()     const {return individuals.size();};
Individual&  GetIndividual(long n)       {return individuals[n];};
const Individual& GetIndividual(long n) const {return individuals[n];};
DoubleVec1d  GetMarkerweights()    const {return markerweights;};
string       GetRegionName()       const {return regionname;};
//StringVec1d  GetLocusNames()       const {return locusnames;}; -- V2

// Factory function
Tree*        CreateTree() const;
void         PruneSamePhaseUnknownSites(IndVec& indivs) const;

// DataPack helper function for DataPack::CanSequencesBePaired()
bool         CanSequencesBePaired() const;
bool         MultiSampleIndividuals() const;

// Validity checking
bool         IsValid(string & errorString) const;

};

//____________________________________________________________________
//____________________________________________________________________

class DataPack
{
private:
DataPack(const DataPack&);     // undefined
DataPack& operator=(const DataPack&);  // undefined

vector<Region *> regions;
StringVec1d    populationnames;
NameIndex popmap;
long npops;
bool shouldpair;

public:
DataPack() : npops(0), shouldpair(false) { };
~DataPack();

void SetRegion(Region* r)                 {r->SetID(regions.size());
                                           regions.push_back(r);};
long AddPopulation(const string& name);
void SetShouldPair(bool poss)             {shouldpair = poss;};

long        GetNRegions()             const {return regions.size();};
vector<Region*>& GetAllRegions()            {return regions;};
const vector<Region*>& GetAllRegions() const {return regions;};
Region&     GetRegion(long n)               {assert(n <
                                             static_cast<long>(regions.size()));
                                             return *regions[n];};
const Region&     GetRegion(long n)   const {assert(n < 
                                             static_cast<long>(regions.size()));
                                             return *regions[n];};
long        GetNPopulations()         const {return npops;};
StringVec1d GetPopulationNames()      const {return populationnames;};
long        GetPopNumber(const string& name) const {return 
                                                popmap.find(name)->second;};
string      GetPopName(long number)   const {assert(number < 
                                             static_cast<long>(populationnames.size()));
                                             return populationnames[number];};
// The next 4 functions are helper functions for the Menu subclass dealing
// with rearrangement
bool        CanSequencesBePaired()    const;
bool        UserIndividualsExist()    const;
bool        CanHapArrange()           const;
bool        ShouldPair()              const;

bool        WeShouldMakePairs()       const {return shouldpair;};

};

#endif



