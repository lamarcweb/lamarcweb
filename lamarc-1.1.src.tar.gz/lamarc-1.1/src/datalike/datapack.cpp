// Id: datapack.cpp,v 1.18 2001/08/24 18:47:00 mkkuhner Exp $ 

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "datapack.h"
#include "registry.h"
#include "constants.h"
#include "branch.h"
#include "branchlist.h"
#include "tree.h"
#include "datatype.h"
#include "dlcell.h"
#include "individual.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//___________________________________________________________________________
//___________________________________________________________________________

TipData::TipData()
{
population = FLAGLONG;
individual = FLAGIND;

} /* TipData::TipData */

//___________________________________________________________________________

void TipData::CopyAllMembers(const TipData& src)
{

population = src.population;
individual = src.individual;
label = src.label;
data = src.data;

} /* TipData::CopyAllMembers */

//___________________________________________________________________________

TipData::TipData(const TipData& src)
{

CopyAllMembers(src);

} /* TipData::TipData */

//___________________________________________________________________________

TipData& TipData::operator=(const TipData& src)
{

CopyAllMembers(src);

return(*this);

} /* TipData::operator= */

//___________________________________________________________________________

string TipData::GetFormattedData(const string& dlm) const
{
  string result;

  unsigned long i;
  for (i = 0; i < data.size(); ++i) {
    result += data[i] + dlm;
  }

  return result;

} /* GetFormattedData */

//___________________________________________________________________________
//___________________________________________________________________________

Region::Region(DataPack& mydatap)
: mydatapack(mydatap)
{

datatype.reset();  // clears datatype
datamodel.reset(); // clears datamodel

nmarkers   = 0;
haveSetNmarkers = false;
nsites = FLAGLONG;

} /* Region::Region */

//___________________________________________________________________________

Region::~Region()
{
// deliberately blank due to shared_ptr auto cleanup
} /* Region destructor */

//___________________________________________________________________________

void Region::SetNmarkers(long n)
{
    if(haveSetNmarkers)
    {
        if(n != nmarkers)
        {
            data_error e("SetNmarkers to an inconsistent number");
            throw e;
        }
    }
    else
    {
        haveSetNmarkers = true;
        nmarkers = n;
    }
} /* Region::SetNmarkers */

//___________________________________________________________________________

LongVec1d Region::CalcNVariableMarkers() const
{
LongVec1d nvarmarkers;

const StringVec3d data = GetAllGeneticData();
StringVec3d::const_iterator popdata;
for(popdata = data.begin(); popdata != data.end(); ++popdata) {
   if (!(*popdata).empty()) 
      nvarmarkers.push_back(datatype->CalcNVarMarkers(*popdata));
   else nvarmarkers.push_back(0);
}

return nvarmarkers;

} /* Region::CalcNVariableMarkers */

//___________________________________________________________________________

vector<wakestats> Region::CalcNPairMarkerDiffs() const
{
vector<wakestats> npairwisediffs;

const StringVec3d data = GetAllGeneticData();
StringVec3d::const_iterator popdata;
for(popdata = data.begin(); popdata != data.end(); ++popdata)
   npairwisediffs.push_back(datatype->CalcNPairDiffs(*popdata));
   
return npairwisediffs;

} /* Region::CalcNPairMarkerDiffs */

//___________________________________________________________________________

bool Region::NoPhaseUnknownSites() const
{
IndVec::const_iterator ind;
for(ind = individuals.begin(); ind != individuals.end(); ++ind)
   if (ind->AnyPhaseUnknownSites()) return false;

return true;

} /* Region::NoPhaseUnknownSites */

//___________________________________________________________________________

long Region::GetNTips(long whichpop) const
{
long count = 0;
vector<TipData>::const_iterator tip;
for(tip = tipdata.begin(); tip != tipdata.end(); ++tip)
   if (tip->population == whichpop) ++count;

return count;

} /* Region::GetNTips(long whichpop) */

//___________________________________________________________________________

StringVec3d Region::GetAllGeneticData() const
{
StringVec3d data(mydatapack.GetNPopulations());
vector<TipData>::const_iterator tip;
for(tip = tipdata.begin(); tip != tipdata.end(); ++tip)
   (data[tip->population]).push_back(tip->data);

return data;

} /* Region::GetAllGeneticData */

//___________________________________________________________________________

long Region::GetNsites() const
{
return ((nsites == FLAGLONG) ? GetNmarkers() : nsites);

} /* Region::GetNsites */

//___________________________________________________________________________

Tree* Region::CreateTree() const
{
Tree*      tree;
TipData    tipData;
TBranch    *pTip;
long        tip, ntips;

tree = registry.GetProtoTree().MakeStump();

tree->SetNsites(GetNsites());

tree->SetProtoCell(datatype->CreateDLCell(*this));

DLCell::ClearStore();   // reset the DLCell freestore

// make the prototype range ...
rangeset emptyset;
rangepair allsites(0L,GetNsites());
rangeset  bigset;
bigset.insert(allsites);
Range     bigrange;
bigrange.SetActivesites(bigset);
bigrange.SetNewactivesites(emptyset);
// ... and push it into the tree
tree->SetProtoRange(bigrange);

ntips = GetNTips();

/* Rewrite of indiviudal setup code to use the region's already existing
   individual vector, Region::individuals -- Jon 2001/11/08 */

long ind;
IndVec treeindivs(individuals);
vector<TipData> tips(tipdata);

// if pairing is true then we will redo the individuals so that
// each individual has two sequences that were adjacent to each other
// in the user's input file.  We assume the ordering of the tipdatas is
// representitive of that order.
if (mydatapack.WeShouldMakePairs()) {
   // fix the individuals first
   long halfoffset = static_cast<long>(treeindivs.size()/2.0 + 0.5);
   assert(halfoffset == static_cast<long>(treeindivs.size()/2));
   treeindivs.erase(treeindivs.begin()+halfoffset,treeindivs.end());

   // now fix the tipdatas, give each consecutive pair the same
   // individual number
   long ind = 0;
   vector<TipData>::iterator tip;
   for(tip = tips.begin(); tip != tips.end(); ++tip) {
      (tip++)->individual = ind;
      tip->individual = ind++;
   }
}

for (tip = 0; tip < ntips; ++tip) {
   // tipData          = GetTipData(tip);
   tipData          = tips[tip];
   pTip             = tree->CreateTip();
   pTip->population = tipData.population;
   pTip->label      = tipData.label;

   unsigned long i;
   for (i = 0; i < pTip->dlcell.size(); ++i) {
     pTip->dlcell[i]->Initialize(tipData.data);
   }

   pTip->eventtime  = 0.0;

   // push the empty set into newly active sites
   pTip->range.SetNewactivesites(emptyset);

   // push the global range into active sites
   pTip->range.SetActivesites(bigset);

   ind = tipData.individual;
   if (ind == FLAGLONG) continue; // FLAGLONG means "not part of an individual"

   IndVec::iterator indiv;
   for(indiv = treeindivs.begin(); indiv != treeindivs.end(); ++indiv)
      if (indiv->GetId() == ind) {
         indiv->AddTip(pTip);
         break;
      }
}

if (!NoPhaseUnknownSites()) PruneSamePhaseUnknownSites(treeindivs);

tree->SetIndividualsWithTips(treeindivs);

tree->SetDLCalculator(datatype->CreateDLCalculator(*this, tree));

return tree;

} /* CreateTree */

//___________________________________________________________________________

void Region::PruneSamePhaseUnknownSites(IndVec& indivs) const
{
IndVec::iterator ind;
for(ind = indivs.begin(); ind != indivs.end(); ++ind)
   ind->PruneSamePhaseUnknownSites();

} /* Region::PruneSamePhaseUnknownSites */

//___________________________________________________________________________

bool Region::CanSequencesBePaired() const
{

// are there an even number of sequences
if ( ((tipdata.size() / 2L) * 2L) != tipdata.size() ) return false;

// are there any individuals with > 1 sample
if (MultiSampleIndividuals()) return false;

return true;

} /* Region::CanSequencesBePaired */

//___________________________________________________________________________

bool Region::MultiSampleIndividuals() const
{

LongVec1d ind(individuals.size(),0L);
vector<TipData>::const_iterator tip;
for(tip = tipdata.begin(); tip != tipdata.end(); ++tip)
   if (ind[tip->individual]++) return true;

return false;

} /* Region::MultiSampleIndividuals */

//___________________________________________________________________________

bool Region::IsValid(string & errorString) const
{
  // Is the number of markers consistent?
  unsigned long nmark = nmarkers;  // to avoid warnings about 'unsigned'

  // default error string -- should be updated
  errorString = string("Invalid Region");

  if(nmarkers < 1)
  {
      errorString = string("No data in region");
      return false;
  }

  if (nmark != positions.size()) return false;
// markerweights are not necessarily right yet!
//  if (nmark != markerweights.size()) return false;

  // Are the marker positions in sorted order?
  vector<long> sortedpositions = positions;
  std::sort(sortedpositions.begin(),sortedpositions.end());
  if (positions != sortedpositions) return false;

#if 0
  // this test is not yet met, but should be (see comments in
  // lamarc.cpp

  // Are all of the markers within the boundaries of the datablock?
  if (positions[nmark-1] >= GetNsites() ) return false;
#endif

#if 0
  // Are all of the weights legal?
  unsigned long i;
  for (i = 0; i < markerweights.size(); ++i) {
    if (markerweights[i] < 0) return false;
  }
#endif

  return true;

} /* Region::IsValid */

//___________________________________________________________________________
//___________________________________________________________________________

DataPack::~DataPack()
{

// once and for all, clean out those DLCell arrays
DLCell::ClearStore();

// clean out the regions
vector<Region*>::iterator rit;
for(rit = regions.begin(); rit != regions.end(); ++rit)
   delete *rit;

} /* DataPack::~DataPack */

//___________________________________________________________________________

long DataPack::AddPopulation(const string& name)
{

if (popmap.insert(make_pair(name,npops)).second) {
   populationnames.push_back(name);
   ++npops;
   return(npops-1);
}

return(GetPopNumber(name));

} /* DataPack::AddPopulation */

//___________________________________________________________________________

bool DataPack::CanSequencesBePaired() const
{

vector<Region*>::const_iterator region;
for(region = regions.begin(); region != regions.end(); ++region)
   if (!(*region)->CanSequencesBePaired()) return false;

return true;

} /* DataPack::CanSequencesBePaired */

//___________________________________________________________________________

bool DataPack::UserIndividualsExist() const
{

vector<Region*>::const_iterator region;
for(region = regions.begin(); region != regions.end(); ++region)
   if ((*region)->MultiSampleIndividuals()) return true;

return false;

} /* DataPack::UserIndividualsExist() */

//___________________________________________________________________________

bool DataPack::ShouldPair() const
{

return (CanSequencesBePaired() && !UserIndividualsExist());

} /* DataPack::ShouldPair */

//___________________________________________________________________________

bool DataPack::CanHapArrange() const
{

return (CanSequencesBePaired() || UserIndividualsExist());

} /* DataPack::CanHapArrange */

//___________________________________________________________________________
