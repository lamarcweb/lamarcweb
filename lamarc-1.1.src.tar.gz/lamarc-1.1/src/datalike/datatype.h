//$Id: datatype.h,v 1.12 2002/06/25 03:17:46 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/*********************************************************************
 This class is the key control class for polymorphism based on 
 the type of the input data (SNP, DNA, microsatellite, etc.)  It is 
 subclassed along datatype lines.

 Each DataType should have a short tag (related to XML file reading)
 and a textual name for its type.  It should have expertese to
 Proofread() raw input data and factory functions to create a
 datatype-appropriate DLCell and DLCalculator.  

 A free function, CreateDataType, can be used to create a DataType
 object corresponding to a tag.  Whenever a new DataType subclass
 is added this function must be updated.

 DataType written by Jim Sloan, revised by Mary Kuhner

 added quickcalculator support Jon Yamato 2001/09/12:
    CalcNVarMarkers(), CalcNPairDiffs(), CalcFw(), CalcFb()
 deleted DataTranslator helper class Mary Kuhner 2002/01/02
    (this functionality now in DataModel)
******************************************************************/
 
#ifndef DATATYPE
#define DATATYPE

#include <vector>
#include <string>
#include <map>
#include <stdlib.h>
#include "types.h"
#include "constants.h"
// in order to call inline dlcalc functions
#include "dlcalc.h"   

// Used by the .cpp implementation:
//#include "dlcell.h"     to create DLCell objects
//#include "dlmodel.h"    for GetNcategories() function
//#include "datapack.h"   for datamodel and GetDataLength() in Region class
//                        plus generalized access to Region in FST
//                        calculators, GetPairwiseMarkers(), CalcFw()
//                        and CalcFb()

class Tree;
class Region;
class DLCell;
class DataModel;

//____________________________________________________________________
// The DataType base class

class DataType
{
private:
DataType(const DataType&);      // undefined
DataType& operator=(DataType&);  // undefined

protected:
string m_name;

virtual long GetPairwiseMarkers(const Region& region) const;
        double DifferenceWithinPop(StringVec2d::const_iterator group1, 
                                StringVec2d::const_iterator done) const;
        double DifferenceBetweenPops(StringVec2d::const_iterator group1,
                                StringVec2d::const_iterator done1, 
                                StringVec2d::const_iterator group2,
                                StringVec2d::const_iterator done2) const;

public:
               DataType() {};
virtual        ~DataType() {};
        string GetDataType() const                       { return m_name; };
virtual bool   Proofread(const string& raw, StringVec1d& clean,
                         string& baddata) const = 0;
        DoubleVec1d CalcFw(const Region& region) const;
        DoubleVec1d CalcFb(const Region& region) const;
virtual long   CalcNVarMarkers(const StringVec2d& data) const;
virtual wakestats CalcNPairDiffs(const StringVec2d& data) const;
virtual bool   IsEquivalent(const string& data1, const string& data2) const;

// user pretty printing
virtual string GetDelimiter() const { return string(""); };

// Factory functions
virtual vector<Cell_ptr> CreateDLCell(const Region& region) const   = 0;
virtual DLCalculator* CreateDLCalculator(const Region& region, Tree *tree) 
                        const = 0;
virtual DataModel*    DefaultDataModel() = 0;

};

//____________________________________________________________________
//____________________________________________________________________
// Nucleotide sequence type

class NucleotideType : public DataType
{
public:
                 NucleotideType() : DataType() {};
    virtual      ~NucleotideType() {};
    virtual bool Proofread(const string& raw, StringVec1d& clean,
                           string& baddata) const;
    virtual bool IsEquivalent(const string& data1, const string& data2) const;

    virtual DataModel*      DefaultDataModel();
};

//____________________________________________________________________
// DNA sequence type

class DNASeqType : public NucleotideType
{
public:
               DNASeqType();
  virtual      ~DNASeqType() {};

  // Factory functions
  virtual vector<Cell_ptr> CreateDLCell(const Region& region) const;
  virtual DLCalculator* CreateDLCalculator(const Region& region, Tree* tree) 
                          const;
};

//____________________________________________________________________
// SNP data type

class SNPDataType : public NucleotideType
{
protected:
virtual long GetPairwiseMarkers(const Region& region) const;

public:
        SNPDataType();
virtual ~SNPDataType() {};

// Factory functions
virtual vector<Cell_ptr> CreateDLCell(const Region& region) const;
virtual DLCalculator* CreateDLCalculator(const Region& region, Tree* tree) 
                        const;

};

//____________________________________________________________________
// Allele type

class AlleleType : public DataType
{
  public:
                   AlleleType() : DataType() {};
    virtual        ~AlleleType() {};

    virtual string GetDelimiter() const { return string(" "); };
};

//____________________________________________________________________
// Microsatellite type

class MSType : public AlleleType
{
public:
             MSType();
virtual      ~MSType() {};

virtual bool Proofread(const string& content, StringVec1d& data,
                       string& baddata) const;

// Factory functions
virtual vector<Cell_ptr> CreateDLCell(const Region& region) const;
virtual DLCalculator* CreateDLCalculator(const Region& region, Tree* tree) 
                        const;
virtual DataModel*    DefaultDataModel();

};

//____________________________________________________________________
//____________________________________________________________________

// Free function, a polymorphic creator for DataTypes.
// If you add a new DataType subclass you must update this
// function.

DataType* CreateDataType(const string tag);

#endif

