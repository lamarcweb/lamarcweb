//$Id: dlcalc.cpp,v 1.38 2002/06/25 03:17:47 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "dlcalc.h"
#include "datapack.h"
#include "dlmodel.h"
#include "tree.h"
#include "branchlist.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

//___________________________________________________________________
//___________________________________________________________________

DLCalculator::DLCalculator(Tree* tr, const Region& region)
: tree(tr), 
  datamodel(*(region.datamodel)),
  markerweights(region.GetMarkerweights())
{
} /* DLCalculator::DLCalculator */

//___________________________________________________________________

DLCalculator::DLCalculator(const DLCalculator& src)
: tree(src.tree), 
  datamodel(src.datamodel),
  markerweights(src.markerweights)
{

} /* DLCalculator copy constructor */

//___________________________________________________________________
//___________________________________________________________________

NucCalculator::NucCalculator(const NucCalculator& src)
: DLCalculator(src),
  aliasmemsize(src.aliasmemsize),
  nmarkers(src.nmarkers)
{
  permalias = new long[nmarkers];
  memcpy(permalias, src.permalias, aliasmemsize);
  newalias = new long[nmarkers];

} /* NucCalculator copy constructor */

//___________________________________________________________________

NucCalculator::NucCalculator(Tree* tr, const Region& region) 
: DLCalculator(tr,region)
{

nmarkers = region.GetNmarkers();

permalias = new long[nmarkers];
newalias = new long[nmarkers];
aliasmemsize = nmarkers*sizeof(long);

// fill the alias array, by first constructing a hash table of
// tip DLCell values, then use the hash table to build the aliases.
TimeList& timelist = tree->GetTimeList();
long ntips = region.GetNTips();
long end = nmarkers*ntips;
unsigned char* aliasTable = new unsigned char [end];
long tip, pos;

// DEBUG debug WARNING warning
// Fill in the alias table--maybe fragile to addition of sequencing error.

long cat = 0;   // we alias based on the first category

Branchiter brit;
for (tip = 0, brit = timelist.Begin(); tip < ntips; ++tip, ++brit) {
   Cell_ptr dlcell = (*brit)->dlcell[0];
   long marker;
   for (pos = tip, marker = 0; pos < end; pos += ntips, ++marker) {
      SiteDL siteDLs = dlcell->GetSiteDLs(marker);
      aliasTable[pos] = static_cast<unsigned char>
                        (siteDLs[cat][baseA] + 2 * siteDLs[cat][baseC] +
                        4 * siteDLs[cat][baseG] + 8 * siteDLs[cat][baseT]);
   }

}

// Fill the alias array.
unsigned char* posn1, *posn2;
permalias[0] = -1;
for (pos = 1, posn1 = aliasTable+ntips; pos < nmarkers; 
     pos++, posn1 += ntips) {
   permalias[pos] = -1;    // Default: invalid alias.
   long step;
   for (step = 1, posn2 = posn1-ntips; step <= pos;
        step++, posn2 -= ntips) {
      // If the positions match for all tips,
      if (!memcmp(posn1, posn2, ntips)) {
         permalias[pos] = pos - step;              // set the alias.
         break;
      }
   }
}

delete [] aliasTable;

} /* NucCalculator::NucCalculator */

//___________________________________________________________________

void NucCalculator::CalculateSite(Cell_ptr child1,
   Cell_ptr child2, Cell_ptr newcell, long pos, long alias)
{
SiteDL newsiteDLs;

SiteDL child1DLs = child1->GetSiteDLs(pos);
SiteDL child2DLs = child2->GetSiteDLs(pos);

// if the alias is invalid, calculate; else use the alias
if (alias == -1) {
   newsiteDLs = dynamic_cast<NucModel&>(datamodel).
                   ComputeSiteDLs(child1DLs,child2DLs);
   if (datamodel.ShouldNormalize()) {
     double newnorm = newcell->Normalize(newsiteDLs) +
       child1->GetNorms(pos) + child2->GetNorms(pos);
     newcell->SetNorms(newnorm, pos);
   }
} else {
   newsiteDLs = newcell->GetSiteDLs(alias);
   newcell->SetNorms(newcell->GetNorms(alias),pos);
}

newcell->SetSiteDLs(pos,newsiteDLs);

} /* NucCalculator::CalculateSite */

//___________________________________________________________________
//___________________________________________________________________

AlleleCalculator::AlleleCalculator(Tree* tr, const Region& region)
: DLCalculator(tr,region)
{
} /* AlleleCalculator::AlleleCalculator */

//___________________________________________________________________
//___________________________________________________________________


void DNACalculator::Breakalias(long* newalias, const rangevector& subtrees)
{
long tr, nsubtrees = subtrees.size();

// copy the initial aliases
memcpy(newalias, permalias, aliasmemsize);

// skip the first subtree because it can't break any aliases
for(tr = 1; tr < nsubtrees; ++tr) { 
   long firstmarker = subtrees[tr].first, lastmarker = subtrees[tr].second;
   long pos;
   for(pos = firstmarker; pos < lastmarker; ++pos) {
// if the alias points to a site before the recombination site, break it
      if (newalias[pos] < firstmarker) 
         newalias[pos] = -1;
   }
}

} /* DNACalculator::Breakalias */

//___________________________________________________________________

DLCalculator* DNACalculator::Clone() const
{
DNACalculator* pnewcalc = new DNACalculator(*this);

return(pnewcalc);

} /* DNACalculator::Clone */

//___________________________________________________________________

void DNACalculator::AccumulateNorms(Cell_ptr my, Cell_ptr child1, Cell_ptr child2, 
   long pos, long alias)
{

double newnorm = ((alias != -1) ? 
                    my->GetNorms(alias) : 
                    my->GetNorms(pos) + child1->GetNorms(pos) + 
                       child2->GetNorms(pos));
                           

my->SetNorms(newnorm,pos);

} /* DNACalculator::AccumulateNorms */

//___________________________________________________________________

void DNACalculator::Calculate()
{
Branch *branch = NULL;
Branch *child = NULL;
Cell_ptr dlcell, child1DLCell, child2DLCell;
double length1, length2, totallike = 0.0;
long posn1, posn2, nsubtrees, tr, pos;
NucModel& datmodel = dynamic_cast<NucModel&>(datamodel);

// Find the subtrees
rangevector subtrees = tree->GetSubtrees();
nsubtrees = subtrees.size();

// Update the aliases.
Breakalias(newalias,subtrees);

// Step through the subtrees to compute the data likelhoods
TimeList& timelist = tree->GetTimeList();
for (tr = 0; tr < nsubtrees; tr++) {
   posn1 = subtrees[tr].first;
   posn2 = subtrees[tr].second;
   bool firstsubtree = (tr == 0);

   Branchiter brit;
   for (brit = timelist.BeginBody(); brit != timelist.End(); ++brit) {
      branch = *brit;
      if (branch->ShouldCalcDL(posn1)) {
         // Find "real" children and appropiate branch lengths.
         // 'child' is a reusable temp 
         dlcell = branch->dlcell[0];

         child = branch->GetValidChild(branch->child[0],posn1);
         length1 = branch->HowFarTo(*child);
         child1DLCell = child->dlcell[0];

         child = branch->GetValidChild(branch->child[1],posn1);
         length2 = branch->HowFarTo(*child);
         child2DLCell = child->dlcell[0];

         // Precalculate exponential terms
         datmodel.RescaleLengths(length1, length2);

         // Calculate the data likelihood at each position.
         for(pos = posn1; pos < posn2; ++pos) {
            CalculateSite(child1DLCell, child2DLCell, dlcell, pos, newalias[pos]);
         }
      }
   }

   // Check the DLs for the subtree at the root, relies on flow through
   // to be at root.

   bool active0 = branch->child[0]->range.IsSiteActive(posn1);
   bool active1 = branch->child[1]->range.IsSiteActive(posn1);

   if (!active0 || !active1) {
     dlcell = branch->dlcell[0];
     Cell_ptr nullcell(new NullCell);
     if (!active0) {
        child = branch->GetValidChild(branch->child[1],posn1);
        child1DLCell = nullcell;
        child2DLCell = child->dlcell[0];
        length1 = MAX_LENGTH;
        length2 = branch->HowFarTo(*child);
     } else {
        child = branch->GetValidChild(branch->child[0],posn1);
        length1 = branch->HowFarTo(*child);
        length2 = MAX_LENGTH;
        child1DLCell = child->dlcell[0];
        child2DLCell = nullcell;
     }
     datmodel.RescaleLengths(length1, length2);
     for (pos = posn1; pos < posn2; pos++) {
        CalculateSite(child1DLCell,child2DLCell,dlcell,pos,newalias[pos]);
     }
   }

   totallike += datmodel.ComputeSubtreeDL(*dlcell, dlcell->GetSiteDLs(posn1),
                   dlcell->GetSiteDLs(posn2), markerweights.begin()+posn1, posn1,
                   firstsubtree);
}

//_________________________________________________
// Calculate the total likelihood for the tree.
// Pass the last marker plus 1 for stl-like interface

tree->SetDLValue(totallike);

} /* DNACalculator::Calculate */

//___________________________________________________________________
//___________________________________________________________________

SNPCalculator::SNPCalculator(Tree* tr, const Region& region)
: NucCalculator(tr,region), markerpos(region.GetPositions()),
  invarmodel(dynamic_cast<NucModel*>(datamodel.Clone()))
{
  assert(invarmodel);
  invarmodel->SetNmarkers(INVARIANTS); // the invariant model should have
                                       // 1 "marker" for each base-type

} /* SNPCalculator::SNPCalculator */

//___________________________________________________________________

SNPCalculator::SNPCalculator(const SNPCalculator& src)
: NucCalculator(src), markerpos(src.markerpos),
  invarmodel(dynamic_cast<NucModel*>(src.invarmodel->Clone()))
{
  assert(invarmodel);
} /* SNPCalculator::copy ctor */

//___________________________________________________________________

SNPCalculator::~SNPCalculator()
{
  delete invarmodel;

} /* SNPCalculator::dtor */

//___________________________________________________________________

rangepair SNPCalculator::SitePairToMarkerPair(rangepair sites)
{
long firstmrkr = FLAGLONG;
long lastmrkr = FLAGLONG;
long firstsite = sites.first;
long lastsite = sites.second;

assert (firstsite < lastsite);

--lastsite;    // calling code assumes half-open intervals

// if we are at the extreme right or left, outside the range
// of markers, return immediately

if (lastsite < markerpos.front() || firstsite > markerpos.back())
  return(rangepair(FLAGLONG, FLAGLONG));

// find first marker that is within site range, inclusive
long marker;
for (marker = 0; marker < nmarkers; ++marker) {
  if (markerpos[marker] > lastsite) {    // we've passed the end
    return(rangepair(FLAGLONG,FLAGLONG));
  }
  if (markerpos[marker] >= firstsite) {  // found it
    firstmrkr = marker;
    break;
  }
}

// find first marker past the end of site range (which may be the
// non-existent marker after all markers; this is a half-open
// interval).

for (marker = nmarkers - 1; marker >= 0; --marker) {
  if (markerpos[marker] <= lastsite) {     
    lastmrkr = marker + 1;                   // found it; we return the
                                             // next marker for half-open
    break;
  }
}

assert(firstmrkr != FLAGLONG && lastmrkr != FLAGLONG);
assert(lastmrkr > firstmrkr);

return(rangepair(firstmrkr, lastmrkr));

} /* SitePairToMarkerPair */

//___________________________________________________________________

DLCalculator* SNPCalculator::Clone() const
{
SNPCalculator* pnewcalc = new SNPCalculator(*this);

return(pnewcalc);

} /* SNPCalculator::Clone */

//___________________________________________________________________

void SNPCalculator::Breakalias(long* newaliases, const rangevector& subtrees)
{
long tr, nsubtrees = subtrees.size();

// copy the initial aliases
memcpy(newalias, permalias, aliasmemsize);

// skip the first subtree because it can't break any aliases
for(tr = 1; tr < nsubtrees; ++tr) {
   rangepair marker = SitePairToMarkerPair(subtrees[tr]);
   long pos;

// if the range in marker is null, both elements are FLAGLONG and
// the following loop will be skipped, which is correct
   for(pos = marker.first; pos < marker.second; ++pos) {

      // if the alias points to a site before the recombination site, break it
      if (newaliases[pos] < marker.first)
         newaliases[pos] = -1;
   }
}

} /* SNPCalculator::Breakalias */

//___________________________________________________________________

void SNPCalculator::CalculateInvarSite(Cell_ptr child1,
   Cell_ptr child2, Cell_ptr newcell, long pos)
{
SiteDL child1DLs = child1->GetSiteDLs(pos);
SiteDL child2DLs = child2->GetSiteDLs(pos);

// no alias for invariant sites

SiteDL newsiteDLs = invarmodel->ComputeSiteDLs(child1DLs,child2DLs);

if (invarmodel->ShouldNormalize()) {
  double norm1 = child1->GetNorms(pos);
  double norm2 = child2->GetNorms(pos);
  double newnorm = newcell->Normalize(newsiteDLs) +
    norm1 + norm2;
  newcell->SetNorms(newnorm,pos);
}

newcell->SetSiteDLs(pos,newsiteDLs);

} /* SNPCalculator::CalculateInvarSite */

//___________________________________________________________________

/* A horrible truth to remember about this code:  the storage used
   for invariant site calculations is *re-used*.  You can never assume
   that that information is still around; the next subtree will wipe
   it out.  This is why we recalculate invariant sites throughout the
   whole tree every time, even though, in theory, this is not necessary. 
   There is a possible but very difficult OPTIMIZATION opportunity here.
   Mary June 11 2002
*/

void SNPCalculator::Calculate()
{
Branch *branch = NULL;
Branch *child1 = NULL, *child2 = NULL;
Cell_ptr dlcell, dlcell1, dlcell2;
double length1 = 0.0;
double length2 = 0.0; 
double totallike = 0.0;
long tr, curmarker;
NucModel& datmodel = dynamic_cast<NucModel&>(datamodel);

// determine the subtrees
rangevector subtrees = tree->GetSubtrees();
long nsubtrees = subtrees.size();

// Update the aliases.
Breakalias(newalias,subtrees);

// Step through the subtrees to compute the data likelhoods
TimeList& timelist = tree->GetTimeList();
for (tr = 0; tr < nsubtrees; ++tr) {
   rangepair marker = SitePairToMarkerPair(subtrees[tr]);
   long firstsite = subtrees[tr].first;
   bool firstsubtree = (tr == 0);

   // no markers in this subtree is handled by the rangepair,
   // marker, having the same value in both first and second.
   // Currently that value is FLAGLONG.

   Branchiter brit;
   for (brit = timelist.BeginBody(); brit != timelist.End(); ++brit) {
      branch = *brit;
      if (branch->CanCalcDL(firstsite)) {
// Precalculate the exponential values based on branch length.
         child1 = branch->GetValidChild(branch->child[0],firstsite);
         length1 = branch->HowFarTo(*child1);
         child2 = branch->GetValidChild(branch->child[1],firstsite);
         length2 = branch->HowFarTo(*child2);

// Calculate the data likelihood at each position for variable sites,
// if appropriate; we skip this if the branch is marked "doesn't need updating"
         if (branch->ShouldCalcDL(firstsite)) {
            dlcell1 = child1->dlcell[0];
            dlcell2 = child2->dlcell[0];
            dlcell = branch->dlcell[0];
            datmodel.RescaleLengths(length1, length2);
            for (curmarker = marker.first; curmarker < marker.second;
                 ++curmarker) {
               CalculateSite(dlcell1,dlcell2,dlcell,curmarker,
                             newalias[curmarker]);
            }
         }

// Calculate the invariant data likelihood for this branch,
// using baseA for allAs, baseC for allCs, etc.
         dlcell1 = child1->dlcell[1];
         dlcell2 = child2->dlcell[1];
         dlcell = branch->dlcell[1];
         invarmodel->RescaleLengths(length1, length2);
         for (curmarker = baseA; curmarker <= baseT; ++curmarker) {
            CalculateInvarSite(dlcell1,dlcell2,dlcell,curmarker);
         }
      }
   }

   // Check the DLs for the subtree at the root, relys on flow through
   // to be at root.
   bool active0 = branch->child[0]->range.IsSiteActive(firstsite);
   bool active1 = branch->child[1]->range.IsSiteActive(firstsite);

   Cell_ptr nullcell(new NullCell);

   if (!active0 || !active1) {
      dlcell = branch->dlcell[0];
      // the root is a one-legged coalescence, was not computed above
      // and must be done here
      assert(active0 || active1);   // a zero-legged coalecence!?
      if (!active0) {
        dlcell1 = nullcell;
        child2 = branch->GetValidChild(branch->child[1],firstsite);
        dlcell2 = child2->dlcell[0];
        length1 = MAX_LENGTH;
        length2 = branch->HowFarTo(*child2);
      } else if (!active1) {
        child1 = branch->GetValidChild(branch->child[0],firstsite);
        length1 = branch->HowFarTo(*child1);
        dlcell1 = child1->dlcell[0];
        length2 = MAX_LENGTH;
        dlcell2 = nullcell;
      }

      datmodel.RescaleLengths(length1, length2);

      // Calculate the data likelihood at each position.
      for (curmarker = marker.first; curmarker < marker.second; 
           curmarker++) {
         CalculateSite(dlcell1, dlcell2,dlcell,
            curmarker,newalias[curmarker]);
      }
 
      // Calculate the invariant data likelihood for this branch,
      // using baseA for allAs, baseC for allCs, etc.
      if (active0) dlcell1 = child1->dlcell[1];
      if (active1) dlcell2 = child2->dlcell[1];
      dlcell = branch->dlcell[1];
      invarmodel->RescaleLengths(length1, length2);
      for (curmarker = baseA; curmarker <= baseT; ++curmarker)
         CalculateInvarSite(dlcell1,dlcell2,dlcell,
            curmarker);
   }

// if the subtree contains no markers skip computing marker datalike
   if (marker.first != FLAGLONG) {
     dlcell = branch->dlcell[0];
     totallike += datmodel.ComputeSubtreeDL(*dlcell,
                  dlcell->GetSiteDLs(marker.first),
                  dlcell->GetSiteDLs(marker.second),
                  markerweights.begin()+marker.first,marker.first, firstsubtree);
   }

// Calculate the invariant marker likelihood for the subtree,
// using baseA for allAs, baseC for allCs, etc.
   long ninvarmarkers = subtrees[tr].second - subtrees[tr].first;
   if (marker.first != FLAGLONG) 
      ninvarmarkers -= marker.second - marker.first;

   if (ninvarmarkers > 0) {   // don't bother if no invariants in this subtree
      DoubleVec1d invarwts(1,ninvarmarkers);

      dlcell = branch->dlcell[1]; // switch to invariant cell

      // We are going to use a trick here, and add together the four
      // invariant site likelihoods into the bin normally occupied
      // by the first one.  This is ugly, but necessary to keep 
      // SNP-specific code out of the DataModel class.  The DataModel
      // needs to treat the four invariant markers as one big
      // supermarker, and cannot determine this itself; so we help it
      // out.

      // Changed to sum to "last" bin

      dlcell->SumMarkers(baseA, baseEnd, invarmodel->ShouldNormalize());

      totallike += invarmodel->ComputeSubtreeDL(*dlcell,
                   dlcell->GetSiteDLs(baseEnd), 
                   dlcell->GetSiteDLs(baseEnd+1),    // one past the end
                   invarwts.begin(),baseEnd, firstsubtree);
   }
}

//_________________________________________________
// Calculate the total likelihood for the tree.
// pass markerpos.size() and baseEnd+1 to get half-open interface

tree->SetDLValue(totallike);

} /* SNPCalculator::Calculate */

//___________________________________________________________________
//___________________________________________________________________

MSCalculator::MSCalculator(Tree* tr, const Region& region)
  : AlleleCalculator(tr,region), 
    markerpos(region.GetPositions())
{

// deliberately blank 

} /* MSCalculator constructor */

//___________________________________________________________________

MSCalculator::MSCalculator(const MSCalculator& src)
  : AlleleCalculator(src),
    markerpos(src.markerpos)
{

// deliberately blank

} /* MSCalculator copy constructor */

//___________________________________________________________________

DLCalculator* MSCalculator::Clone() const
{
MSCalculator* pnewcalc = new MSCalculator(*this);

return(pnewcalc);

} /* MSCalculator::Clone */

//___________________________________________________________________

// Similar to DNA case except:
// no aliasing (identical microsats are too rare)
// uses a unique approach to non-marker sites (different from SNPs)

void MSCalculator::Calculate() 
{
Branch *branch = NULL;
Branch *child = NULL;
Cell_ptr dlcell, child1DLCell, child2DLCell;
double length1 = 0.0; 
double length2 = 0.0; 
double totallike = 0.0;
long posn1, posn2, nsubtrees, tr, pos;
AlleleModel& datmodel = dynamic_cast<AlleleModel&>(datamodel);
DoubleVec1d scaled1, scaled2;

rangevector subtrees = tree->GetSubtrees();
nsubtrees = subtrees.size();

// Step through the subtrees to compute the data likelhoods
TimeList& timelist = tree->GetTimeList();
for (tr = 0; tr < nsubtrees; tr++) {
   rangepair markers = SitePairToMarkerPair(subtrees[tr]);
   if (markers.first == FLAGLONG) continue;  // no markers in this subtree 
   posn1 = markers.first;
   posn2 = markers.second;
   bool firstsubtree = (tr == 0);

   Branchiter brit;
   for (brit = timelist.BeginBody(); brit != timelist.End(); ++brit) {
      branch = *brit;
      if (branch->ShouldCalcDL(posn1)) {
         dlcell = branch->dlcell[0];
   // Find "real" children and appropriate branch lengths.
         child = branch->GetValidChild(branch->child[0],posn1);
         length1 = branch->HowFarTo(*child);
         child1DLCell = child->dlcell[0];
         child = branch->GetValidChild(branch->child[1],posn1);
         length2 = branch->HowFarTo(*child);
         child2DLCell = child->dlcell[0];

   // Precalculate branchlength terms 
         scaled1 = datmodel.RescaleLength(length1);
         scaled2 = datmodel.RescaleLength(length2);

   // Calculate the data likelihood at each position.
         for(pos = posn1; pos < posn2; ++pos) {
            datmodel.ComputeSiteDLs(child1DLCell,
               child2DLCell, dlcell, scaled1,
               scaled2, pos);
         }
      }
   }

   // Check the DLs for the subtree at the root, relies on flow through
   // to be at root.

   bool active0 = branch->child[0]->range.IsSiteActive(posn1);
   bool active1 = branch->child[1]->range.IsSiteActive(posn1);

   if (!active0 || !active1) {
     dlcell = branch->dlcell[0];
     Cell_ptr nullcell(new NullCell);
     // the root is a one-legged coalescence, was not done
     // above and must be done now
     if (!active0) {
       child1DLCell = nullcell;
       child = branch->GetValidChild(branch->child[1],posn1);
       child2DLCell = child->dlcell[0];
       length1 = MAX_LENGTH;
       length2 = branch->HowFarTo(*child);
     } else if (!active1) {
       child = branch->GetValidChild(branch->child[0],posn1);
       child1DLCell = child->dlcell[0];
       child2DLCell = nullcell;
       length1 = branch->HowFarTo(*child);
       length2 = MAX_LENGTH;
     }
 
     scaled1 = datmodel.RescaleLength(length1);
     scaled2 = datmodel.RescaleLength(length2);

     for (pos = posn1; pos < posn2; pos++) {
       datmodel.ComputeSiteDLs(child1DLCell,
         child2DLCell, dlcell, scaled1,
         scaled2, pos);
     }
   }

   totallike += datmodel.ComputeSubtreeDLs(*dlcell, dlcell->GetSiteDLs(posn1),
                   dlcell->GetSiteDLs(posn2), markerweights.begin()+posn1, posn1,
                   firstsubtree);
}

  // Calculate the total likelihood for the tree.
  // pass markerpos.size() for half-open interface

// oddly enough, the microsat likelihood can be 1, and sometimes is, so
// this assert is inappropriate.
//  assert(totallike != 0);  // this would be a likelihood=1, which is *too* likely

  tree->SetDLValue(totallike);

} /* MSCalculator::Calculate */

//___________________________________________________________________

rangepair MSCalculator::SitePairToMarkerPair(rangepair sites)
// This code is well-nigh identical to the SNP version (I wish I could
// combine them)
{
long firstmrkr = FLAGLONG;
long lastmrkr = FLAGLONG;
long firstsite = sites.first;
long lastsite = sites.second;

assert (firstsite < lastsite);

lastsite--;    // calling code assumes half-open intervals
long marker;
long nmarkers = markerpos.size();

// find first marker that is within site range, inclusive
for (marker = 0; marker < nmarkers; ++marker) {
  if (markerpos[marker] > lastsite) {    // we've passed the end
    return(rangepair(FLAGLONG,FLAGLONG));
  }
  if (markerpos[marker] >= firstsite) {  // found it
    firstmrkr = marker;
    break;
  }
}

// find first marker past the end of site range (which may be the
// non-existent marker after all markers; this is a half-open
// interval).

for (marker = nmarkers - 1; marker >= 0; --marker) {
  if (markerpos[marker] <= lastsite) {     
    lastmrkr = marker + 1;                   // found it; we return the
                                             // next marker for half-open
    break;
  }
}

assert(firstmrkr != FLAGLONG && lastmrkr != FLAGLONG);

return(rangepair(firstmrkr, lastmrkr));

} /* SitePairToMarkerPair */

//___________________________________________________________________
