//$Id: dlmodel.cpp,v 1.31 2002/06/26 19:11:52 lamarc Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcdebug.h"
#include "dlmodel.h"
#include "datapack.h"
#include "datatype.h"
#include "dlcell.h"
#include <assert.h>
#include "stringx.h"
#include "mathx.h"
#include <algorithm>
#include "errhandling.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;


//___________________________________________________________________________
//___________________________________________________________________________

DataModel::DataModel() 
: name("Base Data Model"),
  shortname("Base"),
  ncategories(1),
  catrates(1, 1.0),
  catprobs(1, 1.0),
  acratio(1.0),
  normalize(false),
  nbins(FLAGLONG),
  nmarkers(1)
{

  ucratio = 1.0 - acratio;

} /* DataModel constructor */

//___________________________________________________________________________

void DataModel::CopyAllMembers(const DataModel& src)
{

name        = src.name;
shortname   = src.shortname;
ncategories = src.ncategories;
catrates    = src.catrates;
catprobs    = src.catprobs;
acratio     = src.acratio;
ucratio     = src.ucratio;
normalize   = src.normalize;
nbins       = src.nbins;
nmarkers    = src.nmarkers;
catcells    = src.catcells;

} /* DataModel::CopyAllMembers */

//___________________________________________________________________________

bool DataModel::IsValid() const
{
  if (nbins < 1) return false;
  if (nmarkers < 1) return false;
  if (ncategories < 1) return false;
  unsigned long ncats = ncategories;
  if (catrates.size() != ncats) return false;
  if (catprobs.size() != ncats) return false;

  unsigned long i;
  double totalprob = 0.0;
  for (i = 0; i < ncats; ++i) {
    if (catrates[i] < 0.0) return false;
    if (catprobs[i] < 0.0) return false;
    if (catprobs[i] > 1.0) return false;
    totalprob += catprobs[i];
  }

  if (fabs(1.0 - totalprob) > EPSILON) return false;

  return true;

} /* IsValid */

//___________________________________________________________________________

StringVec1d DataModel::CreateDataModelReport() const
{

  StringVec1d report;
  string line;

  if (ncategories > 1) {
    line = ToString(ncategories) + " rate categories with correlated length " + 
      ToString(1.0 / acratio);
    report.push_back(line);
    long cat;
    for (cat = 0; cat < ncategories; ++cat) {
      line = "Relative rate " + ToString(catrates[cat]) + "  Frequency " +
        ToString(catprobs[cat]);
      report.push_back(line);
    }
  }

  return report;
} /* CreateDataModelReport */

//___________________________________________________________________________

void DataModel::Initialize(const Region& region)
// an "implemented pure virtual function"
{

nmarkers = region.GetNmarkers();

// We renormalize the category rates to a weighted mean of 1.0
double meanrate = 0.0;
unsigned long rate;

assert(catrates.size() == catprobs.size());

unsigned long numrates = catrates.size();

for (rate = 0; rate < numrates; ++rate) {
  meanrate += catrates[rate] * catprobs[rate];
}

for (rate = 0; rate < numrates; ++rate) {
  catrates[rate] /= meanrate;
}

} /* DataModel::Initialize */

//___________________________________________________________________________
//___________________________________________________________________________

NucModel::NucModel()
: DataModel()
{
  nbins = BASES;
} /* NucModel constructor */

//___________________________________________________________________________

bool NucModel::AcceptDataType(const string& datatype)
{
/* Nucleotide models can accept only DNA and SNP data types. */
  if (datatype == DNA) return true;
  if (datatype == SNP) return true;
  return false;

} /* NucModel::AcceptDataType */

//___________________________________________________________________________

/* This function implements the standard ambiguity codes for
   nucleotide data, returning a vector of four doubles indicating
   the likelihood for A, C, G, T in that order. */

vector<double> NucModel::DataToLikes(const string& datum, long) const {
  
// We assume this is a single nucleotide base, passed as a string 
// only for generality
  assert(datum.size() == 1);

  vector<double> likes(BASES, 0.0);  // initialize to zero
  char nucleotide = datum[0];

// resolve code

  switch(nucleotide)
  {
    case 'A':
      likes[baseA] = 1.0;
      break;

    case 'C':
      likes[baseC] = 1.0;
      break;

    case 'G':
      likes[baseG] = 1.0;
      break;

    case 'T':
    case 'U':
      likes[baseT] = 1.0;
      break;

    case 'M':
      likes[baseA] = 1.0;
      likes[baseC] = 1.0;
      break;

    case 'R':
      likes[baseA] = 1.0;
      likes[baseG] = 1.0;
      break;

    case 'W':
      likes[baseA] = 1.0;
      likes[baseT] = 1.0;
      break;

    case 'S':
      likes[baseC] = 1.0;
      likes[baseG] = 1.0;
      break;

    case 'Y':
      likes[baseC] = 1.0;
      likes[baseT] = 1.0;
      break;

    case 'K':
      likes[baseG] = 1.0;
      likes[baseT] = 1.0;
      break;

    case 'V':
      likes[baseA] = 1.0;
      likes[baseC] = 1.0;
      likes[baseG] = 1.0;
      break;

    case 'H':
      likes[baseA] = 1.0;
      likes[baseC] = 1.0;
      likes[baseT] = 1.0;
      break;

    case 'D':
      likes[baseA] = 1.0;
      likes[baseG] = 1.0;
      likes[baseT] = 1.0;
      break;

    case 'B':
      likes[baseC] = 1.0;
      likes[baseG] = 1.0;
      likes[baseT] = 1.0;
      break;

    case 'N':
    case 'O':
    case 'X':
    case '?':
    case '-':
      likes[baseA] = 1.0;
      likes[baseC] = 1.0;
      likes[baseG] = 1.0;
      likes[baseT] = 1.0;
      break;

    default:
      assert(false);    // how did an unknown nucleotide get past proofreading?
      break;
  }
  return(likes);

} /* DataToLikes */

//___________________________________________________________________________
//___________________________________________________________________________

F84Model::F84Model()
// set some potentially useful defaults
: NucModel(),
  freqa(0.25), freqc(0.25), freqg(0.25), freqt(0.25),
  ttratio(2.0),
  freqsfromdata(true),
  computed1(true), computed2(true),
  freqar(FLAGDOUBLE), freqcy(FLAGDOUBLE),
  freqgr(FLAGDOUBLE), freqty(FLAGDOUBLE),
  allones(NULL), 
  daughter1(NULL), daughter2(NULL), target(NULL)
{
  // reset the names from the base values
  name = "Felsenstein '84";
  shortname = "F84";

  // the vectors are assumed to be empty at this point

} /* F84Model::F84Model */

//___________________________________________________________________________

void F84Model::EmptyBuffers()
{

if (allones) {
  delete [] allones[0];
  delete [] allones;
}
if (daughter1) {
  delete [] daughter1[0];
  delete [] daughter1;
}
if (daughter2) {
  delete [] daughter2[0];
  delete [] daughter2;
}
if (target) {
  delete [] target[0];
  delete [] target;
}

} /* F84Model::EmptyBuffers */

//___________________________________________________________________________

DataModel* F84Model::Clone() const
{
  DataModel* newmodel = new F84Model(*this);
  return newmodel;
}

//___________________________________________________________________________

void F84Model::AllocateBuffers()
{

allones   = new double* [ncategories];
daughter1 = new double* [ncategories];
daughter2 = new double* [ncategories];
target = new double* [ncategories];
allones[0]   = new double [ncategories*BASES];
daughter1[0] = new double [ncategories*BASES];
daughter2[0] = new double [ncategories*BASES];
target[0] = new double [ncategories*BASES];
long cat;
for (cat = 0; cat < ncategories; ++cat) {
   allones[cat]   = allones[0] + cat*BASES;
   daughter1[cat] = daughter1[0] + cat*BASES;
   daughter2[cat] = daughter2[0] + cat*BASES;
   target[cat] = target[0] + cat*BASES;
   allones[cat][baseA] = 1.0;
   allones[cat][baseC] = 1.0;
   allones[cat][baseG] = 1.0;
   allones[cat][baseT] = 1.0;
}

} /* F84Model::AllocateBuffers */

//___________________________________________________________________________

F84Model::~F84Model()
{
// if the array does not exist we suppose that the object is
// not Finalized, and don't try any deallocations.
EmptyBuffers();

} /* F84Model::~F84Model */

//___________________________________________________________________________

void F84Model::CopyMembers(const F84Model& src)
{
NucModel::CopyAllMembers(src);

freqa     = src.freqa;
freqc     = src.freqc;
freqg     = src.freqg;
freqt     = src.freqt;
ttratio   = src.ttratio;
freqsfromdata = src.freqsfromdata;

freqar    = src.freqar;
freqcy    = src.freqcy;
freqgr    = src.freqgr;
freqty    = src.freqty;

// don't copy the data likelihood buffers

} /* F84Model::CopyMembers */

//___________________________________________________________________________

bool F84Model::IsValid() const
{
  if (!DataModel::IsValid()) return false;

  if (freqa < 0.0 || freqa > 1.0) return false;
  if (freqc < 0.0 || freqc > 1.0) return false;
  if (freqg < 0.0 || freqg > 1.0) return false;
  if (freqt < 0.0 || freqt > 1.0) return false;

  if (fabs(1.0 - (freqa + freqc + freqg + freqt)) > EPSILON) return false;
  if (ttratio <= 0.5) return false;

  return true;
} /* IsValid */

//___________________________________________________________________________

void F84Model::CopyBuffers(const F84Model& src)
{
xcatrates = src.xcatrates;
ycatrates = src.ycatrates;
expA1     = src.expA1;
expB1     = src.expB1;
expC1     = src.expC1;
expA2     = src.expA2;
expB2     = src.expB2;
expC2     = src.expC2;
dlBuffer4 = src.dlBuffer4;

EmptyBuffers();
AllocateBuffers();
memcpy(daughter1[0],src.daughter1[0],ncategories*BASES*sizeof(double));
memcpy(daughter2[0],src.daughter2[0],ncategories*BASES*sizeof(double));
memcpy(target[0],src.target[0],ncategories*BASES*sizeof(double));

} /* F84Model::CopyBuffers */

//___________________________________________________________________________

F84Model::F84Model(const F84Model& src)
 : allones(NULL), daughter1(NULL), daughter2(NULL), target(NULL)
{
CopyMembers(src);
if (src.daughter1) {  // do not try to copy the buffers if they are unallocated
  CopyBuffers(src);
}

} /* F84Model::copy constructor */

//___________________________________________________________________________

F84Model& F84Model::operator=(const F84Model& src)
{
CopyMembers(src);
if (src.daughter1) {  // do not try to copy the buffers if they are unallocated
  CopyBuffers(src);  
}

return *this;

} /* F84Model::operator= */

//___________________________________________________________________________

void F84Model::SetBaseFrequencies(const DoubleVec1d& bases)
{
freqa = bases[baseA];
freqc = bases[baseC];
freqg = bases[baseG];
freqt = bases[baseT];

} /* F84Model::SetBaseFrequencies */

//___________________________________________________________________________

DoubleVec1d F84Model::GetBaseFrequencies() const
{
DoubleVec1d bases(BASES);

bases[baseA] = freqa;
bases[baseC] = freqc;
bases[baseG] = freqg;
bases[baseT] = freqt;

return bases;

} /* F84Model::GetBaseFrequencies */

//___________________________________________________________________________

void F84Model::Initialize(const Region& region)
{
// take care of base class issues
NucModel::Initialize(region);


if (FreqsFromData()) {
  freqa = freqc = freqg = freqt = 0.0;

  double totalmarkers = 0.0;
  const vector<TipData>& tips = region.GetAllTipData();
  vector<TipData>::const_iterator tit;
  for (tit = tips.begin(); tit != tips.end(); ++tit) {
     StringVec1d data = tit->data;

     StringVec1d::const_iterator sit;
     for (sit = data.begin(); sit != data.end(); ++sit) {
       DoubleVec1d site = DataToLikes(*sit);
       double total = site[baseA]+site[baseC]+site[baseG]+site[baseT];
       freqa += site[baseA]/total;
       freqc += site[baseC]/total;
       freqg += site[baseG]/total;
       freqt += site[baseT]/total;
     }
     totalmarkers += nmarkers;
  }

  freqa /= totalmarkers;
  freqc /= totalmarkers;
  freqg /= totalmarkers;
  freqt /= totalmarkers;
}


} /* F84Model::Initialize */

//___________________________________________________________________________

void F84Model::Finalize()
{
double pur, pyr, ag, ct, m, n, x, y;
long cat;

pur    = freqa + freqg;
pyr    = freqc + freqt;
freqar = freqa / pur;
freqcy = freqc / pyr;
freqgr = freqg / pur;
freqty = freqt / pyr;

ag = freqa * freqg;
ct = freqc * freqt;
m  = ttratio * pur * pyr - (ag + ct);
n  = ag / pur + ct / pyr;

// code stolen from DNAMLK here
y = m / (m + n);
x = 1.0 - y;
double fracchange = y * (2.0 * freqa * freqgr + 2.0 * freqc * freqty)
  + x * (1.0 - freqa * freqa - freqc * freqc - freqg * freqg - freqt * freqt);
y /= - fracchange;
x /= - fracchange;

for (cat = 0; cat < ncategories; ++cat) {
   xcatrates.push_back(x*catrates[cat]);
   ycatrates.push_back(y*catrates[cat]);
}

// Allocate additional space for likelihood calculations.
expA1.insert(expA1.begin(),ncategories,0.0);
expA2.insert(expA2.begin(),ncategories,0.0);
expB1.insert(expB1.begin(),ncategories,0.0);
expB2.insert(expB2.begin(),ncategories,0.0);
expC1.insert(expC1.begin(),ncategories,0.0);
expC2.insert(expC2.begin(),ncategories,0.0);

AllocateBuffers();

double zero = 0.0;
dlBuffer4 = CreateVec2d(nmarkers,ncategories,zero);

} /* F84Model::Finalize */

//___________________________________________________________________________

void F84Model::RescaleLengths(double length1, double length2)
{
long cat;
double n;

if (length1 < MAX_LENGTH) {
   computed1 = true;

//   expA1.clear();
//   expB1.clear();
//   expC1.clear();
   for(cat = 0; cat < ncategories; cat++) {
      n = exp(length1 * xcatrates[cat]);
      expA1[cat] = 1.0 - n;
      expB1[cat] = n * exp(length1 * ycatrates[cat]);
      expC1[cat] = n - expB1[cat];
   }
} else
   computed1 = false;

if (length2 < MAX_LENGTH) {
   computed2 = true;

//   expA2.clear();
//   expB2.clear();
//   expC2.clear();
   for(cat = 0; cat < ncategories; cat++) {
      n = exp(length2 * xcatrates[cat]);
      expA2[cat] = 1.0 - n;
      expB2[cat] = n * exp(length2 * ycatrates[cat]);
      expC2[cat] = n - expB2[cat];
   }
} else
   computed2 = false;

} /* F84Model::RescaleLengths */

//___________________________________________________________________________

double** F84Model::ComputeSiteDLs(double** siteDLs1, double** siteDLs2)
{
double sumAll, sumPur, sumPyr;
long cat;

if (computed1) {
   for (cat = 0; cat < ncategories; ++cat) {
      double* catDLs1 = siteDLs1[cat];
      sumAll  = expA1[cat] *
                (freqa*catDLs1[baseA] + freqc*catDLs1[baseC] +
                 freqg*catDLs1[baseG] + freqt*catDLs1[baseT]);

      sumPur  = freqar*catDLs1[baseA] + freqgr*catDLs1[baseG];
      sumPyr  = freqcy*catDLs1[baseC] + freqty*catDLs1[baseT];

      double expC1cat = expC1[cat];
      daughter1[cat][baseA] = sumAll + expB1[cat]*catDLs1[baseA] +
                         expC1cat*sumPur;
      daughter1[cat][baseC] = sumAll + expB1[cat]*catDLs1[baseC] +
                         expC1cat*sumPyr;
      daughter1[cat][baseG] = sumAll + expB1[cat]*catDLs1[baseG] +
                         expC1cat*sumPur;
      daughter1[cat][baseT] = sumAll + expB1[cat]*catDLs1[baseT] +
                         expC1cat*sumPyr;
   }
} else {
   memcpy(daughter1[0],allones[0],ncategories*BASES*sizeof(double));
}

if (computed2) {
   for (cat = 0; cat < ncategories; cat++) {
      double* catDLs2 = siteDLs2[cat];
      sumAll  = expA2[cat] *
                (freqa*catDLs2[baseA] + freqc*catDLs2[baseC] +
                 freqg*catDLs2[baseG] + freqt*catDLs2[baseT]);

      sumPur  = freqar*catDLs2[baseA] + freqgr*catDLs2[baseG];
      sumPyr  = freqcy*catDLs2[baseC] + freqty*catDLs2[baseT];

      double expC2cat = expC2[cat];
      daughter2[cat][baseA] = sumAll + expB2[cat]*catDLs2[baseA] +
                              expC2cat*sumPur;
      daughter2[cat][baseC] = sumAll + expB2[cat]*catDLs2[baseC] +
                              expC2cat*sumPyr;
      daughter2[cat][baseG] = sumAll + expB2[cat]*catDLs2[baseG] +
                              expC2cat*sumPur;
      daughter2[cat][baseT] = sumAll + expB2[cat]*catDLs2[baseT] +
                              expC2cat*sumPyr;
   }
} else {
   memcpy(daughter2[0],allones[0],ncategories*BASES*sizeof(double));
}

for (cat = 0; cat < ncategories; cat++) {
   target[cat][baseA] = daughter1[cat][baseA] *
daughter2[cat][baseA];
   target[cat][baseC] = daughter1[cat][baseC] *
daughter2[cat][baseC];
   target[cat][baseG] = daughter1[cat][baseG] *
daughter2[cat][baseG];
   target[cat][baseT] = daughter1[cat][baseT] *
daughter2[cat][baseT];
}

#ifndef NDEBUG
// This is an expensive check for legality of the likelihood.
// The likelihood should never be zero at this point.
   double sum = 0.0;
   for (cat = 0; cat < ncategories; cat++)
      sum += target[cat][baseA] + target[cat][baseC] +
             target[cat][baseG] + target[cat][baseT];
   assert(sum != 0.0);
#endif

return target;

} /* F84Model::ComputeSiteDLs */

//___________________________________________________________________________

double F84Model::ComputeSubtreeDL(Cell& rootdls, double** startmarker,
   double** endmarker, DoubleVec1d::const_iterator markerweight, 
   long posn, bool first)
{
double total=0.0, subtotal;
double** marker;
long cat;
DoubleVec1d prior(ncategories);
long firstposn = posn;

for (marker = startmarker; marker != endmarker; 
     marker = rootdls.GetNextMarker(marker)) {
   subtotal = 0.0;

   for (cat = 0; cat < ncategories; cat++) {
      prior[cat] = freqa*marker[cat][baseA] +
                   freqc*marker[cat][baseC] +
                   freqg*marker[cat][baseG] +
                   freqt*marker[cat][baseT];

      subtotal += catprobs[cat] * prior[cat];
   }

   if (ShouldNormalize()) {
     total += (*markerweight) * (log(subtotal) + rootdls.GetNorms(posn));
   } else {
     total += (*markerweight) * log(subtotal);
   }
   ++markerweight;

   // de-normalization not needed here, since we are only interested in
   // the ratio
   if (ncategories > 1) {
      for (cat = 0; cat < ncategories; cat++)
         dlBuffer4[posn][cat] = prior[cat]/subtotal;
   }
   ++posn;
}

if (ncategories > 1) total += ComputeCatDL(firstposn, posn, first);
return total;

} /* F84Model::ComputeSubtreeDL */

//___________________________________________________________________________

double F84Model::ComputeCatDL(long startmarker, long endmarker, bool first)
{
double subtotal;
long marker, cat;

// DEBUG this is something of a hack, but it allows values to be
// saved across subtrees, which is critical in the SNP code.
if (first) {
  catcells.assign(ncategories, 1.0);
}
DoubleVec1d like = catcells;
DoubleVec1d nulike(ncategories);

for (marker = startmarker; marker != endmarker; ++marker) {
   subtotal = 0.0;
   for (cat = 0; cat < ncategories; cat++)
      subtotal += catprobs[cat] * like[cat];

   subtotal *= acratio;

   for (cat = 0; cat < ncategories; cat++)
      nulike[cat] = dlBuffer4[marker][cat] *
                       (subtotal + ucratio * like[cat]);

   // the following puts the nulike values into like.  It
   // also puts the like values into nulike, but we will not
   // be using values from nulike so we don't care.
   like.swap(nulike); 
}

subtotal = 0.0;
for (cat = 0; cat < ncategories; cat++)
   subtotal += catprobs[cat] * like[cat];

// the following puts the like values into catcells for
// long-term storage.  It also puts the catcells values into
// like, but we don't care.
catcells.swap(like);

return log(subtotal);

} /* F84Model::ComputeCatDL */

//___________________________________________________________________________

StringVec1d F84Model::CreateDataModelReport() const
{
StringVec1d report = DataModel::CreateDataModelReport();
string line;

line = "Base frequencies: " + ToString(freqa) + ", ";
line += ToString(freqc) + ", ";
line += ToString(freqg) + ", ";
line += ToString(freqt);
report.push_back(line);

line = "Transition/transversion ratio: " + ToString(ttratio);
report.push_back(line);


return report;

} /* F84Model::CreateDataModelReport */

//___________________________________________________________________________
//___________________________________________________________________________

AlleleModel::AlleleModel()
: DataModel()
{
  // no code yet
} /* AlleleModel constructor */

//___________________________________________________________________________

bool AlleleModel::AcceptDataType(const string& datatype)
{
/* Most allelic models can be used on microsat or electrophoretic data */
  if (datatype == MICROSAT) return true;
  if (datatype == ELECTRO) return true;
  return false;

} /* AlleleModel::AcceptDataType */

//___________________________________________________________________________

void AlleleModel::Finalize()
{
  double zero = 0.0;
  m_likes = CreateVec2d(nmarkers, ncategories, zero);
} /* AlleleModel::Finalize */

//___________________________________________________________________________

DoubleVec1d AlleleModel::RescaleLength(double length)
{
  long cat;
  DoubleVec1d scaled(ncategories);
  for (cat = 0; cat < ncategories; ++cat) {
    scaled[cat] = length * catrates[cat];
  }
  return scaled;

} /* AlleleModel::RescaleLengths */

//__________________________________________________________________

double AlleleModel::ComputeCatDL(long startmarker, long endmarker, bool first)
{
double subtotal;
long marker, cat;

   if (first) {
     catcells.assign(ncategories, 1.0);
   } 
   DoubleVec1d previous = catcells;
   DoubleVec1d current(ncategories, 0.0);

   for (marker = startmarker; marker != endmarker; ++marker) {
      subtotal = 0.0;
      for (cat = 0; cat < ncategories; cat++)
         subtotal += catprobs[cat] * previous[cat];

      subtotal *= acratio;

      for (cat = 0; cat < ncategories; cat++)
         current[cat] = m_likes[marker][cat] *
                          (subtotal + ucratio * previous[cat]);

      // This line puts the current values in previous cheaply.  We
      // don't care that it puts the previous values in current,
      // because current will be overwritten anyway.
      previous.swap(current);
   }

   subtotal = 0.0;
   for (cat = 0; cat < ncategories; cat++)
      subtotal += catprobs[cat] * previous[cat];


   catcells.swap(previous);

   return log(subtotal);

} /* AlleleModel::ComputeCatDL */

//___________________________________________________________________________
//___________________________________________________________________________

StepwiseModel::StepwiseModel()
: AlleleModel(),
  threshhold(10),
  allowance(5)
{
  // these are not in the initialization list because they must
  // overwrite the initialized base-class values

  nbins=DEFBINS;
  name="Stepwise";
} /* StepwiseModel constructor */

//___________________________________________________________________________

DataModel* StepwiseModel::Clone() const
{
  DataModel* newmodel = new StepwiseModel(*this);
  return newmodel;
}

//___________________________________________________________________________

StringVec1d StepwiseModel::CreateDataModelReport() const
{
StringVec1d report = DataModel::CreateDataModelReport();

return report;

} /* StepwiseModel::CreateDataModelReport */

//___________________________________________________________________________

bool StepwiseModel::AcceptDataType(const string& datatype)
{
/* The stepwise model can accept only microsatellite data. */
  if (datatype == MICROSAT) return true;
  return false;

} /* StepwiseModel::AcceptDataType */

//___________________________________________________________________________

vector<double> StepwiseModel::DataToLikes(const string& datum, long marker) const
{

  // WARNING DEBUG neither efficient nor safe....
  assert (!bincount.empty());
  assert (bincount[marker] <= nbins);

  if (datum == "?") {       // unknown data fills all bins with 1
    vector<double> result(nbins, 1.0);
    return result;
  } else {
    vector<double> result(nbins, 0.0);
    long allele;
    FromString(datum,allele);
    allele -= offset[marker];
    assert(allele >= 0 && allele < bincount[marker]);
    result[allele] = 1.0;
    return result;
  }

} /* DataToLikes */

//___________________________________________________________________________

void StepwiseModel::Initialize(const Region& region)
{
  AlleleModel::Initialize(region);    // handle base class issues

  nmarkers = region.GetNmarkers();
  long marker;
  unsigned long tip;

  // find the biggest and smallest allele for each marker
  // NB We assume that allele sizes are in number of repeats,
  // *not* base pair count or anything else, and that "missing
  // data" is coded as ?.

  vector<TipData> tips = region.GetAllTipData();
  long tipval;

  for (marker = 0; marker < nmarkers; ++marker) {
    bool real_allele = false;  // did we ever see a non-? allele
    long smallone = MAXLONG, largeone = 0;
    for (tip = 0; tip < tips.size(); ++tip) {
      // convert to number if possible;
      // do not count "unknown data" markers
      string allele = tips[tip].data[marker];
      if (allele == "?") continue;
      else {
        real_allele = true;
        FromString(allele, tipval);  // convert to long
      }
 
      if (tipval < smallone) smallone = tipval;
      if (tipval > largeone) largeone = tipval;
    }

    // if no non-? were ever found, use arbitrary values
    if (!real_allele) {
       smallone = 10; 
       largeone = 10;  
    }
    
    long newoffset = std::max(smallone - allowance, 0L);
    offset.push_back(newoffset);
    bincount.push_back(largeone + allowance + 1 - newoffset);
  }

  // Pre-calculate table of steps
  CalculateSteps();
  
} /* Initialize */

//__________________________________________________________________

/* Adaptation of Peter Beerli's microsatellite likelihood nuview_micro
   routine from Migrate. 
*/

void StepwiseModel::ComputeSiteDLs (Cell_ptr child1, Cell_ptr child2,
  Cell_ptr thiscell, const DoubleVec1d& vv1, const DoubleVec1d& vv2, long marker)
{

  long s, a, diff, cat;
  double x3m = -DBL_MAX;
  double pija1s, pija2s;

  double **xx1 = child1->GetSiteDLs(marker);
  double **xx2 = child2->GetSiteDLs(marker);

  double lx1 = child1->GetNorms(marker);
  double lx2 = child2->GetNorms(marker);

  assert(xx1 || xx2); // they can't both be NULL

// in case of a one-legged coalescence, copy values and return
  if (!xx1) {
    thiscell->SetSiteDLs(marker, xx2);
    thiscell->SetNorms(lx2, marker);
    return;
  }

  if (!xx2) {
    thiscell->SetSiteDLs(marker, xx1);
    thiscell->SetNorms(lx1, marker);
    return;
  }

  long smax = bincount[marker];

  // allocate temporary working space; 
  // OPTIMIZE should be done more cheaply!
  double **xx3;
  xx3 = new double*[ncategories * sizeof(double *)];
  xx3[0] = new double[ncategories * nbins * sizeof(double)];
  for (cat = 0; cat < ncategories; ++cat)
    xx3[cat]=xx3[0] + cat * nbins;


// compute the bin contents for each possible allele size
  for (s = 0; s < smax; s++)
    {
    for (cat = 0; cat < ncategories; ++cat) {
      pija1s = pija2s = 0.0;
      for (a = std::max (0L, s - threshhold); a < s + threshhold && a < smax; a++)
        {
          diff = labs (s - a);
          if (xx1[cat][a] > 0)
            {
              pija1s += Probability (vv1[cat], diff) * xx1[cat][a];
            }
          if (xx2[cat][a] > 0)
            {
              pija2s += Probability (vv2[cat], diff) * xx2[cat][a];
            }
        }
      xx3[cat][s] = pija1s * pija2s;

      if (xx3[cat][s] > x3m) x3m = xx3[cat][s];  // overflow protection
      }
    }

// normalize to further protect against overflow, if requested
  if (ShouldNormalize()) {
    if (x3m == 0.0)
      {
        thiscell->SetNorms(-DBL_MAX,marker);
      }
    else
      {
        for (s = 0; s < smax; s++) {
          for (cat = 0; cat < ncategories; ++cat) {
               xx3[cat][s] /= x3m;
          }
        }
        thiscell->SetNorms(log (x3m) + lx1 + lx2, marker);
      }
  }

  thiscell->SetSiteDLs(marker, xx3);

  delete[] xx3[0];
  delete[] xx3;
} /* ComputeSiteDLs */

//__________________________________________________________________

double StepwiseModel::ComputeSubtreeDLs(Cell& rootdls, double** startmarker,
   double** endmarker, DoubleVec1d::const_iterator markerweight, 
   long posn, bool first)
{

double total=0.0, subtotal;
double** marker;
long cat, bin;
long firstposn = posn;

for (marker = startmarker; marker != endmarker; 
     marker = rootdls.GetNextMarker(marker)) {
   subtotal = 0.0;
   DoubleVec1d buffer(ncategories, 0.0);

   for (cat = 0; cat < ncategories; ++cat) {
      for (bin = 0; bin < bincount[posn]; ++bin) {
        // NB:  We assume a flat allele frequency prior here.
        buffer[cat] += marker[cat][bin];
      }

      subtotal += catprobs[cat] * buffer[cat];
      assert(subtotal != 0);  // that would not be likely enough
   }

   total += (*markerweight) * (log(subtotal) + rootdls.GetNorms(posn));
   ++markerweight;

   assert (total != 0);  // that would be *too* likely

   if (ncategories > 1) {
      for (cat = 0; cat < ncategories; cat++)
         m_likes[posn][cat] = buffer[cat]/subtotal;
   }
   ++posn;
}

if (ncategories > 1) total += ComputeCatDL(firstposn, posn, first);
return total;

} /* StepwiseModel::ComputeSubtreeDLs */

//___________________________________________________________________________
//___________________________________________________________________________

/* Adaptation of Peter Beerli's prob_micro routine from 
   MIGRATE.  This routine computes the probability of
   a change of "diff" steps in time "t". 

   Mary Kuhner 2002/01/02
*/

double StepwiseModel::Probability (double t, long diff) const
{
  // if the difference is greater than allowed, probability is 0
  double summ = 0.0;
  if (diff >= threshhold)
    return summ;

  long k;
  double oldsum = 0.0;
  double logt = log (0.5 * t);
  for (k = diff; k < diff + threshhold; k++)
    {
      summ += exp (-t + logt * (2. * k - diff) - steps[diff][k - diff]);

      // quit if the contributions have become trivial
      if (fabs (oldsum - summ) < DBL_EPSILON) break;
      oldsum = summ;
    }
  return summ;
} /* prob_micro */

//_______________________________________________________________________

/* Adaptation of Peter Beerli's calculate_steps routine
   from MIGRATE.  This routine precomputes values needed
   by Probability, for speed. 
*/
void StepwiseModel::CalculateSteps ()
{
  long k, diff;
  DoubleVec1d tempvec;

  for (diff = 0; diff < threshhold; diff++)
    {
      tempvec.clear();
      for (k = 0; k < threshhold; k++)
        {
          tempvec.push_back(logfac (diff + k) + logfac (k));
        }
      steps.push_back(tempvec);
    }
} /* calculate_steps */

//___________________________________________________________________________
//___________________________________________________________________________

BrownianModel::BrownianModel()
: AlleleModel()
{
  name="Brownian";
  nbins=3;

} /* BrownianModel constructor */

//___________________________________________________________________________

DataModel* BrownianModel::Clone() const
{
  DataModel* newmodel = new BrownianModel(*this);
  return newmodel;
}

//___________________________________________________________________________

void BrownianModel::SetNormalize(bool norm)
{
assert(!norm); // Norm cannot be true for BrownianModels
} /* BrownianModel::SetNormalize */

//___________________________________________________________________________

bool BrownianModel::AcceptDataType(const string& datatype)
{
// This model is appropriate only for microsat data because it relies on
// ordering of alleles

  if (datatype == MICROSAT) return true;
  return false;

} /* AlleleModel::AcceptDataType */

//___________________________________________________________________________

vector<double> BrownianModel::DataToLikes(const string& datum, 
   long) const
{
  vector<double> result(nbins,0.0);

  if (datum == "?") {       // unknown data
     result[0] = 5.0;       // this is an arbitrary value
     result[1] = DBL_BIG;
     result[2] = 0.0;
  } else {
     FromString(datum,result[0]);
     result[1] = 0.0;
     result[2] = 0.0;
  }

  return result;

} /* DataToLikes */

//__________________________________________________________________

void BrownianModel::Initialize(const Region& region)
{
AlleleModel::Initialize(region);

} /* BrownianModel::Initialize */

//__________________________________________________________________
// Adaptation of Peter Beerli's nuview_brownian() from Migrate-1.2.4
// by Jon Yamato 2002/05/06

#define LOG2PIHALF -0.918938533204672741780329736406
                   /*N[Log[1/Sqrt[2 Pi]] ,30] */

void BrownianModel::ComputeSiteDLs(Cell_ptr child1, Cell_ptr child2, 
   Cell_ptr thiscell, const DoubleVec1d& vv1, const DoubleVec1d& vv2,
   long marker)
{
double mean1, mean2, xx1, xx2, c12, v1, v2, vtot, f1, f2;
double **c1dls = child1->GetSiteDLs(marker),
       **c2dls = child2->GetSiteDLs(marker);

assert (c1dls || c2dls); // one of these has to exist!

if (!c1dls) {
   thiscell->SetSiteDLs(marker,c2dls);
   return;
}

if (!c2dls) {
   thiscell->SetSiteDLs(marker,c1dls);
   return;
}

// temporary space needed for interface with dlcell::SetSiteDLs()
double **mydls = new double*[ncategories*sizeof(double*)];
mydls[0] = new double[ncategories*nbins*sizeof(double)];
long cat;
for(cat = 1; cat < ncategories; ++cat)
   mydls[cat] = mydls[0] + cat*nbins;

for (cat = 0; cat < ncategories; ++cat) {

   mean1 = c1dls[cat][0];
   xx1 = c1dls[cat][2];
   v1 = vv1[cat] + c1dls[cat][1];

   mean2 = c2dls[cat][0];
   xx2 = c2dls[cat][2];
   v2 = vv2[cat] + c2dls[cat][1];

   vtot = v1 + v2;

   // the weights are set reciprocally so that the value coming from
   // the shorter branch is given more weight.
   if (vtot > 0.0) f1 = v2/vtot;
   else f1 = 0.5;
   f2 = 1.0 - f1;

   mydls[cat][0] = f1*mean1 + f2*mean2;

   mydls[cat][1] = v1*f1;

   mydls[cat][2] = xx1 + xx2;

   c12 = (mean1-mean2)*(mean1-mean2) / vtot;
   mydls[cat][2] += std::min(0.0,-0.5 * (log(vtot)+c12) + LOG2PIHALF);
}

thiscell->SetSiteDLs(marker,mydls);

delete [] mydls[0];
delete [] mydls;

} /* BrownianModel::ComputeSiteDLs */

#undef LOG2PIHALF

//__________________________________________________________________

double BrownianModel::ComputeSubtreeDLs(Cell& rootdls, double** startmarker,
   double** endmarker, DoubleVec1d::const_iterator markerweight, 
   long posn, bool first)
{

// NB:  Brownian likelihoods are stored as logs!

double total=0.0, subtotal;
double** marker;
long cat;
long firstposn = posn;


for (marker = startmarker; marker != endmarker; 
     marker = rootdls.GetNextMarker(marker)) {

   if (ncategories > 1) {
     // in order to add up likelihoods over categories, we
     // must un-log them.  We normalize them first to avoid
     // underflow.

     DoubleVec1d buffer(ncategories, 0.0);
     subtotal = 0.0;

     double biggest = NEGMAX;

     for (cat = 0; cat < ncategories; ++cat) {
       if (marker[cat][2] > biggest) biggest = marker[cat][2];
     }

     for (cat = 0; cat < ncategories; ++cat) {
        buffer[cat] += exp(marker[cat][2] - biggest);
        subtotal += catprobs[cat] * buffer[cat];
     }

     for (cat = 0; cat < ncategories; cat++)
        m_likes[posn][cat] = buffer[cat]/subtotal;

     total += (*markerweight) * (log(subtotal) + biggest);

   } else {
     // if there is only one category, there is no
     // normalization and we MUST NOT un-log the likelihood
     // or it will underflow

     total += (*markerweight) * marker[0][2];
   }

   ++markerweight;
   ++posn;
}

if (ncategories > 1) total += ComputeCatDL(firstposn, posn, first);

return total;

} /* BrownianModel::ComputeSubtreeDLs */

//___________________________________________________________________________

StringVec1d BrownianModel::CreateDataModelReport() const
{
StringVec1d report = DataModel::CreateDataModelReport();

return report;

} /* BrownianModel::CreateDataModelReport */

//___________________________________________________________________________
//___________________________________________________________________________

// This free function creates an appropriate DataModel object given
// a string tag.

DataModel* CreateDataModel(string tag) 
{
if (tag == "F84") return new F84Model;
if (tag == "Stepwise") return new StepwiseModel;
if (tag == "Brownian") return new BrownianModel;
data_error e("Invalid data model " + tag + " requested");
throw e;
  
} /* CreateDataModel */

