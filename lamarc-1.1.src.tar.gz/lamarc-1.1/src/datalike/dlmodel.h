//$Id: dlmodel.h,v 1.18 2002/06/25 03:17:47 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/*********************************************************************
 DLModel is the key control class for polymorphism based on the
 type of data likelihood model in use.  It is subclassed based on
 model.
 
 A DataModel is an Abstract Factory (Design Patterns, pg 87)
 responsible for creating the data model output report.

 A DataModel also provides the implementation of a particular data
 likelihood model.  Exactly what needs to be provided is laid out in
 the appropriate DLCalculator class.  For example, each realization of
 a nucleotide based model must provide 4 functions:
 RescaleLengths(), ComputeSiteDLs(), ComputeSubtreeDL(),
 and ComputeCatDL();

 The DataToLikes() function allows input data to be translated to
 likelihoods in a model-appropriate way.

 Each DataModel should have a short tag (related to XML file reading,
 defined only in tip subclasses in the member function CheckTag()),
 and a textual name for its model.  Function AcceptDataModel() will, given
 the name of a data *type*, return whether the model can work for
 that type.

 The free function CreateDataModel creates an appropriate DataModel
 object from a string tag.  This function must be updated whenever
 a new DataModel subclass is added.

 NB:  Lamarc includes two similar, but distinct, ways of looking at
 data analysis.  Classes such as DataType and its dependencies 
 (DLCalculators, DLCells, etc.) classify the input data based on
 how it was generated (is it full DNA, SNPs, electrophoretic alleles,
 etc?)  DataModel, in contrast, classifies the data based on what
 model will be used to analyze it.  These hierarchies are distinct,
 because the same kind of data can be analyzed using different
 models (e.g. F84 versus GTR for DNA data) and the same model can
 occasionally be used for different kinds of data (e.g. F84 works
 for both DNA and SNPs).  However, they are far from independent,
 since any given model will only cover a few data types.

 Written by Jim Sloan, rewritten by Jon Yamato.
 winter 2001--removed Dialog factory capability--Mary Kuhner
 2002/01/02 moved DataToLikes into this class--Mary Kuhner

**************************************************************/

#ifndef DLMODEL
#define DLMODEL

#include <math.h>
#include <string>
#include <vector>
#include "vectorx.h"
#include "constants.h"
// for Cell_ptr type
#include "types.h"

// #include "datapack.h" within Initialize() for access to Region:
//    datatype, GetDataLength(), GetAllTipData()
// #include "dlcell.h" within ComputeTreeDL() for access to:
//    GetSiteDLs()

class Region;
class Cell;


//____________________________________________________________________
//____________________________________________________________________
// The Data model base class

class DataModel
{

protected:
string  name;
string  shortname;
long    ncategories;
DoubleVec1d catrates, catprobs;
double acratio, ucratio;
bool    normalize;
long    nbins;
long    nmarkers;
DoubleVec1d catcells;  // working storage for category computations

virtual void CopyAllMembers(const DataModel& src);
DataModel& operator=(const DataModel& src)  {CopyAllMembers(src); 
                                             return *this;};
DataModel(const DataModel& src)             {CopyAllMembers(src);};


public:
DataModel();
virtual ~DataModel()                         {};
virtual DataModel* Clone() const = 0;

// Data input
string GetDataModelName()                 const   {return name;};
string GetDataModelShortName()                 const   {return shortname;};
virtual bool CheckTag(const string& tag)               = 0;
virtual bool AcceptDataType(const string& datatype)    = 0;
virtual vector<double> DataToLikes(const string& datum, long marker = 0) const = 0;

// Access
long        GetNcategories()          const   {return ncategories;};
DoubleVec1d GetCatRates()             const   {return catrates;};
DoubleVec1d GetCatProbabilities()     const   {return catprobs;};
double      GetAcratio()              const   {return acratio;};
virtual bool ShouldNormalize()        const   {return normalize;};
long        GetNbins()                const   {return nbins;};

void SetNcategories(long ncategs)                    {ncategories = ncategs;};
void SetCatRates(const DoubleVec1d& crates)          {catrates = crates;};
void SetCatProbabilities(const DoubleVec1d& cprobs)  {catprobs = cprobs;};
void SetAcratio(double ac)                           {acratio = 1.0 / ac;
                                                      ucratio = 1.0 - acratio;};
virtual void SetNormalize(bool norm)                 {normalize = norm;};
// SNP support function, used in setting up the SNP invarmodel
void SetNmarkers(long nmark)                         {nmarkers = nmark;};

// Likelihood Calculation
virtual void Initialize(const Region& reg)    = 0;
virtual void Finalize()                       = 0;

// Factories

virtual StringVec1d      CreateDataModelReport() const;

// Validation
virtual bool IsValid()                        const;

};

//____________________________________________________________________
// Nucleotide model

class NucModel : public DataModel
{
protected:

NucModel& operator=(const NucModel& src) {CopyAllMembers(src);
                                          return *this;};
NucModel(const NucModel& src)            {CopyAllMembers(src);};

public:
NucModel();
virtual ~NucModel() {};

virtual void CopyAllMembers(const DataModel& src) { DataModel::CopyAllMembers(src); };

// Data input
virtual bool AcceptDataType(const string& datatype);
virtual vector<double> DataToLikes(const string& datum, long marker = 0) const;

// Data Likelihood Calculation
virtual void    RescaleLengths(double length1, double length2)      = 0;
virtual double** ComputeSiteDLs(double** siteDL1, double** siteDL2)      = 0;
virtual double  ComputeSubtreeDL(Cell& rootdls, double** startmarker,
                   double** endmarker, DoubleVec1d::const_iterator markerweights, 
                   long posn, bool first) = 0;
virtual double  ComputeCatDL(long startmarker, long endmarker, bool first) = 0;
virtual void Initialize(const Region& reg) { DataModel::Initialize(reg); };

};

//____________________________________________________________________
// Felsenstein '84 model

class F84Model : public NucModel
{
private:
// User-defined parameters
double freqa, freqc, freqg, freqt, ttratio;
bool freqsfromdata;

// Buffers for data likelihood calculation
bool        computed1, computed2;
double      freqar, freqcy, freqgr, freqty;
DoubleVec1d xcatrates, ycatrates;
DoubleVec1d expA1, expA2, expB1, expB2, expC1, expC2;
                                 // we own the following:
double **allones;                // used in memcpy(), ComputeSiteDL()
double **daughter1, **daughter2; // used in a memcpy(), ComputeCatDL()
double **target;                 // used as return storage, ComputeSiteDL()
                                 //    which is then used in a memcpy(),
                                 //    NucCell::SetSiteDLs()
DoubleVec2d dlBuffer4;           // dim: nmarkers * ncategories

void EmptyBuffers();
void AllocateBuffers();
void CopyMembers(const F84Model& src);
void CopyBuffers(const F84Model& src);

public:
F84Model();
virtual ~F84Model();
virtual DataModel* Clone() const;

F84Model& operator=(const F84Model& src);
F84Model(const F84Model& src);

// Data input
virtual bool CheckTag(const string &tag)  {return tag == "F84";};

// Access
void SetBaseFrequencies(const DoubleVec1d& bf);
void SetFreqsFromData(bool freqs = true)  {freqsfromdata = freqs;};
void SetTTratio(double tr)                {ttratio = tr;};

DoubleVec1d GetBaseFrequencies()  const;
double      FreqsFromData()       const {return freqsfromdata;};
double      GetTTratio()          const {return ttratio;};

// Data Likelihood Calculation
virtual void Initialize(const Region& reg);
virtual void Finalize();
virtual void     RescaleLengths(double length1, double length2);
virtual double** ComputeSiteDLs(double** siteDL1, double** siteDL2);
virtual double   ComputeSubtreeDL(Cell& rootdls, double** startmarker,
                    double** endmarker, DoubleVec1d::const_iterator markerweights,
                    long posn, bool first);
virtual double   ComputeCatDL(long startmarker, long endmarker, bool first);

// Factories
virtual StringVec1d      CreateDataModelReport() const;

// Validation
virtual bool IsValid() const;

};

//____________________________________________________________________
// Allele model

class AlleleModel : public DataModel
{
protected:
AlleleModel();
virtual ~AlleleModel() {};

// Data input
virtual bool AcceptDataType(const string& datatype);
virtual void Finalize();

DoubleVec2d m_likes;   // likelihoods:  marker x category

virtual void CopyAllMembers(const DataModel& src) { DataModel::CopyAllMembers(src); };

public:

virtual DoubleVec1d RescaleLength(double length);
virtual double ComputeCatDL(long startmarker, long endmarker, bool first);
virtual void Initialize(const Region& reg) { DataModel::Initialize(reg); };
virtual void ComputeSiteDLs(Cell_ptr child1, Cell_ptr child2, Cell_ptr thiscell, 
          const DoubleVec1d& vv1, const DoubleVec1d& vv2, long marker) = 0;
virtual double ComputeSubtreeDLs(Cell& rootdls, 
          double** startmarker, double** endmarker, 
          DoubleVec1d::const_iterator markerweight, long posn, bool first) = 0; 
};

//____________________________________________________________________
// Step wise model

class StepwiseModel : public AlleleModel
{
private:

LongVec1d offset;    // per marker, difference of least allele from 0
LongVec1d bincount;  // per marker, total number of usable bins
DoubleVec2d steps;   // pre-computed constants for mutations of various sizes: nbins x nbins
long threshhold;     // threshhold for allelic differences
long allowance;      // extra bins to each side of actual markers

// helper functions for likelihood
        double Probability(double t, long diff) const;
        void CalculateSteps();

public:
// accepting compiler constructed copy-ctor and operator=

StepwiseModel();
virtual ~StepwiseModel() {};
virtual DataModel* Clone() const;

// Data input 
virtual bool CheckTag(const string& tag)    {return tag == "STEPWISE";};
virtual bool AcceptDataType(const string& datatype); 

// don't call this before calling Initialize()!
virtual vector<double> DataToLikes(const string& datum, long marker = 0) const;

// Data Likelihood Calculation
virtual void Initialize(const Region&);
virtual void ComputeSiteDLs(Cell_ptr child1, Cell_ptr child2, Cell_ptr thiscell, 
          const DoubleVec1d& vv1, const DoubleVec1d& vv2, long marker);
virtual double ComputeSubtreeDLs(Cell& rootdls, 
          double** startmarker, double** endmarker, 
          DoubleVec1d::const_iterator markerweight, long posn, bool first); 

// Factories
virtual StringVec1d CreateDataModelReport() const;

};

//____________________________________________________________________
// Brownian model

class BrownianModel : public AlleleModel
{

protected:

public:
BrownianModel();
virtual ~BrownianModel()   {};
virtual DataModel* Clone() const;

virtual bool ShouldNormalize() const {return false;};
virtual void SetNormalize(bool norm);

// Data input
virtual bool CheckTag(const string& tag)    {return tag == "BROWNIAN";};
virtual bool AcceptDataType(const string& datatype);
virtual vector<double> DataToLikes(const string& datum, long marker = 0) const;

// Data Likelihood Calculation
virtual void Initialize(const Region& region);
virtual void ComputeSiteDLs(Cell_ptr child1, Cell_ptr child2, Cell_ptr thiscell, 
          const DoubleVec1d& vv1, const DoubleVec1d& vv2, long marker);
virtual double ComputeSubtreeDLs(Cell& rootdls, 
          double** startmarker, double** endmarker, 
          DoubleVec1d::const_iterator markerweight, long posn, bool first);

// Factories
virtual StringVec1d CreateDataModelReport() const;

};

//________________________________________________________________________
//________________________________________________________________________

// This free function creates an appropriate DataModel object given
// a string tag.

DataModel* CreateDataModel(string tag);

#endif
