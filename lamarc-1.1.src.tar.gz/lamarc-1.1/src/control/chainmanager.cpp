// $Id: chainmanager.cpp,v 1.9 2002/06/26 19:11:50 lamarc Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <fstream>
#include "chainmanager.h"
#include "chainout.h"
#include "chain.h"
#include "chainparam.h"
#include "datapack.h"
#include "treesum.h"
#include "chainsum.h"
#include "registry.h"
#include "tree.h"
#include "maximizer.h"
#include "likelihood.h"
#include "analyzer.h"
#include "runreport.h"
#include "outputfile.h"
#include "forcesummary.h"
#include "definitions.h"
#include "chainsum.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

const long TEMPSWAPMIN =  0; // triggers decrease of temperature interval
const long TEMPSWAPMAX = 10; // triggers increase of temperature interval

using namespace std;

//____________________________________________________________________

ChainManager::ChainManager(RunReport& runrep, Maximizer& maximize)
: totalsteps(0), currentsteps(0),
  chainparm(registry.GetChainParameters()),
  runreport(runrep), randomsource(registry.GetRandom()),
  maximizer(maximize), chainpack()
{
nregions = registry.GetDataPack().GetNRegions();
nreplicates = chainparm.GetNReps();
long chtype;
for(chtype = 0; chtype < NCHAINTYPES; ++chtype) {
   long steps = chainparm.GetNSamples(chtype) *
                chainparm.GetInterval(chtype) +
                chainparm.GetNDiscard(chtype);
   nsteps.push_back(steps);
   totalsteps += steps * nreplicates * chainparm.GetNChains(chtype);
}

multitemp = (chainparm.GetAllTemperatures().size() > 1);
if (multitemp) {
   long chunk;
   for(chtype = 0; chtype < NCHAINTYPES; ++chtype) {
      long interval = chainparm.GetTempInterval();
      LongVec1d chunks;
      for(chunk = interval; chunk <= nsteps[chtype]; chunk += interval) {
         chunks.push_back(interval);
         if (chunk != nsteps[chtype] && chunk+interval > nsteps[chtype])
            chunks.push_back(nsteps[chtype]-chunk);
      }
      chunksize.push_back(chunks);
   }
} else {
   for(chtype = 0; chtype < NCHAINTYPES; ++chtype) {
      LongVec1d chunks(1,nsteps[chtype]);
      chunksize.push_back(chunks);
   }
}

long region;
for(region = 0; region < nregions; ++region) {
   vector<ChainSummary*> repvec;
   long rep;
   for(rep = 0; rep < nreplicates; ++rep)
      repvec.push_back(new ChainSummary);
   chainsums.push_back(repvec);
}

} /* ChainManager::ChainManager */

//____________________________________________________________________

ChainManager::~ChainManager()
{
vector<vector<ChainSummary*> >::iterator region;
for(region = chainsums.begin(); region != chainsums.end(); ++region) {
   vector<ChainSummary*>::iterator rep;
   for(rep = region->begin(); rep != region->end(); ++rep) {
      delete *rep;
   }
}

} /* ChainManager::~ChainManager */

//____________________________________________________________________

void ChainManager::CreateChains()
{
DoubleVec1d temperatures = chainparm.GetAllTemperatures();
DoubleVec1d::iterator temp;
for(temp = temperatures.begin(); temp != temperatures.end(); ++temp) {
   Chain ch(randomsource,runreport,chainparm,*temp);
   temps.push_back(ch);
}
temps.front().SetSampling(true);
temps.back().SetBarprinting(true);

} /* ChainManager::CreateChains */

//____________________________________________________________________

void ChainManager::DoChain(long region, long rep, long chaintype,
   ForceParameters& chainstart)
{
const ForceSummary& forcesum = registry.GetForceSummary();
ChainParameters& chainparm = registry.GetChainParameters();

long chain;
 bool adapt = chainparm.GetTempAdapt();
for(chain = 0; chain < chainparm.GetNChains(chaintype); ++chain) {
   unsigned long temp, temp2, numtemps = temps.size();
   DoubleVec1d swaps;
   DoubleVec1d swapnums;
   DoubleVec1d currenttemps;
   for (temp = 0; temp < numtemps; ++temp) {
     currenttemps.push_back(0.0);
     for (temp2 = temp; temp2 < numtemps; ++temp2) {
       swaps.push_back(0.0);
       swapnums.push_back(0.0);
     }
   }
   if(!adapt)
     currenttemps = chainparm.GetAllTemperatures();
   for(temp = 0; temp < numtemps; ++temp)
      temps[temp].Start(chain,chaintype,forcesum,chainstart);
   unsigned long chunk;
   for(chunk = 0; chunk < chunksize[chaintype].size(); ++chunk) {
      long steps = chunksize[chaintype][chunk];
      for(temp = 0; temp < temps.size(); ++temp)
         temps[temp].Do(steps);
      if (multitemp) {  // propose a swap
        if(!adapt) //needs a menu setting, but currently adaptive is stupid
	  // and cannot cope with random pairs.
	  { 
	    long chain1 = randomsource.Integer(temps.size());
	    long chain2;
	    do {
	      chain2 = randomsource.Integer(temps.size());
	    } while (chain1 == chain2);
	    if (chain1 > chain2) std::swap(chain1, chain2);  // sort
	    ++swapnums[chain1*numtemps + chain2];
	    if (temps[chain1].SwapTrees(temps[chain2])) { 
	      ++swaps[chain1*numtemps + chain2];
	    }
	  }
	else
	  {
	    vector < pair<double,long> > temprow;
	    pair < double , long > pp;
	    vector < pair<double,long> > :: iterator tid ;
	    unsigned long i;
	    for(i=0; i <  temps.size(); i++)
	      {
		pp = make_pair<double,long>(temps[i].GetTemperature(),i);
		temprow.push_back(pp);
	      }
	    sort(temprow.begin(),temprow.end());
	    tid = temprow.begin();
	    long t = randomsource.Integer(temprow.size());
	    long chain1 = (tid + t)->second;
	    while(chain1==static_cast<long>(temps.size())-1)
	      {
		t = randomsource.Integer(temprow.size());
		chain1 = (tid + t)->second;
	      }
	    long chain2 = chain1 + 1;
	    ++swapnums[chain1*numtemps + chain2];
	    if (temps[chain1].SwapTrees(temps[chain2])) { 
	      ++swaps[chain1*numtemps + chain2];
	    }
	    AdjustTemperatures(currenttemps, temps, chunk, chunksize[chaintype].size());
	  }
      }
      currentsteps += steps;
   }

   // Post-processing on a chain
   
   // Figure out which is the cold chain; only that one gets 
   // postprocessed.

   unsigned long tindex;
   unsigned long cold = FLAGLONG;

   for(tindex = 0; tindex < temps.size(); ++tindex) {
     if (temps[tindex].IsCold()) {
       cold = tindex;
       break;      
     }
   }

   assert(static_cast<long>(cold) != FLAGLONG);  // there must be a cold chain!

   Chain& coldchain = temps[cold];

   ChainOut chout = coldchain.End();

   // adjust the summaries, unless this is the last chain
   if (chain != chainparm.GetNChains(chaintype) - 1) {
     chainsums[region][rep]->AdjustSummaries();
   }

   chainsums[region][rep]->forceParameters = chainstart;
   registry.GetSinglePostLike().Setup(chainsums[region][rep]);
   DoubleVec1d mleparam = chainstart.GetParameters(forcesum);
   double maxlike = maximizer.Calculate(mleparam);
   chainstart.SetParameters(maximizer.GetParameters(),forcesum);
   chout.SetLlikemle(maxlike);
   chout.SetEstimates(chainstart);
   chout.SetLlikedata(coldchain.GetCurrentDataLlike());
   
   chout.SetNumtemps(numtemps);
   for (temp = 0; temp < swaps.size(); ++temp) 
      if (swapnums[temp]) swaps[temp] /= swapnums[temp];
   chout.SetSwaprates(swaps);
   chout.SetTemperatures(currenttemps);

   chainpack.SetChain(chout);
   runreport.Prognose(chainpack, currentsteps, totalsteps);
   runreport.DisplayReport(chout);
}

} /* ChainManager::DoChain */

//____________________________________________________________________

void ChainManager::DoChainTypes(long region, long rep)
{
long chaintype;
const ForceSummary& forcesum = registry.GetForceSummary();
ForceParameters chainstart = forcesum.GetStartParameters();
for(chaintype = 0; chaintype < NCHAINTYPES; ++chaintype) {
   vector<Chain>::iterator temp;
   for(temp = temps.begin(); temp != temps.end(); ++temp)
      temp->SetChainType(chaintype,chainparm);
   DoChain(region, rep, chaintype, chainstart);
}

} /* ChainManager::DoChainTypes */

//____________________________________________________________________

void ChainManager::DoReplicates(long region)
{
const ForceSummary& forcesum = registry.GetForceSummary();
long rep;
for(rep = 0; rep < nreplicates; ++rep) {
   vector<Chain>::iterator temp;
   for(temp = temps.begin(); temp != temps.end(); ++temp)
      temp->StartReplicate(chainsums[region][rep],forcesum);
   maximizer.Setup(&(registry.GetSinglePostLike()));
   DoChainTypes(region,rep);
   for(temp = temps.begin(); temp != temps.end(); ++temp)
      temp->EndReplicate();
   chainpack.EndReplicate();
}

if (nreplicates > 1) {
   maximizer.Setup(&(registry.GetReplicatePostLike()));
   registry.GetReplicatePostLike().Setup(&chainsums[region]);
   DoubleVec1d meanparam = chainpack.RegionalMeanParams();
   double maxlike;
   maxlike = maximizer.Calculate(meanparam);
   ForceParameters fp;
   fp.SetParameters(maximizer.GetParameters(),forcesum);
/* warning WARNING -- no reporting
   ChainOut repout;
   repout.SetEstimates(fp);
   repout.SetLlikemle(maxlike);
   chainpack.SetSummaryOverReps(repout);
   runreport.DisplayReport(repout);
*/
}

} /* ChainManager::DoReplicates */

//____________________________________________________________________

void ChainManager::DoRegions()
{
vector<Chain>::iterator temp;
ForceSummary& forcesum = registry.GetForceSummary();

long region;
 Analyzer & analyzer = registry.GetAnalyzer();
for(region = 0; region < nregions; ++region) {
   vector<Tree*> regiontrees;
   Region& curregion = registry.GetDataPack().GetRegion(region);
   for(temp = temps.begin(); temp != temps.end(); ++temp) {
      Tree* regtr = curregion.CreateTree();
      temp->StartRegion(regtr);
      regiontrees.push_back(regtr);
   }
   // WARNING This should really be a run-reporter call!
   if (registry.GetUserParameters().GetProgress() != NONE)  {
     cout << "\nBeginning region: " + curregion.GetRegionName();
     cout << endl;
   }
   DoReplicates(region);
   vector<Tree*>::iterator tree = regiontrees.begin();
   for(temp = temps.begin(); temp != temps.end(); ++temp, ++tree) {
      temp->EndRegion();
      delete *tree;
   }
   // relies on the fact that the maximizer was successfully called
   // before
   analyzer.SetMaximizer(registry.GetMaximizerPtr());
   analyzer.SetPostLike();
   if (registry.GetForceSummary().GetOverallProfileType() != none)
     analyzer.CalcProfiles();
   ChainOut chout = chainpack.GetRegion(region);
   forcesum.SetRegionMLEs(chout);

   chainpack.EndRegion();
}

DLCell::ClearStore(); // static function called to clear datalikehood
                      // memory manager of final region

if (nregions > 1) {
   maximizer.Setup(&(registry.GetRegionPostLike()));
   registry.GetRegionPostLike().Setup(&chainsums);
   DoubleVec1d meanparam = chainpack.OverallMeanParams();
   double maxlike;
   maxlike = maximizer.Calculate(meanparam);

   ForceParameters fp;
   fp.SetParameters(maximizer.GetParameters(),forcesum);
   ChainOut regionout;
   regionout.SetEstimates(fp);
   regionout.SetLlikemle(maxlike);
   chainpack.SetSummaryOverRegions(regionout);
   forcesum.SetOverallMLE(regionout);
/* warning WARNING -- no reporting
   runreport.DisplayReport(regionout);
*/
}

} /* ChainManager::DoRegions() */

//____________________________________________________________________

void ChainManager::DoProfiles()
{

Analyzer & analyzer = registry.GetAnalyzer();
if(nregions>1) {
   analyzer.SetMaximizer(registry.GetMaximizerPtr());
   analyzer.SetPostLike();
   analyzer.CalcProfiles();
}

} /* ChainManager::DoProfiles */

//____________________________________________________________________

void ChainManager::Do()
{
CreateChains();
DoRegions();
// OBSOLETE
  //DoSumarizeRegions();
  // DoPlots();
DoProfiles();
  
OutputFile outputfile(registry,chainpack);
outputfile.Display();
 
} /* ChainManager::Do */

//____________________________________________________________________

// Adjusts the temperatures for the adaptive heating scheme
// every numsteps/10 step the scheme is adjusted.
// This scheme assumes that the chains are swapped between
// adjacent pairs [see ChainManager::HeatedPairSwap()].
// If there are less or equal than TEMPSWAPMIN [0] swaps in that pair
// the temperature difference is lowered by 0.9 [const double smaller]
// and all other temperatures are shifted. If the swap rate exceeds 
// TEMPSWAPMAX  [10] then the temperature raises by a factor of 1.1
// PB 2002
void ChainManager::AdjustTemperatures(DoubleVec1d & currenttemps, vector <Chain> & temps, long step, long numsteps)
{
  const double bigger = 1.1;
  const double smaller = 0.9;
  const long compareval = numsteps/10; 
  const long corrsum = 10;
  DoubleVec1d delta(temps.size());
  // adjust only every numsteps/10 step
  if(step % compareval == 0)
    {
      unsigned long i;
      // construct an ordererd list of temperatures with 
      // indicators to the chains
      vector < pair <double,long> > temprow;
      orderedTempChains(temprow, temps);
      //record used temperatures for reporting
      for(i=0; i <  temprow.size(); i++)
        currenttemps[i] += temps[temprow[i].second].GetTemperature()/corrsum;
      DoubleVec1d :: iterator did;
      long swapcount = 0;
      for(i=1, did = delta.begin(); i < temprow.size(); i++, did++)
	{
	  *did = temprow[i].first - temprow[i-1].first;
	  // debug purposes
	  // cout << temprow[i-1].first << "-" 
	  // << temprow[i].first << " " 
	  // << temps[temprow[i].second].GetSwapcount() << " " << *did << endl;
	}
      //      cout << endl;
      // Adjust the temperature differences
      for(i=0;i<temprow.size()-1;i++)
	{
	  swapcount = temps[temprow[i].second].GetSwapcount();
	  if( swapcount == TEMPSWAPMIN)
	    delta[i] *= smaller;
	  else if (swapcount > TEMPSWAPMAX)
	    delta[i] *= bigger;
	}
      //Set swap counter to zero, do not mix this with the
      // swap counter for reporting.
      for(i=0;i<temps.size();i++)
	temps[i].SetSwapcount(0);
      // Reset the temperatures according to the adjusted temp diffs
      temps[temprow[0].second].SetTemperature(1.);	  
      for(i=1;i<temprow.size();i++)
	temps[temprow[i].second].SetTemperature(temps[temprow[i-1].second].GetTemperature() + delta[i-1]);
    }
}
//____________________________________________________________________

// generates list of chains ordered by their temperature
// PB Feb2002
void ChainManager::orderedTempChains(vector < pair <double,long> > & temprow, 
		       const vector <Chain> & temps)
{
  unsigned long i;
  for(i=0; i <  temps.size(); i++)
    temprow.push_back(make_pair(temps[i].GetTemperature(),i));
  sort(temprow.begin(),temprow.end());
}


