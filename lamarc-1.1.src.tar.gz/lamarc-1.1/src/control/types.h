//$Id: types.h,v 1.8 2002/06/25 03:17:38 mkkuhner Exp $

#ifndef TYPES
#define TYPES

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <set>
#include <vector>
#include "vectorx.h"
#include <list>
#include <string>
#include <map>
#include <memory>
#include "smart_ptr.h"

class Branch;
class DataType;
class DataModel;
class Cell;
class triplet;

typedef boost::shared_ptr<Cell> Cell_ptr;
typedef std::pair<long,long>   wakestats;

typedef std::pair<long,long>   rangepair;
typedef std::set<rangepair>    rangeset;
typedef std::vector<rangepair> rangevector;

typedef std::pair<std::string,long> TagLine;

typedef std::map<std::string,long> NameIndex;
typedef std::map<std::string,DoubleVec2d> percentmap;     // DoubleVec2d dim:
                                                // pop X reg
typedef std::map<std::string,DoubleVec1d> overpercentmap; // DoubleVec1d dim:
                                                // dim: by pop

typedef std::map<std::string, std::pair<long, long> > ratemap; // acceptance rate per arranger

typedef std::list<Branch*>              Branchlist;
typedef Branchlist::iterator       Branchiter;
typedef Branchlist::const_iterator Branchconstiter;

typedef double*** cellarray;
typedef std::multimap<triplet, cellarray> FreeStore;
typedef std::map<string, long> BranchMap;

typedef boost::shared_ptr<DataType> DataType_ptr;
typedef boost::shared_ptr<DataModel> DataModel_ptr;

typedef std::pair<double, double> centilepair;

#endif
