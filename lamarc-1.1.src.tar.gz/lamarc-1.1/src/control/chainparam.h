//$Id: chainparam.h,v 1.3 2002/06/25 03:17:37 mkkuhner Exp $

#ifndef CHAINPARAMETERS
#define CHAINPARAMETERS

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************** 
 ChainParameters is a collection class used for internal communication
 throughout Lamarc.

 ChainParameters contains information needed to run chains, including
 managing the different arrangers.

 Written by Jim Sloan, revised by Mary Kuhner

Additions:
Peter 2002/02/11  SetTempAdapt/GetTempAdapt triggers adjustment
                  of temperatures according to swap-rate,
                  use of this is in Chainmanager::DoChain 
********************************************************************/

#include <vector>
#include "vectorx.h"
#include <stdlib.h>
#include "constants.h"

class Arranger;

// #include "arranger.h" for access to Arranger::dtor in 
//                       ChainParameters::dtor

//____________________________________________________________________
//____________________________________________________________________

class ChainParameters
{
    vector<Arranger*> arrangers;  // we own this

    vector<double> temperatures; // sorted in ascending order
    long         tempinterval;   // how often to swap between heated chains
    bool         tempadapt;      // adpative change of the temperatures
    vector<long> nChains;
    vector<long> nSamples;
    vector<long> interval;
    vector<long> nDiscard;
    long nreps;

    void CopyAllMembers(const ChainParameters&);

  public:
                     ChainParameters();
                     ~ChainParameters();
                     ChainParameters(const ChainParameters& src); 
    ChainParameters& operator=(const ChainParameters& src);           

    // Set Functions
    void AddArranger(Arranger *ar);

    void SetAllTemperatures(const DoubleVec1d& n) { temperatures = n; };
    void SetTempInterval(const long& n)  { tempinterval = n; };
    void SetTempAdapt(const bool& n)  { tempadapt = n; };
    void SetNChains(long i, long n)          { nChains[i]  = n; };
    void SetNSamples(long i, long n)         { nSamples[i] = n; };
    void SetInterval(long i, long n)         { interval[i] = n; };
    void SetNDiscard(long i, long n)         { nDiscard[i] = n; };
    void SetNReps(long n)                    { nreps = n; };
    void ClearAllArrangers();

    // Get Functions
    vector<Arranger*> GetAllArrangers() const { return arrangers; };

    long GetTempInterval()             const { return tempinterval; };
    bool GetTempAdapt()                const { return tempadapt; };
    double GetTemperature(long i)      const { return temperatures[i]; };
    DoubleVec1d GetAllTemperatures()   const { return temperatures; };
    long GetNChains(long i)            const { return nChains[i]; };
    long GetNSamples(long i)           const { return nSamples[i]; };
    long GetInterval(long i)           const { return interval[i]; };
    long GetNDiscard(long i)           const { return nDiscard[i]; };
    long GetNReps()                    const { return nreps; };

    // Validation
    bool IsValid()                     const;

};


// This free function throws an exception of type data_error
// and containing the specified message.  It's meant only as
// a convenience.

void DoError(const string& what);

#endif
