#ifndef __DEFINITIONS_H__
#define __DEFINITIONS_H__

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// DEFINED stuff
//
// Peter Beerli
// $Id: definitions.h,v 1.2 2002/06/25 03:17:37 mkkuhner Exp $
//
#ifndef DBL_MAX
#define DBL_MAX (static_cast<double>(1.7976931348623157e308))
#endif
#ifndef EPSILON
#define EPSILON         0.000001
#endif
//#ifndef NORMEPSILON
//#define NORMEPSILON         0.00001
//#endif
const double NORMEPSILON=0.00001;
#ifndef DBL_EPSILON
#define DBL_EPSILON 2.2204460492503131e-14
#endif
#ifndef NEGMAX
#define NEGMAX -DBL_MAX		// this definition depends on DBL_MAX
#endif
#ifndef EXPMIN
#define EXPMIN -50
#endif
#ifndef EXPMAX
#define EXPMAX 200
#endif
#ifndef DBL_BIG
#define DBL_BIG (static_cast<double>(1.0e300))
#endif
#ifndef MAXLONG
#define MAXLONG (static_cast<long>(32000))
#endif

#include "conf.h"

#define MAX(A,B) (((A) > (B)) ? (A) : (B))

#endif /*__DEFINITONS_H__*/
