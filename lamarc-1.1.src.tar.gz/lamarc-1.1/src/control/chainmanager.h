// $Id: chainmanager.h,v 1.7 2002/06/25 03:17:36 mkkuhner Exp $
/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// The ChainManager is one of the big persistent objects in Lamarc.  It
// is expected to exist from the end of the intial factory phase til
// after the last output report is displayed to the user.
//
// The ChainManager is primarily responsible for providing runtime user
// output (through a RunReport), for managing the interface between the
// posterior likelihood calculator/maximizer and the running chains,
// and for providing end of program user output (through an
// OutputFile).  It is also responsible for taking the user's input
// on chain length and refactoring it for use by its stable of Chains.
//
// It owns the 2 big collections of chain output: the ChainPack, which
// goes to user output; and a STL container of ChainSummaries that is
// utilized by the posterior likelihood calculator.

#ifndef CHAINMAN
#define CHAINMAN

#include <vector>
#include "vectorx.h"
#include "constants.h"
#include "chainpack.h"
#include "plotstat.h"

// #include "datapack.h" -- for number of regions in ctor
//                          for GetRegion(), CreateTree() in DoRegions()
// #include "chainsum.h" -- for ChainSummary ctor in ctor
//                             ChainSummary dtor in dtor
// #include "registry.h" -- for generalized registry access
// #include "tree.h" -- for tree dtor in DoRegions()
// #include "likelihood.h" -- for SinglePostLike::Setup() in DoChain()
// #include "maximizer.h" -- for Calculate() in DoChain()
//                               Setup() in DoReplicates()
// #include "chainout.h" -- for SetEstimates(), SetLlikeMle() in DoRegions()

class Random;
class RunReport;
class ChainParameters;
class ChainSummary;
class Chain;
class Maximizer;

class ChainManager
{
private:
long nregions, nreplicates;
bool multitemp;
LongVec1d nsteps;            // dim: chaintype
LongVec2d chunksize;         // dim: chaintype X chunk
vector<Chain> temps;         // dim: temperatures
vector<vector<ChainSummary*> > chainsums; // dim: region X replicates
                                          // we own what this points to
long totalsteps, currentsteps; // used for completion-time prognosis

const ChainParameters& chainparm;
RunReport& runreport;
Random& randomsource;
Maximizer& maximizer;
ChainPack chainpack;

ChainManager();                                   // undefined
ChainManager(const ChainManager& src);            // undefined
ChainManager& operator=(const ChainManager& src); // undefined

void CreateChains();
void DoRegions();
void DoReplicates(long region);
void DoChainTypes(long region, long rep);
void DoChain(long region, long rep, long chaintype, 
   ForceParameters& chainstart);

// Adjusts the temperatures for the adaptive heating scheme
// every numsteps/10 step the scheme is adjusted.
// This scheme assumes that the chains are swapped between
// adjacent pairs [see ChainManager::HeatedPairSwap()].
// If there are less or equal than TEMPSWAPMIN [0] swaps in that pair
// the temperature difference is lowered by 0.9 [const double smaller]
// and all other temperatures are shifted. If the swap rate exceeds 
// TEMPSWAPMAX  [10] then the temperature raises by a factor of 1.1 [PB02/2002]
 void AdjustTemperatures(DoubleVec1d & currenttemps, vector <Chain> & temps, long step, long numsteps);
// generates list of chains ordered by their temperature
 void orderedTempChains(vector < std::pair <double,long> > & temprow, 
			const vector <Chain> & temps);

public:
ChainManager(RunReport& runrep, Maximizer& maximize);
~ChainManager();
void Do();
 void DoProfiles();
};

#endif

