//$Id: chainparam.cpp,v 1.4 2002/06/25 03:17:37 mkkuhner Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "chainparam.h"
#include "arranger.h"
#include "errhandling.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//___________________________________________________________________________
//___________________________________________________________________________

ChainParameters::ChainParameters()
// set some hopefully useful defaults
: temperatures(1L, 1.0),
  tempinterval(1L),
  tempadapt(false),
  nChains(NCHAINTYPES),
  nSamples(NCHAINTYPES),
  interval(NCHAINTYPES),
  nDiscard(NCHAINTYPES),
  nreps(DEF_REPLICATES)
{
  nChains[0] = DEF_INIT_NCHAINS;
  nChains[1] = DEF_FINAL_NCHAINS;
  nSamples[0] = DEF_INIT_NSAMPLES;
  nSamples[1] = DEF_FINAL_NSAMPLES;
  interval[0] = DEF_INIT_INTERVAL;
  interval[1] = DEF_FINAL_INTERVAL;
  nDiscard[0] = DEF_INIT_DISCARD;
  nDiscard[1] = DEF_FINAL_DISCARD;
}

//___________________________________________________________________________

ChainParameters::~ChainParameters()
{
vector<Arranger*>::iterator arit;
for(arit = arrangers.begin(); arit != arrangers.end(); ++arit)
   delete *arit;

} /* ChainParameters::~ChainParameters */

//___________________________________________________________________________

ChainParameters::ChainParameters(const ChainParameters& src)
{
  CopyAllMembers(src);
} /* ChainParameters copy constructor */

//___________________________________________________________________________

ChainParameters& ChainParameters::operator=(const ChainParameters& src)
{
  if (&src != this) CopyAllMembers(src);
  return(*this);
} /* ChainParameters operator= */

//___________________________________________________________________________

void ChainParameters::CopyAllMembers(const ChainParameters &cp)
{
  // WARNING:  NOT SAFE in case of self-assignment, needs a check in
  // calling code.

  // delete any old arrangers
  ClearAllArrangers();

  // clone the source arrangers
  vector<Arranger*>::const_iterator cit;
  for (cit = cp.arrangers.begin(); cit != cp.arrangers.end(); ++cit) {
    Arranger* ar = (*cit)->Clone();
    arrangers.push_back(ar);
  }

  temperatures = cp.temperatures;
  tempinterval = cp.tempinterval;
  tempadapt = cp.tempadapt;

  nChains    = cp.nChains;
  nSamples   = cp.nSamples;
  interval   = cp.interval;
  nDiscard   = cp.nDiscard;

  nreps = cp.nreps;
}

//___________________________________________________________________________

void ChainParameters::ClearAllArrangers()
{
  vector<Arranger*>::iterator it;
  for (it = arrangers.begin(); it != arrangers.end(); ++it) {
    delete *it;
  }
  arrangers.clear();

} /* ClearAllArrangers */

//___________________________________________________________________________

void ChainParameters::AddArranger(Arranger *ar)
{
  arrangers.push_back(ar);

} /* AddArranger */

//___________________________________________________________________________

// This function makes sure that the ChainParameters object
// contains legal values and that all essential information is
// present.  It actually only returns true; it throws an exception
// if something is wrong.  It is meant to be called after all
// user input has completed; we assume that errors at this stage
// are unrecoverable.

bool ChainParameters::IsValid() const
{
  unsigned long i;  // generic counter
  unsigned long nchaintypes = NCHAINTYPES; // to avoid type warnings

  // are the arrangers okay?
  if (arrangers.size() < 1) DoError("At least one arranger must be specified.");
  if (!arrangers[0]->IsResimArranger()) 
    DoError("The first arranger must be a Resimulating arranger.");

  // are the temperatures okay?
  if (temperatures.size() < 1) 
    DoError("At least one temperature must be specified.");
  if (temperatures[0] != 1.0) 
    DoError("Lowest temperature must be 1");
  for (i = 0; i < temperatures.size(); ++i) {
    if (temperatures[0] < 0.0) DoError("Temperature is negative");
  }

  // are the chains okay?
  if (nChains.size() != nchaintypes) 
    DoError("Inconsistent number of chains.");
  if (nSamples.size() != nchaintypes)
    DoError("Inconsistent number of samples.");
  if (interval.size() != nchaintypes)
    DoError("Inconsistent number of sampling intervals.");
  if (nDiscard.size() != nchaintypes)
    DoError("Inconsistent number of steps to discard.");

  bool anychains = false;
  for (i = 0; i < nchaintypes; ++i) {
    if (nChains[i] < 0) DoError("Illegal number of chains.");
    if (nChains[i] > 0) anychains = true;
    if (nSamples[i] < 0) DoError("Illegal number of samples.");
    if (interval[i] < 0) DoError("Illegal sampling interval.");
    if (nDiscard[i] < 0) DoError("Illegal discard number.");
  }

  if (!anychains) DoError("No chains specified.");

  // are the replicates okay?
  if (nreps < 1) DoError("At least one replicate is required.");

  return true;

} /* IsValid */

//____________________________________________________________________

void DoError(const string& what) {
  data_error e(what);
  throw e;
}
