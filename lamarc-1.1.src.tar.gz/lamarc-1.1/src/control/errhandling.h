//$Id: errhandling.h,v 1.2 2002/06/25 03:17:37 mkkuhner Exp $

#ifndef ERRHANDLING
#define ERRHANDLING

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <stdexcept>
#include <string>

using namespace std;

/**************************************************************
 This file contains all exception classes defined for this
 program.  For all of these exceptions, the public function
 what() can be called to get a string describing the error.

 Please remember to catch exceptions by reference, not by value, 
 lest you slice them.

 Mary Kuhner      March 18, 2001
**************************************************************/

//--------------------------------------------------------------
// Data reading exceptions
//______________________________________________________________

class data_error : public exception {
private:
  string _what;
public:
  data_error(const string& wh): _what (wh) { };
  virtual ~data_error() throw() {};
  virtual const char* what () const throw() { return _what.c_str (); };
};

//______________________________________________________________

class file_error : public data_error {
// failure to read a necessary file
public:
  file_error(const string& wh) : data_error(wh) { };
  virtual ~file_error() throw() {};
};

//______________________________________________________________

class incorrect_data : public data_error {
// XML did not contain required information
public:
  incorrect_data(const string& wh) : data_error(wh) { };
  virtual ~incorrect_data() throw() {};
};

//______________________________________________________________

class incorrect_xml : public data_error {
// XML was syntactically incorrect
public:
  incorrect_xml(const string& wh) : data_error(wh) { };
  virtual ~incorrect_xml() throw() {};
};

//______________________________________________________________

class invalid_sequence : public data_error {
// invalid genetic data
public:
  invalid_sequence(const string& wh) : data_error(wh) { };
  virtual ~invalid_sequence() throw() {};
};

//--------------------------------------------------------------
// Too-many-events exceptions (the tree has gotten bloated)
//______________________________________________________________

class overrun_error : public exception {
private:
  string _what;
public:
  overrun_error(const string& wh) : _what(wh) { };
  virtual ~overrun_error() throw() {};
  virtual const char* what () const throw() { return _what.c_str (); };
};

//______________________________________________________________

class coal_overrun : public overrun_error {
public:
  coal_overrun(const string& wh = "Too many coalescences") :
    overrun_error(wh) { };
  virtual ~coal_overrun() throw() {};
};

//______________________________________________________________

class rec_overrun : public overrun_error {
public:
  rec_overrun(const string& wh = "Too many recombinations") :
    overrun_error(wh) { };
  virtual ~rec_overrun() throw() {};
};

//______________________________________________________________

class mig_overrun : public overrun_error {
public:
  mig_overrun(const string& wh = "Too many migrations") :
    overrun_error(wh) { };
  virtual ~mig_overrun() throw() {};
};

//--------------------------------------------------------------
// The denovo tree cannot be constructed (probably due to deeply
// unreasonable parameter values)
//______________________________________________________________

class denovo_failure : public overrun_error {
private:
  string _what;
public:
  denovo_failure(const string& wh = "Can't generate denovo tree") :
    overrun_error(wh) { };
  virtual ~denovo_failure() throw() {};
};

#endif
