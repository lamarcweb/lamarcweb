// $Id: userparam.cpp,v 1.3 2002/06/25 03:17:38 mkkuhner Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <time.h>
#include "userparam.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif
//___________________________________________________________________________
//___________________________________________________________________________

UserParameters::UserParameters()
{
  // we establish defaults for the user parameters here.
  // they can be overriden both by the data file and by
  // the menu.

  datafilename = "infile";
  paramfilename = "parmfile";
  resultsfilename = "outfile";
  treesumfilename = "sumfile";

  verbosity      = NORMAL;
  progress       = NORMAL;
  echoData       = false;
  plotPost       = false;
  //  profilePost    = false;

  // there is a default for randomSeed that comes from the clock
  // to fend off naive users running the same case over and over.
  // time(NULL)/4 strips the remainder, then 4x =>
  // we guarantee a number of the type 4N+1
  randomSeed = 4 * ( time(NULL)/4 ) + 1;
}

//___________________________________________________________________________

UserParameters::UserParameters(const UserParameters& src)
{
  CopyAllMembers(src);

} /* UserParameters copy constructor */
//___________________________________________________________________________

UserParameters& UserParameters::operator=(const UserParameters& src)
{
  CopyAllMembers(src);
  return(*this);

} /* UserParameters operator= */

//___________________________________________________________________________

void UserParameters::CopyAllMembers(const UserParameters &up)
{
  datafilename     = up.datafilename;
  paramfilename    = up.paramfilename;
  resultsfilename  = up.resultsfilename;
  treesumfilename  = up.treesumfilename;

  verbosity        = up.verbosity;
  progress         = up.progress;
  echoData         = up.echoData;
  plotPost         = up.plotPost;
  //  profilePost  = up.profilePost;

  randomSeed       = up.randomSeed;
}

//___________________________________________________________________________

bool UserParameters::IsValid() const
{

  if (verbosity != CONCISE && verbosity != NORMAL && verbosity != VERBOSE)
    return false;

// there is really nothing else to check!

  return true;

} /* IsValid */

//____________________________________________________________________________
