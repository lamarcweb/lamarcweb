/* conf.h.  Generated automatically by configure.  */

/* this files wil be overwritten when using configure 
   with the content of conf.h.in and the configure output
   $Id: conf.h.in,v 1.2 2001/12/06 22:04:18 beerli Exp $	
 conf.h.in.  Generated automatically from configure.in by autoheader.  */

#ifndef VERSION
#define VERSION "1.0"
#endif


/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define if you have the strftime function.  */
#define HAVE_STRFTIME 1

/* Define as __inline if that's what the C compiler calls it.  */
/* #undef inline */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if your <sys/time.h> declares struct tm.  */
/* #undef TM_IN_SYS_TIME */

/* Define if you have the lgamma function.  */
#define HAVE_LGAMMA 1

/* Define if you have the strcspn function.  */
#define HAVE_STRCSPN 1

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1
