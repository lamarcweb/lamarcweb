// $Id: chainout.h,v 1.3 2002/06/25 03:17:36 mkkuhner Exp $

#ifndef CHAINOUT
#define CHAINOUT

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/********************************************************************
 Class ChainOut contains summary information about the results of
 a chain, such as the acceptance rate, parameter estimates, and
 start/end times.  It does *not* contain the summary trees, which
 are stored separately in a ChainSummary object.

 ChainOut objects are normally stored and organized in the ChainPack.
 They can reasonably be passed by value as they are fairly small,
 simple objects.

 ChainOut has ChainPack as a friend, since the two classes are
 tightly coupled.  This would be fairly easy to change if desired.

 Written by Mary Kuhner
*********************************************************************/

#include <time.h>
#include <string>
#include <map>
#include "types.h"
#include "forceparam.h"

class ChainOut {

private:

void CopyAllMembers(const ChainOut &src);  // common to copy cons. and op=

// chain information
long badtrees;               // number of trees discarded due to limits
double accrate;              // overall acceptance rate
ratemap rates;               // acceptance rate per arranger
long numtemps;               // number of temperatures
DoubleVec1d swaprates;       // heating swap rates as linearized vector
DoubleVec1d temperatures;    // average temperatures [adaptive/static]

// Timing information
// Type "time_t" is a C library type which holds time information
// (in seconds since 1970)
time_t starttime;
time_t endtime;

// chain MLE's
ForceParameters estimates;       // Maximum likelihood estimates
double llikemle;                 // posterior lnL at maximum
double llikedata;                // data lnL of last generated tree in chain


public:

ChainOut();
ChainOut(const ChainOut &src);
virtual ~ChainOut() {};

virtual ChainOut &operator=(const ChainOut &src);

// friendship to allow direct access to member variables
// for these two tightly coupled classes
friend class ChainPack;

// Inspector functions
long            GetNumBadTrees()   const {return badtrees;};
double          GetAccrate()       const {return accrate;};
ratemap         GetAllAccrates()   const {return rates;};
long            GetNumtemps()      const {return numtemps;};
DoubleVec1d     GetSwaprates()     const {return swaprates;};
DoubleVec1d     GetTemperatures()  const {return temperatures;};
double          GetLlikemle()      const {return llikemle;};
double          GetLlikedata()     const {return llikedata;};
ForceParameters GetEstimates()     const {return estimates;};

time_t          GetStarttime()     const {return starttime;};
time_t          GetEndtime()       const {return endtime;};

// Mutator functions
void SetNumBadTrees(const long &nbad)          {badtrees = nbad;};
void SetAccrate(const double &arate)           {accrate = arate;};
void SetAllAccrates(const ratemap &arates)     {rates = arates;};
void SetNumtemps(const long &ntemps)           {numtemps = ntemps;};
void SetSwaprates(const DoubleVec1d &rates)    {swaprates = rates;};
void SetTemperatures(const DoubleVec1d &temps) {temperatures = temps;};
void SetLlikemle(const double &src)            {llikemle = src;};
void SetLlikedata(const double &src)           {llikedata = src;};
void SetEstimates(const ForceParameters &src)  {estimates = src;};

void SetStarttime(const time_t &src)           {starttime = src;};
void SetEndtime(const time_t &src)             {endtime = src;};

// The following two overloads set the time to the current time,
// gotten from the system clock.
void SetStarttime();
void SetEndtime();

};

#endif
