// $Id: constants.h,v 1.16 2002/06/26 19:11:50 lamarc Exp $

#ifndef CONSTANTS
#define CONSTANTS

#ifdef __MWERKS__
#ifndef VERSION
#define VERSION 1.1
#endif
#endif
/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
using std::string;

/***************************************************************
  This file contains constants which control the behavior of
the program.  They are divided into sections:

(1)  Constants which the user may wish to change, in order
     to adapt the program to his/her needs
(2)  Debugging constants which the user should probably not
     change unless sure of his/her reasons
(3)  Internal constants which should not be changed at all
(4)  The tag library (relating tags to literals) which should
     not be changed except to translate the program to a
     different language

If you change anything in this file you must 'make clean' the
entire project.  Unix Make utilities may not think you need to
go so far; but they lie.

****************************************************************/

class Registry;

extern Registry registry;

//--------------------------------------------------------------
//  User-changable constants 
//______________________________________________________________

// If you do not want to use the menu at all, set this constant
// to 0.  The program will then read from 'infile' and
// write to 'outfile' and no menu will be displayed.  Be sure
// that all necessary information is present in 'infile' if
// you use this option.
#define MENU 1

// Default values -- you can change these, but it is easier to
// code your defaults into your input data file.

// parameters
const double DEFAULTTHETA = 0.01;
const double DEFAULTMIGRATION = 100.;
const double DEFAULTRECOMBINATIONRATE = 0.01;
const double DEFAULTGROWTH = 1.0;

// maximum events
const long DEFAULTCOALEVENTS = 100000;
const long DEFAULTMIGEVENTS = 10000; 
const long DEFAULTRECEVENTS = 1000;

// methods
const string THETAMETHOD = "USER";
const string MIGMETHOD = "FST";
const string RECMETHOD = "USER";
const string GROWMETHOD = "USER";

// chains
const long INITIAL = 0;
const long DEF_INIT_NCHAINS  = 10;
const long DEF_INIT_NSAMPLES = 500;
const long DEF_INIT_INTERVAL = 20;
const long DEF_INIT_DISCARD  = 1000;

const long FINAL = 1;
const long DEF_FINAL_NCHAINS  = 2;
const long DEF_FINAL_NSAMPLES = 10000;
const long DEF_FINAL_INTERVAL = 20;
const long DEF_FINAL_DISCARD  = 1000;
// replicates
const long DEF_REPLICATES = 1;
// error conditions
const long TOO_MANY_DENOVO = 50;  // we give up; we can't make a denovo tree

// maximum allowable values for initial parameter estimates
const double MAX_THETA = 100.0;
const double MAX_MIGRATE = 500.0;
const double MAX_RECRATE = 1.0;
const double MAX_GROWRATE = 1000.0;

// default number of bins for allelic and microsat stepwise models
const long DEFBINS = 100;

//---------------------------------------------------------------
// Debugging constants
// (you had better know what you are doing before changing any of
// these)
//_______________________________________________________________

// When true, run without use of data, producing report of the 
// stationary distribution of the sampler
#define STATIONARIES 0
const string INTERVALFILE = "interval.out";
const string RECFILE = "reccount";

// When true, track data likelihoods into file 'like1'
#define LIKETRACK 0

// When false, run without use of data
#define DATA 1
// In no-data case only, when true use all 'X' for 'data'
#define XDATA 1
// In no-data case only, when true use recombination
#define USEREC 1

// When true, make all trees from scratch rather than using
// rearrangement (a very inefficient search)
#define DENOVO 0

//---------------------------------------------------------------
//  Internal program constants
//  (you had better know *exactly* what you are doing if you
//  change any of these--the program may not survive)
//_______________________________________________________________

const double MAX_LENGTH = 200.0;    // maximum branch length

const long  BASES = 4;                // number of nucleotides
const long baseA = 0;                // codes for nucleotides
const long baseC = 1;
const long baseG = 2;
const long baseT = 3;
const long baseEnd = 4;              // allows one-past-the-end use
const int  INVARIANTS   = 4;        // possible invariant sites

const long FLAGLONG     = -99;      // arbitrary flag values
const double FLAGDOUBLE = -99.0;   
const long FLAGINVAR    = -999;

const double DF         = 2.0;      // degrees of freedom for
                                    // likelihood ratio test
const long NCHAINTYPES = 2;         // how many kinds of chains?
const long IDSIZE = 2;              // size of branch ID number
const long NELEM = 2;               // allowed parents or children
                                    // of a branch
const double PERCENTILE_EPSILON = 0.0001; // accuracy percentile in profiles


// The following should be provided by the compiler, but
// we have found this to be unportable, so we define them
// ourselves.

const double NEG_MAX = -999999999.9; // the smallest reasonable double
const double EXP_MIN = -40.0;        // the smallest reasonable power of e

//---------------------------------------------------------------
// Registry of constant string tags
// (you might wish to change these if changing language)
//_______________________________________________________________

const string REC = "recombine";
const string MIG = "migrate";
const string COAL = "coalesce";
const string GROW = "grow";
const string TIP = "tip";
const string BASE = "base";
const string SNP = "SNP";
const string DNA = "DNA";
const string MICROSAT = "MICROSAT";
const string ELECTRO = "ELECTRO";
const string USER = "USER";
const string FST = "FST";
const string WATTERSON = "WATTERSON";

// Enumerations 

enum verbosity_type {CONCISE, NORMAL, VERBOSE, NONE};
enum paramlistcondition { YES, MIX, NO };
enum likelihoodtype { ssingle, replicate, region, gammaregion };
enum proftype { percentile, fix, none };
const proftype DEFAULT_PROFILE = percentile;

#endif






