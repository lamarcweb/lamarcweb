//$Id: chainpack.cpp,v 1.3 2002/06/25 03:17:36 mkkuhner Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "chainpack.h"
#include "registry.h"
#include "constants.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

//______________________________________________________________

ChainOut ChainPack::GetChain(long region, long rep, long chain) const {
  return(chains[region][rep][chain]);
} /* ChainPack::GetChain */

//______________________________________________________________

ChainOut ChainPack::GetRegion(long region) const {
  if (regions.size() == 0) {                 // no sum over replicates
    long last = (chains[region][0].size())-1;
    return(this->GetChain(region, 0, last));
  } else {
    return(regions[region]);
  }
} /* ChainPack::GetRegion */

//______________________________________________________________

ChainOut ChainPack::GetOverall() const {
  if (overall.size() == 0) {                // no sum over regions
     return(this->GetRegion(0));
  } else {
     return(overall[0]);
  }
} /* ChainPack::GetOverall */

//______________________________________________________________

void ChainPack::SetChain(ChainOut& chout) {

  if (currentRep == 0 && currentChain == 0) {            // first entry of its region
    vector<ChainOut> v1;
    v1.push_back(chout);
    vector<vector<ChainOut> > v2;
    v2.push_back(v1);
    chains.push_back(v2);
    currentChain++;
    return;
  }
  if (currentChain == 0) {                        // first entry of its replicate
    vector<ChainOut> v1;
    v1.push_back(chout);
    chains[currentRegion].push_back(v1);
    currentChain++;
    return;
  }
  chains[currentRegion][currentRep].push_back(chout);
  currentChain++;
  
} /* ChainPack::SetChain */

//______________________________________________________________

void ChainPack::SetSummaryOverReps(ChainOut& chout) {
  // a convenience variable
  vector<vector<ChainOut> >& region = chains[currentRegion];

  // set regional start/end times
  long lastrep = (region.size())-1;
  long lastchain = (region[0].size())-1;
  chout.SetStarttime(region[0][0].GetStarttime());
  chout.SetEndtime(region[lastrep][lastchain].GetEndtime());

  // set regional acceptance and dropping rates
  long rep;
  long numreplicates = region.size();
  long badtrees = 0;
  double accrate = 0.0;
  double maxllikedata = NEG_MAX;
  
  for (rep = 0; rep < numreplicates; ++rep) {
      badtrees += region[rep][lastchain].GetNumBadTrees();
      accrate += region[rep][lastchain].GetAccrate();
      maxllikedata = MAX(maxllikedata, region[rep][lastchain].GetLlikedata());
  }
  badtrees /= numreplicates;  // watch out; integer division here!
  accrate /= numreplicates;

  // file the results
  chout.SetNumBadTrees(badtrees);
  chout.SetAccrate(accrate);
  chout.SetLlikedata(maxllikedata);
  regions.push_back(chout);

} /* ChainPack::SetSummaryOverReps */

//______________________________________________________________

void ChainPack::SetSummaryOverRegions(ChainOut& chout) {
  // set overall start/end times
  long lastregion = (chains.size())-1;
  long lastrep = (chains[0].size())-1;
  long lastchain = (chains[0][0].size())-1;
  chout.SetStarttime(chains[0][0][0].GetStarttime());
  chout.SetEndtime(chains[lastregion][lastrep][lastchain].GetEndtime());

  // set overall acceptance and dropping rates
  long region;
  long rep;
  long chain;
  long badtrees = 0;
  double accrate = 0.0;
  double maxllikedata = NEG_MAX;
  long entries = 0;

  for (region = 0; region < (long) chains.size(); ++region) {
    for (rep = 0; rep < (long) chains[region].size(); ++rep) {
      for (chain = 0; chain < (long) chains[region][rep].size(); ++chain) {
        badtrees += chains[region][rep][chain].GetNumBadTrees();
        accrate += chains[region][rep][chain].GetAccrate();
        maxllikedata = MAX(maxllikedata, chains[region][rep][chain].GetLlikedata());
        ++entries;
      }
    }
  }

  badtrees /= entries;    // watch out!  integer division!
  accrate /= entries;

  // file the results
  chout.SetNumBadTrees(badtrees);
  chout.SetAccrate(accrate);
  chout.SetLlikedata(maxllikedata);
  overall.push_back(chout);

} /* ChainPack::SetSummaryOverRegions */

/**************************************************
 The following functions provide summaries of the
 parameter values from a ChainPack.
**************************************************/

//______________________________________________________________

DoubleVec1d ChainPack::RegionalMeanParams() const
{
// summarizes the current region
unsigned long rep;
DoubleVec2d values;
const ForceSummary& forcesum = registry.GetForceSummary();
long lastchain = chains[currentRegion][0].size() - 1;

for (rep = 0; rep < chains[currentRegion].size(); ++rep) {
  const ChainOut& chout = GetChain(currentRegion, rep, lastchain);
  values.push_back(chout.GetEstimates().GetParameters(forcesum));
}

return CalcMean(values);

} /* RegionalMeanParams */

//______________________________________________________________

DoubleVec1d ChainPack::OverallMeanParams() const
{
// summarizes over all regions
unsigned long region;
DoubleVec2d values;
const ForceSummary& forcesum = registry.GetForceSummary();

for (region = 0; region < chains.size(); ++region) {
  const ChainOut& chout = GetRegion(region);
  values.push_back(chout.GetEstimates().GetParameters(forcesum));
}

return CalcMean(values);

} /* OverallMeanParams */

//______________________________________________________________

DoubleVec2d ChainPack::GetRegionThetas() const 
{

long i;
DoubleVec2d summary;

for (i = 0; i < RegionsSoFar(); ++i) {
  ChainOut chout = GetRegion(i);
  summary.push_back(chout.estimates.GetThetas());
}
return(summary);

} /* GetRegionThetas */

//______________________________________________________________

DoubleVec2d ChainPack::GetRegionMigRates() const {

long i;
DoubleVec2d summary;

for (i = 0; i < RegionsSoFar(); ++i) {
  ChainOut chout = GetRegion(i);
  summary.push_back(chout.estimates.GetMigRates());
}
return(summary);

} /* GetRegionMigRates */

//______________________________________________________________

DoubleVec3d ChainPack::GetRegionMigRates2D() const {
/* We can't decide if we need the 1D or 2D form of
migration rates, so I will provide both for now */

long i;
DoubleVec3d summary;

for (i = 0; i < RegionsSoFar(); ++i) {
  ChainOut chout = GetRegion(i);
  summary.push_back(chout.estimates.Get2DMigRates());
}
return(summary);

} /* GetRegionMigRates2D */

//______________________________________________________________

DoubleVec1d ChainPack::GetRegionRecRates() const {
long i;
DoubleVec1d summary;

for (i = 0; i < RegionsSoFar(); ++i) {
  ChainOut chout = GetRegion(i);
  summary.push_back(chout.estimates.GetRecRates()[0]);
}
return(summary);

} /* GetRegionRecRates */

//______________________________________________________________

DoubleVec1d ChainPack::GetOverallThetas() const {

ChainOut chout = GetOverall();
return(chout.estimates.GetThetas());

} /* GetOverallThetas */

//______________________________________________________________

DoubleVec1d ChainPack::GetOverallMigRates() const {

ChainOut chout = GetOverall();
return(chout.estimates.GetMigRates());

} /* GetOverallMigRates */

//______________________________________________________________

DoubleVec2d ChainPack::GetOverallMigRates2D() const {

ChainOut chout = GetOverall();
return(chout.estimates.Get2DMigRates());

} /* GetOverallMigRates2D */

//______________________________________________________________

double ChainPack::GetOverallRecRate() const {

ChainOut chout = GetOverall();
return(chout.estimates.GetRecRates()[0]);

} /* GetOverallRecRate */

//______________________________________________________________

time_t ChainPack::GetStartTime() const {
  ChainOut firstchain = GetChain(0, 0, 0);
  return(firstchain.GetStarttime());
} /* GetStartTime */

//______________________________________________________________

time_t ChainPack::GetEndTime() const {
  ChainOut lastchain = GetOverall();
  return(lastchain.GetEndtime());
} /* GetEndTime */

//______________________________________________________________

// CalcMean assumes that all subvectors are as long as the first one
DoubleVec1d ChainPack::CalcMean(const DoubleVec2d& src) const
{
long index; 
long size = src[0].size();
DoubleVec2d::const_iterator values;
DoubleVec1d mean;

for(index = 0; index < size; ++index) {
   double sum = 0.0;
   for(values = src.begin(); values != src.end(); ++values)
      sum += (*values)[index];
   mean.push_back(sum /= src.size());
}
return mean;

} /* ChainPack::CalcMean */
