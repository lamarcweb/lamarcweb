// $Id: chainpack.h,v 1.3 2002/06/25 03:17:36 mkkuhner Exp $

#ifndef CHAINPACK
#define CHAINPACK

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

//#include <string>
#include <vector>
#include "vectorx.h"
#include <algorithm>
#include <strstream>
#include "chainout.h"
#include "constants.h"
#include "definitions.h"

/************************************************************************
 This class collects ChainOut objects containing the results of all
 chains, as well as a summary for each region and an overall summary.
 It is filled by the chain manager and used by the output report.

 It implements the following rules:  

 If only one replicate was run, the regional result is the result 
 from its last chain.  If multiple replicates were run, there is a 
 separate regional result summing all replicates.

 If only one region was run, the overall result is the result from
 that region.  If multiple regions were run, there is a separate
 overall result summing all regions.

 ChainPack adds timestamps to each summary object indicating the
 times of the chains which it summarizes.  The calling program does
 not need to set timestamps on the summaries, but it does need to set
 timestamps on the individual chain objects.

 DEBUG There is currently a logic problem involving summary times when there
 is only one region.

 While it is being filled up by the chain manager, the ChainPack
 is in an inconsistent state (for example, it may have two regions
 but no overall summary) and should generally not be touched by
 anyone else.

 Written by:  Mary Kuhner September 2000
*************************************************************************/

class ChainPack {

private:
ChainPack& operator=(const ChainPack&);          // deliberately not defined
ChainPack(const ChainPack &src);                 // deliberately not defined

vector<vector<vector<ChainOut> > >  chains;      // output of each chain
                                                 // dim: reg X rep X cha
vector<ChainOut>                    regions;     // summed over reps 
                                                 // dim: reg
vector<ChainOut>                    overall;     // summed over regions
                                                 // dim: really a scalar but kept
                                                 // as a vector for convenience
long currentChain;
long currentRep;
long currentRegion;

long        RegionsSoFar()   const   {return((long)chains.size());};
DoubleVec1d CalcMean(const DoubleVec2d& src)  const;

public:

ChainPack() : currentChain(0), currentRep(0), currentRegion(0) {};
~ChainPack() {};

// Inspector functions
ChainOut  GetChain(long region, long rep, long chain) const;
ChainOut  GetRegion(long region)                      const;
ChainOut  GetOverall()                                const;
time_t    GetStartTime()                              const;
time_t    GetEndTime()                                const;

DoubleVec1d   RegionalMeanParams()                    const;
DoubleVec1d   OverallMeanParams()                     const;

// Summary inspector functions (for output reports)
DoubleVec2d   GetRegionThetas()                       const;      
DoubleVec2d   GetRegionMigRates()                     const;      
DoubleVec3d   GetRegionMigRates2D()                   const;      
DoubleVec1d   GetRegionRecRates()                     const;

DoubleVec1d   GetOverallThetas()                      const;
DoubleVec1d   GetOverallMigRates()                    const;
DoubleVec2d   GetOverallMigRates2D()                  const;
double        GetOverallRecRate()                     const;


// Mutator functions
// These change their arguments--do not make the arguments const!
void SetChain(ChainOut& chout);
void SetSummaryOverReps(ChainOut& chout);
void SetSummaryOverRegions(ChainOut& chout);

void EndReplicate() { ++currentRep; currentChain = 0; };
void EndRegion()    { ++currentRegion; currentRep = 0; };

};

#endif
