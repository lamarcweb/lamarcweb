//$Id: lamarcdebug.h,v 1.1 2002/06/26 19:11:50 lamarc Exp $
// This file works around our inability to pass command line flags
// to the Metrowerks compiler.  If you want to use the debug
// facilities (assert, etc.) comment out the #define NDEBUG below.

#ifndef LAMARCDEBUG
#define LAMARCDEBUG

#ifdef __MWERKS__
//#define NDEBUG
#endif

#endif
