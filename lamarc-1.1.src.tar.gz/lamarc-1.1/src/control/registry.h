// $Id: registry.h,v 1.5 2002/06/25 03:17:38 mkkuhner Exp $

#ifndef REGISTRY
#define REGISTRY

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <stdlib.h>
#include "constants.h"

#include "chainparam.h"
#include "userparam.h"
#include "datapack.h"
#include "forcesummary.h"
#include "random.h"
#include "errhandling.h"

/***************************************************************
 The Registry has two functions:

 (1)  It holds (most of) the Singleton objects of the program
 and provides access to them.

 (2)  It holds prototypes of objects which must be created in
 a specific way for each run.  For example, it holds a
 prototypical Tree.  Once the program knows what kind of Tree will
 be wanted, a prototype is put in the Registry and all further
 Tree creation is done by Clone() of the prototype.

 The Registry is itself a Singleton.  The single instance is
 global (it's in lamarc.cpp) and it's extern everywhere (via
 constants.h).

 Written by Mary Kuhner 
*******************************************************************/

class Tree;
class TreeSummary;
class RunReport;
class Maximizer;
class SinglePostLike;
class ReplicatePostLike;
class RegionPostLike;
class Analyzer;

class Registry
{
  public:
    Registry();
    ~Registry();

    // Getters
    const Tree& GetProtoTree()                  const;
    const TreeSummary& GetProtoTreeSummary()    const;
    const ChainParameters& GetChainParameters() const {return chainparms;};
    const UserParameters& GetUserParameters()   const {return userparms;};
    const DataPack& GetDataPack()               const {return datapack;};
    const ForceSummary& GetForceSummary()       const {return forcesummary;};

    ChainParameters& GetChainParameters()       {return chainparms;};
    UserParameters& GetUserParameters()         {return userparms;};
    DataPack& GetDataPack()                     {return datapack;};
    ForceSummary& GetForceSummary()             {return forcesummary;};
    Random& GetRandom()                         {return random;};
    RunReport& GetRunReport();
    const RunReport& GetRunReport()             const;
    Maximizer& GetMaximizer();
    Maximizer * GetMaximizerPtr();
    SinglePostLike& GetSinglePostLike();
    ReplicatePostLike& GetReplicatePostLike();
    RegionPostLike& GetRegionPostLike();
    Analyzer& GetAnalyzer();

    // Setters
    void Register(Tree* tree);
    void Register(TreeSummary* treesum);
    void Register(RunReport* report);
    void Register(Maximizer* maxim);
    void Register(SinglePostLike* singlel);
    void Register(ReplicatePostLike* replicate);
    void Register(RegionPostLike* region);
    void Register(Analyzer * thisanalyzer);

    void SetChainParameters(ChainParameters& src) {chainparms = src;};
    void SetUserParameters(UserParameters& src)   {userparms = src;};
    void SetForceSummary(ForceSummary& src)   {forcesummary = src;};

  private:
    Registry(const Registry&);       // not defined
    Registry& operator=(const Registry&);  // not defined

    // the prototypes
    Tree* protoTree;
    TreeSummary* protoTreeSummary;

    // the singletons
    ChainParameters chainparms;
    UserParameters userparms;
    DataPack datapack;
    ForceSummary forcesummary;
    Random random;

    // the runtime reporter
    RunReport* runreport;

    // the posterior-likelihood drivers
    Maximizer* maximizer;
    SinglePostLike* PLsingle;
    ReplicatePostLike* PLreplicate;
    RegionPostLike* PLregion;

    // the profile and plot driver
    Analyzer *analyzer;

    // error handling
    void ThrowBadPrototype() const;
};

#endif

