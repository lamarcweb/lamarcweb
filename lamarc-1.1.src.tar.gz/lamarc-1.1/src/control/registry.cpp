// $Id: registry.cpp,v 1.5 2002/06/25 03:17:38 mkkuhner Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "registry.h"
#include "tree.h"
#include "treesum.h"
#include "maximizer.h"
#include "analyzer.h"
#include "likelihood.h"
#include "runreport.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//______________________________________________________________

Registry::Registry()
{
  protoTree = NULL;
  protoTreeSummary = NULL;
  PLsingle = NULL;
  PLreplicate = NULL;
  PLregion = NULL;
  runreport = NULL;
  maximizer = NULL;
  analyzer = NULL;
} /* Registry constructor */

//______________________________________________________________

Registry::~Registry()
{
  delete protoTree;
  delete protoTreeSummary;
  delete PLsingle;
  delete PLreplicate;
  delete PLregion;
  delete runreport;
  delete maximizer;
  delete analyzer;
} /* Registry destructor */

//______________________________________________________________

const Tree& Registry::GetProtoTree() const
{
  if (protoTree == NULL) ThrowBadPrototype();
  return(*protoTree);
} /* GetProtoTree */

//______________________________________________________________

const TreeSummary& Registry::GetProtoTreeSummary() const
{
  if (protoTreeSummary == NULL) ThrowBadPrototype();
  return (*protoTreeSummary);
} /* GetProtoTreeSummary */
//______________________________________________________________

RunReport& Registry::GetRunReport()
{
  if (runreport == NULL) ThrowBadPrototype();
  return (*runreport);
} /* Registry::GetRunReport() */

//______________________________________________________________

const RunReport& Registry::GetRunReport() const
{
  if (runreport == NULL) ThrowBadPrototype();
  return (*runreport);
} /* Registry::GetRunReport() */

//______________________________________________________________

Maximizer& Registry::GetMaximizer()
{
  if (maximizer == NULL) ThrowBadPrototype();
  return (*maximizer);
} /* Registry::GetMaximizer */

Maximizer * Registry::GetMaximizerPtr()
{
  if (maximizer == NULL) ThrowBadPrototype();
  return (maximizer);
} /* Registry::GetMaximizer */

//______________________________________________________________

SinglePostLike& Registry::GetSinglePostLike()
{
  if (PLsingle == NULL) ThrowBadPrototype();
  return (*PLsingle);
} /* Registry::GetSinglePostLike */

//______________________________________________________________

ReplicatePostLike& Registry::GetReplicatePostLike()
{
  if (PLreplicate == NULL) ThrowBadPrototype();
  return (*PLreplicate);
} /* Registry::GetReplicatePostLike */

//______________________________________________________________

RegionPostLike& Registry::GetRegionPostLike()
{
  if (PLregion == NULL) ThrowBadPrototype();
  return (*PLregion);
} /* Registry::GetRegionPostLike */

//______________________________________________________________
Analyzer& Registry::GetAnalyzer()
{
  if (analyzer == NULL) ThrowBadPrototype();
  return (*analyzer);
} /* Registry::GetRegionPostLike */

//______________________________________________________________

void Registry::Register(Tree* tree)
{
  delete protoTree;
  protoTree = tree;
} /* Register (Tree) */

//______________________________________________________________

void Registry::Register(RunReport* report)
{
  delete runreport;
  runreport = report;

} /* Registry::Register(RunReport) */

//______________________________________________________________
void Registry::Register(Maximizer* maxim)
{
  delete maximizer;
  maximizer = maxim;
} /* Registry::Register (Maximizer) */

//______________________________________________________________

void Registry::Register(SinglePostLike* singlel)
{
  delete PLsingle;
  PLsingle = singlel;
} /* Registry::Register (SinglePostLike) */

//______________________________________________________________

void Registry::Register(ReplicatePostLike* replicate)
{
  delete PLreplicate;
  PLreplicate = replicate;
} /* Registry::Register (ReplicatePostLike) */

//______________________________________________________________

void Registry::Register(RegionPostLike* region)
{
  delete PLregion;
  PLregion = region;
} /* Registry::Register (RegionPostLike) */


void Registry::Register(Analyzer *thisanalyzer)
{
  delete analyzer;
  analyzer = thisanalyzer;
} /* Registry::Register (RegionPostLike) */


//______________________________________________________________

void Registry::Register(TreeSummary* treesum)
{
  delete protoTreeSummary;
  protoTreeSummary = treesum;
} /* Registry::Register (intervaldata) */

//______________________________________________________________

void Registry::ThrowBadPrototype() const
{
  logic_error e("Attempt to use unregistered prototype");
  throw e;
}

//______________________________________________________________
