// $Id: chainout.cpp,v 1.3 2002/06/25 03:17:36 mkkuhner Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "chainout.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif
ChainOut::ChainOut()
{

} /* ChainOut */


//__________________________________________________

void ChainOut::CopyAllMembers(const ChainOut &src)
{

badtrees = src.badtrees;
accrate = src.accrate;
rates = src.rates;
numtemps = src.numtemps;
swaprates = src.swaprates;
 temperatures = src.temperatures;
starttime = src.starttime;
endtime = src.endtime;
estimates = src.estimates;
llikemle = src.llikemle;
llikedata = src.llikedata;

} /* CopyAllMembers */

//__________________________________________________

ChainOut::ChainOut(const ChainOut &src)
{

CopyAllMembers(src);

} /* ChainOut */

//__________________________________________________

ChainOut &ChainOut::operator=(const ChainOut &src)
{

CopyAllMembers(src);

return *this;

} /* operator= */

//__________________________________________________

void ChainOut::SetStarttime() 
{
#ifdef NOTIME_FUNC
// The system does not provide a clock.  All times are 0.
  starttime = 0;
#else
  time_t nowtime;
  time (&nowtime);
  starttime = nowtime;
#endif
}

//__________________________________________________

void ChainOut::SetEndtime() 
{
#ifdef NOTIME_FUNC
// The system does not provide a clock.  All times are 0.
  endtime = 0;
#else
  time_t nowtime;
  time (&nowtime);
  endtime = nowtime;
#endif
}

