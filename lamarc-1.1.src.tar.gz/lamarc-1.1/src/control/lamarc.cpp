//$Id: lamarc.cpp,v 1.10 2002/06/25 03:17:37 mkkuhner Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <iostream>
#include <string>
#include <vector>
#include "lamarc.h"
#include "constants.h"
#include "registry.h"
#include "datapack.h"
#include "forcesummary.h"
#include "chainparam.h"
#include "userparam.h"
#include "plotstat.h"
#include "chainmanager.h"
#include "likelihood.h"
#include "runreport.h"
#include "maximizer.h"
#include "analyzer.h"
#include "xml.h"
#include "arranger.h"
#include "menu.h"
#include "dialog.h"
#include "parameter.h"

//_________________________________________________________
// Global variable section.  
// The Registry singleton is global because everyone in
// the world needs to use it.

Registry registry;

//_________________________________________________________

// This routine controls the menu, if any, and other
// startup issues.
void DoUserInput() 
{

#if STATIONARIES
// clear out files used for stationaries record-keeping
   ofstream of;
   of.open(RECFILE.c_str(),ios::trunc);
   of.close();
   of.open(INTERVALFILE.c_str(),ios::trunc);
   of.close();
#endif

#if DATA
  // DEFAULTS and SETUP ==================================
  DataFile datafile(registry);
  DataPack& datapack = registry.GetDataPack();

  ForceSummary& forcesummary = registry.GetForceSummary();
  ChainParameters &chparm = registry.GetChainParameters();
  UserParameters& userparm = registry.GetUserParameters();

  // menu subsystem ======================================
  //
  // dialog subsystem: Possible classes are
  //      ScrollingDialog [shows menu, and reads data into datafile]
  //      NoDialog        [no menu, data reading is separate]

#if MENU
  ScrollingDialog dialog;
  // data menu: shows simple file dialog and reads data from XML file
  DataMenu datamenu(registry, datafile, datapack, dialog); 
  datamenu.Show();
#else 
  NoDialog dialog;
  // no dialog: assumes all parameters are set in infile or use defaults 
  string filename = userparm.GetDataFileName();
  datafile.ReadFile(filename);
#endif

  long npops = datapack.GetNPopulations();
  long nregs = datapack.GetNRegions();

  if(forcesummary.GetAllForces().empty()) 
  {
      forcesummary.SetForce(COAL,datapack);
      StringVec1d defaultWat(npops, WATTERSON);
      forcesummary.SetMethods(COAL, defaultWat); 
      if(npops>1) 
      { 
          forcesummary.SetForce(MIG,datapack);
          StringVec1d defaultMig(npops*npops, FST);
          forcesummary.SetMethods(MIG, defaultMig); 
      } 
  }
  forcesummary.ReconcilePLForces(datapack);

  // forces must already be in ForceVec!
  // MARY
  forcesummary.SummarizeData(datapack);
  
  // need to transfer regional->calculated values to start values in
  // forcesummary somehow....

  // calculates base frequencies [does it accept SET base freqs?]
  // We call initialize here for the menu
  long reg;
  for(reg = 0; reg < nregs; ++reg) 
    {
      Region& region = datapack.GetRegion(reg);
      if (region.datamodel.get() == NULL) {
        DataModel_ptr defmodel(region.datatype->DefaultDataModel());
        region.datamodel = defmodel;
      }
      region.datamodel->Initialize(region);
    }
  
  // main menu: all menus and dialogs, setting of parameters
  // AND SETTING OF DEFAULTS [even in the nodialog case] 
  MainMenu mainmenu(registry, datafile, datapack, dialog);
  mainmenu.Show();
  
  // install forces in the arrangers
  vector<Arranger*> arrs = chparm.GetAllArrangers();
  vector<Arranger*>::iterator arr;

  for(arr = arrs.begin(); arr != arrs.end(); ++arr)
    (*arr)->SetForces(forcesummary);

  // install forces in the treesummaries
  registry.Register(forcesummary.CreateProtoTreeSummary(npops));

  for(reg = 0; reg < nregs; ++reg) {
    Region& region = datapack.GetRegion(reg);

// We call DataModel::Initialize() here again to catch changes
// that the menu process might have changed (categories).
    region.datamodel->Initialize(region);
    region.datamodel->Finalize();

    // a quick consistency check
    if (!region.datamodel->IsValid()) {
      data_error e("Internally inconsistent data model");
      throw e;
    }

    // DEBUG marker-weights are not currently done
    long nmarkers = region.GetNmarkers();
    region.SetMarkerweights(DoubleVec1d(nmarkers,1.0));
  }

  // validity checks
  if (!userparm.IsValid()) {
    data_error e("Internally inconsistent user parameters");
    throw e;
  }
  if (!chparm.IsValid()) {
    data_error e("Internally inconsistent user parameters");
    throw e;
  }
  if (!forcesummary.IsValid()) {
    data_error e("Internally inconsistent evolutionary forces");
    throw e;
  }


#endif

#if !DATA
  // Jon, I moved the nodata code into its own file
  // several times I trapped myself by editing the code in here
  // Peter
  cout << "Running NoData case--data file ignored!" << endl;
  #include "lamarc.nodata.cpp"
#endif

} /* DoUserInput */

/***********************************************************
 This routine constructs and registers objects which
 require user-generated information to create:
    the proto-tree
    the runtime reporter
    the maximizer and its associated likelihoods
************************************************************/
void FinishRegistry()
{
// create and register the proto-tree


Random* prand = &(registry.GetRandom());
// put in the random number seed
prand->Seed(registry.GetUserParameters().GetRandomSeed());

ForceSummary& forcesummary = registry.GetForceSummary();
long npops = registry.GetDataPack().GetNPopulations();

Tree* prototree = forcesummary.CreateProtoTree(prand, npops);
registry.Register(prototree);

// create and register the runtime reporter
// MUST DO THIS BEFORE MAKING THE ANALYZER
verbosity_type progress = registry.GetUserParameters().GetProgress();
StringVec1d popnames = registry.GetDataPack().GetPopulationNames();

RunReport* prunreport = new RunReport(forcesummary, popnames, progress);
registry.Register(prunreport);

// create and register the posterior likelihood objects

// retrieve user-defined values from collection objects
// obsolete? StringVec1d forcestr = forcesummary.GetForceString();
long nregs = registry.GetDataPack().GetNRegions();
long nreps = registry.GetChainParameters().GetNReps();
long paramsize = forcesummary.GetAllNParameters();

// the maximizer itself
Maximizer* pmax = new Maximizer(paramsize);
registry.Register(pmax);

ParamVector params(forcesummary);
// single likelihood
 SinglePostLike* plsingle =
   new SinglePostLike(forcesummary.GetAllForces(), 
		      npops, nregs, nreps, paramsize);
 plsingle->GradientGuideSetup(params);
 registry.Register(plsingle);
 
// replicate likelihood
ReplicatePostLike* plrep =
   new ReplicatePostLike(forcesummary.GetAllForces(), 
			 npops, nregs, nreps, paramsize);
plrep->GradientGuideSetup(params);
registry.Register(plrep);

// region likelihood
RegionPostLike* plreg =
   new RegionPostLike(forcesummary.GetAllForces(), 
		      npops, nregs, nreps, paramsize);
plreg->GradientGuideSetup(params);
registry.Register(plreg);

// Setup Analyzer subsystem {will do plots and profiles}
Analyzer *analyzer = new Analyzer(forcesummary, *prunreport, params); 
registry.Register(analyzer);

} /* FinishRegistry */

//_____________________________________________________________
//_____________________________________________________________

int main(long, char **) 
{

try {
  // handle user input including menu and data fiile
  DoUserInput();

  // register user-input-dependent structures
  FinishRegistry(); 

  // run the chainmanager
  Maximizer& maximizer = registry.GetMaximizer();
  RunReport& runreport = registry.GetRunReport();

  ChainManager chainmanager(runreport, maximizer);
  chainmanager.Do();
  
  if (registry.GetUserParameters().GetProgress() != NONE) {
    cout << endl << "output written to ";
    cout << registry.GetUserParameters().GetResultsFileName() << "\n\n";
    cout << "Program done" << endl;
  }
}

catch (exception& ex) {
  cerr << ex.what() << endl;
}

return 0;

} /* LAMARC main routine */
