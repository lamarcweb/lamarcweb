//$Id: userparam.h,v 1.3 2002/06/25 03:17:38 mkkuhner Exp $

#ifndef USERPARAMETERS
#define USERPARAMETERS

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************** 
 UserParameters is a collection class used for internal communication
 throughout Lamarc.

 UserParameters is a grab-bag of information provided by the user that
 doesn't seem to belong anywhere else, including file names and
 output format options, and the random number seed.

 Copy semantics are provided for menu roll-back purposes; otherwise
 there should only be one copy, registered in Registry.

 Written by Jim Sloan, revised by Mary Kuhner

********************************************************************/

#include <vector>
#include "vectorx.h"
#include <string>
#include <stdlib.h>
#include "constants.h"
#include "plotstat.h"

// #include <time.h> for access to the time function to initialize
//   the random seed in the class ctor.

class UserParameters
{
  private:

    string datafilename;
    string paramfilename;
    string resultsfilename;
    string treesumfilename;

    verbosity_type   verbosity;
    verbosity_type   progress;
    bool   echoData;
    bool   plotPost;
    long   randomSeed;

    void   CopyAllMembers(const UserParameters&);

  public:

                    UserParameters();
                    UserParameters(const UserParameters& src);  
    UserParameters& operator=(const UserParameters& src);    

    // Set Functions
    void   SetDataFileName(const string& fn)     { datafilename    = fn; };
    void   SetParamFileName(const string& fn)    { paramfilename   = fn; };
    void   SetResultsFileName(const string& fn)  { resultsfilename = fn; };
    void   SetTreeSumFileName(const string& fn)  { treesumfilename = fn; };

    void   SetVerbosity(verbosity_type v) { verbosity       = v; };
    void   SetProgress(verbosity_type v)  { progress        = v; };
    void   SetEchoData(bool b)            { echoData        = b; };
    void   SetPlotPost(bool b)            { plotPost        = b; };

    void   SetRandomSeed(long s)              { randomSeed = s; };
    
    // Get Functions
    string GetDataFileName()        const { return datafilename; };
    string GetParamFileName()       const { return paramfilename; };
    string GetResultsFileName()     const { return resultsfilename; };
    string GetTreeSumFileName()     const { return treesumfilename; };

    verbosity_type   GetVerbosity() const { return verbosity; };
    verbosity_type   GetProgress()  const { return progress; };
    bool   GetEchoData()            const { return echoData; };
    bool   GetPlotPost()            const { return plotPost; };

    long   GetRandomSeed()          const { return randomSeed; };

    // Validation
    bool   IsValid()                const;
};

#endif

