#include <float.h>
#include <math.h>

typedef long longer[3];

void init_randum(long inseed, longer seed);
double randum();
