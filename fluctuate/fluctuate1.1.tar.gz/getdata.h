void setupdata(dnadata **dna, long sites, long numseq);
void getdata(tree *curtree, dnadata *dna, option_struct *op,
  FILE *infile, FILE *outfile);
void freedata(dnadata *dna);
void makevalues(dnadata *dna, long categs, tree *curtree);
void empiricalfreqs(tree *curtree, dnadata *dna, long *weight);
void getbasefreqs(dnadata *dna, option_struct *op, double
  locus_ttratio, FILE *outfile);
