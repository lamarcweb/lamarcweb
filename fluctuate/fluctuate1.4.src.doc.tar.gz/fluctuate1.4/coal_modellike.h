#define COAL_MODELLIKE_INCLUDE

void theta_confidence(long chain, double maxtheta, long lowcus,
   double **lthetai);

double fnx (long chain, double theval, long numints, long *fxplus,
   boolean *fxzero);
double dfnx (long chain, double theval, long numints, long *dfxplus,
   boolean *dfxzero);
double coal_singlechain(long chain, boolean chend, boolean rend);

double combined_fnx (double theval, long numints, double **treewt,
   long firstlong, long lastlong, long *fxplus, boolean *fxzero, long lowcus);
double combined_dfnx (double theval, long numints, double **treewt,
   long firstlong, long lastlong, long *dfxplus, boolean *dfxzero, long lowcus);

double combined_locus_fnx(double theta, long numintervals, double ***treewt,
   long firstlong, long lastlong, boolean *return_zero, long *return_plus);
double combined_locus_dfnx(double theta, long numintervals, double ***treewt,
   long firstlong, long lastlong, boolean *return_zero, long *return_plus);

void combined_locus_weights(double **treewt, long firstlong, long lastlong, long
   lowcus, double *lthetai);

double combined_llike(double theta, long firstlong, long lastlong, 
  double *lthetai, long locus);
double sum_combined_llike(double theta, long firstlong, long lastlong, 
  double **lthetai);

double coal_combined_locus_estimate(void);

void coal_curveplot(void);
