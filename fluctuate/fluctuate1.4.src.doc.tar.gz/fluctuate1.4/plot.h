#ifndef WORLD_INCLUDE
#define WORLD_INCLUDE
/*------------------------------------------------------
 Maximum likelihood estimation 
 of migration rate  and effectice population size
 using a Metropolis-Hastings Monte Carlo algorithm                            
-------------------------------------------------------                        
 W O R L D   R O U T I N E S 

 creates tree structures,
 calculates smple parameter estimates (FST,...)
 reads tree [has to be done]
 
 prints results,
 and finally helps to destroy itself.
                                                                                                               
 Peter Beerli 1996, Seattle
 beerli@genetics.washington.edu
 $Id: plot.h,v 1.1.1.1 2002/09/04 21:51:06 dannylee Exp $
-------------------------------------------------------*/

void plot_surface(long lowcus, char ***plane, long x);
void create_locus_plot(long lowcus, char **plane);
void create_plotplane(char**** plane);
void calc_locus_plane(long lowcus, double **pl, double contours[]);
void fill_plotplane(char **plane, double **pl, double contours[]);
void print_mathematica(double **plane, long x, long y);
void print_locusplot(long lowcus);
void free_plotplane (char ****plane);

/* functions donated by fluc_modellike */
extern double fluc_locus_llike(double theta, double growth);
extern double model_llike(double thgiven, double grgiven,
  long chain, long lowcus);

#endif /*WORLD_INCLUDE*/
