// $Id: menu_strings.cpp,v 1.14 2010/03/02 23:12:29 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#include <string>
#include "menu_strings.h"

using std::string;

const string key::dot   = ".";
const string key::Q     = "Q";
const string key::R     = "R";

const string menustr::acknowledge      = "\nType <Return> to continue\n";
const string menustr::bottomLine       = "<Return> = Go Up | . = Run | Q = Quit";
const string menustr::bottomLineAtTop  = ". = Run | Q = Quit";
const string menustr::carriageReturn   = "\n";
const string menustr::divider          = "----------";
const string menustr::emptyString      = "";
const string menustr::inconsistencies  = "\n\nYou must fix inconsistencies with the following menu\nitems before exiting the current menu:\n\t";
const string menustr::space            = " ";
const string menustr::initial          = "Initial";
const string menustr::final            = "Final";
const string menustr::chains           = "Number of chains";
const string menustr::discard          = "Number of genealogies to discard";
const string menustr::interval         = "Sampling interval";
const string menustr::samples          = "Number of samples";

//____________________________________________________________________________________
