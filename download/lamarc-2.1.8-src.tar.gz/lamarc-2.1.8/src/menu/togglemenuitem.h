// $Id: togglemenuitem.h,v 1.16 2010/03/02 23:12:29 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef TOGGLEMENUITEM_H
#define TOGGLEMENUITEM_H

#include <string>
#include "constants.h" // for proftype
#include "menuinteraction.h"
#include "newmenuitems.h"

class UIInterface;
class Display;

#endif  // TOGGLEMENUITEM_H

//____________________________________________________________________________________
