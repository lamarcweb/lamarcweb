// $Id: matrixitem.h,v 1.11 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef MATRIXITEM_H
#define MATRIXITEM_H

#include <string>
#include "menuinteraction.h"
#include "newmenu.h"
#include "setmenuitem.h"
#include "ui_constants.h"
#include "ui_interface.h"
#include "vectorx.h"

class LowerLevelMenuItemGroup : public SetMenuItemGroup
{
  protected:
    std::string legalIdsMenuKey;
    std::string visibilityGuard;
    UIId intoId;
    virtual UIId translateLocalToGlobal(UIId localId);
    virtual UIId translateGlobalToLocal(UIId globalId);
  public:
    LowerLevelMenuItemGroup(UIInterface & myui,
                            std::string myMenuKey,
                            std::string myLegalIdsMenuKey,
                            std::string myVisibilityGuard,
                            UIId myId);
    virtual ~LowerLevelMenuItemGroup();
    virtual std::string GetKey(UIId id);
    virtual UIIdVec1d GetVisibleIds();
};

class LowerLevelMenu : public NewMenu
{
  public:
    LowerLevelMenu(UIInterface & myui,
                   std::string myMenuKey,
                   std::string lowerLevelMenuKey,
                   std::string myLegalIdsMenuKey,
                   std::string myVisibilityGuard,
                   UIId myId);
    virtual ~LowerLevelMenu();
};

class MatrixSetMenuItem : public MenuDisplayGroupBaseImplementation
{
  protected:
    std::string lowerLevelMenuKey;
    std::string legalIdsMenuKey;
    std::string visibilityGuard;
    UIId        forceId;
    // returns sub-menu
    virtual MenuInteraction_ptr MakeOneHandler(UIId id);
  public:
    MatrixSetMenuItem(UIInterface & myui,
                      std::string myMenuKey,
                      std::string myLowerLevelMenuKey,
                      std::string myLegalIdsMenuKey,
                      std::string myVisibilityGuard,
                      force_type ftype);
    virtual ~MatrixSetMenuItem();
    UIIdVec1d GetVisibleIds();
};

#endif  // MATRIXITEM_H

//____________________________________________________________________________________
