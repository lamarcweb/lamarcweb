// $Id: dialog.h,v 1.17 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef DIALOG_H
#define DIALOG_H

#include "menuinteraction.h"

class Dialog : public MenuInteraction
{
  public:
    Dialog();
    virtual ~Dialog();
};

#endif // DIALOG_H

//____________________________________________________________________________________
