// $Id: dialognoinput.cpp,v 1.13 2010/03/17 17:25:59 bobgian Exp $

/*
  Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "dialog.h"
#include "dialognoinput.h"
#include "display.h"
#include "menudefs.h"
#include "menu_strings.h"
#include "stringx.h"
#include <string>

using std::string;

DialogNoInput::DialogNoInput() : Dialog()
{
}

DialogNoInput::~DialogNoInput()
{
}

void DialogNoInput::performAction()
{
    // default is to do nothing at all
}

menu_return_type DialogNoInput::InvokeMe(Display & display)
{
    display.DisplayDialogOutput(outputString());
    performAction();
    return menu_REDISPLAY;
}

//------------------------------------------------------------------------------------

DialogAcknowledge::DialogAcknowledge() : DialogNoInput()
{
}

DialogAcknowledge::~DialogAcknowledge()
{
}

menu_return_type DialogAcknowledge::InvokeMe(Display & display)
{
    display.DisplayDialogOutput(outputString());
    display.DisplayDialogOutput(menustr::acknowledge);
    display.GetUserInput();
    return menu_REDISPLAY;
}

//------------------------------------------------------------------------------------

std::string DialogChideInconsistencies::outputString()
{
    std::string allInconsistencies = ToString(inconsistencies);
    std::string wholeMessage = menustr::inconsistencies + allInconsistencies;
    return wholeMessage;
}

DialogChideInconsistencies::DialogChideInconsistencies(StringVec1d & myInconsistencies)
    : inconsistencies(myInconsistencies)
{
}

DialogChideInconsistencies::~DialogChideInconsistencies()
{
}

//____________________________________________________________________________________
