// $Id: menudefs.h,v 1.12 2010/03/17 17:25:59 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef MENUDEFS_H
#define MENUDEFS_H

enum menu_return_type { menu_GO_UP, menu_REDISPLAY, menu_QUIT, menu_RUN};

#endif // MENUDEFS_H

//____________________________________________________________________________________
