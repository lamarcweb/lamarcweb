// $Id: gc_file_util.h,v 1.6 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_FILE_UTIL_H
#define GC_FILE_UTIL_H

#include "gc_errhandling.h"
#include "wx/string.h"

class wxFileInputStream;
class wxTextInputStream;

class gc_file_error : public gc_ex
{
  public:
    gc_file_error(const wxString &) throw();
    virtual ~gc_file_error() throw();
};

class gc_eof : public gc_file_error
{
  public:
    gc_eof() throw();
    virtual ~gc_eof() throw();
};

class gc_file_missing_error : public gc_file_error
{
  public:
    gc_file_missing_error(const wxString & fileName) throw();
    virtual ~gc_file_missing_error() throw();
};

class gc_file_read_error : public gc_file_error
{
  public:
    gc_file_read_error() throw();
    gc_file_read_error(const wxString & fileName) throw();
    virtual ~gc_file_read_error() throw();
};

wxString
ReadLineSafely(wxFileInputStream * fStream, wxTextInputStream * tStream);

wxString
ReadWordSafely(wxFileInputStream & fStream, wxTextInputStream & tStream);

#endif  // GC_FILE_UTIL_H

//____________________________________________________________________________________
