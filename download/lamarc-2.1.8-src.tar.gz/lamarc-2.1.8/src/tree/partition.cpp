// $Id: partition.cpp,v 1.5 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "force.h"
#include "partition.h"

XPartition::~XPartition() {};

//____________________________________________________________________________________
