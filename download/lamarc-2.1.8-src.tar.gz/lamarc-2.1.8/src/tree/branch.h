// $Id: branch.h,v 1.67 2011/12/15 18:13:37 mkkuhner Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

/*******************************************************************

 Class Branch represents a branch in the tree, and is polymorphic on the type of event at its top
 (a coalescence, migration, etc.).  It contains auxiliary objects (a Range * and a DLCell) to manage
 likelihood and site information.

 A Branch's parents and children are represented by vectors of Branch_ptr.
 There may be 0, 1 or 2 parents and 0, 1 or 2 children; other values are illegal.

 As Branches are polymorphic, they are only put in containers as boost::shared_ptrs.
 To copy a Branch use the Clone() function, which will create a new Branch of appropriate subtype.

 Branches are either Cuttable (can be cut during rearrangement) or not, and signal this by returning
 their "count of cuttable branches" which is currently either 0 or 1.  Partition and stick branches
 are currently non-cuttable.

 Written by Jim Sloan, heavily revised by Jon Yamato
 -- dlcell turned into a container Mary 2002/05/28
 -- derivation hierarchy reworked, TreeBranch class inserted
    Branch class narrowed Jon 2003/02/24
 -- Adding semi-unique ID numbers for each branch (the "same" branch
    in two different trees will share the same ID number).  First
    implementation via reference counted pointer objects.  Jon 2007/01/09

********************************************************************/

#ifndef BRANCH_H
#define BRANCH_H

#include <cassert>
#include <cmath>
#include <deque>
#include <functional>
#include <string>
#include <vector>

#include "vectorx.h"
#include "constants.h"
#include "defaults.h"
#include "range.h"
#include "dlcell.h"
#include "locuscell.h"
#include "shared_ptr.hpp"               // for Branch_ptr (boost::shared_ptr)
#include "enable_shared_from_this.hpp"  // for shared_ptr support
#include "branchtag.h"
#include "rangex.h"                     // for class Range (and subclass) factory duties
#include "fc_status.h"                  // for RevalidateRange debug function

// Note that some functions/variables defined here have "_Br" (for "Branch") as a suffix in their name.
// This is to distinguish them from functions/variables in class Range (or RecRange) of the same name, which use "_Rg".

//------------------------------------------------------------------------------------

class TreeSummary;
class TipData;
class BranchBuffer;
class Force;
class Branch;
class TBranch;
class TiXmlElement;

enum branch_type {btypeBase, btypeTip, btypeCoal, btypeMig, btypeDivMig, btypeDisease, btypeRec, btypeEpoch};
enum branch_group {bgroupTip, bgroupBody};

std::string ToString(branch_type btype);

typedef boost::shared_ptr<TBranch> TBranch_ptr;

//------------------------------------------------------------------------------------

class Branch : public boost::enable_shared_from_this<Branch>
{
  private:
    Branch();                               // Default ctor is undefined.
    Branch & operator=(const Branch & src); // Assignment operator is undefined.
    vector<weakBranch_ptr> m_parents;
    vector<weakBranch_ptr> m_children;

  protected:
    bool m_updateDL;
    BranchTag m_ID;
    weakBranch_ptr m_equivBranch;

    // We own what these point to.
    vector<LocusCell> m_DLcells;
    vector<LocusCell> m_movingDLcells;

    virtual void CopyAllMembers(const Branch & src);
    LongVec1d GetLocalPartitions() const; // Used by ScoreEvent.

    // Each derived branch must implement some form of Range factory function that will be called
    // in that branch's ctor to create the new Range for that branch.  We did not implement a pure
    // virtual base function because of the different signature needs of each of the derived
    // branch's Range.  The current factory is named CreateRange(), which returns a Range *,
    // a pointer to a newly-heap-allocated Range.
    //
    // NB: the C++ standard does not currently (2010/03/31) allow you to call polymorphically
    // from within a ctor of base.  You will get the base instantiation of the function; if one
    // does not exist, the compiler will/should fail.

  public:
    LongVec1d m_partitions;
    double m_eventTime;
    bool m_marked;

    //************Panel Correction control parameters
    // this exists so we don't have to reach all the way back into the xml
    // 0 if a Panel member
    // 1 if a Sample member
    // 2 if a coalescence has only sample tips above it
    int m_isSample;
    bool m_wasCoalCalced; // coalescence DLCell has been calculated once
    // used to prevent recalculation of type 2 coalesences
    //************Panel Correction control parameters

    static Branch_ptr NONBRANCH;

    Range * m_rangePtr;

    Branch(Range * newrangeptr);
    Branch(const Branch & src);

    // Destructor.  Defined to deallocated the Range object in every Branch object.
    // The destructors for all the derived classes are default dtors which do nothing.
    // Since this base class dtor gets called after the dtor for each derived class,
    // this dtor will be the only one which deletes the Range object once and only once.
    virtual ~Branch();

    // RTTI
    virtual branch_type Event()                 const = 0;
    virtual branch_group BranchGroup()          const = 0;

    virtual Branch_ptr Clone() const { return Branch::NONBRANCH; };

    // Convenience getters and setters.
    long    GetID() const;
    weakBranch_ptr GetEquivBranch() const;
    void    SetEquivBranch(Branch_ptr twin);

    long    GetPartition(force_type) const;
    void    SetPartition(force_type force, long val);
    virtual void    CopyPartitionsFrom(Branch_ptr src);

    Branch_ptr    Child(long which) { return m_children[which].lock(); };
    Branch_ptr    Parent(long which) { return m_parents[which].lock(); };
    const Branch_ptr Child(long which) const { return m_children[which].lock(); };
    const Branch_ptr Parent(long which) const { return m_parents[which].lock(); };
    void    SetChild(long which, Branch_ptr val) { m_children[which] = val; };
    void    SetParent(long which, Branch_ptr val) { m_parents[which] = val; };
    long    NParents() const { return m_parents.size(); };
    long    NChildren() const { return m_children.size(); };

    // Arrangemment helpers.
    bool    IsAMember(const Force & force, const LongVec1d & membership) const;
    virtual long    Cuttable()                const { return 0; };
    virtual bool    CanRemove(Branch_ptr)           { return true; };
    virtual long    CountDown()               const { return 0; };
    virtual void    UpdateBranchRange(const rangeset & fcsites, bool dofc) {};
    virtual void    UpdateRootBranchRange(const rangeset & fcsites, bool dofc) {};
    virtual bool    IsEquivalentTo(const Branch_ptr)   const;
    virtual bool    HasSamePartitionsAs(const Branch_ptr) const;
    virtual bool    PartitionsConsistentWith(const Branch_ptr) const;
    long            Nsites() const { return m_rangePtr->NumTotalSites_Rg(); };

    rangeset        GetLiveSites_Br() const { return m_rangePtr->GetLiveSites_Rg(); };

    virtual bool    IsRemovableRecombinationLeg(const rangeset &) const { return false; };

    virtual Branch_ptr GetRecPartner() const { return Branch::NONBRANCH; };
    void            ResetBuffersForNextRearrangement();

    void            ResetOldTargetSites_Br(const rangeset & fcsites) { m_rangePtr->ResetOldTargetSites_Rg(fcsites); };

    // The following routine is a no-op except in a branch where updateDL is
    // allowed to be true, in which case it will be overridden.
    virtual void    SetUpdateDL()                   {};
    void    ClearUpdateDL()                 { m_updateDL = false; };
    bool    GetUpdateDL()             const { return m_updateDL; };
    void    MarkParentsForDLCalc();
    virtual void    ReplaceChild(Branch_ptr oldchild, Branch_ptr newchild);
    virtual bool    HasSameActive(const Branch & br);
    const Cell_ptr GetDLCell(long loc, long ind, bool moving) const;
    Cell_ptr GetDLCell(long loc, long ind, bool moving);

    void    SetDLCells(const std::vector<LocusCell> & src) { m_DLcells = src; };
    long    GetNcells(long locus)  const { return m_DLcells[locus].size(); };
    void    SetMovingDLCells(const std::vector<LocusCell> & src) { m_movingDLcells = src; };

    // long    GetNcells(long locus)  const { return m_DLcells[locus].size(); };

    double          GetTime() { return m_eventTime; };

    // Subtree maker helper.
    virtual long    GetRecSite_Br()             const { return FLAGLONG; };

    // Likelihood calculation helpers.
    virtual double  HowFarTo(const Branch & br) const;
    virtual bool    CanCalcDL(long)             const { return false; };
    virtual bool    CanCalcPanelDL(long)        const { return false; };
    virtual bool    ShouldCalcDL(long)          const { return false; };
    Branch_ptr GetValidChild(Branch_ptr br, long whichpos);
    Branch_ptr GetValidPanelChild(Branch_ptr br, long whichpos);
    Branch_ptr GetValidParent(long whichpos);

    // Haplotyping helpers.
    virtual bool    DiffersInDLFrom(Branch_ptr branch, long locus, long marker) const;

    // Tree summarization helpers.
    // Some subclass functions return results via the reference second and third arguments.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const = 0;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const = 0;

    // Invariant checking.
    virtual bool    operator==(const Branch & src) const;
    bool    operator!=(const Branch & src) const { return !(*this == src); };

    // Debugging functions.
    virtual bool    CheckInvariant()              const;
    virtual string  DLCheck(const Branch & other)  const;
    void            InvertUpdateDL() { m_updateDL = !m_updateDL; };
    virtual void    PrintInfo_Br() const;
    vector<Branch_ptr> GetBranchChildren(); // Used by TimeList::PrintTimeList()
    virtual bool    IsSameExceptForTimes(const Branch_ptr other) const;

    // Used by TimeList::IsValidTimeList(), non-const because of
    // use of boost::shared_from_this()!
    bool            ConnectedTo(const Branch_ptr family);

    // Debugging function.
    // Used by TimeList::RevalidateAllRanges(), must be able to handle "one-legged" forms
    // of all branchtypes (eg. coalescence and recombination).
    //
    // The base class implementation will assume that there exists exactly one child and
    // that there are no changes in the Range object between parent and child, and no
    // changes needed to the passed argument.
    virtual bool    RevalidateRange(FC_Status &) const;

    // GetActiveChild() is a helper function for GetValidChild()
    virtual const Branch_ptr GetActiveChild(long) const { return Child(0); };

    // GetActivePanelChild() is a helper function for GetValidPanelChild()
    virtual const Branch_ptr GetActivePanelChild(long) const { return Child(0); };

    // for writing GraphML output
    virtual void   AddGraphML(TiXmlElement *) const;
    virtual void   AddNodeInfo(TiXmlElement *) const {return;} ;
    virtual string GetGraphMLNodeType() const = 0;
    virtual string GetParentIDs() const;
    virtual string GetChildIDs() const;
    virtual long   GetCanonicalID() const;
    virtual long   GetCanonicalParentID() const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class BBranch : public Branch
{
  private:
    BBranch & operator=(const BBranch & src); // Assignment operator is undefined.

  protected:
    virtual Range * CreateRange() const;

  public:
    BBranch();                          // Need this for TimeList constructor; will construct using CreateRange().
    BBranch(const BBranch & src): Branch(src) {};
    virtual ~BBranch() {};              // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual Branch_ptr Clone()               const;
    virtual branch_type Event()              const { return btypeBase; };
    virtual branch_group BranchGroup()       const { return bgroupBody; };

    // Tree summarization helpers.
    // Some subclass functions (not this one) return results via the reference third argument.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const;

    // Debugging function.
    virtual bool    CheckInvariant()          const;

    // for writing GraphML output
    virtual string GetGraphMLNodeType() const;

};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class TBranch : public Branch
{
  private:
    TBranch();                                // Default ctor is undefined.
    TBranch & operator=(const TBranch & src); // Assignment operator is undefined.

  protected:
    virtual Range * CreateRange(long nsites, const rangeset & dissites) const;

  public:
    string  m_label;

    TBranch(const TipData & tipdata, long nsites, const rangeset & dsites);
    TBranch(const TBranch & src) : Branch(src), m_label(src.m_label) {};
    virtual ~TBranch() {};              // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual Branch_ptr Clone()                    const;
    virtual branch_type Event()                   const { return btypeTip; };
    virtual branch_group BranchGroup()            const { return bgroupTip; };

    virtual long Cuttable()                       const { return 1; };
    virtual const Branch_ptr GetActiveChild(long) const { return Branch::NONBRANCH; };

    // Tree summarization helpers.
    // Some subclass functions (not this one) return results via the reference third argument.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const;

    // Debugging functions.
    virtual bool    CheckInvariant()              const;
    virtual bool    operator==(const Branch & src) const;
    virtual bool    IsSameExceptForTimes(const Branch_ptr other) const;
    virtual bool    RevalidateRange(FC_Status &) const;
    virtual void    PrintInfo_Br() const;

    // for writing GraphML output
    virtual void   AddNodeInfo(TiXmlElement *) const;
    virtual string GetGraphMLNodeType() const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class CBranch : public Branch
{
  private:
    CBranch();                                // Default ctor is undefined.
    CBranch & operator=(const CBranch & src); // Assignment operator is undefined.

  protected:
    // If newbranchisinactive == true, then child1rangeptr is assumed to point to the inactive branch Range
    // and child2rangeptr to point to the active branch Range.
    virtual Range * CreateRange(const Range * const child1rangeptr, const Range * const child2rangeptr,
                                bool  newbranchisinactive, const rangeset & fcsites) const;

  public:
    CBranch(const Range * const child1rangeptr, const Range * const child2rangeptr, bool newbranchisinactive, const rangeset & fcsites);
    CBranch(const CBranch & src) : Branch(src) {};
    virtual ~CBranch() {};              // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual Branch_ptr Clone()                  const;
    virtual branch_type Event()                 const { return btypeCoal; };
    virtual branch_group BranchGroup()          const { return bgroupBody; };

    virtual long    Cuttable()                  const { return 1; };
    virtual bool    CanRemove(Branch_ptr checkchild);
    virtual long    CountDown()                 const { return -2; };
    virtual void    UpdateBranchRange(const rangeset & fcsites, bool dofc);
    virtual void    UpdateRootBranchRange(const rangeset & fcsites, bool dofc);
    virtual void    SetUpdateDL()                     { m_updateDL = true; };
    virtual void    ReplaceChild(Branch_ptr oldchild, Branch_ptr newchild);
    virtual Branch_ptr OtherChild(Branch_ptr badchild);
    virtual bool CanCalcDL(long site) const;
    virtual bool ShouldCalcDL(long site) const { return m_updateDL && CanCalcDL(site); };
    virtual const Branch_ptr GetActiveChild(long site) const;

    // Tree summarization helpers.
    // Some subclass functions (this one does) return results via the reference third argument.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const;

    // Debugging functions.
    virtual bool    CheckInvariant()          const;
    virtual bool    RevalidateRange(FC_Status & fcstatus) const;

    // for writing GraphML output
    virtual string GetGraphMLNodeType() const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class PartitionBranch : public Branch
{
  private:
    PartitionBranch();                                        // Default ctor is undefined.
    PartitionBranch & operator=(const PartitionBranch & src); // Assignment operator is undefined.

  protected:
    Range * CreateRange(const Range * const childrangeptr) const;

  public:
    PartitionBranch(const Range * const childrangeptr);
    PartitionBranch(const PartitionBranch & src) : Branch(src) {};
    virtual ~PartitionBranch() {};      // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual long    Cuttable()             const { return 0; };
    virtual branch_group BranchGroup()     const { return bgroupBody; };
    virtual void    UpdateBranchRange(const rangeset & fcsites, bool dofc);
    virtual void    UpdateRootBranchRange(const rangeset & fcsites, bool dofc) { assert(false); };

    // Debugging function.
    virtual bool    CheckInvariant()       const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
// Abstract base class for migration-like branches (MIG, DIVMIG).

class MigLikeBranch : public PartitionBranch
{
  private:
    MigLikeBranch();                                      // Default ctor is undefined.
    MigLikeBranch & operator=(const MigLikeBranch & src); // Assignment operator is undefined.

  protected:
    // We accept PartitionBranch::CreateRange().

  public:
    MigLikeBranch(const Range * const protorangeptr);
    MigLikeBranch(const MigLikeBranch & src);
    virtual ~MigLikeBranch() {};        // Base-class dtor deletes the Range object pointed to by m_rangePtr.
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class MBranch : public MigLikeBranch
{
  private:
    MBranch();                                // Default ctor is undefined.
    MBranch & operator=(const MBranch & src); // Assignment operator is undefined.

  protected:
    // We accept PartitionBranch::CreateRange().

  public:
    MBranch(const Range * const protorangeptr);
    MBranch(const MBranch & src);
    virtual ~MBranch() {};              // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual Branch_ptr Clone()             const;
    virtual branch_type Event()            const { return btypeMig; };

    // Tree summarization helpers.
    // Some subclass functions (not this one) return results via the reference third argument.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const;

    // for writing GraphML output
    virtual string GetGraphMLNodeType() const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

// Migration nodes for Divergence Migration
class DivMigBranch : public MigLikeBranch
{
  private:
    DivMigBranch();                                     // Default ctor is undefined.
    DivMigBranch & operator=(const DivMigBranch & src); // Assignment operator is undefined.

  protected:
    // We accept PartitionBranch::CreateRange().

  public:
    DivMigBranch(const Range * const protorangeptr);
    DivMigBranch(const DivMigBranch & src);
    virtual ~DivMigBranch() {};         // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual Branch_ptr Clone()             const;
    virtual branch_type Event()            const { return btypeDivMig; };

    // Tree summarization helpers.
    // Some subclass functions (not this one) return results via the reference third argument.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const;

    // for writing GraphML output
    virtual string GetGraphMLNodeType() const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

// Disease mutation branches.  NOT related to Divergence!

class DBranch : public PartitionBranch
{
  private:
    DBranch();                                // Default ctor is undefined.
    DBranch & operator=(const DBranch & src); // Assignment operator is undefined.

  protected:
    // We accept PartitionBranch::CreateRange().

  public:
    DBranch(const Range * const protorangeptr);
    DBranch(const DBranch & src);
    virtual ~DBranch() {};              // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual Branch_ptr Clone()             const;
    virtual branch_type Event()            const { return btypeDisease; };
    virtual branch_group BranchGroup()     const { return bgroupBody; };

    // Tree summarization helpers.
    // Some subclass functions (not this one) return results via the reference third argument.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const;

    // for writing GraphML output
    virtual string GetGraphMLNodeType() const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class EBranch : public PartitionBranch
{
  private:
    EBranch();                                // Default ctor is undefined.
    EBranch & operator=(const EBranch & src); // Assignment operator is undefined.

  protected:
    // We accept PartitionBranch::CreateRange().

  public:
    EBranch(const Range * const protorangeptr) : PartitionBranch(protorangeptr) {};
    EBranch(const EBranch & src) : PartitionBranch(src) {};
    virtual ~EBranch() {};              // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual Branch_ptr Clone()         const;
    virtual branch_type Event()        const { return btypeEpoch; };
    virtual branch_group BranchGroup() const { return bgroupBody; };

    // Tree summarization helpers.
    // Some subclass functions (not this one) return results via the reference third argument.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const;

    // for writing GraphML output
    virtual string GetGraphMLNodeType() const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class RBranch : public Branch
{
  private:
    RBranch();                                // Default ctor is undefined.
    RBranch & operator=(const RBranch & src); // Assignment operator is undefined.

  protected:
    Range * CreateRange(const Range * const childrangeptr, bool isinactive,
                        const rangeset & transmittedsites, const rangeset & fcsites) const;

  public:
    RBranch(const Range * const childrangeptr, bool isinactive,
            const rangeset & transmittedsites, const rangeset & fcsites);
    RBranch(const RBranch & src) : Branch(src) {};
    virtual ~RBranch() {};              // Base-class dtor deletes the Range object pointed to by m_rangePtr.

    virtual Branch_ptr Clone()             const;
    virtual branch_type Event()            const { return btypeRec; };
    virtual branch_group BranchGroup()     const { return bgroupBody; };

    virtual void    CopyPartitionsFrom(Branch_ptr src);
    void    RecCopyPartitionsFrom(Branch_ptr src, FPartMap fparts, bool islow);

    virtual long    Cuttable()             const { return 1; };
    virtual long    CountDown()            const { return 1; };
    virtual void    UpdateBranchRange(const rangeset & fcsites, bool dofc);
    virtual void    UpdateRootBranchRange(const rangeset & fcsites, bool dofc) { assert(false); };
    virtual void    ReplaceChild(Branch_ptr oldchild, Branch_ptr newchild);
    virtual bool    IsRemovableRecombinationLeg(const rangeset &) const;
    virtual Branch_ptr GetRecPartner()     const;

    virtual long    GetRecSite_Br()        const { return m_rangePtr->GetRecSite_Rg(); };

    // Tree summarization helpers.
    // Some subclass functions (this one does) return results via the reference third argument.
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks) const;
    virtual void    ScoreEvent(TreeSummary & summary, BranchBuffer & ks, long & s) const;

    virtual bool    operator==(const Branch & src) const;

    // Debugging functions.
    virtual bool    CheckInvariant()          const;
    virtual bool    IsSameExceptForTimes(const Branch_ptr other) const;
    virtual bool    RevalidateRange(FC_Status & fcstatus) const;

    // for writing GraphML output
    virtual string GetGraphMLNodeType() const;
    virtual void   AddNodeInfo(TiXmlElement *) const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

// Free functions for use as STL predicates

class IsTipGroup : public std::unary_function<Branch_ptr, bool>
{
  public:
    bool operator()(const Branch_ptr t) { return t->BranchGroup() == bgroupTip; };
};

//------------------------------------------------------------------------------------

class IsBodyGroup : public std::unary_function<Branch_ptr, bool>
{
  public:
    bool operator()(const Branch_ptr t) { return t->BranchGroup() == bgroupBody; };
};

//------------------------------------------------------------------------------------

class IsCoalGroup : public std::unary_function<Branch_ptr, bool>
{
  public:
    bool operator()(const Branch_ptr t) { return t->Event() == btypeCoal; };
};

#endif // BRANCH_H

//____________________________________________________________________________________
