// $Id: collector.h,v 1.19 2011/03/07 06:08:52 bobgian Exp $

/*
  Copyright 2003 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

// Collector classes store information from the ongoing chain for
// later analysis.  They are related via a base class for convenience
// in initialization, but mostly used via pointer-to-derived because
// they summarize such different information.

// Mary 2003/12/17

#ifndef COLLECTOR_H
#define COLLECTOR_H

#include <fstream>
#include <utility>    // for pair
#include <vector>
#include "chainstate.h"
#include "tree.h"
#include "vectorx.h"
#include "mathx.h"

typedef std::vector<std::pair<ForceParameters,long> > ParamSumm;
typedef std::vector<std::pair<std::vector<double>,long> > StickSumm;

class ArrangerVec;

//------------------------------------------------------------------------------------
// Abstract base class for all Collectors
//------------------------------------------------------------------------------------

class Collector
{
  public:
    Collector();
    virtual ~Collector() {};
    virtual void Score(ChainState& chstate) = 0;
    virtual void CorrectForFatalAttraction(long region) { };
    virtual void UpdateArrangers(ArrangerVec& arrangers, ChainState& chstate) const { };
    virtual void WriteCollectionWhenScore(std::ofstream* out);
    virtual void WriteLastSummary() = 0;
    virtual void WriteAllSummaries(std::ofstream& out) = 0;

  private:
    // This class is not meant to be copied
    Collector(const Collector&);  // not defined
    Collector& operator=(const Collector&);  // not defined

  protected:
    bool m_areWriting;
    std::ofstream *m_sumout; //non-owning pointer

};

//------------------------------------------------------------------------------------
// Tree summary collector, also includes jointed stick (if any)
//------------------------------------------------------------------------------------

class TreeCollector : public Collector
{
  public:
    TreeCollector(); //Can't be default because of ForceParameters object.
    virtual ~TreeCollector();
    // these two are used directly by postlike routines
    vector<TreeSummary*> treeSummaries;  // public for speed of access
    ForceParameters forceParameters;     // public for speed of access

    virtual void Score(ChainState& chstate);
    virtual void WriteLastSummary();
    virtual void WriteAllSummaries(std::ofstream& out);
    virtual void CorrectForFatalAttraction(long region);
    virtual void AddTreeSummary(TreeSummary* ts);
    void SetStartParameters(const ForceParameters& src)
    { forceParameters = src; };
    long TreeCount() const;

  private:
    bool m_findbesttree;
    double m_besttreedatallike;
};

//------------------------------------------------------------------------------------
// Parameter summary collectors
//------------------------------------------------------------------------------------

class ParamCollector : public Collector
{
  public:
    virtual void Score(ChainState& chstate);
    virtual void AddParamSummary(ForceParameters fp, long ncopy);
    virtual void WriteLastSummary();
    virtual void WriteAllSummaries(std::ofstream& out);
    virtual void UpdateArrangers(ArrangerVec& arrangers, ChainState& chstate) const;
    const ParamSumm& GetParamSumm() const { return m_paramsum; }
    const DoubleVec1d GetLastParameterVec() const;

  private:
    ParamSumm m_paramsum;
    virtual void WriteParamSumm(unsigned long index);
};

//------------------------------------------------------------------------------------
// Map summary collector
//------------------------------------------------------------------------------------

class MapCollector : public Collector
{
  public:
    MapCollector(long region);
    virtual bool DoWeCollectFor(bool lastchain);
    virtual void Score(ChainState& chstate);
    virtual void AddMapSummary(DoubleVec2d& maplikes, long ncopy);
    virtual void WriteLastSummary();
    virtual void WriteAllSummaries(std::ofstream& out);
    virtual DoubleVec2d GetMapSummary();

  private:
    MapCollector(); //undefined
    long m_region;
    long m_nsamples;
    DoubleVec2d m_mapsum;     //Never logs!
    DoubleVec2d m_lastmapsum; //Logs if we're 'floating', 0's and a 1 if 'jumping'
    long m_lastcount;

    virtual void WriteVec1D(std::ofstream& sumout, DoubleVec1d& vec, rangeset range);
    virtual void AccumulateMap();
};

#endif // COLLECTOR_H

//____________________________________________________________________________________
