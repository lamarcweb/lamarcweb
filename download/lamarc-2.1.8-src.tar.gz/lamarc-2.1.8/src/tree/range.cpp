// $Id: range.cpp,v 1.47 2011/07/09 22:30:27 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <cassert>

#include "local_build.h"

#include "range.h"
#include "rangex.h"
#include "stringx.h"
#include "errhandling.h"
#include "registry.h"                   //for random.bool

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

// Note that most functions/variables defined here have "_Rg" (for "Range") as a suffix in their name.
// This is to distinguish them from functions/variables in class Branch ("_Br") or class Tree ("_Tr") of the same name.
// Exceptions are Clone and the constructors.

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

Range::Range(long int nsites)
    : m_numTotalSites_Rg(nsites)
{
    // Intentionally blank; everything is accomplished in initialization list above.
} // "Real" constructor for Range class.

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

Range * Range::Clone() const
{
    return new Range(*this);
} // Range::Clone

//------------------------------------------------------------------------------------
// This copy ctor is callable only by Range::Clone.

Range::Range(const Range & src)
    : m_numTotalSites_Rg(src.m_numTotalSites_Rg)
{
    // Intentionally blank; everything is accomplished in initialization list above.
} // Copy constructor for Range class.

//------------------------------------------------------------------------------------
// CountLinksFromLinks_Rg returns the number of possible links in the range of links sent to it.
// This is the only private member function in Range.

long int Range::CountLinksFromLinks_Rg(const rangeset & links) const
{
    if (links.empty()) return 0L;

    long int count(0L);
    rangeset::const_iterator my_range;
    for(my_range = links.begin(); my_range != links.end(); ++my_range)
    {
        count += my_range->second - my_range->first;
    }

    return count;

} // Range::CountLinksFromLinks_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).
// Polymorphic - Used in recombinant cases; should never be called (thus ASSERTs) in non-rec cases.

bool Range::AreChildTargetSitesTransmitted_Rg(const Range * const childrangeptr, const rangeset & fcsites) const
{
    assert(false);                      // Why are we asking this in a non-rec case?
    return false;                       // To silence compiler warning.
} // Range::AreChildTargetSitesTransmitted_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void Range::UpdateCRange_Rg(const Range * const child1rangeptr, const Range * const child2rangeptr,
                            const rangeset & fcsites, bool dofc)
{
    // Intentionally empty; nothing to do in non-rec case.
} // Range::UpdateCRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void Range::UpdateRootRange_Rg(const Range * const child1rangeptr, const Range * const child2rangeptr,
                               const rangeset & fcsites, bool dofc)
{
    // Intentionally empty; nothing to do in non-rec case.
} // Range::UpdateRootRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void Range::UpdateOneLeggedCRange_Rg(const Range * const childrangeptr)
{
    // Intentionally empty; nothing to do in non-rec case.
} // Range::UpdateOneLeggedCRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void Range::UpdateOneLeggedRootRange_Rg(const Range * const childrangeptr)
{
    // Intentionally empty; nothing to do in non-rec case.
} // Range::UpdateOneLeggedRootRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void Range::UpdateMRange_Rg(const Range * const child1rangeptr)
{
    // Intentionally empty; nothing to do in non-rec case.
} // Range::UpdateMRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).
// Polymorphic - Used in recombinant cases; should never be called (thus ASSERTs) in non-rec cases.

void Range::UpdateRRange_Rg(const Range * const child1rangeptr, const rangeset & fcsites, bool dofc)
{
    assert(false);
} // Range::UpdateRRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

bool Range::operator==(const Range & other) const
{
    return true;
} // Range::operator==

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).
// Polymorphic - Used in recombinant cases; should never be called (thus ASSERTs) in non-rec cases.

bool Range::AreLowSitesOnInactiveBranch_Rg(long int recsite) const
{
    assert(false);                      // Non rec case??
    return false;                       // To silence compiler warning.
} // Range::AreLowSitesOnInactiveBranch_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

bool Range::IsDiseaseSiteTransmitted_Rg() const
{
    return true;
} // Range::IsDiseaseSiteTransmitted_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void Range::ClearNewTargetLinks_Rg()
{
    // Intentionally empty; nothing to do in non-rec case.
} // Range::ClearNewTargetLinks_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void Range::SetOldInfoToCurrent_Rg()
{
    // Intentionally empty; nothing to do in non-rec case.
} // Range::SetOldInfoToCurrent_Rg()

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void Range::ResetOldTargetSites_Rg(const rangeset & fcsites)
{
    // Intentionally empty; nothing to do in non-rec case.
} // Range::ResetOldTargetSites_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).
// Polymorphic - Used in recombinant cases; should never be called (thus ASSERTs) in non-rec cases.

long int Range::GetRecSite_Rg() const
{
    assert(false);
    return FLAGLONG;

} // Range::GetRecSite_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).
// Called only by debugging function; virtual (must work differently on rec and non-rec Ranges).

bool Range::SameAsChild_Rg(const Range * const childrangeptr) const
{
    return true;
} // Range::SameAsChild_Rg

//------------------------------------------------------------------------------------
// Debugging function.
// Virtual function (Range and RecRange).

void Range::PrintLive_Rg() const
{
    cout << "Live sites:           " << ToString(MakeRangeset(0, m_numTotalSites_Rg)) << endl;
} // Range::PrintLive_Rg

//------------------------------------------------------------------------------------
// Debugging function.
// Virtual function (Range and RecRange).

void Range::PrintInfo_Rg() const
{
    cout << "All sites transmitted in non-rec Range." << endl;
    PrintLive_Rg();
    cout << "No Target links in non-rec Range." << endl;
    cout << "No New Target links in non-rec Range." << endl;
    cout << "No Old Target Sites in non-rec Range." << endl;
    cout << "No Old Target Links in non-rec Range." << endl;
}

//------------------------------------------------------------------------------------
// Debugging function.
// Virtual function (Range and RecRange).

void Range::PrintNewTargets_Rg() const
{
    cout << "There are no newly targetable links in a non-recombinant Range." << endl;
} // Range::PrintNewTargets_Rg

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

RecRange::RecRange(long int nsites, const rangeset & diseasesites, const rangeset & transmittedsites,
                   const rangeset & livesites, const rangeset & targetlinks, const rangeset & oldtargetlinks,
                   const rangeset & oldtargetsites, const rangeset & oldlivesites)
    : Range(nsites),
      m_liveSites_Rg(livesites),
      m_diseaseSites_Rg(diseasesites),
      m_transmittedSites_Rg(transmittedsites),
      m_targetLinks_Rg(targetlinks),
      m_numTargetLinks_Rg(CountLinksFromLinks_Rg(m_targetLinks_Rg)),
      m_oldTargetSites_Rg(oldtargetsites),
      m_oldLiveSites_Rg(oldlivesites),
      m_oldTargetLinks_Rg(oldtargetlinks),
      m_newTargetLinks_Rg(RemoveRangeFromRange(oldtargetlinks, m_targetLinks_Rg)),
      m_numNewTargetLinks_Rg(CountLinksFromLinks_Rg(m_newTargetLinks_Rg))
{
    // Intentionally blank; everything is accomplished in initialization list above.
} // "Real" constructor for RecRange class.

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

Range * RecRange::Clone() const
{
    return new RecRange(*this);
} // RecRange::Clone

//------------------------------------------------------------------------------------
// This copy ctor is callable only by RecRange::Clone.

RecRange::RecRange(const RecRange & src)
    : Range(src),
      m_liveSites_Rg(src.m_liveSites_Rg),
      m_diseaseSites_Rg(src.m_diseaseSites_Rg),
      m_transmittedSites_Rg(src.m_transmittedSites_Rg),
      m_targetLinks_Rg(src.m_targetLinks_Rg),
      m_numTargetLinks_Rg(src.m_numTargetLinks_Rg),
      m_oldTargetSites_Rg(src.m_oldTargetSites_Rg),
      m_oldLiveSites_Rg(src.m_oldLiveSites_Rg),
      m_oldTargetLinks_Rg(src.m_oldTargetLinks_Rg),
      m_newTargetLinks_Rg(src.m_newTargetLinks_Rg),
      m_numNewTargetLinks_Rg(src.m_numNewTargetLinks_Rg)
{
    // Intentionally blank; everything is accomplished in initialization list above.
} // Copy constructor for RecRange class.

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

bool RecRange::AreChildTargetSitesTransmitted_Rg(const Range * const childrangeptr, const rangeset & fcsites) const
{
    rangeset childtargetsites(Union(childrangeptr->GetDiseaseSites_Rg(),
                                    RemoveRangeFromRange(fcsites, childrangeptr->GetLiveSites_Rg())));
    rangeset included =  Intersection(childtargetsites, m_transmittedSites_Rg);
    return (!included.empty());

} // RecRange::AreChildTargetSitesTransmitted_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void RecRange::UpdateCRange_Rg(const Range * const child1rangeptr, const Range * const child2rangeptr,
                               const rangeset & fcsites, bool dofc)
{
    m_liveSites_Rg = Union(child1rangeptr->GetLiveSites_Rg(), child2rangeptr->GetLiveSites_Rg());

    rangeset targetsites(m_liveSites_Rg);
    if (dofc) targetsites = RemoveRangeFromRange(fcsites, m_liveSites_Rg);
    targetsites = Union(m_diseaseSites_Rg, targetsites);
    m_targetLinks_Rg = TargetLinksFrom(targetsites);
    m_numTargetLinks_Rg = CountLinksFromLinks_Rg(m_targetLinks_Rg);

    m_newTargetLinks_Rg = RemoveRangeFromRange(m_oldTargetLinks_Rg, m_targetLinks_Rg);
    m_numNewTargetLinks_Rg = CountLinksFromLinks_Rg(m_newTargetLinks_Rg);

#ifndef NDEBUG
    TestInvariants_Rg();
#endif

} // RecRange::UpdateCRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void RecRange::UpdateRootRange_Rg(const Range * const child1rangeptr, const Range * const child2rangeptr,
                                  const rangeset & fcsites, bool dofc)
{
    m_liveSites_Rg = Union(child1rangeptr->GetLiveSites_Rg(), child2rangeptr->GetLiveSites_Rg());

    rangeset targetsites(m_liveSites_Rg);
    if (dofc) targetsites = RemoveRangeFromRange(fcsites, m_liveSites_Rg);
    targetsites = Union(m_diseaseSites_Rg, targetsites);
    m_targetLinks_Rg = TargetLinksFrom(targetsites);
    m_numTargetLinks_Rg = CountLinksFromLinks_Rg(m_targetLinks_Rg);

    // All sites were live and targetable on the old root, so there are no new target sites.
    m_newTargetLinks_Rg.clear();
    m_numNewTargetLinks_Rg = 0;
    m_oldTargetSites_Rg = GetAllSites_Rg();
    m_oldTargetLinks_Rg = GetAllLinks_Rg();

#ifndef NDEBUG
    TestInvariants_Rg();
#endif

} // RecRange::UpdateRootRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void RecRange::UpdateOneLeggedCRange_Rg(const Range * const childrangeptr)
{
    m_liveSites_Rg = childrangeptr->GetLiveSites_Rg();

    m_targetLinks_Rg = childrangeptr->GetTargetLinks_Rg();
    m_numTargetLinks_Rg = childrangeptr->NumTargetLinks_Rg();

    // As a one-legged coalescence may coincide with a change in m_oldTargetLinks_Rg,
    // we must recalculate m_newTargetLinks_Rg here.
    m_newTargetLinks_Rg = RemoveRangeFromRange(m_oldTargetLinks_Rg, m_targetLinks_Rg);
    m_numNewTargetLinks_Rg = CountLinksFromLinks_Rg(m_newTargetLinks_Rg);

#ifndef NDEBUG
    TestInvariants_Rg();
#endif

} // RecRange::UpdateOneLeggedCRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void RecRange::UpdateOneLeggedRootRange_Rg(const Range * const childrangeptr)
{
    m_liveSites_Rg = childrangeptr->GetLiveSites_Rg();

    m_targetLinks_Rg = childrangeptr->GetTargetLinks_Rg();
    m_numTargetLinks_Rg = childrangeptr->NumTargetLinks_Rg();

    // All sites were live and targetable on the old root, so there are no new target sites.
    m_newTargetLinks_Rg.clear();
    m_numNewTargetLinks_Rg = 0;
    m_oldTargetSites_Rg = GetAllSites_Rg();
    m_oldTargetLinks_Rg = GetAllLinks_Rg();

#ifndef NDEBUG
    TestInvariants_Rg();
#endif

} // RecRange::UpdateOneLeggedRootRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void RecRange::UpdateMRange_Rg(const Range * const child1rangeptr)
{
    m_liveSites_Rg = child1rangeptr->GetLiveSites_Rg();

    m_targetLinks_Rg = child1rangeptr->GetTargetLinks_Rg();
    m_numTargetLinks_Rg = child1rangeptr->NumTargetLinks_Rg();
    m_newTargetLinks_Rg = child1rangeptr->GetNewTargetLinks_Rg();
    m_numNewTargetLinks_Rg = child1rangeptr->NumNewTargetLinks_Rg();

#ifndef NDEBUG
    TestInvariants_Rg();
#endif

} // RecRange::UpdateMRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).
// Called only in RecRange (in a recombinant branch); ASSERTs in Range (if in a non-rec situation).

void RecRange::UpdateRRange_Rg(const Range * const child1rangeptr, const rangeset & fcsites, bool dofc)
{
    m_liveSites_Rg = Intersection(child1rangeptr->GetLiveSites_Rg(), m_transmittedSites_Rg);

    rangeset targetsites(m_liveSites_Rg);
    if (dofc) targetsites = RemoveRangeFromRange(fcsites, targetsites);
    targetsites = Union(m_diseaseSites_Rg, targetsites);
    m_targetLinks_Rg = TargetLinksFrom(targetsites);
    m_numTargetLinks_Rg = CountLinksFromLinks_Rg(m_targetLinks_Rg);

    m_newTargetLinks_Rg = RemoveRangeFromRange(m_oldTargetLinks_Rg, m_targetLinks_Rg);
    m_numNewTargetLinks_Rg = CountLinksFromLinks_Rg(m_newTargetLinks_Rg);

#ifndef NDEBUG
    TestInvariants_Rg();
#endif

} // RecRange::UpdateRRange_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

bool RecRange::operator==(const Range & other) const
{
    return (m_liveSites_Rg == dynamic_cast<const RecRange &>(other).m_liveSites_Rg &&
            m_transmittedSites_Rg == dynamic_cast<const RecRange &>(other).m_transmittedSites_Rg &&
            m_targetLinks_Rg == dynamic_cast<const RecRange &>(other).m_targetLinks_Rg);

} // RecRange::operator==

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

bool RecRange::AreLowSitesOnInactiveBranch_Rg(long int recsite) const
{
    // If all old target sites on one side, that's the inactive side.
    if (!m_oldTargetSites_Rg.empty())
    {
        // -1 because it's a half-open interval; we want the actual last site.
        return (m_oldTargetSites_Rg.rbegin()->second - 1 <= recsite);
    }

    // Failing that, if all old live sites on one side, that's the inactive side.
    if (!Surrounds(m_oldLiveSites_Rg, recsite))
    {
        return (m_oldLiveSites_Rg.rbegin()->second - 1 <= recsite);
    }

    // Failing that, make a 50/50 random choice of inactive side.
    return registry.GetRandom().Bool();

} // RecRange::AreLowSitesOnInactiveBranch_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

bool RecRange::IsDiseaseSiteTransmitted_Rg() const
{
    if (m_diseaseSites_Rg.empty()) return true;

    for (set<rangepair>::const_iterator ri = m_diseaseSites_Rg.begin(); ri != m_diseaseSites_Rg.end(); ri++)
    {
        if (!IsInRangeset(m_transmittedSites_Rg, ri->first)) return false;
    }
    return true;

} // RecRange::IsDiseaseSiteTransmitted_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void RecRange::ClearNewTargetLinks_Rg()
{
    m_newTargetLinks_Rg = rangeset();
    m_numNewTargetLinks_Rg = 0L;

} // RecRange::ClearNewTargetLinks_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void RecRange::SetOldInfoToCurrent_Rg()
{
    m_oldLiveSites_Rg = m_liveSites_Rg;
    m_oldTargetLinks_Rg = m_targetLinks_Rg;

} // RecRange::SetOldInfoToCurrent_Rg()

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).

void RecRange::ResetOldTargetSites_Rg(const rangeset & fcsites)
{
    m_oldTargetSites_Rg = Union(m_diseaseSites_Rg, RemoveRangeFromRange(fcsites, m_liveSites_Rg));
} // RecRange::ResetOldTargetSites_Rg

//------------------------------------------------------------------------------------
// Debugging function.
// Virtual function (Range and RecRange).

void RecRange::PrintLive_Rg() const
{
    cout << "Live sites:           " << ToString(m_liveSites_Rg) << endl;
} // RecRange::PrintLive_Rg

//------------------------------------------------------------------------------------
// Debugging function.
// Virtual function (Range and RecRange).

void RecRange::PrintInfo_Rg() const
{
    cout << "Transmitted sites:    " << ToString(m_transmittedSites_Rg) << endl;
    PrintLive_Rg();
    cout << "Old live sites:       " << ToString(m_oldLiveSites_Rg) << endl;
    cout << "Target links:         " << ToString(m_targetLinks_Rg) << endl;
    PrintNewTargets_Rg();
    cout << "Old target sites:     " << ToString(m_oldTargetSites_Rg) << endl;
    cout << "Old target links:     " << ToString(m_oldTargetLinks_Rg) << endl;

    cout << "Num target links:     " << NumTargetLinks_Rg() << endl;
    if (m_numNewTargetLinks_Rg > 0)
    {
        cout << "Num new target links: " << m_numNewTargetLinks_Rg << endl;
    }
}

//------------------------------------------------------------------------------------
// Debugging function; RecRange only.

void RecRange::PrintDiseaseSites_Rg() const
{
    cout << "Disease sites:  " << ToString(m_diseaseSites_Rg) << endl;
} // RecRange::PrintDiseaseSites_Rg

//------------------------------------------------------------------------------------
// Debugging function.
// Virtual function (Range and RecRange).

void RecRange::PrintNewTargets_Rg() const
{
    cout << "Newly targetable links:  " << ToString(m_newTargetLinks_Rg) << endl;
} // RecRange::PrintNewTargets_Rg

//------------------------------------------------------------------------------------
// Debugging function; RecRange-only.

void RecRange::PrintRightOrLeft_Rg() const
{
    cout << "Right or left:  ";
    if (m_transmittedSites_Rg.begin()->first != 0L)
    {
        cout << "left";
    }
    else if (m_transmittedSites_Rg.begin()->second != m_numTotalSites_Rg)
    {
        cout << "right";
    }
    else
    {
        cout << "unset";
    }

    cout << endl;

} // RecRange::PrintRightOrLeft_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).
// Called only on recombinant trees (other than debugging) - BOBGIAN.

long int RecRange::GetRecSite_Rg() const
{
    if (m_transmittedSites_Rg.begin()->first != 0L)
    {
        return m_transmittedSites_Rg.begin()->first - 1;
    }
    else if (m_transmittedSites_Rg.begin()->second != m_numTotalSites_Rg)
    {
        return m_transmittedSites_Rg.begin()->second - 1;
    }

    return FLAGLONG;

} // RecRange::GetRecSite_Rg

//------------------------------------------------------------------------------------
// Virtual function (Range and RecRange).
// Called only by debugging function; virtual (must work differently on rec and non-rec Ranges).

bool RecRange::SameAsChild_Rg(const Range * const childrangeptr) const
{
    return m_liveSites_Rg == childrangeptr->GetLiveSites_Rg() && m_targetLinks_Rg == childrangeptr->GetTargetLinks_Rg();
} // RecRange::SameAsChild_Rg

//------------------------------------------------------------------------------------
// Debugging function in RecRange class only.

void RecRange::TestInvariants_Rg() const
{
    // JDEBUG -- augment to test that the "num" variables are correct; possibly also add a rangeset validator.
    bool good = true;

    for (set<rangepair>::const_iterator ri = m_diseaseSites_Rg.begin(); ri != m_diseaseSites_Rg.end(); ri++)
    {
        if (ri->first < 0) good = false;
        if (ri->first >= m_numTotalSites_Rg) good = false;
    }

    assert(good);

} // RecRange::TestInvariants_Rg

//____________________________________________________________________________________
