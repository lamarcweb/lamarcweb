// $Id: tree.h,v 1.79 2011/08/18 16:57:57 jyamato Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

/*******************************************************************
 Class Tree represents a genealogy (not necessarily a "tree" in the recombinant cases).  It has two subtypes,
 a PlainTree (no recombination) and a RecTree (with recombination) because the recombination machinery is too
 expensive to carry if you don't need it.

 Normally all Trees used during rearrangement come from either copying an existing tree
 or copying the prototype tree in Registry.

 DEBUG:  This class is a monster.  Anything to make it simpler would be good.

 Written by Jim Sloan, heavily revised by Mary Kuhner

 02/08/05 Pulled out locus specific stuff into LocusLike class -- Mary
 2004/9/15 Killed the LocusLike class, merging into Locus
 2005/3/1 Moved alias info, reluctantly, from DLCalc to Tree (because
    DLCalc is a shared object and the alias is not shareable!) -- Mary
 2006/02/13 Begun to add jointed stick
*******************************************************************/

#ifndef TREE_H
#define TREE_H

#include <cmath>
#include <string>
#include <vector>

#include "timelist.h"                   // for TimeList member
#include "individual.h"                 // for IndVec member
#include "locus.h"
#include "vectorx.h"
#include "constants.h"
#include "definitions.h"
#include "rangex.h"
#include "locus.h"      // for DataModel

// Note that some functions/variables defined here have "_Tr" (for "Tree") as a suffix in their name.
// This is to distinguish them from functions/variables in class Range (or RecRange) of the same name, which use "_Rg".

//------------------------------------------------------------------------------------

// typedef also used by Event and Arranger
typedef std::pair<Branch_ptr, Branch_ptr> branchpair;

class TreeSummary;                      // return type of SummarizeTree()
class TipData;
class Random;
class ForceParameters;
class TimeManager;

//------------------------------------------------------------------------------------

class Tree
{
  private:
    Tree(const Tree &);                 // undefined
    Tree & operator=(const Tree &);     // undefined

    vector<LocusCell> m_protoCells;     // cache of locuscells for all loci

    vector<Branch_ptr> FindAllBranchesAtTime(double eventT);

  protected:
    Tree();
    Tree(const Tree & tree, bool makestump);
    IndVec          m_individuals;        // associates tips from same individual
    double          m_overallDL;          // data log-likelihood
    LongVec2d       m_aliases;            // dim: loci x markers
    Random *        m_randomSource;       // non-owning pointer
    TimeList        m_timeList;           // all lineages
    vector<Locus> * m_pLocusVec;          // not owning.  Also, not const because of simulation
    long            m_totalSites;         // span of entire region, including gaps
    TimeManager *   m_timeManager;        // our timemanager....
    bool            m_hasSnpPanel;        // the region that created this tree includes SNP panel data

    // A "timelist" iterator to the the branch after the cut during rearrangement. Set by ActivateBranch().
    // Used during mid-rearrangement so that CopyPartialBody() & Rectree::Prune() can be done quicker.
    // This member is not copied!
    Branchiter    m_firstInvalid;

    // Protected rearrangement primitives.
    virtual void    Break(Branch_ptr pBranch) = 0;
    void    SetFirstInvalidFrom(Branchconstiter & target);
    void    SetFirstInvalid() { m_firstInvalid = m_timeList.BeginBranch(); };
    void    MarkForDLRecalc(Branch_ptr br);

    // Protected Branch-management primitives.
    const vector<LocusCell> & CollectCells(); // Get locuscells for all loci.
    vector<Branch_ptr>  GetTips(StringVec1d & names)  const;

  public:
    // Creation and destruction.
    virtual           ~Tree();
    virtual Tree     *Clone()                 const = 0;
    virtual Tree     *MakeStump()             const = 0;
    virtual void      Clear();
    virtual void      CopyTips(const Tree * tree);
    virtual void      CopyBody(const Tree * tree);
    virtual void      CopyStick(const Tree * tree);
    virtual void      CopyPartialBody(const Tree * tree);
    virtual TBranch_ptr CreateTip(const TipData & tipdata, const vector<LocusCell> & cells,
                                  const vector<LocusCell> & movingcells, const rangeset & diseasesites);
    virtual TBranch_ptr CreateTip(const TipData & tipdata, const vector<LocusCell> & cells,
                                  const vector<LocusCell> & movingcells, const rangeset & diseasesites,
                                  const vector<Locus> & loci);
    void      SetTreeTimeManager(TimeManager * tm);

    // Getters.
    TimeList & GetTimeList()                 { return m_timeList; };
    const TimeList & GetTimeList()           const { return m_timeList; };
    virtual rangevector GetLocusSubtrees(rangepair span) const;
    Branch_ptr     GetTip(const std::string & name) const;
    TimeManager * GetTimeManager()           { return m_timeManager; };
    const TimeManager * GetTimeManager()     const { return m_timeManager; };
    double      RootTime()                  const { return m_timeList.RootTime(); };
    bool        NoPhaseUnknownSites()       const;
    long        GetNsites()                 const;

    bool GroomForGrowth(const DoubleVec1d & thetas, const DoubleVec1d & growths, double temperature);
    bool GroomForLogisticSelection(const DoubleVec1d & thetas,
                                   double s, // logistic selection coefficient or zero
                                   double temperature);
    bool GetSnpPanelFlag() { return m_hasSnpPanel; };

    // Setters.
    void SetIndividualsWithTips(const vector<Individual> & indvec);
    void SetLocusVec(vector<Locus> * loc);
    void SetSnpPanelFlag(bool flag) { m_hasSnpPanel = flag; };

    // Likelihood manipulation.
    virtual void      CalculateDataLikes() = 0;
    virtual double    CalculateDataLikesForFixedLoci();
    double    GetDLValue()            const { return m_overallDL; };
    const LongVec1d & GetAliases(long loc) const { return m_aliases[loc]; };
    void      SetupAliases(const std::vector<Locus> & loci);

    // Rearrangement primitives.
    virtual vector<Branch_ptr> ActivateTips(Tree * othertree);
    virtual Branch_ptr   ActivateBranch(Tree * othertree);
    virtual Branch_ptr   ActivateRoot(FC_Status & fcstatus);

    // ChoosePreferentiallyTowardsRoot does not break the tree, but does set m_firstInvalid.
    // to the interval containing the return value.  So does ChooseFirstBranchInEpoch.
    Branch_ptr   ChoosePreferentiallyTowardsRoot(Tree * othertree);
    Branch_ptr   ChooseFirstBranchInEpoch(double targettime, Tree * othertree);

    virtual void      AttachBase(Branch_ptr newroot);
    virtual vector<Branch_ptr> FindBranchesImmediatelyTipwardOf(Branchiter start);
    vector<Branch_ptr> FindBranchesBetween(double startinterval, double stopinterval);
    virtual vector<Branch_ptr> FirstInterval(double eventT);
    virtual void      NextInterval(Branch_ptr branch );
    virtual void      Prune();
    void      TrimStickToRoot();
    void      SwapSiteDLs();
    virtual void      PickNewSiteDLs();
    virtual void      ReassignDLsFor(std::string lname, long marker, long ind);
    void      SetNewTimesFrom(Branchiter start, const DoubleVec1d & newtimes);
    Branch_ptr TransitionEpoch(double eventT, long newpop, long maxevents, Branch_ptr pActive);
    vector<Branch_ptr> FindBranchesStartingOnOpenInterval(double starttime, double endtime);
    vector<Branch_ptr> FindEpochBranchesAt(double time);
    vector<Branch_ptr> FindBranchesStartingRootwardOf(double time);

    // Force-specific rearrangement primitives.
    Branch_ptr   Coalesce(Branch_ptr child1, Branch_ptr child2, double tevent, const rangeset & fcsites);

    virtual Branch_ptr   CoalesceActive(double eventT, Branch_ptr active1,
                                        Branch_ptr active2, const rangeset & fcsites);
    virtual Branch_ptr   CoalesceInactive(double eventT, Branch_ptr active,
                                          Branch_ptr inactive, const rangeset & fcsites);
    virtual Branch_ptr   Migrate(double eventT, long topop, long maxEvents, Branch_ptr active);
    virtual Branch_ptr   DiseaseMutate(double eventT, long endstatus, long maxEvents, Branch_ptr active);

    // TreeSummaryFactory.
    TreeSummary * SummarizeTree() const;

    // Invariant checking.
    bool      IsValidTree()               const;  // check invariants (debugging function)
    bool      ConsistentWithParameters(const ForceParameters& fp) const;  // debugging function
    bool      operator==(const Tree & src) const; // compare trees
    bool      operator!=(const Tree & src) const { return !(*this == src); };

    // TimeManager call throughs (we provide a public front for TimeManager).  CopyStick() is also in this category.
    void DestroyStick();
    void SetStickParams(const ForceParameters & fp);
    bool UsingStick() const;
    void ScoreStick(TreeSummary & treesum) const;
    DoubleVec1d XpartThetasAtT(double time, const ForceParameters & fp) const;
    DoubleVec1d PartitionThetasAtT(double time, force_type force, const ForceParameters & fp) const;

    // TreeSizeArranger.
    virtual void  SetTargetLinksFrom(const BranchBuffer & brbuffer) { }; // no-op
    virtual void  ClearTargetLinks() { };                                // no-op

    // Simulation.
    virtual bool  SimulateDataIfNeeded();
    virtual long  NumberOfRecombinations() = 0;

    // Debugging functions.
    // MakeCoalescent strips all migration nodes from the tree and forces all remaining
    // coalescences to their expectation times.  DO NOT use with migration!
    void MakeCoalescent(double theta) { m_timeList.MakeCoalescent(theta); };
    //
    // DLCheck returns an error message with the first marker at which each branch pair differs;
    // unmentioned branches don't differ.
    void DLCheck(const Tree & other) const;
    //
    // Call through debugging code.
    void PrintStickThetasToFile(std::ofstream & of) const;
    void PrintStickFreqsToFile(std::ofstream & of) const;
    void PrintStickFreqsToFileAtTime(std::ofstream & of, double time) const;
    void PrintStickThetasToFileForJoint300(std::ofstream & of) const;
    void PrintStickToFile(std::ofstream & of) const;
    void PrintDirectionalMutationEventCountsToFile(std::ofstream & of) const;
    void PrintTimeTilFirstEventToFile(std::ofstream & of) const;
    void PrintTraitPhenotypeAtLastCoalescence(std::ofstream & of) const;
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class PlainTree : public Tree
{
  public:
    // Creation and destruction.
    PlainTree() : Tree()  {};
    PlainTree(const Tree & tree, bool makestump) :
        Tree(tree, makestump)       {};
    virtual          ~PlainTree()        {};
    virtual Tree     *Clone()                 const;
    virtual Tree     *MakeStump()             const;
    virtual void      CalculateDataLikes();
    virtual void      Break(Branch_ptr pBranch);
    virtual long      NumberOfRecombinations() { return 0L; };

    // Yes, everything else is the same as Tree.
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

// To keep track of final coalescences:
typedef std::map<long, rangeset> rangesetcount;
typedef std::map<long, rangeset>::iterator RSCIter;
typedef std::map<long, rangeset>::const_iterator RSCcIter;
typedef std::list<std::pair<double, rangesetcount> > sitecountlist;

//------------------------------------------------------------------------------------

class RecTree : public Tree
{
  private:
    long      m_numTargetLinks_Tr;
    long      m_numNewTargetLinks_Tr;
    std::set<long> GetBreakpoints() const;

  protected:
    vector<Locus> *    m_pMovingLocusVec; // Not owning.  But we can change 'em!
    vector<LocusCell> m_protoMovingCells;

    virtual  void     Break(Branch_ptr branch);
    const vector<LocusCell> & CollectMovingCells();

  public:
    // Creation and destruction.
    RecTree();
    RecTree(const RecTree & tree, bool makestump);
    ~RecTree() {};

    virtual  Tree    *Clone()     const;
    virtual  Tree    *MakeStump() const;
    virtual  void     Clear();
    virtual  void     CopyTips(const Tree * tree);
    virtual  void     CopyBody(const Tree * tree);
    virtual  void     CopyPartialBody(const Tree * tree);

    // Getters.
    virtual  rangevector GetLocusSubtrees(rangepair span) const;
    long     NumTargetLinks_Tr() const    { return m_numTargetLinks_Tr; };
    long     NumNewTargetLinks_Tr() const { return m_numNewTargetLinks_Tr; };
    unsigned long GetNumMovingLoci()      { return m_pMovingLocusVec->size(); };
    virtual  bool DoesThisLocusJump(long mloc) const;
    virtual  bool AnyRelativeHaplotypes() const;

    // Setters.
    void      SetMovingLocusVec(vector<Locus> * locs);
    void      SetMovingMapposition(long mloc, long site);

    virtual TBranch_ptr CreateTip(const TipData & tipdata, const vector<LocusCell> & cells,
                                  const vector<LocusCell> & movingcells, const rangeset & diseasesites);

    virtual TBranch_ptr CreateTip(const TipData & tipdata, const vector<LocusCell> & cells,
                                  const vector<LocusCell> & movingcells, const rangeset & diseasesites,
                                  const vector<Locus> & loci);

    // Likelihood manipulation.
    virtual void        CalculateDataLikes();
    virtual double      CalculateDataLikesForMovingLocus(long mloc);
    virtual DoubleVec1d CalculateDataLikesForFloatingLocus(long mloc);
    virtual DoubleVec1d CalculateDataLikesWithRandomHaplotypesForFloatingLocus(long mloc);
    virtual void CalculateDataLikesForAllHaplotypesForFloatingLocus(long mloc, DoubleVec1d & mlikes);
    virtual bool UpdateDataLikesForIndividualsFrom(long ind, long mloc, DoubleVec1d & mlikes);

    // Rearrangement primitives.
    virtual  vector<Branch_ptr> ActivateTips(Tree * othertree);
    virtual  Branch_ptr  ActivateBranch(Tree * othertree);
    virtual  Branch_ptr  ActivateRoot(FC_Status & fcstatus);
    virtual  void     AttachBase(Branch_ptr newroot);
    virtual  vector<Branch_ptr> FirstInterval(double eventT);
    virtual  void     NextInterval(Branch_ptr branch);
    virtual  void     Prune();
    virtual  void     ReassignDLsFor(std::string lname, long marker, long ind);

    // Force-specific rearrangement primitives.
    virtual Branch_ptr   CoalesceActive(double eventT, Branch_ptr active1,
                                        Branch_ptr active2, const rangeset & fcsites);
    virtual Branch_ptr   CoalesceInactive(double eventT, Branch_ptr active,
                                          Branch_ptr inactive, const rangeset & fcsites);
    virtual Branch_ptr   Migrate(double eventT, long topop, long maxEvents, Branch_ptr active);
    virtual Branch_ptr   DiseaseMutate (double eventT, long endstatus, long maxEvents, Branch_ptr active);
    branchpair RecombineActive(double eventT, long maxEvents, FPartMap fparts,
                               Branch_ptr active, long recsite, const rangeset & fcsites);
    branchpair RecombineInactive(double eventT, long maxEvents, FPartMap fparts,
                                 Branch_ptr active, long recsite, const rangeset & fcsites);

    // Map Summary.
    DoubleVec2d  GetMapSummary();
    std::set<long> IgnoreDisallowedSubTrees(std::set<long> breakpoints, rangeset allowedranges);
    DoubleVec1d ZeroDisallowedSites(DoubleVec1d datalikes, rangeset allowedranges);
    void RandomizeMovingHaplotypes(long mlocus);

    // Simulation.
    virtual bool SimulateDataIfNeeded();
    virtual long NumberOfRecombinations();

    // TreeSizeArranger.
    virtual void  SetTargetLinksFrom(const BranchBuffer & brbuffer);
    virtual void  ClearTargetLinks() { m_numTargetLinks_Tr = 0; };

    // Debugging functions.
    virtual void  SetNewTargetLinksFrom(const BranchBuffer & brbuffer);
    virtual void PrintTipData(long mloc, long marker);
    virtual void PrintRangeSetCount(const rangesetcount & rsc);
    virtual rangesetcount RemoveEmpty(const rangesetcount & rsc);
};

#endif // TREE_H

//____________________________________________________________________________________
