// $Id: collmanager.h,v 1.16 2012/05/22 20:25:32 jyamato Exp $

/*
  Copyright 2003 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

// The CollectionManager class contains all the Collectors and hands out
// information about them.

// Mary 2003/12/17

#ifndef COLLMANAGER_H
#define COLLMANAGER_H

#include <vector>
#include <utility>    // for pair
#include "vectorx.h"
#include "arranger.h"
#include "collector.h"
#include "forcesummary.h"
#include "chainstate.h"
#include "local_build.h"

class ArrangerVec;

//------------------------------------------------------------------------------------
// Collection manager
//------------------------------------------------------------------------------------

// typedef std::vector<std::pair<ForceSummary, long> > ParamSummary;
// ForceSummary object is supposed to be a Singleton.  Commenting typedef
// out to make sure it's not being used.  Jon 2012/05/21

class CollectionManager
{
  private:
    // this class is a singleton and is not to be copied
    CollectionManager();                                    // not defined
    CollectionManager(const CollectionManager&);            // not defined
    CollectionManager& operator=(const CollectionManager&); // not defined

    // dimensions of these are regions x replicates
    std::vector<std::vector<TreeCollector*> > m_treecoll;
    std::vector<std::vector<ParamCollector*> > m_paramcoll;
    std::vector<std::vector<MapCollector*> > m_mapcoll;

    long m_region;
    long m_replicate;
    bool m_sample_trees;
    bool m_sample_params;
    bool m_sample_maps;

  public:
    CollectionManager(long nregions, long nreplicates);
    ~CollectionManager();

    // Sample
    void Collect(ChainState& chstate, long initialOrFinal, bool lastchain);         // EWFIX.CHAINTYPE
    void WriteTraceFile(ChainState& chstate, long initialOrFinal);  // EWFIX.CHAINTYPE
    void WriteNewickTreeFile(ChainState& chstate);
    void WriteRecSitesFile(ChainState& chstate, bool lastchain);    // EWFIX.CHAINTYPE
#ifdef LAMARC_QA_TREE_DUMP
    void WriteArgFile(ChainState& chstate, bool lastchain);
#endif
    void CorrectForFatalAttraction(long region);
    void StartChain(long reg, long rep, bool lastchain);
    void WriteThisChainsCollections(std::ofstream* out) const;
    void WriteLastSummaries() const;
    void WriteAllSummaries(long reg, long rep, std::ofstream& out) const;

    // Fetch packages of samples
    TreeCollector* GetTreeColl(long region, long rep) const;
    std::vector<TreeCollector*> GetTreeColl(long region) const;
    std::vector<std::vector<TreeCollector*> > GetTreeColl() const;

    ParamCollector* GetParamColl(long region, long rep) const;
    std::vector<ParamCollector*> GetParamColl(long region) const;
    std::vector<std::vector<ParamCollector*> > GetParamColl() const;

    MapCollector* GetMapColl(long region, long rep) const;
    std::vector<MapCollector*> GetMapColl(long region) const;
    std::vector<std::vector<MapCollector*> > GetMapColl() const;

    // Inform Arrangers of changes
    void UpdateArrangers(ArrangerVec& arrangers, ChainState& chstate) const;

    bool GetSampleTrees() const { return m_sample_trees; };
};

#endif  // COLLMANAGER_H

//____________________________________________________________________________________
