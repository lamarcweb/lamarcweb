// $Id: intervaldata.h,v 1.24 2011/04/23 02:02:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

/*
  This file contains two closely related classes used in storing
  TreeSummaries.  The first class, Interval, represents all data
  gathered from one time interval in a given tree.  It holds a
  "next" pointer to the next Intervals *of a given event type* (for
  example, a coalescent Interval, one with a coalescence event at
  the bottom, will hold a pointer to the next coalescent Interval).
  These pointers are NULL when there is no such Interval.

  Intervals are meant to be kept within an ordered std::list that
  keeps them in time order; the "next" system is independent of
  that and is used by maximizer code that requires lightning-fast
  access to the next event of the same type.

  The second class, IntervalData, contains and manages Intervals
  and also contains and manages the force-specific Summary objects
  that offer access to them.

  Written by Mary Kuhner
*/

#ifndef INTERVALDATA_H
#define INTERVALDATA_H

#include <fstream>
#include <list>
#include <map>

#include "constants.h"
#include "defaults.h"
#include "vectorx.h"
#include "types.h"
// #include "summary.h" for management of summaries

//------------------------------------------------------------------------------------

class Summary;

typedef std::map<string, double> Forcemap;
typedef std::map<string, double>::iterator Forcemapiter;
typedef std::map<force_type, Summary*> Summap;

//------------------------------------------------------------------------------------

struct Interval
{
    double endtime;  // time at the rootward end of the interval
    // we do not store starttime but rely on computing it on the fly
    LongVec1d xpartlines; // length is cross partition
    LongVec2d partlines;  // length is partition force by partition
    long activesites;  // used only for recombination
    xpart_t oldstatus;    // used for partition events
    // also used for coal events, tracks xpart index
    xpart_t newstatus;    // used for partition events
    long recsite;      // used only for recombination
    Interval* next;  // points to the next interval of the same force or NULL

    // the following is used only if both recombination and a local
    // partition force are in effect
    LongVec1d partnerpicks; // length is (local) partition forces

    force_type type; //The Interval class could be refactored to be polymorphic
    //              by force, which would alleviate some issues here with
    //              writing out the data, but would be tricky elsewhere, since
    //              the interval list would have to be pointers.
    Interval(double etime, const LongVec2d& plines,
             const LongVec1d& xlines, long actives, long ostat, long nstat,
             long rsite, const LongVec1d& picks, force_type ftype)
        : endtime(etime), xpartlines(xlines),
          partlines(plines),
          activesites(actives), oldstatus(ostat), newstatus(nstat),
          recsite(rsite), next(NULL), partnerpicks(picks), type(ftype) {}

    // warning WARNING -- this will lead to intertwined lists if much usage
    //   is made of std::list functionality!
    // believe it or not, we accept the default copy constructor and
    // operator=.  The pointers are NOT owning, and copying them is
    // necessary for its current usage.
};

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

class IntervalData
{
  private:
    IntervalData& operator=(const IntervalData&); // not defined
    IntervalData(const IntervalData& src);        // not defined

  public:

    // the following is a List for iterator stability
    // warning WARNING -- do not use std::list functionality that
    // modifies the whole list at once (like splice or operator=).
    // Non-modifying or single element modifying are usable.
    std::list<Interval> intervals;

    // we must define the default constructor, since we disallow
    // the copy constructor and that prevents compiler generation of it
    IntervalData() {};

    Interval* AddInterval(Interval* prev, double time, const LongVec2d& pk,
                          const LongVec1d& xk, long s, xpart_t ostat, xpart_t nstat, long recsite,
                          const LongVec1d& picks, force_type type);

    // This AddInterval variant is used when a dummy interval is being
    // added as part of fatal attraction prevention code
    Interval* AddDummyInterval(Interval* prev, long s, xpart_t ostat,
                               xpart_t nstat, long recsite, force_type type);

    unsigned long size() { return intervals.size(); };

    std::list<Interval>::iterator begin() { return intervals.begin(); };
    std::list<Interval>::const_iterator begin() const { return intervals.begin(); };
    std::list<Interval>::iterator end() { return intervals.end(); };
    std::list<Interval>::const_iterator end() const { return intervals.end(); };
    void clear() { intervals.clear(); };

    // This function is used when writing tree summaries with growth
    void WriteIntervalData(std::ofstream& sumout) const;

    // debug function
    void PrintIntervalData() const;

};

#endif // INTERVALDATA_H

//____________________________________________________________________________________
