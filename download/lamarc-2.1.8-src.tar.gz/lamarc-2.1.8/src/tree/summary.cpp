// $Id: summary.cpp,v 1.50 2012/05/08 20:14:24 mkkuhner Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <cassert>
#include <cmath>
#include <iostream>

#include "constants.h"
#include "intervaldata.h"
#include "region.h"
#include "summary.h"
#include "force.h"

using namespace std;

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

const DoubleVec1d & Summary::GetShortPoint() const
{
    return m_shortpoint;

} // Summary::ShortPoint

//------------------------------------------------------------------------------------

const DoubleVec1d & Summary::GetShortWait() const
{
    return m_shortwait;
} // Summary::ShortWait

//------------------------------------------------------------------------------------

const LongVec2d & Summary::GetShortPicks() const
{
    return m_shortpicks;
} // Summary::ShortPicks

//------------------------------------------------------------------------------------

Interval const * Summary::GetLongPoint() const
{
    assert(!m_shortness);  // tried to get long-form inappropriately?
    return m_front;
} // Summary::LongPoint

//------------------------------------------------------------------------------------

const list<Interval> & Summary::GetLongWait() const
{
    assert(!m_shortness);  // tried to get long-form inappropriately?
    return m_intervalData.intervals;
}  // Summary::LongWait

//------------------------------------------------------------------------------------

bool Summary::GetShortness() const
{
    return m_shortness;
}

//------------------------------------------------------------------------------------

void Summary::AddInterval(double time, const LongVec2d & pk,
                          const LongVec1d & xk, long s, xpart_t ostat,
                          xpart_t nstat, long recsite,
                          const LongVec1d & picks, force_type type)
{
    // add interval, retaining a pointer to it
    Interval* thisinterval = m_intervalData.AddInterval(m_back, time, pk, xk, s, ostat, nstat, recsite, picks, type);
    // put that pointer in appropriate place(s)
    if (!m_front) m_front = thisinterval;
    m_back = thisinterval;
    // m_intervalData.PrintIntervalData(); // JRM debug

} // Summary::AddInterval

//------------------------------------------------------------------------------------

bool Summary::Compress()
{
    ComputeShortWait();
    ComputeShortPoint();
    ComputeShortPicks();
    return m_shortness;
} // Summary::Compress

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

Summary * CoalSummary::Clone(IntervalData& interval) const
{
    // NB:  This takes a reference to the IntervalData to which
    // the new Summary will belong.  It does *not* copy the
    // contents of the old Summary; only the type and m_shortness.

    return new CoalSummary(interval, m_shortness);
} // Clone

//------------------------------------------------------------------------------------

void CoalSummary::ComputeShortPoint()
{
    // set up the recipient vector
    m_shortpoint.assign(m_nparams, 0.0);

    Interval* in;

    for (in = m_front; in != NULL; in = in->next)
    {
        ++m_shortpoint[in->oldstatus];
    }

} // CoalSummary::ComputeShortPoint

//------------------------------------------------------------------------------------

void CoalSummary::ComputeShortWait()
{
    // set up the recipient vector
    m_shortwait.assign(m_nparams, 0.0);

    list<Interval>::const_iterator interval = m_intervalData.begin();
    list<Interval>::const_iterator end = m_intervalData.end();
    double starttime = 0.0;

    for ( ; interval != end; ++interval)
    {
        double deltaTime = (*interval).endtime - starttime;
        long param;
        for (param = 0; param < m_nparams; ++param)
        {
            // OPT:  pre-calculate k(k-1) in storage routines....
            double k = (*interval).xpartlines[param];
            m_shortwait[param] += deltaTime * k * (k - 1);
        }
        starttime = (*interval).endtime;
    }

} // CoalSummary::ComputeShortWait

//------------------------------------------------------------------------------------

void CoalSummary::ComputeShortPicks()
{
    const ForceSummary & fs = registry.GetForceSummary();
    long numlocalforces = fs.GetNLocalPartitionForces();

    // if there are no local-partition-forces, do nothing
    if (numlocalforces == 0) return;
    // if there is no recombination, do nothing
    if (!fs.CheckForce(force_REC)) return;

    m_shortpicks.clear();
    const ForceVec& forces = fs.GetPartitionForces();
    unsigned long i;
    long index = 0;
    for (i = 0; i < forces.size(); ++i)
    {
        if (forces[i]->IsLocalPartitionForce())
        {
            const PartitionForce* partforce =
                dynamic_cast<const PartitionForce*>(forces[i]);
            long nparts = partforce->GetNPartitions();
            LongVec1d counts(nparts, 0L);
            list<Interval>::const_iterator interval = m_intervalData.begin();
            list<Interval>::const_iterator end = m_intervalData.end();
            for ( ; interval != end; ++interval)
            {
                if (!(*interval).partnerpicks.empty())
                {
                    ++counts[(*interval).partnerpicks[index]];
                }
            }
            m_shortpicks.push_back(counts);
            ++index;
        }
    }
} // CoalSummary::ComputeShortPicks

//------------------------------------------------------------------------------------

void CoalSummary::AdjustSummary(const DoubleVec1d & totals, long region)
{

    Interval* fakefront = NULL;
    Interval* fakeback = NULL;
    assert(totals.size()==m_shortpoint.size()); // inconsistent input?
    unsigned long nparams(totals.size());
    bool didadjust = false;

    unsigned long param;
    for(param = 0; param < nparams; ++param)
    {
        if (totals[param] != 0.0) continue;

        if (!m_shortness)
        {
            didadjust = true;
            Interval * newinterval =
                m_fakeIntervals.AddDummyInterval(fakeback, 0L, param, FLAGLONG, FLAGLONG, force_COAL);

            if (!fakefront) fakefront = newinterval;
            fakeback = newinterval;
        }

        // adjust short-form summary statistics
        m_shortpoint[param] += 1.0;
    }

    if (didadjust)
    {
        // hook fake intervals onto front of real intervals
        fakeback->next = m_front;
        m_front = fakefront;
    }

} // CoalSummary::AdjustSummary

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

Summary * MigSummary::Clone(IntervalData& interval) const
{
    // NB:  This takes a reference to the IntervalData to which
    // the new Summary will belong.  It does *not* copy the
    // contents of the old Summary; only the type and m_shortness.

    return new MigSummary(interval, m_shortness);
} // Clone

//------------------------------------------------------------------------------------

void MigSummary::ComputeShortPoint()
{
    // set up the recipient vector
    m_shortpoint.assign(m_npop * m_npop, 0.0);

    Interval* in;

    for (in = m_front; in != NULL; in = in->next)
    {
        // Migration rates vary newstatus on rows and oldstatus on columns
        ++m_shortpoint[m_npop * in->newstatus + in->oldstatus];
    }

} // MigSummary::ComputeShortPoint

//------------------------------------------------------------------------------------

void MigSummary::ComputeShortWait()
{
    // set up the recipient vector
    m_shortwait.assign(m_npop, 0.0);

    list<Interval>::const_iterator interval = m_intervalData.begin();
    list<Interval>::const_iterator end = m_intervalData.end();
    long pop;
    double starttime = 0.0;

    for ( ; interval != end; ++interval)
    {
        double deltaTime = (*interval).endtime - starttime;
        for (pop = 0; pop < m_npop; ++pop)
        {
            double k = (*interval).partlines[m_migpartindex][pop];
            m_shortwait[pop] += deltaTime * k;
        }
        starttime = (*interval).endtime;
    }

} // MigSummary::ComputeShortWait

//------------------------------------------------------------------------------------

void MigSummary::AdjustSummary(const DoubleVec1d & totals, long region)
{
    assert(static_cast<xpart_t>(totals.size()) == m_npop*m_npop);
    Interval* fakefront = NULL;
    Interval* fakeback = NULL;

    //LS NOTE: It's possible that this will add a migration event for a
    // migration that's been constrained to be zero.  However, the maximizer
    // ignores all such events in this case, so adding one is not fatal.  Though
    // one should be wary.

    bool didadjust = false;

    xpart_t frompop, topop;

    for (frompop = 0; frompop != m_npop; ++frompop)
    {
        for (topop = 0; topop != m_npop; ++topop)
        {

            // no adjustment to diagonal entries
            if (frompop == topop) continue;

            long param = frompop * m_npop + topop; // index into linearized vector
            if (totals[param] == 0.0)              // no events of this type
            {
                if (!m_shortness)
                {
                    didadjust = true;

                    // add fake interval
                    Interval* newinterval =
                        m_fakeIntervals.AddDummyInterval(fakeback, 0L, frompop, topop, FLAGLONG, force_MIG);
                    if (!fakefront) fakefront = newinterval;
                    fakeback = newinterval;
                }

                // adjust short-form summary statistics
                m_shortpoint[param] += 1.0;
            }
        }
    }

    if (didadjust)
    {
        // hook fake intervals onto front of real intervals
        fakeback->next = m_front;
        m_front = fakefront;
    }
} // MigSummary::AdjustSummary

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

Summary * DiseaseSummary::Clone(IntervalData& interval) const
{
    // NB:  This takes a reference to the IntervalData to which
    // the new Summary will belong.  It does *not* copy the
    // contents of the old Summary; only the type and m_shortness.

    return new DiseaseSummary(interval, m_shortness);
} // Clone

//------------------------------------------------------------------------------------

void DiseaseSummary::ComputeShortPoint()
{
    // set up the recipient vector
    m_shortpoint.assign(m_nstati * m_nstati, 0.0);

    Interval* in;

    for (in = m_front; in != NULL; in = in->next)
    {
        // Disease rates vary newstatus on rows and oldstatus on columns
        ++m_shortpoint[m_nstati * in->newstatus + in->oldstatus];
    }

} // DiseaseSummary::ComputeShortPoint

//------------------------------------------------------------------------------------

void DiseaseSummary::ComputeShortWait()
{
    // set up the recipient vector
    m_shortwait.assign(m_nstati, 0.0);

    list<Interval>::const_iterator interval = m_intervalData.begin();
    list<Interval>::const_iterator end = m_intervalData.end();
    long status;
    double starttime = 0.0;

    for ( ; interval != end; ++interval)
    {
        double deltaTime = (*interval).endtime - starttime;
        for (status = 0; status < m_nstati; ++status)
        {
            double k = (*interval).partlines[m_dispartindex][status];
            m_shortwait[status] += deltaTime * k;
        }
        starttime = (*interval).endtime;
    }

} // DiseaseSummary::ComputeShortWait

//------------------------------------------------------------------------------------

void DiseaseSummary::AdjustSummary(const DoubleVec1d & totals, long region)
{
    assert(static_cast<xpart_t>(totals.size()) == m_nstati*m_nstati);
    Interval* fakefront = NULL;
    Interval* fakeback = NULL;

    bool didadjust = false;

    xpart_t oldstatus, newstatus;

    for (oldstatus = 0; oldstatus != m_nstati; ++oldstatus)
    {
        for (newstatus = 0; newstatus != m_nstati; ++newstatus)
        {

            // no adjustment to diagonal entries
            if (oldstatus == newstatus) continue;

            // index into linearized vector
            long param = oldstatus * m_nstati + newstatus;

            if (totals[param] == 0.0)   // no events of this type
            {
                if (!m_shortness)
                {
                    didadjust = true;

                    // add fake interval
                    Interval* newinterval =
                        m_fakeIntervals.AddDummyInterval(fakeback, 0L, oldstatus, newstatus, FLAGLONG, force_DISEASE);
                    if (!fakefront) fakefront = newinterval;
                    fakeback = newinterval;
                }

                // adjust short-form summary statistics
                m_shortpoint[param] += 1.0;
            }
        }
    }

    if (didadjust)
    {
        // hook fake intervals onto front of real intervals
        fakeback->next = m_front;
        m_front = fakefront;
    }
} // DiseaseSummary::AdjustSummary

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

Summary * EpochSummary::Clone(IntervalData& interval) const
{
    // NB:  This takes a reference to the IntervalData to which
    // the new Summary will belong.  It does *not* copy the
    // contents of the old Summary; only the type and m_shortness.

    return new EpochSummary(interval, m_shortness);
} // Clone

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

RecSummary::RecSummary(IntervalData& interval, bool shortform)
    :
    Summary(interval,registry.GetForceSummary().GetNParameters(force_REC), shortform),
    m_nrecsbyxpart(registry.GetForceSummary().GetNParameters(force_COAL), 0L),
    m_nrecs(0L)
{
    long i(0L);
    const ForceVec forces(registry.GetForceSummary().GetPartitionForces());
    ForceVec::const_iterator force;

    (void)i;  // Silence compiler warning about unused variable.

    for(force = forces.begin(); force != forces.end(); ++force)
    {
        if ((*force)->IsLocalPartitionForce())
        {
            LongVec1d fparts((*force)->GetNPartitions(), 0L);
            m_nrecsbydispart = fparts;
        }
    }

} // RecSummary::ctor

//------------------------------------------------------------------------------------

Summary * RecSummary::Clone(IntervalData& interval) const
{
    // NB:  This takes a reference to the IntervalData to which
    // the new Summary will belong.  It does *not* copy the
    // contents of the old Summary; only the type and m_shortness.

    return new RecSummary(interval, m_shortness);
} // Clone

//------------------------------------------------------------------------------------

void RecSummary::ComputeShortPoint()
{
    // set up the recipient vector
    m_shortpoint.assign(m_nparams, 0.0);

    Interval* in;
    for (in = m_front; in != NULL; in = in->next)
    {
        ++m_shortpoint[0];
    }

} // RecSummary::ComputeShortPoint

//------------------------------------------------------------------------------------

void RecSummary::ComputeShortWait()
{
    // set up the recipient vector
    m_shortwait.assign(m_nparams, 0.0);

    list<Interval>::const_iterator interval = m_intervalData.begin();
    list<Interval>::const_iterator end = m_intervalData.end();
    double starttime = 0.0;
    //  long count=1;
    for ( ; interval != end; ++interval)
    {
        double deltaTime = (*interval).endtime - starttime;
        m_shortwait[0] += deltaTime * (*interval).activesites;
        starttime = (*interval).endtime;
#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
        cout << "ShortWait "
             << count++
             << ": ts="
             << (*interval).starttime
             << " te="
             << (*interval).endtime
             << " actsites="
             << (*interval).activesites
             << " r="
             << m_shortwait[0]
             << endl;
#endif
    }

} // RecSummary::ComputeShortWait

//------------------------------------------------------------------------------------

void RecSummary::AdjustSummary(const DoubleVec1d & totals, long region)
{
    assert(totals.size() == 1);  // inconsistent forces?!
    if (!registry.GetDataPack().GetRegion(region).RecombinationCanBeEstimated())
    {
        return;
    }
    Interval* fakefront = NULL;
    Interval* fakeback = NULL;
    bool didadjust = false;

    long param = 0;
    if (totals[param] == 0.0)  // no events of this type
    {
        if (!m_shortness)
        {
            didadjust = true;

            // add fake interval
            Interval* newinterval =
                m_fakeIntervals.AddDummyInterval(fakeback, 0L, FLAGLONG, FLAGLONG, 0L, force_REC);
            if (!fakefront) fakefront = newinterval;
            fakeback = newinterval;
        }

        // adjust short-form summary statistics
        m_shortpoint[param] += 1.0;
    }
    if (didadjust)
    {
        // hook fake intervals onto front of real intervals
        fakeback->next = m_front;
        m_front = fakefront;
    }
} // RecSummary::AdjustSummary

//------------------------------------------------------------------------------------

void RecSummary::AddToRecombinationCounts(const LongVec1d & membership)
{
    // MDEBUG THIS CODE ASSUMES A DISEASE FORCE EXISTS!
    // m_nrecsbyxpart
    m_nrecsbyxpart[registry.GetDataPack().GetCrossPartitionIndex(membership)]++;

    // m_nrecsbydispart
    // it also assumes that Disease is the first (and only) local partition force
    long lpforce = registry.GetForceSummary().GetLocalPartitionIndexes()[0];
    m_nrecsbydispart[membership[lpforce]]++;
    m_nrecs++;

} // RecSummary::AddToRecombinationCounts

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

Summary * DivMigSummary::Clone(IntervalData& interval) const
{
    // NB:  This takes a reference to the IntervalData to which
    // the new Summary will belong.  It does *not* copy the
    // contents of the old Summary; only the type and m_shortness.

    return new DivMigSummary(interval, m_shortness);
} // Clone

//------------------------------------------------------------------------------------

void DivMigSummary::ComputeShortPoint()
{

    // set up the recipient vector
    m_shortpoint.assign(m_npop * m_npop, 0.0);

    Interval* in;

    for (in = m_front; in != NULL; in = in->next)
    {
        // Migration rates vary newstatus on rows and oldstatus on columns
        ++m_shortpoint[m_npop * in->newstatus + in->oldstatus];
    }

} // DivMigSummary::ComputeShortPoint

//------------------------------------------------------------------------------------

void DivMigSummary::ComputeShortWait()
{
    // set up the recipient vector
    m_shortwait.assign(m_npop * m_npop, 0.0);

    list<Interval>::const_iterator interval = m_intervalData.begin();
    list<Interval>::const_iterator end = m_intervalData.end();
    long pop;
    vector<Epoch>::const_iterator curepoch(m_epochs->begin());
    LongVec1d epochpops(curepoch->PopulationsHere());
    double starttime = 0.0;

    for ( ; interval != end; ++interval)
    {
        double deltaTime = (*interval).endtime - starttime;

        if (interval->type == force_DIVERGENCE)
        {
            ++curepoch;
            assert(curepoch != m_epochs->end());
            epochpops = curepoch->PopulationsHere();
        }

        for (pop = 0; pop < m_npop; ++pop)
        {
            double k = (*interval).partlines[m_divmigpartindex][pop];

            // now add k * deltaTime to all populations extant in this epoch
            LongVec1d::iterator epop;
            for(epop = epochpops.begin(); epop != epochpops.end(); ++epop)
            {
                if (pop == (*epop)) continue;
                // Migration rates vary newstatus on rows and oldstatus on columns
                m_shortwait[(*epop) * m_npop + pop] += deltaTime * k;
            }
        }
        starttime = (*interval).endtime;
    }

} // DivMigSummary::ComputeShortWait

//------------------------------------------------------------------------------------

void DivMigSummary::AdjustSummary(const DoubleVec1d & totals, long region)
{
} // DivMigSummary::AdjustSummary

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

void Summary::AddShortPoint(string s)
{
    double a = static_cast<long>(atoi(s.c_str()));
    m_shortpoint.push_back(a);
}

//------------------------------------------------------------------------------------

void Summary::AddShortWait(string s)
{
    double a = static_cast<double>(atof(s.c_str()));
    m_shortwait.push_back(a);
}

//------------------------------------------------------------------------------------

void Summary::AddShortPicks(const StringVec1d & svec)
{
    LongVec1d newpicks;
    StringVec1d::const_iterator values;

    for(values = svec.begin(); values != svec.end(); ++values)
    {
        long a = static_cast<long>(atoi(values->c_str()));
        newpicks.push_back(a);
    }

    m_shortpicks.push_back(newpicks);
}

//____________________________________________________________________________________
