// $Id: priorreport.cpp,v 1.6 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <cassert>
#include <algorithm> // for std::find

#include "priorreport.h"
#include "force.h"
#include "parameter.h"
#include "prior.h"

//------------------------------------------------------------------------------------

PriorReport::PriorReport(const Force& theforce) :
    m_forcename(theforce.GetFullName())
{
    const vector<Parameter>& params(theforce.GetParameters());

    vector<Parameter>::const_iterator param;
    for(param = params.begin(); param != params.end(); ++param)
    {
        if (!(param->IsValidParameter())) continue;
        if (param->GetStatus().Status() == pstat_constant) continue;

        vector<Prior>::iterator found(std::find(m_priors.begin(), m_priors.end(), param->GetPrior()));
        if (found != m_priors.end())
            m_whichparams[std::distance(m_priors.begin(),found)].
                push_back(param->GetUserName());
        else
        {
            StringVec1d newname(1UL,param->GetUserName());
            m_whichparams.push_back(newname);
            m_priors.push_back(param->GetPrior());
        }
    }
} // PriorReport ctor

//------------------------------------------------------------------------------------

void PriorReport::WriteTo(std::ofstream& outf) const
{
    assert(m_whichparams.size() == m_priors.size());

    outf << m_forcename << " Priors" << std::endl;
    outf << "parameter(s)   type   bounds" << std::endl;
    unsigned long ind, nind(m_whichparams.size());
    for(ind = 0; ind < nind; ++ind)
    {
        string line(m_whichparams[ind][0]);
        line += " | " + ToString(m_priors[ind].GetPriorType());
        line += " | " + ToString(m_priors[ind].GetLowerBound());
        line += " to " + ToString(m_priors[ind].GetUpperBound());
        outf << line << std::endl;
        StringVec1d::const_iterator addtlname(m_whichparams[ind].begin());
        for(++addtlname; addtlname != m_whichparams[ind].end(); ++addtlname)
            outf << *addtlname << " -- as above" << std::endl;
        outf << std::endl;
    }
} // PriorReport::WriteTo

//____________________________________________________________________________________
