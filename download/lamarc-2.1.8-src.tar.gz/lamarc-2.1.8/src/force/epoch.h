// $Id: epoch.h,v 1.3 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

//------------------------------------------------------------------------------------

#ifndef EPOCH_H
#define EPOCH_H

#include <vector>

//------------------------------------------------------------------------------------

class Epoch
{
  public:
    Epoch(const std::vector<long>& here, const std::vector<long>& departing, long arriving);

    const std::vector<long>& PopulationsHere() const { return m_here; };
    const std::vector<long>& Departing() const { return m_departing; };
    long Arriving() const { return m_arriving; };

  private:
    std::vector<long> m_here;
    std::vector<long> m_departing;
    long m_arriving;
};

//------------------------------------------------------------------------------------

#endif

//____________________________________________________________________________________
