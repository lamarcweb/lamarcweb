// $Id: stair.h,v 1.4 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef STAIR_H
#define STAIR_H

#include<list>
#include "vectorx.h"

//------------------------------------------------------------------------------------

class StairRiser
{
  public:
    StairRiser(const DoubleVec1d& thetas, double tiptime, double roottime);
    // we accept the default copy ctor, operator= and dtor.
    bool operator<(const StairRiser& other) const;

    void SetThetas(const DoubleVec1d& thetas);
    void SetTipendTime(double newtime);
    void SetRootendTime(double newtime);

    DoubleVec1d GetThetas() const;
    double GetTipendTime() const;
    double GetRootendTime() const;

  private:
    DoubleVec1d m_thetas;
    double m_tiptime, m_roottime; // times at the tipward and rootward edge of
    // a riser.

    StairRiser();                 // the default ctor is disabled.

};

//------------------------------------------------------------------------------------

typedef std::list<StairRiser>     stair;

#endif // STAIR_H

//____________________________________________________________________________________
