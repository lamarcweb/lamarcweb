// $Id: gc_strings_io.h,v 1.5 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_STRINGS_IO_H
#define GC_STRINGS_IO_H

#include "wx/string.h"

class gc_io
{
  public:
    static const wxString eof;
    static const wxString fileMissing;
    static const wxString fileReadError;
    static const wxString fileReadErrorWithName;
};

#endif  // GC_STRINGS_IO_H

//____________________________________________________________________________________
