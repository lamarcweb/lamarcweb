// $Id: gc_strings_region.cpp,v 1.9 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_strings_region.h"
#include "wx/intl.h"

const wxString gcstr_region::effPopSize     =wxTRANSLATE("Relative effective population size: %.2f");
const wxString gcstr_region::internalName   =           "internalGroup_%ld";
const wxString gcstr_region::locusMapPosition       =   "(%d : %s)";
const wxString gcstr_region::mapPosition            =   "@ %ld";
const wxString gcstr_region::numLoci        =wxTRANSLATE("Number of segments: %d");

// const wxString gcstr_region::samplesPer     =wxTRANSLATE("Samples per individual: %d");
const wxString gcstr_region::tabTitle       =wxTRANSLATE("Properties of %d Regions");
const wxString gcstr_region::traitIndexListMember   =   "%d ";

//____________________________________________________________________________________
