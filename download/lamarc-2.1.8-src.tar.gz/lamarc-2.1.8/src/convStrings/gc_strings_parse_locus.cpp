// $Id: gc_strings_parse_locus.cpp,v 1.3 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_strings_parse_locus.h"
#include "wx/intl.h"

const wxString gcstr_parselocus::nameLong = wxTRANSLATE("segment number %ld read during parsing of %s");
const wxString gcstr_parselocus::nameShort= wxTRANSLATE("segment %ld of %s");

//____________________________________________________________________________________
