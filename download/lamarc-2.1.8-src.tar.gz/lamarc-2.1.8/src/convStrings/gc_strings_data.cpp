// $Id: gc_strings_data.cpp,v 1.5 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_strings_data.h"
#include "wx/intl.h"

const wxString gcerr_data::missingPopLocus =   wxTRANSLATE("Did not find any data for population \"%s\" at segment \"%s\". Please remove or merge populations, segments, and regions as appropriate.");
const wxString gcerr_data::missingPopRegion=   wxTRANSLATE("Did not find any data for population \"%s\" at region \"%s\". Please remove or merge populations, segments, and regions as appropriate.");

//____________________________________________________________________________________
