// $Id: gc_strings_map.cpp,v 1.5 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_strings_map.h"
#include "wx/intl.h"

const wxString gcstr_map::notXmlMapFileTryOldFmt    =wxTRANSLATE("%s. Trying to read %s as old map file format.");

const wxString gcerr_map::ERR_BAD_TOP_TAG   =wxTRANSLATE("expected top xml tag of <%s> but got <%s> instead.");
const wxString gcerr_map::fileEmpty         =wxTRANSLATE("File %s empty");
const wxString gcerr_map::fileMissing       =wxTRANSLATE("File %s missing");
const wxString gcerr_map::fileReadErr       =wxTRANSLATE("Unknown error while reading file %s");

//____________________________________________________________________________________
