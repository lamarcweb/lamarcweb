// $Id: gc_strings_region.h,v 1.6 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_STRINGS_REGION_H
#define GC_STRINGS_REGION_H

#include "wx/string.h"

class gcerr_region
{
  public:
};

class gcstr_region
{
  public:
    static const wxString effPopSize;
    static const wxString internalName;
    static const wxString locusMapPosition;
    static const wxString mapPosition;
    static const wxString numLoci;
    // static const wxString samplesPer;
    static const wxString tabTitle;
    static const wxString traitIndexListMember;
};

#endif  // GC_STRINGS_REGION_H

//____________________________________________________________________________________
