// $Id: gc_strings_phase.cpp,v 1.11 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_strings_phase.h"
#include "wx/intl.h"

const wxString gcerr_phase::adjacentPhaseForMultiSample = wxTRANSLATE("Cannot group adjacent samples from file %s into single individuals -- each sample is already a multi-phase sample");
const wxString gcerr_phase::badIndMatchAdjacencyValue = wxTRANSLATE("Cannot group each \"%s\" adjacent samples into single individual. Please use an integer greater or equal to 2.");
const wxString gcerr_phase::badIndMatchType  = wxTRANSLATE("Bad value \"%s\" for individual-matching type attribute. Current legal values are: byAdjacency");
const wxString gcerr_phase::badTopTag = wxTRANSLATE("expected top xml tag of <%s> but got <%s> instead");
const wxString gcerr_phase::bothIndividualAndSample = wxTRANSLATE("Name \"%s\" appears as both an individual name and a sample name. This is not legal.");
const wxString gcerr_phase::individualPhenotypeNameRepeat = wxTRANSLATE("Phenotype \"%s\" appears more once for individual \"%s\".");
const wxString gcerr_phase::markerNotLegal =wxTRANSLATE("unresolved phase position \"%s\" illegal -- must be an integer.");
const wxString gcerr_phase::matchingConfusion = wxTRANSLATE("Cannot determine how to match up all data samples in region %s.\n\nPlease write a converter command file specifying individual and sample relationships using the <individuals> tag.\n\nSamples that need information include \"%s\" and \"%s\".");
const wxString gcerr_phase::mergeMismatch = wxTRANSLATE("Cannot resolve the following individuals\n\n%s\n\n%s\n\nIf present, sample names must match and occur in the same order.");
const wxString gcerr_phase::noIndividualForSample = wxTRANSLATE("No information found relating sample %s to any individual");
const wxString gcerr_phase::noSampleForIndividual = wxTRANSLATE("No information found relating individual %s to any samples");
const wxString gcerr_phase::notLocation = wxTRANSLATE("Cannot assign unresolved phase to marker at position %ld in segment \"%s\" because the segment locations do not include it.");
const wxString gcerr_phase::tooLarge = wxTRANSLATE("Cannot assign unresolved phase to marker at position %ld for individual \"%s\" because position is too large. Segment \"%s\" has largest marker position of %ld.");
const wxString gcerr_phase::tooSmall = wxTRANSLATE("Cannot assign unresolved phase to marker at position %ld for individual \"%s\" because position is too small. Segment \"%s\" has smallest marker position of %ld.");
const wxString gcerr_phase::unevenAdjDivisor      = wxTRANSLATE("Cannot evenly allocate %d samples to individuals with %d samples each.");

const wxString gcstr_phase::adjacentHaps1     =   wxTRANSLATE("Group every ");
const wxString gcstr_phase::adjacentHaps2     =   wxTRANSLATE(" adjacent samples into one individual");
const wxString gcstr_phase::descFileAdjacency =   wxTRANSLATE("induced by adjacency near line %s of file %s, and containing samples %s");
const wxString gcstr_phase::descMultiPhase    =   wxTRANSLATE("induced by multiploid data near line %s of file %s, and containing samples %s");
const wxString gcstr_phase::descPhaseFile     =   wxTRANSLATE("%s defined near line %s of file %s, and containing samples %s");
const wxString gcstr_phase::known   =   wxTRANSLATE("known");
const wxString gcstr_phase::unknown =   wxTRANSLATE("unknown");

//____________________________________________________________________________________
