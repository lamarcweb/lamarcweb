// $Id: gc_strings_structures.h,v 1.10 2011/12/01 22:32:42 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_STRINGS_STRUCTURES_H
#define GC_STRINGS_STRUCTURES_H

#include "wx/string.h"

class gcstr_structures
{
  public:
    static const wxString objDict;
    static const wxString traitDict;
};

class gcerr_structures
{
  public:

    static const wxString duplicateFileBaseName;
    static const wxString duplicateFileName;
    static const wxString duplicateName;

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
    static const wxString locusMergeFailure;
    static const wxString locusHapMismatch;
    static const wxString locusLengthMismatch;
    static const wxString locusTypeMismatch;
    static const wxString missingLocus;
#endif

    static const wxString migrationNotDefined;
    static const wxString mismatchAlleleTrait;
    static const wxString mismatchLocusRegion;

    static const wxString missingFile;
    static const wxString missingMigration;
    static const wxString missingMigrationId;
    static const wxString missingName;
    static const wxString missingPopulation;
    static const wxString missingPanel;
    static const wxString missingPanelId;
    static const wxString missingParent;
    static const wxString missingParentId;
    static const wxString missingRegion;
    static const wxString missingTrait;
    static const wxString nameRepeatAllele;
    static const wxString nameRepeatLocus;
    static const wxString nameRepeatPop;
    static const wxString nameRepeatRegion;
    static const wxString nameRepeatTrait;
    static const wxString panelBlessedError;
    static const wxString panelNotDefined;
    static const wxString panelSizeClash;
    static const wxString regionEffPopSizeClash;
    // static const wxString regionSamplesPerClash;
    static const wxString unparsableFile;
};

#endif  // GC_STRINGS_STRUCTURES_H

//____________________________________________________________________________________
