// $Id: gc_strings_cmdfile.h,v 1.10 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_STRINGS_CMDFILE_H
#define GC_STRINGS_CMDFILE_H

#include "wx/string.h"

class gcerr_cmdfile
{
  public:
    static const wxString atRow;

    static const wxString badCmdFile;
    static const wxString badFileFormat;
    static const wxString badGeneralDataType;
    static const wxString badInterleaving;
    static const wxString badProximity;
    static const wxString badSpecificDataType;
    static const wxString badYesNo;

    static const wxString deprecatedGeneralDataType;

    static const wxString inCmdFile;
    static const wxString inFile;

    static const wxString locusMatchByNameNotEmpty;
    static const wxString locusMatchSingleEmpty;
    static const wxString locusMatchUnknown;

    static const wxString messageIs;

    static const wxString popMatchByNameNotEmpty;
    static const wxString popMatchSingleEmpty;
    static const wxString popMatchUnknown;
};

class gcstr_cmdfile
{
  public:
    static const wxString cmdFilesSelect;
};

#endif  // GC_STRINGS_CMDFILE_H

//____________________________________________________________________________________
