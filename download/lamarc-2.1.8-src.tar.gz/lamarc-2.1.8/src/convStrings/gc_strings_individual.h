// $Id: gc_strings_individual.h,v 1.5 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_STRINGS_INDIVIDUAL_H
#define GC_STRINGS_INDIVIDUAL_H

#include "wx/string.h"

class gcerr_ind
{
  public:
    static const wxString missingPhaseForLocus;
    static const wxString phaseLocusRepeat;
    static const wxString sampleLocusRepeat;
    static const wxString sampleMissingLocusData;
    static const wxString wrongSampleCount;
};

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
class gcstr_individual
{
  public:
};
#endif

#endif  // GC_STRINGS_INDIVIDUAL_H

//____________________________________________________________________________________
