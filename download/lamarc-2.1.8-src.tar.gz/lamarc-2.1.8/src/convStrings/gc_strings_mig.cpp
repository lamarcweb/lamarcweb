// $Id: gc_strings_mig.cpp,v 1.2 2011/12/30 22:50:10 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_strings_mig.h"
#include "wx/intl.h"

const wxString gcstr_mig::internalName = "internalMig_%ld";
const wxString gcstr_mig::migmethodUser     =   wxTRANSLATE("USER");
const wxString gcstr_mig::migmethodFST      =   wxTRANSLATE("FST");
const wxString gcstr_mig::migprofileNone        =   wxTRANSLATE("None");
const wxString gcstr_mig::migprofileFixed       =   wxTRANSLATE("Fixed");
const wxString gcstr_mig::migprofilePercentile  =   wxTRANSLATE("Percentile");
const wxString gcstr_mig::migconstraintInvalid      = wxTRANSLATE("Invalid");
const wxString gcstr_mig::migconstraintConstant     = wxTRANSLATE("Constant");
const wxString gcstr_mig::migconstraintSymmetric    = wxTRANSLATE("Symmetric");
const wxString gcstr_mig::migconstraintUnconstained = wxTRANSLATE("Unconstrained");

//____________________________________________________________________________________
