// $Id: gc_strings_individual.cpp,v 1.6 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_strings_individual.h"
#include "wx/intl.h"

const wxString gcerr_ind::missingPhaseForLocus  = wxTRANSLATE("Individual \"%s\" is missing phase data for segment \"%s\".\n\nDid you write a phase information file?");
const wxString gcerr_ind::phaseLocusRepeat      = wxTRANSLATE("Attempted to add phase data to individual \"%s\" from segment \"%s\" a second time.\n\nCheck to see if individual name is duplicated.");
const wxString gcerr_ind::sampleLocusRepeat     = wxTRANSLATE("Attempted to add data to sample \"%s\" from segment \"%s\" a second time.\n\nCheck to see if sample name is duplicated.");
const wxString gcerr_ind::sampleMissingLocusData= wxTRANSLATE("Cannot find data for sample \"%s\" of segment \"%s\".\n\nYou may need to provide individual/sample resolution information in a phase file.");
const wxString gcerr_ind::wrongSampleCount      = wxTRANSLATE("Individual \"%s\" has conflicting sample counts for data.");

//____________________________________________________________________________________
