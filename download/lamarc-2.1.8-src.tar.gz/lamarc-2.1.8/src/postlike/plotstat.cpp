// $Id: plotstat.cpp,v 1.10 2010/03/17 17:25:59 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <cassert>
#include <vector>
#include "plotstat.h"

//------------------------------------------------------------------------------------

ProfileLineStruct::ProfileLineStruct()
    : loglikelihood(0.0),
      percentile(0.0),
      profilevalue(0.0),
      profparam(),
      isExtremeHigh(false),
      isExtremeLow(false),
      maximizerWarning(false)
{
}

ProfileLineStruct::~ProfileLineStruct()
{
}

//------------------------------------------------------------------------------------

const ProfileLineStruct& ProfileStruct::GetProfileLine(double percentile) const
{
    vector<ProfileLineStruct>::const_iterator prof;
    for(prof = profilelines.begin(); prof != profilelines.end(); ++prof)
        if (percentile == prof->percentile)
            return *prof;

    assert(false);
    return(*prof);
}

//____________________________________________________________________________________
