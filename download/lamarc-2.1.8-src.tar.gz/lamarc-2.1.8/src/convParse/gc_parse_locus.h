// $Id: gc_parse_locus.h,v 1.12 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_PARSE_LOCUS_H
#define GC_PARSE_LOCUS_H

#include "gc_types.h"
#include "wx/string.h"

class GCParse;

class GCParseLocus
{
  private:
    GCParseLocus();     // undefined

    const GCParse *     m_parse;
    size_t              m_indexInParse;
    size_t              m_lineNumber;
    size_t              m_numMarkers;

  public:
    GCParseLocus(   const GCParse *     parse,
                    size_t              indexInParse,
                    size_t              lineNumber,
                    size_t              numMarkers);
    ~GCParseLocus();

    const GCParse &     GetParse()              const ;
    size_t              GetIndexInParse()       const ;
    size_t              GetLineNumber()         const ;
    size_t              GetNumMarkers()         const ;
    gcGeneralDataType   GetDataType()           const ;

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
    gcSpecificDataType  GetSpecificDataType()   const ;
#endif

    wxString            GetName()               const ;
    wxString            GetLongName()           const ;
};

#endif  // GC_PARSE_LOCUS_H

//____________________________________________________________________________________
