// $Id: gc_migrate.h,v 1.17 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_MIGRATE_H
#define GC_MIGRATE_H

#include "gc_parser.h"
#include "gc_types.h"

class GCFile;

class GCMigrateParser : public GCParser
{
  private:
    GCMigrateParser();  // undefined

  protected:
    void    ParseMigrateFirstLine(
        gcSpecificDataType& dataTypeSpecInFile,
        size_t &            numPops,
        size_t &            numLoci,
        wxString &          populationName);
    void    ParseMigrateFirstLine(
        gcSpecificDataType& dataTypeSpecInFile,
        size_t &            numPops,
        size_t &            numLoci,
        wxString &          delimiter,
        wxString &          populationName);

    std::vector<size_t> ParseMigratePopulationInfo(wxString & popName, size_t numLoci);
    std::vector<size_t> ParseMigrateLocusLengths();

    GCParse * NucParse(     GCFile &        fileRef,
                            gcGeneralDataType   dataType,
                            GCInterleaving  interleaving);
    GCParse * AlleleParse(  GCFile &            fileRef,
                            gcGeneralDataType   dataType,
                            GCInterleaving      interleaving);

    bool            IsLegalDelimiter(wxString delimCandidate);
    bool            CompleteParse(GCParse&);

  public:
    GCMigrateParser(const GCDataStore& dataStore);
    virtual ~GCMigrateParser();

    GCParse * Parse(GCFile &            fileRef,
                    gcGeneralDataType   dataType,
                    GCInterleaving      interleaving);
};

#endif  // GC_MIGRATE_H

//____________________________________________________________________________________
