// $Id: gc_parse_sample.h,v 1.8 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_PARSE_SAMPLE_H
#define GC_PARSE_SAMPLE_H

#include "gc_types.h"
#include "wx/string.h"
#include <vector>

class GCParseBlock;
class GCParser;
class GCSequentialData;

class GCParseSample
{
    friend class GCParser;
  private:
    GCParseSample();    // undefined

  protected:
    GCParseBlock * const            m_block;
    size_t                          m_lineInFile;
    wxString                        m_label;
    std::vector<GCSequentialData*>  m_data;

    bool allLengthsEqual()  const;

  public:
    GCParseSample(GCParseBlock &, size_t lineInFile, wxString label);
    virtual ~GCParseSample();

    GCParseBlock &              GetBlock();
    const GCParseBlock &        GetBlock()                      const;
    const GCSequentialData &    GetData(size_t index)           const;
    wxString                    GetLabel()                      const;
    size_t                      GetLine()                       const;
    size_t                      GetLength()                     const;
    size_t                      GetSequencesPerLabel()          const;

    void                        DebugDump(wxString prefix=wxEmptyString)   const;
};

#endif  // GC_PARSE_SAMPLE_H

//____________________________________________________________________________________
