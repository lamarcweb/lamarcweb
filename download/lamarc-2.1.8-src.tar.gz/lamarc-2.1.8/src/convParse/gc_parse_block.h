// $Id: gc_parse_block.h,v 1.9 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_PARSE_BLOCK_H
#define GC_PARSE_BLOCK_H

#include "gc_quantum.h"
#include "wx/string.h"
#include <vector>

class GCParse;
class GCParseLocus;
class GCParsePop;
class GCParser;
class GCParseSample;

class GCParseSamples : public std::vector<GCParseSample*>
{
  public:
    GCParseSamples();
    virtual ~GCParseSamples();
    void DebugDump(wxString prefix=wxEmptyString) const;
};

class GCParseBlock : public GCQuantum
{
    friend class GCParser;
  private:
    GCParse *         m_parse;
    size_t                  m_indexInParse;
    size_t                  m_expectedNumSequences;
    const GCParsePop *      m_popPointer;
    const GCParseLocus *    m_locusPointer;
    GCParseSamples          m_samples;

  protected:
    GCParseSample & FindSample(size_t indexInBlock);
    GCParse &       GetParse();

  public:
    GCParseBlock(   GCParse *               parseParent,
                    size_t                  indexInParse,
                    size_t                  expectedNumSequences,
                    const GCParsePop &      popRef,
                    const GCParseLocus &    locusRef);
    virtual ~GCParseBlock();

    const GCParseSample &   FindSample(size_t indexInBlock) const;

    size_t                  GetExpectedNumSequences()       const;
    size_t                  GetIndexInParse()               const;
    const GCParseLocus &    GetLocusRef()                   const;
    const GCParse &         GetParse()                      const;
    const GCParsePop &      GetPopRef()                     const;
    const GCParseSamples &  GetSamples()                    const;

    bool                    HasIncompleteSequences()        const;
    void                    DebugDump(wxString prefix=wxEmptyString)   const;

    void                    SetCannotBeMsat();
};

#endif  // GC_PARSE_BLOCK_H

//____________________________________________________________________________________
