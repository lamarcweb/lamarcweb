// $Id: gc_genotype_resolution.h,v 1.8 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_GENOTYPE_RESOLUTION_H
#define GC_GENOTYPE_RESOLUTION_H

#include <set>
#include <vector>
#include "wx/arrstr.h"
#include "wx/string.h"

class GCHaplotypeProbability
{
  private:
    double          m_penetrance;
    wxArrayString   m_alleleNames;

  public:
    GCHaplotypeProbability();       // shoult only be used by stl containers
    GCHaplotypeProbability(double penetrance, wxArrayString alleleNames);
    ~GCHaplotypeProbability();

    double      GetPenetrance() const;
    wxString    GetAllelesAsString() const;
    void    DebugDump(wxString prefix=wxEmptyString) const;
};

class GCGenotypeResolution
{
  private:
    wxString                               m_traitName;
    std::vector<GCHaplotypeProbability>    m_probabilities;

  public:
    GCGenotypeResolution();                 // should only be used by stl containers
    GCGenotypeResolution(wxString traitName);
    void foo() const;
    virtual ~GCGenotypeResolution();

    void AppendHap(double penetrance, wxArrayString alleleNames);
    wxString GetTraitName() const;
    const std::vector<GCHaplotypeProbability> & GetHapProbs() const;

    void    DebugDump(wxString prefix=wxEmptyString) const;
};

typedef std::set<const GCGenotypeResolution*>   gcTraitSet;

#endif  // GC_GENOTYPE_RESOLUTION_H

//____________________________________________________________________________________
