// $Id: gc_parse_locus.cpp,v 1.12 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <cassert>

#include "gc_default.h"
#include "gc_file.h"
#include "gc_parse.h"
#include "gc_parse_locus.h"
#include "gc_strings_parse_locus.h"

//------------------------------------------------------------------------------------

GCParseLocus::GCParseLocus( const GCParse *     parse,
                            size_t              indexInParse,
                            size_t              lineNumber,
                            size_t              numMarkers)
    :
    m_parse(parse),
    m_indexInParse(indexInParse),
    m_lineNumber(lineNumber),
    m_numMarkers(numMarkers)
{
}

GCParseLocus::~GCParseLocus()
{
}

const GCParse &
GCParseLocus::GetParse() const
{
    return *m_parse;
}

size_t
GCParseLocus::GetIndexInParse() const
{
    return m_indexInParse;
}

size_t
GCParseLocus::GetLineNumber() const
{
    return m_lineNumber;
}

size_t
GCParseLocus::GetNumMarkers() const
{
    return m_numMarkers;
}

gcGeneralDataType
GCParseLocus::GetDataType() const
{
    assert(m_parse != NULL);
    return m_parse->GetDataType();
}

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
gcSpecificDataType
GCParseLocus::GetSpecificDataType() const
{
    assert(m_parse != NULL);
    return m_parse->GetDataTypeSpecFromFile();
}
#endif

wxString
GCParseLocus::GetName() const
{
    long segCount = 1 + (long)m_indexInParse;
    wxString fileName = m_parse->GetFileRef().GetName();
    return wxString::Format(gcstr_parselocus::nameShort,segCount,fileName.c_str());
}

wxString
GCParseLocus::GetLongName() const
{
    long segCount = 1 + (long)m_indexInParse;
    wxString fileName = m_parse->GetFileRef().GetName();
    return wxString::Format(gcstr_parselocus::nameLong,segCount,fileName.c_str());
}

//____________________________________________________________________________________
