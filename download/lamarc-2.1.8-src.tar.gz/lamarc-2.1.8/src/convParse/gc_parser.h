// $Id: gc_parser.h,v 1.14 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_PARSER_H
#define GC_PARSER_H

#include "gc_types.h"
#include "wx/string.h"

class wxFileInputStream;
class wxTextInputStream;
class GCParseBlock;
class GCParseSample;

class GCParser
{
  private:
    GCParser();         // undefined

  protected:
    const GCDataStore &                 m_dataStore;
    size_t                              m_linesRead;
    wxFileInputStream *                 m_fileStreamPointer;
    wxTextInputStream *                 m_textStreamPointer;

    void SetUpStreams(wxString fileName);
    bool HasContent(const wxString&) const;
    wxString ReadLine(bool skipBlankLines=true);

    void CheckNoExtraData();
    virtual bool CompleteParse(GCParse&) = 0;

    void FillData              (GCParse&, size_t popIndex, size_t locIndex, GCInterleaving, size_t expectedSequences);
    void FillDataInterleaved   (GCParseBlock &,  GCParseLocus &, size_t expectedSequences);
    void FillDataNonInterleaved(GCParseBlock &,  GCParseLocus &, size_t expectedSequences);

    GCParseBlock &  AddBlock(   GCParse & , const GCParsePop &, const GCParseLocus &, size_t expectedSequences);
    GCParseLocus &  AddLocus(   GCParse & , size_t expectedIndex, size_t locusLength);
    GCParsePop &    AddPop(     GCParse & , size_t expectedIndex, wxString comment);
    GCParse &       MakeParse(  GCFile &            fileRef,
                                GCFileFormat        format,
                                gcGeneralDataType   dataType,
                                GCInterleaving      interleaving,
                                wxString            delimiter=wxEmptyString);
    GCParseSample & MakeSample( GCParseBlock &      block,
                                size_t              indexInBlock,
                                size_t              lineInFile,
                                wxString            label);
    void AddDataToSample(GCParseSample &, GCParseLocus &, wxString data);
    void AddNucDataToSample(GCParseSample &, GCParseLocus &, wxString data);
    void AddAllelicDataToSample(GCParseSample &, GCParseLocus &, wxString data);
    wxArrayString makeKalleleTokens(wxString tokensTogether, wxString delim);

    void SetDataTypeFromFile(GCParse & parse, gcSpecificDataType type);

  public:
    GCParser(const GCDataStore&);
    virtual ~GCParser();
};

#endif  // GC_PARSER_H

//____________________________________________________________________________________
