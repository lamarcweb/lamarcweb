// $Id: ui_warnings.cpp,v 1.3 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "ui_warnings.h"
#include <string>

using std::string;

const string uiwarn::calcFST_0      = "Warning: calculating FST estimates for ";
const string uiwarn::calcFST_1      = "and their reciprocal rates is impossible due to the data for the populations involved.  "
    "If the FST method is invoked to obtain starting values for those parameters, defaults will be used instead.";

//____________________________________________________________________________________
