// $Id: ui_constants.cpp,v 1.9 2010/03/02 23:12:31 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#include "ui_constants.h"

const long uiconst::NO_ID               = -1;
const long uiconst::GLOBAL_ID           = -3;
const long uiconst::GLOBAL_DATAMODEL_NUC_ID       = -30;
const long uiconst::GLOBAL_DATAMODEL_MSAT_ID      = -31;
const long uiconst::GLOBAL_DATAMODEL_KALLELE_ID   = -32;
const long uiconst::diseaseColumns      = 3;
const long uiconst::migColumns          = 3;

//____________________________________________________________________________________
