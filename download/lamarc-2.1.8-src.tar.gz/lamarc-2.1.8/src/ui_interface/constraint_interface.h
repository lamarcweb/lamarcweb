// $Id: constraint_interface.h,v 1.5 2011/03/08 19:22:01 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef CONSTRAINT_INTERFACE_H
#define CONSTRAINT_INTERFACE_H

#include <string>
#include "setget.h"

class UIVars;

class uiParameterStatus : public SetGetIndividualParamstatus
{
  public:
    uiParameterStatus();
    virtual ~uiParameterStatus();
    virtual ParamStatus Get(UIVars& vars, UIId id);
    virtual void        Set(UIVars& vars, UIId id, ParamStatus val);
    virtual string Description(UIVars& vars, UIId id);
};

class uiAddParamToGroup : public SetGetNoval
{
  public:
    uiAddParamToGroup();
    virtual ~uiAddParamToGroup();
    virtual void   Set(UIVars& vars, UIId id, noval val);
};

class uiAddParamToNewGroup : public SetGetNoval
{
  public:
    uiAddParamToNewGroup();
    virtual ~uiAddParamToNewGroup();
    virtual void   Set(UIVars& vars, UIId id, noval val);
};

class uiRemoveParamFromGroup : public SetGetNoval
{
  public:
    uiRemoveParamFromGroup();
    virtual ~uiRemoveParamFromGroup();
    virtual void   Set(UIVars& vars, UIId id, noval val);
};

class uiGroupParameterStatus : public SetGetGroupParamstatus
{
  public:
    uiGroupParameterStatus();
    virtual ~uiGroupParameterStatus();
    virtual ParamStatus Get(UIVars& vars, UIId id);
    virtual void        Set(UIVars& vars, UIId id, ParamStatus val);
    virtual string Description(UIVars& vars, UIId id);
};

class uiGroupParameterList : public SetGetLongVec1d
{
  public:
    uiGroupParameterList();
    virtual ~uiGroupParameterList();
    virtual LongVec1d   Get(UIVars& vars, UIId id);
    virtual void        Set(UIVars& vars, UIId id, LongVec1d val);
};

class uiUngroupedParamsForOneForce : public GetUIIdVec1d
{
  public:
    uiUngroupedParamsForOneForce();
    virtual ~uiUngroupedParamsForOneForce();
    virtual UIIdVec1d Get(UIVars& vars, UIId id);
};

class uiGroupedParamsForOneForce : public GetUIIdVec2d
{
  public:
    uiGroupedParamsForOneForce();
    virtual ~uiGroupedParamsForOneForce();
    virtual UIIdVec2d Get(UIVars& vars, UIId id);
};

#endif  // CONSTRAINT_INTERFACE_H

//____________________________________________________________________________________
