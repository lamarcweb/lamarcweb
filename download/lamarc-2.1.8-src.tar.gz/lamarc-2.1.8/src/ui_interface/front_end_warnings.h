// $Id: front_end_warnings.h,v 1.3 2011/03/07 06:08:53 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef FRONT_END_WARNINGS_H
#define FRONT_END_WARNINGS_H

#include <string>
#include <vector>

class FrontEndWarnings
{
  private:
    std::vector<std::string>    m_warnings;

  public:
    FrontEndWarnings();
    virtual ~FrontEndWarnings();
    std::vector<std::string> GetAndClearWarnings();
    void      AddWarning(std::string warnmsg);

};

#endif  // FRONT_END_WARNINGS

//____________________________________________________________________________________
