// $Id: ui_constants.h,v 1.12 2011/03/07 06:08:53 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef UI_CONSTANTS_H
#define UI_CONSTANTS_H

enum ui_param_class { uipsingle, untouched, global };

class uiconst
{
  public:
    static const long NO_ID;
    static const long GLOBAL_ID;
    static const long GLOBAL_DATAMODEL_NUC_ID;
    static const long GLOBAL_DATAMODEL_MSAT_ID;
    static const long GLOBAL_DATAMODEL_KALLELE_ID;
    static const long diseaseColumns;
    static const long migColumns;
};

#endif // UI_CONSTANTS_H

//____________________________________________________________________________________
