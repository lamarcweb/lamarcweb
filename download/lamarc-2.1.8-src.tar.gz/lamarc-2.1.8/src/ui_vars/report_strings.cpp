// $Id: report_strings.cpp,v 1.7 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "report_strings.h"

using std::string;

const string reportstr::header              = "Parameters for model of type: ";

const string reportstr::categoryHeader      = " rate categories with correlated length ";
const string reportstr::categoryRate        = "Relative rate";
const string reportstr::categoryRelativeProb= "Relative probability";

const string reportstr::baseFreqs           = "Base frequencies: ";
const string reportstr::baseFreqSeparator   = ", ";

const string reportstr::TTratio             = "Transition/transversion ratio: ";

const string reportstr::GTRRates            = "Mutation parameters: ";
const string reportstr::GTRRateSeparator    = ", ";
const string reportstr::GTRRatesFromA       = "Between A and (C, G, T): ";
const string reportstr::GTRRatesFromC       = "Between C and (G, T): ";
const string reportstr::GTRRatesFromG       = "Between G and (T): ";

const string reportstr::numberOfBins        = "number of bins: ";

const string reportstr::brownian            = "<Brownian model has no additional parameters>";

const string reportstr::alpha               = "alpha: ";
const string reportstr::optimizeAlpha       = "Optimized value of Alpha will be reported for each chain";
const string reportstr::relativeMutationRate= "Relative marker mutation rate: ";

const string reportstr::perBaseErrorRate    = "Per-base error rate: ";

//____________________________________________________________________________________
