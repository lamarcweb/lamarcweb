// $Id: ui_vars_prior.h,v 1.8 2011/10/31 22:04:52 ewalkup Exp $

/*
 *  Copyright 2004  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef UI_VARS_PRIOR_H
#define UI_VARS_PRIOR_H

#include "constants.h"          // for priortype

class UIInterface;
class UIVarsForces;

//This class is nothing more than a struct right now, but I made it a class
// anyway in case we get more complicated priors in the future.  Also, the
// binwidth member variable may at some point be calculated based on the
// upper and lower bounds instead of being set directly.

class UIVarsPrior
{
  private:
    UIVarsPrior();    // undefined
    UIInterface *   m_ui;
    force_type m_forcetype; //Used for boundary checking.
    priortype  m_priortype;
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
    long       m_relativeSampling;
#endif
    double     m_lowerbound;
    double     m_upperbound;

  public:
    UIVarsPrior(UIInterface * ui,
                force_type force,
                priortype type,
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
                long rate,
#endif
                double lowerbound,
                double upperbound);
    UIVarsPrior(force_type shouldBeGamma);

    //Use the default copy constructor.
    virtual ~UIVarsPrior();

    virtual priortype GetPriorType()  const {return m_priortype;};
    virtual double    GetLowerBound() const {return m_lowerbound;};
    virtual double    GetUpperBound() const {return m_upperbound;};
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
    virtual long      GetRelativeSampling() const {return m_relativeSampling;};
#endif
    virtual double    GetBinwidth() const;

    virtual void SetPriorType(priortype type);
    virtual void SetLowerBound(double bound);
    virtual void SetUpperBound(double bound);
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
    virtual void SetRelativeSampling(long rate);
#endif
    //  virtual void SetBinwidth(double bin);
    //  The binwidth is a function of all the other settings, and cannot (now)
    //   be set on its own.  Perhaps this should be revisited in the future.

    virtual string GetSummaryDescription() const;
};

#endif  // UI_VARS_PRIOR_H

//____________________________________________________________________________________
