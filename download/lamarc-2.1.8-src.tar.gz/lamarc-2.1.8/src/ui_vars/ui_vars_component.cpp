// $Id: ui_vars_component.cpp,v 1.5 2010/03/02 23:12:32 bobgian Exp $

/*
 *  Copyright 2004  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#include <cassert>
#include <cstddef>              // for NULL
#include "ui_vars_component.h"

//------------------------------------------------------------------------------------

UIVarsComponent::UIVarsComponent(UIVars * myUIVars)
    : m_UIVars(myUIVars)
{
}

UIVarsComponent::~UIVarsComponent()
{
    m_UIVars = NULL;
}

const UIVars &
UIVarsComponent::GetConstUIVars() const
{
    assert(m_UIVars != NULL);
    return (*m_UIVars);
}

UIVars &
UIVarsComponent::GetUIVars()
{
    assert(m_UIVars != NULL);
    return (*m_UIVars);
}

//____________________________________________________________________________________
