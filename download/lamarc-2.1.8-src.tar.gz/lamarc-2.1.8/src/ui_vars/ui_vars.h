// $Id: ui_vars.h,v 1.15 2011/03/07 06:08:53 bobgian Exp $

/*
 *  Copyright 2004  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef UI_VARS_H
#define UI_VARS_H

#include "ui_interface.h"
#include "ui_vars_chainparams.h"
#include "ui_vars_datamodel.h"
#include "ui_vars_forces.h"
#include "ui_vars_userparams.h"
#include "ui_vars_datapackplus.h"
#include "ui_vars_traitmodels.h"

class DataPack;

using std::string;

// EWFIX.P5 ENHANCEMENT -- all of the aggregate members of this class have
// a variety of Set methods for setting values. However, we're not
// actually checking that those are good values in most cases.
// we need to create a specialized exception that the menu can
// catch and query the user to try again

// variables that can be changed by the user
class UIVars
{
  private:
    UIVars();   // undefined
    UIVars& operator=(const UIVars& vars); // undefined
    UIInterface* ui;

  public:
    // one might argue that the constructors should have
    // restricted access since only the UndoRedoChain should
    // be creating these puppies.
    UIVars(DataPack& datapack,string fileName,UIInterface* myui);
    UIVars(const UIVars& vars);
    virtual ~UIVars();
    virtual string GetParamNameWithConstraint(force_type ftpye, long pindex,
                                              bool doLongName=true) const;
    virtual UIInterface* GetUI() const {return ui;}

    // public members because we want direct access to their
    // public methods
    UIVarsChainParameters       chains;
    UIVarsUserParameters        userparams;
    UIVarsDataPackPlus          datapackplus;
    UIVarsDataModels            datamodel;
    UIVarsTraitModels           traitmodels;
    UIVarsForces                forces;
};

#endif  // UI_VARS_H

//____________________________________________________________________________________
