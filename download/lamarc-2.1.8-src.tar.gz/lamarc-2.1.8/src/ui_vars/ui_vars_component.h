// $Id: ui_vars_component.h,v 1.8 2011/03/07 06:08:53 bobgian Exp $

/*
 *  Copyright 2004  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef UI_VARS_COMPONENT_H
#define UI_VARS_COMPONENT_H

class UIVars;

class UIVarsComponent
{
    friend class UIVars;    // which is intended to call SetParent method

  private:
    UIVarsComponent();                          // undefined
  protected:
    UIVars * m_UIVars;
  public:
    // one might argue that the constructors should have
    // restricted access since only UIVars should
    // be creating these puppies.
    UIVarsComponent(UIVars*);
    virtual ~UIVarsComponent();

    const UIVars& GetConstUIVars() const;
    UIVars& GetUIVars() ;

};

#endif  // UI_VARS_COMPONENT_H

//____________________________________________________________________________________
