// $Id: divmigmenus.h,v 1.1 2012/02/15 18:13:42 jmcgill Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef DIVMIGMENUS_H
#define DIVMIGMENUS_H

#include <string>
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"

class UIInterface;

class SetAllDivMigsMenuItem : public SetMenuItemId
{
  public:
    SetAllDivMigsMenuItem(std::string myKey, UIInterface & myui);
    virtual ~SetAllDivMigsMenuItem();
    virtual bool IsVisible();
    virtual std::string GetVariableText();
};

class SetDivMigsFstMenuItem : public ToggleMenuItemNoId
{
  public:
    SetDivMigsFstMenuItem(std::string myKey, UIInterface & myui);
    virtual ~SetDivMigsFstMenuItem();
    virtual bool IsVisible();
};

class DivMigMaxEventsMenuItem : public SetMenuItemNoId
{
  public:
    DivMigMaxEventsMenuItem(std::string myKey, UIInterface & myui);
    virtual ~DivMigMaxEventsMenuItem();
    virtual bool IsVisible();
};

class DivMigMenu : public NewMenu
{
  public:
    DivMigMenu(UIInterface & myui);
    virtual ~DivMigMenu();
};

class DivMigMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    DivMigMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~DivMigMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new DivMigMenu(ui));};
};

#endif  // DIVMIGMENUS_H

//____________________________________________________________________________________
