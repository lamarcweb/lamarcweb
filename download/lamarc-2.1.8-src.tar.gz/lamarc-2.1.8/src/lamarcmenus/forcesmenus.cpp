// $Id: forcesmenus.cpp,v 1.29 2012/02/15 18:13:42 jmcgill Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <cassert>
#include <string>

#include "coalmenus.h"
#include "constraintmenus.h"
#include "diseasemenus.h"
#include "forcesmenus.h"
#include "growthmenus.h"
#include "lamarc_strings.h"
#include "logselectmenus.h"
#include "menu_strings.h"
#include "migmenus.h"
#include "divmenus.h"
#include "divmigmenus.h"
#include "newmenuitems.h"
#include "recmenus.h"
#include "regiongammamenus.h"
#include "togglemenuitem.h"
#include "traitmodelmenu.h"
#include "ui_interface.h"
#include "ui_strings.h"

//------------------------------------------------------------------------------------

ForcesSubMenuItem::ForcesSubMenuItem(
    std::string myKey,
    UIInterface & myui,
    std::string myForce,
    std::string myForceLegal,
    NewMenuCreator * mySubMenuCreator)
    :   SubMenuItem(myKey,myui,mySubMenuCreator),
        force(myForce),
        forceLegal(myForceLegal)
{
}

ForcesSubMenuItem::~ForcesSubMenuItem()
{
}

std::string ForcesSubMenuItem::GetVariableText()
{
    return ui.doGetPrintString(force);
}

bool ForcesSubMenuItem::IsVisible()
{
    return ui.doGetBool(forceLegal);
}

ForcesMenu::ForcesMenu (UIInterface & myui)
    : NewMenu (myui,lamarcmenu::forcesTitle,menustr::emptyString)
{
    AddMenuItem(new ForcesSubMenuItem(string("T"),
                                      ui,
                                      uistr::coalescence,
                                      uistr::coalescenceLegal,
                                      new CoalescenceMenuCreator(ui)));
    AddMenuItem(new ForcesSubMenuItem(string("G"),
                                      ui,
                                      uistr::growth,
                                      uistr::growthLegal,
                                      new GrowthMenuCreator(ui)));
    AddMenuItem(new ForcesSubMenuItem(string("M"),
                                      ui,
                                      uistr::migration,
                                      uistr::migrationLegal,
                                      new MigrationMenuCreator(ui)));   
                                         
    AddMenuItem(new ForcesSubMenuItem(string("I"),
                                      ui,
                                      uistr::divergence,
                                      uistr::divergenceLegal,
                                      new DivergenceMenuCreator(ui)));    
                                      
    AddMenuItem(new ForcesSubMenuItem(string("E"),
                                      ui,
                                      uistr::divmigration,
                                      uistr::divmigrationLegal,
                                      new DivMigMenuCreator(ui)));  
                                      
                                   
    AddMenuItem(new ForcesSubMenuItem(string("R"),
                                      ui,
                                      uistr::recombination,
                                      uistr::recombinationLegal,
                                      new RecombinationMenuCreator(ui)));
    AddMenuItem(new ForcesSubMenuItem(string("D"),
                                      ui,
                                      uistr::disease,
                                      uistr::diseaseLegal,
                                      new DiseaseMenuCreator(ui)));
    AddMenuItem(new ForcesSubMenuItem(string("V"),
                                      ui,
                                      uistr::regionGamma,
                                      uistr::regionGammaLegal,
                                      new RegionGammaMenuCreator(ui)));
#ifndef NDEBUG
    AddMenuItem(new ForcesSubMenuItem(string("S"),
                                      ui,
                                      uistr::logisticSelection,
                                      uistr::logisticSelectionLegal,
                                      new LogisticSelectionMenuCreator(ui)));
#endif
#if 0
    AddMenuItem(new ForcesSubMenuItem(string("Z"),
                                      ui,
                                      uistr::logSelectStick,
                                      uistr::logisticSelectionLegal,
                                      new StochasticSelectionMenuCreator(ui)));
#endif
    AddMenuItem(new TraitModelItem(string("A"),ui));
}

ForcesMenu::~ForcesMenu ()
{
}

ForceSubMenuItem::ForceSubMenuItem(std::string myKey,UIInterface & myui, NewMenuCreator * myCreator, UIId myId)
    : SubMenuItem(myKey, myui, myCreator),
      m_id(myId)
{
}

ForceSubMenuItem::~ForceSubMenuItem()
{
}

bool ForceSubMenuItem::IsVisible()
{
    switch(m_id.GetForceType())
    {
        case force_COAL:
            return true;
            break;
        case force_MIG:
            return ui.doGetBool(uistr::migration);
            break;
        case force_DISEASE:
            return ui.doGetBool(uistr::disease);
            break;
        case force_REC:
            return ui.doGetBool(uistr::recombination);
            break;
        case force_GROW:
            return ui.doGetBool(uistr::growth);
            break;
        case force_LOGISTICSELECTION:
            return ui.doGetBool(uistr::logisticSelection);
            break;
        case force_REGION_GAMMA:
            return ui.doGetBool(uistr::regionGamma);
            break;
        case force_EXPGROWSTICK:
            return ui.doGetBool(uistr::expGrowStick);
            break;
        case force_LOGSELECTSTICK:
            return ui.doGetBool(uistr::logSelectStick);
            break;
        case force_DIVERGENCE:
            return ui.doGetBool(uistr::divergence);
            break;
        case force_DIVMIG:
            return ui.doGetBool(uistr::divmigration);
            break;
        default:
/*            string err = "ForceSubMenuItem::IsVisible() did not find force ""
                + m_id.GetForceType(); 
            implementation_error e(err);
            throw e;
            */
            assert(false);              //uncaught force type.
    }
    return true;
}

//____________________________________________________________________________________
