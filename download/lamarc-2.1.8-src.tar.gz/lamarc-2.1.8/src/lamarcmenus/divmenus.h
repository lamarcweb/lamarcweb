// $Id: divmenus.h,v 1.2 2012/02/29 00:29:58 ewalkup Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef DIVMENUS_H
#define DIVMENUS_H

#include <string>
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"

class UIInterface;

class SetMenuItemEpochs : public SetMenuItemGroup
{
  public:
    SetMenuItemEpochs(UIInterface & myui);
    virtual ~SetMenuItemEpochs();
    virtual std::vector<UIId> GetVisibleIds();
    virtual bool HasMultiLineItems() {return true;};
    std::vector<std::string> GetExtraText(UIId id);
    std::vector<std::string> GetExtraVariableText(UIId id);
};

class DivergenceMenu : public NewMenu
{
  public:
    DivergenceMenu(UIInterface & myui);
    virtual ~DivergenceMenu();
};

class DivergenceMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    DivergenceMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~DivergenceMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new DivergenceMenu(ui));};
};

#endif  // DIVMENUS_H

//____________________________________________________________________________________
