// $Id: coalmenus.h,v 1.15 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef COALMENUS_H
#define COALMENUS_H

#include <string>
#include <vector>
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"
#include "menutypedefs.h"

class UIInterface;

class SetAllThetasMenuItem : public SetMenuItemId
{
  public:
    SetAllThetasMenuItem(std::string myKey, UIInterface & myui);
    virtual ~SetAllThetasMenuItem();
    virtual bool IsVisible();
    virtual std::string GetVariableText();
};

class SetThetasFstMenuItem : public ToggleMenuItemNoId
{
  public:
    SetThetasFstMenuItem(std::string myKey, UIInterface & myui);
    virtual ~SetThetasFstMenuItem();
    virtual bool IsVisible();
};

class SetMenuItemThetas : public SetMenuItemGroup
{
  public:
    SetMenuItemThetas(UIInterface & ui);
    virtual ~SetMenuItemThetas();
    virtual std::vector<UIId> GetVisibleIds();
};

class CoalescenceMenu : public NewMenu
{
  public:
    CoalescenceMenu(UIInterface & myui);
    virtual ~CoalescenceMenu();
};

class CoalescenceMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    CoalescenceMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~CoalescenceMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new CoalescenceMenu(ui));};
};

#endif  // COALMENUS_H

//____________________________________________________________________________________
