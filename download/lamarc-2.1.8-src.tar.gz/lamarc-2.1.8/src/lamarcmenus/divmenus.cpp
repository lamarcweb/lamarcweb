// $Id: divmenus.cpp,v 1.4 2012/03/09 22:55:20 jmcgill Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "constraintmenus.h"
#include "lamarc_strings.h"
#include "menu_strings.h"
#include "matrixitem.h"
#include "divmenus.h"
#include "newmenuitems.h"
#include "priormenus.h"
#include "setmenuitem.h"
#include "ui_constants.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "overviewmenus.h"
#include "profilemenus.h"
//#include "gc_structures.h"

using std::string;
//------------------------------------------------------------------------------------

SetMenuItemEpochs::SetMenuItemEpochs(UIInterface & myui)
    : SetMenuItemGroup(myui,uistr::divergenceEpochBoundaryTime)
{
}

SetMenuItemEpochs::~SetMenuItemEpochs()
{
}

vector<UIId> SetMenuItemEpochs::GetVisibleIds()
{
    return ui.doGetUIIdVec1d(uistr::validParamsForForce,UIId(force_DIVERGENCE));
}

std::vector<std::string> SetMenuItemEpochs::GetExtraText(UIId id)
{
    std::vector<std::string> s;
    string ancestor = "  ";
    ancestor += ui.doGetDescription(uistr::divergenceEpochAncestor,id);
    s.push_back(ancestor);
    string decendents = "  ";
    decendents += ui.doGetDescription(uistr::divergenceEpochDescendents,id);
    s.push_back(decendents);
    return s;
}

std::vector<std::string> SetMenuItemEpochs::GetExtraVariableText(UIId id)
{
    std::vector<std::string> s;
    s.push_back(ui.doGetPrintString(uistr::divergenceEpochAncestor,id));
    s.push_back(ui.doGetPrintString(uistr::divergenceEpochDescendents,id));
    return s;
}


//------------------------------------------------------------------------------------

DivergenceMenu::DivergenceMenu (UIInterface & myui )
    : NewMenu (myui,lamarcmenu::divTitle,lamarcmenu::divInfo)
{
    AddMenuItem(new DisplayOnlyMenuItem(uistr::divergence, ui));
    UIId id(force_DIVERGENCE);
    
    AddMenuItem(new SetMenuItemEpochs(ui));
}

DivergenceMenu::~DivergenceMenu ()
{
}

//____________________________________________________________________________________
