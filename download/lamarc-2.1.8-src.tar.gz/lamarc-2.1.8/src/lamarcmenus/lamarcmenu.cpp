// $Id: lamarcmenu.cpp,v 1.22 2010/03/17 17:25:58 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

// the base menu is the NON-Interactive "menu"
// derived menus handele the different windowing systems
//  (- Curses)
//  - Scrolling ASCII console
//  (-graphical GUI etc)
// Peter Beerli

#include <string>
#include "datamodelmenu.h"
#include "forcesmenus.h"
#include "lamarcmenu.h"
#include "lamarcmenuitems.h"
#include "lamarc_strings.h"
#include "menu_strings.h"
#include "newmenu.h"
#include "newmenuitems.h"
#include "overviewmenus.h"
#include "ui_interface.h"

//------------------------------------------------------------------------------------

LamarcMainMenu::LamarcMainMenu (UIInterface & myui)
    : NewMenu (myui,lamarcmenu::mainTitle,menustr::emptyString,true)
{
    AddMenuItem(new SubMenuItem(string("D"),ui,new NewDataModelMenuCreator(ui)));
    AddMenuItem(new SubMenuItem(string("A"),ui,new ForcesMenuCreator(ui)));
    AddMenuItem(new SubMenuItem(string("S"),ui,new StrategyMenuCreator(ui)));
    AddMenuItem(new SubMenuItem(string("I"),ui,new ResultMenuCreator(ui)));
    AddMenuItem(new SubMenuItem(string("O"),ui,new OverviewMenuCreator(ui)));

}

LamarcMainMenu::~LamarcMainMenu ()
{
}

//____________________________________________________________________________________
