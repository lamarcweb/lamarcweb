// $Id: vector_constants.h,v 1.11 2011/03/07 06:08:51 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

// modelled after ui_interface/ui_strings.h

#ifndef VECTOR_CONSTS_H
#define VECTOR_CONSTS_H

#include <vector>
#include "vectorx.h"

using std::vector;

// values for the static const vectors below are set in vectro_consts.cpp
class vecconst
{
  public:
    static const DoubleVec1d percentiles;
    static  DoubleVec1d multipliers;
    static  DoubleVec1d growthmultipliers;
    static const DoubleVec1d growthfixed;
    static  DoubleVec1d logisticselectionmultipliers;
    static const DoubleVec1d logisticselectionfixed;
    static const DoubleVec1d percentiles_short;
    static const DoubleVec1d multipliers_short;
};

#endif // VECTOR_CONSTS_H

//____________________________________________________________________________________
