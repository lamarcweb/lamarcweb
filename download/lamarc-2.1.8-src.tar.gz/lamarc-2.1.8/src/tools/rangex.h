// $Id: rangex.h,v 1.18 2011/12/29 23:44:19 ewalkup Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef RANGEX_H
#define RANGEX_H

#include <set>
#include <string>
#include <vector>

struct rangecmp
{
    bool operator()(const std::pair<long, long>& p1, const std::pair<long, long>& p2)
    {
        if (p1.first == p2.first)
        {
            return (p1.second < p2.second);
        }
        return (p1.first < p2.first);
    }
};

typedef std::pair<long,long>                    rangepair;
typedef std::vector<rangepair>                  rangevector;
typedef std::set<rangepair, rangecmp>           rangeset;
typedef std::set<rangepair, rangecmp>::iterator rangesetiter;

std::string ToString(rangepair rpair);
std::string ToString(rangeset rset);

rangeset MakeRangeset(long int low, long int high);
rangeset AddPairToRange(const rangepair& addpart, const rangeset& rset);
rangeset RemovePairFromRange(const rangepair& removepart, const rangeset& rset);
rangeset RemoveRangeFromRange(const rangeset& removerange, const rangeset& rset);
rangeset Union(const rangeset& set1, const rangeset& set2);
void     ORAppend(rangepair newrange, rangeset& oldranges);
rangeset Intersection(const rangeset& set1, const rangeset& set2);
long     CountSites(rangeset rset);
long     CountLinks(const rangeset& sites);
rangeset TargetLinksFrom(const rangeset& targetsites);
rangeset AddToRangeset(const rangeset& rset, long offset);
rangeset SubtractFromRangeset(const rangeset& rset, long offset);

// We cannot do this since 0 target links are ambiguous as to whether they indicated
// 0 or 1 target sites.
// rangeset TargetSitesFromLinks(const rangeset& targetlinks);

bool     IsInRangeset(const rangeset& targetrange, long target);

// Are there sites in targetrange on both sides of target?
bool     Surrounds(const rangeset& targetrange, long target);

long ToSequentialIfNeeded(long input);
long ToNoZeroesIfNeeded(long input);
rangepair ToSequentialIfNeeded(rangepair input);
rangepair ToNoZeroesIfNeeded(rangepair input);

bool IsRangeCompact(const rangeset& rset);
#endif // RANGEX_H

//____________________________________________________________________________________
