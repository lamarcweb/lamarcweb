// $Id: gc_event_publisher.cpp,v 1.19 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_event_ids.h"
#include "gc_event_publisher.h"
#include "gc_quantum.h"
#include <set>
#include "wx/clntdata.h"
#include "wx/event.h"

const wxEventType DATA_2_SCREEN = wxNewEventType();
const wxEventType SCREEN_2_DATA = wxNewEventType();

void PublishDataEvent(wxEvtHandler* handler,int eventId)
{
    wxCommandEvent myEvent(DATA_2_SCREEN,eventId);
    wxPostEvent(handler,myEvent);
}

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)

void PublishDataEvent(wxEvtHandler* handler,int eventId, const GCQuantum* obj)
{
    wxCommandEvent myEvent(DATA_2_SCREEN,eventId);
    wxClientData * clientP = new GCClientData(obj);
    myEvent.SetClientObject(clientP);
    wxPostEvent(handler,myEvent);
}

void PublishScreenEvent(wxEvtHandler* handler,int eventId)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    wxPostEvent(handler,myEvent);
}

void PublishScreenEvent(wxEvtHandler* handler,int eventId,int intData)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    myEvent.SetInt(intData);
    wxPostEvent(handler,myEvent);
}

void PublishScreenEvent(wxEvtHandler* handler,int eventId,wxString stringData)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    myEvent.SetString(stringData);
    wxPostEvent(handler,myEvent);
}

#endif

void PublishScreenEvent(wxEvtHandler* handler, gcEventActor * obj)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,gcEvent_Generic);
    wxClientData * clientP = new GCClientData(obj);
    myEvent.SetClientObject(clientP);
    wxPostEvent(handler,myEvent);
}

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)

void PublishScreenEvent(wxEvtHandler* handler,int eventId, const GCQuantum* obj,int intData)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    wxClientData * clientP = new GCClientData(obj);
    myEvent.SetClientObject(clientP);
    myEvent.SetInt(intData);
    wxPostEvent(handler,myEvent);
}

void PublishScreenEvent(wxEvtHandler* handler,int eventId, const GCQuantum* obj,wxString stringData)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    wxClientData * clientP = new GCClientData(obj);
    myEvent.SetClientObject(clientP);
    myEvent.SetString(stringData);
    wxPostEvent(handler,myEvent);
}

#endif

//____________________________________________________________________________________
