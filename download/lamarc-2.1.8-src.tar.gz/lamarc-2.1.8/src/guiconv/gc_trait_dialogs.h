// $Id: gc_trait_dialogs.h,v 1.5 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_TRAIT_DIALOGS_H
#define GC_TRAIT_DIALOGS_H

class GCDataStore;
class wxWindow;

void DoDialogAddTrait(wxWindow * parentWindow, GCDataStore & dataStore);

#endif  //GC_TRAIT_DIALOGS_H

//____________________________________________________________________________________
