// $Id: gc_menu_actors.h,v 1.7 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_MENU_ACTORS_H
#define GC_MENU_ACTORS_H

#include "gc_quantum.h"

gcEventActor * MakeMenuActor(int eventId);

class basicMenuActor : public gcEventActor
{
  private:
    basicMenuActor();   // undefined
  protected:
    int m_eventId;
  public:
    basicMenuActor(int eventId);
    virtual ~basicMenuActor();
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_About : public gcEventActor
{
  public:
    gcActor_About() {};
    virtual ~gcActor_About() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_DebugDump : public gcEventActor
{
  public:
    gcActor_DebugDump() {};
    virtual ~gcActor_DebugDump() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_ExportBatchFile : public gcEventActor
{
  public:
    gcActor_ExportBatchFile() {};
    virtual ~gcActor_ExportBatchFile() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_ExportFile : public gcEventActor
{
  public:
    gcActor_ExportFile() {};
    virtual ~gcActor_ExportFile() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_FileAdd : public gcEventActor
{
  public:
    gcActor_FileAdd() {};
    virtual ~gcActor_FileAdd() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_LinkGAdd : public gcEventActor
{
  public:
    gcActor_LinkGAdd() {};
    virtual ~gcActor_LinkGAdd() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_CmdFileRead : public gcEventActor
{
  public:
    gcActor_CmdFileRead() {};
    virtual ~gcActor_CmdFileRead() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_ToggleVerbose : public gcEventActor
{
  public:
    gcActor_ToggleVerbose() {};
    virtual ~gcActor_ToggleVerbose() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

#endif  // GC_MENU_ACTORS_H

//____________________________________________________________________________________
