// $Id: gc_panel_dialogs.h,v 1.1 2011/06/22 18:22:22 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_PANEL_DIALOGS_H
#define GC_PANEL_DIALOGS_H

#include "gc_dialog.h"
#include "gc_quantum.h"
#include "gc_validators.h"

class GCDataStore;
class wxWindow;

//------------------------------------------------------------------------------------

class gcPanelRename : public gcTextHelper
{
  private:
    gcPanelRename();       // undefined
    size_t                  m_panelId;
  protected:
  public:
    gcPanelRename(size_t panelId);
    ~gcPanelRename();

    wxString    FromDataStore(GCDataStore &);
    void        ToDataStore(GCDataStore &, wxString newText);
};

//------------------------------------------------------------------------------------

class gcPanelMemberCount : public gcTextHelper
{
  private:
    gcPanelMemberCount();       // undefined
    size_t                      m_panelId;
    GCPositiveFloatValidator    m_validator;
  protected:
  public:
    gcPanelMemberCount(size_t panelId);
    ~gcPanelMemberCount();

    wxString            FromDataStore(GCDataStore &);
    void                ToDataStore(GCDataStore &, wxString newText);
    const wxValidator & GetValidator();
    wxString            InitialString();
};
//------------------------------------------------------------------------------------

class gcPanelEditDialog : public gcUpdatingDialog
{
  private:
  protected:
    size_t          m_panelId;
  public:
    gcPanelEditDialog( wxWindow *      parentWindow,
                        GCDataStore &   dataStore,
                        size_t          panelId,
                        bool            forJustCreatedObj);
    virtual ~gcPanelEditDialog();
};

//------------------------------------------------------------------------------------

bool DoDialogEditPanel(wxWindow *      parentWindow,
                        GCDataStore &   dataStore,
                        size_t          regionId,
                        bool            forJustCreatedObj);



//------------------------------------------------------------------------------------

class gcActor_PanelEdit : public gcEventActor
{
  private:
    gcActor_PanelEdit();       // undefined
    size_t                      m_panelId;

  public:
    gcActor_PanelEdit(size_t panelId) : m_panelId(panelId) {};
    virtual ~gcActor_PanelEdit() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

#endif  // GC_PANEL_DIALOGS_H
//____________________________________________________________________________________
