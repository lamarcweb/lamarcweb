// $Id: gc_quantum.h,v 1.14 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_QUANTUM_H
#define GC_QUANTUM_H

#include "wx/clntdata.h"
#include "wx/string.h"

class GCQuantum
{
  private:
    static size_t       s_objCount;
  protected:
    size_t              m_objId;
    wxString            m_name;
    bool                m_selected;
  public:
    GCQuantum();

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
    GCQuantum(wxString name);
#endif

    virtual ~GCQuantum();

    size_t      GetId()                         const;
    void        DebugDump(wxString prefix=wxEmptyString)   const;
    virtual wxString    GetName()                       const;
    virtual void        SetName(wxString name);

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
    virtual bool        GetSelected()                   const;
    virtual void        SetSelected(bool selected);
#endif

    static  void        ReportMax();
};

class wxWindow;
class GCDataStore;

class gcEventActor
{
  public:
    gcEventActor() {};
    virtual ~gcEventActor() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & store) = 0;
};

class GCClientData : public wxClientData
{
  private:
    GCClientData();         // undefined
    gcEventActor *          m_myActor;
  public:
    GCClientData(gcEventActor * myActor);
    virtual ~GCClientData();
    gcEventActor *  GetActor() ;
};

#endif  // GC_QUANTUM_H

//____________________________________________________________________________________
