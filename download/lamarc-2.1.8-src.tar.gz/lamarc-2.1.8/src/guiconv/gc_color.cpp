// $Id: gc_color.cpp,v 1.4 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_color.h"

#include "wx/colour.h"
#include "wx/gdicmn.h"
#include "wx/settings.h"

const wxColour & gccolor::selectedFile()
{
    static wxColour selectedFileColor = wxTheColourDatabase->Find("LIGHT BLUE");
    return selectedFileColor;
}

const wxColour & gccolor::enteredObject()
{
    static wxColour enteredObjectColor = wxSystemSettings::GetColour(wxSYS_COLOUR_HIGHLIGHT);
    return enteredObjectColor;
}

const wxColour & gccolor::activeObject()
{
    static wxColour activeObjectColor = wxTheColourDatabase->Find("YELLOW");
    return activeObjectColor;
}

//____________________________________________________________________________________
