// $Id: guiconverter.cpp,v 1.34 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "guiconverter.h"
#include "gc_cmdline.h"
#include "gc_errhandling.h"
#include "gc_event_ids.h"
#include "gc_event_publisher.h"
#include "gc_frame.h"
#include "gc_layout.h"
#include "gc_strings.h"

#include "giraffe32.xpm"

#include "tinyxml.h"

#include "wx/cmdline.h"
#include "wx/icon.h"
#include "wx/log.h"

#ifdef LAMARC_COMPILE_MSWINDOWS
#include "wincon.h"
#endif

GuiConverterApp::GuiConverterApp()
{
}

GuiConverterApp::~GuiConverterApp()
{
}

IMPLEMENT_APP(GuiConverterApp)

void
GuiConverterApp::OnInitCmdLine(wxCmdLineParser& parser)
{
    wxApp::OnInitCmdLine(parser);
    GCCmdLineManager::AddOptions(parser);
}

bool
GuiConverterApp::OnCmdLineParsed(wxCmdLineParser& parser)
{
    bool parentReturned = wxApp::OnCmdLineParsed(parser);
    GCCmdLineManager::ExtractValues(parser);
    return parentReturned;
}

bool
GuiConverterApp::OnInit()
{
    // use the parent's OnInit because it includes command line parsing
    if(wxApp::OnInit())
    {
        if(m_batchOnly)
        {
#ifdef LAMARC_COMPILE_MSWINDOWS
            AttachConsole(-1);
            // this should be better but mingw needs patching
            // AttachConsole(ATTACH_PARENT_PROCESS);
#else
            wxLog::SetActiveTarget(new wxLogStderr());
#endif
            GCCmdLineManager::ProcessCommandLineAndCommandFile(m_logic);
            GCCmdLineManager::DoExport(m_logic);
            wxExit();
            return false;
        }
        else
        {
            if(wxApp::OnInitGui())
            {
                int appWidth  = gclayout::appWidth;
                int appHeight = gclayout::appHeight;
                wxSize maxSize = wxGetDisplaySize();
                int maxWidth = maxSize.GetWidth()  * gclayout::appWidthPercent  / 100;
                int maxHeight= maxSize.GetHeight() * gclayout::appHeightPercent / 100;
                if(appWidth > maxWidth)
                {
                    appWidth = maxWidth;
                }
                if(appHeight > maxHeight)
                {
                    appHeight = maxHeight;
                }

                wxSize bestSize(appWidth,appHeight);

                GCFrame * m_mainFrame = new GCFrame(gcstr::converterTitle,m_logic);
                m_logic.SetDisplayParent(m_mainFrame);
                m_mainFrame->SetSize(bestSize);
                m_mainFrame->CentreOnScreen();
                m_mainFrame->Show(true);
                SetTopWindow(m_mainFrame);

                m_mainFrame->SetIcon( wxICON( giraffe32) );

                GCCmdLineManager::ProcessCommandLineAndCommandFile(m_logic);
                PublishDataEvent(m_mainFrame->GetEventHandler(),D2S_UserInteractionPhaseEnd);

                return true;
            }
        }
    }
    return false;
}

int
GuiConverterApp::OnRun()
{
    try
    {
        int result = wxApp::OnRun();
        return result;
    }
    catch(const gc_fatal_error& e)
    {
        wxLogError(wxString::Format(gcerr::fatalError));
        return 2;
    }
    catch(const std::exception& f)
    {
        wxLogError(wxString::Format(gcerr::uncaughtException,f.what()));
        return 2;
    }
    return 3;       // EWFIX.P3 -- what should this be?
}

int
GuiConverterApp::OnExit()
{
    if(m_doDebugDump)
    {
        m_logic.DebugDump();
    }
    if(! m_batchOutName.IsEmpty())
    {
        TiXmlDocument * doc = m_logic.ExportBatch();
        m_logic.WriteBatchFile(doc,m_batchOutName);
        delete doc;
    }

    m_logic.NukeContents();

    return wxApp::OnExit();
}

//____________________________________________________________________________________
