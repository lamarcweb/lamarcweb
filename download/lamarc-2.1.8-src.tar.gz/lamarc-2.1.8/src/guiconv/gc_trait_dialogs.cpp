// $Id: gc_trait_dialogs.cpp,v 1.10 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_datastore.h"
#include "gc_strings.h"
#include "gc_structures_err.h"
#include "gc_trait_dialogs.h"

#include "wx/textdlg.h"

void
DoDialogAddTrait(wxWindow * parentWindow, GCDataStore & dataStore)
{
    wxString newTraitName
        = wxGetTextFromUser(gcstr::traitEnterNewName,
                            gcstr::traitEnterNewName,  // EWFIX.P3 LATER
                            wxEmptyString,
                            parentWindow);
    if(!(newTraitName.IsEmpty()))
    {
        try
        {
            dataStore.AddNewTrait(newTraitName);
        }
        catch(const duplicate_name_error& e)
        {
            dataStore.GCInfo(e.what());
        }
    }
}

//____________________________________________________________________________________
