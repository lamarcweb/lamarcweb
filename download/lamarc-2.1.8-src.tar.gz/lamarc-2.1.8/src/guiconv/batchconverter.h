// $Id: batchconverter.h,v 1.5 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef BATCHCONVERTER_H
#define BATCHCONVERTER_H

#include "wx/app.h"
#include "wx/wx.h"
#include "gc_cmdline.h"
#include "gc_datastore.h"

class wxCmdLineParser;

class BatchConverterApp: public wxAppConsole, public GCCmdLineManager
                         // main gui converter application
{
  private:
    GCDataStore     m_dataStore;

  public:
    BatchConverterApp();
    virtual ~BatchConverterApp();

    virtual bool    OnCmdLineParsed(wxCmdLineParser&);
    virtual int     OnExit();
    virtual bool    OnInit();
    virtual void    OnInitCmdLine(wxCmdLineParser&);
    virtual int     OnRun();

};

#endif  // BATCHCONVERTER_H

//____________________________________________________________________________________
