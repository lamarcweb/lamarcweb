// $Id: gc_text_ctrl.cpp,v 1.8 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_text_ctrl.h"
#include "gc_validators.h"
#include "wx/log.h"
#include "wx/event.h"

GCTextInput::GCTextInput(wxWindow * parentWindow,const wxValidator& validator)
    :
    wxTextCtrl( parentWindow,
                -1,
                wxEmptyString,
                wxDefaultPosition,
                wxDefaultSize,
                wxTAB_TRAVERSAL | wxTE_RIGHT | wxTE_PROCESS_ENTER,
                validator)
{
}

GCTextInput::~GCTextInput()
{
}

GCIntegerInput::GCIntegerInput(wxWindow * parentWindow)
    :
    GCTextInput(parentWindow,GCIntegerValidator())
{
}

GCIntegerInput::~GCIntegerInput()
{
}

GCNonNegativeIntegerInput::GCNonNegativeIntegerInput(wxWindow * parentWindow)
    :
    GCTextInput(parentWindow,GCNonNegativeIntegerValidator())
{
}

GCNonNegativeIntegerInput::~GCNonNegativeIntegerInput()
{
}

//____________________________________________________________________________________
