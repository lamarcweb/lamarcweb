// $Id: gc_gridpanel.h,v 1.22 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_GRIDPANEL_H
#define GC_GRIDPANEL_H

#include "gc_event_ids.h"
#include "gc_layout.h"
#include "wx/scrolwin.h"
#include "wx/sizer.h"
#include "wx/stattext.h"
#include "wx/wx.h"
#include <map>
#include <vector>

class GCLogic;
class wxSizer;

typedef std::pair<size_t,size_t>        cellIndices;
typedef std::map<cellIndices,wxWindow*> cellMap;
typedef std::vector<size_t>             objIdsByRow;

class gcGridPane : public wxPanel
{
  private:

  protected:
    wxFlexGridSizer *   m_sizer;
    size_t              m_rows;
    size_t              m_cols;
    cellMap             m_cells;
    objIdsByRow         m_objVec;

  public:

    gcGridPane(wxWindow * parent, size_t cols, size_t growCol);
    virtual ~gcGridPane();

    virtual void NotifyEntering     (size_t row, size_t col);
    virtual void NotifyLeaving      (size_t row, size_t col);
    virtual void NotifyLeftDClick   (size_t row, size_t col);
    virtual void NotifyLeftDown     (size_t row, size_t col);
    virtual void NotifyLeftUp       (size_t row, size_t col);

    // EWFIX.P4 -- move to protected and inherit
    void        AddRow(size_t objId, wxArrayString labels);

    void        Finish();
};

class gcGridCell : public wxPanel
{
  private:
    gcGridCell();                // undefined
  protected:
    size_t      m_rowIndex;
    size_t      m_colIndex;
  public:
    gcGridCell( gcGridPane *    parent,
                wxString        label,
                size_t          rowIndex,
                size_t          colIndex);
    virtual ~gcGridCell();

    void OnMouse(wxMouseEvent & event);

    DECLARE_EVENT_TABLE()
};

class gcGridText : public wxStaticText
{
  private:
    gcGridText();       // undefined
  protected:
  public:
    gcGridText(gcGridCell * parent,wxString label);
    virtual ~gcGridText();
    void OnMouse(wxMouseEvent & event);

    DECLARE_EVENT_TABLE()
};

class gcInfoPane : public wxPanel
{
  private:
    gcInfoPane();              // undefined
  protected:
    wxScrolledWindow *  m_scrolled;
    wxSizer *           m_contentSizer;
    wxPanel *           m_innerPanel;
    wxSizer *           m_topSizer;
    const wxString      m_panelLabelFmt;
    wxStaticText *      m_panelLabel;
    GCLogic &           m_logic;
    virtual wxPanel *   MakeContent() = 0;
  public:
    gcInfoPane(wxWindow * parent, GCLogic & logic, wxString title);
    virtual ~gcInfoPane();
    void UpdateUserCues();
    virtual wxString MakeLabel() = 0;
};

#endif  // GC_GRIDPANEL_H

//____________________________________________________________________________________
