// $Id: funcMax.h,v 1.8 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef FUNCMAX_H
#define FUNCMAX_H

#include <iomanip>
#include <fstream>
#include <cmath>

#include "dlcalc.h"
#include "dlmodel.h"
#include "locus.h"
#include "tree.h"

class MixedKSModel;

typedef double (*dblpf) (double);

struct FMState
{
    int max_iters;
    double increment;
    double threshold;
    double leftLimit;
    double rightLimit;
    double initX;
    dblpf pf;

    FMState(int _max_iters,
            double _increment,
            double _threshold,
            double _leftLimit,
            double _rightLimit,
            double _initX
        );
};

class FuncMax
{
    int max_iters;
    double increment;
    double threshold;
    double leftLimit;
    double rightLimit;
    double initX;
    dblpf pf;

    MixedKSModel& mksModel;
    std::ofstream* fs;
    DLCalc_ptr dlcalc;
    Tree* tree;
    const Locus& locus;
    bool m_moving;

  public:
    FuncMax(MixedKSModel& _mksModel, Tree* tree, const Locus& locus);
    void setState(FMState fms);
    void run();
    FMState getCurState();
    double getCurX();

  private:
    double curX;
    double eval(double x);
    bool isInc(double x, double max);
};

#endif  // FUNCMAX_H

//____________________________________________________________________________________
