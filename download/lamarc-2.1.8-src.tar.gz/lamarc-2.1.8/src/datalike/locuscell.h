// $Id: locuscell.h,v 1.9 2011/03/07 06:08:49 bobgian Exp $

/*
  Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

/*************************************************************************
 This class is a managed container of Cells belonging to a single
 locus.  It needs to be managed because Cells generally have to be
 deep copied.

 Written by Mary Kuhner
*************************************************************************/

#ifndef LOCUSCELL_H
#define LOCUSCELL_H

#include <cassert>  // May be needed for inline definitions.
#include <vector>
#include "dlcell.h"

//------------------------------------------------------------------------------------

class LocusCell
{
  private:
    std::vector<Cell_ptr> dlcells;

    void DeepCopyCells(const std::vector<Cell_ptr>& src);

  public:
    LocusCell()                                   {};
    LocusCell(const std::vector<Cell_ptr>& src);
    LocusCell(const LocusCell& src);
    LocusCell(const vector<LocusCell>& src);
    ~LocusCell()                                  {};

    LocusCell&     operator=(const LocusCell& src);
    LocusCell&     operator+=(const LocusCell& src);
    LocusCell&     operator*=(double mult);
    bool           operator==(const LocusCell& src) const;
    unsigned long  size() const             { return dlcells.size(); };
    void           clear()                  { dlcells.clear(); };

    Cell_ptr       operator[](long ind)     { assert(static_cast<unsigned long>(ind) < dlcells.size());
        return dlcells[ind]; };

    const Cell_ptr operator[](long ind) const
    { assert(static_cast<unsigned long>(ind) < dlcells.size());
        return dlcells[ind]; };

    bool           DiffersFrom(const LocusCell& other, long marker) const;
    void           SetAllCategoriesTo(DoubleVec1d& state, long marker);
};

#endif // LOCUSCELL_H

//____________________________________________________________________________________
