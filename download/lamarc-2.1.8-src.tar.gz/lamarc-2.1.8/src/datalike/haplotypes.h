// $Id: haplotypes.h,v 1.9 2011/03/07 06:08:49 bobgian Exp $

/*
  Copyright 2006  Lucian Smith, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

// This files defines the class that stores "haplotype" specific
// information.

#ifndef HAPLOTYPES_H
#define HAPLOTYPES_H

#include "vectorx.h"
#include <set>

class LocusCell;

class Haplotypes
{
  private:
    Haplotypes(); //undefined
    long m_regionnum;
    string m_locusname;
    StringVec2d  m_haplotype_alleles; //Phase 1
    DoubleVec1d  m_penetrances;

    vector<vector<LocusCell> > m_haplotype_dlcells; //Phase 2
    long m_current_hapindex;

    void ConvertAllelesToDLCells();
    void CollapseHaplotypeDLs();
    StringVec2d SetToVecs(std::multiset<std::string> stringSet) const;

  public:
    Haplotypes(long regnum, string lname);
    Haplotypes(Haplotypes hap, bool clear);
    ~Haplotypes() {};
    //We accept the default for:
    //Haplotype& operator=(const Haplotype& src);
    //Haplotype(const Haplotype& src);

    void AddHaplotype(StringVec1d alleles, double penetrance);
    void AddHaplotype(std::multiset<std::string> alleles, double penetrance);
    vector<LocusCell> ChooseNewHaplotypes();
    vector<LocusCell> ChooseRandomHaplotypes();
    vector<LocusCell> ChooseFirstHaplotypes();
    vector<LocusCell> ChooseNextHaplotypes();
    StringVec1d GetAlleles() const; //phase 1
    string GetMarkerData() const; //phase 3 (output)
    StringVec1d GetHaplotypesXML(long nspaces) const; //menuinfile XML
    bool MultipleHaplotypes() const;

    // Debugging function.
    void PrintCellsAndAlleles() const;

};

#endif // HAPLOTYPES_H

//____________________________________________________________________________________
