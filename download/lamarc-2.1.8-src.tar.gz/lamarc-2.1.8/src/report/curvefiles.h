// $Id: curvefiles.h,v 1.2 2010/03/02 23:12:29 bobgian Exp $

/*
  Copyright 2008  Peeter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef CURVEFILES_H
#define CURVEFILES_H

#include <fstream>
#include <iostream>
#include <string>
#include "vectorx.h"

class BayesAnalyzer_1D;
class Force;
class Parameter;

void writeCurveHeader(  std::ofstream &     curvefileStream,
                        std::string         pname,
                        long                paramnum,
                        long                regions,
                        long                replicates,
                        BayesAnalyzer_1D &  ba);

double getMinIndex(BayesAnalyzer_1D&,long,long);

void WriteOneConsolidatedCurveFile( std::string         filePrefix,
                                    BayesAnalyzer_1D &  bayesAnalyzer,
                                    const Parameter &   param,
                                    long                paramnum);
void WriteConsolidatedCurveFiles(   std::string         filePrefix,
                                    BayesAnalyzer_1D &  bayesAnalyzer);

#endif // CURVEFILES_H

//____________________________________________________________________________________
