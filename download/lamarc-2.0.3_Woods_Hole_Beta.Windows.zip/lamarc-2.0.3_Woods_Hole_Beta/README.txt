Lamarc 2.0
----------

A program to estimate population parameters from genetic data.  All
parameters are estimated jointly.  Currently the program allows estimation
of population sizes, recombination rate,  migration rates, and growth
rates.

This release adds the capacity to perform a Bayesian analyses, add
parameter constraints, differentiate Ne and mu among genetic regions, use a
'K-allele' data model for microsatellite or electrophoretic data or a
'Mixed K-allele/Stepwise' data model for microsatellite data, and use a new
GUI for the file converter.

If you have problems, read the documentation in the doc/ subdirectory 
and if you still have problems email to:

lamarc@genetics.washington.edu

DOCUMENTATION:
==============
HTML versions of the documentation are in the doc/ subdirectory.  We are
no longer maintaining the non-HTML documentation.  If this is a problem
for you, please let us know.


BINARY DISTRIBUTIONS:
=====================
If you have downloaded a binary distribution you are all set and the
programs "lamarc", "lam_conv", and gui_lam_conv are in the same directory
as this README

Linux users-you may recieve a cryptic sounding error message concerning
"libstdc++.so.6" or something similar.  In order to run lamarc you
will need to either get the lamarc source distribution and compile
it on your computer, or you will need to install some variant of
version 6 of the standard c++ shared library.  Debian users with
"apt" installed can use "apt-get install libstdc++6" to get the needed
library.

SOURCE DISTRIBUTIONS:
=====================
If you have downloaded the source and have a *UNIX* system (LINUX,
BSD, MACOSX, SOLARIS, TRU64, etc) see INSTALL for directions 
to build "lamarc" and "lam_conv".  The subdirectory "projects" of
this directory may include files for building the tools on
other OSes.

