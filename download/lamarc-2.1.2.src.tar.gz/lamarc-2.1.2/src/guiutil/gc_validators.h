#ifndef GC_VALIDATORS_H
#define GC_VALIDATORS_H

#include "wx/valtext.h"

class GCIntegerValidator : public wxTextValidator
{
    private:
        wxString                    *   m_stringVar;
    public:
        GCIntegerValidator();
        virtual ~GCIntegerValidator();
};

class GCIntegerListValidator : public wxTextValidator
{
    private:
        wxString                    *   m_stringVar;
    public:
        GCIntegerListValidator();
        virtual ~GCIntegerListValidator();
};

class GCNonNegativeIntegerValidator : public wxTextValidator
{
    private:
        wxString                    *   m_stringVar;
    public:
        GCNonNegativeIntegerValidator();
        virtual ~GCNonNegativeIntegerValidator();
};

class GCPositiveFloatValidator : public wxTextValidator
{
    private:
        wxString                    *   m_stringVar;
    public:
        GCPositiveFloatValidator();
        virtual ~GCPositiveFloatValidator();
};
#endif
//GC_VALIDATORS_H
