#include "gc_text_ctrl.h"
#include "gc_validators.h"
#include "wx/log.h"
#include "wx/event.h"


GCTextInput::GCTextInput(wxWindow * parentWindow,const wxValidator& validator)
    :
        wxTextCtrl( parentWindow,
                    -1,
                    wxEmptyString,
                    wxDefaultPosition,
                    wxDefaultSize,
                    wxTAB_TRAVERSAL | wxTE_RIGHT | wxTE_PROCESS_ENTER,
                    validator)
{
}


GCTextInput::~GCTextInput()
{
}

GCIntegerInput::GCIntegerInput(wxWindow * parentWindow)
    :
        GCTextInput(parentWindow,GCIntegerValidator())
{
}

GCIntegerInput::~GCIntegerInput()
{
}

GCNonNegativeIntegerInput::GCNonNegativeIntegerInput(wxWindow * parentWindow)
    :
        GCTextInput(parentWindow,GCNonNegativeIntegerValidator())
{
}

GCNonNegativeIntegerInput::~GCNonNegativeIntegerInput()
{
}
