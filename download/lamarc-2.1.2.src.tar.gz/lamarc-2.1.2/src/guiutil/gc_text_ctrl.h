#ifndef GC_TEXT_CTRL_H
#define GC_TEXT_CTRL_H

#include "wx/textctrl.h"

class GCTextInput : public wxTextCtrl
{

    private:
        GCTextInput();       // undefined
    public:
        GCTextInput(wxWindow * parentWindow,const wxValidator& validator);
        virtual ~GCTextInput();
};


class GCIntegerInput : public GCTextInput
{
    private:
        GCIntegerInput();       // undefined
    public:
        GCIntegerInput(wxWindow * parentWindow);
        virtual ~GCIntegerInput();
};

class GCNonNegativeIntegerInput : public GCTextInput
{
    private:
        GCNonNegativeIntegerInput();       // undefined
    public:
        GCNonNegativeIntegerInput(wxWindow * parentWindow);
        virtual ~GCNonNegativeIntegerInput();
};

#endif
//GC_TEXT_CTRL_H
