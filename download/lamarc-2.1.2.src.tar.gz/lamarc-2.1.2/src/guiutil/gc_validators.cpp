#include "gc_data.h"
#include "gc_validators.h"

///////////////////////////////////////////////

GCIntegerValidator::GCIntegerValidator()
    :
        wxTextValidator(wxFILTER_INCLUDE_CHAR_LIST)
{
    SetIncludes(gcdata::integerList());
}

GCIntegerValidator::~GCIntegerValidator()
{
}

///////////////////////////////////////////////

GCIntegerListValidator::GCIntegerListValidator()
    :
        wxTextValidator(wxFILTER_INCLUDE_CHAR_LIST)
{
    SetIncludes(gcdata::integerListWithSpaces());
}

GCIntegerListValidator::~GCIntegerListValidator()
{
}

///////////////////////////////////////////////

GCNonNegativeIntegerValidator::GCNonNegativeIntegerValidator()
    :
        wxTextValidator(wxFILTER_INCLUDE_CHAR_LIST)
{
    SetIncludes(gcdata::nonNegativeIntegerList());
}

GCNonNegativeIntegerValidator::~GCNonNegativeIntegerValidator()
{
}

///////////////////////////////////////////////

GCPositiveFloatValidator::GCPositiveFloatValidator()
    :
        wxTextValidator(wxFILTER_INCLUDE_CHAR_LIST)
{
    SetIncludes(gcdata::positiveFloatChars());
}

GCPositiveFloatValidator::~GCPositiveFloatValidator()
{
}
