#ifndef GC_CLICKPANEL_H
#define GC_CLICKPANEL_H

//#include "gc_event_ids.h"
//#include "gc_layout.h"
//#include "wx/scrolwin.h"
#include "wx/sizer.h"
#include "wx/stattext.h"
#include "wx/wx.h"

class gcClickCell;

class gcClickPanel : public wxPanel
{
    private:
    protected:
        wxBoxSizer *        m_sizer;
    public:
        gcClickPanel(gcClickCell * parent);
        virtual ~gcClickPanel();

        void AddText(wxString text);
        void OnMouse(wxMouseEvent & event);
        void RecursiveSetColour(wxColour c);

        void        FinishSizing();

        DECLARE_EVENT_TABLE()

};

class gcClickCell : public wxPanel
{
    private:
        gcClickCell();         // undefined
    protected:
        wxStaticBoxSizer *      m_sizer;
        gcClickPanel *          m_clickPanel;
        bool                    m_mouseInCell;

        void        FinishSizing();
    public:
        gcClickCell(wxWindow * parent, wxString label);
        virtual ~gcClickCell();

        void OnMouse(wxMouseEvent & event);
        void RecursiveSetColour(wxColour c);

        virtual void NotifyEntering     ();
        virtual void NotifyLeaving      ();
        virtual void NotifyLeftDClick   ();
        virtual void NotifyLeftDown     ();
        virtual void NotifyLeftUp       ();

        void AddText(wxString text);
        

        DECLARE_EVENT_TABLE()

};


class gcClickText : public wxStaticText
{
    private:
        gcClickText();       // undefined
    protected:
        gcClickPanel *     m_parent;
    public:
        gcClickText(gcClickPanel * parent,wxString label);
        virtual ~gcClickText();

        void OnMouse(wxMouseEvent & event);

        DECLARE_EVENT_TABLE()
};



#endif
// GC_CLICKPANEL_H
