// $Id: registry.h,v 1.25 2007/04/27 19:56:55 lpsmith Exp $

#ifndef REGISTRY_H
#define REGISTRY_H

/* 
   Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include <stdlib.h>
#include "constants.h"
#include "defaults.h"
#include "chainparam.h"
#include "userparam.h"
#include "datapack.h"
#include "forcesummary.h"
#include "random.h"
#include "errhandling.h"
#include "regiongammainfo.h"

/***************************************************************
 The Registry has two functions:

 (1)  It holds (most of) the Singleton objects of the program
 and provides access to them.

 (2)  It holds prototypes of objects which must be created in
 a specific way for each run.  For example, it holds a
 prototypical Tree.  Once the program knows what kind of Tree will
 be wanted, a prototype is put in the Registry and all further
 Tree creation is done by Clone() of the prototype.

 The Registry is itself a Singleton.  The single instance is
 global (it's in lamarc.cpp) and it's extern everywhere (via
 constants.h).

 Written by Mary Kuhner 
*******************************************************************/

class Analyzer;
class BayesAnalyzer_1D;
class DataModel;
class Locus;
class Maximizer;
class RegionPostLike;
class GammaRegionPostLike;
class ReplicatePostLike;
class RunReport;
class SinglePostLike;
class Tree;
class TreeSummary;
class UIInterface;
class UIVarsDataModels;
class UIVarsDataPackPlus;
class UIRegId;
class CellManager;

class Registry
{
  public:
    Registry();
    ~Registry();

    // Initialization -- to foil static global initialization bug
    void Init();

    // Getters
    const Tree& GetProtoTree()                  const;
    const TreeSummary& GetProtoTreeSummary()    const;
    const ChainParameters& GetChainParameters() const {return *chainparams;};
    const UserParameters& GetUserParameters()   const {return *userparams;};
    const DataPack& GetDataPack()               const {return datapack;};
    const ForceSummary& GetForceSummary()       const {return *forcesummary;};

    ChainParameters& GetChainParameters()       {return *chainparams;};
    UserParameters& GetUserParameters()         {return *userparams;};
    DataPack& GetDataPack()                     {return datapack;};
    ForceSummary& GetForceSummary()             {return *forcesummary;};
    Random& GetRandom()                         {return *random;};
    RunReport& GetRunReport();
    const RunReport& GetRunReport()             const;
    Maximizer& GetMaximizer();
    Maximizer * GetMaximizerPtr();
    BayesAnalyzer_1D& GetBayesAnalyzer_1D();
    BayesAnalyzer_1D * GetBayesAnalyzer_1DPtr();
    SinglePostLike& GetSinglePostLike();
    ReplicatePostLike& GetReplicatePostLike();
    RegionPostLike& GetRegionPostLike();
    const RegionGammaInfo* GetRegionGammaInfo() const {return pRegionGammaForceInfo;}; // NULL is allowed
    RegionGammaInfo* GetRegionGammaInfo() {return pRegionGammaForceInfo;}; // NULL is allowed
    Analyzer& GetAnalyzer();
    CellManager& GetCellManager()               {return *cellmanager; };
    bool GetConvertOutputToEliminateZeroes() {return m_convert_output_to_eliminate_zeroes;};
    // Setters
    void Register(Tree* tree);
    void Register(TreeSummary* treesum);
    void Register(RunReport* report);
    void Register(Maximizer* maxim);
  void Register(BayesAnalyzer_1D* bayesan);
    void Register(SinglePostLike* singlel);
    void Register(ReplicatePostLike* replicate);
    void Register(RegionPostLike* region);
    void Register(GammaRegionPostLike* gammaRegion);
    void Register(RegionGammaInfo* regionGammaForceInfo);
    void Register(Analyzer * thisanalyzer);
    void SetConvertOutputToEliminateZeroes(bool conv) {m_convert_output_to_eliminate_zeroes = conv;};

    // build structures from UI data
    void FinalizeDataPack(UIInterface&);
    void InstallChainParameters(UIInterface&);
    void InstallDataModels(UIInterface&);
    void InstallForcesAllOverThePlace(UIInterface&);
    void InstallUserParameters(UIInterface&);

  protected:

    DataModel * CreateDataModel(UIVarsDataModels &, const Locus&,
                                const UIVarsDataPackPlus&, UIRegId);

  private:
    Registry(const Registry&);       // not defined
    Registry& operator=(const Registry&);  // not defined

    // the prototypes
    Tree* protoTree;
    TreeSummary* protoTreeSummary;

    // the singletons
    ChainParameters *chainparams;
    UserParameters *userparams;
    DataPack datapack;
    ForceSummary *forcesummary;
    Random *random;
    CellManager *cellmanager;  // we deliberately don't delete this!

    // the runtime reporter
    RunReport* runreport;

    // the posterior-likelihood drivers
    Maximizer* maximizer;
    SinglePostLike* PLsingle;
    ReplicatePostLike* PLreplicate;
    RegionPostLike* PLregion;
    GammaRegionPostLike* PLgammaRegion;

    // the pseudo-hack
    RegionGammaInfo* pRegionGammaForceInfo;

  BayesAnalyzer_1D* bayesanalyzer;

    // the profile and plot driver
    Analyzer *analyzer;

  //Whether the user wants zeroes in the output
  bool m_convert_output_to_eliminate_zeroes;

  // error handling
  void ThrowBadPrototype() const;
};

#endif /* REGISTRY_H */

