// $Id: chainout.h,v 1.13 2006/08/25 17:36:26 jay Exp $

#ifndef CHAINOUT_H
#define CHAINOUT_H

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/********************************************************************
 Class ChainOut contains summary information about the results of
 a chain, such as the acceptance rate, parameter estimates, and
 start/end times.  It does *not* contain the summary trees, which
 are stored separately in a Collector object.

 ChainOut objects are normally stored and organized in the ChainPack.
 They can reasonably be passed by value as they are fairly small,
 simple objects.

 ChainOut has ChainPack as a friend, since the two classes are
 tightly coupled.  This would be fairly easy to change if desired.

 Written by Mary Kuhner
*********************************************************************/

#include <time.h>
#include <string>
#include <map>
#include "types.h"
#include "forceparam.h"

class ChainOut {

private:

// chain information
long badtrees;            // number of trees discarded due to limits
long tinypoptrees;        // number of trees discarded due to small popsizes
long zerodltrees;         // number of trees discarded due to 0 data likelihood
long stretchedtrees;         // number of trees discarded due to long branches
double accrate;              // overall (cold) acceptance rate
ratemap rates;               // (cold) acceptance rate per arranger
long numtemps;               // number of temperatures
DoubleVec1d swaprates;       // heating swap rates between pairs
DoubleVec1d tempaccrates;    // acceptance rates per temperature
DoubleVec1d temperatures;    // average temperatures [adaptive/static]
LongVec1d   bayesunique;     // per-parameter bayesian acceptances

// Timing information
// Type "time_t" is a C library type which holds time information
// (in seconds since 1970)
time_t starttime;
time_t endtime;

// chain MLE's
ForceParameters estimates;       // Maximum likelihood estimates
double llikemle;                 // posterior lnL at maximum
double llikedata;                // data lnL of last generated tree in chain


public:

// we accept defaults for copy constructor, operator=, and destructor
ChainOut();

// friendship to allow direct access to member variables
// for these two tightly coupled classes
friend class ChainPack;

// Inspector functions
long            GetNumBadTrees()   const {return badtrees;};
long            GetTinyPopTrees()  const {return tinypoptrees;};
long            GetStretchedTrees() const {return stretchedtrees;};
long            GetZeroDLTrees()   const {return zerodltrees;};
double          GetAccrate()       const {return accrate;};
ratemap         GetAllAccrates()   const {return rates;};
long            GetNumtemps()      const {return numtemps;};
DoubleVec1d     GetSwaprates()     const {return swaprates;};
DoubleVec1d     GetTemperatures()  const {return temperatures;};
DoubleVec1d     GetTempAccrates()  const {return tempaccrates;};
double          GetLlikemle()      const {return llikemle;};
double          GetLlikedata()     const {return llikedata;};
ForceParameters GetEstimates()     const {return estimates;};

time_t          GetStarttime()     const {return starttime;};
time_t          GetEndtime()       const {return endtime;};
vector<long>    GetBayesUnique()   const {return bayesunique;};

// Mutator functions
void SetNumBadTrees(const long &nbad)          {badtrees = nbad;};
void SetNumTinyPopTrees(const long &ntiny)     {tinypoptrees = ntiny;};
void SetNumStretchedTrees(const long &nstretch){stretchedtrees = nstretch;};
void SetNumZeroDLTrees(const long &nzero)      {zerodltrees = nzero;};
void SetAccrate(const double &r)               {accrate = r;};
void SetAllAccrates(const ratemap &r)          {rates = r;};
void SetNumtemps(const long &ntemps)           {numtemps = ntemps;};
void SetSwaprates(const DoubleVec1d &r)        {swaprates = r;};
void SetTemperatures(const DoubleVec1d &temps) {temperatures = temps;};
void SetTempAccrates(const DoubleVec1d &r)     {tempaccrates = r;};
void SetLlikemle(const double &src)            {llikemle = src;};
void SetLlikedata(const double &src)           {llikedata = src;};
void SetEstimates(const ForceParameters &src)  {estimates = src;};

void SetStarttime(const time_t &src)           {starttime = src;};
void SetEndtime(const time_t &src)             {endtime = src;};

void SetRates(const ratemap &r)		       {rates = r;};
void SetBayesUnique(const LongVec1d& b)        {bayesunique = b;};
// The following two overloads set the time to the current time,
// gotten from the system clock.
void SetStarttime();
void SetEndtime();

};

#endif /* CHAINOUT_H */
