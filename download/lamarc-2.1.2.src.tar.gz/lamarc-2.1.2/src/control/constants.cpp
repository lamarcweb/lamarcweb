
#include <string>
#include "constants.h"

const int lamarccodes::cleanReturn      = 0;
const int lamarccodes::badAllocation    = 1;
const int lamarccodes::fileError        = 2;
const int lamarccodes::unknownError     = 4;

const std::string lamarcstrings::COAL = "coalesce";
const std::string lamarcstrings::MIG = "migrate";
const std::string lamarcstrings::DISEASE = "disease";
const std::string lamarcstrings::REC = "recombine";
const std::string lamarcstrings::GROW = "grow";
const std::string lamarcstrings::REGION_GAMMA = "gamma over regions";
const std::string lamarcstrings::INVALID = "invalid";
const std::string lamarcstrings::EXPGROWSTICK = "stick grow exponential";
const std::string lamarcstrings::LOGISTICSELECTION = "logistic selection";
const std::string lamarcstrings::LOGSELECTSTICK = "stick logistic selection";

const std::string lamarcstrings::STICK = "stick";
const std::string lamarcstrings::TIP = "tip";
const std::string lamarcstrings::BASE = "base";

const std::string lamarcstrings::SNP = "SNP";
const std::string lamarcstrings::DNA = "DNA";
const std::string lamarcstrings::NUC = "NUC";
const std::string lamarcstrings::MICROSAT = "MICROSAT";

const std::string lamarcstrings::F84 = "F84";
const std::string lamarcstrings::GTR = "GTR";
const std::string lamarcstrings::STEPWISE = "Stepwise";
const std::string lamarcstrings::BROWNIAN = "Brownian";
const std::string lamarcstrings::KALLELE = "KAllele";
const std::string lamarcstrings::MIXEDKS = "MixedKS";

const std::string lamarcstrings::ELECTRO = "ELECTRO";

const std::string lamarcstrings::longNameUSER = "USER";
const std::string lamarcstrings::longNamePROGRAMDEFAULT = "PROGRAMDEFAULT";
const std::string lamarcstrings::longNameFST = "FST";
const std::string lamarcstrings::longNameWATTERSON = "WATTERSON";

const std::string lamarcstrings::shortNameUSER = "USR";
const std::string lamarcstrings::shortNamePROGRAMDEFAULT = "DEF";
const std::string lamarcstrings::shortNameFST = "FST";
const std::string lamarcstrings::shortNameWATTERSON = "WAT";

const std::string lamarcstrings::longBrownianName = "Brownian";
const std::string lamarcstrings::longF84Name = "Felsenstein '84";
const std::string lamarcstrings::longGTRName = "General Time Reversible";
const std::string lamarcstrings::longKAlleleName = "K Allele";
const std::string lamarcstrings::longStepwiseName = "Stepwise";
const std::string lamarcstrings::longMixedKSName = "Mixed KAllele-Stepwise";

const std::string lamarcstrings::shortBrownianName = "Brownian";
const std::string lamarcstrings::shortF84Name = "F84";
const std::string lamarcstrings::shortGTRName = "GTR";
const std::string lamarcstrings::shortKAlleleName = "KAllele";
const std::string lamarcstrings::shortStepwiseName = "Stepwise";
const std::string lamarcstrings::shortMixedKSName = "MixedKS";

const std::string lamarcstrings::shortCurveName =   "CURVE";
// ignoring case, lamarcstrings::shortStickExpName must be the same as
// xmlstr::XML_ATTRVALUE_STICK for use in 
// stringx.cpp::StringMatchesGrowthType() used by
// stringx.cpp::ProduceGrowthTypeOrBarf()
const std::string lamarcstrings::shortStickExpName = "STICK-EXP";
const std::string lamarcstrings::shortStickName = "STICK";
const std::string lamarcstrings::longCurveName  =   "Analytical (Curve) Growth Approx.";
const std::string lamarcstrings::longStickExpName  = "Constant (Stick) Exponential Growth Approx.";
const std::string lamarcstrings::longStickName  = "Linear (Stick) Growth Approx.";

const std::string lamarcstrings::longExpName = "Exponential";
const std::string lamarcstrings::shortExpName = "Exponential";
const std::string lamarcstrings::longStairStepName = "Stair Step";
const std::string lamarcstrings::shortStairStepName = "StairStep";
