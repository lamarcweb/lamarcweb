// $Id: registry.cpp,v 1.75 2007/10/03 16:48:25 mkkuhner Exp $

/* 
   Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include "arranger.h"
#include "analyzer.h"
#include "bayesanalyzer_1d.h"
#include "defaults.h"
#include "dlmodel.h"
#include "errhandling.h"
#include "force.h"
#include "likelihood.h"
#include "maximizer.h"
#include "region.h"
#include "regiongammainfo.h"
#include "registry.h"
#include "runreport.h"
#include "tree.h"
#include "treesum.h"
#include "ui_interface.h"
#include "ui_regid.h"
#include "ui_vars.h"
#include "cellmanager.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

class RegionGammaInfo;

//______________________________________________________________

Registry::Registry()
  :
  protoTree(NULL),
  protoTreeSummary(NULL),
  chainparams(NULL),
  userparams(NULL),
  forcesummary(NULL),
  random(NULL),
  runreport(NULL),
  maximizer(NULL),
  PLsingle(NULL),
  PLreplicate(NULL),
  PLregion(NULL),
  PLgammaRegion(NULL),
  pRegionGammaForceInfo(NULL),
  bayesanalyzer(NULL),
  analyzer(NULL),
  m_convert_output_to_eliminate_zeroes(defaults::convert_output_to_eliminate_zeroes)
{
  cellmanager = new CellManager;
} /* Registry constructor */

//______________________________________________________________

Registry::~Registry()
{
  delete protoTree;
  delete protoTreeSummary;
  delete PLsingle;
  delete PLreplicate;
  delete PLregion;
  delete PLgammaRegion;
  delete runreport;
  delete maximizer;
  delete bayesanalyzer;
  delete analyzer;
  delete chainparams;
  delete userparams;
  delete random;
  delete forcesummary;
  delete pRegionGammaForceInfo;
} /* Registry destructor */


//______________________________________________________________

const Tree& Registry::GetProtoTree() const
{
  if (protoTree == NULL) ThrowBadPrototype();
  return(*protoTree);
} /* GetProtoTree */

//______________________________________________________________

const TreeSummary& Registry::GetProtoTreeSummary() const
{
  if (protoTreeSummary == NULL) ThrowBadPrototype();
  return (*protoTreeSummary);
} /* GetProtoTreeSummary */
//______________________________________________________________

RunReport& Registry::GetRunReport()
{
  if (runreport == NULL) ThrowBadPrototype();
  return (*runreport);
} /* Registry::GetRunReport() */

//______________________________________________________________

const RunReport& Registry::GetRunReport() const
{
  if (runreport == NULL) ThrowBadPrototype();
  return (*runreport);
} /* Registry::GetRunReport() */

//______________________________________________________________

Maximizer& Registry::GetMaximizer()
{
  if (maximizer == NULL) ThrowBadPrototype();
  return (*maximizer);
} /* Registry::GetMaximizer */

Maximizer * Registry::GetMaximizerPtr()
{
  if (maximizer == NULL) ThrowBadPrototype();
  return (maximizer);
} /* Registry::GetMaximizer */

//______________________________________________________________

BayesAnalyzer_1D& Registry::GetBayesAnalyzer_1D()
{
  if (bayesanalyzer == NULL) ThrowBadPrototype();
  return (*bayesanalyzer);
} /* Registry::GetBayesAnalyzer_1D */

BayesAnalyzer_1D * Registry::GetBayesAnalyzer_1DPtr()
{
  if (bayesanalyzer == NULL) ThrowBadPrototype();
  return (bayesanalyzer);
} /* Registry::GetBayesAnalyzer_1D */

//______________________________________________________________

SinglePostLike& Registry::GetSinglePostLike()
{
  if (PLsingle == NULL) ThrowBadPrototype();
  return (*PLsingle);
} /* Registry::GetSinglePostLike */

//______________________________________________________________

ReplicatePostLike& Registry::GetReplicatePostLike()
{
  if (PLreplicate == NULL) ThrowBadPrototype();
  return (*PLreplicate);
} /* Registry::GetReplicatePostLike */

//______________________________________________________________

RegionPostLike& Registry::GetRegionPostLike()
{
  if (GetRegionGammaInfo()) {
    if (PLgammaRegion == NULL) ThrowBadPrototype();
    return (*PLgammaRegion);
  }
  else {
    if (PLregion == NULL) ThrowBadPrototype();
    return (*PLregion);
  }
} /* Registry::GetRegionPostLike */

//______________________________________________________________

Analyzer& Registry::GetAnalyzer()
{
  if (analyzer == NULL) ThrowBadPrototype();
  return (*analyzer);
} /* Registry::GetRegionPostLike */

//______________________________________________________________

void Registry::Register(Tree* tree)
{
  delete protoTree;
  protoTree = tree;
} /* Register (Tree) */

//______________________________________________________________

void Registry::Register(RunReport* report)
{
  delete runreport;
  runreport = report;

} /* Registry::Register(RunReport) */

//______________________________________________________________
void Registry::Register(Maximizer* maxim)
{
  delete maximizer;
  maximizer = maxim;
} /* Registry::Register (Maximizer) */

//______________________________________________________________

void Registry::Register(BayesAnalyzer_1D* bayesan)
{
  delete bayesanalyzer;
  bayesanalyzer = bayesan;
} /* Registry::Register (BayesAnalyzer_1D) */

//______________________________________________________________

void Registry::Register(SinglePostLike* singlel)
{
  delete PLsingle;
  PLsingle = singlel;
} /* Registry::Register (SinglePostLike) */

//______________________________________________________________

void Registry::Register(ReplicatePostLike* replicate)
{
  delete PLreplicate;
  PLreplicate = replicate;
} /* Registry::Register (ReplicatePostLike) */

//______________________________________________________________

void Registry::Register(RegionPostLike* region)
{
  delete PLregion;
  PLregion = region;
} /* Registry::Register (RegionPostLike) */

//______________________________________________________________

void Registry::Register(GammaRegionPostLike* gammaRegion)
{
  delete PLgammaRegion;
  PLgammaRegion = gammaRegion;
} /* Registry::Register (GammaRegionPostLike) */

//______________________________________________________________

void Registry::Register(RegionGammaInfo* pRGFI)
{
  delete pRegionGammaForceInfo;
  pRegionGammaForceInfo = pRGFI;
} /* Registry::Register (RegionGammaInfo) */

//______________________________________________________________

void Registry::Register(Analyzer *thisanalyzer)
{
  delete analyzer;
  analyzer = thisanalyzer;
} /* Registry::Register (RegionPostLike) */


//______________________________________________________________

void Registry::Register(TreeSummary* treesum)
{
  delete protoTreeSummary;
  protoTreeSummary = treesum;
} /* Registry::Register (intervaldata) */

//______________________________________________________________

void Registry::ThrowBadPrototype() const
{
  logic_error e("Attempt to use unregistered prototype");
  throw e;
}

//______________________________________________________________

void Registry::FinalizeDataPack(UIInterface& ui)
{
  //Set the effective population sizes
  DoubleVec1d effectivePopSizes 
    = ui.GetCurrentVars().datapackplus.GetEffectivePopSizes();
  long nRegions = datapack.GetNRegions();
  assert(static_cast<long>(effectivePopSizes.size()) == nRegions);
  for (long regnum=0; regnum < nRegions; regnum++) {
    datapack.GetRegion(regnum).SetEffectivePopSize(effectivePopSizes[regnum]);
  }

  //Now set up all the trait information and whether to simulate
  for (long regnum=0; regnum < nRegions; regnum++) {
    long nLoci = datapack.GetRegion(regnum).GetNloci();
    long regoffset = datapack.GetRegion(regnum).GetSiteSpan().first;
    for (long locusnum=0; locusnum < nLoci; locusnum++) {
      Locus& locus = datapack.GetRegion(regnum).GetLocus(locusnum);
      locus.SetShouldSimulate(ui.GetCurrentVars().datapackplus.GetSimulateData(regnum, locusnum));
      if (locus.IsMovable()) {
        UIRegId regID(regnum, locusnum, ui.GetCurrentVars());
        const UIVarsTraitModels& traits = ui.GetCurrentVars().traitmodels;
        locus.SetName(traits.GetName(regID));
        locus.SetAnalysisType(traits.GetAnalysisType(regID));
        locus.SetAllowedRange(traits.GetRange(regID), regoffset);
        locus.SetGlobalMapposition(traits.GetInitialMapPosition(regID));
        //And set up the phenotypes (for simulation, possibly)
        locus.SetPhenotypes(traits.GetPhenotypes(regID));
      }
    }
    // This call sets up the moving and non-moving loci, gets them
    // assigned to their correct positions on the overall map of the
    // region, and creates their DLCells and DLCalculators.
    datapack.GetRegion(regnum).SetupAndMoveAllLoci();
  }

}/* FinalizeDataPack */

//______________________________________________________________

void Registry::InstallChainParameters(UIInterface& ui)
{
  UIVarsChainParameters & chains = ui.GetCurrentVars().chains;

  double dropTiming = chains.GetDropArrangerRelativeTiming();
  double sizeTiming = chains.GetSizeArrangerRelativeTiming();
  double hapTiming = 
    chains.GetHaplotypeArrangerPossible() 
    ? chains.GetHaplotypeArrangerRelativeTiming()
    : 0.0 ;
  double probhapTiming =
    chains.GetProbHapArrangerPossible()
    ? chains.GetProbHapArrangerRelativeTiming()
    : 0.0 ;
  double bayesTiming = 
    chains.GetDoBayesianAnalysis() 
    ? chains.GetBayesianArrangerRelativeTiming() 
    : 0.0 ;
  double locusTiming = 
    ui.GetCurrentVars().traitmodels.AnyJumpingAnalyses()
    ? chains.GetLocusArrangerRelativeTiming()
    : 0.0 ;
  double zilchTiming = 
    ui.GetCurrentVars().datapackplus.AnySimulation()
    ? chains.GetZilchArrangerRelativeTiming()
    : 0.0 ;

  chainparams = new ChainParameters(
                                    chains.GetChainTemperatures(),
                                    chains.GetTemperatureInterval(),
                                    chains.GetAdaptiveTemperatures(),
                                    chains.GetInitialNumberOfChains(),
                                    chains.GetInitialNumberOfSamples(),
                                    chains.GetInitialChainSamplingInterval(),
                                    chains.GetInitialNumberOfChainsToDiscard(),
                                    chains.GetFinalNumberOfChains(),
                                    chains.GetFinalNumberOfSamples(),
                                    chains.GetFinalChainSamplingInterval(),
                                    chains.GetFinalNumberOfChainsToDiscard(),
                                    chains.GetNumberOfReplicates(),
                                    chains.GetDoBayesianAnalysis(),
                                    dropTiming,
                                    sizeTiming,
                                    hapTiming,
                                    probhapTiming,
                                    bayesTiming,
                                    locusTiming,
                                    zilchTiming
                                    );
}

void Registry::InstallUserParameters(UIInterface& ui)
{
  UIVarsUserParameters & uparams = ui.GetCurrentVars().userparams;

  userparams = new UserParameters(
                                  uparams.GetCurveFilePrefix(),
                                  uparams.GetTraceFilePrefix(),
                                  uparams.GetNewickTreeFilePrefix(),
                                  uparams.GetDataFileName(),
                                  uparams.GetResultsFileName(),
                                  uparams.GetTreeSumInFileName(),
                                  uparams.GetTreeSumOutFileName(),
                                  uparams.GetXMLOutFileName(),
                                  uparams.GetVerbosity(),
                                  uparams.GetProgress(),
                                  uparams.GetPlotPost(),
                                  uparams.GetUseSystemClock(),
                                  uparams.GetReadSumFile(),
                                  uparams.GetWriteSumFile(),
                                  uparams.GetWriteCurveFiles(),
				  uparams.GetWriteTraceFiles(),
				  uparams.GetWriteNewickTreeFiles(),
                                  uparams.GetRandomSeed(),
                                  uparams.GetProgramStartTime()
                                  );

  random = new Random(uparams.GetRandomSeed());
}


DataModel * Registry::CreateDataModel(UIVarsDataModels& modelVars, const Locus& locus, const UIVarsDataPackPlus& dataPackPlus, UIRegId regionId)
{

  data_type thisDataType = locus.GetDataType();
  model_type modelType = modelVars.GetDataModelType(regionId);
  if(!(ModelTypeAcceptsDataType(modelType,thisDataType)))
  {
    // If we reach this point, we have a data model for an inappropriate
    // region/locus pair.  This should be avoided.  --LS NOTE
    assert(false);
    modelType = DefaultModelForDataType(thisDataType);
  }

  switch(modelType)
  {
  case F84:
    {
      F84Model * model 
        = new F84Model(
                       locus.GetNmarkers(),
                       modelVars.GetNumCategories(regionId),
                       modelVars.GetCategoryRates(regionId),
                       modelVars.GetCategoryProbabilities(regionId),
                       modelVars.GetAutoCorrelation(regionId),
                       modelVars.GetNormalization(regionId),
                       modelVars.GetRelativeMuRate(regionId),
                       modelVars.GetFrequencyA(regionId),
                       modelVars.GetFrequencyC(regionId),
                       modelVars.GetFrequencyG(regionId),
                       modelVars.GetFrequencyT(regionId),
                       modelVars.GetTTRatio(regionId),
                       modelVars.GetCalcFreqsFromData(regionId)
                       );
      return model;
    }
    break;
  case Brownian:
    {
      BrownianModel * model
        = new BrownianModel(
                            locus.GetNmarkers(),
                            modelVars.GetNumCategories(regionId),
                            modelVars.GetCategoryRates(regionId),
                            modelVars.GetCategoryProbabilities(regionId),
                            modelVars.GetAutoCorrelation(regionId),
                            modelVars.GetNormalization(regionId),
                            modelVars.GetRelativeMuRate(regionId)
                            );
      return model;
    }
    break;
  case Stepwise:
    {
      StepwiseModel * model
        = new StepwiseModel(
                            locus.GetNmarkers(),
                            dataPackPlus.GetUniqueAlleles(regionId.GetRegion(),
                                                          regionId.GetLocus()),
                            modelVars.GetNumCategories(regionId),
                            modelVars.GetCategoryRates(regionId),
                            modelVars.GetCategoryProbabilities(regionId),
                            modelVars.GetAutoCorrelation(regionId),
                            modelVars.GetNormalization(regionId),
                            modelVars.GetRelativeMuRate(regionId)
                            );
      return model;
    }
    break;
  case KAllele:
    {
      //If we have trait data with unknown haplotypes, we might have
      // some possible alleles that are not represented in the tip data.
      // In this case, we need to get those strings out of the individuals.
      KAlleleModel * model
        = new KAlleleModel(
                           locus.GetNmarkers(),
                           dataPackPlus.GetUniqueAlleles(regionId.GetRegion(),
                                                         regionId.GetLocus()),
                           modelVars.GetNumCategories(regionId),
                           modelVars.GetCategoryRates(regionId),
                           modelVars.GetCategoryProbabilities(regionId),
                           modelVars.GetAutoCorrelation(regionId),
                           modelVars.GetNormalization(regionId),
                           modelVars.GetRelativeMuRate(regionId)
                           );
      return model;
    }
    break;
  case GTR:
    {
      GTRModel * model 
        = new GTRModel(
                       locus.GetNmarkers(),
                       modelVars.GetNumCategories(regionId),
                       modelVars.GetCategoryRates(regionId),
                       modelVars.GetCategoryProbabilities(regionId),
                       modelVars.GetAutoCorrelation(regionId),
                       modelVars.GetNormalization(regionId),
                       modelVars.GetRelativeMuRate(regionId),
                       modelVars.GetFrequencyA(regionId),
                       modelVars.GetFrequencyC(regionId),
                       modelVars.GetFrequencyG(regionId),
                       modelVars.GetFrequencyT(regionId),
                       modelVars.GetGTR_AC(regionId),
                       modelVars.GetGTR_AG(regionId),
                       modelVars.GetGTR_AT(regionId),
                       modelVars.GetGTR_CG(regionId),
                       modelVars.GetGTR_CT(regionId),
                       modelVars.GetGTR_GT(regionId)
                       );
      return model;
    }
    break;
  case MixedKS:
    {
      MixedKSModel * model
        = new MixedKSModel(
                           locus.GetNmarkers(),
                           dataPackPlus.GetUniqueAlleles(regionId.GetRegion(),
                                                         regionId.GetLocus()),
                           modelVars.GetNumCategories(regionId),
                           modelVars.GetCategoryRates(regionId),
                           modelVars.GetCategoryProbabilities(regionId),
                           modelVars.GetAutoCorrelation(regionId),
                           modelVars.GetNormalization(regionId),
                           modelVars.GetRelativeMuRate(regionId),
                           modelVars.GetAlpha(regionId),
                           modelVars.GetOptimizeAlpha(regionId)
                           );
      return model;
    }
    break;
  }
  throw implementation_error("Registry::CreateDataModel needs to know how to build a "+ToString(modelType) + " model ");
}


void Registry::InstallDataModels(UIInterface& ui)
{
  UIVars & vars = ui.GetCurrentVars();

  // install models for each region
  for(long regionId = 0; regionId < vars.datapackplus.GetNumRegions() ; regionId++)
  {
    Region & thisRegion = datapack.GetRegion(regionId);

    for(long locusId = 0; locusId < thisRegion.GetNloci(); locusId++)
    {
      Locus & thisLocus = thisRegion.GetLocus(locusId);
      UIRegId regId(regionId, locusId, vars);

      DataModel * modelForThisLocus
        = CreateDataModel(vars.datamodel, thisLocus, vars.datapackplus, regId);

      // whatever model we've created, attach it to this locus
      thisLocus.SetDataModelOnce(DataModel_ptr(modelForThisLocus));


      // let's make sure we've done this right
      string errString;
      if(!thisLocus.IsValid(errString))
      {
        throw implementation_error("Inconsistent region "+errString);
      }
    }
  }

}


void Registry::InstallForcesAllOverThePlace(UIInterface& ui)
{

  UIVars& vars = ui.GetCurrentVars(); //Not const because of FixGroups().

  // get list of forces to create and install into the forcesummary
  ForceTypeVec1d activeForceTypes = vars.forces.GetActiveForces();
  LongVec1d activeForceSizes = vars.forces.GetForceSizes();
  ForceTypeVec1d::iterator iter;
  LongVec1d::iterator forceSize_iter;

  if (vars.forces.GetForceOnOff(force_REGION_GAMMA))
    {
      vector<Parameter> emptyParamVector;
      RegionGammaForce *pRegionGammaForce = new RegionGammaForce(emptyParamVector,
								 vars.forces.GetGroups(force_REGION_GAMMA),
								 vars.forces.GetDefaultPrior(force_REGION_GAMMA));
      RegionGammaInfo *pRegionGammaInfo =
	new RegionGammaInfo(vars.forces.GetStartValue(force_REGION_GAMMA, 0),
			    vars.forces.GetParamstatus(force_REGION_GAMMA, 0),
			    vars.forces.GetDoProfile(force_REGION_GAMMA, 0),
			    vars.forces.GetProfileType(force_REGION_GAMMA),
			    vars.forces.GetProfileTypeSummaryDescription(force_REGION_GAMMA),
			    pRegionGammaForce);
      Register(pRegionGammaInfo);

      // Prevent this force from being added to forceparams.
      for (iter = activeForceTypes.begin(), forceSize_iter = activeForceSizes.begin();
	   iter != activeForceTypes.end() && *iter != force_REGION_GAMMA; iter++,
	     forceSize_iter++)
	; // purposely empty loop body
      if (activeForceTypes.end() == iter || activeForceSizes.end() == forceSize_iter)
	{
	  string msg = "Registry::InstallForcesAllOverThePlace(), vars.forces.GetForceOnOff(";
	  msg += "force_REGION_GAMMA) claimed this force was active, but vars.forces.";
	  msg += "GetActiveForces() did not return the label for this force.";
	  throw implementation_error(msg);
	}
      activeForceTypes.erase(iter);
      activeForceSizes.erase(forceSize_iter);
    }

  ForceParameters forceparams(global_region, activeForceTypes, activeForceSizes);
    
  unsigned long paramvecIndex = 0;
  ForceVec allforces;
  bool logisticSelectionIsOn(vars.forces.GetForceOnOff(force_LOGISTICSELECTION));
  CoalesceLogisticSelectionPL *pCoalLogisticSelectionPL(NULL);
  DiseaseLogisticSelectionPL *pDiseaseLogisticSelectionPL(NULL);
  
  for(iter = activeForceTypes.begin(); iter != activeForceTypes.end(); iter++)
  {
    const force_type thisForceType = *iter;
    vars.forces.FixGroups(thisForceType);
    if (!vars.forces.GetForceZeroesValidity(thisForceType))
    {
      string err = "Invalid settings for force ";
      err += ToString(thisForceType) + ".  Too many parameters are set invalid or have a start value of 0.0.";
      throw data_error(err);
    }
    // build parameters for this force
    long nParamsForThisForce = vars.forces.GetNumParameters(thisForceType);
    vector<Parameter> parameters;
    for(long paramIndex = 0; paramIndex < nParamsForThisForce;
        paramIndex++, paramvecIndex++)
    {
      bool thisParamValid = vars.forces.GetParamValid(thisForceType,paramIndex);
      paramstatus pstat=vars.forces.GetParamstatus(thisForceType,paramIndex);
      proftype ptype=vars.forces.GetProfileType(thisForceType,paramIndex);
      if(thisParamValid)
      {
        force_type phase2type(vars.forces.GetPhase2Type(thisForceType));
        parameters.push_back
          (Parameter
           (pstat,
            paramvecIndex,
            vars.datapackplus.GetParamName(phase2type,paramIndex,false),
            vars.datapackplus.GetParamName(phase2type,paramIndex,true),
            phase2type,
            vars.forces.GetStartMethod(thisForceType,paramIndex),
            ptype,
            vars.forces.GetPrior(thisForceType,paramIndex),
            vars.forces.GetTrueValue(thisForceType,paramIndex)
            ));
      }
      else
      {
        parameters.push_back(Parameter(pstat_invalid, paramvecIndex));
        assert (pstat==pstat_invalid); //Warn the user about their input? -LS
      }
    }
    Force * newForce = NULL;
    long maxEvents = vars.forces.GetMaxEvents(thisForceType);
    const vector<ParamGroup> groups = vars.forces.GetGroups(thisForceType);
    for (unsigned long gnum=0; gnum<groups.size(); gnum++) {
      if (groups[gnum].first == pstat_identical) {
        //We need to re-name one parameter for every such group.
        long pindex = groups[gnum].second[0];
        assert(parameters[pindex].GetStatus() == pstat_joint);
        parameters[pindex].SetShortName(vars.GetParamNameWithConstraint(thisForceType, pindex, false));
        parameters[pindex].SetName(vars.GetParamNameWithConstraint(thisForceType, pindex, true));
      }
    }
        
    switch(thisForceType)
    {
    case force_COAL:
      newForce = new CoalForce(
                               parameters,
                               maxEvents,
                               vars.forces.GetForceOnOff(force_GROW),
                               logisticSelectionIsOn,
                               groups,
                               vars.forces.GetDefaultPrior(thisForceType));
      if (logisticSelectionIsOn)
	{
	  pCoalLogisticSelectionPL = dynamic_cast<CoalesceLogisticSelectionPL*>(newForce->GetPLForceFunction());
	  if (!pCoalLogisticSelectionPL)
	    {
	      string msg = "Registry::InstallForcesAllOverThePlace(), detected that ";
	      msg += "the logistic selection force is on, but failed to obtain a ";
	      msg += "CoalesceLogisticSelectionPL object from a CoalForce object.";
	      throw implementation_error(msg);
	    }
	}
      break;
    case force_MIG:
      newForce = new MigForce
        (
         parameters,
         maxEvents,
         vars.datapackplus.GetNPartitionsByForceType(thisForceType),
         groups,
         vars.forces.GetDefaultPrior(thisForceType));
      break;
    case force_DISEASE:
      newForce = new DiseaseForce(
                                  parameters,
                                  maxEvents,
				  logisticSelectionIsOn,
                                  vars.datapackplus.GetNPartitionsByForceType(thisForceType),
                                  vars.forces.GetDiseaseLocation(),
                                  groups,
                                  vars.forces.GetDefaultPrior(thisForceType));
      if (logisticSelectionIsOn)
	{
	  pDiseaseLogisticSelectionPL = dynamic_cast<DiseaseLogisticSelectionPL*>(newForce->GetPLForceFunction());
	  if (!pDiseaseLogisticSelectionPL)
	    {
	      string msg = "Registry::InstallForcesAllOverThePlace(), detected that ";
	      msg += "the logistic selection force is on, but failed to obtain a ";
	      msg += "DiseaseLogisticSelectionPL object from a DiseaseForce object.";
	      throw implementation_error(msg);
	    }
	}
      break;
    case force_REC:
      newForce = new RecForce(
                              parameters,
                              maxEvents,
                              groups,
                              vars.forces.GetDefaultPrior(thisForceType));
      break;

    case force_EXPGROWSTICK:
    case force_GROW:
      if (vars.forces.GetGrowthType() == growth_STICKEXP) {
         // stick exponential model
        newForce = new StickExpGrowForce(
                                 parameters,
                                 maxEvents,
                                 groups,
                                 vars.forces.GetDefaultPrior(thisForceType));
      } else { // default growth model
        newForce = new GrowthForce(
                                 parameters,
                                 maxEvents,
                                 groups,
                                 vars.forces.GetDefaultPrior(thisForceType));
      }
      break;

    case force_LOGISTICSELECTION:
      newForce = new LogisticSelectionForce(
				      parameters,
				      maxEvents,
				      paramvecIndex - 1, // -1 to counteract "for" loop
				      groups,
				      vars.forces.GetDefaultPrior(thisForceType));

      // temporary HACK:  Assumes force_COAL processed before force_LOGISTICSELECTION.
      if (!pCoalLogisticSelectionPL)
	{
	  string msg = "Registry::InstallForcesAllOverThePlace(), while processing ";
	  msg += "the logistic selection force, expected to have access to a ";
	  msg += "CoalesceLogisticSelectionPL object, but this object was not found.";
	  throw implementation_error(msg);
	}
      pCoalLogisticSelectionPL->SetSelectionCoefficientLocation(paramvecIndex - 1);
      pDiseaseLogisticSelectionPL->SetSelectionCoefficientLocation(paramvecIndex - 1);
      // -1 because paramvecIndex gets incremented one extra time when the "for" loop stops
      break;

    case force_LOGSELECTSTICK:
      newForce = new StickLogSelectForce(parameters,maxEvents,
         groups,vars.forces.GetDefaultPrior(thisForceType));
      // JDEBUG -- do I need to do something with
      // pCoalLogisticSelectionPL?   See force_LOGISTICSELECTION above
      break;

    case force_REGION_GAMMA:
      string msg = "Registry::InstallForcesAllOverThePlace() is using ";
      msg += "force_REGION_GAMMA in two conflicting ways.";
      throw implementation_error(msg);
      break;
    }
    assert(newForce != NULL);
    allforces.push_back(newForce);
    forceparams.SetGlobalParametersByTag(thisForceType, vars.forces.GetStartValues(thisForceType));
  }

  // install forces into the forcesummary.
  forcesummary = new ForceSummary(allforces, forceparams, GetDataPack());
  assert (forcesummary->IsValid());


  // Create and register a ProtoTree using the new forcesummary object.
  Register(forcesummary->CreateProtoTreeSummary());
    

}

//______________________________________________________________
