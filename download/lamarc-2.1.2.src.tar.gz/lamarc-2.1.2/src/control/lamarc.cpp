//$Id: lamarc.cpp,v 1.123 2007/09/11 17:48:42 lpsmith Exp $

/* 
   Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include <iostream>
#include <string>
#include <vector>
#include <signal.h>
#include "analyzer.h"
#include "arranger.h"
#include "bayesanalyzer_1d.h"
#include "chainmanager.h"
#include "chainout.h"
#include "chainparam.h"
#include "constants.h"
#include "datafilenamedialog.h"
#include "datapack.h"
#include "datatype.h"
#include "dialog.h"
#include "display.h"
#include "dlmodel.h"
#include "forcesummary.h"
#include "front_end_warnings.h"
#include "lamarc.h"
#include "lamarcheaderdialog.h"
#include "lamarcmenu.h"
#include "likelihood.h"
#include "maximizer.h"
#include "newmenuitems.h"
#include "nomenufilereaddialog.h"
#include "outputfile.h"
#include "parameter.h"
#include "parsetreeschema.h"
#include "parsetreetodata.h"
#include "parsetreetosettings.h"
#include "plotstat.h"
#include "region.h"
#include "registry.h"
#include "runreport.h"
#include "stringx.h"
#include "treesum.h"
#include "ui_interface.h"
#include "ui_vars.h"
#include "userparam.h"
#include "xml.h"
#include "xml_strings.h"
using namespace std;

//_________________________________________________________
// Global variable section.  
// The Registry singleton is global because everyone in
// the world needs to use it.

Registry registry;
extern jmp_buf prewrite;

//_________________________________________________________
// This routine controls the menu, if any, and other
// startup issues.
bool DoUserInput(long argc, char** argv) 
{


  // DEFAULTS and SETUP ==================================
  // DataPack& datapack = registry.GetDataPack();
  BranchTag::BeginBranchIDs(defaults::numSemiUniqueBranches);

  // menu subsystem ======================================

  ScrollingDisplay display;
  LamarcHeaderDialog header;
  header.InvokeMe(display); 


  LamarcSchema        schema;
  FrontEndWarnings    warnings;
  XmlParser           parser(schema,warnings);

  string infilename;
  bool infileprovided=false;
  bool batchmode=false;
  for (int arg=1; arg<argc; arg++) {
    string option(argv[arg]);
    if (option == "-b" || option=="--batch") {
      batchmode = true;
    }
    else if (!infileprovided) {
      infileprovided = true;
      infilename = option;
      parser.ParseFileData(infilename);
    }
    else {
      string msg("Warning:  Unknown command-line option:  " + option +
                 ".  (Using " + infilename +
                 " as the name of the input file.)");
      warnings.AddWarning(msg);
    }
  }
  if (!infileprovided) {
    if (batchmode) {
      // advises user that inputFileName will be read
      NoMenuFileReadDialog noMenuFileReadDialog(parser);
      noMenuFileReadDialog.InvokeMe(display);
    }
    else {
    // allows user to change inputFileName
    DataFileNameDialog dataDialog(parser);
    dataDialog.InvokeMe(display);
    }
  }

  // print out any warnings that occured during parsing
  display.Warn(warnings.GetAndClearWarnings());

  // read the datapack portion of the input file
  ParseTreeToData dataParser(parser,registry.GetDataPack());
  dataParser.ProcessFileData();


  // read the settings portion of the input file
  UIInterface uiInterface(warnings,registry.GetDataPack(),parser.GetFileName());
  uiInterface.SetUndoRedoMode(undoRedoMode_FILE);
  ParseTreeToSettings settingsParser(parser,uiInterface);

  // If we're in batch mode, default to no output (verbosity="none").  However,
  //  we allow this to be overwritten by the input file.
  if (batchmode) {
    uiInterface.GetCurrentVars().userparams.SetProgress(NONE);
  }
  
  settingsParser.ProcessFileSettings();

  bool runProgram = true;
  if (!batchmode) {
    // main menu: all menus and displays, setting of parameters
    uiInterface.SetUndoRedoMode(undoRedoMode_USER);
    LamarcMainMenu mainmenu(uiInterface);
    bool stayInLoop = true;
    while (stayInLoop) {
      menu_return_type menuCmd = mainmenu.InvokeMe(display);
      switch(menuCmd)
      {
      case menu_RUN:
        uiInterface.AddWarning("(Already at top-level menu.  Type '.' to run LAMARC.)");
        stayInLoop = false;
        break;
      case menu_QUIT:
        stayInLoop = false;
        runProgram = false;
        break;
      default:
        break;
      }
    
    }
  }

  FinishRegistry(uiInterface); 


  return runProgram;
 
} /* DoUserInput */

/***********************************************************
 This routine constructs and registers objects which
 require user-generated information to create:
    the proto-tree
    the runtime reporter
    the maximizer and its associated likelihoods
************************************************************/
void FinishRegistry(UIInterface & uiInterface)
{
  // build structures from uiInterface data -- ORDER MATTERS HERE
  registry.InstallUserParameters(uiInterface);
  registry.InstallForcesAllOverThePlace(uiInterface);
  registry.InstallChainParameters(uiInterface); //needs a ForceSummary, above
  registry.InstallDataModels(uiInterface);
  registry.FinalizeDataPack(uiInterface); //Needs installed datamodels 

  ForceSummary& forcesummary = registry.GetForceSummary();

  Tree * prototree = forcesummary.CreateProtoTree();
  registry.Register(prototree);

  // create and register the runtime reporter
  // MUST DO THIS BEFORE MAKING THE ANALYZER
  verbosity_type progress = registry.GetUserParameters().GetProgress();

  RunReport* prunreport = new RunReport(forcesummary, progress);

  registry.Register(prunreport);
  
  // create and register the posterior likelihood objects
  
  // retrieve user-defined values from collection objects
  // obsolete? StringVec1d forcestr = forcesummary.GetForceString();
  long nregs = registry.GetDataPack().GetNRegions();
  long nreps = registry.GetChainParameters().GetNReps();
  long paramsize = forcesummary.GetAllNParameters();

  // the maximizer itself
  Maximizer* pmax = new Maximizer(paramsize);
  pmax->SetConstraints(forcesummary.GetIdenticalGroupedParams());
  //The above could probably be moved into the maximizer constructor.
  registry.Register(pmax);

  const ParamVector params(true);
  if (!params.NumVariableParameters() &&
      registry.GetChainParameters().IsBayesian()) {
    string msg = "All parameters are fixed in value, which in a Bayesian run "
      "means no estimation is possible.  Please check your xml input file.";
    prunreport->ReportUrgent(msg);
    exit(0);
  }
  // single likelihood
  SinglePostLike* plsingle =
    new SinglePostLike(forcesummary, 
		       nregs, nreps, paramsize);
  registry.Register(plsingle);
  pmax->GradientGuideSetup(params, plsingle);
 
  // replicate likelihood
  ReplicatePostLike* plrep =
    new ReplicatePostLike(forcesummary, 
			  nregs, nreps, paramsize);
  pmax->GradientGuideSetup(params, plrep);
  registry.Register(plrep);

  // region likelihood
  // create the vector to handle parameter rescaling
  DoubleVec2d paramscalars(registry.GetDataPack().CreateParamScalarVector());
  RegionPostLike* plreg =
    new RegionPostLike(forcesummary, 
		       nregs, nreps, paramsize, paramscalars);
  pmax->GradientGuideSetup(params, plreg);
  registry.Register(plreg);

  // multi-region likelihood
  // with background mu rates varying over regions via a gamma distribution
  GammaRegionPostLike* plgammareg =
    new GammaRegionPostLike(forcesummary, 
			    nregs, nreps, paramsize, paramscalars);
  pmax->GradientGuideSetup(params, plgammareg);
  registry.Register(plgammareg);

  // Setup Analyzer subsystem {will do plots and profiles}
  Analyzer *analyzer = new Analyzer(forcesummary, params, pmax); 
  registry.Register(analyzer);

  // But we might be doing a Bayesian analysis, in which case we need a
  // bayesian analyzer instead.  For now, just do a 1D analysis.

  BayesAnalyzer_1D *bayesanalyzer = new BayesAnalyzer_1D();
  registry.Register(bayesanalyzer);
} /* FinishRegistry */

//_____________________________________________________________
//_____________________________________________________________

int main(long argc, char **argv) 
{

    int return_code = lamarccodes::cleanReturn;

// We attempt to deal with cases of a too-big output file, but
// we don't know how to make this work on Windows yet!
#if defined(LAMARC_COMPILE_LINUX) || defined(LAMARC_COMPILE_MACOSX)
  signal (SIGXFSZ, &CatchFileTooBigSignal);
#endif

#ifdef STATIONARIES
// clear out files used for stationaries record-keeping
   ofstream of;
   of.open(INTERVALFILE.c_str(),ios::trunc);
   of.close();
   of.open(MIGFILE.c_str(),ios::trunc);
   of.close();
   of.open(DISFILE.c_str(),ios::trunc);
   of.close();
   of.open(RECFILE.c_str(),ios::trunc);
   of.close();
   of.open(DISRECFILE.c_str(),ios::trunc);
   of.close();
#endif

  try {
    // handle user input including menu and data file
    bool runProgram = DoUserInput(argc,argv);

#ifdef JSIM  // call with true to get seperate files by region && pop
    registry.GetDataPack().WritePopulationXMLFiles(false);
    string ofname("flucinfile");
    registry.GetDataPack().WriteFlucFile(ofname);
#endif

    // run the chainmanager
    Maximizer& maximizer = registry.GetMaximizer();
    RunReport& runreport = registry.GetRunReport();



    if (runProgram)
    {
        try 
        {   
            XMLOutfile xmlout;
            xmlout.Display();
        }
        catch (file_error& e) {
            throw e;
        }

        ChainManager chainmanager(runreport, maximizer);
        chainmanager.Do();
      
        if (registry.GetUserParameters().GetProgress() != NONE) {
          string msg = "Output written to ";
          msg += registry.GetUserParameters().GetResultsFileName();
          runreport.ReportUrgent(msg);
          if (registry.GetUserParameters().GetWriteSumFile()) {
        msg = "Output summary file written to ";
        msg += registry.GetUserParameters().GetTreeSumOutFileName();
        runreport.ReportUrgent(msg);
          }
          StringVec1d curvefilenames = registry.GetUserParameters().GetCurveFileNames();
          if (curvefilenames.size() > 0) {
            //LS NOTE: not GetWriteCurveFiles() because if not bayesian, that
            // parameter is meaningless.  This version is much safer.
            msg = "Wrote to curve file(s):  " + curvefilenames[0];
            for (unsigned long i=1; i<curvefilenames.size(); i++) {
              msg += ", " + curvefilenames[i];
            }
            runreport.ReportUrgent(msg);
          }
          set<string> tracefilenames = registry.GetUserParameters().GetTraceFileNames();
          if (tracefilenames.size() > 0) {
            msg = "Wrote to Tracer file(s):";
            set<string>::iterator tname = tracefilenames.begin();
            msg += " " + *tname;
            for (tname++; tname != tracefilenames.end(); tname++) {
              msg += ", " + *tname;;
            }
            runreport.ReportUrgent(msg);
          }
          runreport.ReportUrgent("\nProgram completed.", 0);
          runreport.ReportUrgent("You may now exit manually if we haven't already exited automatically.", 0);
          runreport.ReportUrgent("In either case, you may now examine your results.", 0);
          runreport.ReportUrgent("For assistance interpreting your results, see http://evolution.gs.washington.edu/lamarc/documentation/ (or your local copy of the documentation).", 0);
        }
    }
  }

  catch (bad_alloc) {
    cerr << endl << endl
         << "LAMARC has terminated because an insufficient amount of memory"
	 << endl
         << "is available.  If you are running additional programs"
         << endl
         << "simultaneously on your computer, try terminating them and"
         << endl
         << "re-executing LAMARC.  Or, try running LAMARC on a different"
         << endl << "computer that has more memory available."
         << endl << endl;
    return_code = return_code | lamarccodes::badAllocation;
  }

  catch(const unrecognized_tag_error & e)
  {
    cerr <<  xmlstr::XML_IERR_NO_TAG_0
                                + e.what()
                                + xmlstr::XML_IERR_NO_TAG_1
                                + ToString(e.where())
                                + xmlstr::XML_IERR_NO_TAG_2
        << std::endl ;
    return_code = return_code | lamarccodes::fileError;
  }

  catch (exception& ex) {
    cerr << ex.what() << endl;
    return_code = return_code | lamarccodes::unknownError;
  }

// needed for any clickable executables
#if defined(LAMARC_COMPILE_MSWINDOWS) || defined(LAMARC_COMPILE_MACOSX)
  cout << "Press Enter to Quit" << endl;
  std::string dummyString;
  MyCinGetline(dummyString);
#endif

  return return_code;

} /* LAMARC main routine */

void CatchFileTooBigSignal(int signal)
{
  //The kernel has sent a signal that the file size limit has been exceeded.
  //We're going to assume that this was for the summary file writing, since
  // that's the biggest
  // Stop writing to the summary file.
  registry.GetRunReport().ReportUrgent("File size exceeded for summary file writing--continuing, but without writing to the summary file any more.  Try the command 'unlimit filesize' if on a UNIX system.");
  longjmp(prewrite, 1);
  //We set this jumppoint in ChainManager at a point where we can close
  // the summary file and stop writing to it.
}

