// $Id: chainmanager.h,v 1.48 2007/02/01 19:19:49 lpsmith Exp $
/* 
   Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
   
   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

// The ChainManager is one of the big persistent objects in Lamarc.  It
// is expected to exist from the end of the intial factory phase til
// after the last output report is displayed to the user.
//
// The ChainManager is primarily responsible for providing runtime user
// output (through a RunReport), for managing the interface between the
// posterior likelihood calculator/maximizer and the running chains,
// and for providing end of program user output (through an
// OutputFile).  It is also responsible for taking the user's input
// on chain length and refactoring it for use by its stable of Chains.
//
// It owns the 2 big collections of chain output: the ChainPack, which
// goes to user output; and a collection manager that is
// utilized by the posterior likelihood calculator.

#ifndef CHAINMAN_H
#define CHAINMAN_H

#include <vector>
#include "chainpack.h"
#include "collector.h"
#include "collmanager.h"
#include "constants.h"
#include "sumfilehandler.h"
#include "vectorx.h"

class BayesAnalyzer_1D;
class Random;
class RunReport;
class ChainParameters;
class Chain;
class Maximizer;

class ChainManager
{
public:
  ChainManager(RunReport& runrep, Maximizer& maximize);
  ~ChainManager();
  void Do();

private:
  ChainManager();                                   // undefined
  ChainManager(const ChainManager& src);            // undefined
  ChainManager& operator=(const ChainManager& src); // undefined

  const ChainParameters& m_chainparam;
  RunReport& m_runreport;
  Random& m_randomsource;
  Maximizer& m_maximizer;
  BayesAnalyzer_1D& m_bayesanalyzer;
  ChainPack m_chainpack;
  long m_nregions, m_nreplicates;
  CollectionManager m_collectionmanager;
  SumFileHandler m_sumfilehandler;

  bool m_multitemp;
  LongVec1d m_nsteps;            // dim: chaintype
  LongVec2d m_chunksize;         // dim: chaintype X chunk
  std::vector<Chain> m_temps;         // dim: temperatures
  long m_totalsteps, m_currentsteps; // used for completion-time prognosis

  DoubleVec2d m_logGeyerWeights;

  bool m_writesumfile;
  bool m_readsumfile;
  // true if in the process of reading or writing tree summaries to a file.

  bool m_recoversumfile;  //true if picking up in the middle
  long m_recover_region;
  long m_recover_replicate;
  long m_recover_chaintype;
  long m_recover_chain;   // All recover_* variables are indices, not counters.
  bool m_recover_redochain;
  bool m_recover_redomaximization;
  bool m_redoreplicatesum;
  bool m_redoregionsum;

  vector<Tree*> m_regiontrees;  // the trees for the various temperature chains

  void ReadInRecover();
  void SetRecoverChaintypeChainsFrom(long last_chain);
  void TellUserWhereWeAreRestarting();
  void CreateChains();
  void DoRegions();
  void CalculateMLEsOverRegions();
  void CalculateNonBayesMultiRegionMLEs(ForceParameters& fp,
                                        ChainOut& regionout, double& maxlike);
  void DoReplicates(long region);
  void DoChainTypes(long region, long rep);
  // the following handles maximization on a stored-tree chain
  void DoChainFromSummaryFile(long region, long rep, long chaintype,
			      long chain);
  void DoChain(long region, long rep, long chaintype, long chain,
	       ForceParameters& chainstart);
  void GroomTrees(ForceParameters& chainstart);
  unsigned long FindColdChain(const vector<Chain>& chains) const;
  void DoSingleChainPosterior(long region, long rep, long chaintype,
			      long chain, ChainOut& chout,
			      ForceParameters& chainstart);
  void DoSingleChainBayes(long region, long rep, ChainOut& chout,
			  ForceParameters& chainstart);


  // Adjust temperatures for adaptive heating
  void AdjustTemperatures(DoubleVec1d & averagetemps, long step, double& howoften);
  void ChooseTwoAdjacentChains(unsigned long& chain1, unsigned long& chain2);
  std::vector<std::pair<double, long> > SortChainsByTemperature(const
    vector<Chain>& temps);

  void ReadInNoRedoMax(long region);
  void RedoMaximization(long region);
  void CompareAndWarn(ForceParameters calcfp, ForceParameters readfp);
  void DoOverallProfiles();
  void CloseSumOut();
  void SaveGeyerWeights(DoubleVec1d logGeyerWeights, long region);
  void OptimizeDataModels(long reg);
  void ResetAllAlphas();

};

#endif /* CHAINMAN_H */
