//$Id: userparam.h,v 1.29 2007/08/03 20:44:46 lpsmith Exp $

#ifndef USERPARAMETERS_H
#define USERPARAMETERS_H

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************** 
 UserParameters is a collection class used for internal communication
 throughout Lamarc.

 UserParameters is a grab-bag of information provided by the user that
 doesn't seem to belong anywhere else, including file names and
 output format options, and the random number seed.

 Copy semantics are provided for menu roll-back purposes; otherwise
 there should only be one copy, registered in Registry.

 Written by Jim Sloan, revised by Mary Kuhner

********************************************************************/

#include "constants.h"
#include <string>
#include <vector>
#include <set>

class Registry;

class UserParameters
{
  private:

    const std::string m_curvefileprefix;
    const std::string m_tracefileprefix;
    const std::string m_newicktreefileprefix;
    std::string m_datafilename;
    std::string m_resultsfilename;
    std::string m_treesuminfilename;
    std::string m_treesumoutfilename;
    std::string m_xmloutfilename;

    verbosity_type   m_verbosity;
    verbosity_type   m_progress;
    bool   m_plotPost;
    bool   m_usesystemclock;
    bool   m_readsumfile;   // if true read in tree summaries from a file
    bool   m_writesumfile;  // if true write tree summaries to file.
                          // Note:  Both could be 'true'; reading
                          //  and writing to a file.
    bool   m_writecurvefiles;
    bool   m_writetracefiles; // if true write Tracer output to file.
                             // JDEBUG--currently only works for
			     // Bayesian runs
    bool   m_writenewicktreefiles;
    long   m_randomSeed;

    time_t m_programstarttime;

  //LS DEBUG:  The following member variables are being stored here for now,
  // but should eventually move to an 'output manager' of some sort.
  std::vector<std::string> m_curvefilenames;
  std::set<std::string> m_tracefilenames;
  std::set<std::string> m_newicktreefilenames;
  std::string m_currentTraceFileName;
  std::string m_currentNewickTreeFileName;
  double m_currentBestLike;
  long m_currentStep;


                    UserParameters();       // undefined
  public:
    UserParameters( 
                    std::string curvefileprefix,
                    std::string tracefileprefix,
                    std::string newicktreefileprefix,
                    std::string datafilename,
                    std::string resultsfilename,
                    std::string treesuminfilename,
                    std::string treesumoutfilename,
                    std::string xmloutfilename,
                    verbosity_type   verbosity,
                    verbosity_type   progress,
                    bool   plotPost,
                    bool   usesystemclock,
                    bool   readsumfile,
                    bool   writesumfile,
                    bool   writecurvefiles,
		    bool   writetracefile,
		    bool   writenewicktreefile,
                    long   randomSeed,
                    time_t programstarttime
    );
    ~UserParameters() {};
    // accepting default copy constructor and assignment operator

    
    // Get Functions
    std::vector < std::string > ToXML(unsigned long nspaces) const;

    std::string GetCurveFilePrefix()     const { return m_curvefileprefix; };
    std::string GetTraceFilePrefix()     const { return m_tracefileprefix; };
    std::string GetNewickTreeFilePrefix()const {return m_newicktreefileprefix;};
    std::string GetDataFileName()        const { return m_datafilename; };
    std::string GetResultsFileName()     const { return m_resultsfilename; };
    std::string GetTreeSumInFileName()   const { return m_treesuminfilename; };
    std::string GetTreeSumOutFileName()  const { return m_treesumoutfilename; };
    std::string GetXMLOutFileName()      const { return m_xmloutfilename; };
    std::vector<std::string> GetCurveFileNames() const { return m_curvefilenames; };
    std::set<std::string> GetTraceFileNames() const { return m_tracefilenames; };
    std::set<std::string> GetNewickTreeFileNames() const { return m_newicktreefilenames; };
  

    verbosity_type   GetVerbosity() const { return m_verbosity; };
    verbosity_type   GetProgress()  const { return m_progress; };
    bool   GetPlotPost()            const { return m_plotPost; };
    bool   GetReadSumFile()         const { return m_readsumfile; };
    bool   GetWriteSumFile()        const { return m_writesumfile; };
    bool   GetWriteCurveFiles()     const { return m_writecurvefiles; };
    bool   GetWriteTraceFiles()     const { return m_writetracefiles; };
    bool   GetWriteNewickTreeFiles()const { return m_writenewicktreefiles; };
    bool   GetUseSystemClock()      const { return m_usesystemclock; };

    long   GetRandomSeed()          const { return m_randomSeed; };
    time_t GetProgramStartTime()    const { return m_programstarttime; };


    // These Set methods are public because lamarc may have to set them
    // to "false" if an error occurs. This makes them not quite "user"
    // parameters, but it is the best place for this logic.
    void   SetWriteSumFile  (const bool a)     { m_writesumfile = a; };
    void   SetReadSumFile   (const bool a)     { m_readsumfile  = a; };

  //LS DEBUG:  These are the functions that would need to move to an output
  // manager if we make one:
  void AddCurveFileName (const std::string name);
  void AddTraceFileName (const std::string name);
  void AddNewickTreeFileName (const std::string name);
  void UpdateFileNamesAndSteps(long region, long replicate, bool readsumfile);
  void UpdateWriteTraceFile(long region, long replicate);
  string GetCurrentTraceFileName() {return m_currentTraceFileName;};
  string GetCurrentNewickTreeFileName() {return m_currentNewickTreeFileName;};
  double GetCurrentBestLike() {return m_currentBestLike;};
  void SetCurrentBestLike(double like) {m_currentBestLike = like;};
  void ClearCurrentBestLike() {m_currentBestLike = -DBL_MAX;};
  long GetNextStep();
};

#endif /* USERPARAMETERS_H */

