//$Id: lamarc.h,v 1.17 2005/06/14 21:21:37 jay Exp $
#ifndef LAMARC_H
#define LAMARC_H
/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/***************************************************************
 This file (not a class at this time) contains the main driver
 routines for LAMARC.  It does the following:

 (1) Set up registry (main)
 (2) Accept user input (DoUserInput)
 (3) Finalize registry (FinishRegistry)
 (4) Launch chain manager (main)

 Mary Kuhner (based on work by Jon Yamato) April 2001
***************************************************************/

#include <setjmp.h>
#include <vector>

class UIInterface;

bool DoUserInput(long argc, char** argv);
void FinishRegistry(UIInterface&);
void CatchFileTooBigSignal(int signal);
int main(long, char **);


#endif /* LAMARC_H */
