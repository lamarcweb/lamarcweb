// $Id: sumfilehandler.h,v 1.5 2005/10/13 19:22:53 lpsmith Exp $
/* 
   Copyright 2005 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
   
   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/


// The Sumfile Handler is here to handle reading and writing of summary files.
// Earlier versions of the functions here can be found in chainmanager directly,
// since it was pulled out of there due to this sort of thing taking up too
// much space.

// In general, it is owned by and called from the chainmanager object, and
// modifies (by reference) other chainmanager member variables when called
// upon to read a summary file, and reads (by reference) other chainmanager
// member variables when called upon to write a summary file.

#ifndef SUMFILEHANDLER_H
#define SUMFILEHANDLER_H

#include <fstream>
#include "vectorx.h"

class ForceParameters;
class ChainOut;
class ChainPack;
class CollectionManager;

class SumFileHandler
{
private:
  std::ifstream m_sumin;	// use when reading from a summary file
  std::ofstream m_sumout;	// use when writing to a summary file

  long m_lastRegion;
  long m_lastReplicate;
  long m_lastChain;
  long m_lastRegionChainSum;
  long m_lastReplicateChainSum;
  long m_lastReplicateSummary;
  bool m_regionSummary;

public:
  SumFileHandler();
  ~SumFileHandler() {};
  SumFileHandler(const SumFileHandler& src);            // undefined
  SumFileHandler& operator=(const SumFileHandler& src); // undefined

  long GetLastRegion() {return m_lastRegion;};
  long GetLastReplicate() {return m_lastReplicate;};
  long GetLastChain() {return m_lastChain;};
  long GetLastRegionChainSum() {return m_lastRegionChainSum;};
  long GetLastReplicateChainSum() {return m_lastReplicateChainSum;};
  long GetLastReplicateSummary() {return m_lastReplicateSummary;};
  bool GetRegionSummary() {return m_regionSummary;};

  
  void ReadInChainPack		(ChainPack& chainpack);
  void ReadInChainSum		(ChainPack& chainpack,
                                 CollectionManager& collectionmanager,
                                 long numchains);
  void SkipComments   		();
  void ReadInChainOut 		(ChainOut &c );
  void ReadInSumFile		(ChainPack& chainpack,
                                 CollectionManager& collectionmanager,
                                 long numchains);
  void ReadInReplicateSummary	(ChainPack& chainpack);
  void ReadInRegionSummary	(ChainPack& chainpack);
  bool ReadInVec1D	        (DoubleVec1d& vd, string endtag );
  bool ReadInVec1D	        (LongVec1d& vd, string endtag );
  void ReadInEndRegion		(ChainPack& chainpack);
  void ReadInRecover		(ChainPack& chainpack);
  // public only so TreeSummary::ReadInTreeSummary() can use, change if merge
  void ReadInForceParameters    (ForceParameters& fp );
  static void HandleSumOutFileFormatError( string callingfxn );
  static void ReadInCheckFileFormat( string callingfxn, string expectedtag, string readtag );
  
  void WriteSumFileStart	();
  void WriteSumFileEnd		(const ChainPack& chainpack);
  void WriteChainSumStart	(long int whichregion, long int whichreplicate,
                                 const CollectionManager& collectionmanager);
  void WriteChainSumEnd		(const CollectionManager& collectionmanager);
  void WriteChainPack		(ChainOut& chainout,const ChainPack& chainpack);
  void WriteLastChain           (const ChainPack& chainpack);
  void WriteRegionSummary	(ForceParameters& fp, double maxlike);
  void WriteReplicateSummary	(ForceParameters& fp, double maxlike,
                                 const ChainPack& chainpack);
  void WriteWhatWasRead 	(bool recoversumfile,
                                 long recover_region,
                                 long recover_replicate,
                                 long recover_chaintype,
                                 long recover_chain,
                                 bool recover_redochain,
                                 bool recover_redomaximization,
                                 long nregions,
                                 long nreplicates,
                                 const ChainPack& chainpack,
                                 const CollectionManager& collectionmanager);
  static void WriteVec1D ( std::ofstream& out, vector<double>& vd );
  static void WriteVec1D ( std::ofstream& out, vector<long>& vd );
  void CloseSumOut();

};

#endif /* SUMFILEHANDLER_H */
