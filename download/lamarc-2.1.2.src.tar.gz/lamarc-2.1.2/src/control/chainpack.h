// $Id: chainpack.h,v 1.21 2006/04/14 18:24:35 lpsmith Exp $

#ifndef CHAINPACK_H
#define CHAINPACK_H

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <fstream>
#include <vector>
#include "vectorx.h"
#include <algorithm>
#include "chainout.h"
#include "constants.h"
#include "definitions.h"

/************************************************************************
 This class collects ChainOut objects containing the results of all
 chains, as well as a summary for each region and an overall summary.
 It is filled by the chain manager and used by the output report.

 It implements the following rules:  

 If only one replicate was run, the regional result is the result 
 from its last chain.  If multiple replicates were run, there is a 
 separate regional result summing all replicates.

 If only one region was run, the overall result is the result from
 that region.  If multiple regions were run, there is a separate
 overall result summing all regions.

 ChainPack adds timestamps to each summary object indicating the
 times of the chains which it summarizes.  The calling program does
 not need to set timestamps on the summaries, but it does need to set
 timestamps on the individual chain objects.

 DEBUG There is currently a logic problem involving summary times when there
 is only one region.

 (MDEBUG:  Mary looked at this 3/23/2005.  The class is badly designed
 and should be redesigned so that the regional and overall results always
 exist (removes a lot of nasty special case code and kills the logic
 bug) but this is a fairly large refactoring and is being deferred till
 after 2.0.)

 While it is being filled up by the chain manager, the ChainPack
 is in an inconsistent state (for example, it may have two regions
 but no overall summary) and should generally not be touched by
 anyone else.

 Written by:  Mary Kuhner September 2000
*************************************************************************/

class ChainPack {

private:
ChainPack& operator=(const ChainPack&);        // deliberately not defined
ChainPack(const ChainPack &src);               // deliberately not defined

vector<vector<vector<ChainOut> > >  chains;    // output of each chain
                                               // dim: reg X rep X cha
vector<ChainOut>                    regions;   // summed over reps 
                                               // dim: reg
vector<ChainOut>                    overall;   // summed over regions
                                               // dim: really a scalar but kept
                                               // as a vector for convenience
long currentChain;
long currentRep;
long currentRegion;

long        RegionsSoFar()   const   {return(static_cast<long>(chains.size()));};
DoubleVec1d CalcMean(const DoubleVec2d& src)  const;

public:

ChainPack() : currentChain(0), currentRep(0), currentRegion(0) {};
~ChainPack() {};

// Inspector functions
ChainOut  GetChain(long region, long rep, long chain) const;
ChainOut  GetLastChain()                              const;
ChainOut  GetLastChain(long region)                   const;
ChainOut  GetRegion(long region)                      const;
ChainOut  GetOverall()                                const;
long      GetLenRegionsVec()                          const;
long      GetLenOverallVec()                          const;
time_t    GetStartTime()                              const;
time_t    GetStartTime(long region)                   const;
time_t    GetEndTime()                                const;
DoubleVec1d   RegionalMeanParams()                    const;
DoubleVec1d   OverallMeanParams()                     const;

vector<vector<vector<ChainOut > > > GetAllChains()    const;

  // Mutator functions
  // These change their arguments--do not make the arguments const!
  void SetChain(ChainOut& chout, long region, long rep, long chain);
  void SetChain(ChainOut& chout);
  void ResetLastChain(ChainOut& chout, long region);
  void RemoveLastChain();
  void SetSummaryOverReps(ChainOut& chout);
  void ResetSummaryOverReps(ChainOut& chout, long region);
  void SetSummaryOverRegions(ChainOut& chout);

  void EndReplicate() { ++currentRep; currentChain = 0; };
  void EndRegion()    { ++currentRegion; currentRep = 0; currentChain = 0;};
  void EndRegionIfNecessary(long region);
  void EndRegionsOrRepsAsNeeded(long maxreps, long maxchains);
  
  //Summary file functions to write out chain info
  void WriteLastChain 	( std::ofstream& out ) const ;
  void WriteChain	( std::ofstream& out, long, long, long ) const;
  void WriteChainOut  	( std::ofstream& out, const ChainOut& chout) const;
  void WriteForceParameters ( std::ofstream& out, const ForceParameters& fp ) const;
  void WriteAlphas(std::ofstream& sumout, long reg, long rep, long chain) const;

//Function to test whether we're assembling correctly.
  void VerifyPosition	( long test_reg, long test_rep, long test_chain) ;
};

#endif /* CHAINPACK_H */
