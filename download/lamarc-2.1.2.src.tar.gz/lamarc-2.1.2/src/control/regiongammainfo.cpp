// $Id: regiongammainfo.cpp,v 1.5 2007/02/14 01:38:00 erynes Exp $
   
/*
  Copyright 2002  Mary Kuhner, Jon Yamato, Eric Rynes and Joseph Felsenstein
  
  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "regiongammainfo.h"
#include "force.h"
#include "stringx.h"
#include "xml_strings.h"

RegionGammaInfo::RegionGammaInfo(double startValue, paramstatus paramStatus,
                                 bool doProfile, proftype profType,
                                 std::string profTypeSummaryDescription,
                                 RegionGammaForce *pRegionGammaForce)
  : m_startValue(startValue),
    m_paramstatus(paramStatus),
    m_doProfile(doProfile), 
    m_proftype(profType),
    m_proftypeSummaryDescription(profTypeSummaryDescription),  
    m_CurrentlyPerformingAnalysisOverRegions(false),
    m_HaveMLE(false), 
    m_HaveProfile(false), 
    m_pRegionGammaForce(pRegionGammaForce)
{
}


RegionGammaInfo::~RegionGammaInfo()
{
  delete m_pRegionGammaForce;
}

proftype RegionGammaInfo::GetProfType(void) const
{
  if (m_doProfile) {
    return m_proftype;
  }
  return profile_NONE;
}

double RegionGammaInfo::GetLowValue(void) const
{
  if (!m_pRegionGammaForce)
    throw implementation_error("RegionGammaInfo is missing m_pRegionGammaForce");
  return m_pRegionGammaForce->GetLowVal();
}

double RegionGammaInfo::GetHighValue(void) const
{ 
  if (!m_pRegionGammaForce)
    throw implementation_error("RegionGammaInfo is missing m_pRegionGammaForce");
  return m_pRegionGammaForce->GetHighVal();
}

double RegionGammaInfo::GetLowMultiplier(void) const
{
  if (!m_pRegionGammaForce)
    throw implementation_error("RegionGammaInfo is missing m_pRegionGammaForce");
  return m_pRegionGammaForce->GetLowMult();
}

double RegionGammaInfo::GetHighMultiplier(void) const
{
  if (!m_pRegionGammaForce)
    throw implementation_error("RegionGammaInfo is missing m_pRegionGammaForce");
  return m_pRegionGammaForce->GetHighMult();
}

double RegionGammaInfo::GetMaxValue(void) const
{ 
  if (!m_pRegionGammaForce)
    throw implementation_error("RegionGammaInfo is missing m_pRegionGammaForce");
  return m_pRegionGammaForce->GetMaximizerMaxVal();
}

double RegionGammaInfo::GetMinValue(void) const
{ 
  if (!m_pRegionGammaForce)
    throw implementation_error("RegionGammaInfo is missing m_pRegionGammaForce");
  return m_pRegionGammaForce->GetMaximizerMinVal();
}

void RegionGammaInfo::ConstrainToMax()
{
  if (m_paramstatus==pstat_constant) {
    assert(false);
    throw implementation_error("Tried to constrain alpha to its maximum value when it was already constrained.");
  }
  m_paramstatus = pstat_constant;
  m_doProfile = false;
  m_HaveProfile = false; // possibly unnecessary
  m_startValue = GetMaxValue();
}

StringVec1d RegionGammaInfo::ToXML(long nspaces) const
{
  StringVec1d xmllines;   
  string line = MakeIndent(MakeTag(xmlstr::XML_TAG_REGION_GAMMA),nspaces); 
  xmllines.push_back(line);
       
  nspaces += INDENT_DEPTH;
  string mytag(MakeTag(xmlstr::XML_TAG_START_VALUES));
  DoubleVec1d startvalues;
  startvalues.push_back(m_startValue);
  line = MakeIndent(mytag,nspaces) + ToString(startvalues,5) 
    + " " + MakeCloseTag(mytag);
  xmllines.push_back(line);

  mytag = MakeTag(xmlstr::XML_TAG_PROFILES);
  string profile_st;
  if (m_doProfile) {
    profile_st = ToString(m_proftype);
  }
  else {
    profile_st = ToString(profile_NONE);
  }
  line = MakeIndent(mytag,nspaces) + " " + profile_st 
    + " " + MakeCloseTag(mytag);
  xmllines.push_back(line);

  mytag = MakeTag(xmlstr::XML_TAG_CONSTRAINTS);
  line = MakeIndent(mytag,nspaces) + " " + ToString(m_paramstatus) 
    + " " + MakeCloseTag(mytag);
  xmllines.push_back(line);
  
  //The gamma doesn't have groups or a prior.  Change this if we give it some!

  nspaces -= INDENT_DEPTH;
  line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_REGION_GAMMA),nspaces);
  xmllines.push_back(line);
  return xmllines;

}
