// $Id: userparam.cpp,v 1.37 2007/09/24 22:38:45 lpsmith Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "errhandling.h"
#include "force.h"
#include "region.h"
#include "registry.h"
#include "stringx.h"
#include "timex.h"
#include "userparam.h"
#include "xml_strings.h"  // for ToXML()

#include <fstream>

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using std::string;
using std::vector;

//___________________________________________________________________________
//___________________________________________________________________________

UserParameters::UserParameters( 
                    string curvefileprefix,
                    string tracefileprefix,
                    string newicktreefileprefix,
                    string datafilename,
                    string resultsfilename,
                    string treesuminfilename,
                    string treesumoutfilename,
                    string xmloutfilename,
                    verbosity_type   verbosity,
                    verbosity_type   progress,
                    bool   plotPost,
                    bool   usesystemclock,
                    bool   readsumfile,
                    bool   writesumfile,
                    bool   writecurvefiles,
		    bool   writetracefiles,
		    bool   writenewicktreefiles,
                    long   randomSeed,
                    time_t programstarttime)
    :
                    m_curvefileprefix(curvefileprefix),
                    m_tracefileprefix(tracefileprefix),
                    m_newicktreefileprefix(newicktreefileprefix),
                    m_datafilename(datafilename),
                    m_resultsfilename(resultsfilename),
                    m_treesuminfilename(treesuminfilename),
                    m_treesumoutfilename(treesumoutfilename),
                    m_xmloutfilename(xmloutfilename),
                    m_verbosity(verbosity),
                    m_progress(progress),
                    m_plotPost(plotPost),
                    m_usesystemclock(usesystemclock),
                    m_readsumfile(readsumfile),
                    m_writesumfile(writesumfile),
                    m_writecurvefiles(writecurvefiles),
		    m_writetracefiles(writetracefiles),
		    m_writenewicktreefiles(writenewicktreefiles),
                    m_randomSeed(randomSeed),
                    m_programstarttime(programstarttime)
{
  // we establish defaults for the user parameters here.
  // they can be overriden both by the data file and by
  // the menu.

  //LS DEBUG:  move to the output manager when one exists.
  string regionname = registry.GetDataPack().GetRegion(0).GetRegionName();
  regionname = SpacesToUnderscores(regionname);
  m_currentTraceFileName = m_tracefileprefix + "_" + regionname + "_0.txt";
  m_currentNewickTreeFileName = m_newicktreefileprefix + "_"
    + regionname + ".txt";
  m_currentBestLike = -DBL_MAX;
  m_currentStep = 0;
}

//____________________________________________________________________________

StringVec1d UserParameters::ToXML(unsigned long nspaces) const
{
  StringVec1d xmllines;
  string line = MakeIndent(MakeTag(xmlstr::XML_TAG_FORMAT),nspaces);
  xmllines.push_back(line);

  nspaces += INDENT_DEPTH;

  string mytag;

  mytag = MakeTag(xmlstr::XML_TAG_CONVERT_OUTPUT);
  line = MakeIndent(mytag, nspaces) + " "
   + ToString(registry.GetConvertOutputToEliminateZeroes()) + " "
   + MakeCloseTag(mytag);
  xmllines.push_back(line);

  mytag = MakeTag(xmlstr::XML_TAG_SEED);
  if (!GetUseSystemClock()) {
    line = MakeIndent(mytag,nspaces) + ToString(GetRandomSeed()) + MakeCloseTag(mytag);
    xmllines.push_back(line);
  } 
  mytag = MakeTag(xmlstr::XML_TAG_VERBOSITY);
  line = MakeIndent(mytag,nspaces) + ToString(GetVerbosity()) + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_PROGRESS_REPORTS);
  line = MakeIndent(mytag,nspaces) + ToString(GetProgress()) + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_RESULTS_FILE);
  line = MakeIndent(mytag,nspaces) + GetResultsFileName() + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_USE_IN_SUMMARY);
  line = MakeIndent(mytag,nspaces) + ToStringTF(GetReadSumFile()) + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_IN_SUMMARY_FILE);
  line = MakeIndent(mytag,nspaces) + GetTreeSumInFileName() + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_USE_OUT_SUMMARY);
  line = MakeIndent(mytag,nspaces) + ToStringTF(GetWriteSumFile()) + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_OUT_SUMMARY_FILE);
  line = MakeIndent(mytag,nspaces) + GetTreeSumOutFileName() + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_USE_CURVEFILES);
  line = MakeIndent(mytag,nspaces) + ToStringTF(GetWriteCurveFiles()) + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_CURVEFILE_PREFIX);
  line = MakeIndent(mytag,nspaces) + GetCurveFilePrefix() + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_USE_TRACEFILE);
  line = MakeIndent(mytag,nspaces) + ToStringTF(GetWriteTraceFiles())
    + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_TRACEFILE_PREFIX);
  line = MakeIndent(mytag,nspaces) + GetTraceFilePrefix() + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_USE_NEWICKTREEFILE);
  line = MakeIndent(mytag,nspaces) + ToStringTF(GetWriteNewickTreeFiles())
    + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_NEWICKTREEFILE_PREFIX);
  line = MakeIndent(mytag,nspaces) + GetNewickTreeFilePrefix()
    + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_OUT_XML_FILE);
  line = MakeIndent(mytag,nspaces) + GetXMLOutFileName() + MakeCloseTag(mytag);
  xmllines.push_back(line);
  nspaces -= INDENT_DEPTH;

  line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_FORMAT),nspaces);
  xmllines.push_back(line);

  return xmllines;
} /* ToXML */

void UserParameters::UpdateFileNamesAndSteps(long region, long replicate,
                                             bool readsumfile)
{
  string regionname = registry.GetDataPack().GetRegion(region).GetRegionName();
  regionname = SpacesToUnderscores(regionname);
  m_currentTraceFileName = m_tracefileprefix + "_" + regionname + "_"
    + ToString(replicate+1) + ".txt";
  m_currentNewickTreeFileName = m_newicktreefileprefix + "_"
    + regionname + ".txt";
  m_currentStep = 0;
  //If we're in a non-bayesian run, and if we're collecting tracer data, we
  // need to start things off here.
  //
  // Er, this is ugly design.  LS DEBUG

  //Note:  Below are the headers for the tracer file; the contents are
  // written in CollectionManager::WriteTraceFile(...) in collmanager.cpp
  if (GetWriteTraceFiles() && !readsumfile) {
    std::ofstream tracefile;
    tracefile.open(m_currentTraceFileName.c_str(),std::ios::trunc);
    tracefile << "Step\tLn(Data Likelihood)";
    if (registry.GetChainParameters().IsBayesian()) {
      const vector<Force*>& forces = registry.GetForceSummary().GetAllForces();
      vector<Force*>::const_iterator force;
      for (force = forces.begin(); force != forces.end(); ++force) {
        vector<string> paramnames = (*force)->GetAllParamNames();
        vector<string>::iterator name;
        for (name = paramnames.begin(); name != paramnames.end(); ++name) {
          if (!(*name).empty()) {
            tracefile << "\t" << *name;
          }
        }
      }
    }
    tracefile << std::endl;
    tracefile.close();
    AddTraceFileName(m_currentTraceFileName);
  }
}

void UserParameters::UpdateWriteTraceFile(long region, long replicate)
{
  //m_currentTraceFileName should be accurate.  We should not have written
  // to it during this run of LAMARC, but we might have written to it
  // during the previous run.  If so, we'll just append.  If not, we'll
  // create a new file by calling UpdateFileNamesAndSteps.
  std::ifstream tracefile;
  tracefile.open(m_currentTraceFileName.c_str(), std::ios::in );
  if (!tracefile) {
    UpdateFileNamesAndSteps(region, replicate, false);
  }
}

long UserParameters::GetNextStep()
{
  m_currentStep += registry.GetChainParameters().GetInterval(defaults::final);
  return m_currentStep;
}

void UserParameters::AddCurveFileName (const std::string name)
{
  m_curvefilenames.push_back(name);
}

void UserParameters::AddTraceFileName (const std::string name)
{
  m_tracefilenames.insert(name);
}

void UserParameters::AddNewickTreeFileName (const std::string name)
{
  m_newicktreefilenames.insert(name);
}
