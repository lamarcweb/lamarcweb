//$Id: chainpack.cpp,v 1.28 2007/09/11 17:48:42 lpsmith Exp $

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <cstdlib>
#include "chainpack.h"
#include "constants.h"
#include "region.h"
#include "registry.h"
#include "stringx.h"
#include "sumfilehandler.h"
#include "xmlsum_strings.h"  // for xml sumfile handling

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//______________________________________________________________

ChainOut ChainPack::GetChain(long region, long rep, long chain) const {
  return(chains[region][rep][chain]);
} /* ChainPack::GetChain */

//______________________________________________________________

ChainOut ChainPack::GetLastChain() const {
  long region = chains.size()-1;
  if (region != -1) {
    long rep    = chains[region].size()-1;
    if (rep != -1) {
      long chain  = chains[region][rep].size()-1;
      if (chain != -1) {
        return(chains[region][rep][chain]);
      }
    }
  }
  //There was no last chain
  ChainOut blankchout;
  if (region == -1) region = 0;
  ForceParameters fp(registry.GetForceSummary().GetStartParameters(), region);
  blankchout.SetEstimates(fp);
  return blankchout;

} /* ChainPack::GetLastChain */

ChainOut ChainPack::GetLastChain(long region) const {
  assert(region <= static_cast<long>(chains.size()));
  assert(chains[region].size() > 0);
  unsigned long rep = chains[region].size()-1;
  assert(chains[region][rep].size() > 0);
  unsigned long chain = chains[region][rep].size() - 1;
  return(chains[region][rep][chain]);
} /* ChainPack::GetLastChain */

//______________________________________________________________

ChainOut ChainPack::GetRegion(long region) const {
  if (regions.size() == 0) {                 // no sum over replicates
    long last = (chains[region][0].size())-1;
    return(this->GetChain(region, 0, last));
  } else {
    return(regions[region]);
  }
} /* ChainPack::GetRegion */

//______________________________________________________________

ChainOut ChainPack::GetOverall() const {
  if (overall.size() == 0) {                // no sum over regions
     return(this->GetRegion(0));
  } else {
     return(overall[0]);
  }
} /* ChainPack::GetOverall */

//______________________________________________________________

// Two functions for the summary file reader to make sure the
//  region/replicate summaries are being set.
long ChainPack::GetLenRegionsVec() const {
  return (regions.size());
}

long ChainPack::GetLenOverallVec() const {
  return (overall.size());
}

//______________________________________________________________

void ChainPack::SetChain(ChainOut& chout, long region, long rep, long chain)
{
  if (region > currentRegion) {
    EndRegion();
    VerifyPosition(region, rep, chain);
    SetChain(chout);
    return;
  }
  if (rep > currentRep) {
    EndReplicate();
    VerifyPosition(region, rep, chain);
    SetChain(chout);
    return;
  }
  VerifyPosition(region, rep, chain);
  SetChain(chout);
}

void ChainPack::ResetLastChain(ChainOut& chout, long region)
{
  long rep = chains[region].size()-1;
  long chain = chains[region].size()-1;
  assert (rep >= 0);
  assert (chain >= 0);
  chains[region][rep][chain] = chout;
}

void ChainPack::ResetSummaryOverReps(ChainOut& chout, long region)
{
  assert(region <= static_cast<long>(regions.size()));
  regions[region] = chout;
}

void ChainPack::SetChain(ChainOut& chout) {

  // The estimates in chout might not have known what region they were for.
  // If that's the case, this will set it straight.
  ForceParameters fp(chout.GetEstimates(), currentRegion);
  chout.SetEstimates(fp);

  if (currentRep == 0 && currentChain == 0) { // first entry of its region
    vector<ChainOut> v1;
    v1.push_back(chout);
    vector<vector<ChainOut> > v2;
    v2.push_back(v1);
    chains.push_back(v2);
    currentChain++;
    return;
  }
  if (currentChain == 0) {                   // first entry of its replicate
    vector<ChainOut> v1;
    v1.push_back(chout);
    chains[currentRegion].push_back(v1);
    currentChain++;
    return;
  }

  chains[currentRegion][currentRep].push_back(chout);
  currentChain++;
  
} /* ChainPack::SetChain */

//______________________________________________________________

// RemoveLastChain is needed by ChainManager in the unlikely event that
//  we have read in chain summary information for the last chain in a
//  region/replicate, but have no tree summary information, and thus
//  need to reproduce that tree, giving us a new chain.
//                 --Lucian
void ChainPack::RemoveLastChain() {
  if (currentChain == 0) {
    //We called EndRegion and/or EndReplicate too early, and have to back up.
    if (currentRep == 0) {
      if (currentRegion == 0) {
	//There are no chains to remove--do nothing
        assert(false); //Why did this happen?
	return;
      }
    }
    currentRegion = chains.size()-1;
    currentRep = chains[currentRegion].size()-1;
    currentChain = chains[currentRegion][currentRep].size()-1;
  }
  chains[currentRegion][currentRep].pop_back();
  currentChain--;
}

void ChainPack::SetSummaryOverReps(ChainOut& chout) {
  // a convenience variable
  vector<vector<ChainOut> >& region = chains[currentRegion];

  // set regional start/end times
  long lastrep = (region.size())-1;
  long lastchain = (region[0].size())-1;
  chout.SetStarttime(region[0][0].GetStarttime());
  chout.SetEndtime(region[lastrep][lastchain].GetEndtime());

  // This information is not helpful for the user so we'll supress it:
  chout.SetNumBadTrees(FLAGLONG);
  chout.SetNumTinyPopTrees(FLAGLONG);
  chout.SetNumStretchedTrees(FLAGLONG);
  chout.SetNumZeroDLTrees(FLAGLONG);
  chout.SetAccrate(FLAGDOUBLE);
  chout.SetLlikedata(FLAGDOUBLE);

  // The estimates in chout might not have known what region they were for.
  // If that's the case, this will set it straight.
  ForceParameters fp(chout.GetEstimates(), currentRegion);
  chout.SetEstimates(fp);
  regions.push_back(chout);

} /* ChainPack::SetSummaryOverReps */

//______________________________________________________________

void ChainPack::SetSummaryOverRegions(ChainOut& chout) {
  assert(chout.GetEstimates().GetParamSpace() == global_region);
  // set overall start/end times
  long lastregion = (chains.size())-1;
  long lastrep = (chains[0].size())-1;
  long lastchain = (chains[0][0].size())-1;
  chout.SetStarttime(chains[0][0][0].GetStarttime());
  chout.SetEndtime(chains[lastregion][lastrep][lastchain].GetEndtime());

  // This information is not helpful for the user so we'll supress it:
  chout.SetNumBadTrees(FLAGLONG);
  chout.SetNumTinyPopTrees(FLAGLONG);
  chout.SetNumStretchedTrees(FLAGLONG);
  chout.SetNumZeroDLTrees(FLAGLONG);
  chout.SetAccrate(FLAGDOUBLE);
  chout.SetLlikedata(FLAGDOUBLE);

  if (overall.size() > 0) {
    overall[0] = chout;
    //Useful for re-setting this when reading from a summary file.
  }
  else {
    overall.push_back(chout);
  }
} /* ChainPack::SetSummaryOverRegions */

void ChainPack::EndRegionIfNecessary(long region)
{
  if (currentRegion > region) return;
  EndRegion();
}

void ChainPack::EndRegionsOrRepsAsNeeded(long maxreps, long maxchains)
{
  if (currentChain >= maxchains) {
    EndReplicate();
  }
  if (currentRep >= maxreps) {
    EndRegion();
  }
}

/**************************************************
 The following functions provide summaries of the
 parameter values from a ChainPack.
**************************************************/

//______________________________________________________________

DoubleVec1d ChainPack::RegionalMeanParams() const
{
// summarizes the current region
unsigned long rep;
DoubleVec2d values;
long lastchain = chains[currentRegion][0].size() - 1;

for (rep = 0; rep < chains[currentRegion].size(); ++rep) {
  const ChainOut& chout = GetChain(currentRegion, rep, lastchain);
  values.push_back(chout.GetEstimates().GetRegionalParameters());
}

return CalcMean(values);

} /* RegionalMeanParams */

//______________________________________________________________

DoubleVec1d ChainPack::OverallMeanParams() const
{
// summarizes over all regions
unsigned long region;
DoubleVec2d values;

for (region = 0; region < chains.size(); ++region) {
  const ChainOut& chout = GetRegion(region);
  values.push_back(chout.GetEstimates().GetGlobalParameters());
}

return CalcMean(values);

} /* OverallMeanParams */

//______________________________________________________________

time_t ChainPack::GetStartTime() const {
  ChainOut firstchain = GetChain(0, 0, 0);
  return(firstchain.GetStarttime());
} /* GetStartTime */

time_t ChainPack::GetStartTime(long region) const {
  ChainOut firstchain = GetChain(region, 0, 0);
  return(firstchain.GetStarttime());
} /* GetStartTime */

//______________________________________________________________

time_t ChainPack::GetEndTime() const {
  ChainOut lastchain = GetOverall();
  return(lastchain.GetEndtime());
// daniel 040903
// why does lastchain.GetEndTime() sometimes return 0?  when the below endtime is correct?
// see output file from reading in sumfile
// bug in the overall vector?
/*
  long int i,j,k;
  i = chains.size() - 1;
  j = chains[i].size() - 1;
  k = chains[i][j].size() - 1;
  return chains[i][j][k].endtime;
*/
} /* GetEndTime */

//______________________________________________________________

// CalcMean assumes that all subvectors are as long as the first one
DoubleVec1d ChainPack::CalcMean(const DoubleVec2d& src) const
{
long index; 
long size = src[0].size();
DoubleVec2d::const_iterator values;
DoubleVec1d mean;

 for(index = 0; index < size; ++index) {
   double sum = 0.0;
   for(values = src.begin(); values != src.end(); ++values)
     sum += (*values)[index];
   mean.push_back(sum /= src.size());
 }
 return mean;

} /* ChainPack::CalcMean */

// following setter and getter for resuming with sumfiles
vector<vector<vector<ChainOut > > > ChainPack::GetAllChains() const
{ return chains; }

void ChainPack::WriteLastChain ( ofstream& sumout) const
{
  if ( sumout.is_open() ){
    sumout << xmlsum::CHAINPACK_START << endl;
    sumout << "\t" << xmlsum::NUMBER_START 
	   << " " << currentRegion << " " << currentRep << " " << (currentChain -1)
	   << " " << xmlsum::NUMBER_END << endl;
    WriteChainOut( sumout, chains[currentRegion][currentRep][(currentChain-1)] );
    WriteAlphas(sumout, currentRegion, currentRep, currentChain-1);
    sumout << xmlsum::CHAINPACK_END << endl;
  } else SumFileHandler::HandleSumOutFileFormatError("ChainPack::WriteLastChain");
} /* ChainPack::WriteLastChain */

void ChainPack::WriteChain(ofstream& sumout, long region, long rep, long chain) const
{
  if ( sumout.is_open() ){
    sumout << xmlsum::CHAINPACK_START << endl;
    sumout << "\t" << xmlsum::NUMBER_START 
	   << " " << region << " " << rep << " " << chain
	   << " " << xmlsum::NUMBER_END << endl;
    WriteChainOut( sumout, chains[region][rep][chain] );
    WriteAlphas(sumout, region, rep, chain);
    sumout << xmlsum::CHAINPACK_END << endl;
  } else SumFileHandler::HandleSumOutFileFormatError("ChainPack::WriteChain");
} /* ChainPack::WriteLastChain */

void ChainPack::WriteChainOut( ofstream& sumout, const ChainOut& chout) const
{
  if ( sumout.is_open() ){
    long badtrees	= chout.GetNumBadTrees();
    long tinytrees	= chout.GetTinyPopTrees();
    long stretchedtrees	= chout.GetStretchedTrees();
    long zerodltrees	= chout.GetZeroDLTrees();
    double accrate	= chout.GetAccrate();
    double llikemle	= chout.GetLlikemle();
    double llikedata	= chout.GetLlikedata();
    time_t starttime	= chout.GetStarttime();
    time_t endtime	= chout.GetEndtime();
    ratemap rates	= chout.GetAllAccrates();
    ForceParameters fp	= chout.GetEstimates();
    DoubleVec1d temperatures = chout.GetTemperatures();
    DoubleVec1d swaprates    = chout.GetSwaprates();
    LongVec1d   bayesunique  = chout.GetBayesUnique();
    
    sumout << "\t" << xmlsum::CHAINOUT_START << endl;
    sumout << "\t\t" << xmlsum::BADTREES_START	<< " " << badtrees
	   << " " << xmlsum::BADTREES_END << endl;
    sumout << "\t\t" << xmlsum::TINYTREES_START	<< " " << tinytrees
	   << " " << xmlsum::TINYTREES_END << endl;
    sumout << "\t\t" << xmlsum::STRETCHEDTREES_START << " " << stretchedtrees
	   << " " << xmlsum::STRETCHEDTREES_END << endl;
    sumout << "\t\t" << xmlsum::ZERODLTREES_START << " " << zerodltrees
	   << " " << xmlsum::ZERODLTREES_END << endl;
    sumout << "\t\t" << xmlsum::ACCRATE_START 	<< " " << accrate
	   << " " << xmlsum::ACCRATE_END << endl;
    sumout << "\t\t" << xmlsum::LLIKEMLE_START 	<< " " << llikemle
	   << " " << xmlsum::LLIKEMLE_END << endl;
    sumout << "\t\t" << xmlsum::LLIKEDATA_START << " " << llikedata
	   << " " << xmlsum::LLIKEDATA_END << endl;
    sumout << "\t\t" << xmlsum::STARTTIME_START << " " << starttime
	   << " " << xmlsum::STARTTIME_END << endl; 
    sumout << "\t\t" << xmlsum::ENDTIME_START 	<< " " << endtime
	   << " " << xmlsum::ENDTIME_END << endl;
		
    sumout << "\t\t" << xmlsum::RATES_START << " ";
    map< string, pair<long, long> >::iterator rit;
    for (rit = rates.begin(); rit != rates.end(); ++rit) {	
      sumout << xmlsum::MAP_START << " "; // map<string, pair<long, long> >
      sumout << rit->first << " " 
	     << rit->second.first << " " << rit->second.second << " ";
      sumout << xmlsum::MAP_END << " ";
    }
    sumout << xmlsum::RATES_END << endl;

    long numtemps = chout.GetNumtemps();
    if (numtemps > 1) {
      sumout << "\t\t" << xmlsum::TEMPERATURES_START << " ";
      SumFileHandler::WriteVec1D(sumout, temperatures);
      sumout << xmlsum::TEMPERATURES_END << endl;
    
      sumout << "\t\t" << xmlsum::SWAPRATES_START << " ";
      SumFileHandler::WriteVec1D(sumout, swaprates);
      sumout << xmlsum::SWAPRATES_END << endl;
    }
    if (bayesunique.size() > 0) {
      sumout << "\t\t" << xmlsum::BAYESUNIQUE_START << " ";
      SumFileHandler::WriteVec1D(sumout, bayesunique);
      sumout << xmlsum::BAYESUNIQUE_END << endl;
    }
    fp.WriteForceParameters(sumout, 2);		
    sumout << "\t" << xmlsum::CHAINOUT_END << endl;
  } else SumFileHandler::HandleSumOutFileFormatError("ChainPack::WriteChainOut");
}

void ChainPack::WriteAlphas(ofstream& sumout, long reg, long rep, long chain) const
{
  const Region& region = registry.GetDataPack().GetRegion(reg);
  for (long loc=0; loc<region.GetNloci(); loc++) {
    const Locus& locus = region.GetLocus(loc);
    locus.GetDataModel()->WriteAlpha(sumout, loc, rep, chain);
  }
}

void ChainPack::VerifyPosition( long test_reg, long test_rep, long test_chain) {
  
  if ((test_reg != currentRegion) || (test_rep != currentRep) || (test_chain != currentChain)) {
    string msg = "Tried to set the chainpack for region " + ToString(test_reg)
      + ", replicate " + ToString(test_rep) + ", and chain "
      + ToString(test_chain) + ", but we needed the chainpack for region "
      + ToString(currentRegion) + ", replicate " + ToString(currentRep)
      + ", and chain " + ToString(currentChain) + ".";
    throw data_error(msg);
  }
}
