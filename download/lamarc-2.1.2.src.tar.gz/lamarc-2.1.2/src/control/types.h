//$Id: types.h,v 1.18 2006/03/17 23:03:19 jay Exp $

#ifndef TYPES_H
#define TYPES_H

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "vectorx.h"
#include <list>
#include <string>
#include <map>
#include <memory>
#include "shared_ptr.hpp"

class Branch;
class DataType;
class DataModel;
class Cell;
class triplet;
class DLCalculator;

typedef boost::shared_ptr<Cell> Cell_ptr;
typedef std::pair<long,long>   wakestats;

typedef std::pair<std::string,long> TagLine;

typedef std::map<std::string,DoubleVec2d> percentmap;     // DoubleVec2d dim:
                                                // pop X reg
typedef std::map<std::string,DoubleVec1d> overpercentmap; // DoubleVec1d dim:
                                                // dim: by pop

typedef std::map<std::string, std::pair<long, long> > ratemap; // acceptance rate per arranger

typedef boost::shared_ptr<Branch>  Branch_ptr;
typedef boost::weak_ptr<Branch>    weakBranch_ptr;
typedef std::list<Branch_ptr>      Branchlist;
typedef Branchlist::iterator       Branchiter;
typedef Branchlist::const_iterator Branchconstiter;

typedef double*** cellarray;
typedef std::multimap<triplet, cellarray> FreeStore;

typedef boost::shared_ptr<DataType> DataType_ptr;
typedef boost::shared_ptr<DataModel> DataModel_ptr;

typedef std::pair<double, double> centilepair;

typedef boost::shared_ptr<DLCalculator> DLCalc_ptr;

typedef std::map<force_type, long>  FPartMap;
typedef std::map<force_type, long>::iterator  FPartMapiter;

typedef short xpart_t;  // type representing a number of partitions or
                        // cross-partitions.  Change this if you expect to
                        // have too many population x disease state x whatever
                        // combos to fit in the current size.
typedef std::vector<xpart_t> XPartVec1d;
typedef std::vector<std::vector<xpart_t> > XPartVec2d;

#endif /* TYPES_H */
