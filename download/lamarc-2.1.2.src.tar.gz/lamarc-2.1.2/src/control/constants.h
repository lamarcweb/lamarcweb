// $Id: constants.h,v 1.80 2007/07/10 23:46:40 jay Exp $

#ifndef CONSTANTS_H
#define CONSTANTS_H

/* 
   Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "definitions.h"
using std::string;

/***************************************************************
  This file contains constants which control the behavior of
the program.  They are divided into sections:

(1)  Constants which the user may wish to change, in order
     to adapt the program to his/her needs
(2)  Debugging constants which the user should probably not
     change unless sure of his/her reasons
(3)  Internal constants which should not be changed at all
(4)  The tag library (relating tags to literals) which should
     not be changed except to translate the program to a
     different language

If you change anything in this file you must 'make clean' the
entire project.  Unix Make utilities may not think you need to
go so far; but they lie.

****************************************************************/

class Registry;

extern Registry registry;

//--------------------------------------------------------------
//  User-changable constants 
//______________________________________________________________

// Only for Metrowerks compiles, see Makefile for other platforms 
// If you do not want to use the menu at all, set this constant
// to 0.  The program will then read from 'infile' and
// write to 'outfile' and no menu will be displayed.  Be sure
// that all necessary information is present in 'infile' if
// you use this option.
#ifdef __MWERKS__
#define MENU 1
#endif

// Enumerations 
enum verbosity_type {CONCISE, NORMAL, VERBOSE, NONE};
enum paramlistcondition { paramlist_YES, paramlist_MIX, paramlist_NO };
enum likelihoodtype { ltype_ssingle, ltype_replicate, ltype_region,
                      ltype_gammaregion };
enum proftype { profile_PERCENTILE, profile_FIX, profile_NONE };
enum noval {noval_none}; //used when I need a null instantiation for a template
// if you edit model_type, also edit numPossibleDataModels and allDataModels()
// in defaults.cpp
enum model_type {F84,Brownian,Stepwise,KAllele,GTR,MixedKS};
enum method_type {method_PROGRAMDEFAULT, method_USER, method_FST, method_WATTERSON};
enum priortype {LINEAR, LOGARITHMIC};
enum force_type { force_COAL, force_MIG, force_DISEASE, force_REC, 
	          force_GROW, force_REGION_GAMMA, force_EXPGROWSTICK, 
		  force_LOGISTICSELECTION, force_LOGSELECTSTICK };
enum paramstatus { pstat_invalid, pstat_unconstrained, pstat_constant, pstat_identical, pstat_joint };
/* Deleted (for now?) paramstatus values:  valid, symmetricNm, symmetricM
   (use 'mean' instead of symmetricM, 'standard' instead of valid, and don't
   use symmetricNm unless we allow our general migration model to vary based
   on population size.
*/
enum growth_type {growth_CURVE, growth_STICK, growth_STICKEXP};
enum growth_scheme {growth_EXP, growth_STAIRSTEP};



//---------------------------------------------------------------
// Debugging constants
// (you had better know what you are doing before changing any of
// these)
//_______________________________________________________________

// When STATIONARIES is true, the program will run without use of 
// data, producing a report of the stationary distribution of the sampler
// This is a useful debugging tool and can also be used to obtain
// stationaries of otherwise difficult distributions via Monte Carlo.
// NEVER turn this on if you mean to analyze your data--it will
// cause the data to be totally ignored!
#ifdef STATIONARIES
const string INTERVALFILE = "interval.out";
const string MIGFILE = "migcount";
const string DISFILE = "discount";
const string RECFILE = "reccount";
const string DISRECFILE = "disreccount";
#endif

// When true, track data likelihoods into file 'like1'
#define LIKETRACK 0

//---------------------------------------------------------------
//  Internal program constants
//  (you had better know *exactly* what you are doing if you
//  change any of these--the program may not survive)
//_______________________________________________________________

const double MAX_LENGTH = 200.0;    // maximum branch length
                                    // this must be less than
				    // DBL_MAX because of use in
				    // Active/InactiveStairStickCoal
				    // events.

const long BASES = 4;                // number of nucleotides
const long baseA = 0;                // codes for nucleotides
const long baseC = 1;
const long baseG = 2;
const long baseT = 3;
const long baseEnd = 4;              // allows one-past-the-end use
const int  INVARIANTS   = 4;        // possible invariant sites

const long FLAGLONG     = -99;      // arbitrary flag values
const double FLAGDOUBLE = -99.0;   
const long FLAGINVAR    = -999;

const double DF         = 2.0;      // degrees of freedom for
                                    // likelihood ratio test
const long NCHAINTYPES = 2;         // how many kinds of chains?
const long IDSIZE = 2;              // size of branch ID number
const long NELEM = 2;               // allowed parents or children
                                    // of a branch

// The following should be provided by the compiler, but
// we have found this to be unportable, so we define them
// ourselves.

const double NEG_MAX = -999999999.9; // the smallest reasonable double

//---------------------------------------------------------------
// Registry of constant string tags
// (you might wish to change these if changing language)
//_______________________________________________________________
const unsigned long INDENT_DEPTH = 2;  // output of input xml indentation depth

// The precision of the numbers written to the summary output file.
// NOTE:  When writing tree summaries with growth, the precision *must*
// be at least as large as the minimum timestep allowable.
const int SUMFILE_PRECISION = 18;

class lamarccodes
{
public:
  static const int cleanReturn;
  static const int badAllocation;
  static const int fileError;
  static const int unknownError;
};

class lamarcstrings
{
public:
  static const std::string COAL       ;
  static const std::string MIG        ;
  static const std::string DISEASE    ;
  static const std::string REC        ;
  static const std::string GROW       ;
  static const std::string LOGISTICSELECTION;

  static const std::string REGION_GAMMA;
  static const std::string INVALID    ;
  static const std::string STICK      ;
  static const std::string TIP        ;
  static const std::string BASE       ;
  static const std::string SNP        ;
  static const std::string DNA        ;
  static const std::string NUC        ;
  static const std::string MICROSAT   ;
  static const std::string EXPGROWSTICK;
  static const std::string LOGSELECTSTICK;

  static const std::string F84;
  static const std::string GTR;
  static const std::string STEPWISE;
  static const std::string BROWNIAN;
  static const std::string KALLELE;
  static const std::string MIXEDKS;

  static const std::string ELECTRO    ;

  static const std::string longNameUSER;
  static const std::string longNamePROGRAMDEFAULT;
  static const std::string longNameFST;
  static const std::string longNameWATTERSON;

  static const std::string shortNameUSER;
  static const std::string shortNamePROGRAMDEFAULT;
  static const std::string shortNameFST;
  static const std::string shortNameWATTERSON;

  static const std::string longBrownianName;
  static const std::string longF84Name;
  static const std::string longGTRName;
  static const std::string longKAlleleName;
  static const std::string longStepwiseName;
  static const std::string longMixedKSName;

  static const std::string shortBrownianName;
  static const std::string shortF84Name;
  static const std::string shortGTRName;
  static const std::string shortKAlleleName;
  static const std::string shortStepwiseName;
  static const std::string shortMixedKSName;

  static const std::string longCurveName;
  static const std::string longStickExpName;
  static const std::string longStickName;
  static const std::string shortCurveName;
  static const std::string shortStickExpName;
  static const std::string shortStickName;

  static const std::string longExpName;
  static const std::string longStairStepName;
  static const std::string shortExpName;
  static const std::string shortStairStepName;
};

#endif /* CONSTANTS_H */
