//$Id: chainparam.h,v 1.30 2006/04/14 22:32:52 lpsmith Exp $

#ifndef CHAINPARAMETERS_H
#define CHAINPARAMETERS_H

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************** 
 ChainParameters is a collection class used for internal communication
 throughout Lamarc.

 ChainParameters contains information needed to run chains, including
 managing the different arrangers.

 Written by Jim Sloan, revised by Mary Kuhner

 reworked by Elizabeth Walkup 2004/08/06 to mesh with 
 front-end/back-end separation
********************************************************************/

#include <vector>
#include "vectorx.h"
#include <stdlib.h>
#include "constants.h"
#include "arrangervec.h"

class Arranger;

//____________________________________________________________________
//____________________________________________________________________

class ChainParameters
{
  private:
    ArrangerVec         m_arrangers;    // we own this
    DoubleVec1d         m_temperatures; // sorted in ascending order
    long                m_tempinterval; // how often to swap between heated chains
    bool                m_tempadapt;    // adpative change of the temperatures
    long                m_nChains_initial;
    long                m_nSamples_initial;
    long                m_interval_initial;
    long                m_nDiscard_initial;
    long                m_nChains_final;
    long                m_nSamples_final;
    long                m_interval_final;
    long                m_nDiscard_final;
    long                m_nreps;
    bool                m_bayesian;     // are we doing Bayesian or frequentist?
    bool                m_runprofilereps; // if true run additional replicates
                                          //   to improve generation of
                                          //   profile-likelihood boundaries
                                          // ignored if the run is bayesian

    bool ValidTemperatures() const;

    ChainParameters();                                      // undefined
    ChainParameters(const ChainParameters& src);            // undefined
    ChainParameters& operator=(const ChainParameters& src); // undefined           
  protected:
    void SortAndNormalizeTemperatures();

  public:
    ChainParameters(    
                        DoubleVec1d temperatures,
                        long        tempInterval,
                        bool        tempAdapt,
                        long        nChains_initial,
                        long        nSamples_initial,
                        long        interval_initial,
                        long        nDiscard_initial,
                        long        nChains_final,
                        long        nSamples_final,
                        long        interval_final,
                        long        nDiscard_final,
                        long        nreps,
                        bool        bayesian,
                        double      dropTiming,
                        double      sizeTiming,
                        double      hapTiming,
                        double      probhapTiming,
                        double      bayesTiming,
                        double      locusTiming,
                        double      zilchTiming
                    );
                     ~ChainParameters();

    // Get Functions
    double GetArrangerTiming(const string& atype) const;
    ArrangerVec CloneArrangers() const;
    StringVec1d GetAllStringsForActiveArrangers() const;

    StringVec1d ToXML(unsigned long nspaces) const;

    long GetTempInterval()             const { return m_tempinterval; };
    bool GetTempAdapt()                const { return m_tempadapt; };
    double GetTemperature(long i)      const { return m_temperatures[i]; };
    DoubleVec1d GetAllTemperatures()   const { return m_temperatures; };
    long GetNChains(long i)            const;
    long GetNSamples(long i)           const;
    long GetInterval(long i)           const;
    long GetNDiscard(long i)           const;
    long GetNReps()                    const { return m_nreps; };
    bool IsBayesian()                  const { return m_bayesian; };
    // getter used by CollectionManger ctor
    long GetNAllChains()               const;
    bool RunProfileReps()              const;
    long GetNProfileReps(long nparams) const;
    long GetNRepsAndNProfileReps(long nparams)    const;

    // Validation
    bool IsValid()                     const;

};


// This free function throws an exception of type data_error
// and containing the specified message.  It's meant only as
// a convenience.

void DoError(const string& what);

#endif /* CHAINPARAMETERS_H */
