// $Id: bayesparamlike_1d.h,v 1.8 2006/04/06 02:26:35 lpsmith Exp $
#ifndef BAYES_PARAMLIKE_1D_H
#define BAYES_PARAMLIKE_1D_H

/*
  Copyright 2004  Lucian Smith, Mary Kuhner, Jon Yamato and Joseph Felsenstein
  
  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

/*
  
*/

#include "bayescurve.h"

class Parameter;

class BayesParamLike_1D
{
public:
  BayesParamLike_1D (Parameter param);
  ~BayesParamLike_1D ();
  void AddPoint(double value, long freq);
  //Initializes m_smoothed_curve
  void SmoothCurve();
  BayesCurve GetSmoothedCurve() {return m_smoothed_curve;}
  priortype GetPriorType() {return m_priortype;}
  double GetKernelWidth() {return m_kernelwidth;}
  long   GetNumUniquePoints();
  
private:
  std::vector<std::pair<double, long> > m_raw_data;
  unsigned long m_numpoints;
  bool m_isvalid;

  BayesCurve m_smoothed_curve;

  double m_kernelwidth;

  //These values are set on a per-force basis.
  priortype m_priortype;
  double m_binwidth;

  //Functions.  Used by SmoothCurve(), generally.
  void InitializeCurve();
  double CalculateStdev(const double average); //used for CalcualateH()

}; /* class BayesParamLike_1D */
#endif //BAYES_PARAMLIKE_1DH
