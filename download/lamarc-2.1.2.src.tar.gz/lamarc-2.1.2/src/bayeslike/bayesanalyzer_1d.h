// $Id: bayesanalyzer_1d.h,v 1.13 2007/08/03 20:43:08 lpsmith Exp $
#ifndef BAYES_ANALYZER_H
#define BAYES_ANALYZER_H

/*
  Copyright 2004  Lucian Smith, Mary Kuhner, Jon Yamato and Joseph Felsenstein
  
  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

/*
  The Bayesian analyzer holds vectors of 'BayesParamlike's, which are front
  ends, of a sort, for BayesCurves.  As the collection manager sends the
  BayesAnalyzer lists of parameters, it divvies up the information, and sends
  it to the appropriate BayesParamLike.  The ParamLikes then take the
  accumulated data points and curve-smooth them so that we know both the
  MLEs and the confidence intervals for all parameters.

  This can be accomplished by analyzing the parameters 1-, 2-, or
  n-dimensionally.  The simplest is 1-dimensionally, where we look at each
  parameter without regard to how it might affect other parameters.  At the
  next level, we might consider pairs of parameters, and smooth the
  resulting 2-dimensional surface.  Finally, we might attempt to go for the
  gusto and consider all parameters at once, smoothing an n-dimensional
  surface.  Such a surface would be nigh-impossible to visualize, and trying
  to find the maximum on such a surface would probably be as difficult as
  normal maximization.  Perhaps the maximizer object could do such a
  maximization, given a different PLforces object, or some such.  Anyway.

  As a first pass at attempting to do this, we'll be analyzing the parameters
  individually with Bayes_Analyzer_1D.  In the future, we might try the
  other two options (_2D and _ND, respectively).

  It might be interesting to look at this in terms of Singular Value
  Decomposition, or SVD.  This is what folks at Rice did with protein
  dynamics.


*/

#include "vectorx.h"
#include "collector.h"
#include "bayesparamlike_1d.h"
#include "bayescurve.h"
#include "forcesummary.h"
#include "parameter.h"


class BayesAnalyzer_1D
{
public:
  //   ---Generic BayesAnalyzer functions---
  BayesAnalyzer_1D();
  ~BayesAnalyzer_1D();

  void AnalyzeAndAdd(const ParamSumm paramsumm);
  void ReplaceLastChainAndAnalyze(const ParamSumm paramsumm);
  //You might call the Replace routine if you do a run with more than one
  // chain, but wanted to analyze the first chain.
  void EndChainsAndAnalyze();
  void EndReplicatesAndAnalyze();
  void EndRegionsAndAnalyze();

  //   ---Functions specific to a 1D analysis---
  DoubleVec1d GetMaxVecForLastChain();
  double      GetAvgMaxLikeForLastChain();
  double      GetAvgMaxLikeForRegion(long region);
  double      GetAvgMaxLikeForAllRegions();

  double      GetMaxForChain(long chain, long parameter);
  double      GetLikeAtMaxForChain(long chain, long parameter);

  double      GetMaxForRegion(long region, long parameter);
  DoubleVec1d GetMaxVecForRegion(long region);

  double      GetLikeAtMaxForRegion(long region, long parameter);
  double      GetValAtPercentileForRegion(double percentile, long region,
					  long parameter);
  double      GetPercentileAtValForRegion(double val, long region,
					  long parameter);
  double      GetLikeAtValForRegion(double val, long region, long parameter);

  double      GetMaxForAllRegions(long parameter);
  DoubleVec1d GetMaxVecForAllRegions();
  double      GetLikeAtMaxForAllRegions(long parameter);
  double      GetValAtPercentileForAllRegions(double percentile,
					      long parameter);
  double      GetPercentileAtValForAllRegions(double val, long parameter);
  double      GetLikeAtValForAllRegions(double val, long parameter);

  void CalcProfiles(long region);
  std::vector <long> GetNumUniquePointsVec();
  void WriteCurvesForRegion     (long region);

private:

  long m_currentChain;
  long m_currentReplicate;
  long m_currentRegion;

  const ForceSummary &m_forcesummary;

  vector < paramstatus > m_paramstatuses;
  DoubleVec1d m_startparams;

  //The chain curves are stored in the vector of BayesParamLikes, while
  // the region and overall curves are stored as BayesCurve member variables.
  vector < vector <BayesParamLike_1D> >  m_paramlikes;
  //Dimensions are m_paramlikes[chain][parameter]
  vector < vector < vector < BayesCurve> > > m_replicatecurves;
  //Dimensions are [region][replicate][parameter]
  vector < vector <BayesCurve> >  m_regioncurves;
  //Dimensions are m_regioncurves[region][parameter]
  vector <BayesCurve>  m_allregioncurves;
  //Dimensions are m_allregioncurves[parameter]

  vector <BayesParamLike_1D> m_blankBayesParamVec;
  //This is created at object creation, initialized with the appropriate
  // forces in the correct orders, since BayesParamLike_1D's can only be
  // created knowing what force they're for.

  bool IsVariable(unsigned long parameter);
  void CalcProfile(ParamVector::iterator param, long nparam, long nregion);

}; /* class BayesAnalyzer_1D */




#endif //BAYES_ANALYZER_H
