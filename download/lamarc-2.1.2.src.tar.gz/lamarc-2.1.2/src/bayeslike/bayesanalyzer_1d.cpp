// $Id: bayesanalyzer_1d.cpp,v 1.27 2007/08/03 20:43:08 lpsmith Exp $
// Devised May 2004 by Lucian Smith
// Uses data from a CollectionManager to do a bayesian analysis.

/*
  Copyright 2004  Lucian Smith, Mary Kuhner, Jon Yamato and Joseph Felsenstein
  
  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/
#include <fstream>
#include <iostream>
#include "bayesanalyzer_1d.h"
#include "bayesparamlike_1d.h"
#include "bayescurve.h"
#include "collector.h"
#include "collmanager.h"
#include "constants.h"
#include "registry.h"
#include "mathx.h"
#include "parameter.h"
#include "runreport.h"
#include "forcesummary.h"
#include "userparam.h"
#include "vector_constants.h"
#include "force.h"

using namespace std;

BayesAnalyzer_1D::BayesAnalyzer_1D()
  : m_currentChain(0), m_currentReplicate(0), m_currentRegion(0),
    m_forcesummary(registry.GetForceSummary())
{
  const ParamVector paramvec(true);
  for (unsigned long i=0; i<paramvec.size(); i++) {
    BayesParamLike_1D bp(paramvec[i]);
    m_blankBayesParamVec.push_back(bp);
    m_paramstatuses.push_back(paramvec[i].GetStatus());
  }
  m_startparams = registry.GetForceSummary().GetStartParameters().GetGlobalParameters();
}

BayesAnalyzer_1D::~BayesAnalyzer_1D()
{
}

void BayesAnalyzer_1D::AnalyzeAndAdd(const ParamSumm paramsumm)
{
  if (m_currentChain == 0) {
    m_paramlikes.clear();
  }
  //Make new BayesParamLikes by force, stick the data in 'em, then
  // run the curve smoothing algorithms on a per-chain basis.
  vector<BayesParamLike_1D> bayesparamls = m_blankBayesParamVec;
  for (unsigned long sample=0; sample<paramsumm.size(); sample++) {
    DoubleVec1d parameters = paramsumm[sample].first.GetGlobalParameters();
    long freq              = paramsumm[sample].second;
    for (unsigned long pnum=0; pnum<parameters.size(); pnum++) {
      if (IsVariable(pnum)) {
        bayesparamls[pnum].AddPoint(parameters[pnum], freq);
      }
    }
  }

  //All the data has been added; now smooth the curve.
  for (unsigned long pnum=0; pnum<bayesparamls.size(); pnum++) {
    if (IsVariable(pnum)) {
      bayesparamls[pnum].SmoothCurve();
    }
  }
  
  //And now stick it into the appropriate member variables.
  m_paramlikes.push_back(bayesparamls);
  m_currentChain++;
  
}

//You might call the Replace routine if you do a run with more than one
// chain, wanted to analyze the first chain, but didn't want to keep the
// results.
void BayesAnalyzer_1D::ReplaceLastChainAndAnalyze(const ParamSumm paramsumm)
{
  if (m_currentChain > 0) {
    m_currentChain--;
    m_paramlikes.pop_back();
  }
  AnalyzeAndAdd(paramsumm);
}

void BayesAnalyzer_1D::EndChainsAndAnalyze()
{
  assert (m_paramlikes.size() > 0);

  vector < vector < BayesCurve > > curvesbyparam;
  //Dimensions are [parameter][chain], *not* the other way around.
  // We want it this way so we can sum each parameter over its chains.

  //Set up the curvesbyparam vector.
  for (unsigned long param=0; param < m_blankBayesParamVec.size(); param++) {
    vector < BayesCurve> onecurve;
    onecurve.push_back(m_paramlikes[0][param].GetSmoothedCurve());
    curvesbyparam.push_back(onecurve);
  }

  //And now add the other chains to the vectors.
  //LS NOTE:  our current analysis discards previous chains, so this never
  // gets used.
  for (long chain=1; chain<m_currentChain; chain++) {
    for (unsigned long param=0; param < m_blankBayesParamVec.size(); param++)
      curvesbyparam[param].push_back(m_paramlikes[chain][param].GetSmoothedCurve());
  }

  vector <BayesCurve> summedcurves;
  for (unsigned long param=0; param< m_blankBayesParamVec.size(); param++) {
    BayesCurve summedcurve(curvesbyparam[param], ADD);
    summedcurves.push_back(summedcurve);
  }

  if (m_currentReplicate == 0) {
    vector < vector <BayesCurve> > sumcurvevec;
    sumcurvevec.push_back(summedcurves);
    m_replicatecurves.push_back(sumcurvevec);
  }
  else
    m_replicatecurves[m_currentRegion].push_back(summedcurves);

  //m_paramlikes.clear();
  m_currentReplicate++;
  m_currentChain = 0;
}

void BayesAnalyzer_1D::EndReplicatesAndAnalyze()
{
  vector < vector < BayesCurve > > curvesbyparam;
  //Dimensions are [parameter][replicate], *not* the other way around.
  // We want it this way so we can sum each parameter over its replicates.

  //Set up the curvesbyparam vector.
  for (unsigned long param=0; param < m_blankBayesParamVec.size(); param++) {
    vector < BayesCurve> onecurve;
    onecurve.push_back(m_replicatecurves[m_currentRegion][0][param]);
    curvesbyparam.push_back(onecurve);
  }

  //And now add the other replicates to the vectors.
  for (long replicate=1; replicate<m_currentReplicate; replicate++) {
    for (unsigned long param=0; param < m_blankBayesParamVec.size(); param++)
      curvesbyparam[param].push_back(m_replicatecurves[m_currentRegion][replicate][param]);
  }

  vector <BayesCurve> summedcurves;
  for (unsigned long param=0; param< m_blankBayesParamVec.size(); param++) {
    BayesCurve summedcurve(curvesbyparam[param], ADD);
    summedcurves.push_back(summedcurve);
  }
  
  m_regioncurves.push_back(summedcurves);
  
  m_currentRegion++;
  m_currentReplicate = 0;
  m_currentChain = 0;
}

void BayesAnalyzer_1D::EndRegionsAndAnalyze()
{
  //Basically the same as EndReplicates, except we multiply the curves instead
  // of adding them.

  assert (m_regioncurves.size() > 0);
  vector < vector < BayesCurve > > curvesbyparam;
  //Dimensions are [parameter][region], *not* the other way around.
  // We want it this way so we can sum each parameter over its replicates.

  //Set up the curvesbyparam vector.
  for (unsigned long param=0; param < m_blankBayesParamVec.size(); param++) {
    vector < BayesCurve> onecurve;
    onecurve.push_back(m_regioncurves[0][param]);
    curvesbyparam.push_back(onecurve);
  }

  //And now add the other regions to the vectors.
  for (long region=1; region<m_currentRegion; region++) {
    for (unsigned long param=0; param < m_blankBayesParamVec.size(); param++)
      curvesbyparam[param].push_back(m_regioncurves[region][param]);
  }

  for (unsigned long param=0; param< m_blankBayesParamVec.size(); param++) {
    BayesCurve summedcurve(curvesbyparam[param], MULTIPLY);
    m_allregioncurves.push_back(summedcurve);
  }
}

//The chain curves are stored in the vector of BayesParamLikes, while
// the region and overall curves are stored as member variables.
DoubleVec1d BayesAnalyzer_1D::GetMaxVecForLastChain()
{
  DoubleVec1d results = m_startparams;
  unsigned long chain = m_paramlikes.size()-1;
  for (unsigned long parameter=0; parameter<m_startparams.size(); parameter++) {
    if (IsVariable(parameter)) {
      double newval = GetMaxForChain(chain, parameter);
      registry.GetForceSummary().SetParamWithConstraints(parameter, newval, results);
    }
  }
  return results;
}

double BayesAnalyzer_1D::GetAvgMaxLikeForLastChain()
{
  double result = 0.0;
  long pcount=0;
  unsigned long chain = m_paramlikes.size()-1;
  for (unsigned long parameter=0; parameter<m_startparams.size(); parameter++) {
    if (IsVariable(parameter)) {
      result += GetLikeAtMaxForChain(chain, parameter);
      pcount++;
    }
  }
  if (pcount>0)
    return result/pcount;
  else return 1.0;
}

double BayesAnalyzer_1D::GetAvgMaxLikeForRegion(long region)
{
  double result = 0.0;
  long pcount=0;
  for (unsigned long parameter=0; parameter<m_startparams.size(); parameter++) {
    if (IsVariable(parameter)) {
      result += GetLikeAtMaxForRegion(region, parameter);
      pcount++;
    }
  }
  if (pcount>0)
    return result/pcount;
  else return 1.0;
}

double BayesAnalyzer_1D::GetAvgMaxLikeForAllRegions()
{
  double result = 0.0;
  long pcount=0;
  for (unsigned long parameter=0; parameter<m_startparams.size(); parameter++) {
    if (IsVariable(parameter)) {
      result += GetLikeAtMaxForAllRegions(parameter);
      pcount++;
    }
  }
  if (pcount>0)
    return result/pcount;
  else return 1.0;
}

double BayesAnalyzer_1D::GetMaxForChain(long chain, long parameter)
{
  if (IsVariable(parameter))
    return m_paramlikes[chain][parameter].GetSmoothedCurve().GetMax();
  else return m_startparams[parameter];
}

double BayesAnalyzer_1D::GetLikeAtMaxForChain(long chain, long parameter)
{
  if (IsVariable(parameter))
    return m_paramlikes[chain][parameter].GetSmoothedCurve().GetLikeAtMax();
  else return 1.0;
}

double BayesAnalyzer_1D::GetMaxForRegion(long region, long parameter)
{
  if (IsVariable(parameter))
    return m_regioncurves[region][parameter].GetMax();
  else return m_startparams[parameter];
}

double BayesAnalyzer_1D::GetLikeAtMaxForRegion(long region, long parameter)
{
  if (IsVariable(parameter))
    return m_regioncurves[region][parameter].GetLikeAtMax();
  else return 1.0;
}

DoubleVec1d BayesAnalyzer_1D::GetMaxVecForRegion(long region)
{
  DoubleVec1d results = m_startparams;
  for (unsigned long parameter=0; parameter<m_startparams.size(); parameter++) {
    if (IsVariable(parameter)) {
      double newval = GetMaxForRegion(region, parameter);
      registry.GetForceSummary().SetParamWithConstraints(parameter, newval, results);
    }
  }
  return results;
}

double BayesAnalyzer_1D::GetPercentileAtValForRegion(double val,
						long region, long parameter)
{
  if (IsVariable(parameter))
    return m_regioncurves[region][parameter].GetPercentileAtVal(val);
  else return 0.5;
}

double BayesAnalyzer_1D::GetValAtPercentileForRegion(double val,
						long region, long parameter)
{
  if (IsVariable(parameter))
    return m_regioncurves[region][parameter].GetValAtPercentile(val);
  else return m_startparams[parameter];
}

double BayesAnalyzer_1D::GetLikeAtValForRegion(double val,
					       long region, long parameter)
{
  if (IsVariable(parameter))
    return m_regioncurves[region][parameter].GetLikeAtVal(val);
  else return 0.0;
}

double BayesAnalyzer_1D::GetMaxForAllRegions(long parameter)
{
  if (IsVariable(parameter))
    return m_allregioncurves[parameter].GetMax();
  else return m_startparams[parameter];
}

double BayesAnalyzer_1D::GetLikeAtMaxForAllRegions(long parameter)
{
  if (IsVariable(parameter))
    return m_allregioncurves[parameter].GetLikeAtMax();
  else return 1.0;
}

DoubleVec1d BayesAnalyzer_1D::GetMaxVecForAllRegions()
{
  DoubleVec1d results = m_startparams;
  for (unsigned long parameter=0; parameter<m_startparams.size(); parameter++) {
    if (IsVariable(parameter)) {
      double newval = GetMaxForAllRegions(parameter);
      registry.GetForceSummary().SetParamWithConstraints(parameter, newval, results);
    }
  }
  return results;
}

double BayesAnalyzer_1D::GetValAtPercentileForAllRegions(double percentile,
						    long parameter)
{
  if (IsVariable(parameter))
    return m_allregioncurves[parameter].GetValAtPercentile(percentile);
  else return m_startparams[parameter];
}

double BayesAnalyzer_1D::GetPercentileAtValForAllRegions(double val,
						    long parameter)
{
  if (IsVariable(parameter))
    return m_allregioncurves[parameter].GetPercentileAtVal(val);
  else return 0.5;
}

double BayesAnalyzer_1D::GetLikeAtValForAllRegions(double val,
						    long parameter)
{
  if (IsVariable(parameter))
    return m_allregioncurves[parameter].GetLikeAtVal(val);
  else return 0.0;
}

bool BayesAnalyzer_1D::IsVariable(unsigned long parameter)
{
  switch(m_paramstatuses[parameter])
    {
    case pstat_invalid:
    case pstat_constant:
    case pstat_identical:
      return false;
      break;
    case pstat_unconstrained:
    case pstat_joint:
      return true;
      break;
    }
  assert(false); //A new parameter validity has not been accounted for.
  return true;
}

void BayesAnalyzer_1D::CalcProfiles(long region)
{
  if (!((region == FLAGLONG) && (m_regioncurves.size()==1)))
    registry.GetRunReport().RecordProfileStart();

  ParamVector toDolist(false);
  ParamVector::iterator param;
  long paramnum;

  for (param = toDolist.begin(), paramnum = 0;
       param != toDolist.end(); ++param, ++paramnum) {
    ProfileStruct emptyprofile ;
    switch (m_paramstatuses[paramnum]) {
    case pstat_invalid:
      break;
    case pstat_constant:
    case pstat_identical:
      if (region==FLAGLONG)
        param->AddProfile(emptyprofile,ltype_region);
      else
        param->AddProfile(emptyprofile,ltype_replicate);
      break;
    case pstat_unconstrained:
    case pstat_joint:
      CalcProfile (param, paramnum, region);
      break;
    }
  }
}


void BayesAnalyzer_1D::CalcProfile(ParamVector::iterator param, long nparam,
				   long nregion)
{
  likelihoodtype ltype;
  double MLE, MLElike, MLEperc;
  if (nregion == FLAGLONG) {
    ltype = ltype_region; //'region' is an enum.
    MLE = GetMaxForAllRegions(nparam);
    MLElike = GetLikeAtMaxForAllRegions(nparam);
    MLEperc = GetPercentileAtValForAllRegions(MLE, nparam);
  }
  else {
    ltype = ltype_replicate; //Could be anything as long as it's not 'region'.
    MLE = GetMaxForRegion(nregion, nparam);
    MLElike = GetLikeAtMaxForRegion(nregion, nparam);
    MLEperc = GetPercentileAtValForRegion(MLE, nregion, nparam);
  }
  proftype ptype = param->GetProfileType();
  if (ptype == profile_NONE) {
    assert(false); //profiling should always be on for bayesian parameters.
    ProfileStruct emptyprofile ;
    param->AddProfile(emptyprofile,ltype);
    return;
  }
  DoubleVec1d modifiers = m_forcesummary.GetModifiers(nparam);
  
  ProfileStruct theprofile;

  for (unsigned long i=0; i< modifiers.size(); ++i) {
    ProfileLineStruct profileline;
    double perc, val, likelihood;
    if (ptype == profile_FIX) {
      if(param->IsForce(force_GROW) &&
	 (registry.GetUserParameters().GetVerbosity() != CONCISE)) {
	if (i < vecconst::growthmultipliers.size())
	  val = modifiers[i] * MLE;
	else
	  val = modifiers[i];
	// The second part of this vector is filled with values which we want
	// to *set* growth to, not to multiply growth by. --LS
      }
      else if(param->IsForce(force_LOGISTICSELECTION) &&
	 (registry.GetUserParameters().GetVerbosity() != CONCISE)) {
	if (i < vecconst::logisticselectionmultipliers.size())
	  val = modifiers[i] * MLE;
	else
	  val = modifiers[i];
	// The second part of this vector is filled with values which we want
	// to *set* the logistic selection coeff. to, not to multiply it by. --LS
      }
      else
	val = modifiers[i] * MLE;
      if (ltype == ltype_region) {
	perc = GetPercentileAtValForAllRegions(val, nparam);
	likelihood = GetLikeAtValForAllRegions(val, nparam);
      }
      else {
	perc = GetPercentileAtValForRegion(val, nregion, nparam);
	likelihood = GetLikeAtValForRegion(val, nregion, nparam);
      }      
    }
    else { //ptype == percentile;
      perc = modifiers[i];
      if (ltype == ltype_region) {
	val = GetValAtPercentileForAllRegions(perc, nparam);
	likelihood = GetLikeAtValForAllRegions(val, nparam);
      }
      else {
	val = GetValAtPercentileForRegion(perc, nregion, nparam);
	likelihood = GetLikeAtValForRegion(val, nregion, nparam);
      }
    }
    profileline.percentile = perc;
    profileline.profilevalue = val;
    profileline.loglikelihood = likelihood; //Not really a *log*, but anyway.
    theprofile.profilelines.push_back(profileline);
    //LS TEST
    //std::cout << perc << ", " << val << ", " << likelihood << std::endl;
  }
  ProfileLineStruct profileline;

  profileline.percentile = MLEperc;
  profileline.profilevalue = MLE;
  profileline.loglikelihood = MLElike;
  theprofile.profilelines.push_back(profileline);
  //LS TEST
  //std::cout << MLEperc << ", " << MLE << ", " << MLElike << std::endl;

  param->AddProfile(theprofile, ltype);
} /* BayesAnalyzer_1D::CalcProfile */

vector <long> BayesAnalyzer_1D::GetNumUniquePointsVec()
{
  vector <long> results;
  unsigned long chain = m_paramlikes.size()-1;
  for (unsigned long pnum=0; pnum<m_paramlikes[chain].size(); pnum++)
    results.push_back(m_paramlikes[chain][pnum].GetNumUniquePoints());
  return results;
}

void BayesAnalyzer_1D::WriteCurvesForRegion(long region)
{
  ofstream curvefile;
  curvefile.precision(10);
  string regname;
  if (region==FLAGLONG)
    regname = "overall_";
  else
    regname = "reg" + indexToKey(region) + "_";  

  const ParamVector paramvec(true);
  unsigned long chain = m_paramlikes.size()-1;
  for (long pnum=0; pnum<static_cast<long>(paramvec.size()); pnum++) {
    if (!IsVariable(pnum)) continue;
    DoublePairVec curve;
    bool islog;
    if (region==FLAGLONG) {
      curve = m_allregioncurves[pnum].GetXYvec();
      islog = m_allregioncurves[pnum].IsLog();
    }
    else {
      curve = m_regioncurves[region][pnum].GetXYvec();
      islog = m_regioncurves[region][pnum].IsLog();
    }
    string pname = paramvec[pnum].GetShortName();
    string::size_type i = pname.find("/");
    while (i != string::npos) {
      pname.replace(i,1,"+");
      i = pname.find("/");
    }
    UserParameters& userparams = registry.GetUserParameters();
    string prefix = userparams.GetCurveFilePrefix();
    string fname = prefix + "_" + regname + pname + ".txt";
    curvefile.open(fname.c_str(), ios::out );
    userparams.AddCurveFileName(fname);
    //General info
    curvefile << "Bayesian likelihood curve for \""
              << paramvec[pnum].GetName() << "\" ";
    if (region==FLAGLONG)
      curvefile << "as combined over all genomic regions.";
    else
      curvefile << "for genomic region " << (region + 1) << ".";
    curvefile << endl;
    
    if ((region != m_currentRegion-1) && (region != FLAGLONG)) {
      registry.GetRunReport().ReportDebug("WriteCurvesForRegion can report more information when called on only the most recent region or for the overall region estimates.");
    }
    else if (region == FLAGLONG) {
      long numregions = m_regioncurves.size();
      curvefile << "Created by averaging " << numregions
                << " different regional curves." << endl;
    }
    else {
      long numreplicates = m_replicatecurves[m_currentRegion-1].size();
      if (numreplicates > 1) {
        curvefile << "Created by averaging " << numreplicates
                  << " different replicate curves." << endl;
      }
      else {
        long numpoints = m_paramlikes[chain][pnum].GetNumUniquePoints();
        double kernel = m_paramlikes[chain][pnum].GetKernelWidth();
        curvefile << "Created from " << numpoints
                  << " unique data points and a kernel width of "
                  << kernel << "." << endl;
      }
    }
    double lowerbound = paramvec[pnum].GetPrior().GetLowerBound();
    double upperbound = paramvec[pnum].GetPrior().GetUpperBound();
    curvefile << "The prior for this parameter was ";
    if (islog) {
      curvefile << "logarithmic";
    }
    else {
      curvefile << "flat";
    }
    curvefile << ", and ranged from "
              << ToString(lowerbound) << " to "
              << ToString(upperbound) << ".";
    if (islog) {
      curvefile << "  (Or, in log space, "
                << ToString(SafeLog(lowerbound)) << " to "
                << ToString(SafeLog(upperbound)) << ".)";
    }
    curvefile << endl;

    //Column headers
    if (islog)
      curvefile << "Ln(" << pname << ")";
    else 
      curvefile << pname;
    curvefile << "\tLikelihood" << endl;
    //Raw data
    for (unsigned long line=0; line<curve.size(); line++)
      curvefile << curve[line].first << "\t" << curve[line].second << endl;
    curvefile << endl << endl;
    curvefile.close();
  }

  
} /*WriteCurvesForRegion*/
