//$Id: menuerror.h,v 1.5 2004/05/04 18:23:28 ewalkup Exp $
#ifndef MENUERROR_H
#define MENUERROR_H

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <stdexcept>
#include <string>

class DialogProtocolError : public std::exception {
    private:
        std::string _what;
    public:
        DialogProtocolError(const std::string& wh): _what (wh) { };
        virtual ~DialogProtocolError() throw() {};
        virtual const char* what () const throw() { return _what.c_str (); };
};


#endif  /* MENUERROR_H */
