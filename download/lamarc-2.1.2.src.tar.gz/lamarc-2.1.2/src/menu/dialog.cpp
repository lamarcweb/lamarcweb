// $Id: dialog.cpp,v 1.21 2003/04/25 19:43:28 ewalkup Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/


#include "menuinteraction.h"
#include "dialog.h"

Dialog::Dialog() : MenuInteraction()
{
}


Dialog::~Dialog()
{
}

