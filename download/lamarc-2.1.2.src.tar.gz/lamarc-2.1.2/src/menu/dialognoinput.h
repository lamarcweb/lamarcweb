//$Id: dialognoinput.h,v 1.10 2004/08/05 18:43:10 ewalkup Exp $

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#ifndef DIALOGNOINPUT_H
#define DIALOGNOINPUT_H

#include "dialog.h"
#include "menudefs.h"
#include "vectorx.h"
#include <string>

class Display;


class DialogNoInput : public Dialog
{
    protected:
        virtual std::string outputString() = 0;
        virtual void performAction();
    public:
        DialogNoInput();
        virtual ~DialogNoInput();
        virtual menu_return_type InvokeMe(Display&);
};

class DialogAcknowledge : public DialogNoInput
{
    public:
        DialogAcknowledge();
        virtual ~DialogAcknowledge();
        virtual menu_return_type InvokeMe(Display&);
};

class DialogChideInconsistencies : public DialogAcknowledge
{
    protected:
        StringVec1d & inconsistencies;
        virtual std::string outputString();
    public:
        DialogChideInconsistencies(StringVec1d & inconsistencies);
        virtual ~DialogChideInconsistencies();
};

#endif /* DIALOGNOINPUT_H */
