//$Id: menudefs.h,v 1.10 2004/08/25 00:20:39 ewalkup Exp $
#ifndef MENUDEFS_H
#define MENUDEFS_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/


enum menu_return_type { menu_GO_UP, menu_REDISPLAY, menu_QUIT, menu_RUN};

#endif /* MENUDEFS_H */
