//$Id: dialogrepeat.h,v 1.8 2004/05/04 18:23:28 ewalkup Exp $

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#ifndef DIALOGREPEAT_H
#define DIALOGREPEAT_H

#include "dialog.h"
#include <string>

class Display;


class DialogRepeat : public Dialog
{
    protected:
        virtual long maxTries() = 0;
        virtual std::string beforeLoopOutputString() = 0;
        virtual std::string inLoopOutputString() = 0;
        virtual std::string inLoopFailureOutputString() = 0;
        virtual std::string afterLoopSuccessOutputString() = 0;
        virtual std::string afterLoopFailureOutputString() = 0;
        virtual bool handleInput(std::string input) = 0;
        virtual void doFailure() = 0;
    public:
        DialogRepeat();
        virtual ~DialogRepeat();
        virtual menu_return_type InvokeMe(Display&);
};

#endif /* DIALOGREPEAT_H */
