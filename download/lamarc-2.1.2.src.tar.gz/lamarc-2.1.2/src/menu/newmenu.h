// $Id: newmenu.h,v 1.20 2007/06/29 22:31:28 lpsmith Exp $
#ifndef NEWMENU_H
#define NEWMENU_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "menudefs.h"
#include "menuinteraction.h"
#include "menuitem.h"
#include <string>
#include "menutypedefs.h"
#include "vectorx.h"

class Display;
class UIInterface;


class NewMenu : public MenuInteraction
{
    protected:
        UIInterface & ui;
        const std::string title;
        const std::string info;
        MenuDisplayQuantaVec afterContent;
        MenuDisplayQuantaVec beforeContent;
        MenuDisplayQuantaVec myContent;
        virtual void AddMenuItem(MenuDisplayQuanta*);
        void fillStandardContent(bool atTop);
    public:
        NewMenu(UIInterface & myui, const std::string myTitle, bool atTop=false);
        NewMenu(UIInterface & myui, const std::string myTitle, const std::string myInfo, bool atTop=false);
        virtual ~NewMenu();
        virtual bool Handles(std::string input);
        virtual MenuInteraction_ptr GetHandler(std::string input);
        virtual menu_return_type InvokeMe(Display&);
        virtual std::string Title();
        virtual std::vector<std::string> Warnings();
        virtual void AddWarning(std::string warning);
        virtual std::string Info();
        virtual MenuDisplayQuantaVec MenuItems();
        virtual StringVec1d GetInconsistencies();
};

class NewMenuCreator
{
    public:
        NewMenuCreator();
        virtual ~NewMenuCreator();
//        virtual NewMenu * Create() = 0;
        virtual NewMenu_ptr Create() = 0;
};

#endif /* NEWMENU_H */
