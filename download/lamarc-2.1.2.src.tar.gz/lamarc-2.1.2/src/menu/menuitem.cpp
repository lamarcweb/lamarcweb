// $Id: menuitem.cpp,v 1.22 2005/07/27 16:34:04 ewalkup Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// menuitem.cpp
// functions to control the menuitem (a single line in a menu)
//
// Peter Beerli

#include "display.h"
#include "errhandling.h"
#include "menuinteraction.h"
#include "menuitem.h"
#include "menutypedefs.h"
#include "stringx.h"
#include "ui_constants.h"
#include <vector>


void
MenuDisplayQuantaVec::NukeContents()
{
    MenuDisplayQuantaVec::iterator iter;
    for(iter = begin(); iter != end(); iter++)
    {
        delete(*iter);
    }
}

MenuInteraction_ptr
MenuDisplayQuantaWithHandler::GetHandler(string key)
{
    return MenuInteraction_ptr(NULL);
}

void MenuDisplayLine::DisplayItemOn(Display & display)
{
    display.ShowMenuDisplayLine(*this);
}

UIId& MenuDisplayLine::GetId()
{
    return NO_ID();
}

bool MenuDisplayLine::IsVisible()
{
    return true;
}

bool MenuDisplayLine::IsConsistent()
{
    return true;
}

void MenuDisplayGroup::DisplayItemOn(Display & display)
{
    display.ShowMenuDisplayGroup(*this);
}

std::vector<UIId> MenuDisplayGroup::GetInconsistentIds()
{
    std::vector<UIId> badIds;   // empty vector => no bad ids!
    return badIds;
}


void MenuDisplayTable::DisplayItemOn(Display & display)
{
    display.ShowMenuDisplayTable(*this);
}

DisplayOnlyGroupWrapper::DisplayOnlyGroupWrapper(MenuDisplayGroup * group)
    : m_group(group)
{
}

DisplayOnlyGroupWrapper::~DisplayOnlyGroupWrapper()
{
    delete m_group;
}

vector<UIId>
DisplayOnlyGroupWrapper::GetVisibleIds()
{
    return m_group->GetVisibleIds();
}

vector<UIId>
DisplayOnlyGroupWrapper::GetInconsistentIds()
{
    vector<UIId> emptyVector;
    return emptyVector;
}

string
DisplayOnlyGroupWrapper::GetKey(UIId id)
{
    return menustr::emptyString;
}

string
DisplayOnlyGroupWrapper::GetText(UIId id)
{
    return m_group->GetText(id);
}

string
DisplayOnlyGroupWrapper::GetVariableText(UIId id)
{
    return m_group->GetVariableText(id);
}

KeyedMenuItem::KeyedMenuItem(const string& myKey)
    : MenuDisplayLine(), key(myKey)
{
}

KeyedMenuItem::~KeyedMenuItem()
{
}

string KeyedMenuItem::GetKey()
{
    return key;
}

bool KeyedMenuItem::Handles(std::string inputKey)
{
    if(IsVisible())
    {
        return CaselessStrCmp(GetKey(),inputKey);
    }
    return false;
}

