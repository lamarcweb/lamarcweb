//$Id: togglemenuitem.cpp,v 1.11 2003/08/11 19:35:54 mkkuhner Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "togglemenuitem.h"
#include "stringx.h"
#include "ui_interface.h"

using std::string;

