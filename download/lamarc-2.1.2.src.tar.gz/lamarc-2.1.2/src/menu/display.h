// $Id: display.h,v 1.20 2006/03/31 00:29:51 ewalkup Exp $
#ifndef DISPLAY_H
#define DISPLAY_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include <vector>

#include "menudefs.h" // for menu_return_type
#include "vectorx.h"

class Dialog;
class NewMenu;
class MenuDisplayQuantaVec;
class MenuDisplayGroup;
class ToggleMenuItem2dGroup;
class MenuDisplayLine;
class MenuDisplayTable;

class Display
{
    public:
        Display() {};
        virtual ~Display(){};
        virtual menu_return_type DisplayNewMenu(NewMenu&) = 0;
        virtual menu_return_type DisplayRaw(StringVec1d) = 0;
        // 
        virtual void ShowMenuDisplayGroup(MenuDisplayGroup&) = 0;
        virtual void ShowMenuDisplay2dGroup(ToggleMenuItem2dGroup&) = 0;
        virtual void ShowMenuDisplayLine(MenuDisplayLine&) = 0;
        virtual void ShowMenuDisplayTable(MenuDisplayTable&) = 0;
        //
        virtual void DisplayDialogOutput(std::string)= 0;
        virtual std::string GetUserInput()=0;
};

class ScrollingDisplay : public Display
{
    protected:
        void ShowMenuDisplayQuantaVec(MenuDisplayQuantaVec);
        void Prompt();
        void Title(const std::string & title, const std::string & info);
        void DisplayOneLine(std::string);
        void ShowOneMenuLine(std::string,std::string,std::string);
        std::vector<std::string> BreakAtCarriageReturns(std::string);
        std::vector<std::string> MakeDisplayableUnits(std::string, long width);
        void ChideOnInconsistencies(StringVec1d inconsistencies);
    public:
        ScrollingDisplay();
        ~ScrollingDisplay();
        //
        virtual menu_return_type DisplayNewMenu(NewMenu&);
        virtual menu_return_type DisplayRaw(StringVec1d);
        //
        virtual void ShowMenuDisplayGroup(MenuDisplayGroup&);
        virtual void ShowMenuDisplay2dGroup(ToggleMenuItem2dGroup&);
        virtual void ShowMenuDisplayLine(MenuDisplayLine&);
        virtual void ShowMenuDisplayTable(MenuDisplayTable&);
        //
        virtual void DisplayDialogOutput(std::string);
        virtual std::string GetUserInput();
        //
        void Warn(std::vector<std::string> warnings);
};

class NoDisplay : public Display 
{
    public:
        NoDisplay() ;
        ~NoDisplay();
        virtual menu_return_type DisplayNewMenu(NewMenu&);
        virtual menu_return_type DisplayRaw(StringVec1d);
        //
        virtual void ShowMenuDisplayGroup(MenuDisplayGroup&);
        virtual void ShowMenuDisplay2dGroup(ToggleMenuItem2dGroup&);
        virtual void ShowMenuDisplayLine(MenuDisplayLine&);
        virtual void ShowMenuDisplayTable(MenuDisplayTable&);
        //
        virtual void DisplayDialogOutput(std::string);
        virtual std::string GetUserInput();
};


#endif  /* DISPLAY_H */
