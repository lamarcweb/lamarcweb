//$Id: togglemenuitem.h,v 1.15 2004/05/04 18:23:28 ewalkup Exp $
#ifndef TOGGLEMENUITEM_H
#define TOGGLEMENUITEM_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// $Id: togglemenuitem.h,v 1.15 2004/05/04 18:23:28 ewalkup Exp $

#include <string>
#include "constants.h" // for proftype
#include "menuinteraction.h"
#include "newmenuitems.h"

class UIInterface;
class Display;


#endif  /* TOGGLEMENUITEM_H */
