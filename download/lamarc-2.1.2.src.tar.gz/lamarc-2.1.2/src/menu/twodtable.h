//$Id: twodtable.h,v 1.4 2004/05/04 18:23:28 ewalkup Exp $
#ifndef TWODTABLE_H
#define TWODTABLE_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// $Id: twodtable.h,v 1.4 2004/05/04 18:23:28 ewalkup Exp $

#include <string>
#include "menuitem.h"

class Display;
class UIInterface;

class TwoDTable : public MenuDisplayTable
{
    protected:
        UIInterface & ui;
        virtual long ColCount(UIInterface & ui) = 0;
        virtual long RowCount(UIInterface & ui) = 0;
        virtual std::string Title(UIInterface & ui) = 0;
        virtual std::string RowHeader(UIInterface & ui);
        virtual std::string ColLabel(UIInterface & ui, long index) = 0;
        virtual std::string RowLabel(UIInterface & ui, long index) = 0;
        virtual std::string Cell(UIInterface & ui, long rowIndex, long colIndex) = 0;
        std::string CreateDisplayString(UIInterface & myui);
    public:
        TwoDTable(UIInterface & myui);
        virtual ~TwoDTable();
        virtual bool IsVisible();
        std::string CreateDisplayString();
};

#endif  /* TWODTABLE_H */
