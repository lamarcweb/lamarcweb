//$Id: menutypedefs.h,v 1.2 2004/05/04 18:23:28 ewalkup Exp $

#ifndef MENUTYPEDEFS_H
#define MENUTYPEDEFS_H

#include <memory>

class NewMenu;
//typedef boost::shared_ptr<NewMenu> NewMenu_ptr;
typedef std::auto_ptr<NewMenu> NewMenu_ptr;
class MenuInteraction;
//typedef boost::shared_ptr<MenuInteraction> MenuInteraction_ptr;
typedef std::auto_ptr<MenuInteraction> MenuInteraction_ptr;

#endif /* MENUTYPEDEFS_H */
