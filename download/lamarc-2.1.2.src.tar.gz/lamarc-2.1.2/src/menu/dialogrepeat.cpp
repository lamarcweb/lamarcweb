//$Id: dialogrepeat.cpp,v 1.9 2004/08/25 00:20:39 ewalkup Exp $
/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "dialog.h"
#include "dialogrepeat.h"
#include "display.h"
#include "menudefs.h"
#include "ui_constants.h"
#include <string>

using std::string;

DialogRepeat::DialogRepeat() : Dialog()
{
}

DialogRepeat::~DialogRepeat()
{
}


menu_return_type DialogRepeat::InvokeMe(Display& display)
{
    display.DisplayDialogOutput(beforeLoopOutputString());
    for(int i=0;i<maxTries();i++)
    {
        display.DisplayDialogOutput(inLoopOutputString());
        std::string result = display.GetUserInput();
        if (handleInput(result))
        {
            display.DisplayDialogOutput(afterLoopSuccessOutputString());
            return menu_REDISPLAY;
        }
        else
        {
            display.DisplayDialogOutput(inLoopFailureOutputString());
        }
    }
    display.DisplayDialogOutput(afterLoopFailureOutputString());
    doFailure();
    return menu_REDISPLAY;
}
