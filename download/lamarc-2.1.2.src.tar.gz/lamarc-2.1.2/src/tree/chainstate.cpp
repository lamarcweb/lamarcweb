// $Id: chainstate.cpp,v 1.13 2007/09/28 22:00:13 lpsmith Exp $

/*
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <assert.h>
#include "chainstate.h"
#include "tree.h"

// WARNING:  This code assumes that no operation changes more than one
// of the Tree, the Jointed Stick, and the Parameters at the same time!
// If such changes can occur this scheme will have to be heavily revised!

//_______________________________________________________________________

ChainState::ChainState()
  : m_tree(NULL),
    m_oldtree(NULL),
    m_parameters(global_region),
    m_oldparameters(global_region),
    //Since the ChainState works in region space, this will require that both
    // of these member variables get overwritten before being used.  In other
    // words, 'global_region' is wrong, and it's set to that on purpose
    // because it's a flag that it's wrong.
    unsampled_tree(true),
    unsampled_parameters(true),
    unsampled_stick(true),
    unsampled_map(true),
    unexported_parameters(true)
{
  // deliberately blank
} /* ctor */

//_______________________________________________________________________

ChainState::ChainState(const ChainState& src)
  : m_tree(src.m_tree), // yes, a shallow copy
    m_parameters(src.m_parameters),
    m_oldparameters(src.m_oldparameters),
    unsampled_tree(src.unsampled_tree),
    unsampled_parameters(src.unsampled_parameters),
    unsampled_stick(src.unsampled_stick),
    unsampled_map(src.unsampled_map),
    unexported_parameters(src.unexported_parameters)
{
   if (m_tree) m_oldtree = src.m_tree->Clone();  // deep copy
   else m_oldtree = NULL;

} /* copy ctor */

//_______________________________________________________________________

ChainState::~ChainState()
{
  delete m_oldtree;
} /* dtor */

//_______________________________________________________________________

ChainState& ChainState::operator=(const ChainState& src)
{
  m_tree = src.m_tree;  // yes, a shallow copy

  delete m_oldtree;
  if (m_tree) m_oldtree = src.m_tree->Clone();  // deep copy
  else m_oldtree = NULL;

  m_parameters = src.m_parameters;
  m_oldparameters = src.m_oldparameters;
  unsampled_tree = src.unsampled_tree;
  unsampled_parameters = src.unsampled_parameters;
  unsampled_stick = src.unsampled_stick;
  unsampled_map = src.unsampled_map;
  unexported_parameters = src.unexported_parameters;
  return *this;
} /* operator= */

//_______________________________________________________________________

void ChainState::SetTree(Tree* tree)
// This routine sets m_tree and then makes m_oldtree a tips-and-stump-and-stick
// copy of it
{
  assert(tree);   // We can't set things up with no tree!
  m_tree = tree;
  delete m_oldtree;
  m_oldtree = m_tree->MakeStump();
  m_oldtree->CopyTips(m_tree);
  m_oldtree->GetTimeList().CopyStick(m_tree->GetTimeList());
  TreeChanged();
  if (m_tree->GetTimeList().NoStick()) unsampled_stick = false;
  else StickChanged();

} /* SetTree */

//_______________________________________________________________________

void ChainState::SetOldTree(Tree* tree)
  // This routine sets m_oldtree to be a full, valid copy of tree.
  // Added October 2004 by erynes for use by ChainManager.
{
  assert(tree);   // We can't set things up with no tree!
  m_oldtree->CopyTips(tree);
  m_oldtree->CopyBody(tree);
  m_oldtree->GetTimeList().CopyStick(tree->GetTimeList());
  // NB This is called only at the start of a chain; therefore, it does 
  // not need to mark the tree as modified.  Be careful if using it
  // anywhere else!  --Mary
} /* SetOldTree */

//_______________________________________________________________________

void ChainState::UpdateStickParams()
{
  m_tree->SetStickParams(m_parameters);
  m_oldtree->SetStickParams(m_parameters);
} /* UpdateStickParams */

//_______________________________________________________________________

void ChainState::SimulateDataIfNeeded()
{
  assert(m_tree);   // We can't set things up with no tree!
  if (m_tree->SimulateDataIfNeeded()) {
    //This changes the tips, so:
    m_oldtree->CopyTips(m_tree);
    m_oldtree->CopyBody(m_tree);
    // we assume the stick is still germane
  }
} /* SimulateDataIfNeeded */

//_______________________________________________________________________

void ChainState::SetParameters(const ForceParameters& params)
{
  m_parameters = params;
  ParametersChanged();
} /* SetParameters */

//_______________________________________________________________________

void ChainState::OverwriteOldTree()
{
  m_oldtree->CopyBody(m_tree);
  m_oldtree->CopyStick(m_tree);
} /* OverwriteOldTree */

//_______________________________________________________________________

void ChainState::OverwriteTree()
{
  m_tree->CopyBody(m_oldtree);
  m_tree->CopyStick(m_oldtree);
  TreeChanged();
} /* OverwriteTree */

//_______________________________________________________________________

void ChainState::OverwriteParameters()
{
  m_parameters = m_oldparameters;
} /* OvewriteParameters */

//_______________________________________________________________________

void ChainState::OverwriteOldParameters()
{
  m_oldparameters = m_parameters;
} /* OvewriteOldParameters */

//_______________________________________________________________________

void ChainState::TreeChanged()
{
  unsampled_tree = true;
  unsampled_map  = true; //Only actually true if we're doing a floating
  //                       analysis, but probably not worth checking.
} /* TreeChanged */

//_______________________________________________________________________

void ChainState::ParametersChanged()
{
  unsampled_parameters = true;
  unexported_parameters = true;
} /* ParametersChanged */

//_______________________________________________________________________

void ChainState::StickChanged()
{
  unsampled_stick = true;
} /* StickChanged */

//____________________________________________________________________

void ChainState::MapChanged()
{
  unsampled_map = true;
} /* MapChanged */

//____________________________________________________________________

void ChainState::AllChanged()
{ 
  TreeChanged();
  ParametersChanged();
  if (!m_tree->GetTimeList().NoStick()) {
    StickChanged();
  }
  MapChanged();
} /* AllChanged */

//____________________________________________________________________

void ChainState::SwapParameters(ChainState& other)
{
  std::swap(m_parameters, other.m_parameters);
  std::swap(m_oldparameters, other.m_oldparameters);
  ParametersChanged();
  other.ParametersChanged();
} /* SwapParameters */

//____________________________________________________________________
//____________________________________________________________________
