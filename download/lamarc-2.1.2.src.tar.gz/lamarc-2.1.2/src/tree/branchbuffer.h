// $Id: branchbuffer.h,v 1.5 2007/09/13 00:12:27 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// This files defines a time ordered container of Branch_ptr,
// BranchBuffer.  The BranchBuffer
// is a storage buffer used during rearrangement to store active and
// inactive branches.

#ifndef BRANCHBUFFER_H
#define BRANCHBUFFER_H

#include <vector>
#include "vectorx.h"
#include <map>
#include "defaults.h"
#include "definitions.h"
#include "types.h"
#include "branch.h"

// #include "branch.h"--to create the "base" branch, TimeList constructor
//                      to create a Tbranch, CreateTip
//                      to initialize branch innards, both of the above
//                      to maintain tree child & parent relationships
//                         in CopyBody()
//                      to maintain tree child & parent relationships
//                         in CopyPartialBody()
//                      to track ncuttable via branch.Cuttable()
//                      to track marked status via branch.marked,
//                         branch.SetUpdateDL()

class TipData;
class DataPack;

class BranchBuffer
{
private:
Branchlist branches;      // we do not own these branches!
LongVec1d m_branchxparts; // dim: cross partitions
LongVec2d m_branchparts;  // dim: partition force X partitions

BranchBuffer(const BranchBuffer& src);            // undefined
BranchBuffer& operator=(const BranchBuffer& src); // undefined
BranchBuffer();                                   // undefined

long GetNBranches(force_type force, const LongVec1d& membership) const;
long GetNPartBranches(force_type force, long part) const;


public:
BranchBuffer(const DataPack& dpack);
~BranchBuffer()                            {};
void Clear();
LongVec2d GetBranchParts()                    const {return m_branchparts;};
LongVec1d GetBranchParts(force_type force)    const;
LongVec1d GetBranchXParts()                   const;
void Append(Branch_ptr newbranch);
void Append(std::vector<Branch_ptr> newbranches);
void AddAfter(Branchiter here, Branch_ptr newbranch);
void Collate(Branch_ptr newbranch);
long Size()                          const {return branches.size();};
Branchiter Begin()                         {return branches.begin();};
Branchiter End()                           {return branches.end();};
void       Remove(Branchiter here);
void       Remove(Branch_ptr branch);
Branch_ptr GetFirst();
Branch_ptr RemoveFirst();
Branch_ptr RemoveBranch(force_type force, long xpartindex, double rnd);
Branch_ptr RemoveBranch(force_type force, const LongVec1d& membership, 
   double rnd);
Branch_ptr RemovePartitionBranch(force_type force, long part, double rnd);

// This routine updates the "current branch count" storage in the
// BranchBuffer to make its count of partitions and crosspartitions
// accurate for a new time slice.  Passing true means that the
// partitions being passed are newly added; passing false means
// that they are newly removed.  For example, if you were moving down
// past a coalescence, you would want to remove the two lineages
// that were coalescing, and add the lineage they coalesce into.

void UpdateBranchCounts(const LongVec1d& newpartitions, bool addbranch = true);

// meant to only be used on arranger::inactivelist().
double  IntervalBottom();
double  NextIntervalBottom();

// used by TreeSizeArranger
vector<Branch_ptr> ExtractConstBranches() const;

// debugging
void PrintEvents() const;
void PrintRanges() const;
};


#endif /* BRANCHBUFFER_H */
