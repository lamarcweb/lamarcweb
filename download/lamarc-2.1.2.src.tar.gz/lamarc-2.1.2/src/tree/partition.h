// $Id: partition.h,v 1.4 2004/08/05 18:43:10 ewalkup Exp $

#ifndef PARTITION_H
#define PARTITION_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <map>
#include <vector>
#include <string>
#include "vectorx.h"
#include "defaults.h"  // for force_type definition

class TimeSize;

class XPartition
{
private:
LongVec1d m_membership;          // branch membership match
TimeSize* m_sizeat;              // size formula, owning pointer
vector<XPartition*> m_partners;  // related xpartitions
bool m_hasparam;                 

// way to find jointed stick? can't be pointer due to tree copying
// way to find appropiate theta and g (if any)

public:
XPartition() : m_sizeat(NULL) {};
~XPartition();

bool HasParam() const {return m_hasparam;};

void SetHasParam(bool val) { m_hasparam = val; };

};

//____________________________________________________________________
//____________________________________________________________________

class Partition
{

private: 
vector<XPartition*> m_xparts;  // non-owning 
string m_forcename;            // what force are we part of?

public:
Partition(const string& fname) : m_forcename(fname) {};
~Partition() {};

};

//____________________________________________________________________
//____________________________________________________________________


class PartitionNames : public std::map<force_type,StringVec1d>
{
    public:
        PartitionNames() { std::map<force_type,StringVec1d>();};
        ~PartitionNames(){};
};

class PartitionSummary
{

private:
vector<Partition> m_partitions;
vector<XPartition> m_xpartitions;

PartitionNames m_partnames;
StringVec1d m_outputpopnames; // in the single population case
                              // save the MIG partition names here
LongVec1d m_finalcount; // this is set by SetFinalPartitionCounts()

public:
// we accept the default ctor, copy-ctor and dtor

long AddPartition(const string& forcename, const string& partname);

long GetNPartitions(const string& forcename) const;
string GetPartitionName(const string& forcename, long index) const;
long GetPartitionNumber(const string& forcename, const string& name) const;
StringVec1d GetAllPartitionNames(force_type) const;
StringVec1d GetAllCrossPartitionNames() const;

// this function is provided to interface with tipdata objects
// it's also used by GetAllCrossPartitionNames which needs to pass
// false as an argument (it cares about partition forces with only
// one partition.
std::vector<std::map<string,string> >
GetCrossPartitionIds(bool ignoresinglepop = true) const;

// this function will return 0 if the membership vector is empty.
// it does this to interface with the BranchBuffer and
// Branch::ScoreEvent?
long GetCrossPartitionIndex(const LongVec1d& membership) const;
LongVec1d GetBranchMembership(long xpartindex) const;
std::map<string,string> GetTipId(long xpartindex) const;

long GetNPartitionForces() const;
long GetNCrossPartitions() const;
long GetNPartitions(unsigned long index) const;
LongVec1d GetAllNPartitions() const;

// called by ForceSummary::SummarizeData
void SetFinalPartitionCounts(LongVec1d pcounts);

};


#endif /* PARTITION_H */
