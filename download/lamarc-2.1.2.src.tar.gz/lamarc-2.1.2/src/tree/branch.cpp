// $Id: branch.cpp,v 1.61 2007/09/28 22:00:13 lpsmith Exp $
/* 
   Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include "branch.h"
#include <algorithm>
#include "treesum.h"
#include "summary.h"
#include "datapack.h"
#include "branchbuffer.h"
#include <numeric>    // for std::accumulate

#include "force.h"  // for RBranch::RecCopyPartitionsFrom
                    //     Branch::IsAMember
#include "locus.h"  // for TipData stuff used in ctor

#ifdef DMALLOC_FUNC_CHECK
#include <dmalloc.h>
#endif

using namespace std;

Branch_ptr Branch::NONBRANCH;

string ToString(branch_type btype)
{
  switch(btype) {
  case btypeBase:   return "Base";
  case btypeTip:    return "Tip";
  case btypeCoal:   return "Coalescence";
  case btypeMig:    return "Migration";
  case btypeDisease:return "Disease";
  case btypeRec:    return "Recombination";
  case btypeStick:  return "Jointed Stick";
  }
  assert(false);
  return "";
}

//_________________________________________________

Branch::Branch(Range protorange)
  : m_parents(NELEM,Branch::NONBRANCH),
    m_children(NELEM,Branch::NONBRANCH),
    m_ID(),
    m_equivBranch(Branch::NONBRANCH),
    m_partitions(registry.GetDataPack().GetNPartitionForces(),FLAGLONG),
    m_range(protorange)
{
  m_eventtime   = 0.0;
  m_updateDL    = false;
  m_marked      = false;

} /* Branch::Branch */

//_________________________________________________

Branch::~Branch()
{
  // no need to delete due to use of shared_ptr
} /* Branch destructor */

//_________________________________________________

Branch::Branch(const Branch& src)
  : m_parents(NELEM,Branch::NONBRANCH),
    m_children(NELEM,Branch::NONBRANCH),
    m_equivBranch(Branch::NONBRANCH),
    m_range(src.m_range)
{

  CopyAllMembers(src);

} /* Branch copy ctor */

//_________________________________________________

Branch::Branch(const Branch& src, bool nodlcells)
  : m_parents(NELEM,Branch::NONBRANCH),
    m_children(NELEM,Branch::NONBRANCH),
    m_ID(src.m_ID),
    m_equivBranch(Branch::NONBRANCH),
    m_range(src.m_range)
{
  assert(nodlcells); // copy ctor only for no dlcells!

  m_eventtime  = src.m_eventtime;
  m_partitions = src.m_partitions;
  m_updateDL   = src.m_updateDL;
  m_marked     = src.m_marked;
 
} /* Branch dlcell-lacking copy ctor */

//_________________________________________________

void Branch::CopyAllMembers(const Branch& src)
{
  fill(m_parents.begin(),m_parents.end(),Branch::NONBRANCH);
  fill(m_children.begin(),m_children.end(),Branch::NONBRANCH);


  m_ID         = src.m_ID;
  m_eventtime  = src.m_eventtime;
  m_partitions = src.m_partitions;
  m_updateDL   = src.m_updateDL;
  m_marked     = src.m_marked;
  m_range      = src.m_range;
  m_dlcells    = src.m_dlcells;
  m_movingDLcells = src.m_movingDLcells; 
 
} /* Branch::CopyAllMembers */

//_________________________________________________

bool Branch::IsAMember(const Force& force, const LongVec1d& membership) const
{
  return force.IsAMember(m_partitions,membership);
} /* Branch::IsAMember */

//_________________________________________________

bool Branch::UpdateFCToInclude(rangeset fc)
{
  return m_range.UpdateFCToInclude(fc);
}

//_________________________________________________

void Branch::UpdateFCToExclude(rangeset nofc)
{
  m_range.UpdateFCToExclude(nofc);
}
//_________________________________________________

// Checks if two branches are functionally the same.
// If you want full equivalency use operator==().
bool Branch::IsEquivalentTo(const Branch_ptr twin)   const
{

  return m_ID == twin->m_ID;
#if 0
  if (Event() != twin->Event()) {
    // cout << "Different events" << endl;
    return false;
  }
  if (m_partitions != twin->m_partitions) {
    // cout << "Different partitions" << endl;
    return false;
  }
  if (m_range.GetActiveSites() != twin->m_range.GetActiveSites()) {
    // cout << "Different Active sites" << endl;
    return false;
  }
  if (m_range.GetRecsite() != twin->m_range.GetRecsite()) {
    // cout << "Different recombination site" << endl;
    return false;
  }
  if (m_eventtime != twin->m_eventtime) {
    // cout << "Different event times" << endl;
    return false;
  }
  return true;
#endif

} /*IsEquivalentTo */
//_________________________________________________

bool Branch::HasSamePartitionsAs(const Branch_ptr twin)   const
{
  if (twin) {
    if (m_partitions != twin->m_partitions) {
      return false;
    }
  }
  return true;
} /*HasSamePartitionsAs */

//_________________________________________________

bool Branch::PartitionsConsistentWith(const Branch_ptr child)   const
{
  assert(Event() == btypeRec); //
  if (child) {
    const ForceSummary& fs = registry.GetForceSummary();
    if (fs.CheckForce(force_DISEASE)) {
      if (m_range.IsAlwaysActiveInRange()) {
        long diseaseIndex = fs.GetPartIndex(force_DISEASE);
        long diseaseState = child->GetDisease();
        if (diseaseState != m_partitions[diseaseIndex]) {
          return false;
        }
      }
    }
  }
  return true;
} /*HasSamePartitionsAs */

//_________________________________________________

LongVec1d Branch::GetLocalPartitions() const
{
  LongVec1d lppartitions;
  LongVec1d lpindex(registry.GetForceSummary().GetLocalPartitionIndexes());
  LongVec1d::iterator lpforce;
  for(lpforce = lpindex.begin(); lpforce != lpindex.end(); ++lpforce) {
    lppartitions.push_back(m_partitions[*lpforce]);
  }
  return lppartitions;

} /* GetLocalPartitions */

//_________________________________________________

long Branch::GetPopulation() const
{
  return m_partitions[registry.GetForceSummary().GetPartIndex(force_MIG)];
} /* Branch::GetPopulation */

//_________________________________________________

void Branch::SetPopulation(long pop)
{
  m_partitions[registry.GetForceSummary().GetPartIndex(force_MIG)] = pop;
} /* Branch::SetPopulation */

//_________________________________________________

long Branch::GetDisease() const
{
  return m_partitions[registry.GetForceSummary().GetPartIndex(force_DISEASE)];
} /* Branch::GetDisease */

//_________________________________________________

void Branch::SetDisease(long dis)
{
  m_partitions[registry.GetForceSummary().GetPartIndex(force_DISEASE)] = dis;
} /* Branch::SetDisease */

//_________________________________________________

long Branch::GetID() const
{
  return m_ID.ID();
}

//_________________________________________________

weakBranch_ptr Branch::GetEquivBranch() const
{
  return m_equivBranch;
}

//_________________________________________________

void Branch::SetEquivBranch(Branch_ptr twin)
{
  m_equivBranch = twin;
}

//_________________________________________________

long Branch::GetPartition(force_type force) const
{
  return m_partitions[registry.GetForceSummary().GetPartIndex(force)];
} /* Branch::GetDisease */

//_________________________________________________

void Branch::CopyPartitionsFrom(Branch_ptr src)
{
  m_partitions = src->m_partitions;

} /* Branch::CopyPartitionsFrom */

//_________________________________________________

void Branch::MarkParentsForDLCalc()
{

  // evil kludge necessary because we force parents/children
  // to always have two spaces even when empty!

  if (!m_parents[0].expired()) {
    Branch_ptr parent0(m_parents[0]);
    if (!parent0->m_updateDL) {
      parent0->SetUpdateDL();
      parent0->MarkParentsForDLCalc();
    }
  }

  if (!m_parents[1].expired()) {
    Branch_ptr parent1(m_parents[1]);
    if (!parent1->m_updateDL) {
      parent1->SetUpdateDL();
      parent1->MarkParentsForDLCalc();
    }
  }

} /* Branch::MarkParentsForDLCalc */

//_________________________________________________

void Branch::ReplaceChild(Branch_ptr, Branch_ptr newchild)
{
  newchild->m_parents[0] = shared_from_this();
  m_children[0]          = newchild;

} /* Branch::ReplaceChild */

//_________________________________________________

bool Branch::HasSameActive(const Branch& br)
{
  return m_range.SameActive(br.m_range.GetActiveSites());

} /* Branch::HasSameActive */

//_________________________________________________
const Cell_ptr Branch::GetDLCell(long loc, long ind, bool moving)      const 
{
  if (moving) {
    assert(loc < static_cast<long>(m_movingDLcells.size()));
    assert(ind < static_cast<long>(m_movingDLcells[loc].size()));
    return m_movingDLcells[loc][ind];
  }
  else {
    assert(loc < static_cast<long>(m_dlcells.size()));
    assert(ind < static_cast<long>(m_dlcells[loc].size()));
    return m_dlcells[loc][ind];
  }
}
//_________________________________________________
Cell_ptr Branch::GetDLCell(long loc, long ind, bool moving)
{
  if (moving) {
    assert(loc < static_cast<long>(m_movingDLcells.size()));
    assert(ind < static_cast<long>(m_movingDLcells[loc].size()));
    return m_movingDLcells[loc][ind];
  }
  else {
    assert(loc < static_cast<long>(m_dlcells.size()));
    assert(ind < static_cast<long>(m_dlcells[loc].size()));
    return m_dlcells[loc][ind];
  }
}
//_________________________________________________

double Branch::HowFarTo(const Branch& br) const
{
  return fabs(br.m_eventtime - m_eventtime);

} /* Branch::HowFarTo */

//_________________________________________________

Branch_ptr Branch::GetValidChild(Branch_ptr br, long whichpos)
{

  Branch_ptr pChild = br->GetActiveChild(whichpos);
  if (pChild)
    br = GetValidChild(pChild,whichpos);

  return br;

} /* Branch::GetValidChild */

//_________________________________________________

Branch_ptr Branch::GetValidParent(long whichpos)
{
  // We are looking for an ancestor of our branch at which
  // the site of interest coalesces

  Branch_ptr pParent(Parent(0));
  if (Parent(1)) { 
    // this branch has two parents; which one is needed?
    if (Parent(1)->m_range.IsSiteActive(whichpos)) pParent = Parent(1);
  }

  // If we have reached the bottom of the tree, we give up--there
  // is no parent.

  if (pParent->Event() == btypeBase) return Branch::NONBRANCH;
 
  // Otherwise, check if this could be the parent we need

  if (pParent->Event() == btypeCoal) {
    // this could be the coalescence we're looking for, but
    // does our site actually coalesce here?
    if (pParent->Child(0)->m_range.IsSiteActive(whichpos) &&
        pParent->Child(1)->m_range.IsSiteActive(whichpos)) {
      return pParent;
    }
  }

  // it's not a coalescence (or the right coalescence), so keep going downward
  return pParent->GetValidParent(whichpos);

} /* GetValidParent */

//_________________________________________________

bool Branch::DiffersInDLFrom(Branch_ptr branch, long locus, long marker) const
{
  return m_dlcells[locus].DiffersFrom(branch->m_dlcells[locus],marker);

} /* Branch::DiffersInDLFrom */

//_________________________________________________

bool Branch::CheckInvariant() const
{
  // check correct time relationships among parents and offspring
  long index;
  for (index = 0; index < NELEM; ++index) {
    // if the child exists it must be earlier
    if (Child(index)) {
      if (Child(index)->m_eventtime > m_eventtime) {
        return false;
      }
    }
    // if the parent exists it must be later
    if (Parent(index)) {
      if (Parent(index)->m_eventtime < m_eventtime) {
        return false;
      }
    }
  }

  return true;

} /* CheckInvariant */

//_________________________________________________

bool Branch::operator==(const Branch& src) const
{
  if (Event() != src.Event()) return false;
  if (m_partitions != src.m_partitions) return false;
  if (m_eventtime != src.m_eventtime) return false;
  
  return true;

} /* operator== */

//_________________________________________________

string Branch::DLCheck(const Branch& other) const
{
  unsigned long locus;
  string problems;
  if (m_dlcells.size() != other.m_dlcells.size()) {
    return string("   The dlcells are different sizes--error\n");
  }
  for (locus = 0; locus < m_dlcells.size(); ++locus) {
    unsigned long ncells = m_dlcells[locus].size();
    if (ncells != other.m_dlcells[locus].size())
      return string("   Bad branch comparison--error\n");

    unsigned long ind;
    for (ind = 0; ind < ncells; ++ind) {
      long badmarker = m_dlcells[locus][ind]->DiffersFrom(other.m_dlcells[locus][ind]);
      if (badmarker == FLAGLONG) continue;

      problems += "   Branch " + ToString(m_ID.ID());
      problems += " differs from other branch " + ToString(other.m_ID.ID());
      problems += " at marker " + ToString(badmarker);
      problems += "\n";
      return problems;
    }

  }

  return problems;

} /* Branch::DLCheck */

//_________________________________________________

void Branch::PrintInfo() const
{
  cout << "Event type:  " << ToString(Event()) << endl;
  cout << "ID: " << m_ID.ID() << endl;
  cout << "Partitions:  ";
  for (unsigned long i=0; i<m_partitions.size(); i++) {
    cout << m_partitions[i] << " ";
  }
  cout << endl;
  cout << "Event time:  " << m_eventtime << endl;
  m_range.PrintInfo();
}

//_________________________________________________

vector<Branch_ptr> Branch::GetChildren()
{
  vector<Branch_ptr> newkids;
  vector<weakBranch_ptr>::iterator kid;
  for(kid = m_children.begin(); kid != m_children.end(); ++kid) {
    newkids.push_back(kid->lock());
  }
  return newkids;
}

//_________________________________________________
// this function is non-const because we need boost::shared_from_this()!
bool Branch::ConnectedTo(const Branch_ptr family)
{
  if (Child(0) && Child(0) == family) return true;
  if (Child(1) && Child(1) == family) return true;
  if (Parent(0) && Parent(0) == family) return true;
  if (Parent(1) && Parent(1) == family) return true;

  cout << endl << "Branch " << family->m_ID.ID();
  cout << " is not connected to branch " << m_ID.ID() << " ";
  cout << "even though it thinks it is via it's ";

  Branch_ptr me(shared_from_this());
  if (family->Child(0) && family->Child(0) == me) cout << "child0";
  if (family->Child(1) && family->Child(1) == me) cout << "child1";
  if (family->Parent(0) && family->Parent(0) == me) cout << "parent0";
  if (family->Parent(1) && family->Parent(1) == me) cout << "parent1";
  cout << endl;
  return false;
}

//_________________________________________________

bool Branch::IsSameExceptForTimes(const Branch_ptr other) const
{
  if (Event() != other->Event()) return false;
  if (m_partitions != other->m_partitions) return false;
  
  return true;
}

//_________________________________________________
//_________________________________________________

BBranch::BBranch()
  : Branch(Range(0L, registry.GetForceSummary().GetSelectedSites()))
{
} /*BBranch default constructor */

//_________________________________________________

Branch_ptr BBranch::Clone(bool copydlcells) const
{
  if (copydlcells) return Branch_ptr(new BBranch(*this));
  else return Branch_ptr(new BBranch(*this,!copydlcells));

} /* BBranch::Clone */

//_________________________________________________

void BBranch::ScoreEvent(TreeSummary&, BranchBuffer&) const
{
  assert(false);  // I don't think this should ever be called
} /* BBranch::ScoreEvent */

//_________________________________________________

void BBranch::ScoreEvent(TreeSummary&, BranchBuffer&, long&) const
{
  assert(false);  // I don't think this should ever be called
} /* BBranch::ScoreEvent */

//_________________________________________________

bool BBranch::CheckInvariant() const
{

  // Base branches have no parents...
  long index;
  for (index = 0; index < NELEM; ++index) {
    if (Parent(index)) return false;
  }

  // ...and one child
  if (!Child(0)) return false;
  if (Child(1)) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________
//_________________________________________________

TBranch::TBranch(const TipData& tipdata, Range protorange)
  : Branch(protorange)
{
  m_partitions = tipdata.GetBranchPartitions();
  m_label = tipdata.label;
  // WARNING:  must be changed for sequential-sampling case
  m_eventtime = 0.0;
} /* TBranch ctor */

//_________________________________________________

TBranch::TBranch(const TBranch& src, bool nodlcells)
  : Branch(src,nodlcells), m_label(src.m_label)
{
} /* specialized TBranch copy ctor */

//_________________________________________________

Branch_ptr TBranch::Clone(bool copydlcells) const
{
  if (copydlcells) return Branch_ptr(new TBranch(*this));
  else return Branch_ptr(new TBranch(*this,!copydlcells));

} /* TBranch::Clone */

//_________________________________________________

bool TBranch::CheckInvariant() const
{

  // Tip branches have no children...
  long index;
  for (index = 0; index < NELEM; ++index) {
    if (Child(index)) return false;
  }

  // ...and at least one parent
  if (!Parent(0)) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________

bool TBranch::operator==(const Branch& src) const
{

  return ((Branch::operator==(src)) && 
          (m_label == dynamic_cast<const TBranch&>(src).m_label));

} /* operator== */

//_________________________________________________

bool TBranch::IsSameExceptForTimes(const Branch_ptr src) const
{

  return ((Branch::IsSameExceptForTimes(src)) && 
          (m_label == boost::dynamic_pointer_cast<const TBranch>(src)->m_label));

} /* IsSameExceptForTimes */

//_________________________________________________

void TBranch::ScoreEvent(TreeSummary&, BranchBuffer&) const
{
  assert(false); // I don't think this should ever be called

} /* TBranch::ScoreEvent */

//_________________________________________________

void TBranch::ScoreEvent(TreeSummary&, BranchBuffer&, long&) const
{
  assert(false); // I don't think this should ever be called

} /* TBranch::ScoreEvent */

//_________________________________________________
//_________________________________________________

Branch_ptr CBranch::Clone(bool copydlcells) const
{
  if (copydlcells) return Branch_ptr(new CBranch(*this));
  else return Branch_ptr(new CBranch(*this,!copydlcells));

} /* CBranch::Clone */

//_________________________________________________

bool CBranch::CanRemove(Branch_ptr checkchild)
{
  if (m_marked) return true;

  m_marked = true;
  if (Child(0) == checkchild) SetChild(0,Child(1));
  SetChild(1,Branch::NONBRANCH);
  return false;

} /* CBranch::CanRemove */

//_________________________________________________

bool CBranch::UpdateRange(bool dofc)
{
  if (m_marked) return m_range.UpdateMRange(Child(0)->m_range, dofc);

  return m_range.UpdateCRange(Child(0)->m_range,Child(1)->m_range, dofc);

} /* CBranch::UpdateRange */

//_________________________________________________

void CBranch::ReplaceChild(Branch_ptr pOldChild, Branch_ptr pNewChild)
{
  if (Child(0) == pOldChild) SetChild(0,pNewChild);
  else SetChild(1,pNewChild);

  pNewChild->SetParent(0,shared_from_this());

} /* CBranch::ReplaceChild */

//_________________________________________________

Branch_ptr CBranch::OtherChild(Branch_ptr badchild)
{
  if (Child(0) == badchild) return Child(1);

  return Child(0);

} /* CBranch::OtherChild */

//_________________________________________________

// If both children are active return Branch::NONBRANCH to signal a stop,
// otherwise return the child that is active.
const Branch_ptr CBranch::GetActiveChild(long site)  const
{
  if (Child(0)->m_range.IsSiteActive(site)) {
    if (Child(1)->m_range.IsSiteActive(site)) return Branch::NONBRANCH;
    return Child(0);
  } else
    return Child(1);

} /* CBranch::GetActiveChild */

//_________________________________________________

void CBranch::ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const
{
  Summary* csum = summary.GetSummary(force_COAL);

  // forces have become inconsistent!
  assert(dynamic_cast<CoalSummary*>(csum));

  long myxpart = registry.GetDataPack().
    GetCrossPartitionIndex(m_partitions);

  LongVec1d emptyvec;
  // score the event
  csum->AddInterval(m_eventtime, ks.GetBranchParts(), 
                    ks.GetBranchXParts(), FLAGLONG, myxpart, FLAGLONG, FLAGLONG, 
                    emptyvec, force_COAL);

  // adjust the branch counts
  long i;
  for(i = 0; i < NELEM; ++i)
    ks.UpdateBranchCounts(Child(i)->m_partitions,false);
  ks.UpdateBranchCounts(m_partitions);
  
} /* CBranch::ScoreEvent */

//_________________________________________________

void CBranch::ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
                         long& s) const
{
  Summary* csum = summary.GetSummary(force_COAL);

  // forces have become inconsistent!
  assert(dynamic_cast<CoalSummary*>(csum));

  long myxpart = registry.GetDataPack().
    GetCrossPartitionIndex(m_partitions);
  LongVec1d emptyvec;
  // score the event
  csum->AddInterval(m_eventtime, ks.GetBranchParts(), 
                    ks.GetBranchXParts(), s, myxpart, FLAGLONG, FLAGLONG, 
                    emptyvec, force_COAL);

  // adjust the branch & link counts
  long i;
  for (i = 0; i < NELEM; ++i) {
    ks.UpdateBranchCounts(Child(i)->m_partitions,false);
    s -= Child(i)->m_range.ActiveLinks();
  }
  ks.UpdateBranchCounts(m_partitions);
  s += m_range.ActiveLinks();
  
} /* CBranch::ScoreEvent */

//_________________________________________________

bool CBranch::CheckInvariant() const
{

  // Coalescent branches have two children...
  if (!Child(0)) return false;
  if (!Child(1)) return false;

  //...and at least one parent
  if (!Parent(0)) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________
//_________________________________________________

Branch_ptr MBranch::Clone(bool copydlcells) const
{
  if (copydlcells) return Branch_ptr(new MBranch(*this));
  else return Branch_ptr(new MBranch(*this,!copydlcells));

} /* MBranch::Clone */

//_________________________________________________

bool MBranch::UpdateRange(bool dofc)
{
  return m_range.UpdateMRange(Child(0)->m_range, dofc);

} /* MBranch::UpdateRange */

//_________________________________________________

void MBranch::ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const
{
  Summary* msum = summary.GetSummary(force_MIG);

  // forces have become inconsistent!
  assert(dynamic_cast<MigSummary*>(msum));

  long mypop = GetPopulation();
  long chpop = Child(0)->GetPopulation();
  LongVec1d emptyvec;
  // score the event
  msum->AddInterval(m_eventtime, ks.GetBranchParts(),
                    ks.GetBranchXParts(), FLAGLONG, mypop, chpop, FLAGLONG, 
                    emptyvec, force_MIG);

  // adjust the branch counts
  assert(!Child(1));   // too many children??
  ks.UpdateBranchCounts(m_partitions);
  ks.UpdateBranchCounts(Child(0)->m_partitions,false);

  // we do not adjust active sites; they cannot possibly change
  
} /* MBranch::ScoreEvent */

//_________________________________________________

void MBranch::ScoreEvent(TreeSummary& summary, BranchBuffer& ks, 
                         long& s) const
{
  Summary* msum = summary.GetSummary(force_MIG);

  // forces have become inconsistent!
  assert(dynamic_cast<MigSummary*>(msum));

  long mypop = GetPopulation();
  long chpop = Child(0)->GetPopulation();
  LongVec1d emptyvec;
  // score the event
  msum->AddInterval(m_eventtime, ks.GetBranchParts(), 
                    ks.GetBranchXParts(), s, mypop, chpop, FLAGLONG, 
                    emptyvec, force_MIG);

  // adjust the branch counts
  assert(!Child(1));   // too many children??
  ks.UpdateBranchCounts(m_partitions);
  ks.UpdateBranchCounts(Child(0)->m_partitions,false);

  // we do not adjust active sites; they cannot possibly change
  
} /* MBranch::ScoreEvent */

//_________________________________________________

bool MBranch::CheckInvariant() const
{

  // Migrant branches have one child...
  if (!Child(0)) return false;
  if (Child(1)) return false;

  //...and at least one parent
  if (!Parent(0)) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________
//_________________________________________________

Branch_ptr DBranch::Clone(bool copydlcells) const
{
  if (copydlcells) return Branch_ptr(new DBranch(*this));
  else return Branch_ptr(new DBranch(*this,!copydlcells));

} /* DBranch::Clone */

//_________________________________________________

bool DBranch::UpdateRange(bool dofc)
{
  return m_range.UpdateMRange(Child(0)->m_range, dofc);

} /* DBranch::UpdateRange */

//_________________________________________________

void DBranch::ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const
{
  Summary* dissum = summary.GetSummary(force_DISEASE);

  // forces have become inconsistent!
  assert(dynamic_cast<DiseaseSummary*>(dissum));

  long mydis = GetDisease();
  long chdis = Child(0)->GetDisease();
  LongVec1d emptyvec;
  // score the event
  dissum->AddInterval(m_eventtime, ks.GetBranchParts(),
                      ks.GetBranchXParts(), FLAGLONG, mydis, chdis, FLAGLONG,
                      emptyvec, force_DISEASE);

  // adjust the branch counts
  assert(!Child(1));   // too many children??
  ks.UpdateBranchCounts(m_partitions);
  ks.UpdateBranchCounts(Child(0)->m_partitions,false);

  // we do not adjust active sites; they cannot possibly change
  
} /* DBranch::ScoreEvent */

//_________________________________________________

void DBranch::ScoreEvent(TreeSummary& summary, BranchBuffer& ks, 
                         long& s) const
{
  Summary* dissum = summary.GetSummary(force_DISEASE);

  // forces have become inconsistent!
  assert(dynamic_cast<DiseaseSummary*>(dissum));

  long mydis = GetDisease();
  long chdis = Child(0)->GetDisease();
  LongVec1d emptyvec;
  // score the event
  dissum->AddInterval(m_eventtime, ks.GetBranchParts(),
                      ks.GetBranchXParts(), s, mydis, chdis, FLAGLONG,
                      emptyvec, force_DISEASE);

  // adjust the branch counts
  assert(!Child(1));   // too many children??
  ks.UpdateBranchCounts(m_partitions);
  ks.UpdateBranchCounts(Child(0)->m_partitions,false);

  // we do not adjust active sites; they cannot possibly change
  
} /* DBranch::ScoreEvent */

//_________________________________________________

bool DBranch::CheckInvariant() const
{

  // Disease branches have one child...
  if (!Child(0)) return false;
  if (Child(1)) return false;

  //...and at least one parent
  if (!Parent(0)) return false;

  if (!Branch::CheckInvariant()) return false;

  return true;
} /* CheckInvariant */

//_________________________________________________
//_________________________________________________

RBranch::RBranch(const RBranch& src, bool nodlcells)
  : Branch(src,nodlcells)
{
} /* specialized RBranch copy ctor */

//_________________________________________________

RBranch::RBranch(Branch_ptr child, long rec, bool isleft, long totalsites)
  : Branch(child->m_range)
{
  rangepair recSite;
  if (isleft) {
    recSite.first = 0;
    recSite.second = rec + 1;   // the site after the recombination
  }
  else {
    recSite.first = rec + 1;
    recSite.second = totalsites;
  }
  assert(recSite.first < recSite.second);

  m_range.SetRRange(child->m_range, recSite, isleft);
  
};
//_________________________________________________

Branch_ptr RBranch::Clone(bool copydlcells) const
{
  if (copydlcells) return Branch_ptr(new RBranch(*this));
  else return Branch_ptr(new RBranch(*this,!copydlcells));

} /* RBranch::Clone */

//_________________________________________________

void RBranch::CopyPartitionsFrom(Branch_ptr src)
{
  m_partitions = src->m_partitions;
} /* Branch::CopyPartitionsFrom */

//_________________________________________________

void RBranch::RecCopyPartitionsFrom(Branch_ptr src, FPartMap fparts, bool islow)
{
  m_partitions = src->m_partitions; //fparts may override.

  ForceVec forces(registry.GetForceSummary().GetPartitionForces());

  for(unsigned long force=0; force<forces.size(); force++) {
    
    FPartMapiter thisforcepart = fparts.find(forces[force]->GetTag());
    if (thisforcepart != fparts.end()) {
      long chosenpart = thisforcepart->second;
      long partition = dynamic_cast<PartitionForce*>(forces[force])->
        ChoosePartition(src->m_partitions[force],
                        chosenpart,islow,GetRecSite());
      m_partitions[force] = partition;
    }
  }

} /* RBranch::RecCopyPartitionsFrom */

//_________________________________________________

bool RBranch::UpdateRange(bool dofc)
{
  return m_range.UpdateRRange(Child(0)->m_range, dofc);

} /* RBranch::UpdateRange */

//_________________________________________________

void RBranch::ReplaceChild(Branch_ptr oldchild, Branch_ptr newchild)
{
  SetChild(0,newchild);

  Branch_ptr myself = shared_from_this();

  if (oldchild->Parent(0) == myself) newchild->SetParent(0,myself);
  else newchild->SetParent(1,myself);

} /* RBranch::ReplaceChild */

//_________________________________________________

bool RBranch::operator==(const Branch& other) const
{

  return (Branch::operator==(other) && (m_range == other.m_range));
}

//_________________________________________________

bool RBranch::IsSameExceptForTimes(const Branch_ptr other) const
{

  return (Branch::IsSameExceptForTimes(other) && (m_range == other->m_range));
}

//_________________________________________________

bool RBranch::RecPartnerIsBad() const
{
  Branch_ptr partner((Child(0)->Parent(0) == shared_from_this()) ? 
                     Child(0)->Parent(1) : Child(0)->Parent(0));

  return((partner->m_eventtime != m_eventtime) ||
         (partner->Event() != btypeRec));
}

//_________________________________________________
//_________________________________________________

void RBranch::ScoreEvent(TreeSummary&, BranchBuffer&) const
{
  assert(false);  // this should never be called
} /* Rbranch::ScoreEvent */

//_________________________________________________

void RBranch::ScoreEvent(TreeSummary& summary, BranchBuffer& ks, 
                         long& s) const
{
  // One interval with a recombination at the top involves *two*
  // RBranches.  Only one will be summarized into the TreeSummary.
  // Thus, this peculiar-looking code only calls AddInterval if
  // the RBranch in question is its Child's *first* Parent, though
  // it does clean-up bookkeeping in any case.

  if (Child(0)->Parent(0) == shared_from_this()) {
  
    Summary* rsum = summary.GetSummary(force_REC);

    // forces have become inconsistent!?
    assert(dynamic_cast<RecSummary*>(rsum));

    // obtain the partnerpicks information for the branch which
    // had it, which is not necessarily this one.  This code
    // is correct even if there are multiple local partition forces,
    // so that the branch needed varies from force to force.  As a
    // consequence it is rather cumbersome and does not use
    // GetLocalPartitions().
    //
    // I assume that either both parents match the child, and it
    // doesn't matter which we use, or one parent does not match
    // the child, in which case that parent must be used.
    
    LongVec1d childpartitions = Child(0)->m_partitions;
    LongVec1d otherpartitions = Child(0)->Parent(1)->m_partitions;  // other branch of rec
    LongVec1d partnerpicks;
    LongVec1d lpindex(registry.GetForceSummary().GetLocalPartitionIndexes());
    LongVec1d::iterator lpforce;
    for(lpforce = lpindex.begin(); lpforce != lpindex.end(); ++lpforce) {
      if (m_partitions[*lpforce] == childpartitions[*lpforce]) 
        partnerpicks.push_back(otherpartitions[*lpforce]);
      else partnerpicks.push_back(m_partitions[*lpforce]);
    }

    // score the event
    rsum->AddInterval(m_eventtime, ks.GetBranchParts(),
                      ks.GetBranchXParts(), s, FLAGLONG, FLAGLONG, GetRecSite(),
                      partnerpicks, force_REC);

    // adjust the branch counts and activesite counts
    // for removal of the child
    ks.UpdateBranchCounts(Child(0)->m_partitions,false);
    s -= Child(0)->m_range.ActiveLinks();
  }

  // adjust the branch and activesite counts for addition of this branch
  
  ks.UpdateBranchCounts(m_partitions);
  s += m_range.ActiveLinks();
  
} /* RBranch::ScoreEvent */

//_________________________________________________

bool RBranch::CheckInvariant() const
{

  // Recombinant branches have one child...
  if (!Child(0)) {
    return false;
  }
  if (Child(1)) {
    return false;
  }
  //...and at least one parent
  if (!Parent(0)) {
    return false;
  }

  if (!Branch::CheckInvariant()) return false;
  return true;
} /* CheckInvariant */

//_________________________________________________
//_________________________________________________

JBranch::JBranch(const JBranch& src, bool nodlcells)
  : Branch(src,nodlcells), m_thetas(src.m_thetas)
{
} /* specialized JBranch copy ctor */

//_________________________________________________

Branch_ptr JBranch::Clone(bool copydlcells) const
{
  if (copydlcells) return Branch_ptr(new JBranch(*this));
  else return Branch_ptr(new JBranch(*this,!copydlcells));

} /* JBranch::Clone */

//_________________________________________________

JBranch_ptr JBranch::NextJoint()
{
  // don't assert on Parent(0), this is expected to return NULL
  // sometimes!
  JBranch_ptr nextbr = boost::dynamic_pointer_cast<JBranch>(Parent(0));
  return nextbr;
}

//_________________________________________________

JBranch_ptr JBranch::NextJointAppendingIfLast(const ForceParameters& fp)
{
  JBranch_ptr nextbr = NextJoint();
  if (!nextbr) AppendJoint(fp);

  return NextJoint();
}

//_________________________________________________

double JBranch::BottomTime()
{
  return NextJoint()->m_eventtime;
}

//_________________________________________________

JBranch_ptr JBranch::AppendJoint(const ForceParameters& fp)
{
  JBranch_ptr newjoint(boost::dynamic_pointer_cast<JBranch>(this->Clone(true)));
  assert(newjoint);

  const StickForce& force(registry.GetForceSummary().GetStickForce());
  double newtime = force.NextTime(fp.GetGrowthRates(),m_eventtime);

  assert(newtime != m_eventtime);

  newjoint->m_eventtime = newtime;
  newjoint->SetChild(0,
                     boost::dynamic_pointer_cast<JBranch>(shared_from_this()));
  newjoint->SetParent(0,Parent(0));
  SetParent(0,newjoint);

  DoubleVec1d newthetas = force.ComputeStickValues(newtime,fp);
  newjoint->SetThetas(newthetas);
  return newjoint; // so the caller can Collate it
}

//_________________________________________________

bool JBranch::CheckInvariant() const
{
  // Jointed stick branches have one child and one parent!
  /*JDEBUG--comment back in when dynamic_pointer_cast fixed
   * if (NChildren() != 1 || NParents() != 1) return false;
   */

  if (!Branch::CheckInvariant()) return false;
  return true;

} /* JBranch::CheckInvariant */

//_________________________________________________

