// $Id: newick.h,v 1.6 2006/02/22 22:10:43 jay Exp $

#ifndef NEWICK_H
#define NEWICK_H
#include <assert.h>

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include <vector>
#include <assert.h>
#include "branch.h" // for Branch_ptr declaration

class Tree;

//________________________________________________________________________

class UserTree
{
// we accept the default ctor, copy-ctor, and operator=
public:

  virtual ~UserTree() {};

  virtual bool Exists() { return false; };
  virtual void ToLamarcTree(Tree& stump) = 0;
 
};

//________________________________________________________________________

class NullUserTree : public UserTree
{
// we accept the default ctor, copy-ctor, and operator=
public:

  virtual ~NullUserTree() {};

  virtual void ToLamarcTree(Tree& stump) { assert(false); }; // instantiating NULL tree
};

//________________________________________________________________________

class NewickTree : public UserTree
{
private:
  std::string m_newicktree;
  unsigned long m_curr_char;
  const std::string m_numbers;
  const std::string m_terminators;

  double ProcessLength();
  Branch_ptr ProcessName(const Tree& stump);
  void ProcessComment();  // currently throws comments away

// we accept the default copy-ctor, and operator=

public:

  NewickTree(const std::string& tree);
  virtual ~NewickTree() {};

  virtual bool Exists() { return true; };
  void ToLamarcTree(Tree& stump);  // not const due to use m_curr_char

};

//________________________________________________________________________
// This is a helper class for NewickTree, representing one unfinished
// node in the tree.


class NewickNode 
{
private:

  Tree& m_tree;
  std::vector<NewickNode*> m_children;
  Branch_ptr m_branch;
  NewickNode* m_parent;
  double m_length;

              NewickNode(const NewickNode&); // not defined
  NewickNode& operator=(const NewickNode&);  // not defined

public:
  NewickNode(Tree& stump);
  ~NewickNode();

  NewickNode* AddChild();
  NewickNode* Terminate();
  NewickNode* GetParent() const;
  Branch_ptr  GetBranch() const;
  void AddBranch(Branch_ptr br);
  void SetLength(double newlength);

  // recursively coalesce all nodes contained within this one, 
  // returning the time (not length!) of coalescence.
  double Coalesce();  // not const because assigns to m_branch
  
}; /* NewickNode */

//________________________________________________________________________
//________________________________________________________________________

class NewickConverter
{
private:
   double RecurseWriteNewick(std::string& newick, Branch_ptr br) const;

// We accept the default ctor, dtor, copy ctor and operator=
public:
   std::string LamarcTreeToNewickString(const Tree& tree) const;

}; /* NewickConverter */

#endif /* NEWICK_H */
