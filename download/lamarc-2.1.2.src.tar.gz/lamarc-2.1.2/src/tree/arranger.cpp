//$Id: arranger.cpp,v 1.77 2007/09/13 00:12:26 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "arranger.h"
#include "event.h"
#include "tree.h"
#include "force.h"
#include "forceparam.h"
#include "forcesummary.h"
#include "random.h"
#include "errhandling.h"   // Arranger can throw data_error
#include "mathx.h"
#include "registry.h"
#include "likelihood.h"    // for Bayesian arranger functions
#include "chainstate.h"
#include "timelist.h"      // used extensively in rearrangement

using namespace std;

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif
//________________________________________________________________________
//________________________________________________________________________

Arranger::Arranger(double timing)
  :  m_timing(timing),
     m_savetiming(timing),
     m_tree(NULL),
     randomSource(&(registry.GetRandom()))
{
} /* Arranger::Arranger */

//________________________________________________________________________

Arranger::Arranger(const Arranger& src)
 : m_timing(src.m_timing),
   m_savetiming(src.m_savetiming),
   randomSource(src.randomSource)
{
  m_tree = NULL;
} /* Arranger::Arranger */

//________________________________________________________________________

void Arranger::SetTiming(double t)
{
    if(t < 0.0)
    {
        data_error e("arranger timing cannot be < 0.0");
        throw e;
    }

    // We used to barf for t > 1.0, but now we normalize
    // the timings later, so we don't do that

    m_timing = t;
}   // Arranger::SetTiming

//________________________________________________________________________
//________________________________________________________________________

ResimArranger::ResimArranger(const ForceSummary& fs, double timing)
  : Arranger(timing),
    m_eventvec(fs.CreateEventVec()),
    m_hasLogisticSelection(false), //set in SetParameters
    m_logsel_cutoff(FLAGDOUBLE),   //ditto
    m_activelist(registry.GetDataPack()), 
    m_inactivelist(registry.GetDataPack())
{

  // inform each Event of the Arranger for callbacks
  vector<Event*>::iterator event = m_eventvec.begin();
  vector<Event*>::iterator eventend = m_eventvec.begin();
  for ( ; event != eventend; ++event) {
    (*event)->SetArranger(*this);
  }
} /* ResimArranger ctor */

//________________________________________________________________________

ResimArranger::ResimArranger(const ResimArranger& src) 
  : Arranger(src),
    m_eventvec(),
    m_hasLogisticSelection(false), //set in SetParameters
    m_logsel_cutoff(FLAGDOUBLE),   //ditto
    m_activelist(registry.GetDataPack()),
    m_inactivelist(registry.GetDataPack())
{
  vector<Event*>::const_iterator event = src.m_eventvec.begin();
  vector<Event*>::const_iterator end = src.m_eventvec.end();
  Event* newevent;
  for( ; event != end; ++event) {
     newevent = (*event)->Clone();
     newevent->SetArranger(*this);
     m_eventvec.push_back(newevent);
  }   

  // we do not copy m_xactives etc. because they are only
  // scratchpads for Event use.
} /* ResimArranger::ResimArranger */

//________________________________________________________________________

ResimArranger::~ResimArranger()
{
  ClearEventVec();
} /* ResimArranger::~ResimArranger */

//________________________________________________________________________

void ResimArranger::ClearEventVec()
{

  vector<Event*>::iterator it = m_eventvec.begin();
  vector<Event*>::iterator end = m_eventvec.end();
  for ( ; it != end; ++it) {
    delete *it;
  }
  m_eventvec.clear();

} /* ClearEventVec */

//________________________________________________________________________

void ResimArranger::SetParameters(ChainState& chainstate)
{

  assert(m_eventvec.size() != 0);      // *some* events must be possible!

  vector<Event*>::iterator it = m_eventvec.begin();
  vector<Event*>::iterator end = m_eventvec.end();

  m_hasLogisticSelection = false;

  ForceParameters starts(chainstate.GetParameters());
  for ( ; it != end; ++it) {
    (*it)->InstallParameters(starts);
    if (dynamic_cast<ActiveLogisticSelectionCoal*>(*it))
      {
	// Compute and store the maximum starttime, beyond which over/underlow will ensue.
	double theta_A0 = starts.GetRegionalThetas()[0];
	double theta_a0 = starts.GetRegionalThetas()[1];
	double s = starts.GetLogisticSelectionCoefficient()[0];
	if (theta_A0 <= 0. || theta_a0 <= 0.)
	  throw impossible_error("Invalid Theta received by ResimArranger::SetParameters().");
	m_hasLogisticSelection = true;
	if (s > 0.)
	  m_logsel_cutoff = (EXPMAX - log(theta_a0) - 4.*LOG10)/s;
	else if (s < 0.)
	  m_logsel_cutoff = (EXPMAX - log(theta_A0) - 4.*LOG10)/(-s);
	else
	  m_logsel_cutoff = DBL_MAX; // no cutoff
      }
  }

} /* SetParameters */

//________________________________________________________________________

double ResimArranger::EventTime(Event*& returnevent, double eventT)
{

  m_xactives = m_activelist.GetBranchXParts();
  m_xinactives = m_inactivelist.GetBranchXParts();

  m_pactives = m_activelist.GetBranchParts();
  m_pinactives = m_inactivelist.GetBranchParts();

  double time = 0.0;

  vector<Event*>::iterator event;
  map<double,Event *> times;

  for (event = m_eventvec.begin(); event != m_eventvec.end(); ++event) {
    time = (*event)->PickTime(eventT);
    if (time != FLAGDOUBLE) {
       assert(time >= 0.0);  // should not be negative, ever!
       times.insert(make_pair(time,*event));
    }
  }

  // the first element in the map is now the smallest, since maps
  // are intrinsically sorted

  if (!times.empty()) {
    map<double,Event*>::const_iterator mapit = times.begin();
    double newT(mapit->first);

    if (newT == MAX_LENGTH) {
       string msg("maximal length branch won the horse race in");
       msg += " ResimArranger::EventTime";
       stretched_error e(msg);
       throw e;
    }

    if (m_hasLogisticSelection && eventT+newT > m_logsel_cutoff)
      {
	// Shrink this new interval a bit, to prevent over/underflow.
	// The cutoff is computed in SetParameters().
	// It's a simple function of the current (driving) values
	// of theta_A0, theta_a0, and s.
	newT = m_logsel_cutoff - eventT;
      }

    returnevent = (*mapit).second;
    return newT;

  } else {
  // there is no way to call an event, so return flags
    returnevent = NULL;     
    return FLAGLONG;
  }

}  /* EventTime */

//________________________________________________________________________

void ResimArranger::DropAll(double eventT)
{
  double time;
  Event* eventptr = NULL;

  m_inactivelist.Clear();
  m_tree->SetFCFrom(m_activelist, m_inactivelist);
  //a no-op for non-rec trees. m_inactivelist is empty.

  while (m_activelist.Size() > 1)  {
#ifndef NDEBUG
    if (!registry.GetForceSummary().IsMissingForce(force_REC)) {
       RecTree* rt(dynamic_cast<RecTree*>(m_tree));
       long oldnlinks(rt->ActiveLinks());
       rt->SetActiveLinksFrom(m_activelist);
       assert(oldnlinks == rt->ActiveLinks());
       //Also check FC:
       assert(rt->FCMatchesList(m_activelist, m_inactivelist));
    }
#endif

    time = EventTime(eventptr, eventT);
    assert (time != FLAGLONG);
    assert (eventptr != NULL);
    double nextT(eventT+time);
    eventptr->DoEvent(nextT);
    eventT = nextT;
    // JDEBUG--do something about extending stick if necessary....
    // make DoEvent do it...
  }

  // remove the root from the m_activelist then attach it to the tree
  m_tree->AttachBase(m_activelist.RemoveFirst());
} /* DropAll */

//________________________________________________________________________

double ResimArranger::Activate(Tree* oldtree)
{
  Branch_ptr activebranch = m_tree->ActivateBranch(oldtree);
  m_activelist.Append(activebranch);
  return activebranch->m_eventtime;

} /* Activate */

//________________________________________________________________________

void ResimArranger::Resimulate(double eventT)
{
  double nextT, time;
  Event* eventptr;
  JBranch_ptr stickjoint;

  double rootT = m_tree->RootTime();

  vector<Branch_ptr> newinactives = m_tree->FirstInterval(eventT);
  unsigned long i;
  m_inactivelist.Clear();
  for (i = 0; i < newinactives.size(); ++i) {
    m_inactivelist.Collate(newinactives[i]);
  }
  nextT = m_inactivelist.IntervalBottom();

  //This is for Final Coalescence (no-op for non-rec trees)
  m_tree->SetFCFrom(m_activelist, m_inactivelist);

  // The following loop resimulates lineages down the tree.
  // It will terminate when the Event objects agree that no
  // more events are possible, or when the root is reached,
  // at which point DropAll is invoked.

  while (1) {

    // poll the Event objects to see if we're done yet

    if (StopNow()) return;       

#ifndef NDEBUG
    if (!registry.GetForceSummary().IsMissingForce(force_REC)) {
       RecTree* rt(dynamic_cast<RecTree*>(m_tree));
       long oldnlinks(rt->ActiveLinks());
       rt->SetActiveLinksFrom(m_activelist);
       assert(oldnlinks == rt->ActiveLinks());
       //LS DEBUG printing.  If the above asserts, this sometimes helps:
       //rt->PrintFC();
       long oldnopenlinks(rt->OpenLinks());
       rt->SetOpenLinksFrom(m_inactivelist);
       assert(oldnopenlinks == rt->OpenLinks());

       //Also check FC:
       assert(rt->FCMatchesList(m_activelist, m_inactivelist));
    }
#endif

    time = EventTime(eventptr, eventT);

    // if an event is possible, we test to see if it happens
    // and carry it out if so.  If an event happens
    // we return to the top of the loop while remaining in the
    // same interval, since further events may occur.

    if (time != FLAGLONG) {
      eventT += time;
      if (eventT < nextT) {          
        eventptr->DoEvent(eventT);
        continue;
      }
    }

    // if we are at the root, finish up using DropAll()

    if (nextT == rootT) {
      m_activelist.Append(m_tree->ActivateRoot());
      DropAll(rootT);
      return;
    }
  
    // otherwise go on to the next interval

    eventT = nextT;
    nextT = NextInterval(eventT);
  }

} /* Resimulate */

//________________________________________________________________________

double ResimArranger::NextInterval(double lastT)
{
  // Remove first branch from inactive list
  Branch_ptr pBranch = m_inactivelist.RemoveFirst();

  // Insert its parent into inactive list
  Branch_ptr pParent = pBranch->Parent(0);
  m_inactivelist.Collate(pParent);

  if (pParent->Child(1)) {      // If the branch has a sibling,
    m_inactivelist.RemoveFirst(); // remove it from the inactive list also.
                                // if the branch has a second parent,
	   // insert it
  } else if (pBranch->Parent(1)) {
    m_inactivelist.Collate(pBranch->Parent(1));
  }

  // MARYDEBUG--kludge til think of something better used to
  // handle rectree updating--should probably move rectree updating
  // into arranger?
  m_tree->NextInterval(pBranch);

  // return the time at the bottom of the current interval.
  return m_inactivelist.IntervalBottom();

} /* NextInterval */

//________________________________________________________________________

bool ResimArranger::StopNow() const
{

  // Poll the Events to see if they are Done().  If any are
  // not, return false.

  vector<Event*>::const_iterator event = m_eventvec.begin();
  vector<Event*>::const_iterator end = m_eventvec.end();
 
  for ( ; event != end; ++event) {
    if (!(*event)->Done()) return false;
  }

  return true;

} /* StopNow */

//________________________________________________________________________

void ResimArranger::Rearrange(ChainState& chstate)
// This is a "template method" giving the steps of rearrangement 
// It may throw a "rejecttree_error" to signal a newtree that should
// be discarded.
{
  m_activelist.Clear();// m_activelist "clear" happens here instead of
                       // in Activate in case we want to "Activate"
                       // more than one branch for a given "drop".
  m_tree = chstate.GetTree();
  Tree* oldtree = chstate.GetOldTree();
  double eventT = Activate(oldtree);
  Resimulate(eventT);
  m_tree->Prune();
  assert(m_tree->IsValid());

} /* Rearrange */

//________________________________________________________________________

void ResimArranger::ScoreRearrangement(ChainState& chstate)
{
  // calculate data likelihood of new tree (stores it in the Tree object)
  chstate.GetTree()->CalculateDataLikes();
} /* ScoreRearrangement */

//________________________________________________________________________

bool ResimArranger::AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree)
// NB:  We assume that the tips of the tree were not changed, and
// thus we only accept/reject the body of the tree.
{

  if (badtree) {  // reject this tree immediately
    chstate.OverwriteTree();
    return false;
  }

  Tree* tree = chstate.GetTree();
  Tree* oldtree = chstate.GetOldTree();

  double test = (tree->GetDLValue() - oldtree->GetDLValue()) / temperature;
  test += Hastings(chstate);
  //  test += log(static_cast<double>(oldtree->GetTimeList().GetNCuttable()-1)/
  //              (tree->GetTimeList().GetNCuttable()-1));

  if (test < 0.0)
  {
    if (test < log(randomSource->Float())) {   // rejection
      tree->CopyPartialBody(oldtree);
      tree->CopyStick(oldtree);
      return false;
    }
  }

  // acceptance
  oldtree->CopyPartialBody(tree);
  oldtree->CopyStick(tree);
  chstate.TreeChanged();
  return true;
} /* AcceptAndSynchronize */

double ResimArranger::Hastings(ChainState& chstate)
{
  Tree* tree = chstate.GetTree();
  Tree* oldtree = chstate.GetOldTree();

  return log(static_cast<double>(oldtree->GetTimeList().GetNCuttable()-1)/
             (tree->GetTimeList().GetNCuttable()-1));
}

//________________________________________________________________________
//________________________________________________________________________

Arranger* DropArranger::Clone() const
{
  Arranger* arr = new DropArranger(*this);
  return arr;

} /* DropArranger::Clone */

//________________________________________________________________________
//________________________________________________________________________

Arranger* DeNovoArranger::Clone() const
{
  Arranger* arr = new DeNovoArranger(*this);
  return arr;
} /* DeNovoArranger::Clone */

//________________________________________________________________________

void DeNovoArranger::Rearrange(ChainState& chstate)
// routine formerly known as ResimArranger::DeNovoTree
{
  m_tree = chstate.GetTree();
  vector<Branch_ptr> tips = m_tree->ActivateTips(chstate.GetOldTree());

  // set up the active-lineage list
  m_activelist.Clear();
  m_inactivelist.Clear();
  unsigned long i;

  for (i = 0; i < tips.size(); ++i) {
    m_activelist.Append(tips[i]);
  }

  DropAll(0.0);

} /* DeNovoArranger::Rearrange */

//________________________________________________________________________

bool DeNovoArranger::AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree)
{
  // DeNovo trees are always accepted unless the 'badtree' flag forbids

  if (badtree) { 
    chstate.OverwriteTree();
    return false;
  } else { 
    chstate.OverwriteOldTree();
    chstate.TreeChanged();
    return true;
  }
} /* DeNovoArranger::AcceptAndSynchronize */

//________________________________________________________________________
//________________________________________________________________________

void BaseHapArranger::SetParameters(ChainState& chainstate)
{
  // deliberately blank
}

//________________________________________________________________________

void BaseHapArranger::ScoreRearrangement(ChainState& chstate)
{
  chstate.GetTree()->CalculateDataLikes();
} /* ScoreRearrangement */

//________________________________________________________________________

bool BaseHapArranger::AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree)
// We copy the full tree, as we may have changed the tips as well
// as the state of internal nodes (i.e. by changing DLCells).
{

  Tree* tree = chstate.GetTree();
  Tree* oldtree = chstate.GetOldTree();

  if (badtree) {   // reject this tree immediately
    tree->CopyTips(oldtree);
    tree->CopyBody(oldtree);
    return false;
  }

  double test = (tree->GetDLValue() - oldtree->GetDLValue()) / temperature;

  if (test < 0.0)
  {
    if (test < log(randomSource->Float())) {
      tree->CopyTips(oldtree);
      tree->CopyBody(oldtree);
      return false;
    }
  }

  oldtree->CopyTips(tree);
  oldtree->CopyBody(tree);
  chstate.TreeChanged();
  return true;
}

//________________________________________________________________________
//________________________________________________________________________

Arranger* HapArranger::Clone() const
{
  Arranger* arr = new HapArranger(*this);
  return arr;

} /* HapArranger::Clone */

//________________________________________________________________________

void HapArranger::Rearrange(ChainState& chstate)
{
  m_tree = chstate.GetTree();
  m_tree->SwapSiteDLs();
  assert(m_tree->IsValid());
}

//________________________________________________________________________
//________________________________________________________________________

Arranger* ProbHapArranger::Clone() const
{
  Arranger* arr = new ProbHapArranger(*this);
  return arr;

} /* ProbHapArranger::Clone */

//________________________________________________________________________

void ProbHapArranger::Rearrange(ChainState& chstate)
{
  m_tree = chstate.GetTree();
  m_tree->PickNewSiteDLs();
  assert(m_tree->IsValid());
}

void ProbHapArranger::ScoreRearrangement(ChainState& chstate)
{
  BaseHapArranger::ScoreRearrangement(chstate);
}

//________________________________________________________________________
//________________________________________________________________________

TreeSizeArranger::TreeSizeArranger(const ForceSummary& fs, double timing)
  : ResimArranger(fs,timing)
{
  //We only want Active events, so we re-set m_eventvec.
  vector<Event*>::iterator evit;
  
  for (evit = m_eventvec.begin(); evit != m_eventvec.end(); ) {
    if ((*evit)->IsInactive()) {
      delete *evit;
      evit = m_eventvec.erase(evit);
    }
    else {
      evit++;
    }
  }

}

//________________________________________________________________________

Arranger* TreeSizeArranger::Clone() const
{
  Arranger* arr = new TreeSizeArranger(*this);
  return arr;

} /* TreeSizeArranger::Clone */
 
//________________________________________________________________________

double TreeSizeArranger::Activate(Tree* oldtree)
{

  Branch_ptr branch(m_tree->ChoosePreferentiallyTowardsRoot(oldtree));
  return branch->m_eventtime;

} /* Activate */

//________________________________________________________________________

void TreeSizeArranger::Resimulate(double eventT)
{
  double nextT, displacement;
  Event* eventptr;

// The following loop draws new times for each event in the tree via
// resimulating a new event, discarding everything but its time, and
// storing the new time.  We will push all the new times into the
// tree in one fell swoop.  This minimizes the amount of work done
// while the tree is in a time-inconsistent state.

  TimeList& newtreelist = m_tree->GetTimeList();

  // find the start of the area to be modified
  Branchiter startpoint;

  for(startpoint = newtreelist.FirstBody();
      startpoint != newtreelist.End(); startpoint = newtreelist.NextBody(startpoint)) {
    if ((*startpoint)->m_eventtime >= eventT) break;
  }
  assert((*startpoint)->m_eventtime == eventT);

  assert(startpoint != newtreelist.End());
  assert((*startpoint)->m_eventtime == eventT);

  // set eventT so it defines the start of the interval in which the branch
  // it belongs to resides
  Branchiter intervalstart(startpoint);
  while ((*intervalstart)->m_eventtime == eventT)
     intervalstart = newtreelist.PrevBodyOrTip(intervalstart);
  eventT = (*intervalstart)->m_eventtime;
  assert((*startpoint)->m_eventtime > eventT);
  Branchiter newbranch;
  DoubleVec1d newtimes;

  m_activelist.Clear();
  m_activelist.Append(m_tree->
     FindBranchesImmediatelyTipwardOf(startpoint));

  for(newbranch = startpoint; newbranch != newtreelist.End();
      newbranch = newtreelist.NextBody(newbranch)) {

    m_tree->SetActiveLinksFrom(m_activelist);

    displacement = EventTime(eventptr, eventT);
    assert(displacement != FLAGLONG);
    assert(eventptr != NULL);
    nextT = eventT+displacement;
    newtimes.push_back(nextT);

    // now to fix up the activelist--remove all the children (if any)
    for(long i = 0; i < NELEM; ++i) {
       Branch_ptr br((*newbranch)->Child(i));
       if (br) m_activelist.Remove(br);
    }
    // then add the newbranch
    m_activelist.Append(*newbranch);

    if ((*newbranch)->Event() == btypeRec) {
       newtimes.push_back(nextT);
       newbranch = newtreelist.NextBody(newbranch);
       assert((*newbranch)->Event() == btypeRec);
       m_activelist.Append(*newbranch);
    }
    eventT = nextT;

  }

  assert(m_tree->IsValid());
  m_tree->SetNewTimesFrom(startpoint,newtimes);
  // clean up Tree scratchpads
  m_tree->ClearActiveLinks();

} /* Resimulate */

//________________________________________________________________________

double TreeSizeArranger::Hastings(ChainState& chstate)
{
  //The tree size arranger does not include a hastings term for the number
  // of cuttable branches because both should be identical.  Also, since
  // we are choosing a random branch instead of a random time, there need
  // be no compensation for that, either.
  return 0.0;
}

//________________________________________________________________________
//________________________________________________________________________

BayesArranger::BayesArranger(const BayesArranger& src) 
  : Arranger(src),
    m_oldlogs(src.m_oldlogs),
    m_newlogs(src.m_newlogs)
{
  // deliberately blank 
} /* copy ctor */

//________________________________________________________________________

Arranger* BayesArranger::Clone() const
{
  return new BayesArranger(*this);

} /* Clone */

//________________________________________________________________________

void BayesArranger::SetParameters(ChainState& chainstate)
{
  // we make sure that oldlogs are ready for use, which means
  // they start out equal to newlogs

  m_newlogs = chainstate.GetParameters().GetRegionalLogParameters();
  m_oldlogs = m_newlogs;

}  /* BayesArranger::SetParameters */

//________________________________________________________________________

void BayesArranger::Rearrange(ChainState& chstate)
{

  DoubleVec1d newparameters = chstate.GetParameters().GetGlobalParameters();
  //We must operate in global parameter space, since that's what space
  // the prior operates in.

  // choose a parameter
  const ParamVector pv(true);
  long chosen;
  while (true) {
    //LS DEBUG:  Potential for an infinite loop here if no parameter is set
    // to be variable, but this should be caught when exiting the menu.
    chosen = randomSource->Long(pv.size());
    paramstatus pstat = pv[chosen].GetStatus();
    if ((pstat == pstat_unconstrained) || (pstat == pstat_joint)) {
      break;
    }
  }

  // draw from appropriate prior
  pair<double, double> newp = pv[chosen].DrawFromPrior();
  registry.GetForceSummary().SetParamWithConstraints(chosen, newp.first, newparameters);
  chstate.GetParameters().SetGlobalParameters(newparameters);
  double newlogregparam = chstate.GetParameters().GetRegionalLogParameter(chosen);
  // This may not be a log, if it's growth, but we let
  // the ForceParameter worry about that.  We do need to make sure it's the
  // regional parameter, not the global parameter.
  registry.GetForceSummary().SetParamWithConstraints(chosen, newlogregparam, m_newlogs);

}  /* BayesArranger::Rearrange */

//________________________________________________________________________

void BayesArranger::ScoreRearrangement(ChainState& chstate)
{
  // it would be logical to compute the prior here, but currently
  // we do that in AcceptAndSynchronize.  OPTIMIZATION possible here.
} /* ScoreRearrangement */

//________________________________________________________________________

bool BayesArranger::AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree)
{
#ifdef STATIONARIES
  chstate.OverwriteOldParameters();
  m_oldlogs = m_newlogs;
  chstate.ParametersChanged();
  return true;
#endif

  assert(!badtree);  // Bayesian arrangers never make bad trees,
  // since they do not make trees at all!

  ForceParameters& newparameters = chstate.GetParameters();
  ForceParameters& oldparameters = chstate.GetOldParameters();
  SinglePostLike& postlike = registry.GetSinglePostLike();

  // summarize tree; we end up owning this summary
  // WARNING:  leaks memory if intervening code throws
  TreeSummary* trsum = chstate.GetTree()->SummarizeTree();

  // pass tree summary with old and new parameters to postlike routines
  // this returns ln likelihood!
  double oldprior = postlike.Calc_lnProbGP(oldparameters.GetRegionalParameters(),
					   m_oldlogs, trsum);
  double newprior = postlike.Calc_lnProbGP(newparameters.GetRegionalParameters(),
					   m_newlogs, trsum);
  //Postlike operates in Regional parameter space (unlike the priors, in
  // Rearrange), so we have to send them that version.

  // delete the summary
  delete trsum;

  // choose a winner
  double test = (newprior - oldprior)/temperature;

  if (test < log(randomSource->Float())) {  // reject
    chstate.OverwriteParameters();
    m_newlogs = m_oldlogs;
    return false;
  }

  // else accept
  chstate.OverwriteOldParameters();
  m_oldlogs = m_newlogs;
  chstate.ParametersChanged();
  return true;

} /* BayesArranger::AcceptAndSynchronize */


//________________________________________________________________________
//________________________________________________________________________

void LocusArranger::SetParameters(ChainState& chainstate)
{
  //Do nothing--the parameters don't change in a moving locus rearrangement.
}

//Our Locus arranger is a Gibbs arranger--it always accepts.
void LocusArranger::Rearrange(ChainState& chstate)
{
  RecTree* rtree = dynamic_cast<RecTree*>(chstate.GetTree());
  for (unsigned long mloc=0; mloc<rtree->GetNumMovingLoci(); mloc++) {
    //We might have a mix of jumping and floating loci--only do this for the
    // jumping ones.
    if (rtree->DoesThisLocusJump(mloc)) {
      DoubleVec1d likelihoods = rtree->CalculateDataLikesForFloatingLocus(mloc);
      ScaleLargestToZero(likelihoods);
      DoubleVec1d likesums;
      double total = 0;
      for (unsigned long site=0; site<likelihoods.size(); site++) {
        total += exp(likelihoods[site]);
        likesums.push_back(total);
      }
      double choice = randomSource->Float()*total;
      for (unsigned long site=0; site<likesums.size(); site++) {
        //LS DEBUG:  inefficient.  But earlier attempts were wrong, so.
        rtree->SetMovingMapposition(mloc, site);
        if (likesums[site] > choice) {
          break;
        }
      }
    }
  }
}


void LocusArranger::ScoreRearrangement(ChainState& chstate)
{
  // calculate data likelihood of new tree (stores it in the Tree object)
  
  RecTree* rtree = dynamic_cast<RecTree*>(chstate.GetTree());
  rtree->GetTimeList().SetAllUpdateDLs();
  for (unsigned long mloc=0; mloc<rtree->GetNumMovingLoci(); mloc++) {
    rtree->CalculateDataLikesForMovingLocus(mloc);
  }
  //We need to fill the DLcells with appropriate values at the new location
  // for the next arranger.  If we choose later to only rearrange a single
  // randomly-chosen moving loci instead of all of them, we'll need to
  // store the number of the chosen locus and only CalculateDataLikesFor... for
  // that locus.
}
  
bool LocusArranger::AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree)
{
  assert(!badtree);  //Enh?
  chstate.MapChanged();
  return true;
  //Note:  We don't do any tree copying, since the tree itself doesn't own what
  // we changed.  So it's a good thing we always accept!
}

Arranger* LocusArranger::Clone() const
{
  Arranger* arr = new LocusArranger(*this);
  return arr;
}

//________________________________________________________________________
//________________________________________________________________________

Arranger* ZilchArranger::Clone() const
{
  Arranger* arr = new ZilchArranger(*this);
  return arr;
} /* ZilchArranger::Clone */

bool ZilchArranger::AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree)
{
  assert(!badtree); //What?  We did nothing!
  //We assume the trees are still identical.
  return false; //No sense fooling the user into thinking we did something.

} /* ZilchArranger::AcceptAndSynchronize */

//________________________________________________________________________
//________________________________________________________________________

Arranger* StairArranger::Clone() const
{
	Arranger* arr = new StairArranger(*this);
	return arr;
} /* Clone */

//________________________________________________________________________

void StairArranger::SetParameters(ChainState& chainstate)
{
  // get the parameters we need, whatever those are
} /* SetParameters */

//________________________________________________________________________

void StairArranger::Rearrange(ChainState& chstate)
{
  // count the stairs
  long numstairs = m_tree->GetTimeList().CountJoints();
  // choose a stair at random
  long chosen = randomSource->Long(numstairs);
  long i;
  JBranch_ptr chosenjoint = m_tree->FindStickAtTime(0.0);
  JBranch_ptr prevjoint;
  for (i = 0; i < chosen; ++i) {
    prevjoint = chosenjoint;
    chosenjoint = chosenjoint->NextJoint();
  }
  assert (chosenjoint);  // it had better exist!
  double scoeff = 
            chstate.GetParameters().GetLogisticSelectionCoefficient()[0];
  DoubleVec1d murates(chstate.GetParameters().GetDiseaseRates());
  assert(murates.size() == 2);
  DoubleVec1d newthetas(2, 0.0);
  DoubleVec1d tipthetas(chstate.GetParameters().GetRegionalThetas());
  double totaltheta = tipthetas[0] + tipthetas[1];
  // draw a random number from the normal distribution
  double nextfreq, prevfreq, mean_x, new_x, var_delta;

  if (chosenjoint->NextJoint() && prevjoint) {
  // case I:  both previous and next joints exist
     DoubleVec1d nextths(chosenjoint->NextJoint()->GetThetas());
     DoubleVec1d prevths(prevjoint->GetThetas());
     assert(nextths.size() == 2 && prevths.size() == 2);
     nextfreq = nextths[0] / (nextths[0] + nextths[1]);
     prevfreq = prevths[0] / (prevths[0] + prevths[1]);
     mean_x = (nextfreq + Mean_delta_x(nextfreq, scoeff, 
			 murates[0], murates[1]) + 
	                 prevfreq + Mean_delta_x(prevfreq, scoeff, 
			 murates[0], murates[1])) / 2.0;
     var_delta = (Var_delta_x(nextfreq, nextths[0]+nextths[1]) +
	                Var_delta_x(prevfreq,prevths[0]+prevths[1])) / 2.0;

  } else if (chosenjoint->NextJoint()) {
  // case II:  only the next joint exists (we chose the first joint)
	  assert(!prevjoint);
     DoubleVec1d nextths(chosenjoint->NextJoint()->GetThetas());
     // MDEBUG the following is oversimplified if there are other
     // partitionforces
     assert(nextths.size() == 2 && tipthetas.size() == 2);
     nextfreq = nextths[0] / (nextths[0] + nextths[1]);
     prevfreq = tipthetas[0] / (tipthetas[0] + tipthetas[1]);
     mean_x = (nextfreq + Mean_delta_x(nextfreq, scoeff, 
			 murates[0], murates[1]) + 
	                 prevfreq + Mean_delta_x(prevfreq, scoeff, 
			 murates[0], murates[1])) / 2.0;
     var_delta = (Var_delta_x(nextfreq, nextths[0]+nextths[1]) +
	                Var_delta_x(prevfreq,tipthetas[0]+tipthetas[1])) / 2.0;

  } else {
  // case III:  only the previous joint exists (we chose the last joint)
	  assert(!chosenjoint->NextJoint());
	  assert(prevjoint);
     DoubleVec1d prevths(prevjoint->GetThetas());
     prevfreq = prevths[0] / (prevths[0] + prevths[1]);
     mean_x = prevfreq + Mean_delta_x(prevfreq, scoeff,
		     murates[0], murates[1]);
     var_delta = Var_delta_x(prevfreq, prevths[0] + prevths[1]);
  }

  do {
    double pick = randomSource->Normal();
    new_x = pick * sqrt(var_delta) + mean_x;
  } while (new_x > 1.0 || new_x < 0.0);

  newthetas[0] = new_x * totaltheta;
  newthetas[1] = (1.0 - new_x) * totaltheta;
  chosenjoint->SetThetas(newthetas);

} /* Rearrange */

//________________________________________________________________________

double StairArranger::Mean_delta_x(double x, double s, double mu, double nu)
// compute M(delta_x) = sx(1-x) + mu(1-x) - nu(x)
  {
    double mean_delta = s * x * (1.0 - x) + mu * (1.0 - x) -
	    nu * x;
    assert (-1.0 <= mean_delta && mean_delta <= 1.0);
    return mean_delta;
  } /* Mean_delta_x */

//________________________________________________________________________

double StairArranger::Var_delta_x(double x, double theta)
{
  double var_delta = x * (1.0 - x) / theta;
  assert(var_delta >= 0.0);
  return var_delta;
} /* Var_delta_x */

//________________________________________________________________________

void StairArranger::ScoreRearrangement(ChainState& chstate)
{
  // In ResimulatingArrangers this routine scores P(D|G).  The
  // analogous computation in StairArranger, like BayesArranger,
  // is done in AcceptAndSynchronize, so that even when stationaries
  // are being run, it will still happen.  Therefore this routine
  // is empty.
} /* ScoreRearrangement */

//________________________________________________________________________

// Much of this code is cut and paste from BayesArranger and
// should probably be combined, but not all of it, so this
// function can't simply be shared or inherited.
bool StairArranger::AcceptAndSynchronize(ChainState& chstate, double
		temperature, bool badtree)
{
  assert(!badtree); // we don't make trees at all, how could it be bad?!

  // summarize trees; we end up owning these summaries
  // WARNING:  leaks memory if intervening code throws

  // NB:  while it looks like we're comparing trees here, the
  // trees differ only in their stairs.  We pass a whole TreeSummary
  // only because there is no separate StairSummary.
  
  TreeSummary* newtrsum = chstate.GetTree()->SummarizeTree();
  TreeSummary* oldtrsum = chstate.GetOldTree()->SummarizeTree();

  SinglePostLike& postlike = registry.GetSinglePostLike();
  DoubleVec1d param = chstate.GetParameters().GetRegionalParameters();
  DoubleVec1d logparam = chstate.GetParameters().GetRegionalLogParameters();
  double oldprior = postlike.Calc_lnProbGP(param, logparam, oldtrsum);
  double newprior = postlike.Calc_lnProbGP(param, logparam, newtrsum);

  // delete the summaries
  delete newtrsum;
  delete oldtrsum;

  // choose the winner
  double test = (newprior - oldprior)/temperature;

  if (test < log(randomSource->Float())) { // reject
     chstate.GetTree()->CopyStick(chstate.GetOldTree());
     return false;
  }

  // else accept
  chstate.GetOldTree()->CopyStick(chstate.GetTree());
  chstate.StickChanged();
  return true;
    
} /* ScoreRearrangement */

//________________________________________________________________________
