// $Id: branchtag.h,v 1.2 2007/02/19 23:08:51 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/*******************************************************************
 Class BranchTag tracks and manages the semi-unique ID number of each
 "branch".  Semi-unique, in that if two (or more) branches represent the
 same "branch", then they will share the same ID number.

 Implementationwise, BranchTags are a shared pointer that on construction
 pulls a new unique ID number and initializes a counter.  Copying one
 increments the counter.  Destroying one decrements the counter.  On
 decrement if the counter reaches "zero", then the ID is freed for reuse.

 This class makes heavy use of static members--the member BeginBranchIDs,
 with an argument equal to the number of needed ids, must be called before
 any branch ids are handed out.  The call will look something like this:
     long max_number_of_concurrent_branches = 1000000;
     BranchTag::BeginBranchIDs(max_number_of_concurrent_branches);
 
 Written by Jon Yamato
********************************************************************/

#ifndef BRANCHTAG_H
#define BRANCHTAG_H

#include <deque>

#include "vectorx.h"

class BranchTag
{
private:
  LongVec1d::size_type m_id;

  void DecrementID(long oldid);
  static LongVec1d& RefCount();
  static std::deque<long>& NextID();

protected:

public:
  BranchTag();
  BranchTag(const BranchTag& src);
  BranchTag& operator=(const BranchTag& src);
  virtual ~BranchTag();

  void static BeginBranchIDs(long nids);

  bool operator==(const BranchTag& src) const;
  long ID() const;
};

#endif /* BRANCHTAG_H */
