#include "force.h"
#include "partition.h"
#include "timesize.h"

XPartition::~XPartition() { delete m_sizeat; };

