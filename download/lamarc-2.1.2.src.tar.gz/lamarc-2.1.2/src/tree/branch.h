// $Id: branch.h,v 1.43 2007/09/28 22:00:13 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/*******************************************************************
 Class Branch represents a branch in the tree, and is polymorphic
 on the type of event at its top (a coalescence, migration, etc.)
 It contains auxiliary objects--a Range and a DLCell--to manage
 likelihood and site information.

 A Branch's parents and children are represented by vectors of Branch_ptr.
 There may be 0, 1 or 2 parents and 0, 1 or 2 children; other
 values are illegal.

 As Branches are polymorphic, they are only put in containers as
 boost::shared_ptrs.  To copy a Branch use the Clone() function, which will
 create a new Branch of appropriate subtype.

 Branches are either Cuttable (can be cut during rearrangement) or
 not, and signal this by returning their "count of cuttable branches"
 which is currently either 0 or 1.  Partition and stick branches
 are currently non-cuttable.

 Written by Jim Sloan, heavily revised by Jon Yamato
 -- dlcell turned into a container Mary 2002/05/28
 -- derivation hierarchy reworked, TreeBranch class inserted
    Branch class narrowed Jon 2003/02/24
 -- Adding semi-unique ID numbers for each branch (the "same" branch
    in two different trees will share the same ID number).  First
    implementation via reference counted pointer objects.  Jon 2007/01/09


********************************************************************/

#ifndef BRANCH_H
#define BRANCH_H

#include <math.h>
#include <string>
#include <vector>
#include <deque>
#include <functional>
#include "vectorx.h"
#include "constants.h"
#include "defaults.h"
#include "range.h"
#include "dlcell.h"
#include "locuscell.h"
#include "shared_ptr.hpp" // for Branch_ptr (boost::shared_ptr)
#include "enable_shared_from_this.hpp" // for shared_ptr support
#include "forceparam.h" // for use in JBranch::AppendJoint()
#include "branchtag.h"

class TreeSummary;
class TipData;
class BranchBuffer;
class Force;
class Branch;
class TBranch;
class JBranch;

enum branch_type {btypeBase, btypeTip, btypeCoal, btypeMig, btypeDisease,
                  btypeRec, btypeStick};
enum branch_group {bgroupTip, bgroupStick, bgroupBody};
std::string ToString(branch_type btype);
typedef boost::shared_ptr<TBranch> TBranch_ptr;
typedef boost::shared_ptr<JBranch> JBranch_ptr;

class Branch : public boost::enable_shared_from_this<Branch>
{
private:
  Branch();
  vector<weakBranch_ptr> m_parents;
  vector<weakBranch_ptr> m_children;

  // GetActiveChild() is a helper function for GetValidChild()
  virtual const Branch_ptr GetActiveChild(long) const {return Child(0);};

protected:
  bool m_updateDL;
  BranchTag m_ID;
  weakBranch_ptr m_equivBranch;

  // We own what these point to
  vector<LocusCell> m_dlcells;
  vector<LocusCell> m_movingDLcells;

  virtual void CopyAllMembers(const Branch& src);
  Branch(const Branch& src, bool nodlcells);  // copy ctor only meant to
                                              // be used to construct branches
                                              // without dlcells
  LongVec1d GetLocalPartitions() const; // used by ScoreEvent

public:
  LongVec1d m_partitions;
  double m_eventtime;
  bool m_marked;
  static Branch_ptr NONBRANCH;

  Range   m_range;

  Branch(Range protorange);
  Branch(const Branch& src);
  virtual ~Branch();

  // RTTI
  virtual branch_type Event()                 const = 0;
  virtual branch_group BranchGroup()          const = 0;

  virtual Branch_ptr Clone(bool copydlcells) const         {return Branch::NONBRANCH;};

  // convenience getters & setters
          long    GetPopulation() const;
          void    SetPopulation(long pop);
          long    GetDisease() const;
          void    SetDisease(long dis);
	  long    GetID() const;
          weakBranch_ptr GetEquivBranch() const;
          void    SetEquivBranch(Branch_ptr twin);

          long    GetPartition(force_type) const;
  virtual void    CopyPartitionsFrom(Branch_ptr src);

    Branch_ptr    Child(long which) { return m_children[which].lock(); };
    Branch_ptr    Parent(long which) { return m_parents[which].lock(); };
const Branch_ptr Child(long which) const { return m_children[which].lock(); };
const Branch_ptr Parent(long which) const { return m_parents[which].lock(); };
          void    SetChild(long which, Branch_ptr val)
	             { m_children[which] = val; };
          void    SetParent(long which, Branch_ptr val)
	             { m_parents[which] = val; };
	  long    NParents() const { return m_parents.size(); };
	  long    NChildren() const { return m_children.size(); };

  // arrangemment helpers
          bool    IsAMember(const Force& force, const LongVec1d& membership) const;
  virtual long    Cuttable()                const {return 0;};
  virtual bool    CanRemove(Branch_ptr)           {return true;};
  virtual long    CountDown()               const {return 0;};
  virtual bool    UpdateRange(bool dofc)          {return false;};
  virtual bool    UpdateFCToInclude(rangeset fc);
  virtual void    UpdateFCToExclude(rangeset nofc);
  virtual bool    IsEquivalentTo(const Branch_ptr)   const;
  virtual bool    HasSamePartitionsAs(const Branch_ptr) const;
  virtual bool    PartitionsConsistentWith(const Branch_ptr) const;
  // the following routine is a no-op except in a branch where updateDL is
  // allowed to be true, in which case it will be overridden.
  virtual void    SetUpdateDL()                   {};  
          void    ClearUpdateDL()                 {m_updateDL = false; };
          bool    GetUpdateDL()             const {return m_updateDL; };
          void    MarkParentsForDLCalc();
  virtual void    ReplaceChild(Branch_ptr oldchild, Branch_ptr newchild);
  virtual bool    HasSameActive(const Branch& br);
  const Cell_ptr GetDLCell(long loc, long ind, bool moving)      const;
        Cell_ptr GetDLCell(long loc, long ind, bool moving);
          void    SetDLCells(const std::vector<LocusCell>& src) 
                                                  {m_dlcells = src; };
          long    GetNcells(long locus)  const { return m_dlcells[locus].size(); };

          void    SetMovingDLCells(const std::vector<LocusCell>& src) 
                                                  {m_movingDLcells = src; };
  //          long    GetNcells(long locus)  const { return m_dlcells[locus].size(); };
  
  const double          GetTime() {return m_eventtime;};

  // subtree maker helper
  virtual long    GetRecSite()              const {return FLAGLONG;};

  // likelihood calculation helpers
  virtual double  HowFarTo(const Branch& br) const;
  virtual bool    CanCalcDL(long)           const {return false;};
  virtual bool    ShouldCalcDL(long)        const {return false;};
  Branch_ptr GetValidChild(Branch_ptr br, long whichpos);
  Branch_ptr GetValidParent(long whichpos);

  // haplotyping helpers
  virtual bool    DiffersInDLFrom(Branch_ptr branch, long locus, long marker) const;

  // tree summarization helpers
  virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const = 0;
  virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
     long& s) const = 0;

  // invariant checking
  virtual bool    CheckInvariant()          const;
  virtual bool    operator==(const Branch& src) const;
          bool    operator!=(const Branch& src) const {return !(*this == src); };

  // debugging
  virtual string  DLCheck(const Branch& other)    const;
  void            InvertUpdateDL() { m_updateDL = !m_updateDL; };
  void            PrintInfo() const;
  vector<Branch_ptr> GetChildren();  // used by TimeList::Printtimelist()
  bool            ConnectedTo(const Branch_ptr family);  // used by
                            // TimeList::IsValid(), non-const because of
                            // use of boost::shared_from_this()!
  virtual bool    IsSameExceptForTimes(const Branch_ptr other) const;

};

//_________________________________________________________________
//_________________________________________________________________

class BBranch : public Branch
{
private:
// specialized copy ctor only to be used for making branches w/o dlcells!
BBranch(const BBranch& src, bool nodlcells) : Branch(src,nodlcells) {};

public:
BBranch(); //Need this for the TimeList constructor--we'll fake the
           // range object.
BBranch(Range protorange) : Branch(protorange) {};
virtual ~BBranch()                             {};
BBranch(const BBranch& src): Branch(src) {};
virtual Branch_ptr Clone(bool copydlcells) const;
virtual branch_type Event()              const {return btypeBase;};
virtual branch_group BranchGroup()       const {return bgroupBody; };

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
   long& s) const;

virtual bool    CheckInvariant()          const;
};

//_________________________________________________________________
//_________________________________________________________________

class TBranch : public Branch
{
private:
// specialized copy ctor only to be used for making branches w/o dlcells!
TBranch(const TBranch& src, bool nodlcells);
virtual const Branch_ptr GetActiveChild(long) const {return Branch::NONBRANCH;};

public:
string  m_label;

virtual ~TBranch()                              {};
TBranch(const TipData& tipdata, Range protorange);
TBranch(const TBranch& src) : Branch(src), m_label(src.m_label)       {}; 
virtual Branch_ptr Clone(bool copydlcells) const;
virtual branch_type Event()                 const {return btypeTip;};
virtual branch_group BranchGroup()       const {return bgroupTip; };

virtual long Cuttable()                   const {return 1;};

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
   long& s) const;

virtual bool    CheckInvariant()          const;
virtual bool    operator==(const Branch& src) const;
virtual bool    IsSameExceptForTimes(const Branch_ptr other) const;
};

//_________________________________________________________________
//_________________________________________________________________

class CBranch : public Branch
{
private:
// specialized copy ctor only to be used for making branches w/o dlcells!
CBranch(const CBranch& src, bool nodlcells) : Branch(src,nodlcells) {};
  CBranch();
virtual const Branch_ptr GetActiveChild(long site) const;
  
public:
CBranch(Range protorange) : Branch(protorange)    {};
virtual ~CBranch()                                {};
CBranch(const CBranch& src) : Branch(src) {};
virtual Branch_ptr Clone(bool copydlcells) const;
virtual branch_type Event()                 const {return btypeCoal;};
virtual branch_group BranchGroup()          const {return bgroupBody; };

virtual long    Cuttable()                  const {return 1;};
virtual bool    CanRemove(Branch_ptr checkchild);
virtual long    CountDown()                 const {return -2;};
virtual bool    UpdateRange(bool dofc);
virtual void    SetUpdateDL()                     {m_updateDL = true;};
virtual void    ReplaceChild(Branch_ptr oldchild, Branch_ptr newchild);
virtual Branch_ptr OtherChild(Branch_ptr badchild);


virtual bool CanCalcDL(long site)           const {return
                                    Child(0)->m_range.IsSiteActive(site) && 
                                    Child(1)->m_range.IsSiteActive(site);};
virtual bool ShouldCalcDL(long site)        const {return m_updateDL &&
                                                   CanCalcDL(site);};

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
   long& s) const;

virtual bool    CheckInvariant()          const;
};

//_________________________________________________________________
//_________________________________________________________________

class PartBranch : public Branch
{
protected:
// specialized copy ctor only to be used for making branches w/o dlcells!
PartBranch(const PartBranch& src, bool nodlcells) : Branch(src,nodlcells) {};
PartBranch();
  
public:
PartBranch(Range protorange) : Branch(protorange)  {};
virtual ~PartBranch()                        {};
PartBranch(const PartBranch& src) : Branch(src)       {};
virtual long    Cuttable()             const {return 0;};

};

//_________________________________________________________________
//_________________________________________________________________

class MBranch : public PartBranch
{
private:
// specialized copy ctor only to be used for making branches w/o dlcells!
MBranch(const MBranch& src, bool nodlcells) : PartBranch(src,nodlcells) {};
MBranch();

public:
MBranch(Range protorange) : PartBranch(protorange)  {};
virtual ~MBranch()                           {};
MBranch(const MBranch& src) : PartBranch(src)       {};
virtual Branch_ptr Clone(bool copydlcells) const;
virtual branch_type Event()            const {return btypeMig;};
virtual branch_group BranchGroup()     const {return bgroupBody; };

virtual bool    UpdateRange(bool dofc);

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
   long& s) const;

virtual bool    CheckInvariant()          const;
};

//_________________________________________________________________
//_________________________________________________________________

class DBranch : public PartBranch
{
private:
// specialized copy ctor only to be used for making branches w/o dlcells!
DBranch(const DBranch& src, bool nodlcells) : PartBranch(src,nodlcells) {};
DBranch();

public:
DBranch(Range protorange) : PartBranch(protorange)  {};
virtual ~DBranch()                           {};
DBranch(const DBranch& src) : PartBranch(src)       {};
virtual Branch_ptr Clone(bool copydlcells) const;
virtual branch_type Event()            const {return btypeDisease;};
virtual branch_group BranchGroup()     const {return bgroupBody; };

virtual bool    UpdateRange(bool dofc);

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
   long& s) const;

virtual bool    CheckInvariant()          const;
};

//_________________________________________________________________
//_________________________________________________________________

class RBranch : public Branch
{
private:
// specialized copy ctor only to be used for making branches w/o dlcells!
RBranch(const RBranch& src, bool nodlcells);
RBranch();

public:
RBranch(Branch_ptr child, long recsite, bool isleft, long totalsites);
virtual ~RBranch()                           {};
RBranch(const RBranch& src) : Branch(src)       {};
virtual Branch_ptr Clone(bool copydlcells) const;
virtual branch_type Event()            const {return btypeRec;};
virtual branch_group BranchGroup()     const {return bgroupBody; };

virtual void    CopyPartitionsFrom(Branch_ptr src);
        void    RecCopyPartitionsFrom(Branch_ptr src, FPartMap fparts,
                                      bool islow);

virtual long    Cuttable()             const {return 1;};
virtual long    CountDown()            const {return 1;};
virtual bool    UpdateRange(bool dofc);
virtual void    ReplaceChild(Branch_ptr oldchild, Branch_ptr newchild);

virtual long    GetRecSite()           const {return m_range.GetRecsite();};

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const;
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
   long& s) const;

virtual bool    CheckInvariant()          const;
virtual bool    operator==(const Branch& src) const;
virtual bool    IsSameExceptForTimes(const Branch_ptr other) const;
        bool    RecPartnerIsBad() const;
};

//_________________________________________________________________
//_________________________________________________________________

// This Branch represents part of the 'jointed stick' of population
// size changes.  

class JBranch : public Branch
{
private:
DoubleVec1d m_thetas;
// specialized copy ctor only to be used for making branches w/o dlcells!
JBranch(const JBranch& src, bool nodlcells);

public:
virtual ~JBranch()                                                {};
JBranch(const DoubleVec1d& p, Range& protorange) :
  Branch(protorange), m_thetas(p)                 {};
JBranch(const JBranch& src): Branch(src), m_thetas(src.m_thetas) {};
JBranch_ptr AppendJoint(const ForceParameters& fp);

virtual Branch_ptr Clone(bool copydlcells) const;
virtual branch_type Event()             const {return btypeStick;};
virtual branch_group BranchGroup()     const {return bgroupStick; };

        JBranch_ptr NextJoint();
	JBranch_ptr NextJointAppendingIfLast(const ForceParameters& fp);
        double      BottomTime();

// tree summarization helpers
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks) const
{/* bogus stuff */};
virtual void    ScoreEvent(TreeSummary& summary, BranchBuffer& ks,
   long& s) const
{/* bogus stuff */};

// Getters and setters
const DoubleVec1d& GetThetas() const {return m_thetas;};
void SetThetas(const DoubleVec1d& src) {m_thetas = src; };

virtual bool    CheckInvariant()          const;
};

// Free functions for use as STL predicates

class IsTipGroup : public std::unary_function<Branch_ptr, bool>
{
	public:
bool operator()(const Branch_ptr t) { return t->BranchGroup() == bgroupTip; };
};

class IsBodyGroup : public std::unary_function<Branch_ptr, bool>
{
	public:
bool operator()(const Branch_ptr t) { return t->BranchGroup() == bgroupBody; };
};

class IsStickGroup : public std::unary_function<Branch_ptr, bool>
{
	public:
bool operator()(const Branch_ptr t) { return t->BranchGroup() == bgroupStick; };
};

class IsCoalGroup : public std::unary_function<Branch_ptr, bool>
{
	public:
bool operator()(const Branch_ptr t) { return t->Event() == btypeCoal; };
};

#endif /* BRANCH_H */
