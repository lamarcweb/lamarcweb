// $Id: arranger_types.h,v 1.9 2006/03/14 23:53:35 lpsmith Exp $

#ifndef ARRANGER_TYPES_H
#define ARRANGER_TYPES_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>

//enum arranger_type { ARBASE, RESIM, DROP, HAP, BAYES, DENO };

class arrangerstrings
{
    public:
        static const std::string BASE   ;
        static const std::string RESIM  ;
        static const std::string DROP   ;
        static const std::string HAP    ;
        static const std::string BAYES  ;
        static const std::string DENO   ;
        static const std::string RECSITE;
        static const std::string PROBHAP;
        static const std::string TREESIZE;
        static const std::string LOCUS  ;
        static const std::string ZILCH  ;

};


#endif  /* ARRANGER_TYPES_H */

