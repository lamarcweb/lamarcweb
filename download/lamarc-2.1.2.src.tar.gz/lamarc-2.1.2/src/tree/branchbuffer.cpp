// $Id: branchbuffer.cpp,v 1.7 2007/09/13 00:12:27 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "branchbuffer.h"
#include "datapack.h" // for BranchBuffer ctor
#include "registry.h" // for access to global datapack for handling
                      // partition logic in BranchBuffer class
#include "errhandling.h" // for exceptions
#include "force.h"    // for force ctor in BranchBuffer::RemoveBranch()

extern Registry registry;

using namespace std;

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

//____________________________________________________________________________
//____________________________________________________________________________

BranchBuffer::BranchBuffer(const DataPack& dpack) :
m_branchxparts(dpack.GetNCrossPartitions(),0L),
m_branchparts(dpack.GetNPartitionForces()) 
{
long force, nforces = dpack.GetNPartitionForces();
for(force = 0; force < nforces; ++force) {
   LongVec1d parts(dpack.GetNPartitions(force),0L);
   m_branchparts[force] = parts;
}

} /* BranchBuffer::BranchBuffer */

//____________________________________________________________________________

void BranchBuffer::Clear()
{
branches.clear();

m_branchxparts.assign(m_branchxparts.size(),0L);
LongVec2d::iterator force;
for(force = m_branchparts.begin(); force != m_branchparts.end(); ++force)
   force->assign(force->size(),0L);

} /* BranchBuffer::Clear */

//____________________________________________________________________________

long BranchBuffer::GetNBranches(force_type force, 
   const LongVec1d& membership) const
{

long count = m_branchxparts[registry.GetDataPack().
                            GetCrossPartitionIndex(membership)];

return count;

} /* BranchBuffer::GetNBranches */

//____________________________________________________________________________

long BranchBuffer::GetNPartBranches(force_type force, long part) const
{
long count = m_branchparts[registry.GetForceSummary().GetPartIndex(force)]
                          [part];

return count;

} /* BranchBuffer::GetNPartBranches */

//____________________________________________________________________________

void BranchBuffer::UpdateBranchCounts(const LongVec1d& newpartitions,
   bool addbranch)
{
unsigned long xpartindex = registry.GetDataPack().
                           GetCrossPartitionIndex(newpartitions);

assert(xpartindex >= 0 && xpartindex < m_branchxparts.size());

if (addbranch) {
   ++m_branchxparts[xpartindex];
   long force, nforces = newpartitions.size();
   for(force = 0; force < nforces; ++force)
      ++m_branchparts[force][newpartitions[force]];
} else {
   --m_branchxparts[xpartindex];
   long force, nforces = newpartitions.size();
   for(force = 0; force < nforces; ++force)
      --m_branchparts[force][newpartitions[force]];
}

} /* BranchBuffer::UpdateBranchCounts */

//____________________________________________________________________________

LongVec1d BranchBuffer::GetBranchParts(force_type force) const
{
return m_branchparts[registry.GetForceSummary().GetPartIndex(force)];

} /* BranchBuffer::GetBranchParts */

//____________________________________________________________________________

LongVec1d BranchBuffer::GetBranchXParts() const
{
return m_branchxparts;

} /* BranchBuffer::GetBranchXParts */

//____________________________________________________________________________

void BranchBuffer::Append(Branch_ptr newbranch)
{

// OPTIMIZE -- should we change to list push_back?
  branches.push_back(newbranch);

  UpdateBranchCounts(newbranch->m_partitions);

} /* BranchBuffer::Append */

//____________________________________________________________________________

void BranchBuffer::Append(vector<Branch_ptr> newbranches)
{
vector<Branch_ptr>::iterator branch;
for(branch = newbranches.begin(); branch != newbranches.end(); ++branch)
   Append(*branch);

} /* BranchBuffer::Append */

//____________________________________________________________________________

void BranchBuffer::AddAfter(Branchiter here, Branch_ptr newbranch)
{

// debug DEBUG warning WARNING--assume that we can keep time sorted
//    ordering by simple append after here.
++here;
branches.insert(here,newbranch);

UpdateBranchCounts(newbranch->m_partitions);

} /* BranchBuffer::AddAfter */

//____________________________________________________________________________

void BranchBuffer::Collate(Branch_ptr newbranch)
{

// Degenerate collate into an empty list
if (branches.empty()) {
  branches.push_front(newbranch);
  UpdateBranchCounts(newbranch->m_partitions);
  return;
}

// Regular collate
Branchiter br = branches.begin();

// Catch insertion before the first entry
if ((*br)->Parent(0)->m_eventtime > newbranch->Parent(0)->m_eventtime) {
  branches.push_front(newbranch);
  UpdateBranchCounts(newbranch->m_partitions);
  return;
}

// Insertion after an entry
Branchiter end = branches.end();
Branchiter previous = br;
br++;      // first entry has been taken care of already

for ( ; br != end; ++br) {
  if ((*br)->Parent(0)->m_eventtime > newbranch->Parent(0)->m_eventtime) break;
  previous = br;
}

// we rely on flowthrough for the case where this will be the
// new bottommost branch.

AddAfter(previous, newbranch);

} /* BranchBuffer::Collate */

//____________________________________________________________________________

void BranchBuffer::Remove(Branchiter here)
{

  UpdateBranchCounts((*here)->m_partitions,false);
  branches.erase(here);

} /* BranchBuffer::Remove */

void BranchBuffer::Remove(Branch_ptr branch)
{
  UpdateBranchCounts(branch->m_partitions, false);
  branches.remove(branch);
}

//____________________________________________________________________________

Branch_ptr BranchBuffer::GetFirst()
{
return branches.front();

} /* BranchBuffer::GetFirst */

//____________________________________________________________________________

Branch_ptr BranchBuffer::RemoveFirst()
{
Branch_ptr pbranch = GetFirst();
UpdateBranchCounts(pbranch->m_partitions,false);
branches.pop_front();

return pbranch;

} /* BranchBuffer::RemoveFirst */

//____________________________________________________________________________

Branch_ptr BranchBuffer::RemovePartitionBranch(force_type force,
                                            long part, double rnd)
{
  long count = static_cast<long>(rnd * GetNPartBranches(force,part));

  Branchiter brit;
  for(brit = branches.begin(); brit != branches.end(); ++brit)
    if ((*brit)->GetPartition(force) == part) {
      if (!count) break;
      --count;
    }

  assert(count == 0); // didn't find a branch
  Branch_ptr retbranch = *brit;
  Remove(brit);
  return retbranch;

} /* BranchBuffer::RemovePartitionBranch */

//____________________________________________________________________________

Branch_ptr BranchBuffer::RemoveBranch(force_type forceid, long xpartindex,
   double rnd)
{
  const LongVec1d& membership = registry.GetDataPack().
    GetBranchMembership(xpartindex);

  long count = static_cast<long>(rnd * GetNBranches(forceid,membership));

  const Force& force(**registry.GetForceSummary().GetForceByTag(forceid));
  Branchiter brit;
  for(brit = branches.begin(); brit != branches.end(); ++brit) {
    if ((*brit)->IsAMember(force,membership)) {
      if (!count) break;
      --count;
    }
  }

  assert(count == 0); // didn't find a branch
  assert(brit != branches.end());

  Branch_ptr retbranch = *brit;
  Remove(brit);
  return retbranch;
} /* BranchBuffer::RemoveBranch */

//____________________________________________________________________________

Branch_ptr BranchBuffer::RemoveBranch(force_type forceid, 
                                   const LongVec1d& membership, double rnd)
{
  long count = static_cast<long>(rnd * GetNBranches(forceid,membership));

  const Force& force(**registry.GetForceSummary().GetForceByTag(forceid));
  Branchiter brit;
  for(brit = branches.begin(); brit != branches.end(); ++brit)
    if ((*brit)->IsAMember(force,membership)) {
      if (!count) break;
      --count;
    }

  assert(count == 0); // didn't find a branch

  Branch_ptr retbranch = *brit;
  Remove(brit);
  return retbranch;
} /* BranchBuffer::RemoveBranch */

//____________________________________________________________________________

double BranchBuffer::IntervalBottom()
{
return GetFirst()->Parent(0)->m_eventtime;

} /* BranchBuffer::IntervalBottom() */

//____________________________________________________________________________

vector<Branch_ptr> BranchBuffer::ExtractConstBranches() const
{
  vector<Branch_ptr> br;
  Branchconstiter brit;
  for(brit = branches.begin(); brit != branches.end(); ++brit)
     br.push_back(*brit);

  return br;

} /* BranchBuffer::ExtractConstBranches */

//____________________________________________________________________________

void BranchBuffer::PrintEvents() const
{
  cout << endl;
  Branchconstiter brit;
  for(brit = branches.begin(); brit != branches.end(); ++brit)
     cout << ToString((*brit)->Event()) << ", ";

  cout << endl;

} /* BranchBuffer::PrintEvents */


//____________________________________________________________________________

void BranchBuffer::PrintRanges() const
{
  cout << "Ranges of branches in this list:" << endl;
  Branchconstiter brit;
  for(brit = branches.begin(); brit != branches.end(); ++brit) {
    (*brit)->m_range.PrintInfo();
    cout << endl;
  }

} /* BranchBuffer::PrintRanges */


