// $Id: arrangervec.h,v 1.19 2006/12/05 23:58:41 lpsmith Exp $

#ifndef ARRANGERVEC_H
#define ARRANGERVEC_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <map>
#include <vector>
#include "arranger_types.h"

//_________________________________________________________________________

// This class is a managed map of Arranger objects (objects which
// can carry out a single Markov Chain step).  Mapping is between
// the Arranger's type and the object itself.

// Written by Mary, Jon, and/or Elizabeth, probably around 11/22/2002

// Added ability to manage ForceParameters, needed by BayesArranger.
// Mary 2003/12/01

// NOTE:  If you run Bayesian Stationaries, the code here will silently
// transform all mention of the DropArranger to the DenovoArranger.

//_________________________________________________________________________

class Arranger;

typedef std::map<string, Arranger*> arrangermap;
typedef arrangermap::iterator arrangerit;
typedef arrangermap::const_iterator const_arrangerit;

class ArrangerVec
{
    private:  
        ArrangerVec();          // undefined

        arrangermap arrangers;
        void                    CopyAllMembers(const ArrangerVec& cp);
        void                    Normalize();

    public:
        ArrangerVec(double dropTiming, double sizeTiming,
                    double hapTiming, double probhapTiming,
                    double bayesTiming,
                    double locusTiming, double zilchTiming);
        ~ArrangerVec();
        ArrangerVec(const ArrangerVec& src);
        ArrangerVec& operator=(const ArrangerVec& src);

        double                 GetArrangerTiming(const string& atype) const;
        Arranger*              GetDenovoArranger() const;
        Arranger*              GetRandomArranger(double) const;
        StringVec1d            GetAllStringsForActiveArrangers() const;

        void                   ClearAll();

        void                   ZeroHapArranger();
        void                   ZeroProbHapArranger();
        void                   ZeroLocusArranger();
        void                   RestoreTiming();

        arrangerit             begin() {return arrangers.begin();};
        arrangerit             end() {return arrangers.end();};
        const_arrangerit       begin() const {return arrangers.begin();};
        const_arrangerit       end() const {return arrangers.end();};
        unsigned long          size() const;
        bool                   empty() const;

  void      PrintArrangers() const;
};

#endif  /* ARRANGERVEC_H */
