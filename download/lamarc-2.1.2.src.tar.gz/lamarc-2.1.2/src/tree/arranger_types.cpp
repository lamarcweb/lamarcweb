
#include <string>
#include "arranger_types.h"

const std::string arrangerstrings::BASE     = "Base-Arranger";
const std::string arrangerstrings::RESIM    = "Resim-Arranger";
const std::string arrangerstrings::DROP     = "Tree-Arranger";
const std::string arrangerstrings::HAP      = "Haplotype-Arranger";
const std::string arrangerstrings::BAYES    = "Bayes-Arranger";
const std::string arrangerstrings::DENO     = "Denovo-Arranger";
const std::string arrangerstrings::PROBHAP  = "Trait-Haplotype-Arranger";
const std::string arrangerstrings::RECSITE  = "RecSite-Arranger";
const std::string arrangerstrings::TREESIZE = "Tree-Size-Arranger";
const std::string arrangerstrings::LOCUS    = "Map-Arranger";
const std::string arrangerstrings::ZILCH    = "Do-Nothing-Arranger";
