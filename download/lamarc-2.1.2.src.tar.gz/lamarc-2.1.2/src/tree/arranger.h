// $Id: arranger.h,v 1.44 2007/07/10 23:46:41 jay Exp $

#ifndef ARRANGER_H
#define ARRANGER_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <math.h>
#include <vector>
#include <string>
#include <map>
#include "vectorx.h"
#include "branchbuffer.h"
#include "arranger_types.h"

// #include "event.h"    uses Event methods in .cpp
// #include "tree.h"
// #include "forceparam.h"
// #include "forcesummary.h"
// #include "random.h"

class Event;
class Tree;
class ForceParameters;
class Random;
class ForceSummary;
class ChainState;
class TimeList;

/*******************************************************************
 The Arranger class transforms a tree and decides whether the new
 tree should be accepted or rejected.  It provides a routine 
 DeNovoTree() to make an independent tree, and a routine Rearrange to 
 make a tree based on a previous tree.

 Subclasses of Arranger carry out different types of transformation.

 Written by Jim Sloan, revised by Mary Kuhner

 BayesArranger added 11/26/03 Mary.  This Arranger changes the
 parameter values rather than the tree.

 DeNovoArranger added 11/26/03 Mary.  This Arranger makes trees
 from scratch ("de novo") and replaces the DeNovo member function
 which could not be implemented on most Arrangers.

 RecSiteArranger removed 3/29/06 Mary as it was a deteriorating
 pseudogene.

 StairArranger added 4/4/07 Mary.  This Arranger changes the
 stairway of doom (AKA wiggling stick).

********************************************************************/

class Arranger
{
  private:
                     Arranger();                 // undefined
           Arranger& operator=(const Arranger&); // undefined

  protected:      
    Arranger(const Arranger& src);

    double  m_timing, m_savetiming;

  public:
            Tree   *m_tree;     // public for speedy access by Event subclasses
                                // also set by Chain::StartRegion()
    Random *randomSource;

                    Arranger(double timing);
    virtual         ~Arranger()                            {};

    // does not copy the tree pointer!
    virtual Arranger* Clone() const                       = 0; 
            
    // Arrangement functions 
    virtual void    SetParameters(ChainState& chainstate) = 0;
    virtual void    Rearrange(ChainState& chstate)              = 0;
    virtual void    ScoreRearrangement(ChainState& chstate) = 0;
    virtual bool    AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree) = 0;

    // Getter/Setters
            Tree*   GetTree() const          { return m_tree; };
            double  GetTiming() const        { return m_timing; };
    virtual std::string  GetName() const     { return arrangerstrings::BASE; };  

            void    SetTiming(double t);
            void    SetSaveTiming()             { m_savetiming = m_timing; };
            void    RestoreTiming()             { m_timing = m_savetiming; };


};

//____________________________________________________________________

/*********************************************************************
 ResimArranger is an abstract base class for Arrangers which do any 
 form of resimulation of lineages downward through the tree.  It is 
 tightly coupled with the Event class, which provides expertese needed 
 in resimulation.  The eventvec is a vector of all available types of 
 Events (depending on forces and other strategy details) which 
 ResimArranger polls to conduct its resimulation.
***********************************************************************/
  
class ResimArranger : public Arranger
{
  protected:
    std::vector<Event*> m_eventvec;    // code for various event types
    
    // helper functions
                   ResimArranger(const ResimArranger& src);
    void           ClearEventVec();
    virtual void   DropAll(double eventT);
    virtual double EventTime(Event*& returnevent, double eventT);
    virtual double Activate(Tree* oldtree);
    virtual void   Resimulate(double eventT);
    virtual bool   StopNow() const;
    double         NextInterval(double lastT);

    bool m_hasLogisticSelection;
    double m_logsel_cutoff;

  public:

    // The following variables are helpers for use by the subclasses
    // of Event.  They are public because otherwise Event would have to be a
    // friend, and this would tie Arranger to the specific subclasses of Event.

    LongVec1d m_xactives;   // dim: cross partitions
    LongVec2d m_pactives;   // dim: part-force X partitions
    LongVec1d m_xinactives; // dim: cross partitions
    LongVec2d m_pinactives; // dim: part-force X partitions

    BranchBuffer m_activelist;  // lineages currently active
    BranchBuffer m_inactivelist; // inactive lineages in current interval

                   ResimArranger(const ForceSummary& fs, double timing);
    virtual        ~ResimArranger() = 0;  // "implemented pure virtual"

    // Arrangement functions
    virtual void   SetParameters(ChainState& chainstate);
    virtual void   Rearrange(ChainState& chstate);
    virtual void   ScoreRearrangement(ChainState& chstate);
    virtual bool   AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree);
    virtual double Hastings(ChainState& chstate);

            long   ActiveSize() const {return m_activelist.Size();};

    // Getters/Setters
    virtual std::string GetName() const { return arrangerstrings::RESIM; };

};

//________________________________________________________________

class DropArranger: public ResimArranger
{
  protected:
                       DropArranger(const DropArranger& src) :
                         ResimArranger(src) {};

  public:
                       DropArranger(const ForceSummary& fs, double timing) 
			       : ResimArranger(fs, timing) {};
    virtual           ~DropArranger() {};
    virtual Arranger*  Clone() const;
    virtual std::string     GetName() const { return arrangerstrings::DROP; };

};

//________________________________________________________________

class DeNovoArranger: public ResimArranger
{
  protected:
                       DeNovoArranger(const DeNovoArranger& src) :
                         ResimArranger(src) {};

  public:
                       DeNovoArranger(const ForceSummary& fs, double timing) 
			       : ResimArranger(fs, timing) {};
    virtual           ~DeNovoArranger() {};
    virtual Arranger*  Clone() const;
    virtual void       Rearrange(ChainState& chstate);
    virtual bool       AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree);
    virtual std::string     GetName() const { return arrangerstrings::DENO; };

};

//________________________________________________________________

class BaseHapArranger : public Arranger
{
  protected:
                      BaseHapArranger(const BaseHapArranger& src)
                        : Arranger(src) {};

  public:
                      BaseHapArranger(double timing) : Arranger(timing)   {};
    virtual void      SetParameters(ChainState& chainstate);
    virtual void      Rearrange(ChainState& chstate) = 0;
    virtual void      ScoreRearrangement(ChainState& chstate);
    virtual bool      AcceptAndSynchronize(ChainState& chstate, double temperature, bool badtree);
    virtual Arranger* Clone() const = 0;
    virtual std::string    GetName() const = 0;
  
};

//________________________________________________________________

class HapArranger : public BaseHapArranger
{
  protected:
                      HapArranger(const HapArranger& src)
                      : BaseHapArranger(src) {};

  public:
                      HapArranger(double timing) : BaseHapArranger(timing) {};
    virtual void      Rearrange(ChainState& chstate);
    virtual Arranger* Clone() const;
    virtual std::string    GetName() const { return arrangerstrings::HAP; };

};

//________________________________________________________________
// The 'Probability Haplotype Arranger' (which I'm calling it here in the code
//  because that's what it is; we'll probably call it the 'Trait Haplotype
//  Arranger' for the user) is the arranger to use when you have haplotypes
//  that need to be swapped among a set instead of among just two alternating
//  options.
//  It's being added here for use for trait data with sets of possible
//  haplotype resolutions (i.e. HH, Hh, and hH).

class ProbHapArranger : public BaseHapArranger
{
  protected:
                      ProbHapArranger(const ProbHapArranger& src)
                      : BaseHapArranger(src) {};

  public:
                      ProbHapArranger(double timing):BaseHapArranger(timing) {};
    virtual void      Rearrange(ChainState& chstate);
    virtual void      ScoreRearrangement(ChainState& chstate);
    virtual Arranger* Clone() const;
    virtual std::string    GetName() const { return arrangerstrings::PROBHAP; };

};

//________________________________________________________________
//________________________________________________________________

class TreeSizeArranger : public ResimArranger
{
protected:
  TreeSizeArranger(const TreeSizeArranger& src) : ResimArranger(src) {};
  virtual double Activate(Tree* oldtree);
  virtual void   Resimulate(double eventT);

public:
  TreeSizeArranger(const ForceSummary& fs, double timing);
  virtual ~TreeSizeArranger() {};
  virtual double     Hastings(ChainState& chstate);
  virtual Arranger*  Clone() const;
  virtual std::string GetName() const { return arrangerstrings::TREESIZE; };

};

//________________________________________________________________
//________________________________________________________________

class BayesArranger : public Arranger
{
  private:
    DoubleVec1d m_oldlogs;
    DoubleVec1d m_newlogs;

  protected:
                      BayesArranger(const BayesArranger& src);
    

  public:
                      BayesArranger(double timing) : Arranger(timing) {};
    virtual void      SetParameters(ChainState& chainstate);
    virtual void      Rearrange(ChainState& chstate);
    virtual void      ScoreRearrangement(ChainState& chstate);
    virtual bool      AcceptAndSynchronize(ChainState&, double temperature, bool badtree);
    virtual Arranger* Clone() const;
    virtual std::string GetName() const { return arrangerstrings::BAYES; };
};

class LocusArranger : public Arranger
{
 protected:
  // LocusArranger(const LocusArranger& src);  //we accept the default.


 public:
                      LocusArranger(double timing) : Arranger(timing) {};
    virtual void      SetParameters(ChainState& chainstate);
    virtual void      Rearrange(ChainState& chstate);
    virtual void      ScoreRearrangement(ChainState& chstate);
    virtual bool      AcceptAndSynchronize(ChainState&, double temperature, bool badtree);
    virtual Arranger* Clone() const;
    virtual std::string GetName() const { return arrangerstrings::LOCUS; };
};

//________________________________________________________________

class ZilchArranger: public Arranger
{
 public:
  ZilchArranger(double timing) : Arranger(timing) {};
  virtual      ~ZilchArranger() {};
  virtual void SetParameters(ChainState& chainstate) {};
  virtual void Rearrange(ChainState& chstate) {};
  virtual void ScoreRearrangement(ChainState& chstate) {};
  virtual bool AcceptAndSynchronize(ChainState&, double temperature, bool badtree);
  virtual Arranger* Clone() const;
  virtual std::string GetName() const { return arrangerstrings::ZILCH; };
};

//________________________________________________________________

class StairArranger: public Arranger
{
  protected:
    double Mean_delta_x(double x, double s, double mu, double nu);
    double Var_delta_x(double x, double theta);

  public:
    StairArranger(double timing) : Arranger(timing) {};
    virtual ~StairArranger() {};
    virtual Arranger* Clone() const;
    // Arrangement functions
    virtual void SetParameters(ChainState& chainstate);
    virtual void Rearrange(ChainState& chstate);
    virtual void ScoreRearrangement(ChainState& chstate);
    virtual bool AcceptAndSynchronize(ChainState& chstate,
		    double temperature, bool badtree);

};


#endif /* ARRANGER_H */
