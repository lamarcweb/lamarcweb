// $Id: individual.h,v 1.17 2007/05/04 23:47:51 lpsmith Exp $

// This files defines the class that stores "individual" specific
// information.

#ifndef INDIVIDUAL_H
#define INDIVIDUAL_H

/* 
   Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include <vector>
#include <string>
#include <map>
//#include <pair>
#include "haplotypes.h"
#include "vectorx.h"
#include "branch.h" // for Branch_ptr declaration

class Branch;
class Random;
class DLCell;

class Individual
{
 private:
  long               m_id;
  LongVec2d          m_phasemarkers; // dim:  loci by markers
  LongVec2d          m_phasesites; // dim:  loci by sites (for XML output)
  string             m_name;
  vector<Branch_ptr> m_ptips;

  std::map<std::pair<string, long>, Haplotypes> m_haplotypesmap;
  std::map<std::pair<string, long>, vector<LocusCell> > m_currentHapsMap;
  // The string is the name of the locus, and the long is the marker (will
  //  almost always just be 0, but might not be).

 public:
  Individual()                                  {};
  ~Individual()                                 {};
  //We accept the default for:
  //Individual& operator=(const Individual& src);
  //Individual(const Individual& src);

  string          GetName()         const       {return m_name;};
  vector<Branch_ptr> GetAllTips()   const       {return m_ptips;};
  StringVec1d     GetAllTipNames()  const;
  long            GetId()           const       {return m_id;};
  const LongVec2d& GetPhaseMarkers() const      {return m_phasemarkers;};
  const LongVec2d& GetPhaseSites() const        {return m_phasesites;};
  bool            AnyPhaseUnknownSites() const;
  bool            MultipleTraitHaplotypes() const;

  void            PruneSamePhaseUnknownSites();
  std::pair<long,long> PickRandomPhaseMarker(Random& rs) const;
  std::pair<string,long> PickRandomHaplotypeMarker() const;

  void SetPhaseMarkers(const LongVec2d& pm);
  void SetPhaseSites(const LongVec2d& ps);
  void SetName(const string& newname)           {m_name = newname;};
  void SetTips(vector<Branch_ptr> tps)          {m_ptips = tps;};
  void AddTip(Branch_ptr tip)                   {m_ptips.push_back(tip);};
  void SetId(long newid)                        {m_id = newid;};
  void AddHaplotype(long regnum, string lname, long marker,
                    const StringVec1d& alleles, double penetrance);
  StringVec1d GetAllelesFor(string lname, long marker) const; //phase 1
  vector<LocusCell> GetLocusCellsFor(string lname, long marker) const; //phase 2
  Haplotypes GetHaplotypesFor(string lname, long marker) const;
  string GetMarkerDataFor(string lname, long marker) const; //phase 3/Output.
  void ChooseNewHaplotypesFor(string lname, long marker);
  bool ChooseRandomHaplotypesFor(string lname, long marker);
  void RandomizeAllHaplotypes();

  void ChooseFirstHaplotypeFor(string lname, long marker);
  bool ChooseNextHaplotypeFor(string lname, long marker);

  //For simulated data:
  void SetHaplotypes(string lname, long marker, Haplotypes haps);
  StringVec1d GetAllelesFromDLs(long locus, long marker, bool moving,
                                DataModel_ptr model);
  
  bool IsValid() const;
  StringVec1d GetTraitXML(long nspaces) const;

  //debugging
  void PrintHaplotypesFor(string lname, long marker) const;

};

typedef vector<Individual> IndVec;

#endif /* INDIVIDUAL_H */

