//$Id: prior.h,v 1.3 2005/07/29 23:55:40 ewalkup Exp $

#ifndef PRIOR_H
#define PRIOR_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/


//A prior is a shape.  Currently, we have two possible shapes:  a rectangle
// in linear space, and a rectangle in log space.  Those are simple enough
// that we don't really need a class for them, but if we want more complex
// priors in the future (say, a gaussian curve) we will probably want this.
// RandomDraw() encapsulates the usefulness of a prior--it picks a random
// number within its shape, with the chance based on volume.

//____________________________________________________________________________

#include "constants.h"

class UIVarsPrior;

class Prior
{

private:
  Prior();    // undefined
  priortype  m_priortype;
  double     m_lowerbound;
  double     m_upperbound;
  double     m_lnlower; //speed optimization--precalculated.
  double     m_lnupper;
  double     m_binwidth;

public:
  Prior(UIVarsPrior uiprior);
  Prior(paramstatus shouldBeInvalid);
  //Use the default copy constructor.
  virtual ~Prior();
  bool      operator==(const Prior src) const;  // compare priors

  virtual priortype GetPriorType()  const {return m_priortype;};
  virtual double    GetLowerBound() const {return m_lowerbound;};
  virtual double    GetUpperBound() const {return m_upperbound;};
  virtual double    GetBinwidth()   const {return m_binwidth;};

  virtual std::pair<double, double> RandomDraw() const;
};

#endif /* PRIOR_H */

