//$Id: parameter.cpp,v 1.37 2006/05/12 23:14:29 lpsmith Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "parameter.h"
#include "forcesummary.h"
#include "prior.h"
#include "registry.h"
#include "mathx.h"
#include "stringx.h"
#include "ui_vars_prior.h"
#include "ui_strings.h" // for kludgy Parameter::GetUserName()
//#include "regiongammainfo.h"
class RegionGammaInfo;

using namespace std;

//___________________________________________________________________________

double ResultStruct::GetMLE(long region) const
{
  assert(region >= 0 && static_cast<unsigned long>(region) < mles.size());
  return mles[region];
} /* GetMLE */

//___________________________________________________________________________

double ResultStruct::GetOverallMLE() const
{
// if there is exactly one region, we will return the regional
// mle as the overall mle.  If there are multiple regions and
// no overall mle, something is wrong.
 assert(!(overallmle.empty() && mles.size() != 1));

 if (overallmle.empty()) return mles[0];
 else return overallmle[0];
} /* GetOverallMLE */

//___________________________________________________________________________

DoubleVec1d ResultStruct::GetAllMLEs()  const
{
  assert(!mles.empty());
  DoubleVec1d result = mles;
  if (!overallmle.empty()) result.push_back(overallmle[0]);
  return result;
} /* GetAllMLEs */

//___________________________________________________________________________

const ProfileStruct& ResultStruct::GetProfile(long region) const
{
  assert(region >= 0 && static_cast<unsigned long>(region) < profiles.size());
  return profiles[region];
} /* GetProfile */

//___________________________________________________________________________

const ProfileStruct& ResultStruct::GetOverallProfile() const
{
// if there is exactly one region, we will return its profile.
// otherwise, it is an error to ask for overalls if there aren't
// any.

  assert(!(overallprofile.empty() && profiles.size() != 1));

  if (overallprofile.empty()) return profiles[0];
  else return overallprofile[0];
} /* GetOverallProfile */

//___________________________________________________________________________

vector<ProfileStruct> ResultStruct::GetAllProfiles() const
{
  assert(!profiles.empty());
  vector<ProfileStruct> result = profiles;
  result.push_back(overallprofile[0]);
  return result;
} /* GetAllProfiles */

const ProfileLineStruct& ResultStruct::GetProfileFor(double centile,
                                                     long reg) const
{
  if (reg == registry.GetDataPack().GetNRegions()) {
    return GetOverallProfile().GetProfileLine(centile);
  }
  return GetProfile(reg).GetProfileLine(centile);
}

void ResultStruct::AddMLE(double mle, long region)
{
  //We have to replace the MLE sometimes when reading from a summary file.
  if (region < static_cast<long>(mles.size())) {
    mles[region] = mle;
  }
  else {
    assert(region == static_cast<long>(mles.size()));
    mles.push_back(mle);
  }
}

void ResultStruct::AddOverallMLE(double mle)
{
  if (overallmle.size() > 0) {
    overallmle[0] = mle;
  }
  else {
    overallmle.push_back(mle);
  }
}

//___________________________________________________________________________
//___________________________________________________________________________


Parameter::Parameter(   paramstatus status,
                        unsigned long paramvecIndex,
                        const string sname, 
                        const string lname, 
                        force_type thisforce,
                        method_type meth,
                        proftype prof,
                        const UIVarsPrior & uiprior,
			double truevalue
                        )
: m_status(status),
  m_paramvecIndex(paramvecIndex),
  m_shortname(sname),
  m_name(lname),
  m_force(thisforce),
  m_method(meth),
  m_profiletype(prof),
  m_truevalue(truevalue),
  m_prior(uiprior)
{
  if (m_status == pstat_constant) {
    m_profiletype = profile_NONE;
    m_name += " (held constant)";
  } // The names of grouped parameters are set in registry.cpp later.
} /* Parameter constructor */


Parameter::Parameter(paramstatus status, unsigned long paramvecIndex)
  : m_status(status),
    m_paramvecIndex(paramvecIndex),
    m_method(method_PROGRAMDEFAULT),
    m_profiletype(profile_NONE),
    m_prior(status)
{
  if (m_status != pstat_invalid) {
    throw implementation_error("Tried to create a valid parameter object using the invalid parameter constructor.");
  }
} /* Invalid parameter constructor */

//___________________________________________________________________________
//___________________________________________________________________________

string Parameter::GetUserName() const
{
string uname(m_name);

string forcename;
if (m_force == force_COAL) forcename = uistr::theta;
else if (m_force == force_MIG) forcename = uistr::migrationByID;
else if (m_force == force_DISEASE) forcename = uistr::muRate;
else if (m_force == force_REC) forcename = uistr::recRate;
else if (m_force == force_GROW) forcename = uistr::growthRate;
else if (m_force == force_REGION_GAMMA) forcename = uistr::regGammaShape; 
else assert(false); // can't get here in Parameter::GetUserName

// JDEBUG -- this will fail if a name contains three or more
// occurences of the forcename---really want to use find2nd
// instead..if that even exists...
unsigned long found(uname.rfind(forcename));

assert(found != string::npos);
if (found != 0) { // if the last occurence isn't at the start
   // remove the word "and" plus flanking blankspaces
   found -= 5;
   assert(found > 0);
   uname.erase(found,uname.size()-found);
}

return uname;

} /* GetUserName */

//___________________________________________________________

pair<double, double> Parameter::DrawFromPrior() const
{
  return m_prior.RandomDraw();
} /* DrawFromPrior */

//___________________________________________________________

bool Parameter::IsZeroTrueMin()
{
  if (m_force == force_GROW)
    return false;
  return true;
}

//___________________________________________________________________________

vector<centilepair> Parameter::GetPriorLikes(long region) const
{

  assert(IsValid());
  vector<centilepair> answer;

  const ProfileStruct& profile = m_results.GetProfile(region);
  vector<ProfileLineStruct>::const_iterator it;

  for (it = profile.profilelines.begin();
       it != profile.profilelines.end();
       ++it)
  {
    centilepair newpair(it->percentile, it->loglikelihood);
    answer.push_back(newpair);
  }
  return answer;
  
} /* GetPriorLikes */

//___________________________________________________________________________

vector<centilepair> Parameter::GetOverallPriorLikes() const
{
  assert(IsValid());

  vector<centilepair> answer;

  const ProfileStruct& profile = m_results.GetOverallProfile();
  vector<ProfileLineStruct>::const_iterator it;

  for (it = profile.profilelines.begin();
       it != profile.profilelines.end();
       ++it)
  {
    centilepair newpair(it->percentile, it->loglikelihood);
    answer.push_back(newpair);
  }
  return answer;
  
} /* GetOverallPriorLikes */

//___________________________________________________________________________

vector<vector<centilepair> > Parameter::GetProfiles(long region) const
{
  assert(IsValid());

  const ProfileStruct& profile = m_results.GetProfile(region);
  vector<ProfileLineStruct>::const_iterator line;

  vector<vector<centilepair> > answer;
  vector<centilepair> answerline;

  long parameter;
  long numparams = 0;
  // hack, sorry
  for (line = profile.profilelines.begin(); line != profile.profilelines.end();
       ++line) {
    if (!line->profparam.empty()) {
      numparams = line->profparam.size();
      break;
    }
  }

  // if this assert fires, profiles have been requested but none
  // whatsoever can be found....
  // assert(numparams > 0);
  // LS NOTE:  In a bayesian analysis, having no profiles is expected--we
  //  use GetCIs and GetLikes, etc. instead.  It's convenient to call this
  //  routine anyway, so I don't have to special-case the calling code in
  //  runreports.  Hence, commenting out the above 'assert'.
  
  //long numparams = profile.profilelines[0].profparam.size();

  for (parameter = 0; parameter < numparams; ++parameter)
  {
    for (line = profile.profilelines.begin();
         line != profile.profilelines.end();
         ++line) 
    {
      double thisparam = line->profparam[parameter];
      centilepair newpair(line->percentile, thisparam);
      answerline.push_back(newpair);
    }
    answer.push_back(answerline);
    answerline.clear();
  }

  return answer;

} /* GetProfiles */

//___________________________________________________________________________

vector<vector<centilepair> > Parameter::GetOverallProfile() const
{
  assert(IsValid());

  vector<vector<centilepair> > answer;
  vector<centilepair> answerline;

  const ProfileStruct& profile = m_results.GetOverallProfile();
  vector<ProfileLineStruct>::const_iterator line;

  long parameter;
  // hack, sorry
  long numparams = profile.profilelines[0].profparam.size();

  for (parameter = 0; parameter < numparams; ++parameter)
  {
    for (line = profile.profilelines.begin();
         line != profile.profilelines.end();
         ++line) 
    {
      double thisparam = line->profparam[parameter];
      centilepair newpair(line->percentile, thisparam);
      answerline.push_back(newpair);
    }
    answer.push_back(answerline);
    answerline.clear();
  }

  return answer;

} /* GetOverallProfile */

//___________________________________________________________________________

vector<centilepair> Parameter::GetCIs(long region) const
{
  assert(IsValid());

  vector<centilepair> answer;

  const ProfileStruct& profile = m_results.GetProfile(region);
  vector<ProfileLineStruct>::const_iterator it;

  for (it = profile.profilelines.begin();
       it != profile.profilelines.end();
       ++it) 
  {
    centilepair newpair(it->percentile, it->profilevalue);
    answer.push_back(newpair);
  }
  return answer;

} /* GetCIs */

//___________________________________________________________________________

vector<centilepair> Parameter::GetOverallCIs() const
{
  assert(IsValid());

  vector<centilepair> answer;

  const ProfileStruct& profile = m_results.GetOverallProfile();
  vector<ProfileLineStruct>::const_iterator it;

  for (it = profile.profilelines.begin();
       it != profile.profilelines.end();
       ++it) 
  {
    centilepair newpair(it->percentile, it->profilevalue);
    answer.push_back(newpair);
  }
  return answer;

} /* GetOverallCIs */

bool Parameter::CentileIsExtremeLow(double centile, long reg) const
{
  return m_results.GetProfileFor(centile, reg).isExtremeLow;
}

bool Parameter::CentileIsExtremeHigh(double centile, long reg) const
{
  return m_results.GetProfileFor(centile, reg).isExtremeHigh;
}

bool Parameter::CentileHadWarning(double centile, long reg) const
{
  return m_results.GetProfileFor(centile, reg).maximizerWarning;
}

//___________________________________________________________________________

void Parameter::AddProfile(const ProfileStruct& prof, likelihoodtype like)
{
  assert(IsValid());
  switch (like) {
  case ltype_ssingle: 
    m_results.AddProfile(prof);
    break;
  case ltype_replicate:
    m_results.AddProfile(prof);
    break;
  case ltype_region:
    m_results.AddOverallProfile(prof);
    break;
  case ltype_gammaregion:
    RegionGammaInfo *pRegionGammaInfo = registry.GetRegionGammaInfo();
    if (!pRegionGammaInfo ||
	!pRegionGammaInfo->CurrentlyPerformingAnalysisOverRegions())
      {
	string msg = "Parameter::AddProfile() was told to add a profile ";
	msg += "for an overall estimate over all genomic regions with ";
	msg += "gamma-distributed background mutation rates, but the ";
	msg += "necessary RegionGammaInfo object was not found, or was ";
	msg += "found in the \"off\" state, neither of which should happen.";
	throw implementation_error(msg);
      }
    m_results.AddOverallProfile(prof);
    if (!pRegionGammaInfo->HaveProfile() && force_REGION_GAMMA == m_force)
      pRegionGammaInfo->AddProfile(prof);
    break;
  }
  
} /* AddProfile */

//___________________________________________________________________________
//___________________________________________________________________________

// Initialization of static variable, needs to be in .cpp
bool ParamVector::locked = false;

//___________________________________________________________________________


// This constructor can make a read-only ParamVector 

ParamVector::ParamVector(bool readonly)
  : m_readonly(readonly),
    forcesum(registry.GetForceSummary())
{
  if (m_readonly) {
    parameters = forcesum.GetAllParameters();
  } else {
    assert(!locked);        // attempt to check out a second set of parameters!
    parameters = forcesum.GetAllParameters();
    locked = true;
  }
  const RegionGammaInfo *pRegionGammaInfo = registry.GetRegionGammaInfo();
  if (pRegionGammaInfo && pRegionGammaInfo->CurrentlyPerformingAnalysisOverRegions())
    {
      UIVarsPrior gammaprior(force_REGION_GAMMA);
      Parameter paramAlpha(pRegionGammaInfo->GetParamStatus(),
			   parameters.size(),
			   "alpha",
			   "alpha (shape parameter for gamma over regions)",
			   force_REGION_GAMMA,
                           method_PROGRAMDEFAULT,
                           pRegionGammaInfo->GetProfType(),
                           gammaprior,
                           FLAGDOUBLE);
      if (pRegionGammaInfo->HaveMLE())
	{
	  paramAlpha.AddOverallMLE(pRegionGammaInfo->GetMLE());
	  if (pRegionGammaInfo->HaveProfile())
	    paramAlpha.AddProfile(pRegionGammaInfo->GetProfile(), ltype_gammaregion);
	}
      parameters.push_back(paramAlpha);
    }

} /* ParamVector */
//___________________________________________________________________________

ParamVector::~ParamVector()
{
  if (m_readonly) return;

  assert(locked);        // how did it get unlocked before destruction??
  forcesum.SetAllParameters(parameters);
  locked = false;

} /* ParamVector destructor */

//___________________________________________________________________________

Parameter& ParamVector::operator[](long index)
{
  assert(ParamVector::locked);  // should only be unlocked in 'const' context

  // bounds checking
  assert(index >= 0);
  assert(index < static_cast<long>(parameters.size()));

  return parameters[index];

} /* ParamVector operator[] */

//___________________________________________________________________________

const Parameter& ParamVector::operator[](long index) const
{
  assert(index >= 0);
  assert(index < static_cast<long>(parameters.size()));

  return parameters[index];

} /* ParamVector operator[] const */

//___________________________________________________________________________

paramlistcondition ParamVector::CheckCalcProfiles() const
{
  vector <Parameter> :: const_iterator pit;
  long ok=0;
  long nok=0;
  for(pit=parameters.begin(); pit != parameters.end(); pit++)
    {
      if(pit->IsValid())
        {
          switch(pit->GetProfileType())
            {
            case profile_FIX:
            case profile_PERCENTILE:
              ok++;
              break;
            case profile_NONE:
              nok++;
              continue;
            }
        }
    }
  long sum = ok + nok;
  if(nok==sum)
    return paramlist_NO;
  else
    {
      if(ok==sum)
        return paramlist_YES;
      else
        return paramlist_MIX;
    }
}

//___________________________________________________________________________

paramlistcondition ParamVector::CheckCalcPProfiles() const
{
  vector <Parameter> :: const_iterator pit;
  long fok=0;
  long pok=0;
  long nok=0;
  for(pit=parameters.begin(); pit != parameters.end(); pit++) {
    if(pit->IsValid()) {
      switch(pit->GetProfileType()) {
      case profile_FIX:
	fok++;
	break;
      case profile_PERCENTILE:
	pok++;
	break;
      case profile_NONE:
	nok++;
	continue;
      }
    }
  }
  long sum = fok + pok + nok;
  if(nok==sum)
    return paramlist_NO;
  else
    {
      if(pok==sum)
        return paramlist_YES;
      else
        return paramlist_MIX;
    }
}

//___________________________________________________________________________

long ParamVector::NumProfiledParameters() const
{
  vector<Parameter>::const_iterator it;

  long result = 0;

  for (it = parameters.begin(); it != parameters.end(); ++it) {
    if (it->IsProfiled())
        ++result;
  }

  return result;
} /* NumProfiledParameters */

//___________________________________________________________________________

long ParamVector::NumVariableParameters() const
{
  vector<Parameter>::const_iterator it;

  long result = 0;

  for (it = parameters.begin(); it != parameters.end(); ++it) {
    paramstatus pstat = it->GetStatus();
    switch (pstat)
      {
      case pstat_unconstrained:
      case pstat_joint:
        ++result;
        break;
      case pstat_invalid:
      case pstat_constant:
      case pstat_identical:
        break;
      }
  }

  return result;
} /* NumVariableParameters */

//___________________________________________________________________________

