// $Id: vectorx.cpp,v 1.9 2007/05/02 00:45:12 lpsmith Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <math.h>
#include <assert.h>
#include "vectorx.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//___________________________________________________________
// maintenance functions

// forward declarations if helper functions of the maintenace functions
double logsave(const double value);
double log0(const double value);

void LogVec0(const vector<double> &in, vector<double> &out)
{
  assert(in.size() == out.size());
  transform(in.begin(),in.end(),out.begin(),log0);    
}
 
// helper function that keeps the structural zeros intact
// used in LogVec0() in  PostLike::Setup0()
double log0(const double value)
{
  return ((value > 0.) ? log(value) : 0.0);
}



long LongSquareRootOfLong(long shouldBeASquare)
{
  // this is a funny-looking way to take a square root,
  // necessitated by the fact that the C library only provides
  // floating-point square root, and we don't want to deal with
  // the consequences of rounding error.

  long i;

  for (i = 1; i <= long(shouldBeASquare/2); ++i) {
    if (i * i == shouldBeASquare) {
        return i;
    }
  }
  throw ("Attempt to take long square root of non-square");
}
