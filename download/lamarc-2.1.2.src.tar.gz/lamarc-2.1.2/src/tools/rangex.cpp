// $Id: rangex.cpp,v 1.5 2007/09/13 00:06:41 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "rangex.h"
#include "stringx.h"
#include "registry.h"

using std::string;
using std::make_pair;

string ToString(rangepair rpair)
{
  //Note!  This prints stuff out in 'user units' instead of 'internal units'.
  // In other words, if the range is <0,34>, this is an 'open-ended' interval
  // and the actual active sites are 0:33
  //
  //Furthermore, if the user is expecting to have no zeroes in the output, we
  // need to convert the 0 to -1, and display "-1:33".
  rpair.second--;
  rpair = ToNoZeroesIfNeeded(rpair);
  string retval = ToString(rpair.first);
  if (rpair.second > rpair.first) {
    retval += ":" + ToString(rpair.second);
  }
  return retval;
}

string ToString(rangeset rset)
{
  rangeset::iterator rpair = rset.begin();
  if (rpair == rset.end()) {
    return "(none)";
  }
  string retval = ToString(*rpair);
  rpair++;
  for (; rpair != rset.end(); rpair++){
    retval += ", " + ToString(*rpair);
  }
  return retval;
}
  
rangeset AddPairToRange(const rangepair& addpart, const rangeset& rset)
{
  rangeset retset = rset;

  rangepair low  = make_pair(addpart.first, addpart.first);
  rangepair high = make_pair(addpart.second, addpart.second);

  long newlow = low.first;
  long newhigh = high.second;

  rangesetiter early = retset.lower_bound(low);
  if (early != retset.begin()) {
    early--;
    if (early->second >= low.first) {
      //'low' falls within early's interval
      newlow = early->first;
    }
  }
  
  rangesetiter late = retset.upper_bound(high);
  //We need to increment this late.first == high.first
  if (late != retset.end()) {
    if (late->first == high.first) {
      late++;
    }
  }
  if (late != retset.begin()) {
    late--;
    if (late->second > high.first) {
      //'high' falls within late's interval
      newhigh = late->second;
    }
  }

  early = retset.lower_bound(make_pair(newlow, newlow+1));
  late  = retset.upper_bound(make_pair(newhigh-1, newhigh));

  retset.erase(early, late);
  retset.insert(make_pair(newlow, newhigh));

  return retset;

}

rangeset RemovePairFromRange(const rangepair& removepart, const rangeset& rset)
{
  rangeset retset;
  for (rangeset::iterator range=rset.begin(); range != rset.end(); range++){
    if ((range->first >= removepart.first) &&
        (range->second <= removepart.second)) {
      //Don't add it.
    }
    else {
      if ((range->first < removepart.first) &&
          (range->second > removepart.second)) {
        //Add two outside halves.
        retset.insert(make_pair(range->first, removepart.first));
        retset.insert(make_pair(removepart.second, range->second));
      }
      else if ((range->second > removepart.first) &&
               (range->second <= removepart.second)) {
        //Add only the first half.
        retset.insert(make_pair(range->first, removepart.first));
      }
      else if ((range->first >= removepart.first) &&
               (range->first <= removepart.second)) {
        //Add only the second half.
        retset.insert(make_pair(removepart.second, range->second));
      }
      else {
        //Add the whole thing.
        retset.insert(*range);
      }
    }
  }
  return retset;
}

rangeset RemoveRangeFromRange(const rangeset& removerange, const rangeset& rset)
{
  rangeset retset = rset;
  for (rangeset::iterator removepair = removerange.begin();
       removepair != removerange.end(); removepair++) {
    retset = RemovePairFromRange(*removepair, retset);
  }
  return retset;
}

//LS NOTE:
//These functions originally written for range.cpp, but ended up being
// needed elsewhere.
//
//Note that 'Union' (used to be 'OR' but I got confused too often) actually
// does the exact same thing that 'AddRangeToRange' used to, but much faster,
// so I took out AddRangeToRange entirely.  Perhaps there's a similar way to
// speed up RemoveRangeFromRange?  We'll see if it shows up in the profiler.
rangeset Union(const rangeset& set1, const rangeset& set2)
{

  if (set1.empty()) return set2;
  if (set2.empty()) return set1;

  rangeset mergeset;
  merge(set1.begin(),set1.end(),set2.begin(),set2.end(),
        inserter(mergeset,mergeset.begin()));

  rangeset newset;
  rangeset::iterator rit;
  for(rit = mergeset.begin(); rit != mergeset.end(); ++rit)
    ORAppend(*rit,newset);

  return newset;

} /* OR */

//_______________________________________________________________
//Helper function for 'Union'
void ORAppend(rangepair newrange, rangeset& oldranges)
{

  if (oldranges.empty()) {
    oldranges.insert(newrange);
    return;
  }

  rangeset::iterator last = --oldranges.end();

  assert(newrange.first >= last->first); // expect sequential,
  // sorted input

  // new is contained in old
  if (newrange.second <= last->second) return;

  // new is after old
  if (newrange.first > last->second) {
    oldranges.insert(oldranges.end(),newrange);
    return;
  }

  // new starts within old and extends past it
  newrange.first = last->first;
  oldranges.erase(last);
  oldranges.insert(oldranges.end(),newrange);
  return;

} /* Range::ORAppend */

//_______________________________________________________________
//Used to be 'AND' until I got confused too often.
rangeset Intersection(const rangeset& mother, const rangeset& father)
{

  rangeset::const_iterator m = mother.begin();
  rangeset::const_iterator f = father.begin();

  rangeset result;
  rangepair newpair;

  if (mother.empty() || father.empty()) return result;

  while (true) {
    newpair.first = std::max((*m).first, (*f).first);
    newpair.second = std::min((*m).second, (*f).second);

    if (newpair.first < newpair.second)
      result.insert(result.end(),newpair);

    if ((*m).second < (*f).second) ++m;
    else ++f;

    if (m == mother.end() || f == father.end()) return result;
  }

} /* AND */

//_______________________________________________________________

long CountSites(rangeset rset)
{
  long retval(0);
  for (rangeset::iterator rpair = rset.begin(); rpair != rset.end(); rpair++) {
    retval += rpair->second - rpair->first;
  }
  return retval;
}


//These functions are to be used when converting site labels for display to
// the user, and from *menu* input from the user.  It is assumed that in the
// XML, the 'user input' has already been converted to the 'sequential' version.
long ToSequentialIfNeeded(long input)
{
  //Note:  input might equal zero if it was the upper end of a rangepair,
  // since rangepairs are open-ended by default.  In other words, if the user
  // types in "-20:-1" in the menu, the first thing that happens is that these
  // numbers are converted to the pair <-20, 0>.  To convert these values to
  // the 'sequential' numbering system, this needs to be converted to the
  // pair <-19, 1>.

  if (registry.GetConvertOutputToEliminateZeroes() && (input<=0)) {
    input++;
  }
  return input;
}

long ToNoZeroesIfNeeded(long input)
{
  if (registry.GetConvertOutputToEliminateZeroes() && (input <=0)) {
    input--;
  }
  return input;
}

rangepair ToSequentialIfNeeded(rangepair input)
{
  if (registry.GetConvertOutputToEliminateZeroes()) {
    input.first = ToSequentialIfNeeded(input.first);
    input.second = ToSequentialIfNeeded(input.second);
  }
  return input;
}

rangepair ToNoZeroesIfNeeded(rangepair input)
{
  if (registry.GetConvertOutputToEliminateZeroes()) {
    input.first = ToNoZeroesIfNeeded(input.first);
    input.second = ToNoZeroesIfNeeded(input.second);
  }
  return input;
}
