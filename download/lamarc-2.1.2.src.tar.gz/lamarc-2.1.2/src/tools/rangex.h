// $Id: rangex.h,v 1.5 2007/09/13 00:06:41 lpsmith Exp $
#ifndef RANGEX_H
#define RANGEX_H  

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <set>
#include <vector>

struct rangecmp
{
  bool operator()(const std::pair<long, long>& p1, const std::pair<long, long>& p2) {
    if (p1.first == p2.first) {
      return (p1.second < p2.second);
    }
    return (p1.first < p2.first);
  }
};

typedef std::pair<long,long>                    rangepair;
typedef std::vector<rangepair>                  rangevector;
typedef std::set<rangepair, rangecmp>           rangeset;
typedef std::set<rangepair, rangecmp>::iterator rangesetiter;

std::string ToString(rangepair rpair);
std::string ToString(rangeset rset);

rangeset AddPairToRange(const rangepair& addpart, const rangeset& rset);
rangeset RemovePairFromRange(const rangepair& removepart, const rangeset& rset);
rangeset RemoveRangeFromRange(const rangeset& removerange, const rangeset& rset);
rangeset Union(const rangeset& set1, const rangeset& set2);
void     ORAppend(rangepair newrange, rangeset& oldranges);
rangeset Intersection(const rangeset& set1, const rangeset& set2);

long     CountSites(rangeset rset);

long ToSequentialIfNeeded(long input);
long ToNoZeroesIfNeeded(long input);
rangepair ToSequentialIfNeeded(rangepair input);
rangepair ToNoZeroesIfNeeded(rangepair input);

#endif /* RANGEX_H */

