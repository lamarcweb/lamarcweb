// $Id: tools.h,v 1.2 2004/05/03 20:51:54 ewalkup Exp $

// This is just a catch-all include file for all of the program
//    specific extensions to the standard library

#ifndef TOOLS_H
#define TOOLS_H

#include "stringx.h"
#include "vectorx.h"

#endif /* TOOLS_H */
