//$Id: nomenufilereaddialog.cpp,v 1.2 2004/08/06 20:16:04 ewalkup Exp $

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>

#include "defaults.h"
#include "nomenufilereaddialog.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "xml.h"

using std::string;

NoMenuFileReadDialog::NoMenuFileReadDialog(XmlParser & parser) 
    : DialogNoInput(), m_parser(parser)
{
}

NoMenuFileReadDialog::~NoMenuFileReadDialog()
{
}

string NoMenuFileReadDialog::outputString()
{
    return
     string("---------------------------------------------------------------------------\n")
    +string("** Menu-less version generated with \"configure --disable-menu\"\n")
    +string("** For menu re-run \"configure --enable-menu\" and recompile\n")
    +string("---------------------------------------------------------------------------\n")
    +string("** Reading data from \"")
        +m_parser.GetFileName()
        +string("\" and writing to its default outfile\n")
    +string("---------------------------------------------------------------------------\n");

}

void
NoMenuFileReadDialog::performAction()
{
    m_parser.ParseFileData(m_parser.GetFileName());
}

