//$Id: forcesmenus.h,v 1.9 2005/01/07 21:32:03 lpsmith Exp $
#ifndef FORCESMENUS_H
#define FORCESMENUS_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "newmenuitems.h"

class UIInterface;

class ForcesSubMenuItem : public SubMenuItem
{
    protected:
        std::string force;
        std::string forceLegal;
    public:
        ForcesSubMenuItem(std::string myKey,
                            UIInterface & myui,
                            std::string myForce,
                            std::string myForceLegal,
                            NewMenuCreator * mySubMenuCreator);
        virtual ~ForcesSubMenuItem();
        virtual std::string GetVariableText();
        virtual bool IsVisible();
};

class ForcesMenu : public NewMenu
{
    public:
        ForcesMenu(UIInterface & myui);
        ~ForcesMenu();
};

class ForcesMenuCreator : public NewMenuCreator
{
    protected:
        UIInterface & ui;
    public:
        ForcesMenuCreator(UIInterface & myui) : ui(myui) {};
        virtual ~ForcesMenuCreator() {};
        NewMenu_ptr Create() { return NewMenu_ptr(new ForcesMenu(ui));};
};

class ForceSubMenuItem : public SubMenuItem
{
private:
  ForceSubMenuItem(); //undefined
  UIId m_id;
public:
  ForceSubMenuItem(std::string myKey,UIInterface & myui,
                   NewMenuCreator * myCreator, UIId id);
  virtual ~ForceSubMenuItem();
  virtual bool IsVisible();
};

#endif  /* FORCESMENUS_H */
