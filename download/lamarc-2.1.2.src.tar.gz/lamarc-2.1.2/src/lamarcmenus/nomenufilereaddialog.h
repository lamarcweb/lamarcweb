//$Id: nomenufilereaddialog.h,v 1.2 2004/08/06 20:16:04 ewalkup Exp $
#ifndef NOMENUDIALOG_H
#define NOMENUDIALOG_H

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "dialognoinput.h"
#include <string>

class XmlParser;

class NoMenuFileReadDialog : public DialogNoInput
{
    protected:
        XmlParser &     m_parser;
        virtual std::string outputString();
        virtual void performAction();
    public:
        NoMenuFileReadDialog(XmlParser & parser);
        virtual ~NoMenuFileReadDialog();
};

#endif /* NOMENUDIALOG_H */
