//$Id: profilemenus.cpp,v 1.9 2007/07/10 23:46:41 jay Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "lamarc_strings.h"
//#include "newmenuitems.h"
#include "profilemenus.h"
//#include "togglemenuitem.h"
#include "ui_interface.h"
#include "ui_strings.h"

using std::string;

ProfileMenu::ProfileMenu(UIInterface & myui)
    : NewMenu(myui,lamarcmenu::profileTitle, lamarcmenu::profileInfo)
{
    AddMenuItem(new ToggleMenuItemNoId("A",ui,uistr::allProfilesOn));
    AddMenuItem(new ToggleMenuItemNoId("X",ui,uistr::allProfilesOff));
    AddMenuItem(new ToggleMenuItemNoId("P",ui,uistr::allProfilesPercentile));
    AddMenuItem(new ToggleMenuItemNoId("F",ui,uistr::allProfilesFixed));
    AddMenuItem(new ProfileByForceMenuItemGroup(ui));
}

ProfileMenu::~ProfileMenu()
{
}

ProfileByForceMenuItemGroup::ProfileByForceMenuItemGroup(UIInterface& ui)
    : MenuDisplayGroupBaseImplementation(ui,uistr::profileByForce)
{
}

ProfileByForceMenuItemGroup::~ProfileByForceMenuItemGroup()
{
}

MenuInteraction_ptr
ProfileByForceMenuItemGroup::MakeOneHandler(UIId id)
{
    return MenuInteraction_ptr(new 
      ProfileMenuForOneForce(ui,id));
}

UIIdVec1d
ProfileByForceMenuItemGroup::GetVisibleIds()
{
    return ui.doGetUIIdVec1d(uistr::validForces);
}

string
ProfileByForceMenuItemGroup::GetKey(UIId id)
{
    switch(id.GetForceType())
    {
    case force_COAL:
      return "T";
      break;
    case force_DISEASE:
      return "D";
      break;
    case force_GROW:
      return "G";
      break;
    case force_MIG:
      return "M";
      break;
    case force_REC:
      return "R";
      break;
    case force_REGION_GAMMA:
      return "L";
      break;
    case force_EXPGROWSTICK:
      return "ES";
      break;
    case force_LOGISTICSELECTION:
      return "S";
      break;
    case force_LOGSELECTSTICK:
      return "LS";
      break;
    }
    throw implementation_error("force_type enum missing case in ProfileByForceMenuItemGroup::GetKey");
}

ProfileMenuForOneForce::ProfileMenuForOneForce(UIInterface& ui,UIId id)
    : NewMenu(ui,lamarcmenu::forceProfileTitle+ToString(id.GetForceType()),
              lamarcmenu::forceProfileInfo)
{
    AddMenuItem(new ToggleMenuItemId("A",ui,uistr::oneForceProfilesOn,id));
    AddMenuItem(new ToggleMenuItemId("X",ui,uistr::oneForceProfilesOff,id));
    AddMenuItem(new ToggleMenuItemId("P",ui,uistr::oneForceProfileType,id));
    AddMenuItem(new ToggleMenuItemGroupProfiles(ui,id));
}

ProfileMenuForOneForce::~ProfileMenuForOneForce()
{
}

SubMenuProfileForOneForce::SubMenuProfileForOneForce(std::string key, UIInterface& ui, UIId id)
  : ForceSubMenuItem(key, ui, new ProfileMenuForOneForceCreator(ui, id), id)
{
}

SubMenuProfileForOneForce::~SubMenuProfileForOneForce()
{
}

ToggleMenuItemGroupProfiles::ToggleMenuItemGroupProfiles(UIInterface & ui,UIId id)
    : ToggleMenuItemGroup(ui,uistr::profileByID), m_id(id)
{
}

ToggleMenuItemGroupProfiles::~ToggleMenuItemGroupProfiles()
{
}

UIIdVec1d
ToggleMenuItemGroupProfiles::GetVisibleIds()
{
    return ui.doGetUIIdVec1d(uistr::validParamsForForce,m_id);
}



