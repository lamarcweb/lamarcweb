//$Id: coalmenus.cpp,v 1.13 2005/01/07 21:32:03 lpsmith Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "constraintmenus.h"
#include "coalmenus.h"
#include "forcesummary.h"
#include "lamarc_strings.h"
#include "menu_strings.h"
#include "priormenus.h"
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "profilemenus.h"
using std::string;

//-----------------------------------------------------------------

SetAllThetasMenuItem::SetAllThetasMenuItem(string myKey, UIInterface & ui)
    : SetMenuItemId(myKey,ui,uistr::globalTheta, UIId(force_COAL, uiconst::GLOBAL_ID))
{
}

SetAllThetasMenuItem::~SetAllThetasMenuItem()
{
}

bool SetAllThetasMenuItem::IsVisible()
{
    return (ui.doGetLong(uistr::crossPartitionCount) > 1);
}

string SetAllThetasMenuItem::GetVariableText()
{
    return "";
}

/////////

SetThetasFstMenuItem::SetThetasFstMenuItem(string key,UIInterface & ui)
    : ToggleMenuItemNoId(key,ui,uistr::fstSetTheta)
{
}

SetThetasFstMenuItem::~SetThetasFstMenuItem()
{
}

bool SetThetasFstMenuItem::IsVisible()
{
    return (ui.doGetLong(uistr::crossPartitionCount) > 1);
}


/////////

SetMenuItemThetas::SetMenuItemThetas(UIInterface & myui)
    : SetMenuItemGroup(myui,uistr::userSetTheta) 
{
}

SetMenuItemThetas::~SetMenuItemThetas()
{
}

vector<UIId> SetMenuItemThetas::GetVisibleIds()
{
  return ui.doGetUIIdVec1d(uistr::validParamsForForce,UIId(force_COAL));
}


/////////
CoalescenceMenu::CoalescenceMenu (UIInterface & myui ) 
    : NewMenu (myui,lamarcmenu::coalTitle,lamarcmenu::coalInfo)
{
  UIId id(force_COAL);
  AddMenuItem(new SubMenuConstraintsForOneForce("C",ui,id));
  AddMenuItem(new SubMenuProfileForOneForce("P",ui,id));
  AddMenuItem(new SubMenuPriorForOneForce("B",ui,id));
  AddMenuItem(new SetAllThetasMenuItem("G",ui));
  AddMenuItem(new SetThetasFstMenuItem("F",ui));
  AddMenuItem(new ToggleMenuItemNoId("W",ui,uistr::wattersonSetTheta));
  AddMenuItem(new SetMenuItemThetas(ui));
}

CoalescenceMenu::~CoalescenceMenu ()
{
}
