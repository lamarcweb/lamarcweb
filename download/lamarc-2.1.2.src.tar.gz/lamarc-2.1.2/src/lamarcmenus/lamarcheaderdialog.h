//$Id: lamarcheaderdialog.h,v 1.5 2004/08/05 18:43:10 ewalkup Exp $
#ifndef LAMARCHEADERDIALOG_H
#define LAMARCHEADERDIALOG_H

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "dialognoinput.h"
#include <string>


class LamarcHeaderDialog : public DialogNoInput
{
    protected:
        virtual std::string outputString();
    public:
        LamarcHeaderDialog();
        virtual ~LamarcHeaderDialog();
};

#endif /* LAMARCHEADERDIALOG_H */
