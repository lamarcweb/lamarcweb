//$Id: priormenus.h,v 1.1 2005/01/07 21:33:08 lpsmith Exp $
#ifndef PRIORMENUS_H
#define PRIORMENUS_H

/* 
   Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "forcesmenus.h"
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"

class UIInterface;

class PriorMenu : public NewMenu
{
private:
  PriorMenu(); //undefined
public:
  PriorMenu(UIInterface& ui);
  virtual ~PriorMenu();
};

class PriorMenuCreator : public NewMenuCreator
{
protected:
  UIInterface & ui;
public:
  PriorMenuCreator(UIInterface & myui) : ui(myui) {};
  virtual ~PriorMenuCreator() {};
  virtual NewMenu_ptr Create() { return NewMenu_ptr(new PriorMenu(ui));};
};

class PriorByForceMenuItemGroup : public MenuDisplayGroupBaseImplementation
{
private:
  PriorByForceMenuItemGroup(); //undefined
public:
  PriorByForceMenuItemGroup(UIInterface& ui);
  virtual ~PriorByForceMenuItemGroup();
  virtual MenuInteraction_ptr MakeOneHandler(UIId id);
  virtual UIIdVec1d           GetVisibleIds();
  virtual string              GetKey(UIId id);
};

class PriorMenuForOneForce : public NewMenu
{
private:
  PriorMenuForOneForce(); //undefined
public:
  PriorMenuForOneForce(UIInterface& ui, UIId id);
  virtual ~PriorMenuForOneForce();
};

//These two classes are used for the individual forces' menus.
class SubMenuPriorForOneForce : public ForceSubMenuItem
{
private:
  SubMenuPriorForOneForce(); //undefined
  UIId id;
public:
  SubMenuPriorForOneForce(std::string key, UIInterface& ui, UIId id);
  virtual ~SubMenuPriorForOneForce();
  virtual bool IsVisible();
};

class PriorMenuForOneForceCreator : public NewMenuCreator
{
private:
  PriorMenuForOneForceCreator(); //undefined
  UIInterface& ui;
  UIId id;
public:
  PriorMenuForOneForceCreator(UIInterface& myui, UIId myid) :
    ui(myui), id(myid) {};
  virtual ~PriorMenuForOneForceCreator() {};
  virtual NewMenu_ptr Create() { return NewMenu_ptr(new PriorMenuForOneForce(ui, id));};
};

class PriorByParameterMenuItemGroup : public MenuDisplayGroupBaseImplementation
{
private:
  PriorByParameterMenuItemGroup(); //undefined
  UIId m_id;
public:
  PriorByParameterMenuItemGroup(UIInterface& ui, UIId id);
  virtual ~PriorByParameterMenuItemGroup();
  virtual UIIdVec1d  GetVisibleIds();
  virtual MenuInteraction_ptr MakeOneHandler(UIId id);
};

class DefaultPriorForForce: public SubMenuItem
{
private:
  DefaultPriorForForce();
  UIId m_id;
public:
  DefaultPriorForForce(string myKey, UIInterface& myUI, UIId myId);
  virtual ~DefaultPriorForForce();
  virtual string GetVariableText();
};

class PriorMenuForOneParameter : public NewMenu
{
private:
  PriorMenuForOneParameter();
  UIId m_id;
public:
  PriorMenuForOneParameter(UIInterface& ui, UIId id);
  virtual ~PriorMenuForOneParameter();
  virtual string Title();
};

class PriorMenuForOneParameterCreator : public NewMenuCreator
{
protected:
  UIInterface & ui;
  UIId id;
public:
  PriorMenuForOneParameterCreator(UIInterface & myui, UIId myid) :
    ui(myui), id(myid) {};
  virtual ~PriorMenuForOneParameterCreator() {};
  virtual NewMenu_ptr Create() { return NewMenu_ptr(new PriorMenuForOneParameter(ui, id));};
};

#endif  /* PRIORMENUS_H */
