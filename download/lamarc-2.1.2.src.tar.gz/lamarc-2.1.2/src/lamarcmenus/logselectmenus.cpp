/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "constraintmenus.h"
#include "lamarc_strings.h"
#include "newmenuitems.h"
#include "forcesmenus.h"
#include "logselectmenus.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "profilemenus.h"

LogisticSelectionCoefficientMenuItem::LogisticSelectionCoefficientMenuItem(string myKey, UIInterface & myui)
    : SetMenuItemId(myKey,myui,uistr::logisticSelectionCoefficient, UIId(force_LOGISTICSELECTION, uiconst::GLOBAL_ID))
{
}

LogisticSelectionCoefficientMenuItem::~LogisticSelectionCoefficientMenuItem()
{
}

bool LogisticSelectionCoefficientMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::logisticSelection);
}

LogisticSelectionMenu::LogisticSelectionMenu (UIInterface & myui ) 
    : NewMenu (myui,lamarcmenu::logisticSelectionTitle,lamarcmenu::logisticSelectionInfo)
{
  AddMenuItem(new ToggleMenuItemNoId("X",ui,uistr::logisticSelection));
  UIId id(force_LOGISTICSELECTION);
  AddMenuItem(new SubMenuConstraintsForOneForce("C",ui,id));
  AddMenuItem(new SubMenuProfileForOneForce("P",ui,id));
  AddMenuItem(new LogisticSelectionCoefficientMenuItem("S",ui));
}

LogisticSelectionMenu::~LogisticSelectionMenu ()
{

}
