//$Id: profilemenus.h,v 1.2 2005/01/07 21:32:03 lpsmith Exp $
#ifndef PROFILEMENUS_H
#define PROFILEMENUS_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "forcesmenus.h"
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"

class UIInterface;

// choices for profile type and on/off for individual quantities
class ProfileMenu : public NewMenu
{
    public:
        ProfileMenu(UIInterface & myui);
        ~ProfileMenu();
};

class ProfileMenuCreator : public NewMenuCreator
{
protected:
  UIInterface & ui;
public:
  ProfileMenuCreator(UIInterface & myui) : ui(myui) {};
  virtual ~ProfileMenuCreator() {};
  NewMenu_ptr Create() { return NewMenu_ptr(new ProfileMenu(ui));};
};

class ProfileByForceMenuItemGroup : public MenuDisplayGroupBaseImplementation
{
    protected:
        virtual MenuInteraction_ptr MakeOneHandler(UIId id);
    public:
        ProfileByForceMenuItemGroup(UIInterface& ui);
        virtual ~ProfileByForceMenuItemGroup();
        virtual UIIdVec1d GetVisibleIds();
        virtual std::string GetKey(UIId id);
};

class ProfileMenuForOneForce : public NewMenu
{
    public:
        ProfileMenuForOneForce(UIInterface &ui,UIId id);
        virtual ~ProfileMenuForOneForce();
};

//These two classes are used for the individual forces' menus.
class SubMenuProfileForOneForce : public ForceSubMenuItem
{
private:
  SubMenuProfileForOneForce(); //undefined
  UIId id;
public:
  SubMenuProfileForOneForce(std::string key, UIInterface& ui, UIId id);
  virtual ~SubMenuProfileForOneForce();
};

class ProfileMenuForOneForceCreator : public NewMenuCreator
{
private:
  ProfileMenuForOneForceCreator(); //undefined
  UIInterface& ui;
  UIId id;
public:
  ProfileMenuForOneForceCreator(UIInterface& myui, UIId myid) :
    ui(myui), id(myid) {};
  virtual ~ProfileMenuForOneForceCreator() {};
  virtual NewMenu_ptr Create() { return NewMenu_ptr(new ProfileMenuForOneForce(ui, id));};
};

class ToggleMenuItemGroupProfiles : public ToggleMenuItemGroup
{
    private:
        UIId    m_id;
    public:
        ToggleMenuItemGroupProfiles(UIInterface & ui,UIId id);
        virtual ~ToggleMenuItemGroupProfiles();
        virtual UIIdVec1d GetVisibleIds();
};

#endif  /* PROFILEMENUS_H */
