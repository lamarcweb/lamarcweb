// $Id: lamarcmenu.h,v 1.5 2004/08/26 23:13:45 ewalkup Exp $
#ifndef LAMARCMENU_H_
#define LAMARCMENU_H_

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "newmenu.h"

class UIInterface;

class LamarcMainMenu : public NewMenu
{
 public:
  LamarcMainMenu(UIInterface & myui);
  ~LamarcMainMenu();
};

#endif /* LAMARCMENU_H_ */
