//$Id: migmenus.h,v 1.11 2005/01/07 21:32:03 lpsmith Exp $
#ifndef MIGMENUS_H
#define MIGMENUS_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"

class UIInterface;

class SetAllMigrationsMenuItem : public SetMenuItemId
{
    public:
        SetAllMigrationsMenuItem(std::string myKey, UIInterface & myui);
        virtual ~SetAllMigrationsMenuItem();
        virtual bool IsVisible();
        virtual std::string GetVariableText();
};

class SetMigrationsFstMenuItem : public ToggleMenuItemNoId
{
    public:
        SetMigrationsFstMenuItem(std::string myKey, UIInterface & myui);
        virtual ~SetMigrationsFstMenuItem();
        virtual bool IsVisible();
};

class MigrationMaxEventsMenuItem : public SetMenuItemNoId
{
    public:
        MigrationMaxEventsMenuItem(std::string myKey, UIInterface & myui);
        virtual ~MigrationMaxEventsMenuItem();
        virtual bool IsVisible();
};

class MigrationMenu : public NewMenu
{
 public:
  MigrationMenu(UIInterface & myui);
  virtual ~MigrationMenu();
};

class MigrationMenuCreator : public NewMenuCreator
{
    protected:
        UIInterface & ui;
    public:
        MigrationMenuCreator(UIInterface & myui) : ui(myui) {};
        virtual ~MigrationMenuCreator() {};
        NewMenu_ptr Create() { return NewMenu_ptr(new MigrationMenu(ui));};
};

#endif  /* MIGMENUS_H */
