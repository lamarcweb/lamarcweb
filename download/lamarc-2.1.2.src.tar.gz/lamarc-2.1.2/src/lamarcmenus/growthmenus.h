//$Id: growthmenus.h,v 1.14 2006/09/15 23:43:11 jay Exp $
#ifndef GROWTHMENUS_H
#define GROWTHMENUS_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include <vector>
#include "newmenu.h"
#include "setmenuitem.h"
#include "newmenuitems.h"

class UIInterface;

class SetAllGrowthMenuItem : public SetMenuItemId
{
    public:
        SetAllGrowthMenuItem(std::string myKey, UIInterface & myui);
        virtual ~SetAllGrowthMenuItem();
        virtual bool IsVisible();
        virtual std::string GetVariableText();
};

class SetMenuItemGrowths : public SetMenuItemGroup
{
    public:
        SetMenuItemGrowths(UIInterface & ui);
        virtual ~SetMenuItemGrowths();
        virtual std::vector<UIId> GetVisibleIds();
};

class ToggleMenuItemGrowthScheme : public ToggleMenuItemNoId
{
    public:
       ToggleMenuItemGrowthScheme(std::string myKey, UIInterface& myui);
       virtual ~ToggleMenuItemGrowthScheme();
       virtual bool IsVisible();
};

class ToggleMenuItemGrowthType : public ToggleMenuItemNoId
{
    public:
       ToggleMenuItemGrowthType(std::string myKey, UIInterface& myui);
       virtual ~ToggleMenuItemGrowthType();
       virtual bool IsVisible();
};

class GrowthMenu : public NewMenu
{
 public:
  GrowthMenu(UIInterface & myui);
  virtual ~GrowthMenu();
};

class GrowthMenuCreator : public NewMenuCreator
{
    protected:
        UIInterface & ui;
    public:
        GrowthMenuCreator(UIInterface & myui) : ui(myui) {};
        virtual ~GrowthMenuCreator() {};
        NewMenu_ptr Create() { return NewMenu_ptr(new GrowthMenu(ui));};
};


#endif  /* GROWTHMENUS_H */
