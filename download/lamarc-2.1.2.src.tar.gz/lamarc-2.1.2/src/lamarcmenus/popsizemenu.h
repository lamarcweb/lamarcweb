//$Id: popsizemenu.h,v 1.2 2005/02/22 18:50:01 lpsmith Exp $
#ifndef POPSIZEMENU_H
#define POPSIZEMENU_H

/* 
   Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "newmenuitems.h"
#include "setmenuitem.h"

class UIInterface;

class EffectivePopSizeMenu : public NewMenu
{
private:
  EffectivePopSizeMenu(); //undefined
public:
  EffectivePopSizeMenu(UIInterface& ui);
  virtual ~EffectivePopSizeMenu();
};

class EffectivePopSizeMenuCreator : public NewMenuCreator
{
protected:
  UIInterface & ui;
public:
  EffectivePopSizeMenuCreator(UIInterface & myui) : ui(myui) {};
  virtual ~EffectivePopSizeMenuCreator() {};
  virtual NewMenu_ptr Create() { return NewMenu_ptr(new EffectivePopSizeMenu(ui));};
};

class EffectivePopSizeGroup : public SetMenuItemGroup
{
public:
  EffectivePopSizeGroup(UIInterface& myui);
  virtual ~EffectivePopSizeGroup();
  virtual UIIdVec1d GetVisibleIds();
  virtual string GetText(UIId id);
};
  
#endif  /* POPSIZEMENU_H */
