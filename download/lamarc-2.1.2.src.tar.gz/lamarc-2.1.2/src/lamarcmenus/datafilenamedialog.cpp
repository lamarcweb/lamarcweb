//$Id: datafilenamedialog.cpp,v 1.11 2007/04/30 20:14:49 lpsmith Exp $

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "dialogrepeat.h"
#include "datafilenamedialog.h"
#include "errhandling.h"
#include "menudefs.h"
#include "stringx.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "xml.h"
#include <string>
#include <iostream>

DataFileNameDialog::DataFileNameDialog(XmlParser & parser) 
    : DialogRepeat() , m_dataFileName(parser.GetFileName()), m_parser(parser)
{
}

DataFileNameDialog::~DataFileNameDialog()
{
}

long DataFileNameDialog::maxTries()
{
    return 3;
}

std::string DataFileNameDialog::displayFileName()
{
    std::string displayFileName;
    if(m_dataFileName == "") 
    {
        displayFileName = "[No default set]\n";
    }
    else
    {
        displayFileName = "[Default: "+ m_dataFileName + "]\n";
    }
    return displayFileName;
}

std::string DataFileNameDialog::beforeLoopOutputString()
{
    return "";
}

std::string DataFileNameDialog::inLoopOutputString()
{
    return "Enter the location of the data file\n"+displayFileName()+"\n";
}

std::string DataFileNameDialog::inLoopFailureOutputString()
{
    return " \n \n" + m_errmsg + "\n";
}

std::string DataFileNameDialog::afterLoopSuccessOutputString()
{
    std::string message = "Data file was read successfully\n\n"; 
    message += "Calculating starting values; please be patient";
    return message;
}

std::string DataFileNameDialog::afterLoopFailureOutputString()
{
    return "Unable to read or find your file in "+ToString(maxTries())
        + " attempts.\n";
}


bool DataFileNameDialog::handleInput(std::string input)
{
    if (input.size () != 0) 
    { 
        m_dataFileName = input;
    } 
    try 
    { 
        m_parser.ParseFileData(m_dataFileName);
    } 
    catch (const data_error& e) 
    {
        m_errmsg = e.whatString();
        return false;
    } 
    return true;
}

void DataFileNameDialog::doFailure()
{
    throw data_error("To create a LAMARC input file, please run the converter (lam_conv).");
}
