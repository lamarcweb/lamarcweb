//$Id: recmenus.h,v 1.10 2005/01/07 21:32:03 lpsmith Exp $
#ifndef RECMENUS_H
#define RECMENUS_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "newmenuitems.h"
#include "setmenuitem.h"

class UIInterface;

class RecombineMaxEventsMenuItem : public SetMenuItemNoId
{
    public:
        RecombineMaxEventsMenuItem(std::string myKey, UIInterface & myui);
        ~RecombineMaxEventsMenuItem();
        bool IsVisible();
};

class RecombineRateMenuItem : public SetMenuItemId
{
    public:
        RecombineRateMenuItem(std::string myKey, UIInterface & myui);
        ~RecombineRateMenuItem();
        bool IsVisible();
};

class RecombinationMenu : public NewMenu
{
    public:
        RecombinationMenu(UIInterface & myui);
        virtual ~RecombinationMenu();
};

class RecombinationMenuCreator : public NewMenuCreator
{
    protected:
        UIInterface & ui;
    public:
        RecombinationMenuCreator(UIInterface & myui) : ui(myui) {};
        virtual ~RecombinationMenuCreator() {};
        NewMenu_ptr Create() { return NewMenu_ptr(new RecombinationMenu(ui));};
};

#endif  /* RECMENUS_H */
