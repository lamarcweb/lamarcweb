//$Id: lamarcheaderdialog.cpp,v 1.7 2007/09/11 17:48:54 lpsmith Exp $

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "lamarcheaderdialog.h"
#include <string>

using std::string;

LamarcHeaderDialog::LamarcHeaderDialog() 
    : DialogNoInput()
{
}

LamarcHeaderDialog::~LamarcHeaderDialog()
{
}

string LamarcHeaderDialog::outputString()
{
  return
     string("       L A M A R C      Likelihood Analysis with               \n")
    +string("                        Metropolis-Hastings Algorithms         \n")
    +string("                        using Random Coalescences              \n")
    +string("                        Version  ") + VERSION
#ifndef NDEBUG
    +string(" (Debug)")
#endif
    +string("\n")
    +string("                        Release Date: ") + RELEASE_DATE + string("\n")
    +string("---------------------------------------------------------------------------\n");

}

