//$Id: growthmenus.cpp,v 1.14 2006/11/30 00:07:47 lpsmith Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "constraintmenus.h"
#include "forcesummary.h"
#include "growthmenus.h"
#include "lamarc_strings.h"
#include "menu_strings.h"
#include "newmenuitems.h"
#include "priormenus.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "profilemenus.h"

using std::string;

SetAllGrowthMenuItem::SetAllGrowthMenuItem(string myKey, UIInterface & ui)
    : SetMenuItemId(myKey,ui,uistr::globalGrowth, UIId(force_GROW, uiconst::GLOBAL_ID))
{
}

SetAllGrowthMenuItem::~SetAllGrowthMenuItem()
{
}

bool SetAllGrowthMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::growth);
}

std::string SetAllGrowthMenuItem::GetVariableText()
{
    return "";
}

/////////

ToggleMenuItemGrowthScheme::ToggleMenuItemGrowthScheme(string k, UIInterface & myui)
    : ToggleMenuItemNoId(k,myui,uistr::growthScheme)
{
}

ToggleMenuItemGrowthScheme::~ToggleMenuItemGrowthScheme()
{
}

bool ToggleMenuItemGrowthScheme::IsVisible()
{
#ifdef NDEBUG
  return false;
#else
  return ui.doGetBool(uistr::growth);
#endif
}

/////////

ToggleMenuItemGrowthType::ToggleMenuItemGrowthType(string k, UIInterface & myui)
    : ToggleMenuItemNoId(k,myui,uistr::growthType)
{
}

ToggleMenuItemGrowthType::~ToggleMenuItemGrowthType()
{
}

bool ToggleMenuItemGrowthType::IsVisible()
{
#ifdef NDEBUG
  return false;
#else
    return ui.doGetBool(uistr::growth);
#endif
}

/////////

SetMenuItemGrowths::SetMenuItemGrowths(UIInterface & myui)
    : SetMenuItemGroup(myui,uistr::growthByID) 
{
}

SetMenuItemGrowths::~SetMenuItemGrowths()
{
}

vector<UIId> SetMenuItemGrowths::GetVisibleIds()
{
  return ui.doGetUIIdVec1d(uistr::validParamsForForce,UIId(force_GROW));
}
 
///////////////

GrowthMenu::GrowthMenu (UIInterface & myui ) 
    : NewMenu (myui,lamarcmenu::growTitle,lamarcmenu::growInfo)
{
  AddMenuItem(new ToggleMenuItemNoId("X",ui,uistr::growth));
  UIId id(force_GROW);
  AddMenuItem(new ToggleMenuItemGrowthScheme("S",ui));
  AddMenuItem(new ToggleMenuItemGrowthType("I",ui));
  AddMenuItem(new SubMenuConstraintsForOneForce("C",ui,id));
  AddMenuItem(new SubMenuProfileForOneForce("P",ui,id));
  AddMenuItem(new SubMenuPriorForOneForce("B",ui,id));
  AddMenuItem(new SetAllGrowthMenuItem("G",ui));
  AddMenuItem(new SetMenuItemGrowths(ui));
}

GrowthMenu::~GrowthMenu ()
{
}
