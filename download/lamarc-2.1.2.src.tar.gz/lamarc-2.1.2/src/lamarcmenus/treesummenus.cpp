//$Id: treesummenus.cpp,v 1.11 2005/10/13 19:24:24 lpsmith Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <fstream>
#include <string>
#include "menu_strings.h"
#include "newmenuitems.h"
#include "togglemenuitem.h"
#include "treesummenus.h"
#include "ui_interface.h"
#include "ui_strings.h"

using std::string;

SetMenuItemTreeSumInFileName::SetMenuItemTreeSumInFileName(string myKey, UIInterface & myui)
    : SetMenuItemNoId(myKey,myui,uistr::treeSumInFileName)
{
}

SetMenuItemTreeSumInFileName::~SetMenuItemTreeSumInFileName()
{
}

SetMenuItemTreeSumOutFileName::SetMenuItemTreeSumOutFileName(string myKey, UIInterface & myui)
    : SetMenuItemNoId(myKey,myui,uistr::treeSumOutFileName)
{
}

SetMenuItemTreeSumOutFileName::~SetMenuItemTreeSumOutFileName()
{
}

bool SetMenuItemTreeSumInFileName::IsVisible()
{
    return ui.doGetBool(uistr::treeSumInFileEnabled);
}

bool SetMenuItemTreeSumOutFileName::IsVisible()
{
    return ui.doGetBool(uistr::treeSumOutFileEnabled);
}

TreeSumInMenu::TreeSumInMenu(UIInterface & myui)
    : NewMenu(myui,uistr::treeSumInFileEnabled,menustr::emptyString)
{
    AddMenuItem(new ToggleMenuItemNoId("X",ui,uistr::treeSumInFileEnabled));
    AddMenuItem(new SetMenuItemTreeSumInFileName("N",ui));
}

TreeSumInMenu::~TreeSumInMenu()
{
}

TreeSumOutMenu::TreeSumOutMenu(UIInterface & myui)
    : NewMenu(myui,uistr::treeSumOutFileEnabled,menustr::emptyString)
{
    AddMenuItem(new ToggleMenuItemNoId("X",ui,uistr::treeSumOutFileEnabled));
    AddMenuItem(new SetMenuItemTreeSumOutFileName("N",ui));
}

TreeSumOutMenu::~TreeSumOutMenu()
{
}

TreeSumInSubMenuItem::TreeSumInSubMenuItem(string myKey, UIInterface & myui)
    : SubMenuItem(myKey, myui, new TreeSumInMenuCreator(myui))
{
}

TreeSumOutSubMenuItem::TreeSumOutSubMenuItem(string myKey, UIInterface & myui)
    : SubMenuItem(myKey, myui, new TreeSumOutMenuCreator(myui))
{
}

string TreeSumInSubMenuItem::GetVariableText()
{
    return ui.doGetPrintString(uistr::treeSumInFileEnabled,GetId());
}
string TreeSumOutSubMenuItem::GetVariableText()
{
    return ui.doGetPrintString(uistr::treeSumOutFileEnabled,GetId());
}
