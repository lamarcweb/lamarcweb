//$Id: outfilemenus.cpp,v 1.19 2005/07/13 18:07:33 jay Exp $
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "lamarc_strings.h"
#include "newmenuitems.h"
#include "outfilemenus.h"
#include "profilemenus.h"
#include "ui_interface.h"
#include "ui_strings.h"

using std::string;

OutfileMenu::OutfileMenu(UIInterface & myui)
    : NewMenu(myui,lamarcmenu::outfileTitle)
{
    AddMenuItem(new SetMenuItemNoId("N",ui,uistr::resultsFileName));
    AddMenuItem(new ToggleMenuItemNoId("V",ui,uistr::verbosity));
    AddMenuItem(new SubMenuItem("P", ui,new ProfileMenuCreator(ui)));
}

OutfileMenu::~OutfileMenu()
{
}

OutfileSubMenuItem::OutfileSubMenuItem(std::string myKey, UIInterface & myui) 
    : SubMenuItem(myKey, myui,new OutfileMenuCreator(myui))
{
}

std::string OutfileSubMenuItem::GetVariableText()
{
    return ui.doGetPrintString(uistr::resultsFileName,GetId());
}
