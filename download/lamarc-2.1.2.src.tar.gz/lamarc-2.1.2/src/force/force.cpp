// $Id: force.cpp,v 1.50 2007/10/03 18:06:34 erynes Exp $

/* 
   Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include "chainpack.h"
#include "constants.h"
#include "datapack.h"
#include "datatype.h"
#include "defaults.h"
#include "event.h"
#include "force.h"
#include "forcesummary.h"
#include "mathx.h"
#include "plforces.h"
#include "region.h"
#include "registry.h"
#include "runreport.h"
#include "stringx.h"
#include "summary.h"
#include "ui_vars.h"
#include "ui_strings.h"
#include "userparam.h"
#include "xml_strings.h" // for Force::ToXML() and PartitionForce::GetXMLStatusTag()
#include <math.h>
#include <numeric> // for stl::accumulate


#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;


//___________________________________________________________

Force::Force(       force_type          tag,
                    string              name,
                    string              fullname,
                    string              paramname,
                    string              fullparamname,
                    vector<Parameter>   parameters,
                    long                maxevents,
                    double              defvalue,
                    double              maxvalue,
                    double              minvalue,
		    double              maximizer_maxvalue,
		    double              maximizer_minvalue,
                    double              highval,
                    double              lowval,
                    double              highmult,
                    double              lowmult,
                    std::vector<ParamGroup> groups,
                    const UIVarsPrior &       prior)
    :   m_tag(tag),
        m_name(name),
        m_fullname(fullname),
        m_paramname(paramname),
        m_fullparamname(fullparamname),
        m_parameters(parameters),
        m_maxevents(maxevents),
        m_defvalue(defvalue),
        m_maxvalue(maxvalue),
        m_minvalue(minvalue),
	m_maximizer_maxvalue(maximizer_maxvalue),
	m_maximizer_minvalue(maximizer_minvalue),
        m_highval(highval),
        m_lowval(lowval),
        m_highmult(highmult),
        m_lowmult(lowmult),
        m_plforceptr(NULL),
        m_groups(groups),
        m_defaultPrior(prior)
{
}

//___________________________________________________________

DoubleVec1d Force::PopParameters(DoubleVec1d& valuelist)
{
  // chew off as many values from the front of "valuelist"
  // as this force has parameters, and return them.
  // The passed vector is reduced in size.
  DoubleVec1d tempvec;
  DoubleVec1d::iterator start = valuelist.begin();
  DoubleVec1d::iterator end = start + m_parameters.size();

  tempvec.insert(tempvec.end(), start, end);
  valuelist.erase(start, end);
  return tempvec;

} // PopParameters

//___________________________________________________________

vector<proftype> Force::GetProfileTypes() const
{
  vector<proftype> profiles;

  vector<Parameter>::const_iterator param = m_parameters.begin();
  for ( ; param != m_parameters.end(); ++param)
    profiles.push_back(param->GetProfileType());

  return profiles;

} // GetProfileTypes

vector<paramstatus> Force::GetParamstatuses() const
{
  vector<paramstatus> pstats;

  vector<Parameter>::const_iterator param = m_parameters.begin();
  for ( ; param != m_parameters.end(); ++param)
    pstats.push_back(param->GetStatus());

  return pstats;

} /* GetProfileTypes */

//___________________________________________________________

StringVec1d Force::MakeStartParamReport() const
{
  StringVec1d rpt;
  verbosity_type verbose = registry.GetUserParameters().GetVerbosity(); 

  if (verbose == VERBOSE) {
    string line = m_fullparamname;
    MethodTypeVec1d meth = registry.GetForceSummary().GetMethods(GetTag());
    DoubleVec1d start = registry.GetForceSummary().GetStartParameters().
      GetGlobalParametersByTag(GetTag());
    if (m_parameters.size() > 1UL) {                               
      line += " (USR = user, WAT = watterson, FST = FST)";
      rpt.push_back(line);
      line = "Population";
      unsigned long param;
      for(param = 0; param < m_parameters.size(); ++param) {
	line += " "+indexToKey(param)+" "+ToString(meth[param],false); // false => short version of name
	line += " "+Pretty(start[param],12);
	rpt.push_back(line);
	line.assign(10,' ');
      }
    } else {
      line += " (" + ToString(meth[0],false) + ")"; // ToString(method_type,false) gives short version of name
      line = MakeJustified(line,-25);
      line += MakeJustified(Pretty(start[0]),25);
      rpt.push_back(line);
    }
  }

  return(rpt);
} // Force::MakeStartParamReport

//___________________________________________________________

StringVec1d Force::MakeChainParamReport(const ChainOut& chout) const
{
  ForceParameters fparam = chout.GetEstimates();
  return(Tabulate(fparam.GetGlobalParametersByTag(GetTag()), 8));
} // Force::MakeChainParamReport

//__________________________________________________________________


DoubleVec2d Force::GetMles() const
{
  assert(m_parameters.size() != 0);  // if there are no Parameters 
                                   // yet it's too early to call this!

  vector<Parameter>::const_iterator it;
  DoubleVec2d result;
  DoubleVec1d empty;

  for (it = m_parameters.begin(); it != m_parameters.end(); ++it) {
    if (it->IsValid()) result.push_back((*it).GetRegionMLEs());
    else result.push_back(empty);
  }
  return result;

} // GetMles

//___________________________________________________________

DoubleVec1d Force::GetPopmles() const
{
  assert(m_parameters.size() != 0);  // if there are no Parameters 
                                   // yet it's too early to call this!

  vector<Parameter>::const_iterator it;
  DoubleVec1d result;

  for (it = m_parameters.begin(); it != m_parameters.end(); ++it) {
    if (it->IsValid()) result.push_back((*it).GetOverallMLE());
    else result.push_back(0.0);
  }
  return result;

} // GetPopmles

//___________________________________________________________

MethodTypeVec1d Force::GetMethods() const
{
  assert(m_parameters.size() != 0);  // if there are no Parameters 
                                   // yet it's too early to call this!

  vector<Parameter>::const_iterator it;
  MethodTypeVec1d result;

  for (it = m_parameters.begin(); it != m_parameters.end(); ++it) {
    result.push_back((*it).GetMethod());
  }
  return result;

} // GetMethods

//___________________________________________________________

StringVec1d Force::GetAllParamNames() const
{
  StringVec1d names;
  vector<Parameter>::const_iterator param;
  for(param = m_parameters.begin(); param != m_parameters.end(); ++param)
    if (param->IsValid()) 
      names.push_back(param->GetName());
    else {
      string emptystring("");
      names.push_back(emptystring);
    }

  return names;

} // GetAllParamNames

//___________________________________________________________

DoubleVec1d Force::CreateVectorOfParametersWithValue(double val) const
{
DoubleVec1d pvec(m_parameters.size(),val);

return pvec;
} // CreateVectorOfParametersWithValue

//___________________________________________________________

proftype Force::SummarizeProfTypes() const
{
  vector<Parameter>::const_iterator param;
  for(param = m_parameters.begin(); param != m_parameters.end(); ++param)
    if (param->GetProfileType() != profile_NONE)
      return param->GetProfileType();

  return profile_NONE;

} // SummarizeProfTypes

//___________________________________________________________

// GetIdenticalGroupedParams is used in the Forcesummary constructor.
ULongVec2d Force::GetIdenticalGroupedParams() const
{
  ULongVec2d groups;
  for (unsigned long gnum=0; gnum<m_groups.size(); gnum++) {
    if (m_groups[gnum].first == pstat_identical) {
      ULongVec1d onegroup;
      for (unsigned long pnum=0; pnum<m_groups[gnum].second.size(); pnum++) {
        onegroup.push_back(m_parameters[m_groups[gnum].second[pnum]].GetParamVecIndex());
      }
      groups.push_back(onegroup);
    }
  }
  return groups;
}

//___________________________________________________________

std::string Force::MakeOpeningTag(unsigned long nspaces) const
{
    return MakeIndent(MakeTag(GetXMLName()),nspaces);
}

StringVec1d Force::ToXML(unsigned long nspaces) const
{
  StringVec1d xmllines;
  string line = MakeOpeningTag(nspaces);
  xmllines.push_back(line);

  nspaces += INDENT_DEPTH;
  string mytag(MakeTag(xmlstr::XML_TAG_START_VALUES));
  const ForceParameters& fp = registry.GetForceSummary().GetStartParameters();
  DoubleVec1d params = fp.GetGlobalParametersByTag(GetTag());
  // DEBUG WARNING Problem here if starting parameter > 5 digits!
  line = MakeIndent(mytag,nspaces) + ToString(params,5) + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_METHOD);
  line = MakeIndent(mytag,nspaces) + ToString(GetMethods()) + MakeCloseTag(mytag);
  xmllines.push_back(line);
  if (m_tag != force_GROW && m_tag != force_COAL) {
    mytag = MakeTag(xmlstr::XML_TAG_MAX_EVENTS);
    line = MakeIndent(mytag,nspaces) + ToString(GetMaxEvents()) + MakeCloseTag(mytag);
    xmllines.push_back(line);
  }
  mytag = MakeTag(xmlstr::XML_TAG_PROFILES);
  line = MakeIndent(mytag,nspaces) + " " + ToString(GetProfileTypes()) + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_CONSTRAINTS);
  line = MakeIndent(mytag,nspaces) + " " + ToString(GetParamstatuses()) + MakeCloseTag(mytag);
  xmllines.push_back(line);

  for (unsigned long gnum = 0; gnum<m_groups.size(); gnum++) {
    mytag = MakeTagWithConstraint(xmlstr::XML_TAG_GROUP, ToString(m_groups[gnum].first));
    LongVec1d indexes = m_groups[gnum].second;
    for (unsigned long i=0; i<indexes.size(); i++)
      indexes[i]++;
    line = MakeIndent(mytag, nspaces) + ToString(indexes) + " " + MakeCloseTag(xmlstr::XML_TAG_GROUP);
    xmllines.push_back(line);
  }

  //Write out the default prior
  mytag = MakeTagWithType(xmlstr::XML_TAG_PRIOR, ToString(m_defaultPrior.GetPriorType()));
  line = MakeIndent(mytag, nspaces);
  xmllines.push_back(line);
  nspaces += INDENT_DEPTH;

  mytag = MakeTag(xmlstr::XML_TAG_PARAMINDEX);
  line = MakeIndent(mytag, nspaces) + " " + ToString(uistr::allStr) + " " + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_PRIORLOWERBOUND);
  line = MakeIndent(mytag, nspaces) + " " + ToString(m_defaultPrior.GetLowerBound()) + " " + MakeCloseTag(mytag);
  xmllines.push_back(line);
  mytag = MakeTag(xmlstr::XML_TAG_PRIORUPPERBOUND);
  line = MakeIndent(mytag, nspaces) + " " + ToString(m_defaultPrior.GetUpperBound()) + " " + MakeCloseTag(mytag);
  xmllines.push_back(line);

  nspaces -= INDENT_DEPTH;
  line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_PRIOR), nspaces);
  xmllines.push_back(line);
  
  //Write out any overridden priors
  for (unsigned long pnum = 0; pnum < m_parameters.size(); pnum++) {
    if (m_parameters[pnum].IsValid()) {
      Prior thisPrior = m_parameters[pnum].GetPrior();
      if (!(thisPrior == m_defaultPrior)) {
        mytag = MakeTagWithType(xmlstr::XML_TAG_PRIOR, ToString(thisPrior.GetPriorType()));
        line = MakeIndent(mytag, nspaces);
        xmllines.push_back(line);
        nspaces += INDENT_DEPTH;

        mytag = MakeTag(xmlstr::XML_TAG_PARAMINDEX);
        line = MakeIndent(mytag, nspaces) + " " + ToString(pnum+1) + " " + MakeCloseTag(mytag);
        xmllines.push_back(line);
        mytag = MakeTag(xmlstr::XML_TAG_PRIORLOWERBOUND);
        line = MakeIndent(mytag, nspaces) + " " + ToString(thisPrior.GetLowerBound()) + " " + MakeCloseTag(mytag);
        xmllines.push_back(line);
        mytag = MakeTag(xmlstr::XML_TAG_PRIORUPPERBOUND);
        line = MakeIndent(mytag, nspaces) + " " + ToString(thisPrior.GetUpperBound()) + " " + MakeCloseTag(mytag);
        xmllines.push_back(line);

        nspaces -= INDENT_DEPTH;
        line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_PRIOR), nspaces);
        xmllines.push_back(line);

      }
    }
  }
  
  nspaces -= INDENT_DEPTH;
  line = MakeIndent(MakeCloseTag(GetXMLName()),nspaces);
  xmllines.push_back(line);
  return xmllines;
} // ToXML

//___________________________________________________________

bool Force::IsAMember(const LongVec1d& m1, const LongVec1d& m2) const
{
  return m1 == m2; 
} // IsAMember

//___________________________________________________________

deque<bool> Force::UseCalculatedValues() const
{
  deque<bool> howtouse;

  vector<Parameter>::const_iterator it;
  for (it = m_parameters.begin(); it != m_parameters.end(); ++it) {
    howtouse.push_back( (*it).GetMethod() != method_USER &&
                        (*it).GetMethod() != method_PROGRAMDEFAULT);
  }
  
  return howtouse;

} /* Force::UseCalculatedValues */

//__________________________________________________________________

double Force::Truncate(double target) const
{
  if (target > m_maxvalue)
    return m_maxvalue;
  if (target < m_minvalue)
    return m_minvalue;
  return target;

} /* Force::Truncate */

//__________________________________________________________________

DoubleVec1d Force::RetrieveGlobalParameters(const ForceParameters& fp) const
{
  return fp.GetGlobalParametersByTag(GetTag());

} // Force::RetrieveParameters

DoubleVec1d Force::RetrieveRegionalParameters(const ForceParameters& fp) const
{
  return fp.GetRegionalParametersByTag(GetTag());

} // Force::RetrieveParameters

//__________________________________________________________________

DoubleVec1d Force::RetrieveGlobalLogParameters(const ForceParameters& fp) const
{
  DoubleVec1d params(fp.GetGlobalParametersByTag(GetTag()));
  DoubleVec1d result(params.size(), 0.0);
  LogVec0(params, result);
  return result;
} // Force::RetrieveLogParameters

DoubleVec1d Force::RetrieveRegionalLogParameters(const ForceParameters& fp) const
{
  DoubleVec1d params(fp.GetRegionalParametersByTag(GetTag()));
  DoubleVec1d result(params.size(), 0.0);
  LogVec0(params, result);
  return result;
} // Force::RetrieveLogParameters

//__________________________________________________________________

unsigned long Force::FindOrdinalPosition(long cannonicalpos) const
{
assert(cannonicalpos >= m_plforceptr->GetStart());
return cannonicalpos - m_plforceptr->GetStart();
} /* Force::FindOrdinalPosition */

//__________________________________________________________________
//___________________________________________________________

CoalForce::CoalForce(vector<Parameter> parameters,
                     long maxevents,
                     bool withGrowth,
		     bool withLogisticSelection,
                     std::vector<ParamGroup> groups,
                     const UIVarsPrior & prior)
    : Force(    force_COAL,
                "Coal",
                "Coalescence",
                "Theta",
                "Theta",
                parameters,
                maxevents,
                defaults::theta,
                defaults::maxTheta,
                defaults::minTheta,
		defaults::maximization_maxTheta,
		defaults::maximization_minTheta,
                defaults::highvalTheta,
                defaults::lowvalTheta,
                defaults::highmultTheta,
                defaults::lowmultTheta,
                groups,
                prior)
{
  m_axisname.push_back(string("Population"));
  m_axisname.push_back(string("Region"));
  m_sectitle = registry.GetDataPack().GetAllCrossPartitionNames();

  // setting up the coalescePL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  if(withGrowth)
  {
      m_plforceptr = new CoalesceGrowPL(parameters.size());
  }
  else if (withLogisticSelection)
    {
      m_plforceptr = new CoalesceLogisticSelectionPL(parameters.size());
    }
  else
  {
      m_plforceptr = new CoalescePL (parameters.size());
  }
} // CoalForce constructor

//___________________________________________________________


vector<Event*> CoalForce::MakeEvents(const ForceSummary& fs) const
{
  vector<Event*> tempvec;
  tempvec.push_back(new ActiveCoal(fs));
  tempvec.push_back(new InactiveCoal(fs));
  return tempvec;
} // MakeEvents

//__________________________________________________________________

Summary* CoalForce::CreateSummary(IntervalData& interval, bool
				  shortness) const
{
  return new CoalSummary(interval, shortness);
} /* CreateSummary */

//___________________________________________________________

long
CoalForce::ReportDimensionality() const
{
    if(m_parameters.size() == 1)
    {
        return 1L;
    }
    return 2L;
}

//___________________________________________________________
//___________________________________________________________

RegionGammaForce::RegionGammaForce(vector<Parameter> parameters,
				   std::vector<ParamGroup> groups,
				   const UIVarsPrior & prior)
    : Force(    force_REGION_GAMMA,
                "RegionGamma",
                "Background mutation rate gamma-distributed over regions",
                "Alpha",
                "Scaled shape parameter (\"alpha\")",
                parameters,
                0,
                defaults::gammaOverRegions,
                defaults::maxGammaOverRegions,
                defaults::minGammaOverRegions,
		defaults::maximization_maxGammaOverRegions,
		defaults::maximization_minGammaOverRegions,
                defaults::highvalGammaOverRegions,
                defaults::lowvalGammaOverRegions,
                defaults::highmultGammaOverRegions,
                defaults::lowmultGammaOverRegions,
                groups,
                prior)  // ignored
{
}

//___________________________________________________________


vector<Event*> RegionGammaForce::MakeEvents(const ForceSummary& fs) const
{
  vector<Event*> tempvec;  // yes this returns an empty vector
  return tempvec;

} // RegionGammaForce::MakeEvents()

//__________________________________________________________________

long RegionGammaForce::ReportDimensionality() const
{
  return 1L;
}

//__________________________________________________________________

Summary* RegionGammaForce::CreateSummary(IntervalData& interval,
					 bool shortness) const
{
  return NULL;  // yes, we have no summary of our own

} // RegionGammaForce::CreateSummary

//___________________________________________________________
//___________________________________________________________

MigForce::MigForce(vector<Parameter> parameters,
                   long maxevents,
                   long npop,
                   std::vector<ParamGroup> groups,
                   const UIVarsPrior & prior)
    : PartitionForce(
                force_MIG,
                "Mig",
                "Migration",
                "Mig",
                "Migration Rate",
                parameters,
                maxevents,
                defaults::migration,
                defaults::maxMigRate,
                defaults::minMigRate,
		defaults::maximization_maxMigRate,
		defaults::maximization_minMigRate,
                defaults::highvalMig,
                defaults::lowvalMig,
                defaults::highmultMig,
                defaults::lowmultMig,
                npop,
                groups,
                prior)
{
  m_axisname.push_back(string("Population"));
  m_axisname.push_back(string("Region"));

    long pop1, pop2, pindex;
    string sname, lname;
    StringVec1d popnames = registry.GetDataPack().GetAllPartitionNames(force_MIG);
    for (pop1 = 0, pindex = 0; pop1 < npop; ++pop1) {
        for (pop2 = 0; pop2 < npop; ++pop2, ++pindex) {
            if (pop1 != pop2) {
                string stitle("From");
                stitle += " "+popnames[pop2];
                stitle += " to "+popnames[pop1];
                m_sectitle.push_back(stitle);
            }
        }
    }

  // setting up the coalescePL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  m_plforceptr = new MigratePL (npop);

} // MigForce constructor

//___________________________________________________________

string MigForce::GetXMLStatusTag() const
{
  return string("");
} // GetXMLStatusTag

//__________________________________________________________________

vector<Event*> MigForce::MakeEvents(const ForceSummary& fs) const
{
  vector<Event*> tempvec;
  tempvec.push_back(new MigEvent(fs));
  return tempvec;
} // MakeEvents

//__________________________________________________________________

Summary* MigForce::CreateSummary(IntervalData& interval,
				 bool shortness) const
{
  return new MigSummary(interval, shortness);
} // CreateSummary


//___________________________________________________________
//___________________________________________________________

RecForce::RecForce(vector<Parameter> parameters,
                   long maxevents,
                   std::vector<ParamGroup> groups,
                   const UIVarsPrior & prior )
    : Force(    force_REC,
                "Rec",
                "Recombination",
                "Rec",
                "Recombination Rate",
                parameters,
                maxevents,
                defaults::recombinationRate,
                defaults::maxRecRate,
                defaults::minRecRate,
		defaults::maximization_maxRecRate,
		defaults::maximization_minRecRate,
                defaults::highvalRec,
                defaults::lowvalRec,
                defaults::highmultRec,
                defaults::lowmultRec,
                groups,
                prior)
{
  m_axisname.push_back(string(""));
  m_axisname.push_back(string("Region"));
  m_sectitle.clear();
  m_sectitle.push_back(string(" "));

  // setting up the recombinePL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  m_plforceptr = new RecombinePL ();

} /* RecForce constructor */ 

  
//___________________________________________________________


vector<Event*> RecForce::MakeEvents(const ForceSummary& fs) const
{
  vector<Event*> tempvec;
  tempvec.push_back(new ActiveRec(fs));
  tempvec.push_back(new InactiveRec(fs));
  return tempvec;
} // MakeEvents

//__________________________________________________________________

Summary* RecForce::CreateSummary(IntervalData& interval,
				 bool shortness) const
{
  // as far as we know, RecSummaries are always short.
  return new RecSummary(interval, shortness);
} // CreateSummary

//___________________________________________________________

//__________________________________________________________________
//___________________________________________________________

PartitionForce::PartitionForce(
                    force_type          tag,
                    string              name,
                    string              fullname,
                    string              paramname,
                    string              fullparamname,
                    vector<Parameter>   parameters,
                    long                maxevents,
                    double              defvalue,
                    double              maxvalue,
                    double              minvalue,
		    double              maximizer_maxvalue,
		    double              maximizer_minvalue,
                    double              highval,
                    double              lowval,
                    double              highmult,
                    double              lowmult,
                    long                npartitions,
                    std::vector<ParamGroup> groups,
                    const UIVarsPrior &       prior)
    : Force(        tag,
                    name,
                    fullname,
                    paramname,
                    fullparamname,
                    parameters,
                    maxevents,
                    defvalue,
                    maxvalue,
                    minvalue,
		    maximizer_maxvalue,
		    maximizer_minvalue,
                    highval,
                    lowval,
                    highmult,
                    lowmult,
                    groups,
                    prior),
        m_npartitions(npartitions)
{
  // as a pure-virtual method class, the ctor just calls through
} // PartitionForce::ctor

//___________________________________________________________


long PartitionForce::ChoosePartition(long origpart, long chosenpart,
                                     bool islow, long midpoint) const
{
  return origpart;
} // PartitionForce::ChoosePartition

//___________________________________________________________

void PartitionForce::ModifyEvents(const ForceSummary& fs, 
   vector<Event*>& events) const
{
  vector<Event*>::iterator it;
  for (it = events.begin(); it != events.end(); ++it) {

    if ((*it)->Type() == activeRecEvent)
      dynamic_cast<ActiveRec*>(*it)->AddSizeForce(m_tag);

    if ((*it)->Type() == inactiveRecEvent)
      dynamic_cast<InactiveRec*>(*it)->AddSizeForce(m_tag);

  }

} // PartitionForce::ModifyEvents

//___________________________________________________________

bool PartitionForce::SetPartIndex(long value)
{
  m_partindex = value;
  return true;
} // PartitionForce::SetPartIndex

//___________________________________________________________

bool PartitionForce::IsAMember(const LongVec1d& m1, const LongVec1d& m2) const
{
  return m1[m_partindex] == m2[m_partindex];
} // PartitionForce::IsAMember

//___________________________________________________________

DoubleVec1d PartitionForce::CreateVectorOfParametersWithValue(double val) const
{
  DoubleVec1d pvec(m_parameters.size());
  DoubleVec1d::iterator part(pvec.begin());
  unsigned long part1, part2, nparts(GetNPartitions());

  assert(m_parameters.size() == nparts*nparts);

  for(part1 = 0; part1 < nparts && part != pvec.end(); ++part1)
     for(part2 = 0; part2 < nparts; ++part2, ++part)
        if (part1 == part2) *part = 0.0;
        else *part = val;

  return pvec;

} // PartitionForce::CreateVectorOfParametersWithValue

//___________________________________________________________

StringVec1d PartitionForce::MakeStartParamReport() const
{
  StringVec1d rpt;
  verbosity_type verbose = registry.GetUserParameters().GetVerbosity(); 

  if (verbose == VERBOSE) {
    string line = m_fullparamname+" (USR = user, FST = FST)";
    rpt.push_back(line);
    MethodTypeVec2d meth = registry.GetForceSummary().
      Get2DMethods(GetTag());
    DoubleVec2d start = registry.GetForceSummary().
      GetStartParameters().GetGlobal2dRates(GetTag());
    long nparts = registry.GetDataPack().GetNPartitionsByForceType(GetTag());
    long colwidth1 = 9, colwidth2 = 14;
    long totlength = nparts * colwidth2 + colwidth1;
    line = MakeCentered("to",totlength);
    rpt.push_back(line);
    line = MakeJustified("Pop",colwidth1);
    long part;
    for(part = 0; part < nparts; ++part)
      line += MakeCentered(indexToKey(part),colwidth2);
    rpt.push_back(line);
    line = MakeJustified("from 1",colwidth1);
    for(part = 0; part < nparts; ++part) {
      long ipart;
      for(ipart = 0; ipart < nparts; ++ipart) {
	string name = ToString(meth[part][ipart], false); // false to get short name
	if (part == ipart) name = "-";
	if (name == "-") line += MakeCentered(name,colwidth2);
	else line += 
	       MakeCentered(name+" "+Pretty(start[part][ipart],colwidth1),
			    colwidth2);
      }
      rpt.push_back(line);
      line.erase();
      line = MakeJustified(ToString(part+2),colwidth1);
    }
  }
  
  return(rpt);

} // PartitionForce::MakeStartParamReport

//___________________________________________________________

StringVec1d PartitionForce::MakeChainParamReport(const ChainOut& chout)
  const
{
  return(Tabulate(chout.GetEstimates().GetGlobal2dRates(GetTag()), 8));
} // PartitionForce::MakeChainParamReport

//___________________________________________________________

DoubleVec1d PartitionForce::SumXPartsToParts(const DoubleVec1d& xparts) const
{
  DoubleVec1d parts(m_npartitions,0.0);
  LongVec1d nparts(registry.GetDataPack().GetAllNPartitions());

  LongVec1d indicator(registry.GetDataPack().GetNPartitionForces(),0L);

  DoubleVec1d::const_iterator xpart;
  for(xpart = xparts.begin(); xpart != xparts.end(); ++xpart) {
    parts[indicator[m_partindex]] += *xpart;

    long part;
    for(part = nparts.size() - 1; part >= 0; --part) {
      ++indicator[part];
      if (indicator[part] < nparts[part]) break;
      indicator[part] = 0;
    }
  }

  return parts;
} // PartitionForce::SumXPartsToParts

//___________________________________________________________

DoubleVec1d PartitionForce::SumXPartsToParts(const DoubleVec1d& xparts,
					     const DoubleVec1d& growths, double etime) const
{
  DoubleVec1d parts(m_npartitions,0.0);
  LongVec1d nparts(registry.GetDataPack().GetAllNPartitions());

  LongVec1d indicator(registry.GetDataPack().GetNPartitionForces(),0L);

  long xpart, nxparts = xparts.size();
  for(xpart = 0; xpart < nxparts; ++xpart) {
    parts[indicator[m_partindex]] += xparts[xpart] * 
      exp(-growths[xpart]*etime);

    long part;
    for(part = nparts.size() - 1; part >= 0; --part) {
      ++indicator[part];
      if (indicator[part] < nparts[part]) break;
      indicator[part] = 0;
    }
  }

  return parts;
} // PartitionForce::SumXPartsToParts

//___________________________________________________________

string PartitionForce::MakeStatusXML(const string& mystatus) const
{
  return(GetXMLStatusTag() + mystatus + MakeCloseTag(GetXMLStatusTag()));
} // PartitionForce::MakeStatusXML

//___________________________________________________________
//___________________________________________________________

LocalPartitionForce::LocalPartitionForce(
                    force_type          tag,
                    string              name,
                    string              fullname,
                    string              paramname,
                    string              fullparamname,
                    vector<Parameter>   parameters,
                    long                maxevents,
                    double              defvalue,
                    double              maxvalue,
                    double              minvalue,
		    double              maximizer_maxvalue,
		    double              maximizer_minvalue,
                    double              highval,
                    double              lowval,
                    double              highmult,
                    double              lowmult,
                    long                npartitions,
                    long                localsite,
                    std::vector<ParamGroup> groups,
                    const UIVarsPrior &       prior)
    : PartitionForce(        
                    tag,
                    name,
                    fullname,
                    paramname,
                    fullparamname,
                    parameters,
                    maxevents,
                    defvalue,
                    maxvalue,
                    minvalue,
		    maximizer_maxvalue,
		    maximizer_minvalue,
                    highval,
                    lowval,
                    highmult,
                    lowmult,
                    npartitions,
                    groups,
                    prior),
        m_localsite(localsite)
{
  // deliberately blank
} // LocalPartitionForce ctor

//___________________________________________________________


StringVec1d LocalPartitionForce::ToXML(unsigned long nspaces) const
{
  StringVec1d xmllines(Force::ToXML(nspaces));

  string mytag(MakeTag(xmlstr::XML_TAG_DISEASELOCATION));
  nspaces += INDENT_DEPTH;
  string line = MakeIndent(mytag,nspaces) + ToString(GetLocalSite()) + MakeCloseTag(mytag);

  // insert location information just before close tag
  StringVec1d::iterator it = xmllines.end();
  --it;
  xmllines.insert(it,line);

  return xmllines;

} // LocalPartitionForce::ToXML

//__________________________________________________________________

long LocalPartitionForce::ChoosePartition(long origpart, 
  long chosenpart, bool islow, long midpoint) const
{
  // if the disease marker is NOT present on our branch
  if (!((m_localsite <= midpoint && islow) ||
	(m_localsite > midpoint && !islow))) {

    return chosenpart;
  }

  return origpart;

} // LocalPartitionForce::ChoosePartition

//___________________________________________________________
//___________________________________________________________


GrowthForce::GrowthForce(vector<Parameter> parameters,
                         long maxevents,
                         std::vector<ParamGroup> groups,
                         const UIVarsPrior & prior )
    : Force(    force_GROW,
                "Grow",
                "Growth",
                "Growth",
                "GrowthRate",
                parameters,
                maxevents,
                defaults::growth,
                defaults::maxGrowRate,
                defaults::minGrowRate,
		defaults::maximization_maxGrowRate,
		defaults::maximization_minGrowRate,
                defaults::highvalGrowth,
                defaults::lowvalGrowth,
                defaults::highmultGrowth,
                defaults::lowmultGrowth,
                groups,
                prior)
{
  m_axisname.push_back(string("Population"));
  m_axisname.push_back(string("Region"));
  m_sectitle = registry.GetDataPack().GetAllCrossPartitionNames();

  // setting up the growPL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  m_plforceptr = new GrowPL (parameters.size());

} // GrowthForce::ctor

//___________________________________________________________


vector<Event*> GrowthForce::MakeEvents(const ForceSummary& fs) const
{
  vector<Event*> tempvec;  // yes this returns an empty vector
  return tempvec;

} // GrowthForce::MakeEvents()

//__________________________________________________________________

Summary* GrowthForce::CreateSummary(IntervalData& interval,
				    bool shortness) const
{
  return NULL;  // yes, we have no summary of our own

} // CreateSummary

//___________________________________________________________

void GrowthForce::ModifyEvents(const ForceSummary& fs, 
   vector<Event*>& events) const
{

  // This routine does a search-and-replace on the target
  // vector of Events.  It removes CoalActive, CoalInactive
  // and MigEvent Events and replaces them with growth versions.
  // ActiveRec and InactiveRec Events are definitely unaffected.
  // If you add another Event, you must decide if it is affected.
  //
  // Note: the MigEvent changes do not actually occur yet. Jon 2006/02/23

  vector<Event*>::iterator it = events.begin();
  vector<Event*>::iterator end = events.end();

  for ( ; it != end; ++it) {
    Event* oldevent = *it;
    if (oldevent->Type() == activeCoalEvent) {
      Event* newevent = new ActiveGrowCoal(fs);
      delete oldevent;
      *it = newevent;
      continue;
    }
    if ((*it)->Type() == inactiveCoalEvent) {
      Event* newevent = new InactiveGrowCoal(fs);
      delete oldevent;
      *it = newevent;
      continue;
    }
  }

} // GrowthForce::ModifyEvents()

//___________________________________________________________


DoubleVec1d GrowthForce::RetrieveGlobalLogParameters(const ForceParameters& fp) const
{
DoubleVec1d params(fp.GetGlobalParametersByTag(GetTag()));

return params;

} // Force::RetrieveLogParameters

DoubleVec1d GrowthForce::RetrieveRegionalLogParameters(const ForceParameters& fp) const
{
DoubleVec1d params(fp.GetRegionalParametersByTag(GetTag()));

return params;

} // Force::RetrieveLogParameters

long GrowthForce::ReportDimensionality() const
{
    if(m_parameters.size() == 1)
    {
        return 1L;
    }
    return 2L;
}

std::string GrowthForce::MakeOpeningTag(unsigned long nspaces) const
{
    return MakeIndent(MakeTagWithType(GetXMLName(),ToString(growth_CURVE)),
                         nspaces);
}

//___________________________________________________________
//___________________________________________________________


LogisticSelectionForce::LogisticSelectionForce(vector<Parameter> parameters,
                         long maxevents,
			 long paramvecindex,
                         std::vector<ParamGroup> groups,
                         const UIVarsPrior & prior )
    : Force(    force_LOGISTICSELECTION,
                "LSelect",
                "Logistic Selection",
                "LSelectCoeff",
                "Logistic Selection Coefficient",
                parameters,
                maxevents,
                defaults::logisticSelection,
                defaults::maxLSelectCoeff,
                defaults::minLSelectCoeff,
		defaults::maximization_maxLSelectCoeff,
		defaults::maximization_minLSelectCoeff,
                defaults::highvalLSelect,
                defaults::lowvalLSelect,
                defaults::highmultLSelect,
                defaults::lowmultLSelect,
                groups,
                prior)
{
  m_axisname.push_back(string("Population"));
  m_axisname.push_back(string("Region"));
  m_sectitle = registry.GetDataPack().GetAllCrossPartitionNames();

  long numPartitionForces = registry.GetDataPack().GetNPartitionForces();

  if (1 != numPartitionForces)
    {
      string msg = "LogisticSelectionForce constructor, detected ";
      msg += ToString(numPartitionForces) + " partition forces; ";
      msg += "currently, only one such force type is allowed.";
      throw implementation_error(msg);
    }
  long numCrossPartitions = registry.GetDataPack().GetNCrossPartitions();
  if (2 != numCrossPartitions)
    {
      string msg = "LogisticSelectionForce constructor, detected ";
      msg += ToString(numCrossPartitions) + " populations; ";
      msg += "must have exactly 2, one for the favored allele, ";
      msg += "one for the disfavored allele.";
      throw implementation_error(msg);
    }
  // setting up the LogisticSelectionPL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  m_plforceptr = new LogisticSelectionPL(paramvecindex);

} // LogisticSelectionForce::ctor

//___________________________________________________________


vector<Event*> LogisticSelectionForce::MakeEvents(const ForceSummary& fs) const
{
  vector<Event*> tempvec;  // yes this returns an empty vector
  return tempvec;

} // LogisticSelectionForce::MakeEvents()

//__________________________________________________________________

Summary* LogisticSelectionForce::CreateSummary(IntervalData& interval,
					       bool shortness) const
{
  return NULL;  // yes, we have no summary of our own

} // CreateSummary

//___________________________________________________________

void LogisticSelectionForce::ModifyEvents(const ForceSummary& fs, 
					  vector<Event*>& events) const
{

  // This routine does a search-and-replace on the target
  // vector of Events.  It removes CoalActive, CoalInactive
  // and MigEvent Events and replaces them with logistic selection versions.
  // ActiveRec and InactiveRec Events are definitely unaffected.
  // If you add another Event, you must decide if it is affected.
  //
  // Note: the MigEvent changes do not actually occur yet. Jon 2006/02/23

  vector<Event*>::iterator it = events.begin();
  vector<Event*>::iterator end = events.end();

  for ( ; it != end; ++it) {
    Event* oldevent = *it;
    if (oldevent->Type() == activeCoalEvent) {
      Event* newevent = new ActiveLogisticSelectionCoal(fs);
      delete oldevent;
      *it = newevent;
      continue;
    }
    if ((*it)->Type() == inactiveCoalEvent) {
      Event* newevent = new InactiveLogisticSelectionCoal(fs);
      delete oldevent;
      *it = newevent;
      continue;
    }
    if (migEvent == oldevent->Type())
      {
	string msg = "Logistic selection is now designed to work with ";
	msg += "the \"disease\" force, not the \"migration\" force.";
	msg += "If your data is divided into two \"populations\" with ";
	msg += "migration between them, please edit your input file ";
	msg += "and transform it into a one-population data set, ";
	msg += "with a disease status specified for each individual ";
	msg += "(healthy = favored allele, diseased = disfavored allele).";
	throw implementation_error(msg);
      }
    if (diseaseEvent == oldevent->Type())
      {
	Event* newevent = new DiseaseLogSelEvent(fs);
	delete oldevent;
	*it = newevent;
	continue;
      }
  }

} // LogisticSelectionForce::ModifyEvents()

//___________________________________________________________


DoubleVec1d LogisticSelectionForce::RetrieveGlobalLogParameters(const ForceParameters& fp) const
{
  DoubleVec1d params(fp.GetGlobalParametersByTag(GetTag()));

  return params;

}

DoubleVec1d LogisticSelectionForce::RetrieveRegionalLogParameters(const ForceParameters& fp) const
{
  DoubleVec1d params(fp.GetRegionalParametersByTag(GetTag()));

  return params;

}

long LogisticSelectionForce::ReportDimensionality() const
{
    if(m_parameters.size() == 1)
    {
        return 1L;
    }
    return 2L;
}

std::string LogisticSelectionForce::MakeOpeningTag(unsigned long nspaces) const
{
    return MakeIndent(MakeTag(GetXMLName()), nspaces);
}


//__________________________________________________________________
//___________________________________________________________

DiseaseForce::DiseaseForce(
            vector<Parameter> parameters,
            long maxevents,
	    bool hasLogisticSelection,
            long nstates,
            long localsite,
            std::vector<ParamGroup> groups,
            const UIVarsPrior & prior)
    : LocalPartitionForce(
                force_DISEASE,
                "Disease",
                "Disease Status",
                "Disease MuRate",
                "Disease Mutation Rate",
                parameters,
                maxevents,
                defaults::disease,
                defaults::maxDiseaseRate,
                defaults::minDiseaseRate,
		defaults::maximization_maxDiseaseRate,
		defaults::maximization_minDiseaseRate,
                defaults::highvalDisease,
                defaults::lowvalDisease,
                defaults::highmultDisease,
                defaults::lowmultDisease,
                nstates,
                localsite,
                groups,
                prior)
{
  m_axisname.push_back(string("Population"));
  m_axisname.push_back(string("Region"));
  m_sectitle = registry.GetDataPack().GetAllPartitionNames(force_DISEASE);
  // setting up the diseasePL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()

  if (hasLogisticSelection)
    m_plforceptr = new DiseaseLogisticSelectionPL(nstates);
  else
    m_plforceptr = new DiseasePL(nstates);

} // DiseaseForce::ctor

//___________________________________________________________


string DiseaseForce::GetXMLStatusTag() const
{
  return MakeTag(xmlstr::XML_TAG_DISEASESTATUS);
} // DiseaseForce::GetXMLStatusTag


//__________________________________________________________________

vector<Event*> DiseaseForce::MakeEvents(const ForceSummary& fs) const
{
  vector<Event*> tempvec;
  tempvec.push_back(new DiseaseEvent(fs));
  return tempvec;
} // MakeEvents

//__________________________________________________________________

Summary* DiseaseForce::CreateSummary(IntervalData& interval,
				     bool shortness) const
{
  return new DiseaseSummary(interval, shortness);
} // DiseaseForce::CreateSummary

//___________________________________________________________
//___________________________________________________________

StickForce::StickForce(
              force_type         tag,
              string             name,
              string             fullname,
              string             paramname,
	      string             fullparamname,
              vector<Parameter>  parameters,
              long               maxevents,
              double             defvalue,
              double             maxvalue,
              double             minvalue,
	      double             maximizer_maxvalue,
	      double             maximizer_minvalue,
              double             highval,
              double             lowval,
              double             highmult,
              double             lowmult,
              std::vector<ParamGroup> groups,
              const UIVarsPrior& prior)
     : Force(tag,name,fullname,paramname,fullparamname,parameters,
	     maxevents,defvalue,maxvalue,minvalue,maximizer_maxvalue,
	     maximizer_minvalue,highval,lowval,highmult,
	     lowmult,groups,prior), m_percentchange(defaults::perThetaChange)
{
   // as a pure-virtual method class, the ctor just calls through
} // StickForce::ctor

//___________________________________________________________
//___________________________________________________________

StickExpGrowForce::StickExpGrowForce(
            vector<Parameter> parameters,
            long maxevents ,
            std::vector<ParamGroup> groups,
            const UIVarsPrior & prior)
    : StickForce(
                force_EXPGROWSTICK,
                "StickExpGrow",
                "StickExpGrow Status",
                "StickExpGrow MuRate",
                "StickExpGrow Mutation Rate",
                parameters,
                maxevents,
                defaults::growth,
                defaults::maxGrowRate,
                defaults::minGrowRate,
		defaults::maximization_maxGrowRate,
		defaults::maximization_minGrowRate,
                defaults::highvalGrowth,
                defaults::lowvalGrowth,
                defaults::highmultGrowth,
                defaults::lowmultGrowth,
                groups,
                prior),
      m_negln(log(1.0+m_percentchange)),
      m_posln(log(1.0-m_percentchange))

{
  m_axisname.push_back(string("Population"));
  m_axisname.push_back(string("Region"));
  m_sectitle = registry.GetDataPack().GetAllCrossPartitionNames();
  // setting up the normal growPL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  m_plforceptr = new GrowPL (parameters.size());

} // StickExpGrowForce::ctor

//___________________________________________________________

std::string StickExpGrowForce::MakeOpeningTag(unsigned long nspaces) const
{
    return MakeIndent(MakeTagWithType(GetXMLName(),
               xmlstr::XML_ATTRVALUE_STICKEXP),nspaces);
}

//___________________________________________________________

std::string StickExpGrowForce::GetXMLName() const
{
    return xmlstr::XML_TAG_GROWTH;
}

//___________________________________________________________

vector<Event*> StickExpGrowForce::MakeEvents(const ForceSummary& fs) const
{
    vector<Event*> tempvec;  // yes this returns an empty vector
    return tempvec;
}

//___________________________________________________________

void StickExpGrowForce::ModifyEvents(const ForceSummary& fs, 
   vector<Event*>& events) const
{

  // This routine does a search-and-replace on the target
  // vector of Events.  It removes CoalActive, CoalInactive
  // and MigEvent Events and replaces them with growth versions.
  // ActiveRec and InactiveRec Events are definitely unaffected.
  // If you add another Event, you must decide if it is affected.
  //
  // Note: the MigEvent changes do not actually occur yet. Jon 2006/02/23

  vector<Event*>::iterator it = events.begin();
  vector<Event*>::iterator end = events.end();

  for ( ; it != end; ++it) {
    Event* oldevent = *it;
    if (oldevent->Type() == activeCoalEvent) {
      Event* newevent = new ActiveStairStickCoal(fs);
      delete oldevent;
      *it = newevent;
      continue;
    }
    if ((*it)->Type() == inactiveCoalEvent) {
      Event* newevent = new InactiveStairStickCoal(fs);
      delete oldevent;
      *it = newevent;
      continue;
    }
  }

} // StickExpGrowForce::ModifyEvents()

//___________________________________________________________

Summary* StickExpGrowForce::CreateSummary(IntervalData& interval,
   bool shortness) const
{
  return NULL;  // yes, we have no summary of our own
}

//___________________________________________________________

DoubleVec1d StickExpGrowForce::RetrieveGlobalLogParameters
   (const ForceParameters& fp) const
{
    DoubleVec1d params(fp.GetGlobalParametersByTag(GetTag()));
    return params;
}

//___________________________________________________________

DoubleVec1d StickExpGrowForce::RetrieveRegionalLogParameters
   (const ForceParameters& fp) const
{
    DoubleVec1d params(fp.GetRegionalParametersByTag(GetTag()));
    return params;
}

//___________________________________________________________

long StickExpGrowForce::ReportDimensionality() const
{
    if (m_parameters.size() == 1)
    {
       return 1L;
    }
    return 2L;
}

//___________________________________________________________

DoubleVec1d StickExpGrowForce::ComputeStickValues(double eventtime,
		const ForceParameters& fp) const
{
return m_timesize.SizeAt(fp,eventtime);
} /* StickExpGrowForce */

//___________________________________________________________

double StickExpGrowForce::NextTime(const DoubleVec1d& params,
   double origtime) const
{
#if 0
DoubleVec1d newtimes(param.size());
DoubleVec1d::size_type i;
for(i = 0; i < params.size(); ++i)
   newtimes[i] = ((params[i] < 0.0) ? origtime - m_negln/param :
                                      origtime - m_posln/param);

return *std::min_element(newtimes.begin(),newtimes.end());
#endif

double newtime(DBL_BIG);
DoubleVec1d::const_iterator param;
assert(!params.empty());  // no growth?!
for(param = params.begin(); param != params.end(); ++param) {
    double ptime((*param < 0.0) ? origtime - m_negln/(*param) :
                                  origtime - m_posln/(*param));
    if (ptime < newtime) newtime = ptime;
}

return newtime;

}

//___________________________________________________________

StickLogSelectForce::StickLogSelectForce(
            vector<Parameter> parameters,
            long maxevents ,
            std::vector<ParamGroup> groups,
            const UIVarsPrior & prior)
    : StickForce(
                force_LOGSELECTSTICK,
                "StickLogSelect",
                "StickLogSelect Status",
                "StickLogSelect MuRate",
                "StickLogSelect Mutation Rate",
                parameters,
                maxevents,
                defaults::logisticSelection,
                defaults::maxLSelectCoeff,
                defaults::minLSelectCoeff,
		defaults::maximization_maxLSelectCoeff,
		defaults::maximization_minLSelectCoeff,
                defaults::highvalLSelect,
                defaults::lowvalLSelect,
                defaults::highmultLSelect,
                defaults::lowmultLSelect,
                groups,
                prior)

{
  m_axisname.push_back(string("Population"));
  m_axisname.push_back(string("Region"));
  const DataPack& dp(registry.GetDataPack());
  m_sectitle = dp.GetAllCrossPartitionNames();

  long numpforces(dp.GetNPartitionForces());
  if (numpforces != 1)
    {
      string msg = "StickLogisticSelectionForce constructor, detected ";
      msg += ToString(numpforces) + " partition forces; ";
      msg += "currently, only one such force type is allowed.";
      throw implementation_error(msg);
    }
  long numcpforces(dp.GetNCrossPartitions());
  if (numcpforces != 2)
    {
      string msg = "StickLogisticSelectionForce constructor, detected ";
      msg += ToString(numcpforces) + " populations; ";
      msg += "must have exactly 2, one for the favored allele, ";
      msg += "one for the disfavored allele.";
      throw implementation_error(msg);
    }
  // setting up the StickLogisticSelectionPL object
  // as a pointer that will be used later by the 
  // PostLike::GetPLfunction()
  m_plforceptr = new StickLogSelectPL (registry.GetForceSummary());

} // StickLogSelectForce::ctor

//___________________________________________________________

string StickLogSelectForce::GetXMLName() const
{
    return xmlstr::XML_TAG_LOGISTICSELECTION;
}

//___________________________________________________________

vector<Event*> StickLogSelectForce::MakeEvents(const ForceSummary& fs) const
{
    vector<Event*> tempvec;  // yes this returns an empty vector
    return tempvec;
}

//___________________________________________________________

string StickLogSelectForce::MakeOpeningTag(unsigned long nspaces) const
{
    return MakeIndent(MakeTagWithType(GetXMLName(),
               xmlstr::XML_ATTRVALUE_STICK),nspaces);
}

//___________________________________________________________

Summary* StickLogSelectForce::CreateSummary(IntervalData& interval,
   bool shortness) const
{
  return NULL;  // yes, we have no summary of our own
}

//___________________________________________________________

DoubleVec1d StickLogSelectForce::RetrieveGlobalLogParameters(const
   ForceParameters& fp) const
{
  DoubleVec1d params(fp.GetRegionalParametersByTag(GetTag()));
  return params;
}

//___________________________________________________________

DoubleVec1d StickLogSelectForce::RetrieveRegionalLogParameters(const
   ForceParameters& fp) const
{
  DoubleVec1d params(fp.GetRegionalParametersByTag(GetTag()));
  return params;
}

//___________________________________________________________

long StickLogSelectForce::ReportDimensionality() const
{
  if(m_parameters.size() == 1) return 1L;
  else return 2L;
}

//___________________________________________________________

DoubleVec1d StickLogSelectForce::ComputeStickValues(double eventtime,
   const ForceParameters& fp) const
{
  return m_timesize.SizeAt(fp,eventtime);
}

//___________________________________________________________

double StickLogSelectForce::NextTime(const DoubleVec1d& params,
   double origtime) const
{
// JDEBUG -- constant time is wrong!
   double newlength = 0.01;
   return origtime + newlength;
}

//___________________________________________________________
//___________________________________________________________

StringVec1d Tabulate(double params, long width=7)
{
  StringVec1d str;
  str.push_back(Pretty(params,width));
  return(str);
} /* Tabulate(double) */

//___________________________________________________________

StringVec1d Tabulate(const DoubleVec1d& params, long width=7)
{
  StringVec1d str;
  long i;
  for (i = 0; i < (long)params.size(); ++i) str.push_back(Pretty(params[i],width));
  return(str);
} /* Tabulate(DoubleVec1d) */

//___________________________________________________________

StringVec1d Tabulate(const DoubleVec2d& params, long width=7)
{
  StringVec1d str;
  long i;
  long j;
  for (i = 0; i < static_cast<long>(params.size()); ++i) {
    string tempstr = "";
    for (j = 0; j < static_cast<long>(params[0].size()); ++j) {
      if (j != 0) tempstr += " ";
      if (j != i) tempstr += Pretty(params[i][j],width);
      else {
        long k;
        for (k = 0; k < width; ++k) tempstr += "-";
      }
      tempstr += " ";
    }
    str.push_back(tempstr);
  }
  return(str);
} /* Tabulate(DoubleVec2d) */


