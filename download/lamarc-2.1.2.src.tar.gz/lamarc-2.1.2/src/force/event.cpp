// $Id: event.cpp,v 1.33 2007/09/24 23:25:48 lpsmith Exp $

/* 
Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <algorithm>
#include "branch.h"
#include "shared_ptr.hpp"
#include "event.h"
#include "forcesummary.h"
#include "arranger.h"
#include "tree.h"
#include "registry.h"
#include "mathx.h"
#include "stringx.h"
#include "timesize.h"
#include <functional> // for divides<> and less<> used in ThrowIfSubPopSizeTiny

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

typedef boost::shared_ptr<RBranch> RBranch_ptr;


//____________________________________________________________________________
//____________________________________________________________________________

Event::Event(const ForceSummary& fs)
	: ar(NULL), 
	m_CalcSizeAtTime(fs.GetSizeCalculator()),
	m_allparams(fs.GetStartParameters())
{
} /* Event ctor */

//____________________________________________________________________________

bool Event::Done() const
{ 
// As far as this event knows, we are Done if there are no more active 
// lineages.

  if (ar->ActiveSize() == 0) return true;
  else return false;

} /* Done */

//____________________________________________________________________________

Event::Event(const Event& src) :
ar(src.ar), m_maxEvents(src.m_maxEvents), m_pindex(src.m_pindex),
m_thetas(src.m_thetas), m_growths(src.m_growths),m_allparams(src.m_allparams)
{
  if (src.m_CalcSizeAtTime) {
     m_CalcSizeAtTime = src.m_CalcSizeAtTime->Clone();
  } else {
     // Clone (below) shouldn't handle NULL pointers, but NULL
     // is a perfectly valid value for this field and we want
     // to preserve it rather than introducing garbage into memory.
     m_CalcSizeAtTime = NULL;
  }
} /* Event copy ctor */

//____________________________________________________________________________

void Event::InstallParameters(const ForceParameters& starts)
{
  m_thetas = starts.GetRegionalThetas();
  m_growths = starts.GetGrowthRates();
  m_allparams = starts;
} /* Event::InstallParameters */

//____________________________________________________________________________

void Event::InstallThetas(const DoubleVec1d& thetas)
{
  m_thetas = thetas;
} /* InstallThetas */

//____________________________________________________________________________
//____________________________________________________________________________

XPartitionEvent::XPartitionEvent(const ForceSummary& fs)
	: Event(fs),
          m_nxparts(registry.GetDataPack().GetNCrossPartitions()) 
{
       	/* deliberately blank */
} /* XPartitionEvent ctor */

//____________________________________________________________________________

void XPartitionEvent::ThrowIfSubPopSizeTiny(double eventT) const
{
  DoubleVec1d popsizes(m_CalcSizeAtTime->SizeAt(m_allparams,eventT));
  transform(popsizes.begin(),popsizes.end(),popsizes.begin(),
            bind2nd(divides<double>(),defaults::minMuRate));
  if (std::find_if(popsizes.begin(),popsizes.end(),bind2nd(less<double>(),1.0))
      != popsizes.end()) {
     std::string estring("XPartitionEvent::ThrowIfSubPopSizeTiny:  ");
     estring += "Tried to have a coal event at " + ToString(eventT);
     tinypopulation_error e(estring);
     throw e;
  }

} /* XPartitionEvent::ThrowIfSubPopSizeTiny */

//____________________________________________________________________________
//____________________________________________________________________________

CoalEvent::CoalEvent(const ForceSummary& fs, bool isactive) 
  : XPartitionEvent(fs),
    m_chosenxpart(FLAGLONG),
    m_isactive(isactive)
{
	// set up base class fields deferred to the subclass
    m_maxEvents = fs.GetMaxEvents(force_COAL);
    m_pindex = FLAGLONG; // we use cross partitions, not partitions
} /* CoalEvent constructor */

//____________________________________________________________________________

void CoalEvent::InstallParameters(const ForceParameters& starts)
{
  Event::InstallParameters(starts);
  
} /* InstallParameters */

//____________________________________________________________________________

void CoalEvent::DoEvent(double eventT)
{
  ThrowIfSubPopSizeTiny(eventT); 
  // Pick two active branches from the population at random.
  double rn = ar->randomSource->Float();
  Branch_ptr branch1 = ar->m_activelist.RemoveBranch(force_COAL, m_chosenxpart, rn);

  rn = ar->randomSource->Float();
  Branch_ptr branch2;

  if (m_isactive) {
    branch2 = ar->m_activelist.RemoveBranch(force_COAL, m_chosenxpart, rn);
  }
  else {
    branch2 = ar->m_inactivelist.RemoveBranch(force_COAL, m_chosenxpart, rn);
  }
  FinishEvent(eventT, branch1, branch2);
} /* DoEvent */

void CoalEvent::FinishEvent(double eventT, Branch_ptr branch1, Branch_ptr branch2)
{
  assert(branch1->HasSamePartitionsAs(branch2));
  if (m_isactive) {
    Branch_ptr newbranch = ar->GetTree()->
      CoalesceActive(eventT, branch1, branch2);
    ar->m_activelist.Append(newbranch);
  }
  else {
    Branch_ptr newbranch = ar->GetTree()->
      CoalesceInactive(eventT, branch1, branch2);
    ar->m_inactivelist.Collate(newbranch);
  }
} /* FinishEvent */

//____________________________________________________________________________
//____________________________________________________________________________

ActiveCoal::ActiveCoal(const ForceSummary& fs) 
  : CoalEvent(fs, true),
    m_invTheta()
{
} /* ActiveCoal constructor */

//____________________________________________________________________________

Event* ActiveCoal::Clone() const
{
  ActiveCoal* event = new ActiveCoal(*this);
  return event;

} /* ActiveCoal::Clone */

//____________________________________________________________________________

void ActiveCoal::InstallParameters(const ForceParameters& starts)
{
  CoalEvent::InstallParameters(starts);

  m_invTheta = starts.GetRegionalThetas();
  
  // store 1/Theta
  std::transform(m_invTheta.begin(), m_invTheta.end(),
		  m_invTheta.begin(),
		  std::bind1st(std::divides<double>(),1.0));

} /* InstallParameters */

//____________________________________________________________________________

void ActiveCoal::InstallThetas(const DoubleVec1d& thetas)
{
  Event::InstallThetas(thetas);
  m_invTheta = thetas;
  
  // store 1/Theta
  std::transform(m_invTheta.begin(), m_invTheta.end(),
		  m_invTheta.begin(),
		  std::bind1st(std::divides<double>(),1.0));

} /* InstallThetas */

//____________________________________________________________________________

double ActiveCoal::PickTime(double)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  // Note:  The expectation value of this "delta t" is theta/(k*(k-1)),
  // where k (the number of active lineages) and theta correspond to the
  // population which yields the smallest "delta t."

  map<double, long> times;
  double newtime;
  long i;

  for (i = 0; i < m_nxparts; ++i) // loop over populations
    {
      // if there are at least two active lineages in this population...
      if (ar->m_xactives[i] > 1)
	{
	  // compute the time of the next coalescence
	  newtime = - log(ar->randomSource->Float()) / 
	    (m_invTheta[i] * ar->m_xactives[i] * (ar->m_xactives[i] - 1.0));

	  // insert it into map (for sorting)
	  times.insert(make_pair(newtime, i));
	}
    }

  if (times.empty())
    {
      // no event is possible
      m_chosenxpart = FLAGLONG;
      return FLAGDOUBLE;
    }
  else
    {
      // the first map entry is the smallest, and thus chosen, time
      map<double, long>::const_iterator mapit = times.begin();
      m_chosenxpart = (*mapit).second;
      assert ((*mapit).first >= 0.0);
      return (*mapit).first;
    }

} /* ActiveCoal::PickTime */

//____________________________________________________________________________
//____________________________________________________________________________

ActiveGrowCoal::ActiveGrowCoal(const ForceSummary& fs) 
  : CoalEvent(fs, true)
{
} /* ActiveGrowCoal constructor */

//____________________________________________________________________________

Event* ActiveGrowCoal::Clone() const
{
  ActiveGrowCoal* event = new ActiveGrowCoal(*this);
  return event;

} /* ActiveCoal::Clone */

//____________________________________________________________________________

double ActiveGrowCoal::PickTime(double starttime)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  // Note:  The expectation value of this "delta t" is:
  //                           (1/g)*ExpE1(k*(k-1)*exp(g*starttime)/(g*theta)),
  // where g, theta, and k are the growth rate, theta, and number of active lineages
  // for the population which yields the smallest "delta t."
  // For details on the function ExpE1(), see mathx.cpp.

  map<double, long> times;
  double newtime = 0.0;
  double magicstart;
  long i;

  // compute coalescence terms per cross partition
  for (i = 0; i < m_nxparts; ++i)
    {
      // if there are at least two active lineages in this population...
      if (ar->m_xactives[i] > 1)
	{
	  // compute the time of the next coalescence
	  // first do computation in "magic time"
	  newtime =  - log(ar->randomSource->Float()) / 
	    (ar->m_xactives[i] * (ar->m_xactives[i] - 1.0) / m_thetas[i]);

	  // now convert to "real time"
	  if (m_growths[i] != 0)
	    {
	      // convert starttime to magical time
	      magicstart = -(1.0 - exp(m_growths[i] * starttime)) / m_growths[i];
	      // add starttime to displacement
	      newtime += magicstart;
	      // comvert result to real time
	      if (1.0 + m_growths[i] * newtime > 0.0)
		{ 
		  newtime = log(1.0 + m_growths[i] * newtime)/m_growths[i];
		  // convert back to displacement
		  newtime -= starttime;
		  // guard against underflow
		  if (newtime < DBL_EPSILON)
		    {
		      tinypopulation_error e("bad time proposed in Event::PickTime");
		      throw e;
		    }
		}
	      else
		newtime = MAX_LENGTH; // make this interval length
	                              // very unlikely to win the race
	    }
	  // (else newtime holds the same number that would have been
	  // computed by ActiveCoal, in the absence of growth)

	  // insert it into map (for sorting)
	  times.insert(make_pair(newtime, i));
	}
    }

  if (times.empty())
    {
      // no event is possible
      m_chosenxpart = FLAGLONG;
      return FLAGDOUBLE;
    }
  else
    {
      // the first map entry is the smallest, and thus chosen, time
      map<double, long>::const_iterator mapit = times.begin();
      m_chosenxpart = (*mapit).second;
      assert ((*mapit).first >= 0.0);
      return (*mapit).first;
    }

} /* ActiveGrowCoal::PickTime */


//____________________________________________________________________________
//____________________________________________________________________________

ActiveLogisticSelectionCoal::ActiveLogisticSelectionCoal(const ForceSummary& fs) 
  : CoalEvent(fs, true), m_selectionCoefficient(0.)
{
} /* ActiveLogisticSelectionCoal constructor */

//____________________________________________________________________________

Event* ActiveLogisticSelectionCoal::Clone() const
{
  ActiveLogisticSelectionCoal* event = new ActiveLogisticSelectionCoal(*this);
  return event;

} /* ActiveLogisticSelectionCoal::Clone */


//____________________________________________________________________________

void ActiveLogisticSelectionCoal::InstallParameters(const ForceParameters& starts)
{
  CoalEvent::InstallParameters(starts);
  m_selectionCoefficient = starts.GetLogisticSelectionCoefficient()[0];
} /* InstallParameters */

//____________________________________________________________________________
//____________________________________________________________________________

ActiveStairStickCoal::ActiveStairStickCoal(const ForceSummary& fs) 
  : CoalEvent(fs, true)
{
} /* ActiveStairStickCoal constructor */

//____________________________________________________________________________

Event* ActiveStairStickCoal::Clone() const
{
  ActiveStairStickCoal* event = new ActiveStairStickCoal(*this);
  return event;

} /* ActiveStairStickCoal::Clone */

//____________________________________________________________________________

double ActiveStairStickCoal::PickTime(double starttime)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time
  // interval, not the timestamp for the end of the interval.

  TimeList& intervals(ar->m_tree->GetTimeList());
  JBranch_ptr joint(intervals.FindStickAtTime(starttime));
  DoubleVec1d newfrac(m_nxparts);
  DoubleVec1d::iterator it;
  for(it = newfrac.begin(); it != newfrac.end(); ++it)
     // technically, we should be taking the log of (1-rnd[float]),
     // but that's the same as log(rnd[float]), so omitted for
     // simplicity/speed
     (*it) = -1.0 * log(ar->randomSource->Float());

  if (*max_element(ar->m_xactives.begin(),ar->m_xactives.end()) < 2) {
     m_chosenxpart = FLAGLONG;
     return FLAGDOUBLE;
  }

  DoubleVec1d total(newfrac.size(),0.0), oldtotal(newfrac.size(),0.0);
  if (!joint->NextJoint()) intervals.AddNextJoint(joint);
  double length(joint->BottomTime() - starttime), totallength(0.0);

  while(true) {
    oldtotal = total;
    DoubleVec1d thetas(joint->GetThetas());

    assert(thetas.size() == newfrac.size());

    double mindisplace(DBL_MAX);
    long i;
    for (i = 0; i < m_nxparts; ++i) {
       if (ar->m_xactives[i] < 2) continue;
       total[i] += ar->m_xactives[i] * (ar->m_xactives[i] - 1.0) /
          thetas[i] * length;
       if (total[i] > newfrac[i]) {
          double newdisplace(newfrac[i] - oldtotal[i]);
	  newdisplace /= ar->m_xactives[i] * (ar->m_xactives[i] - 1.0) /
             thetas[i];
	  newdisplace += totallength;
	  if (newdisplace < mindisplace) {
             m_chosenxpart = i;
	     mindisplace = newdisplace;
	  }
       }
    }
    if (mindisplace < DBL_MAX) return mindisplace;
    totallength += length;
    if (totallength >= MAX_LENGTH) return MAX_LENGTH;

    joint = intervals.NextJointAppendingIfLast(joint);
    if (!joint->NextJoint()) intervals.AddNextJoint(joint);
    length = joint->BottomTime() - joint->m_eventtime;
  }

  // can't get here
  assert(false);
  m_chosenxpart = FLAGLONG;
  return FLAGDOUBLE;
 
} /* ActiveStairStickCoal::PickTime */

//____________________________________________________________________________
//____________________________________________________________________________

InactiveStairStickCoal::InactiveStairStickCoal(const ForceSummary& fs) 
  : CoalEvent(fs, false)
{
} /* InactiveStairStickCoal constructor */

//____________________________________________________________________________

Event* InactiveStairStickCoal::Clone() const
{
  InactiveStairStickCoal* event = new InactiveStairStickCoal(*this);
  return event;

} /* InactiveStairStickCoal::Clone */

//____________________________________________________________________________

double InactiveStairStickCoal::PickTime(double starttime)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time
  // interval, not the timestamp for the end of the interval.

  TimeList& intervals(ar->m_tree->GetTimeList());
  JBranch_ptr joint(intervals.FindStickAtTime(starttime));
  DoubleVec1d newfrac(ar->m_xactives.size());
  DoubleVec1d::iterator it;
  for(it = newfrac.begin(); it != newfrac.end(); ++it)
     (*it) = -1.0 * log(ar->randomSource->Float());

  if (*max_element(ar->m_xactives.begin(),ar->m_xactives.end()) < 1 ||
      *max_element(ar->m_xinactives.begin(),ar->m_xinactives.end()) < 1 ) {
     m_chosenxpart = FLAGLONG;
     return FLAGDOUBLE;
  }

  DoubleVec1d total(newfrac.size(),0.0), oldtotal(newfrac.size(),0.0);
  if (!joint->NextJoint()) intervals.AddNextJoint(joint);
  double length(joint->BottomTime() - starttime), totallength(0.0);

  while(true) {
    oldtotal = total;
    DoubleVec1d thetas(joint->GetThetas());

    assert(thetas.size() == newfrac.size());

    double mindisplace(DBL_MAX);
    long i;
    for (i = 0; i < m_nxparts; ++i) {
       if (ar->m_xinactives[i] < 1 || ar->m_xactives[i] < 1) continue;
       total[i] += 2.0 * ar->m_xactives[i] * ar->m_xinactives[i] /
          thetas[i] * length;
       if (total[i] > newfrac[i]) {
          double newdisplace(newfrac[i] - oldtotal[i]);
	  newdisplace /= 2.0 * ar->m_xactives[i] * ar->m_xinactives[i] /
             thetas[i];
	  newdisplace += totallength;
	  if (newdisplace < mindisplace) {
             m_chosenxpart = i;
	     mindisplace = newdisplace;
	  }
       }
    }
    if (mindisplace < DBL_MAX) return mindisplace;
    totallength += length;
    if (totallength >= MAX_LENGTH) return MAX_LENGTH;

    joint = intervals.NextJointAppendingIfLast(joint);
    if (!joint->NextJoint()) intervals.AddNextJoint(joint);
    length = joint->BottomTime() - joint->m_eventtime;
  }

  // can't get here
  assert(false);
  m_chosenxpart = FLAGLONG;
  return FLAGDOUBLE;
 
} /* InactiveStairStickCoal::PickTime */


double ActiveLogisticSelectionCoal::PickTime(double starttime)
{
  if (2 != m_nxparts)
    {
      string msg = "ActiveLogisticSelectionCoal::PickTime() called with m_nxparts = ";
      msg += ToString(m_nxparts);
      msg += ".  m_nxparts must equal 2, reflecting one population with the major ";
      msg += "allele and one population with the minor allele.";
      throw implementation_error(msg);
    }

  if (0. == m_thetas[0] || 0. == m_thetas[1])
    {
      string msg = "ActiveLogisticSelectionCoal::PickTime() received an invalid Theta ";
      msg += "of 0.0.";
      throw impossible_error(msg);
    }

  if (ar->m_xactives[0] <= 1 && ar->m_xactives[1] <= 1)
    {
      // no event is possible
      m_chosenxpart = FLAGLONG;
      return FLAGDOUBLE;
    }


  // First, compute the interval lengths in "magic time"--drawn from an exponential
  // distribution assuming constant size for population "A" and for population "a".
  double dtau_A(FLAGDOUBLE), dtau_a(FLAGDOUBLE); // important:  these are < 0

  if (ar->m_xactives[0] > 1)
    dtau_A = -log(ar->randomSource->Float()) /
      (ar->m_xactives[0]*(ar->m_xactives[0] - 1.)/m_thetas[0]);

  if (ar->m_xactives[1] > 1)
    dtau_a = -log(ar->randomSource->Float()) /
      (ar->m_xactives[1]*(ar->m_xactives[1] - 1.)/m_thetas[1]);

  return LogisticSelectionPickTime(m_thetas[0],m_thetas[1],m_selectionCoefficient,
				   starttime,dtau_A,dtau_a,&m_chosenxpart);

}


// This helper function performs the transformations from "magic time" into "real time."
// These transformations are:
//
// dtau_A = (theta_a0*exp(s*t_s)*((exp(s*dt_A)-1)/s) + theta_A0*dt_A)/(theta_A0+theta_a0)
//
// dtau_a = (theta_A0*exp(-s*t_s)*((exp(-s*dt_a)-1)/(-s)) + theta_a0*dt_a)/(theta_A0+theta_a0)
//
// Given dtau_A and dtau_a, we solve for dt_A and dt_a, and return the shorter of these,
// along with the identity of the population which "won the horse race."
// Note that each transformation includes dt in both an exponential term and a linear term.
// In some cases, one of these terms is negligible; these are explained in the code below.
// When neither the exponential nor the linear term is negligible, the transformation
// can only be solved by iterative guessing.
//
// Note:  If this function is called, then a coalescence is possible
// in at least one of the two populations.  This is a requirement.
//
double LogisticSelectionPickTime(const double& theta_A0, const double& theta_a0,
				 const double& s, const double& t_s,
				 const double& dtau_A, const double& dtau_a,
				 long* pChosenPopulation)
{
  double dt_A(FLAGDOUBLE), dt_a(FLAGDOUBLE); // important: these are < 0
  double minimum_possible_dt(t_s * numeric_limits<double>::epsilon());
  double ln_theta_A0(log(theta_A0)), ln_theta_a0(log(theta_a0)), a, b(0.), c, x;

  if (s > 0)
    {
      if (s*t_s > EXPMAX - ln_theta_a0)
	{
	  // theta_a0 * exp(s*t_s) overflows.
	  // This means the expectation E[dt_A] underflows to zero,
	  // so if we return any nonzero dt_A, no matter how short,
	  // it will be many times longer than its expected value.
	  // Return the shortest interval possible (guaranteed to win the "horse race"),
	  // if a coalescence is allowed in population "A" (not allowed if k = 1).
	  if (dtau_A > .999*FLAGDOUBLE)
	    {
	      *pChosenPopulation = 0;
	      return minimum_possible_dt;
	    }
	  // Otherwise, population "a" coalesces.  Underflow simplifies the result.
	  *pChosenPopulation = 1;
	  return dtau_a*(theta_A0+theta_a0)/theta_a0;
	}
      
      if (s*t_s > 4.*LOG10 + ln_theta_A0 - ln_theta_a0)
	{
	  if (dtau_A > .999*FLAGDOUBLE)
	    {
	      // It's possible to coalesce in population "A",
	      // and the linear term in the right-hand side of the transformation
	      // for dtau_A may safely be ignored.
	      b = SafeProductWithExp(theta_a0,s*t_s); // guaranteed > 0
	      c = -dtau_A*(theta_A0+theta_a0); // c < 0
	      x = s*(-c)/b;
	      if (x > 1.0e-04)
		dt_A = (1./s)*log(1. + x);
	      else
		dt_A = x/s; // because log(1+x) = x + O(x^2)
	      if (dt_A < minimum_possible_dt)
		dt_A = minimum_possible_dt;
	    }
	  if (dtau_a > .999*FLAGDOUBLE)
	    {
	      // It's possible to coalesce in population "a",
	      // and the exponential term in the right-hand side of the
	      // transformation for dtau_a may safely be ignored.
	      // For s>0, (exp(-s*dt)-1)/(-s) is maximal at s=0.
	      dt_a = dtau_a*(theta_A0+theta_a0)/theta_a0;
	      if (dtau_A <= .999*FLAGDOUBLE || dt_a < dt_A)
		{
		  *pChosenPopulation = 1;
		  return dt_a; 
		}
	    }
	  // Recall a coalescence must be possible at least one of these populations,
	  // per this function's definition.
	  *pChosenPopulation = 0;
	  return dt_A;
	}
    }

  if (s < 0.)
    {
      // These overflow and almost-overflow cases are analogous to those above.
      if (-s*t_s > EXPMAX - ln_theta_A0)
	{
	  if (dtau_a > .999*FLAGDOUBLE)
	    {
	      *pChosenPopulation = 1;
	      return minimum_possible_dt;
	    }
	  *pChosenPopulation = 0;
	  return dtau_A*(theta_A0+theta_a0)/theta_A0;
	}
      
      if (-s*t_s > 4.*LOG10 + ln_theta_a0 - ln_theta_A0)
	{
	  if (dtau_a > .999*FLAGDOUBLE)
	    {
	      b = SafeProductWithExp(theta_A0,-s*t_s); // guaranteed > 0
	      c = -dtau_a*(theta_A0+theta_a0); // c < 0
	      x = s*c/b;
	      if (x > 1.0e-04)
		dt_a = (1./(-s))*log(1. + x);
	      else
		dt_a = x/(-s); // because log(1+x) = x + O(x^2)
	      if (dt_a < minimum_possible_dt)
		dt_a = minimum_possible_dt;
	    }
	  if (dtau_A > .999*FLAGDOUBLE)
	    {
	      dt_A = dtau_A*(theta_A0+theta_a0)/theta_A0;
	      if (dtau_a <= .999*FLAGDOUBLE || dt_A < dt_a)
		{
		  *pChosenPopulation = 0;
		  return dt_A; 
		}
	    }
	  // Recall a coalescence must be possible at least one of these populations,
	  // per this function's definition.
	  *pChosenPopulation = 1;
	  return dt_a;
	}
    }

  // If we get here, then solve for dt_A and/or dt_a
  // by iterating over a series of increasingly better guesses.

  if (s != 0.)
    {
      double new_dt, old_dt, initialGuess_dt, discriminant;
      long nIter, maxIter(100);

      if (dtau_A > .999*FLAGDOUBLE)
	{
	  // It's possible to coalesce in population "A".
	  double dtA_1(FLAGDOUBLE), dtA_2(FLAGDOUBLE); // FLAGDOUBLE < 0

	  if (0.5*s*t_s > 1.0e-04 || 0.5*(-s)*t_s > 1.0e-04)
	    b = SafeProductWithExp(theta_a0,s*t_s);
	  // s>0: 0 < b <= 10000*theta_A0.  s<0: b >= (1.0e-04)*theta_A0.
	  else
	    b = theta_a0*(1. + s*t_s);
	  a = 0.5 * b * s; // sgn(a)=sgn(s). Can't overflow. Can underflow if s almost underflows.
	  b += theta_A0; // b > 0
	  c = -dtau_A*(theta_A0+theta_a0); // c < 0
	  discriminant = b*b - 4.*a*c; // > 0 if s > 0
	  if (a > 0. && 1./a < DBL_BIG)
	    initialGuess_dt = (-b + sqrt(discriminant))/(2.*a);
	  else if (a < 0. && -1./a < DBL_BIG)
	    {
	      if (discriminant >= 0.)
		initialGuess_dt = (-b + sqrt(discriminant))/(2.*a);
	      else
		initialGuess_dt = -c/theta_A0; // heuristic guess
	    }
	  else // s is extremely tiny, equivalent to s=0
	    {
	      initialGuess_dt = dtau_A;
	      maxIter = 0; // prevent either iterative loop from being executed
	    }
	  new_dt = initialGuess_dt;
	  
	  nIter = 0;
	  old_dt = 2.*new_dt; // meaningless initialization value that, when appropriate,
	  // guarantees we'll enter the "while" loop
	  while (0. != new_dt && fabs(new_dt - old_dt)/new_dt > 0.00001 && nIter < maxIter)
	    {
	      old_dt = new_dt;
	      //new_dt = (dtau_A*(theta_A0+theta_a0) - theta_a0*exp(s*t_s)*(exp(s*old_dt)-1.)/s)/theta_A0;
	      new_dt = (-c - (SafeProductWithExp((b-theta_A0)/s,s*old_dt)-(b-theta_A0)/s))/theta_A0;
	      nIter++;
	    }
	  // note that if new_dt erroneously goes negative, the loop will terminate
	  dtA_1 = new_dt;
	  if (new_dt > 0. && (nIter < maxIter || 0 == maxIter))
	    {
	      maxIter = 0; // found a solution; no need to use the other formula
	      new_dt = FLAGDOUBLE; // bogus negative value
	    }
	  else
	    {
	      // failed to find a solution; use the other formula
	      dtA_1 = FLAGDOUBLE; // bogus negative value
	      new_dt = initialGuess_dt; // precomputed initial guess
	    }
	  
	  nIter = 0;
	  old_dt = 2.*new_dt; // just to ensure the initial "while" condition is met, when appropriate
	  while (0. != new_dt && fabs(new_dt - old_dt)/new_dt > 0.00001 && nIter < maxIter)
	    {
	      old_dt = new_dt;
	      x = s*(-c - theta_A0*old_dt)/(b - theta_A0);
	      if ((x > 0.00001 && s > 0.) ||
		  (x < -0.00001 && x > -(1. - numeric_limits<double>::epsilon()) && s < 0.))
		new_dt = (1./s)*log(1. + x);
	      else if ((x > 0. && s > 0.) ||
		       (x >= -0.00001 && x < 0. && s < 0.))
		new_dt = x/s; // because log(1+x) = x + O(x^2)
	      else
		new_dt = FLAGDOUBLE; // negative value--this will terminate the loop
	      nIter++;
	    }
	  // note that if new_dt erroneously goes negative, the loop will terminate
	  dtA_2 = new_dt;
	  
	  if (dtA_1 > 0.)
	    dt_A = dtA_1; // equation 1 converged, or s is essentially zero
	  else if (dtA_2 > 0. && nIter < maxIter)
	    dt_A = dtA_2; // equation 2 converged
	  else
	    dt_A = MAX_LENGTH; // neither equation converged, so ignore their results
	}
	  
      if (dtau_a > .999*FLAGDOUBLE)
	{
	  // It's possible to coalesce in population "a".
	  double dta_1(FLAGDOUBLE), dta_2(FLAGDOUBLE); // FLAGDOUBLE < 0

	  maxIter = 100;

	  if (0.5*s*t_s > 1.0e-04 || 0.5*(-s)*t_s > 1.0e-04)
	    {
	      // If we have just completed computing dt_A, re-use one computation.
	      if (dtau_A > .999*FLAGDOUBLE)
		b = theta_A0*theta_a0/(b-theta_A0); // b = SafeProductWithExp(theta_A0, -s*t_s)
	      else
		b = SafeProductWithExp(theta_A0, -s*t_s);
	      // s>0: b >= (1.0e-04)*theta_a0.  s<0: 0 < b <= 10000*theta_a0.
	    }
	  else
	    b = theta_A0*(1. - s*t_s);
	  a = -0.5 * b * s; // sgn(a) = -sgn(s). Can't overflow. Can underflow if s almost underflows.
	  b += theta_a0; // b > 0
	  c = -dtau_a*(theta_A0+theta_a0); // c < 0
	  discriminant = b*b - 4.*a*c; // > 0 if s < 0
	  if (a > 0. && 1./a < DBL_BIG)
	    initialGuess_dt = (-b + sqrt(discriminant))/(2.*a);
	  else if (a < 0. && -1./a < DBL_BIG)
	    {
	      if (discriminant >= 0.)
		initialGuess_dt = (-b + sqrt(discriminant))/(2.*a);
	      else
		initialGuess_dt = -c/theta_a0; // heuristic guess
	    }
	  else // s is extremely tiny, equivalent to s=0
	    {
	      initialGuess_dt = dtau_a;
	      maxIter = 0; // prevent either iterative loop from being executed
	    }
	  new_dt = initialGuess_dt;

	  nIter = 0;
	  old_dt = 2.*new_dt; // just to ensure the initial "while" condition is met, when appropriate
	  while (0. != new_dt && fabs(new_dt - old_dt)/new_dt > 0.00001 && nIter < maxIter)
	    {
	      old_dt = new_dt;
	      //new_dt = (dtau_a*(theta_A0+theta_a0) + theta_A0*exp(-s*starttime)*(exp(-s*old_dt)-1.)/s)/theta_a0;
	      new_dt = (-c + (SafeProductWithExp((b-theta_a0)/s,-s*old_dt)-(b-theta_a0)/s))/theta_a0;
	      nIter++;
	    }
	  // note that if new_dt erroneously goes negative, the loop will terminate
	  dta_1 = new_dt;
	  if (new_dt > 0. && (nIter < maxIter || 0 == maxIter))
	    {
	      maxIter = 0; // found a solution; no need to use the other formula
	      new_dt = FLAGDOUBLE; // bogus negative value
	    }
	  else
	    {
	      // failed to find a solution; use the other formula
	      dta_1 = FLAGDOUBLE; // bogus negative value
	      new_dt = initialGuess_dt; // precomputed initial guess
	    }
	  
	  nIter = 0;
	  old_dt = 2.*new_dt; // just to ensure the initial "while" condition is met, when appropriate
	  while (0. != new_dt && fabs(new_dt - old_dt)/new_dt > 0.00001 && nIter < maxIter)
	    {
	      old_dt = new_dt;
	      x = s*(-c - theta_a0*old_dt)/(b - theta_a0);
	      if ((x > 0.00001 && x < (1. - numeric_limits<double>::epsilon()) && s > 0.) ||
		  (x < -0.00001 && s < 0.))
		new_dt = (1./(-s))*log(1. - x);
	      else if ((x > 0. && s > 0.) ||
		       (x >= -0.00001 && x < 0. && s < 0.))
		new_dt = x/s; // because log(1-x) = -x - O(x^2)
	      else
		new_dt = FLAGDOUBLE; // negative value--this will terminate the loop
	      nIter++;
	    }
	  // note that if new_dt erroneously goes negative, the loop will terminate
	  dta_2 = new_dt;
	  
	  if (dta_1 > 0.)
	    dt_a = dta_1; // equation 1 converged, or s is essentially zero
	  else if (dta_2 > 0. && nIter < maxIter)
	    dt_a = dta_2; // equation 2 converged
	  else
	    dt_a = MAX_LENGTH; // neither equation converged, so ignore their results
	}
    } // end of the iterative solution code

  else // s == 0, and "magic time" is actually "real time"
    {
      dt_A = dtau_A;
      dt_a = dtau_a;
    }

  if ((dt_A >= 0. && dt_A < minimum_possible_dt) || 
      (dt_a >= 0. && dt_a < minimum_possible_dt))
    {
      string msg = "Bad time length (" + ToString(min(dt_A,dt_a));
      msg += ") proposed in LogisticSelectionPickTime().";
      tinypopulation_error e(msg);
      throw e;
    }
  if (dt_a < 0.) // FLAGDOUBLE
    {
      *pChosenPopulation = (dt_A < 0.) ? FLAGLONG : 0;
      return dt_A;
    }
  if (dt_A < 0.) // FLAGDOUBLE
    {
      *pChosenPopulation = 1;
      return dt_a;
    }
  // If we get here, both interval lengths are valid.
  if (dt_A < dt_a)
    {
      *pChosenPopulation = 0;
      return dt_A;
    }
  *pChosenPopulation = 1;
  return dt_a;

} /* LogisticSelectionPickTime() */


//____________________________________________________________________________
//____________________________________________________________________________

InactiveCoal::InactiveCoal(const ForceSummary& fs) 
  : CoalEvent(fs, false),
    m_inv2Theta()
{
} /* InactiveCoal copy constructor */

//____________________________________________________________________________

Event* InactiveCoal::Clone() const
{
  InactiveCoal* event = new InactiveCoal(*this);
  return event;

} /* InactiveCoal::Clone */

//____________________________________________________________________________

void InactiveCoal::InstallParameters(const ForceParameters& starts)
{
  CoalEvent::InstallParameters(starts);

  // We store 2/Theta for speed
  m_inv2Theta = starts.GetRegionalThetas();

  // store 2/Theta
  std::transform(m_inv2Theta.begin(), m_inv2Theta.end(),
		  m_inv2Theta.begin(),
		  std::bind1st(std::divides<double>(),2.0));

} /* InstallParameters */

//____________________________________________________________________________

void InactiveCoal::InstallThetas(const DoubleVec1d& thetas)
{
  Event::InstallThetas(thetas);

  m_inv2Theta = thetas;
  // store 2/Theta
  std::transform(m_inv2Theta.begin(), m_inv2Theta.end(),
		  m_inv2Theta.begin(),
		  std::bind1st(std::divides<double>(),2.0));

} /* InstallThetas */

//____________________________________________________________________________

double InactiveCoal::PickTime(double)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  // Note:  The expectation value of this "delta t" is theta/(j*k),
  // where j and k (the numbers of inactive and active lineages) and theta
  // correspond to the population which yields the smallest "delta t."

  map<double, long> times;
  double newtime = 0.0;
  long i;

  for (i = 0; i < m_nxparts; ++i) // loop over populations
    {
      if (ar->m_xactives[i] > 0 && ar->m_xinactives[i] > 0)
	{
	  // denominator contains j*k, inactives*actives,
	  // instead of k*(k-1)
	  newtime = - log (ar->randomSource->Float()) /
	    (m_inv2Theta[i] * ar->m_xactives[i] * ar->m_xinactives[i]);
	  times.insert(make_pair(newtime,i));
	}
    }

  if (times.empty())
    {
      // no event is possible
      m_chosenxpart = FLAGLONG;
      return FLAGDOUBLE;
    }
  else
    {
      // the first map entry is the smallest, and thus chosen, time
      map<double, long>::const_iterator mapit = times.begin();
      m_chosenxpart = (*mapit).second;
      assert ((*mapit).first >= 0.0);
      return (*mapit).first;
    }

} /* InactiveCoal::PickTime */

//____________________________________________________________________________
//____________________________________________________________________________

InactiveGrowCoal::InactiveGrowCoal(const ForceSummary& fs) 
 : CoalEvent(fs, false)
{
} /* InactiveGrowCoal constructor */

//____________________________________________________________________________

Event* InactiveGrowCoal::Clone() const
{
  InactiveGrowCoal* event = new InactiveGrowCoal(*this);
  return event;

} /* InactiveGrowCoal::Clone */

//____________________________________________________________________________

double InactiveGrowCoal::PickTime(double starttime)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  // Note:  The expectation value of this "delta t" is:
  //                           (1/g)*ExpE1(j*k*exp(g*starttime)/(2*g*theta)),
  // where g, theta, j, and k are the growth rate, theta, and numbers of
  // inactive and active lineages for the population which yields the
  // smallest "delta t."  (Note also the factor of 2, absent from ActiveGrowCoal.)
  // For details on the function ExpE1(), see mathx.cpp.

  map<double, long> times;
  double newtime, magicstart;
  long i;

  for (i = 0; i < m_nxparts; ++i) // loop over populations
    {
      if (ar->m_xactives[i] > 0 && ar->m_xinactives[i] > 0)
	{
	  // first do calculation in "magic time"
	  // Numerator contains j*k, inactives*actives,
	  // instead of k*(k-1)
	  // Also, denominator contains a factor of 2, unlike ActiveGrowCoal.
	  newtime = - log(ar->randomSource->Float()) /
	    ((2.0 / m_thetas[i]) * ar->m_xactives[i] * ar->m_xinactives[i]);

	  // then convert to "real time"
	  if (m_growths[i] != 0)
	    {
	      // convert starttime to magical time
	      magicstart = -(1.0 - exp(m_growths[i] * starttime)) / m_growths[i];
	      // add starttime to displacement
	      newtime += magicstart;
	      if (1.0 + m_growths[i] * newtime > 0.0)
		{
		  // convert result to real time
		  newtime = log(1.0 + m_growths[i] * newtime)/m_growths[i];
		  // convert back to displacement
		  newtime -= starttime;
		  // guard against underflow
		  if (newtime < DBL_EPSILON)
		    {
		      tinypopulation_error e("bad time proposed in Event::PickTime");
		      throw e;
		    }
		}
	      else
		newtime = MAX_LENGTH; // make this interval length
	                              // unlikely to win the race
	    }
	  
	  // insert into map (for sorting)
	  times.insert(make_pair(newtime,i));
	}
    }

  if (times.empty())
    {
      // no event is possible
      m_chosenxpart = FLAGLONG;
      return FLAGDOUBLE;
    }
  else
    {
      // the first map entry is the smallest, and thus chosen, time
      map<double, long>::const_iterator mapit = times.begin();
      m_chosenxpart = (*mapit).second;
      assert ((*mapit).first >= 0.0);
      return (*mapit).first;
    }

} /* InactiveGrowCoal::PickTime */


//____________________________________________________________________________
//____________________________________________________________________________

InactiveLogisticSelectionCoal::InactiveLogisticSelectionCoal(const ForceSummary& fs) 
  : CoalEvent(fs, false), m_selectionCoefficient(0.)
{
} /* InactiveLogisticSelectionCoal constructor */

//____________________________________________________________________________

Event* InactiveLogisticSelectionCoal::Clone() const
{
  InactiveLogisticSelectionCoal* event = new InactiveLogisticSelectionCoal(*this);
  return event;

} /* InactiveLogisticSelectionCoal::Clone */

//____________________________________________________________________________

void InactiveLogisticSelectionCoal::InstallParameters(const ForceParameters& starts)
{
  CoalEvent::InstallParameters(starts);
  m_selectionCoefficient = starts.GetLogisticSelectionCoefficient()[0];
} /* InstallParameters */

//____________________________________________________________________________

double InactiveLogisticSelectionCoal::PickTime(double starttime)
{
  if (2 != m_nxparts)
    {
      string msg = "InactiveLogisticSelectionCoal::PickTime() called with m_nxparts = ";
      msg += ToString(m_nxparts);
      msg += ".  m_nxparts must equal 2, reflecting one population with the major ";
      msg += "allele and one population with the minor allele.";
      throw implementation_error(msg);
    }

  if (0. == m_thetas[0] || 0. == m_thetas[1])
    {
      string msg = "InactiveLogisticSelectionCoal::PickTime() received an invalid Theta ";
      msg += "of 0.0.";
      throw impossible_error(msg);
    }

  if (!((ar->m_xactives[0] >= 1 && ar->m_xinactives[0] >= 1) ||
	(ar->m_xactives[1] >= 1 && ar->m_xinactives[1] >= 1)))
    {
      // no event is possible
      m_chosenxpart = FLAGLONG;
      return FLAGDOUBLE;
    }

  // First, compute the interval lengths in "magic time"--drawn from an exponential
  // distribution assuming constant size for population "A" and for population "a".
  double dtau_A(FLAGDOUBLE), dtau_a(FLAGDOUBLE); // important:  these are < 0

  if (ar->m_xactives[0] > 0 && ar->m_xinactives[0] > 0)
    dtau_A = -log(ar->randomSource->Float()) / 
      (2.*ar->m_xactives[0]*ar->m_xinactives[0]/m_thetas[0]);

  if (ar->m_xactives[1] > 0 && ar->m_xinactives[1] > 0) 
    dtau_a = -log(ar->randomSource->Float()) / 
      (2.*ar->m_xactives[1]*ar->m_xinactives[1]/m_thetas[1]); 

  return LogisticSelectionPickTime(m_thetas[0],m_thetas[1],m_selectionCoefficient,
				   starttime,dtau_A,dtau_a,&m_chosenxpart);

} /* InactiveLogisticSelectionCoal::PickTime */

//____________________________________________________________________________
//____________________________________________________________________________

PartitionEvent::PartitionEvent(const ForceSummary& fs)
	: Event(fs)
{
} /* PartitionEvent ctor */

//____________________________________________________________________________
//____________________________________________________________________________

MigEvent::MigEvent(const ForceSummary& fs)
	: PartitionEvent(fs),
	m_rescaledMigRates(),
	m_immigrationRates(),
	m_frompop(FLAGLONG),
	m_topop(FLAGLONG)
{
        m_nparts = registry.GetDataPack().GetNPartitionsByForceType(force_MIG);
	m_forcetype = force_MIG;
        m_maxEvents = fs.GetMaxEvents(force_MIG);
        m_pindex = fs.GetPartIndex(force_MIG);
} /* MigEvent ctor */

//____________________________________________________________________________

Event* MigEvent::Clone() const
{
  MigEvent* event = new MigEvent(*this);
  return event;

} /* MigEvent::Clone */

//____________________________________________________________________________

void MigEvent::InstallParameters(const ForceParameters& starts)
{
  Event::InstallParameters(starts);

  // pre-compute migration rate tables
  ComputeCumulativeRates(starts);

} /* InstallParameters */

//____________________________________________________________________________

void MigEvent::ComputeCumulativeRates(const ForceParameters& starts)
{
  vector<vector<double> > migRates = starts.GetRegional2dRates(force_MIG);
  vector<double> indRate;

  m_rescaledMigRates.clear();
  m_immigrationRates.clear();

  double totalMig;
  long i, j;

  // computes cumulative migration rates in "m_rescaledMigRates"
  // and total immigration into a population in "m_immigrationRates"

  for (i = 0; i < m_nparts; ++i) {
    totalMig = 0.0;
    indRate.clear();
    for (j = 0; j < m_nparts; ++j) {
       totalMig += migRates[i][j];
       indRate.push_back(totalMig);     // cumulative rate
    }

    // normalize cumulative rates to total
    if (totalMig > 0) {
      for (j = 0; j < m_nparts; ++j) {
        indRate[j] /= totalMig;   
      }
    }

    m_rescaledMigRates.push_back(indRate);      // cumulative rates
    m_immigrationRates.push_back(totalMig);     // total immigration
  }

} /* ComputeCumulativeRates */

//____________________________________________________________________________

double MigEvent::PickTime(double)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  // Note:  The expectation value of this "delta t" is 1/(M*k), where M and k
  // are the immigration rate and number of active lineages of the population
  // which yields the smallest "delta t."

  map<double, long> times;
  double newtime;
  long i;

  for (i = 0; i < m_nparts; ++i)
    {
      if (ar->m_pactives[m_pindex][i] > 0)
	{
	  newtime = -log (ar->randomSource->Float()) /
	    (m_immigrationRates[i] * ar->m_pactives[m_pindex][i]);
	  times.insert(make_pair(newtime, i));
	}  
    }

  if (times.empty())
    {
      // no event is possible
      m_frompop = FLAGLONG;
      m_topop = FLAGLONG;
      return FLAGDOUBLE;
    }
  else
    {
      // the first map entry is the smallest, and thus chosen, time
      map<double, long>::const_iterator mapit = times.begin();
      m_frompop = (*mapit).second;
      double rn = ar->randomSource->Float();
      for (m_topop = 0; m_rescaledMigRates[m_frompop][m_topop] < rn; m_topop++)
	{};
      assert ((*mapit).first >= 0.0);
      return (*mapit).first;
    }

} /* MigEvent::PickTime */

//____________________________________________________________________________

void MigEvent::DoEvent(double eventT)
{
  assert(m_frompop >= 0 && m_topop >= 0);

  // Pick an active branch from the population at random.
  double rn = ar->randomSource->Float();
  Branch_ptr active = ar->m_activelist.RemovePartitionBranch(force_MIG, m_frompop, rn);
  FinishEvent(eventT, active, m_topop);
} /* DoEvent */

void MigEvent::FinishEvent(double eventT, Branch_ptr active, long topop)
{

  Branch_ptr newbranch = ar->GetTree()->Migrate(eventT, topop, m_maxEvents, active);

  ar->m_activelist.Append(newbranch);

} /* FinishEvent */    

//____________________________________________________________________________
//____________________________________________________________________________

DiseaseEvent::DiseaseEvent(const ForceSummary& fs)
	: PartitionEvent(fs),
	m_probhere(),
	m_murateto(),
	m_startdis(FLAGLONG),
	m_enddis(FLAGLONG)
{
 m_nparts = registry.GetDataPack().GetNPartitionsByForceType(force_DISEASE);
	m_forcetype = force_DISEASE;
        m_maxEvents = fs.GetMaxEvents(force_DISEASE);
        m_pindex = fs.GetPartIndex(force_DISEASE);
} /* DiseaseEvent ctor */

//____________________________________________________________________________

Event* DiseaseEvent::Clone() const
{
DiseaseEvent* event = new DiseaseEvent(*this);
return event;

} /* DiseaseEvent::Clone */

//____________________________________________________________________________

double DiseaseEvent::PickTime(double)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  // Note:  The expectation value of "delta t" is 1/(mu*k), where mu and k
  // are the mutation rate to the disease state and the number of active lineages
  // of the population which yields the smallest value of "delta t."

  map<double, long> times;
  double newtime;
  long i;

  for (i = 0; i < m_nparts; ++i)
    {
      if (ar->m_pactives[m_pindex][i] > 0)
	{
	  newtime = -log (ar->randomSource->Float()) /
	    (m_murateto[i] * ar->m_pactives[m_pindex][i]);
	  times.insert(make_pair(newtime, i));
	}  
    }

  if (times.empty())
    {
      // no event is possible
      m_startdis = FLAGLONG;
      m_enddis = FLAGLONG;
      return FLAGDOUBLE;
    }
  else
    {
      // the first map entry is the smallest, and thus chosen, time
      map<double, long>::const_iterator mapit = times.begin();
      m_startdis = (*mapit).second;
      double rn = ar->randomSource->Float();
      for (m_enddis = 0; m_probhere[m_startdis][m_enddis] < rn;
	   m_enddis++)
	{};
      assert ((*mapit).first >= 0.0);
      return (*mapit).first;
    }

} /* DiseaseEvent::PickTime */

//____________________________________________________________________________

void DiseaseEvent::DoEvent(double eventT)
{
  assert(m_startdis >= 0 && m_enddis >= 0);

  // Pick an active branch from the disease category at random.
  double rn = ar->randomSource->Float();
  Branch_ptr active = ar->m_activelist.RemovePartitionBranch(force_DISEASE, m_startdis, rn);
  FinishEvent(eventT, active, m_enddis);
} /* DoEvent */

void DiseaseEvent::FinishEvent(double eventT, Branch_ptr active, long enddis)
{
  Branch_ptr newbranch = ar->GetTree()->DiseaseMutate(eventT,enddis,m_maxEvents,active);
  ar->m_activelist.Append(newbranch);
} /* DiseaseEvent::FinishEvent */

//____________________________________________________________________________

void DiseaseEvent::InstallParameters(const ForceParameters& starts)
{
  Event::InstallParameters(starts);
  ComputeCumulativeRates(starts);

} /* DiseaseEvent::InstallParameters */

//____________________________________________________________________________

void DiseaseEvent::ComputeCumulativeRates(const ForceParameters& starts)
{
  vector<vector<double> > murates = starts.GetRegional2dRates(force_DISEASE);
  vector<double> indRate;

  m_probhere.clear();
  m_murateto.clear();

  double totaldisease;
  long i, j;

  // computes chance of having a mutation in "probhere"
  // and total rate of change to a disease state in "murateto"


  for (i = 0; i < m_nparts; ++i) {
    totaldisease = 0.0;
    indRate.clear();
    for (j = 0; j < m_nparts; ++j) {
       totaldisease += murates[i][j];
       indRate.push_back(totaldisease);     // cumulative rate
    }

    // normalize cumulative rates to total
    if (totaldisease > 0) {
      for (j = 0; j < registry.GetDataPack().GetNPartitionsByForceType(force_DISEASE); ++j) {
        indRate[j] /= totaldisease;   
      }
    }

    m_probhere.push_back(indRate);      // cumulative rates
    m_murateto.push_back(totaldisease); // total immigration
  }

} /* ComputeCumulativeRates */



//____________________________________________________________________________

DiseaseLogSelEvent::DiseaseLogSelEvent(const ForceSummary& fs)
	: DiseaseEvent(fs),
	  m_mu_into_A_from_a(0.),
	  m_mu_into_a_from_A(0.),
	  m_selectionCoefficient(0.)
{
} /* DiseaseLogSelEvent ctor */

//____________________________________________________________________________

Event* DiseaseLogSelEvent::Clone() const
{
  DiseaseLogSelEvent* event = new DiseaseLogSelEvent(*this);
  return event;

} /* DiseaseLogSelEvent::Clone */
//____________________________________________________________________________

void DiseaseLogSelEvent::InstallParameters(const ForceParameters& starts)
{
  Event::InstallParameters(starts);
  vector<vector<double> > murates = starts.GetRegional2dRates(force_DISEASE);
  if (2 != murates[0].size() || 2 != murates[1].size() || 0 != murates[0][0] ||
      0 != murates[1][1] || 0 >= murates[0][1] || 0 >= murates[1][0])
    throw implementation_error("DiseaseLogSelEvent::InstallParameters():  bad murates matrix");

  m_mu_into_A_from_a = murates[0][1];
  m_mu_into_a_from_A = murates[1][0];
  m_selectionCoefficient = starts.GetLogisticSelectionCoefficient()[0]; // a one-element vector

} /* DiseaseLogSelEvent::InstallParameters */

//____________________________________________________________________________

double DiseaseLogSelEvent::PickTime(double t_s)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  double theta_A0(m_thetas[0]), theta_a0(m_thetas[1]), s(m_selectionCoefficient),
    dtau_A(FLAGDOUBLE), dtau_a(FLAGDOUBLE), dt_A(FLAGDOUBLE), dt_a(FLAGDOUBLE), argOfLog;

  if (ar->m_pactives[m_pindex][0] > 0)
    {
      dtau_A = -log(ar->randomSource->Float()) /
	(m_mu_into_A_from_a * ar->m_pactives[m_pindex][0]);
      if (0. == s)
	dt_A = dtau_A;
      else
	{
	  argOfLog = 1. + SafeProductWithExp((dtau_A*s*theta_A0/theta_a0),-s*t_s);
	  if (argOfLog > 0.)
	    dt_A = log(argOfLog) / s;
	}
    }
  if (ar->m_pactives[m_pindex][1] > 0)
    {
      dtau_a = -log(ar->randomSource->Float()) /
	(m_mu_into_a_from_A * ar->m_pactives[m_pindex][1]);
      if (0. == s)
	dt_a = dtau_a;
      else
	{
	  argOfLog = 1. + SafeProductWithExp((dtau_a*(-s)*theta_a0/theta_A0),s*t_s);
	  if (argOfLog > 0.)
	    dt_a = log(argOfLog) / (-s);
	}
    }

  if (dt_a <= 0.)
    {
      if (dt_A <= 0.)
	{
	  // no event is possible
	  m_startdis = FLAGLONG;
	  m_enddis = FLAGLONG;
	  return FLAGDOUBLE;
	}
      m_startdis = 0; // going backward in time, from tip to root
      m_enddis = 1;
      return dt_A;
    }

  // If we get here, dt_a > 0.
  if (dt_A <= 0. || dt_A > dt_a)
    {
      m_startdis = 1;
      m_enddis = 0;
      return dt_a;
    }

  // If we get here, 0 < dt_A <= dt_a.
  m_startdis = 0;
  m_enddis = 1;
  return dt_A;

} /* DiseaseLogSelEvent::PickTime */

//____________________________________________________________________________
//____________________________________________________________________________

ActiveRec::ActiveRec(const ForceSummary& fs)
	: Event(fs),
	m_recrate(defaults::recombinationRate),
	m_onPartitionForces()
{
        m_maxEvents = fs.GetMaxEvents(force_REC);
        m_pindex = FLAGLONG; // we don't use partitions...yet!
} /* ActiveRec ctor */

//____________________________________________________________________________

Event* ActiveRec::Clone() const
{
  ActiveRec* event = new ActiveRec(*this);
  return event;
} /* ActiveRec::Clone */

//____________________________________________________________________________

void ActiveRec::InstallParameters(const ForceParameters& starts)
{
  Event::InstallParameters(starts);

  assert(starts.GetRecRates().size() == 1);  // only one rec rate!
  m_recrate = starts.GetRecRates()[0];

} /* InstallParameters */

//____________________________________________________________________________

double ActiveRec::PickTime(double)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  // Note:  The expectation value of "delta t" is 1/(r*nA), where r and nA are the
  // recombination rate and number of active links for the population which yields
  // the smallest value of "delta t."

  RecTree* tr = dynamic_cast<RecTree*>(ar->GetTree());
  assert(!(tr->ActiveLinks() > 0 && ar->ActiveSize() == 0));  
  // active sites w/o lineages
  if (tr->ActiveLinks() > 0)
    {
    double retval = -log(ar->randomSource->Float()) / (m_recrate * tr->ActiveLinks());
      assert (retval >= 0.0);
      return retval;
    }
  else
    return FLAGDOUBLE;

} /* ActiveRec::PickTime */

//____________________________________________________________________________

void ActiveRec::DoEvent(double eventT)
{
  RecTree* tr = dynamic_cast<RecTree*>(ar->GetTree());

  // Pick an active branch and recombination site at random.
  Branch_ptr active;
  long rn = ar->randomSource->Long(tr->ActiveLinks());
  Branchiter brit;
  for (brit = ar->m_activelist.Begin(); ; ++brit)
  {
    active = *brit;
    long n = active->m_range.ActiveLinks();
    if (n > rn) break;   // found it!
    rn -= n;
  }
  long recsite = active->m_range.GetFirstNonFCActiveSite() + rn;
  ar->m_activelist.Remove(brit);

  //Pick a partition at random if we have a local partition force (i.e.
  // Disease) on and active at this region.
  FPartMap fparts;
  if (!m_onPartitionForces.empty()) {
    for(vector<force_type>::iterator spart = m_onPartitionForces.begin();
        spart != m_onPartitionForces.end(); ++spart) {
      if (*spart != force_MIG) {
        DoubleVec1d allSizes = m_CalcSizeAtTime->
          PartitionSizeAt(*spart,m_allparams,eventT);
        long randomPart = ChooseRandomFromWeights(allSizes);
        fparts.insert(make_pair(*spart, randomPart));
      }
    }
  }
  
  FinishEvent(eventT, active, recsite, fparts);
} /* DoEvent */

branchpair ActiveRec::FinishEvent(double eventT, Branch_ptr active, long recsite,
                            FPartMap fparts)
{
  RecTree* tr = dynamic_cast<RecTree*>(ar->GetTree());

  branchpair newbranches = 
     tr->RecombineActive(eventT, m_maxEvents, fparts, active, recsite); 

  ar->m_activelist.Append(newbranches.first);
  ar->m_activelist.Append(newbranches.second);
  assert(newbranches.first->PartitionsConsistentWith(active));
  assert(newbranches.second->PartitionsConsistentWith(active));
  return newbranches;

} /* FinishEvent */
    
//____________________________________________________________________________
//____________________________________________________________________________

InactiveRec::InactiveRec(const ForceSummary& fs)
	: Event(fs),
          m_recrate(defaults::recombinationRate)
{
          m_maxEvents = fs.GetMaxEvents(force_REC);
          m_pindex = FLAGLONG; // we don't use partitions...yet!
} /* InactiveRec ctor */

//____________________________________________________________________________

Event* InactiveRec::Clone() const
{
  InactiveRec* event = new InactiveRec(*this);
  return event;

} /* InactiveRec::Clone */

//____________________________________________________________________________

void InactiveRec::InstallParameters(const ForceParameters& starts)
{
  Event::InstallParameters(starts);

  assert(starts.GetRecRates().size() == 1); // only one rec rate!
  m_recrate = starts.GetRecRates()[0];

} /* InstallParameters */

//____________________________________________________________________________

double InactiveRec::PickTime(double)
{
  // Computes a displacement, a.k.a. "delta t" -- the length of the time interval,
  // not the timestamp for the end of the interval.

  // Note:  The expectation value of "delta t" is 1/(r*nO), where r and nO are the
  // recombination rate and number of open links of the population which yields
  // the smallest value of "delta t."

  RecTree* tr = dynamic_cast<RecTree*>(ar->GetTree());
  long links = tr->OpenLinks();
  if (links > 0)
    {
      double retval = -log(ar->randomSource->Float()) / (m_recrate * links);
      assert(retval >= 0.0);
      return retval;
    }
  else
    return FLAGDOUBLE;

} /* InactiveRec::PickTime */

//____________________________________________________________________________

void InactiveRec::DoEvent(double eventT)
{
  RecTree* tr = dynamic_cast<RecTree*>(ar->GetTree());

  //Pick a partition at random if we have a local partition force (i.e.
  // Disease) on and active at this region.
  FPartMap fparts;
  if (!m_onPartitionForces.empty()) {
    for(vector<force_type>::iterator spart = m_onPartitionForces.begin();
        spart != m_onPartitionForces.end(); ++spart) {
      if (*spart != force_MIG) {
        DoubleVec1d allSizes = m_CalcSizeAtTime->
          PartitionSizeAt(*spart,m_allparams,eventT);
        long randomPart = ChooseRandomFromWeights(allSizes);
        fparts.insert(make_pair(*spart, randomPart));
      }
    }
  }

  // Pick an open branch and recombination site at random.
  Branch_ptr branch;
  long rn = ar->randomSource->Long(tr->OpenLinks());
  Branchiter brit;
  for (brit = ar->m_inactivelist.Begin(); ; ++brit)
  {
    assert (brit != ar->m_inactivelist.End());
    branch = *brit;
    long n = branch->m_range.NewActiveLinks();
    if (n > rn) break;      // found it!
    rn -= n;
  }

  // at this point "rn" contains the index, counting from 0, of the
  // desired site on branch pBranch

  assert(branch != Branch::NONBRANCH);  // we didn't find a branch?

  ar->m_inactivelist.Remove(brit);

  // Find the recombination site.
  long recsite(FLAGLONG);
  rangeset openlinks = branch->m_range.GetNewActiveLinks();
  rangeset::iterator rit;
  for(rit = openlinks.begin(); rit != openlinks.end(); ++rit) {
     long s1 = rit->first;
     long s2 = rit->second;
     recsite = s1 + rn;
     if (recsite < s2) break;   // found it!
     rn -= (s2 - s1);
  }

  assert(recsite != FLAGLONG); // failed to find a recombination site!
  branchpair branches = 
     tr->RecombineInactive(eventT, m_maxEvents, fparts, branch, recsite);

  ar->m_inactivelist.Collate(branches.first);
  ar->m_activelist.Append(branches.second);
  assert(branches.first->PartitionsConsistentWith(branch));
  assert(branches.second->PartitionsConsistentWith(branch));
} /* DoEvent */
    
//_______________________________________________

string ToString(const Event &e)
{
  switch (e.Type())
    {
    case activeCoalEvent:
      return "activeCoalEvent";
      break;
    case activeGrowCoalEvent:
      return "activeGrowCoalEvent";
      break;
    case activeLogisticSelectionCoalEvent:
      return "activeLogisticSelectionEvent";
      break;
    case inactiveCoalEvent:
      return "inactiveCoalEvent";
      break;
    case inactiveGrowCoalEvent:
      return "inactiveGrowCoalEvent";
      break;
    case inactiveLogisticSelectionCoalEvent:
      return "inactiveLogisticSelectionCoalEvent";
      break;
    case migEvent:
      return "migEvent";
      break;
    case diseaseEvent:
      return "diseaseEvent";
      break;
    case diseaseLogSelEvent:
      return "diseaseLogSelEvent";
      break;
    case activeRecEvent:
      return "activeRecEvent";
      break;
    case inactiveRecEvent:
      return "inactiveRecEvent";
      break;
    case activeStairStickCoalEvent:
      return "activeStairStickCoalEvent";
      break;
    case inactiveStairStickCoalEvent:
      return "inactiveStairStickCoalEvent";
      break;
    }
  assert(false);
  return "";
}

