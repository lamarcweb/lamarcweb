// $Id: timesize.cpp,v 1.7 2007/09/24 21:43:09 erynes Exp $

/* 
   Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#include "force.h"
#include "mathx.h"    // for SafeProductWithExp()
#include "timesize.h"


#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;


DoubleVec1d GrowTimeSize::PartitionSizeAt(force_type partforce, 
   const ForceParameters& fp, double etime) const
{
  DoubleVec1d thetas(fp.GetRegionalThetas()),growths(fp.GetGrowthRates());
  return dynamic_cast<PartitionForce*>(*registry.GetForceSummary().
     GetForceByTag(partforce))->SumXPartsToParts(thetas,growths,etime);
} // GrowTimeSize::PartitionSizeAt

//___________________________________________________________

DoubleVec1d GrowTimeSize::SizeAt(const ForceParameters& fp, double etime) const
{
  DoubleVec1d thetas(fp.GetRegionalThetas()),growths(fp.GetGrowthRates());
  assert(thetas.size() == growths.size());
  DoubleVec1d newthetas(thetas.size());
  unsigned long param;
  for(param = 0; param < thetas.size(); ++param) {
     newthetas[param] = SafeProductWithExp(thetas[param],-growths[param]*etime);
  }

  return newthetas;
} // GrowTimeSize::SizeAt

//___________________________________________________________
//___________________________________________________________

DoubleVec1d StaticTimeSize::PartitionSizeAt(force_type partforce, 
   const ForceParameters& fp, double etime) const
{
  DoubleVec1d thetas(fp.GetRegionalThetas());
  return dynamic_cast<PartitionForce*>(*registry.GetForceSummary().
		      GetForceByTag(partforce))->SumXPartsToParts(thetas);
} // StaticTimeSize::PartitionSizeAt

//___________________________________________________________

DoubleVec1d StaticTimeSize::SizeAt(const ForceParameters& fp, double etime)
   const
{
  DoubleVec1d thetas(fp.GetRegionalThetas());
  return thetas;
} /* StaticTimeSize::SizeAt */

//___________________________________________________________
//___________________________________________________________

DoubleVec1d LogisticSelectionTimeSize::SizeAt(const ForceParameters& fp,
   double t) const
{
  DoubleVec1d thetas(fp.GetRegionalThetas()),
     selcoeffs(fp.GetLogisticSelectionCoefficient());

  if (2 != thetas.size())
    {
      string msg = "LogisticSelectionTimeSize::SizeAt(), needed to receive ";
      msg += "two thetas, one for each allele, but instead received ";
      msg += ToString(thetas.size());
      msg + " thetas.";
      throw implementation_error(msg);
    }

  if (1 != selcoeffs.size())
    {
      string msg = "LogisticSelectionTimeSize::SizeAt(), needed to receive ";
      msg += "1 selection coefficient, but instead received ";
      msg += ToString(selcoeffs.size());
      msg + " coefficients.";
      throw implementation_error(msg);
    }

  DoubleVec1d newthetas(2);
  double t_term = SafeProductWithExp(thetas[1], selcoeffs[0]*t);
  newthetas[0] = (thetas[0]+thetas[1])/(thetas[0] + t_term);
  newthetas[1] = newthetas[0] * t_term;
  newthetas[0] = newthetas[0] * thetas[0];

  return newthetas;
} // LogisticSelectionTimeSize::SizeAt

//___________________________________________________________

DoubleVec1d LogisticSelectionTimeSize::PartitionSizeAt(force_type partforce, 
   const ForceParameters& fp, double etime) const
{
  DoubleVec1d emptyvec;
  throw implementation_error("LogisticSelectionTimeSize::PartitionSizeAt() was called; shouldn\'t be?");
  return emptyvec;
} // LogisticSelectionTimeSize::PartitionSizeAt

