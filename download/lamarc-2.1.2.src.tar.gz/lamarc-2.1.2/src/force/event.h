//$Id: event.h,v 1.23 2007/09/24 23:25:48 lpsmith Exp $

#ifndef EVENT_H
#define EVENT_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <vector>
#include "vectorx.h"
#include "defaults.h"
#include "timesize.h"
#include "forceparam.h"
#include "tree.h" // for branchpair typedef

class ForceSummary;
class ResimArranger;
class Branch;
class TimeList;

enum event_class {activeCoalEvent, activeGrowCoalEvent,
		  activeLogisticSelectionCoalEvent, inactiveCoalEvent,
                  inactiveGrowCoalEvent, inactiveLogisticSelectionCoalEvent,
		  migEvent, diseaseEvent, diseaseLogSelEvent, activeRecEvent, inactiveRecEvent,
		  activeStairStickCoalEvent, inactiveStairStickCoalEvent};

/***************************************************************
  This class contains expertese needed to handle one type of
  "event" in the rearrangment process.  Events are things such
  as a migration, a recombination on an active lineage, a
  recombination on an inactive lineage, etc.  The PickTime()
  routine calculates the time of the next such event.  The DoEvent() 
  routine calls Tree code needed to actually implement the event.  
  The Done() routine indicates whether resimulation needs to continue; 
  only if all events are Done() will resimulation terminate before
  the end of the tree is reached.

  The class is polymorphic on event type, which is related
  to Force, but more than one event type can be associated
  with the same Force (for example, the two types of recombination). 

  Events must be initialized with the parameters of the current
  chain via a call to InstallParameters() before they are used.

  Written by Mary Kuhner
  March 2002--revised to enable Growth force

  December 2003--revised to move parameters up to ArrangerVec
    class to enable BayesArranger.  Mary

  November 2004--revised to split DoEvent into DoEvent (which picks
    all the random stuff) and FinishEvent (which uses the stuff chosen
    by DoEvent).  DoEventThatMatches written to parallel the new DoEvent
    so it could make non-random choices.  --Lucian

  March 2006--removed DoEventThatMatches due to Branch_ptr refactor and
    subsequent realization that TreeSizeArranger need not erase the tree!

***************************************************************/

class Event
{
  public:
		 Event(const ForceSummary& fs);
  virtual        ~Event() { delete m_CalcSizeAtTime; };
  
  virtual double PickTime(double) = 0;
  virtual void   DoEvent(double eventT) = 0;
  virtual void   InstallParameters(const ForceParameters& starts);
  virtual void   InstallThetas(const DoubleVec1d& thetas);
  virtual bool   Done() const;
  virtual Event* Clone() const = 0;
  virtual event_class Type() const = 0;   // RTII
  void           SetArranger(ResimArranger& newowner) { ar = &newowner; };
  virtual bool   IsInactive() {return false;};
  
  protected:
                   Event(const Event& src);
    ResimArranger* ar;         // points back to owning arranger

  // these are all set by InstallParameters()
    long           m_maxEvents;  // maximum for this force
    long           m_pindex;   // index into a standard partition force
                               // ordered vector for an event
    TimeSize*      m_CalcSizeAtTime;    // we own this!
    DoubleVec1d    m_thetas, m_growths; // theta and growth values for
                                        // use with m_CalcSizeAtTime
					// plus other use
                                        // empty is okay
    ForceParameters m_allparams;        // general parameter interface
                                        // for use m_CalcSizeAtTime

  private:
            Event& operator=(const Event& src);  // not defined
            Event(); // not defined

}; /* Event class */ 

//______________________________________________________________________

class XPartitionEvent : public Event
{
  public:
                   XPartitionEvent(const ForceSummary& fs);
     virtual       ~XPartitionEvent() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

  protected:
     long m_nxparts;

     virtual void  ThrowIfSubPopSizeTiny(double eventT) const;

}; /* XPartition Event */

//______________________________________________________________________

class CoalEvent : public XPartitionEvent
{
  public:
		 CoalEvent(const ForceSummary& fs, bool isactive);
  virtual        ~CoalEvent() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

  virtual void   DoEvent(double eventT);
  virtual void   FinishEvent(double eventT, Branch_ptr branch1, Branch_ptr branch2);
  virtual void   InstallParameters(const ForceParameters& starts);
  virtual bool   IsInactive() {return (!m_isactive);};

protected:
  long m_chosenxpart;
  const bool m_isactive;

}; /* CoalEvent class*/

//______________________________________________________________________

class ActiveCoal : public CoalEvent
{
  public:
                   ActiveCoal(const ForceSummary& fs);
    virtual        ~ActiveCoal() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double);
    virtual void   InstallParameters(const ForceParameters& starts);
    virtual void   InstallThetas(const DoubleVec1d& thetas);
    virtual Event* Clone() const;
    virtual event_class Type() const { return activeCoalEvent; };   // RTII

  private:                      // these are set up by InstallParameters
    vector<double> m_invTheta;    // precomputed 1/Theta array


}; /* ActiveCoal Event */

//______________________________________________________________________


// The growth-aware version of the above

class ActiveGrowCoal : public CoalEvent 
{
  public:
                   ActiveGrowCoal(const ForceSummary& fs);
    virtual        ~ActiveGrowCoal() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double starttime);
    virtual Event* Clone() const;
    virtual event_class Type() const { return activeGrowCoalEvent; };   // RTII

}; /* ActiveGrowCoal Event */


//______________________________________________________________________


// A version of the above with deterministic, logistic selection acting.
// Very similar to growth, with different math.

class ActiveLogisticSelectionCoal : public CoalEvent 
{
  public:
                   ActiveLogisticSelectionCoal(const ForceSummary& fs);
    virtual        ~ActiveLogisticSelectionCoal() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double starttime);
    virtual void   InstallParameters(const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual event_class Type() const { return activeLogisticSelectionCoalEvent; };   // RTII
 private:
    double m_selectionCoefficient;
}; /* ActiveLogisticSelectionCoal Event */


//______________________________________________________________________

class ActiveStairStickCoal : public CoalEvent
{
  public:
                   ActiveStairStickCoal(const ForceSummary& fs);
    virtual        ~ActiveStairStickCoal() {};
  // we accept default c\opy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double starttime);
    virtual Event* Clone() const;
    // RTTI
    virtual event_class Type() const { return activeStairStickCoalEvent; };

}; /* ActiveStairStickCoal */

//______________________________________________________________________

class InactiveCoal : public CoalEvent
{
  public:
                   InactiveCoal(const ForceSummary& fs);
    virtual        ~InactiveCoal() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double);
    virtual void   InstallParameters(const ForceParameters& starts);
    virtual void   InstallThetas(const DoubleVec1d& thetas);
    virtual Event* Clone() const;
    virtual event_class Type() const { return inactiveCoalEvent; };   // RTII

  private:                      // these are set up by InstallParameters
    vector<double> m_inv2Theta;  // precomputed 2/Theta array

}; /* InactiveCoal Event */

//______________________________________________________________________

// the growth-aware version of the above

class InactiveGrowCoal : public CoalEvent
{
  public:
                   InactiveGrowCoal(const ForceSummary& fs);
    virtual        ~InactiveGrowCoal() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double starttime);
    virtual Event* Clone() const;
    virtual event_class Type() const { return inactiveGrowCoalEvent; }; // RTII

}; /* InactiveGrowCoal Event */

//______________________________________________________________________

// A version of the above with deterministic, logistic selection acting.
// Very similar to growth, with different math.

class InactiveLogisticSelectionCoal : public CoalEvent
{
  public:
                   InactiveLogisticSelectionCoal(const ForceSummary& fs);
    virtual        ~InactiveLogisticSelectionCoal() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double starttime);
    virtual void   InstallParameters(const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual event_class Type() const { return inactiveLogisticSelectionCoalEvent; }; // RTII
 private:
    double m_selectionCoefficient;

}; /* InactiveLogisticSelectionCoal Event */

//______________________________________________________________________

class InactiveStairStickCoal : public CoalEvent
{
  public:
                   InactiveStairStickCoal(const ForceSummary& fs);
    virtual        ~InactiveStairStickCoal() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double starttime);
    virtual Event* Clone() const;
    // RTTI
    virtual event_class Type() const { return inactiveStairStickCoalEvent; };

}; /* InactiveStairStickCoal */

//______________________________________________________________________

class PartitionEvent : public Event
{
  public:
                   PartitionEvent(const ForceSummary& fs);                
     virtual       ~PartitionEvent() {};
  // we accept default copy ctor; def ctor and op= disabled in base class
  

  protected:
     long m_nparts;

    virtual void   FinishEvent(double eventT, Branch_ptr active, long topop) = 0;
    force_type m_forcetype;

}; /* Partition Event */

//______________________________________________________________________

class MigEvent : public PartitionEvent
{
public:
  MigEvent(const ForceSummary& fs);
  virtual        ~MigEvent() {};
  // we accept default copy ctor; def ctor and op= disabled in base class
  
  virtual double PickTime(double);
  virtual void   DoEvent(double eventT);
  virtual void   InstallParameters(const ForceParameters& starts);
  virtual Event* Clone() const;
  virtual event_class Type() const { return migEvent; };   // RTII

protected:
  virtual void   FinishEvent(double eventT, Branch_ptr active, long topop);
  
private:                      // these are set up by InstallParameters
  DoubleVec2d    m_rescaledMigRates;  // rescaled parameters
  DoubleVec1d    m_immigrationRates;  // combined over source populations
  long           m_frompop;
  long           m_topop;

  void           ComputeCumulativeRates(const ForceParameters& starts);

}; /* MigEvent */

//______________________________________________________________________

class DiseaseEvent : public PartitionEvent
{
  private:   // all member variables are initialized by InstallParameters
    DoubleVec2d m_probhere;
    DoubleVec1d m_murateto;

    void           ComputeCumulativeRates(const ForceParameters& starts);

 protected:
    long m_startdis;
    long m_enddis;

  public:
                   DiseaseEvent(const ForceSummary& fs);
    virtual        ~DiseaseEvent() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual Event* Clone() const;

    virtual double PickTime(double);
    virtual void   DoEvent(double eventT);
    virtual void   FinishEvent(double eventT, Branch_ptr active, long enddis);
    virtual void   InstallParameters(const ForceParameters& starts);
    virtual event_class Type() const { return diseaseEvent; };   // RTTI
}; /* DiseaseEvent */

//______________________________________________________________________

class DiseaseLogSelEvent : public DiseaseEvent
{
  public:
                   DiseaseLogSelEvent(const ForceSummary& fs);
    virtual        ~DiseaseLogSelEvent() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double);
    virtual void   InstallParameters(const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual event_class Type() const { return diseaseLogSelEvent; };   // RTTI

 private:
    double m_mu_into_A_from_a;
    double m_mu_into_a_from_A;
    double m_selectionCoefficient;

}; /* DiseaseLogSelEvent */

//______________________________________________________________________

class ActiveRec : public Event
{
  public:
                   ActiveRec(const ForceSummary& fs);
    virtual        ~ActiveRec() {};
  // we accept default copy ctor; def ctor and op= disabled in base class

    virtual double PickTime(double);
    virtual void   DoEvent(double eventT);
    virtual void   InstallParameters(const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual event_class Type() const { return activeRecEvent; };   // RTII

            void   AddSizeForce(force_type fname)
                                { m_onPartitionForces.push_back(fname); };

  protected:
    virtual branchpair FinishEvent(double eventT, Branch_ptr active, long recsite,
                               FPartMap fparts);

  private:                      // these are set up by InstallParameters
    double  m_recrate;  // recombination rate

                               // m_onPartitionForces is filled by 
                               // Force::ModifyEvents
    vector<force_type> m_onPartitionForces;

}; /* ActiveRec Event */

//______________________________________________________________________

class InactiveRec : public Event
{
  public:
                   InactiveRec(const ForceSummary& fs);
    virtual        ~InactiveRec() {};

    virtual double PickTime(double);
    virtual void   DoEvent(double eventT); 
    virtual void   InstallParameters(const ForceParameters& starts);
    virtual Event* Clone() const;
    virtual event_class Type() const { return inactiveRecEvent; };   // RTII

            void   AddSizeForce(force_type fname)
                                { m_onPartitionForces.push_back(fname); };
    virtual bool  IsInactive() {return true;};

// In the absence of a more correct algorithm for detecting upcoming
// InactiveRecombinations, we presume that resimulation must continue
// to the bottom of the tree.

    virtual bool   Done() const           { return false; };

  private:                      // these are set up by InstallParameters
    double  m_recrate;  // recombination rate

                               // m_onPartitionForces is filled by 
                               // Force::ModifyEvents
    vector<force_type> m_onPartitionForces;

}; /* InactiveRec Event */


//______________________________________________________________________

// helper function

double LogisticSelectionPickTime(const double& theta_A0, const double& theta_a0,
				 const double& s, const double& t_s,
				 const double& dtau_A, const double& dtau_a,
				 long* pChosenPopulation);

std::string ToString(const Event &e);

#endif /* EVENT_H */
