// $Id: timesize.h,v 1.4 2007/07/10 23:46:41 jay Exp $

#ifndef TIMESIZE_H
#define TIMESIZE_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "constants.h"
#include "vectorx.h"
#include "forceparam.h"

//___________________________________________________________________________
//___________________________________________________________________________

class TimeSize
{
public:
// we accept the compiler-generated ctor, copy-ctor, and operator=
virtual ~TimeSize() {};
virtual TimeSize* Clone() const = 0;

virtual DoubleVec1d PartitionSizeAt(force_type, const ForceParameters& fp,
   double etime) const = 0;
virtual DoubleVec1d SizeAt(const ForceParameters& fp, double etime) const = 0;

}; /* TimeSize */

//___________________________________________________________________________

class GrowTimeSize : public TimeSize
{
public:
// we accept the compiler-generated ctor, copy-ctor, and operator=
virtual ~GrowTimeSize() {};
virtual TimeSize* Clone() const { return new GrowTimeSize(*this); };

virtual DoubleVec1d PartitionSizeAt(force_type partforce, 
   const ForceParameters& fp, double etime) const;
virtual DoubleVec1d SizeAt(const ForceParameters& fp, double etime) const;

}; /* GrowTimeSize */

//___________________________________________________________________________

class StaticTimeSize : public TimeSize
{
public:
// we accept the compiler-generated ctor, copy-ctor, and operator=
virtual ~StaticTimeSize() {};
virtual TimeSize* Clone() const { return new StaticTimeSize(*this); };

virtual DoubleVec1d PartitionSizeAt(force_type partforce,
   const ForceParameters& fp, double etime) const;
virtual DoubleVec1d SizeAt(const ForceParameters& fp, double etime) const;

}; // StaticTimeSize


//___________________________________________________________________________

class LogisticSelectionTimeSize : public TimeSize
{
public:
  LogisticSelectionTimeSize() {};
virtual ~LogisticSelectionTimeSize() {};
virtual TimeSize* Clone() const { return new LogisticSelectionTimeSize(*this); };

virtual DoubleVec1d PartitionSizeAt(force_type partforce,
   const ForceParameters& fp, double etime) const;
virtual DoubleVec1d SizeAt(const ForceParameters& fp, double etime) const;

}; /* LogisticSelectionTimeSize */

#endif /* TIMESIZE_H */
