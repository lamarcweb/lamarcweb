#ifndef GC_FILE_UTIL_H
#define GC_FILE_UTIL_H

#include "gc_errhandling.h"
#include "wx/string.h"

class wxFileInputStream;
class wxTextInputStream;

class gc_file_error : public gc_ex
{
    public:
        gc_file_error(const wxString &) throw();
        virtual ~gc_file_error() throw();
};

class gc_eof : public gc_file_error
{
    public:
        gc_eof() throw();
        virtual ~gc_eof() throw();
};

class gc_file_missing_error : public gc_file_error
{
    public:
        gc_file_missing_error(const wxString & fileName) throw();
        virtual ~gc_file_missing_error() throw();
};

class gc_file_read_error : public gc_file_error
{
    public:
        gc_file_read_error() throw();
        gc_file_read_error(const wxString & fileName) throw();
        virtual ~gc_file_read_error() throw();
};

wxString
ReadLineSafely(wxFileInputStream * fStream, wxTextInputStream * tStream);

wxString
ReadWordSafely(wxFileInputStream & fStream, wxTextInputStream & tStream);

#endif
// GC_FILE_UTIL_H
