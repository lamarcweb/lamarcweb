#include "gc_errhandling.h"
#include "gc_file_util.h"
#include "gc_strings_io.h"
#include "wx/log.h"
#include "wx/txtstrm.h"
#include "wx/wfstream.h"

//////////////////

gc_file_error::gc_file_error(const wxString & msg) throw()
    : gc_ex(msg)
{
}

gc_file_error::~gc_file_error() throw()
{}

//////////////////

gc_eof::gc_eof() throw()
    : gc_file_error(gc_io::eof)
{
}

gc_eof::~gc_eof() throw()
{}

//////////////////

gc_file_missing_error::gc_file_missing_error(const wxString & fileName) throw()
    : gc_file_error(wxString::Format(gc_io::fileMissing,fileName.c_str()))
{
}

gc_file_missing_error::~gc_file_missing_error() throw()
{}

//////////////////

gc_file_read_error::gc_file_read_error() throw()
    : gc_file_error(gc_io::fileReadError)
{
}

gc_file_read_error::gc_file_read_error(const wxString & fileName) throw()
    : gc_file_error(wxString::Format(gc_io::fileReadErrorWithName,fileName.c_str()))
{
}

gc_file_read_error::~gc_file_read_error() throw()
{}

////////////////////////////////////////


wxString ReadLineSafely(wxFileInputStream * fStream,
                        wxTextInputStream * tStream)
{
    assert(fStream != NULL);
    assert(tStream != NULL);
    wxString line  = tStream->ReadLine();
    wxStreamError lastError = fStream->GetLastError();
    if(lastError == wxSTREAM_EOF)
    {
        throw gc_eof();
    }
    if(lastError != wxSTREAM_NO_ERROR)
    {
        throw gc_file_read_error();
    }
    return line;
}

////////////////////////////////////////


wxString ReadWordSafely(wxFileInputStream & fStream,
                        wxTextInputStream & tStream)
{
    wxString line  = tStream.ReadWord();
    wxStreamError lastError = fStream.GetLastError();
    if(lastError == wxSTREAM_EOF)
    {
        throw gc_eof();
    }
    if(lastError != wxSTREAM_NO_ERROR)
    {
        throw gc_file_read_error();
    }
    return line;
}
