//$Id: gc_errhandling.h,v 1.9 2007/09/07 20:55:33 ewalkup Exp $

#ifndef GC_ERRHANDLING_H
#define GC_ERRHANDLING_H

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <stdexcept>
#include "wx/string.h"

///////////////////////////////////////////////////////
class gc_ex : public std::exception
{
    private:
        gc_ex();    // undefined
    protected:
        wxString    m_what;
        size_t      m_row;
        wxString    m_fileName;
    public:
        gc_ex(wxString) throw();
        virtual ~gc_ex() throw();

        bool    hasRow() const throw();
        size_t  getRow() const throw();
        void    setRow(size_t row) throw();
        void    setRow(int row) throw();

        bool        hasFile()   const throw();
        wxString    getFile()   const throw();
        void        setFile(const wxString & s) throw();

        virtual const char* what () const throw();
        virtual const wxString & wxWhat() const throw();

};

class gc_data_error : public gc_ex {
public:
  gc_data_error(const wxString & wh);
  virtual ~gc_data_error() throw();
};

class gc_implementation_error : public gc_ex {
public:
  gc_implementation_error(const wxString & wh);
  virtual ~gc_implementation_error() throw();
};

class gui_error : public gc_ex {
public:
    gui_error(const wxString & wh);
    virtual ~gui_error() throw();
};

class gc_abandon_export : public gc_ex {
public:
    gc_abandon_export() throw() ;
    virtual ~gc_abandon_export() throw();
};

class gc_fatal_error : public gc_ex {
public:
  gc_fatal_error();
  virtual ~gc_fatal_error() throw();
};


#endif
// GC_ERRHANDLING_H
