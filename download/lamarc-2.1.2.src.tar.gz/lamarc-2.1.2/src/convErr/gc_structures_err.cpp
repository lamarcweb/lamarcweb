#include "gc_structures_err.h"
#include "gc_strings.h" // EWFIX.P4 refactor out
#include "gc_strings_structures.h"

gc_structures_err::gc_structures_err(const wxString & wh) throw()
    :   gc_data_error(wh)
{
}

gc_structures_err::~gc_structures_err() throw() {};
////////////////////////////////////

duplicate_file_base_name_error::duplicate_file_base_name_error(const wxString & wh) throw()
    : gc_structures_err(wxString::Format(gcerr_structures::duplicateFileBaseName,wh.c_str()))
{
}
duplicate_file_base_name_error::~duplicate_file_base_name_error() throw() {};

duplicate_file_error::duplicate_file_error(const wxString & wh) throw()
    : gc_structures_err(wxString::Format(gcerr_structures::duplicateFileName,wh.c_str()))
{
}
duplicate_file_error::~duplicate_file_error() throw() {};

duplicate_name_error::duplicate_name_error(const wxString& name, const wxString & where) throw()
    : gc_structures_err(wxString::Format(gcerr_structures::duplicateName,name.c_str(),where.c_str()))
{
}
duplicate_name_error::~duplicate_name_error() throw() {};

empty_name_error::empty_name_error(const wxString& where) throw()
    : gc_structures_err(wxString::Format(gcerr::emptyName,where.c_str()))
{
}
empty_name_error::~empty_name_error() throw() {};

incompatible_pops::incompatible_pops(const wxString& wh) throw()
    : gc_structures_err(wh)
{
}
incompatible_pops::~incompatible_pops() throw() {};

missing_file_error::missing_file_error(const wxString & wh) throw()
    : gc_structures_err(wxString::Format(gcerr_structures::missingFile,wh.c_str()))
{
}
missing_file_error::~missing_file_error() throw() {};


missing_name_error::missing_name_error(const wxString& name, const wxString & where) throw()
    : gc_structures_err(wxString::Format(gcerr_structures::missingName,name.c_str(),where.c_str()))
{
}
missing_name_error::~missing_name_error() throw() {};

unparsable_file_error::unparsable_file_error(const wxString & wh) throw()
    : gc_structures_err((wxString::Format(gcerr_structures::unparsableFile,wh.c_str())))
{
}
unparsable_file_error::~unparsable_file_error() throw() {};

gc_missing_population::gc_missing_population(const wxString & popName) throw()
    : gc_structures_err(wxString::Format(gcerr_structures::missingPopulation,popName.c_str()))
{
}
gc_missing_population::~gc_missing_population() throw() {};

missing_region::missing_region(const wxString & regName) throw()
    : gc_structures_err(wxString::Format(gcerr_structures::missingRegion,regName.c_str()))
{
}
missing_region::~missing_region() throw() {};

missing_trait::missing_trait(const wxString & traitName) throw()
    : gc_structures_err(wxString::Format(gcerr_structures::missingTrait,traitName.c_str()))
{
}
missing_trait::~missing_trait() throw() {};

effective_pop_size_clash::effective_pop_size_clash(double size1, double size2) throw()
    :   gc_structures_err(wxString::Format(gcerr_structures::regionEffPopSizeClash,size1,size2))
{
}
effective_pop_size_clash::~effective_pop_size_clash() throw() {};

gc_name_repeat_allele::gc_name_repeat_allele(wxString & name, int row1, int row2) throw()
    :   gc_structures_err(wxString::Format(gcerr_structures::nameRepeatAllele,name.c_str(),row1))
{
    setRow(row2);
}
gc_name_repeat_allele::~gc_name_repeat_allele() throw() {};
    

gc_name_repeat_locus::gc_name_repeat_locus(wxString & name, int row1, int row2) throw()
    :   gc_structures_err(wxString::Format(gcerr_structures::nameRepeatLocus,name.c_str(),row1))
{
    setRow(row2);
}
gc_name_repeat_locus::~gc_name_repeat_locus() throw() {};
    

gc_name_repeat_pop::gc_name_repeat_pop(wxString & name, int row1, int row2) throw()
    :   gc_structures_err(wxString::Format(gcerr_structures::nameRepeatPop,name.c_str(),row1))
{
    setRow(row2);
}
gc_name_repeat_pop::~gc_name_repeat_pop() throw() {};
    

gc_name_repeat_region::gc_name_repeat_region(wxString & name, int row1, int row2) throw()
    :   gc_structures_err(wxString::Format(gcerr_structures::nameRepeatRegion,name.c_str(),row1))
{
    setRow(row2);
}
gc_name_repeat_region::~gc_name_repeat_region() throw() {};
    

gc_name_repeat_trait::gc_name_repeat_trait(wxString & name, int row1, int row2) throw()
    :   gc_structures_err(wxString::Format(gcerr_structures::nameRepeatTrait,name.c_str(),row1))
{
    setRow(row2);
}
gc_name_repeat_trait::~gc_name_repeat_trait() throw() {};
    
gc_allele_trait_mismatch::gc_allele_trait_mismatch(wxString name, wxString newTraitName, wxString oldTraitName) throw()
    :   gc_structures_err(wxString::Format(gcerr_structures::mismatchAlleleTrait,name.c_str(),newTraitName.c_str(),oldTraitName.c_str()))
{
}
gc_allele_trait_mismatch::~gc_allele_trait_mismatch() throw() {};
    
    
gc_locus_region_mismatch::gc_locus_region_mismatch(wxString name, wxString newRegionName, wxString oldRegionName) throw()
    :   gc_structures_err(wxString::Format(gcerr_structures::mismatchLocusRegion,name.c_str(),newRegionName.c_str(),oldRegionName.c_str()))
{
}
gc_locus_region_mismatch::~gc_locus_region_mismatch() throw() {};
    
