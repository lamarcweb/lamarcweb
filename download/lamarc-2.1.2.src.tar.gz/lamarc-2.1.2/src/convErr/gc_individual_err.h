#ifndef GC_INDIVIDUAL_ERR
#define GC_INDIVIDUAL_ERR

#include "gc_errhandling.h"

class GCIndividual;
class GCParseSample;

class gc_individual_err : public gc_ex
{
    public:
        gc_individual_err(wxString msg) throw() ;
        virtual ~gc_individual_err() throw() ;
};


//////////////////////////
class gc_phase_locus_repeat : public gc_individual_err
{
    public:
        gc_phase_locus_repeat(wxString indName, wxString locusName) throw();
        virtual ~gc_phase_locus_repeat() throw() ;
};


//////////////////////////
class gc_sample_locus_repeat : public gc_individual_err
{
    public:
        gc_sample_locus_repeat(wxString sampleName, wxString locusName) throw();
        virtual ~gc_sample_locus_repeat() throw() ;
};

//////////////////////////
class gc_sample_missing_locus_data : public gc_individual_err
{
    public:
        gc_sample_missing_locus_data(wxString sampleName, wxString locusName) throw();
        virtual ~gc_sample_missing_locus_data() throw() ;
};

//////////////////////////
class gc_ind_missing_phase_for_locus : public gc_individual_err
{
    public:
        gc_ind_missing_phase_for_locus(wxString indName, wxString locusName) throw();
        virtual ~gc_ind_missing_phase_for_locus() throw() ;
};

//////////////////////////
class gc_ind_wrong_sample_count : public gc_individual_err
{
    public:
        gc_ind_wrong_sample_count(const GCIndividual&) throw();
        virtual ~gc_ind_wrong_sample_count() throw() ;
};


#endif
// GC_INDIVIDUAL_ERR
