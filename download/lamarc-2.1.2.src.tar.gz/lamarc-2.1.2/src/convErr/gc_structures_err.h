//$Id: gc_structures_err.h,v 1.7 2007/04/02 21:46:16 ewalkup Exp $

#ifndef GC_STRUCTURES_ERR_H
#define GC_STRUCTURES_ERR_H

/* 
 Copyright 2002 Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "gc_errhandling.h"

class gc_structures_err : public gc_data_error {
public:
  gc_structures_err(const wxString & wh) throw();
  virtual ~gc_structures_err() throw() ;
};

class duplicate_file_base_name_error : public gc_structures_err {
public:
    duplicate_file_base_name_error(const wxString & wh) throw();
    virtual ~duplicate_file_base_name_error() throw() ;
};

class duplicate_file_error : public gc_structures_err {
public:
    duplicate_file_error(const wxString & wh) throw();
    virtual ~duplicate_file_error() throw() ;
};

class unparsable_file_error : public gc_structures_err {
public:
    unparsable_file_error(const wxString & wh) throw();
    virtual ~unparsable_file_error() throw() ;
};

class gc_missing_population : public gc_structures_err {
public:
  gc_missing_population(const wxString & popName) throw() ;
  virtual ~gc_missing_population() throw() ;
};

class missing_region : public gc_structures_err {
public:
  missing_region(const wxString& wh) throw() ;
  virtual ~missing_region() throw() ;
};

class missing_trait : public gc_structures_err {
public:
  missing_trait(const wxString& wh) throw();
  virtual ~missing_trait() throw() ;
};

class duplicate_name_error : public gc_structures_err {
    public:
        duplicate_name_error(const wxString & name, const wxString & why) throw();
        virtual ~duplicate_name_error() throw() ;
};

class empty_name_error : public gc_structures_err {
    public:
        empty_name_error(const wxString& why) throw();
        virtual ~empty_name_error() throw() ;
};

class incompatible_pops : public gc_structures_err {
    public:
        incompatible_pops(const wxString & wh) throw();
        virtual ~incompatible_pops() throw() ;
};

class missing_file_error : public gc_structures_err {
public:
    missing_file_error(const wxString & filename) throw();
    virtual ~missing_file_error() throw() ;
};

class missing_name_error : public gc_structures_err {
    public:
        missing_name_error(const wxString& name, const wxString & why) throw();
        virtual ~missing_name_error() throw() ;
};

class effective_pop_size_clash : public gc_structures_err {
    public:
        effective_pop_size_clash(double size1, double size2) throw();
        virtual ~effective_pop_size_clash() throw() ;
};

class gc_name_repeat_allele : public gc_structures_err {
    public:
        gc_name_repeat_allele(wxString & name, int oldRow, int newRow) throw();
        virtual ~gc_name_repeat_allele() throw ();
};

class gc_name_repeat_locus : public gc_structures_err {
    public:
        gc_name_repeat_locus(wxString & name, int oldRow, int newRow) throw();
        virtual ~gc_name_repeat_locus() throw ();
};

class gc_name_repeat_pop : public gc_structures_err {
    public:
        gc_name_repeat_pop(wxString & name, int oldRow, int newRow) throw();
        virtual ~gc_name_repeat_pop() throw ();
};

class gc_name_repeat_region : public gc_structures_err {
    public:
        gc_name_repeat_region(wxString & name, int oldRow, int newRow) throw();
        virtual ~gc_name_repeat_region() throw ();
};

class gc_name_repeat_trait : public gc_structures_err {
    public:
        gc_name_repeat_trait(wxString & name, int oldRow, int newRow) throw();
        virtual ~gc_name_repeat_trait() throw ();
};

class gc_allele_trait_mismatch : public gc_structures_err {
    public:
        gc_allele_trait_mismatch(wxString alleleName, wxString newTraitName, wxString oldTraitName) throw();
        virtual ~gc_allele_trait_mismatch() throw ();
};

class gc_locus_region_mismatch : public gc_structures_err {
    public:
        gc_locus_region_mismatch(wxString locusName, wxString newRegionName, wxString oldRegionName) throw();
        virtual ~gc_locus_region_mismatch() throw ();
};


#endif
// GC_STRUCTURES_ERR_H
