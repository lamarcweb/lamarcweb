#ifndef GC_CMDFILE_ERR
#define GC_CMDFILE_ERR

#include "gc_errhandling.h"

class gc_cmdfile_err : public gc_ex {
    public:
        gc_cmdfile_err(const wxString & msg) throw();
        virtual ~gc_cmdfile_err() throw() ;
};

///////////////////////////////////////////////////////


class gc_bad_yes_no : public gc_cmdfile_err {
    public:
        gc_bad_yes_no(const wxString & token) throw();
        virtual ~gc_bad_yes_no() throw() ;
};

class gc_bad_proximity : public gc_cmdfile_err {
    public:
        gc_bad_proximity(const wxString & token) throw();
        virtual ~gc_bad_proximity() throw() ;
};

class gc_bad_file_format : public gc_cmdfile_err {
    public:
        gc_bad_file_format(const wxString & token) throw();
        virtual ~gc_bad_file_format() throw() ;
};

class gc_bad_interleaving : public gc_cmdfile_err {
    public:
        gc_bad_interleaving(const wxString & token) throw();
        virtual ~gc_bad_interleaving() throw() ;
};

class gc_bad_general_data_type : public gc_cmdfile_err {
    public:
        gc_bad_general_data_type(const wxString & token) throw();
        virtual ~gc_bad_general_data_type() throw() ;
};

class gc_bad_specific_data_type : public gc_cmdfile_err {
    public:
        gc_bad_specific_data_type(const wxString & token) throw();
        virtual ~gc_bad_specific_data_type() throw() ;
};

///////////////////////////////////////////////////////

class gc_locus_match_byname_not_empty : public gc_cmdfile_err {
    public:
        gc_locus_match_byname_not_empty() throw ();
        virtual ~gc_locus_match_byname_not_empty() throw() ;
};

class gc_locus_match_single_empty : public gc_cmdfile_err {
    public:
        gc_locus_match_single_empty() throw ();
        virtual ~gc_locus_match_single_empty() throw() ;
};

class gc_locus_match_unknown : public gc_cmdfile_err {
    public:
        gc_locus_match_unknown(const wxString & locusMatchType) throw ();
        virtual ~gc_locus_match_unknown() throw() ;
};

class gc_pop_match_byname_not_empty : public gc_cmdfile_err {
    public:
        gc_pop_match_byname_not_empty() throw ();
        virtual ~gc_pop_match_byname_not_empty() throw() ;
};

class gc_pop_match_single_empty : public gc_cmdfile_err {
    public:
        gc_pop_match_single_empty() throw ();
        virtual ~gc_pop_match_single_empty() throw() ;
};

class gc_pop_match_unknown : public gc_cmdfile_err {
    public:
        gc_pop_match_unknown(const wxString & popType) throw ();
        virtual ~gc_pop_match_unknown() throw() ;
};
#endif 
//GC_CMDFILE_ERR
