#ifndef GC_DATA_MISSING_ERR
#define GC_DATA_MISSING_ERR

#include "gc_errhandling.h"

class gc_data_missing_err : public gc_ex
{
    public:
        gc_data_missing_err(wxString msg) throw();
        virtual ~gc_data_missing_err() throw() ;
};


//////////////////////////
class gc_data_missing_pop_locus : public gc_data_missing_err
{
    public:
        gc_data_missing_pop_locus(wxString popName, wxString locusName) throw();
        virtual ~gc_data_missing_pop_locus() throw() ;
};

//////////////////////////
class gc_data_missing_pop_region : public gc_data_missing_err
{
    public:
        gc_data_missing_pop_region(wxString popName, wxString regionName) throw();
        virtual ~gc_data_missing_pop_region() throw() ;
};



#endif
// GC_DATA_MISSING_ERR
