#include "gc_individual.h"
#include "gc_individual_err.h"
#include "gc_strings_individual.h"

gc_individual_err::gc_individual_err(wxString msg) throw ()
    : gc_ex(msg)
{
}
gc_individual_err::~gc_individual_err() throw () {}

gc_phase_locus_repeat::gc_phase_locus_repeat(wxString indName, wxString locusName) throw()
    : gc_individual_err(wxString::Format(gcerr_ind::phaseLocusRepeat,indName.c_str(),locusName.c_str()))
{
}
gc_phase_locus_repeat::~gc_phase_locus_repeat() throw () {}

gc_sample_locus_repeat::gc_sample_locus_repeat(wxString sampleName, wxString locusName) throw()
    : gc_individual_err(wxString::Format(gcerr_ind::sampleLocusRepeat,sampleName.c_str(),locusName.c_str()))
{
}
gc_sample_locus_repeat::~gc_sample_locus_repeat() throw () {}

gc_sample_missing_locus_data::gc_sample_missing_locus_data(wxString sampleName, wxString locusName) throw()
    : gc_individual_err(wxString::Format(gcerr_ind::sampleMissingLocusData,sampleName.c_str(),locusName.c_str()))
{
}
gc_sample_missing_locus_data::~gc_sample_missing_locus_data() throw () {}

gc_ind_missing_phase_for_locus::gc_ind_missing_phase_for_locus(wxString indName, wxString locusName) throw()
    : gc_individual_err(wxString::Format(gcerr_ind::missingPhaseForLocus,indName.c_str(),locusName.c_str()))
{
}
gc_ind_missing_phase_for_locus::~gc_ind_missing_phase_for_locus() throw () {}

gc_ind_wrong_sample_count::gc_ind_wrong_sample_count(const GCIndividual& ind) throw()
    : gc_individual_err(wxString::Format(gcerr_ind::wrongSampleCount,ind.GetName().c_str()))
{
}
gc_ind_wrong_sample_count::~gc_ind_wrong_sample_count() throw () {}
