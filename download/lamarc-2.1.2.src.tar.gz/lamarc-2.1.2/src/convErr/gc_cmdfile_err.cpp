#include "gc_cmdfile_err.h"
#include "gc_strings_cmdfile.h"

//////////////////////
gc_cmdfile_err::gc_cmdfile_err(const wxString & msg) throw ()
    : gc_ex(msg)
{
}

gc_cmdfile_err::~gc_cmdfile_err() throw() {};

//////////////////////

gc_bad_yes_no::gc_bad_yes_no(const wxString & string) throw()
    : gc_cmdfile_err(wxString::Format(gcerr_cmdfile::badYesNo,string.c_str()))
{
}

gc_bad_yes_no::~gc_bad_yes_no() throw() {};

//////////////////////
gc_bad_proximity::gc_bad_proximity(const wxString & string) throw()
    : gc_cmdfile_err(wxString::Format(gcerr_cmdfile::badProximity,string.c_str()))
{
}

gc_bad_proximity::~gc_bad_proximity() throw() {};

//////////////////////
gc_bad_file_format::gc_bad_file_format(const wxString & string) throw()
    : gc_cmdfile_err(wxString::Format(gcerr_cmdfile::badFileFormat,string.c_str()))
{
}

gc_bad_file_format::~gc_bad_file_format() throw() {};

//////////////////////
gc_bad_interleaving::gc_bad_interleaving(const wxString & string) throw()
    : gc_cmdfile_err(wxString::Format(gcerr_cmdfile::badInterleaving,string.c_str()))
{
}

gc_bad_interleaving::~gc_bad_interleaving() throw() {};

//////////////////////
gc_bad_general_data_type::gc_bad_general_data_type(const wxString & string) throw()
    : gc_cmdfile_err(wxString::Format(gcerr_cmdfile::badGeneralDataType,string.c_str()))
{
}

gc_bad_general_data_type::~gc_bad_general_data_type() throw() {};

//////////////////////
gc_bad_specific_data_type::gc_bad_specific_data_type(const wxString & string) throw()
    : gc_cmdfile_err(wxString::Format(gcerr_cmdfile::badSpecificDataType,string.c_str()))
{
}

gc_bad_specific_data_type::~gc_bad_specific_data_type() throw() {};

//////////////////////
gc_locus_match_byname_not_empty::gc_locus_match_byname_not_empty() throw ()
    : gc_cmdfile_err(gcerr_cmdfile::locusMatchByNameNotEmpty)
{
}

gc_locus_match_byname_not_empty::~gc_locus_match_byname_not_empty() throw() {};

//////////////////////
gc_locus_match_single_empty::gc_locus_match_single_empty() throw ()
    : gc_cmdfile_err(gcerr_cmdfile::locusMatchSingleEmpty)
{
}

gc_locus_match_single_empty::~gc_locus_match_single_empty() throw() {};

//////////////////////
gc_locus_match_unknown::gc_locus_match_unknown(const wxString & matchType) throw ()
    : gc_cmdfile_err(wxString::Format(gcerr_cmdfile::locusMatchUnknown,matchType.c_str()))
{
}

gc_locus_match_unknown::~gc_locus_match_unknown() throw() {};

//////////////////////
gc_pop_match_byname_not_empty::gc_pop_match_byname_not_empty() throw ()
    : gc_cmdfile_err(gcerr_cmdfile::popMatchByNameNotEmpty)
{
}

gc_pop_match_byname_not_empty::~gc_pop_match_byname_not_empty() throw() {};

//////////////////////
gc_pop_match_single_empty::gc_pop_match_single_empty() throw ()
    : gc_cmdfile_err(gcerr_cmdfile::popMatchSingleEmpty)
{
}

gc_pop_match_single_empty::~gc_pop_match_single_empty() throw() {};

//////////////////////
gc_pop_match_unknown::gc_pop_match_unknown(const wxString & matchType) throw ()
    : gc_cmdfile_err(wxString::Format(gcerr_cmdfile::popMatchUnknown,matchType.c_str()))
{
}

gc_pop_match_unknown::~gc_pop_match_unknown() throw() {};

