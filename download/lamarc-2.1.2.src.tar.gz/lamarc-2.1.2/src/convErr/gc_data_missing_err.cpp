#include "gc_data_missing_err.h"
#include "gc_strings_data.h"

gc_data_missing_err::gc_data_missing_err(wxString msg) throw()
    : gc_ex(msg)
{
}
gc_data_missing_err::~gc_data_missing_err() throw() {}

gc_data_missing_pop_locus::gc_data_missing_pop_locus(wxString popName, wxString locusName) throw()
    : gc_data_missing_err(wxString::Format(gcerr_data::missingPopLocus,popName.c_str(),locusName.c_str()))
{
}
gc_data_missing_pop_locus::~gc_data_missing_pop_locus() throw() {}

gc_data_missing_pop_region::gc_data_missing_pop_region(wxString popName, wxString regionName) throw()
    : gc_data_missing_err(wxString::Format(gcerr_data::missingPopRegion,popName.c_str(),regionName.c_str()))
{
}
gc_data_missing_pop_region::~gc_data_missing_pop_region() throw() {}
