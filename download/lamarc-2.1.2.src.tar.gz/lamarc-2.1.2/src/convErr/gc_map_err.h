#ifndef GC_MAP_ERR
#define GC_MAP_ERR

#include "gc_errhandling.h"

class gc_map_err : public gc_ex
{
    public:
        gc_map_err(wxString msg) throw();
        virtual ~gc_map_err() throw();
};

class gc_map_file_missing : public gc_map_err
{
    public:
        gc_map_file_missing(wxString fileName) throw();
        virtual ~gc_map_file_missing() throw() ;
};

class gc_map_file_read_err : public gc_map_err
{
    public:
        gc_map_file_read_err(wxString fileName) throw();
        virtual ~gc_map_file_read_err() throw() ;
};

class gc_map_file_empty : public gc_map_err
{
    public:
        gc_map_file_empty(wxString fileName) throw();
        virtual ~gc_map_file_empty() throw() ;
};


#endif
// GC_MAP_ERR
