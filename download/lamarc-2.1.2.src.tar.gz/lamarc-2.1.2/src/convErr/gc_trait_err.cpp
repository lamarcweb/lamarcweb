#include "gc_trait_err.h"
#include "gc_strings_trait.h"

gc_trait_err::gc_trait_err(wxString msg) throw()
    : gc_ex(msg)
{
}
gc_trait_err::~gc_trait_err() throw() {}


gc_haplotype_probability_negative::gc_haplotype_probability_negative(double prob) throw()
    : gc_trait_err(wxString::Format(gcerr_trait::hapProbabilityNegative,prob))
{
}
gc_haplotype_probability_negative::~gc_haplotype_probability_negative() throw() {}

gc_trait_allele_name_reuse::gc_trait_allele_name_reuse(wxString alleleName) throw()
    : gc_trait_err(wxString::Format(gcerr_trait::alleleNameReuse,alleleName.c_str()))
{
}
gc_trait_allele_name_reuse::~gc_trait_allele_name_reuse() throw() {}

gc_trait_phenotype_name_reuse::gc_trait_phenotype_name_reuse(wxString phenotypeName, wxString traitName) throw()
    : gc_trait_err(wxString::Format(gcerr_trait::phenotypeNameReuse,phenotypeName.c_str(),traitName.c_str()))
{
}
gc_trait_phenotype_name_reuse::~gc_trait_phenotype_name_reuse() throw() {}

gc_missing_phenotype::gc_missing_phenotype(wxString phenotypeName) throw()
    : gc_trait_err(wxString::Format(gcerr_trait::phenotypeMissing,phenotypeName.c_str()))
{
}
gc_missing_phenotype::~gc_missing_phenotype() throw() {}

gc_missing_allele::gc_missing_allele(wxString alleleName) throw()
    : gc_trait_err(wxString::Format(gcerr_trait::alleleMissing,alleleName.c_str()))
{
}
gc_missing_allele::~gc_missing_allele() throw() {}

/*
gc_allele_trait_mismatch::gc_allele_trait_mismatch(const gcTraitAllele & allele,
                                                    const GCTraitInfo & trait,
                                                    const gcPhenotype & pheno,
                                                    size_t lineNo) throw ()
    : gc_trait_err(wxString::Format(gcerr_trait::alleleTraitMismatch,
                                        allele.GetName().c_str(),
                                        pheno.GetName().c_str(),
                                        trait.GetName().c_str()))
{
    setRow(lineNo);
}
gc_allele_trait_mismatch::~gc_allele_trait_mismatch() throw() {}
*/

gc_pheno_trait_mismatch::gc_pheno_trait_mismatch(const GCTraitInfo & outer,
                                                    const GCTraitInfo & inner,
                                                    const gcPhenotype & pheno,
                                                    size_t lineNo) throw ()
    : gc_trait_err(wxString::Format(gcerr_trait::phenoTraitMismatch,
                                        pheno.GetName().c_str(),
                                        inner.GetName().c_str(),
                                        outer.GetName().c_str()))
{
    setRow(lineNo);
}
gc_pheno_trait_mismatch::~gc_pheno_trait_mismatch() throw() {}

gc_trait_allele_name_spaces::gc_trait_allele_name_spaces(wxString alleleName) throw()
    : gc_trait_err(wxString::Format(gcerr_trait::alleleNameSpaces,
                                        alleleName.c_str()))
{
}
gc_trait_allele_name_spaces::~gc_trait_allele_name_spaces() throw() {}
