#include "gc_map_err.h"
#include "gc_strings_map.h"

gc_map_err::gc_map_err(wxString msg) throw()
    :   gc_ex(msg)
{
}
gc_map_err::~gc_map_err() throw() {};


gc_map_file_missing::gc_map_file_missing(wxString fileName) throw()
    : gc_map_err(wxString::Format(gcerr_map::fileMissing,fileName.c_str()))
{
}
gc_map_file_missing::~gc_map_file_missing() throw() {}

gc_map_file_read_err::gc_map_file_read_err(wxString fileName) throw()
    : gc_map_err(wxString::Format(gcerr_map::fileReadErr,fileName.c_str()))
{
}
gc_map_file_read_err::~gc_map_file_read_err() throw() {}

gc_map_file_empty::gc_map_file_empty(wxString fileName) throw()
    : gc_map_err(wxString::Format(gcerr_map::fileEmpty,fileName.c_str()))
{
}
gc_map_file_empty::~gc_map_file_empty() throw() {}
