// $Id: maximizer_strings.h,v 1.2 2007/10/02 05:38:34 lpsmith Exp $
/* 
   Copyright 2006 Mary Kuhner, Jon Yamato and Joseph Felsenstein
   
   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/

#ifndef MAXSTR_H
#define MAXSTR_H

#include <string>
#include "stringx.h"

class maxstr
{
public:

  static const string MAX_BAD_ALPHA_0;
  static const string MAX_BAD_ALPHA_1;
  static const string MAX_BAD_LNL_0;
  static const string MAX_BAD_LNL_1;
  static const string MAX_BAD_LNL_2A1;
  static const string MAX_BAD_LNL_2A2;
  static const string MAX_BAD_LNL_2B;
  static const string MAX_CLIFF_EDGE_0;
  static const string MAX_CLIFF_EDGE_1;
  static const string MAX_CLIFF_EDGE_2;
  static const string MAX_FAILED_BRACKET_0;
  static const string MAX_FAILED_BRACKET_1;
  static const string MAX_FAILED_BRACKET_2;
  static const string MAX_FAILED_BRACKET_3;
  static const string MAX_HIGH_ALPHA_0;
  static const string MAX_NO_CONVERGENCE_0;
  static const string MAX_NO_CONVERGENCE_1;
  static const string MAX_NO_CONVERGENCE_2;
  static const string MAX_NO_CONVERGENCE_3;
  static const string MAX_NO_CONVERGENCE_4;
  static const string MAX_NO_MULTI_MAX;
  static const string MAX_NO_UPPER_BOUND_0;
  static const string MAX_NO_UPPER_BOUND_1;
  static const string MAX_NO_UPPER_BOUND_2;
  static const string MAX_UNDEFINED_BORDER_0;
  static const string MAX_UNDEFINED_BORDER_1;
  static const string MAX_UNDEFINED_BORDER_2;
};
#endif /* MAXSTR_H */
