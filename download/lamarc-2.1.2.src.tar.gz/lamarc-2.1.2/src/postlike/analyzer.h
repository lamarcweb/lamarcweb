#ifndef ANALYZER_H
#define ANALYZER_H
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// analyzer.h
//
// the analyzer generates 
// - profiles  [code will be in profile.cpp]
// 
// Peter Beerli November 2000
// $Id: analyzer.h,v 1.30 2006/03/31 21:49:55 jay Exp $
//

#include "likelihood.h"
#include "maximizer.h"
#include "parameter.h"
#include "plotstat.h"
#include "vectorx.h"
#include <fstream>
#include <vector>

typedef std::map<double, double> DoublesMap;
typedef std::map<double, double>::iterator DoublesMapiter;
typedef std::map<double, double>::reverse_iterator DoublesMapReviter;

typedef std::map<double, DoubleVec1d> DoubleToVecMap;
typedef std::map<double, DoubleVec1d>::iterator DoubleToVecMapiter;

typedef std::map<double, string> DoubleToStringMap;
typedef std::map<double, string>::iterator DoubleToStringiter;


class ForceSummary;

long difference(DoubleVec1d param1, DoubleVec1d param2);

class Analyzer
{
public:
  // Instantiate the Analyzer
  // using the "last" postlike object or "last" maximizer object, 
  // the Analyzer assumes that the 
  // Prob(G|parameter_0) are already computed 
  // [in likelihood.h:....PostLike::Setup()
  Analyzer (ForceSummary &fs, const ParamVector &params,
            Maximizer * thismaximizer);
  ~Analyzer ();


  void SetMLEs(DoubleVec1d newMLEs);
  //Debug function:
  void PrintMLEs();

  // calculate the profiles and put them into class variable profiles
  void CalcProfiles (const DoubleVec1d MLEs, double likelihood, long region);

private:
  DoubleVec1d  m_MLEparams;	// holds MLE parameters
  DoubleVec1d  m_MLElparams;	// holds the log(m_MLEparam)
  Maximizer *m_maximizer;	// holds the maximizer [for profiles]
  PostLike *m_postlikelihood;	// pointer to the PostLike [for plots]
  double m_likelihood;          // holds the L of the last maximization
  const ForceSummary &m_forcesummary;
  vector < double > m_modifiers;    // for calculation of percentiles or fixed 

  // Temporary variables as an optimization
  DoubleVec1d m_newparams;

  // Calculates a single Profile table
  void CalcProfile (ParamVector::iterator guide, long pnum, long region);
  void CalcProfileFixed (ParamVector::iterator guide, long pnum, long region);
  void CalcProfilePercentile (ParamVector::iterator guide, long pnum, long region);
  void DoHalfTheProfile(bool high, DoubleVec1d& targetLikes,
                        DoublesMap& percsForLikes, long pnum, long region,
                        vector<ProfileLineStruct>& localprofiles,
                        ParamVector::iterator guide);

  bool AddMoreExtremeValue(DoublesMap& foundLikesForVals,
                           DoubleToVecMap& foundVecsForVals,
                           DoubleToStringMap& messagesForVals,
                           bool high, long pnum);
  // returns fairly high and low values for specific forces
  DoublesMapiter GetLastHigher(DoublesMap& foundLikesForVals,
                                 double targetLike, bool high);
  DoublesMapiter GetFirstLower(DoublesMap& foundLikesForVals,
                                 double targetLike, bool high);
  bool ExpandSearch(DoublesMap& foundLikesForVals,
                    DoubleToVecMap& foundVecsForVals,
                    DoublesMapiter& lowValAndLike,
                    DoublesMapiter& highValAndLike,
                    DoubleToStringMap& messagesForVals,
                    long pnum, double targetlike);
  double LowParameter(long pnum, double currentLow);
  double HighParameter(long pnum, double currentHigh);
  DoublesMapiter ClosestFoundFor(DoublesMap& foundLikesForVals,
                                 double targetLike);
  double GetNewValFromBracket(DoublesMapiter& highValAndLike,
                              DoublesMapiter& lowValAndLike,
                              double targetLike);
  void AddBlankProfileForModifier(double modifier,
                                  vector<ProfileLineStruct>& localprofiles);
  void   CheckForMultipleMaxima(DoublesMap& foundLikesForVals, bool high);
  void   PrintDoublesMap(DoublesMap& printme);
  void   PrintDoublesIter(DoublesMapiter& printme);
  void   PrintDoubleToStringMap(DoubleToStringMap& printme);
  void   PrintDoubleToStringIter(DoubleToStringiter& printme);
};

#endif /* ANALYZER_H */
