// $Id: plforces.h,v 1.30 2007/09/24 21:43:09 erynes Exp $
#ifndef PLFORCES_H
#define PLFORCES_H
/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// PLforces class --------------------------------------------------
// 
// know how to calculate waiting times and point probabilities 
// of the parameters
//

#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <numeric>
#include <math.h>
#include "treesum.h"
#include "summary.h"

class TimeSize;

class PLForces
{
protected:
  PLForces(const PLForces& src) :
    m_nPop(src.m_nPop), m_pTreedata(src.m_pTreedata), m_start(src.m_start),
    m_end(src.m_end), m_growthstart(src.m_growthstart)
  {
  };

  long m_nPop;
  TreeSummary *m_pTreedata;    // non-owning pointer
  long m_start;        //offsets into the param vector that does not yet exist
  long m_end;

  long m_growthstart; //we need to know where the growth parameters are stored
  // we need this in all forces to handle the scaled times.

public:
    PLForces ()
 {
  };

  PLForces (long thisnpop)
  {
    m_nPop = thisnpop;
    m_start = 0L;
    m_end = 0L;
    m_growthstart = 0L;
  };

  virtual ~ PLForces ()
  {
  };

  virtual PLForces* Clone() const = 0;

  virtual double lnWait (const vector < double >&param,
			 const TreeSummary * treedata) = 0;
  virtual double lnPoint (const vector < double >&param,
			  const vector < double >&lparam,
			  const TreeSummary * treedata) = 0;
  virtual double DlnWait (const vector < double >&param,
			  const TreeSummary * treedata,
			  const long &whichparam) = 0;
  virtual double DlnPoint (const vector < double >&param,
			   const TreeSummary * treedata,
			   const long &whichparam) = 0;

  virtual long GetNparam() { return m_nPop; };
          long GetStart()  { return m_start; }; // used by Force::FindOrdinalPosition()

  virtual void SetStart(const long& start) { m_start = start; };
  virtual void SetEnd  (const long& end  ) { m_end   = end;   };
  virtual void SetGrowthStart(const long& growthstart)
                                  { m_growthstart = growthstart; };
};


class CoalescePL:public PLForces
{
protected:
  // dim: force X xpart
  vector<vector<DoubleVec1d::size_type> > m_whichpart; 
  // dim: force X part X xpart-list
  vector<vector<vector<DoubleVec1d::size_type> > > m_whichxparts; 
  ForceVec m_localpartforces;
  double CalculateScaledLPCounts(const DoubleVec1d& params,
                                 const LongVec2d& picks) const;
  CoalescePL(const CoalescePL& src) :
    PLForces(src)
  {
  };

public:
  // coalescence related wait, and point functions
  // and derivatives of them
  CoalescePL ()
  {
  };
  ~CoalescePL ()
  {
  };
  CoalescePL (long thisnpop)
  {
    m_nPop = thisnpop;
  };
  virtual PLForces* Clone() const
  {
    return new CoalescePL(*this);
  };
  void SetLocalPartForces(const ForceSummary& fs);

  double lnWait (const vector < double >&param, 
		 const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam, 
		  const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, 
		  const long &whichparam);
  double DlnPoint (const vector < double >&param,
		   const TreeSummary * treedata, 
		   const long &whichparam);
};

// subclass of CoalescePL that uses long form with growth
class CoalesceGrowPL:public CoalescePL
{
protected:
  TimeSize* m_timesize;

  CoalesceGrowPL(const CoalesceGrowPL& src) :
    CoalescePL(src)//, growthstart(src.growthstart)
  {
  };

public:

  ~CoalesceGrowPL ()
  {

  };

  CoalesceGrowPL (long thisnpop)
  {
    m_nPop=thisnpop;

  };
  virtual PLForces* Clone() const
  {
    return new CoalesceGrowPL(*this);
  };

  void SetTimeSize(TimeSize* newtimesize) {m_timesize = newtimesize;};

  double lnWait (const vector < double >&param, 
		 const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam, 
		  const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, const long &whichparam);
  //  DlnPoint is growth-independent, so just use CoalescePL::DlnPoint
  //  double DlnPoint (const vector < double >&param,
  //		 const TreeSummary * treedata, const long &whichparam);

protected:
  double lnWaitForTinyGrowth(const double theta, const double growth,
			     const unsigned long xpartition,
			     const std::list<Interval>& treesummary);
  double DlnWaitForTinyGrowth(const vector < double >&param,
			      const TreeSummary * treedata,
			      const long &whichparam);
};


//
class GrowPL:public PLForces
{
protected:
  GrowPL(const GrowPL& src) :
    PLForces(src), m_thetastart(src.m_thetastart)
  {
  };

  // exponential growth coalescence related wait, and point functions
  // and derivatives of them
  long m_thetastart;

public:
  GrowPL ()
  {
    m_thetastart = 0L;
  };

  ~GrowPL ()
  {
  };

  GrowPL (long thisnpop)
  {
    m_nPop = thisnpop;
    m_thetastart = 0;
  };

  virtual PLForces* Clone() const
  {
    return new GrowPL(*this);
  };

  virtual void SetThetaStart(const long& thetastart)
                             { m_thetastart = thetastart; };

  double lnWait (const vector < double >&param, 
		 const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam, const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, const long &whichparam);
  double DlnPoint (const vector < double >&param,
		   const TreeSummary * treedata, const long &whichparam);

 protected:

  double DlnWaitForTinyGrowth(const vector < double >&param,
			      const TreeSummary * treedata,
			      const long &whichparam);
};


class DiseasePL:public PLForces
{
public:
  // disease related wait, and point functions
  // and derivatives of them
  DiseasePL ()
  {
  };

  DiseasePL (long thisnstati) : m_msum(thisnstati,0.0)
  {
    m_nPop = thisnstati;
  };

  ~DiseasePL ()
  {
  };

  virtual PLForces* Clone() const
  {
    return new DiseasePL(*this);
  };

  double lnWait (const vector < double >&param, const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam, const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, const long &whichparam);
  double DlnPoint (const vector < double >&param,
		   const TreeSummary * treedata, const long &whichparam);

protected:
  DoubleVec1d m_msum;
  DiseasePL(const DiseasePL& src) :
    PLForces(src), m_msum(src.m_msum)
  {
  };

};


class DiseaseLogisticSelectionPL:public DiseasePL
{
 protected:
  long m_s_is_here;
public:
  // disease related wait, and point functions
  // and derivatives of them
  DiseaseLogisticSelectionPL ()
  {
  };

  DiseaseLogisticSelectionPL(long thisnstati) : DiseasePL(thisnstati)
  {
  };

  ~DiseaseLogisticSelectionPL()
  {
  };

  virtual PLForces* Clone() const
  {
    return new DiseaseLogisticSelectionPL(*this);
  };

  void SetSelectionCoefficientLocation(long paramvecindex)
  {
    m_s_is_here = paramvecindex;
  };

  double lnWait (const vector < double >&param, const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam, const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, const long &whichparam);
  // DlnPoint is selection-independent, so just use DiseasePL::DlnPoint().

protected:
  DiseaseLogisticSelectionPL(const DiseaseLogisticSelectionPL& src) :
    DiseasePL(src)
  {
  };
  double DlnWaitForTinyLogisticSelectionCoefficient(const vector<double>& param,
						    const TreeSummary *treedata,
						    const long &whichparam);
};


class MigratePL:public PLForces
{
public:
  // migration related wait, and point functions
  // and derivatives of them
  MigratePL ()
  {
  };

  MigratePL (long thisnpop)
  {
    m_nPop = thisnpop;
    m_msum = CreateVec1d(m_nPop, static_cast<double>(0.0));
  };
  ~MigratePL ()
  {
  };
  virtual PLForces* Clone() const
  {
    return new MigratePL(*this);
  };
  double lnWait (const vector < double >&param, 
		 const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam, 
		  const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, 
		  const long &whichparam);
  double DlnPoint (const vector < double >&param,
		   const TreeSummary * treedata, 
		   const long &whichparam);

protected:
  DoubleVec1d m_msum;
  MigratePL(const MigratePL& src) :
    PLForces(src), m_msum(src.m_msum)
  {
  };

  
};


class RecombinePL:public PLForces
{
public:
  // recombination related wait, and point functions
  // and derivatives of them
  RecombinePL ()
  {
  };
  ~RecombinePL ()
  {
  };
  virtual PLForces* Clone() const
  {
    return new RecombinePL(*this);
  };
  double lnWait (const vector < double >&param, 
		 const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam,
		  const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, 
		  const long &whichparam);
  double DlnPoint (const vector < double >&param,
		   const TreeSummary * treedata, 
		   const long &whichparam);

protected:
  RecombinePL(const RecombinePL& src) :
    PLForces(src)
  {
  };

};

class SelectPL:public PLForces
{
public:
  // selection related wait, and point functions
  // and derivatives of them
  virtual PLForces* Clone() const
  {
    return new SelectPL(*this);
  };
  double lnWait (const vector < double >&param, 
		 const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam, 
		  const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, 
		  const long &whichparam);
  double DlnPoint (const vector < double >&param,
		   const TreeSummary * treedata, 
		   const long &whichparam);

protected:
  SelectPL(const SelectPL& src) :
    PLForces(src)
  {
  };

};

class CoalesceLogisticSelectionPL:public CoalescePL
{
protected:
  CoalesceLogisticSelectionPL(const CoalesceLogisticSelectionPL& src) :
    CoalescePL(src)
  {
  };
  long m_s_is_here;

public:

  ~CoalesceLogisticSelectionPL ()
  {

  };

  // perhaps move to the .cpp file?
  CoalesceLogisticSelectionPL (long thisnpop)
  {
    if (2 != thisnpop)
      {
	string msg = "Attempted to create a CoalesceLogisticSelectionPL object ";
	msg += "with " + ToString(thisnpop) + " populations.  This object can only ";
	msg += "be used with two populations, one for the favored allele and ";
	msg += "one for the disfavored allele.";
	throw implementation_error(msg);
      }
    m_nPop=thisnpop;
  };
  virtual PLForces* Clone() const
  {
    return new CoalesceLogisticSelectionPL(*this);
  };

  void SetSelectionCoefficientLocation(long paramvecindex)
  {
    m_s_is_here = paramvecindex;
  };

  double lnWait(const vector<double>& param, 
		const TreeSummary *treedata);
  double lnPoint(const vector<double>& param,
		 const vector<double>& lparam, 
		 const TreeSummary *treedata);
  double DlnWait(const vector<double>& param,
		 const TreeSummary *treedata, const long &whichparam);
  double DlnPoint(const vector<double>& param,
		  const TreeSummary *treedata, const long &whichparam);

 protected:
  double lnWaitForTinyLogisticSelectionCoefficient(const vector<double>& param,
						   const TreeSummary *treedata);
  double DlnWaitForTinyLogisticSelectionCoefficient(const vector<double>& param,
						    const TreeSummary *treedata,
						    const long &whichparam);
};

class LogisticSelectionPL:public PLForces
{
protected:
  LogisticSelectionPL(const LogisticSelectionPL& src) :
    PLForces(src)
  {
  };
  long m_s_is_here;

public:

  ~LogisticSelectionPL ()
  {

  };

  LogisticSelectionPL(long paramvecindex)
  {
    m_s_is_here = paramvecindex;
  };

  virtual PLForces* Clone() const
  {
    return new LogisticSelectionPL(*this);
  };

  double lnWait(const vector<double>& param, 
		const TreeSummary *treedata);
  double lnPoint(const vector<double>& param,
		 const vector<double>& lparam, 
		 const TreeSummary *treedata);
  double DlnWait(const vector<double>& param,
		 const TreeSummary *treedata, const long &whichparam);
  double DlnPoint(const vector<double>& param,
		  const TreeSummary *treedata, const long &whichparam);
 protected:
  double DlnWaitForTinyLogisticSelectionCoefficient(const vector<double>& param,
						    const TreeSummary *treedata,
						    const long &whichparam);
};

class StickLogSelectPL:public PLForces
{

public:
  // stair selection related wait, and point functions
  // and derivatives of them
  StickLogSelectPL(const ForceSummary& fs);
  virtual ~StickLogSelectPL();

  virtual PLForces* Clone() const
  {
    return new StickLogSelectPL(*this);
  };
  double lnWait (const vector < double >&param, 
		 const TreeSummary * treedata);
  double lnPoint (const vector < double >&param,
		  const vector < double >&lparam, 
		  const TreeSummary * treedata);
  double DlnWait (const vector < double >&param,
		  const TreeSummary * treedata, 
		  const long &whichparam);
  double DlnPoint (const vector < double >&param,
		   const TreeSummary * treedata, 
		   const long &whichparam);

  void SetThetastart(long start) {m_thetastart = start;};
  void SetThetaend(long end) {m_thetaend = end;};
  void SetForwardNu(long index);
  void SetBackwardMu(long index);
  void SetSelCoeff(long index) {m_s_here = index;};
  void SetRecRate(long index) {m_r_here = index;};
  void SetLocalPartForces(const ForceSummary& fs);

protected:
  long m_thetastart, m_thetaend;
  long m_mu_here;
  long m_nu_here;
  long m_s_here;
  long m_r_here;

// helper(s) used for stick selection
  double m_minuslnsqrt2pi;

// helper(s) used for disease
  DoubleVec1d m_msum;
  long m_disstart;
  long m_ndis;

// helpers(s) used for coalescence
  long m_nxparts;
  LongVec1d m_partindex;
  ForceVec m_localpartforces;
  // dim: force X xpart
  vector<vector<DoubleVec1d::size_type> > m_whichpart; 
  // dim: force X part X xpart-list
  vector<vector<vector<DoubleVec1d::size_type> > > m_whichxparts; 
  // dim: xpart
  vector<DoubleVec1d::size_type> m_whichmigpart; 

  StickLogSelectPL(const StickLogSelectPL& src) :
    PLForces(src), m_thetastart(src.m_thetastart),
    m_thetaend(src.m_thetaend), m_mu_here(src.m_mu_here),
    m_nu_here(src.m_nu_here), m_s_here(src.m_s_here)
  {
  };

  double StickMean(double freq, double s, double mu, double nu) const;
  double StickVar(double freq, double theta) const;
  double CommonFunctional(double freq, double prevfreq, double s,
      double mu, double nu, double length) const;

};


#endif /* #define PLFORCES_H */
