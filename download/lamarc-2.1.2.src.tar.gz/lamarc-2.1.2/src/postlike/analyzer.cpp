// analyzer.cpp
//
// the analyzer generates
// - profiles  [the code is in profile.cpp] 
// - likelihood surfaces
// - likelihood ratio tests
// 
// Peter Beerli November 2000
// $Id: analyzer.cpp,v 1.27 2005/08/19 21:41:38 lpsmith Exp $
//
/* 
   Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

   This software is distributed free of charge for non-commercial use
   and is copyrighted.  Of course, we do not guarantee that the software
   works, and are not responsible for any damage you may cause or have.
*/


#include "analyzer.h"
#include "forcesummary.h"
#include "mathx.h"          // for probchi
#include "registry.h"
#include "runreport.h"
#include "stringx.h"

using namespace std;

//////////////////////////////////////////////////////////////////
// Instantiate the Analyzer
// using the "last" postlike object, the Analyzer assumes that the 
// Prob(G|parameter_0) are already computed 
// [in likelihood.h:....PostLike::Setup()

Analyzer::Analyzer (ForceSummary &fs, const ParamVector& params, Maximizer * thismaximizer):
  m_maximizer(thismaximizer),
  m_forcesummary (fs)
{
  m_newparams = CreateVec1d(params.size(), static_cast<double>(0.0));
}

//__________________________________________________________________________

Analyzer::~Analyzer ()
{
};

void Analyzer::SetMLEs(DoubleVec1d newMLEs)
{
  m_MLEparams = newMLEs;
  m_MLElparams = m_MLEparams;
  LogVec0 (m_MLEparams, m_MLElparams);
}

//__________________________________________________________________________

void Analyzer::PrintMLEs()
{
  cout << "Current analyzer MLE's:" << endl;
  for (unsigned long i=0; i<m_MLEparams.size(); ++i)
    cout << m_MLEparams[i] << endl;
}
