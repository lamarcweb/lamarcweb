// $Id: plotstat.h,v 1.9 2006/03/31 21:49:55 jay Exp $

#ifndef PLOTSTAT_H
#define PLOTSTAT_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include <vector>
#include "vectorx.h"
#include <math.h>

class ForceSummary;
class Parameter;

enum plottype
{ log_ten, linear };
enum analysistype
{ mle, profile };

struct PlotStruct
{
public:Parameter * xaxis;
  Parameter *yaxis;
  DoubleVec2d plane;
};

class ProfileLineStruct
{
 public:
  // class variables
  ProfileLineStruct();
  ~ProfileLineStruct();
  double loglikelihood;
  double percentile;
  double profilevalue;
  DoubleVec1d profparam;
  bool isExtremeHigh;
  bool isExtremeLow;
  bool maximizerWarning;
};

class ProfileStruct
{
 public:
  // class variables
  vector < ProfileLineStruct > profilelines;
  
  // class methods
  const ProfileLineStruct& GetProfileLine(double percentile) const;
};

class LikeGraphs
{
public:LikeGraphs ()
  {
  };
  ~LikeGraphs ()
  {
  };

  string MakeBorder (long points, long breaks = 4);
  vector < string > MakeInnards (const DoubleVec2d & likes);
  vector < string > MakeLikePlot (const StringVec1d & innards,
				  const Parameter & paramX,
				  const Parameter & paramY, long breaks = 4);
  DoubleVec2d AddGraphs (const DoubleVec2d & a, const DoubleVec2d & b);

private:

  bool Divides (long x, long y);

};

#endif /* PLOTSTAT_H */
