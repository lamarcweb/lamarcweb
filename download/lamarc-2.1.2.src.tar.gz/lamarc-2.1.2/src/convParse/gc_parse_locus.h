#ifndef GC_PARSE_LOCUS_H
#define GC_PARSE_LOCUS_H

#include "gc_types.h"
#include "wx/string.h"

class GCParse;

class GCParseLocus
{
    private:
        GCParseLocus();     // undefined

        const GCParse *     m_parse;
        size_t              m_indexInParse;
        size_t              m_numMarkers;
        wxString            m_name;

    public:
        GCParseLocus(   const GCParse *     parse,
                        size_t              indexInParse,
                        size_t              numMarkers,
                        wxString            name);
        ~GCParseLocus();

        const GCParse &     GetParse()              const ;
        size_t              GetIndexInParse()       const ;
        size_t              GetNumMarkers()         const ;
        gcGeneralDataType   GetDataType()           const ;
        /*
        gcSpecificDataType  GetSpecificDataType()   const ;
        */
        wxString            GetName()               const ;

};

#endif
//GC_PARSE_LOCUS_H
