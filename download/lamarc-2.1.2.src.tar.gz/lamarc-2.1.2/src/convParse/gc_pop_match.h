#ifndef GC_POP_MATCH_H
#define GC_POP_MATCH_H

#include "gc_types.h"
#include "wx/arrstr.h"

class GCFile;
class GCParse;

class GCPopSpec
{
    private:
        bool            m_blessed;
        wxString        m_name;
        GCPopSpec();    // undefined
    public:
        GCPopSpec(bool blessed, wxString name);
        ~GCPopSpec();

        bool        GetBlessed()    const ;
        wxString    GetName()       const ;
};


class GCPopMatcher
{
    protected:
        pop_match       m_popMatchType;
        wxArrayString   m_popNames;
    public:
        GCPopMatcher();
        GCPopMatcher(pop_match popMatchType);
        GCPopMatcher(pop_match popMatchType, wxString name);
        GCPopMatcher(pop_match popMatchType, wxArrayString names);
        ~GCPopMatcher();
        GCPopSpec   GetPopSpec(size_t index, const GCParse &) const;
        bool        HandlesThisManyPops(size_t count) const;
        pop_match   GetPopMatchType() const ;

        const wxArrayString &   GetPopNames() const;
};

#endif
//GC_POP_MATCH_H
