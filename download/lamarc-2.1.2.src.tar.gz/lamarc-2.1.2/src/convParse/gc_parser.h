#ifndef GC_PARSER_H
#define GC_PARSER_H

#include "gc_types.h"
#include "wx/string.h"

class wxFileInputStream;
class wxTextInputStream;
class GCParseBlock;
class GCParseSample;


class GCParser
{
    private:
        GCParser();         // undefined

    protected:
        const GCDataStore &                 m_dataStore;
        size_t                              m_linesRead;
        wxFileInputStream *                 m_fileStreamPointer;
        wxTextInputStream *                 m_textStreamPointer;

        void SetUpStreams(wxString fileName);
        bool HasContent(const wxString&) const;
        wxString ReadLine(bool skipBlankLines=true);

        void CheckNoExtraData();

        void FillData              (GCParse&, size_t popIndex, size_t locIndex, GCInterleaving, size_t expectedSequences);
        void FillDataInterleaved   (GCParseBlock &,  GCParseLocus &, size_t expectedSequences);
        void FillDataNonInterleaved(GCParseBlock &,  GCParseLocus &, size_t expectedSequences);

        GCParseBlock &  AddBlock(   GCParse & , const GCParsePop &, const GCParseLocus &);
        GCParseLocus &  AddLocus(   GCParse & , size_t expectedIndex, size_t locusLength);
        GCParsePop &    AddPop(     GCParse & , size_t expectedIndex, wxString comment);
        GCParse &       MakeParse(  GCFile &            fileRef,
                                    GCFileFormat        format,
                                    gcGeneralDataType   dataType,
                                    GCInterleaving      interleaving,
                                    wxString            delimiter=wxEmptyString);
        GCParseSample & MakeSample( GCParseBlock &      block,
                                    size_t              indexInBlock,
                                    size_t              lineInFile,
                                    wxString            label);
        void AddDataToSample(GCParseSample &, GCParseLocus &, wxString data);
        void AddNucDataToSample(GCParseSample &, GCParseLocus &, wxString data);
        void AddAllelicDataToSample(GCParseSample &, GCParseLocus &, wxString data);
        wxArrayString makeKalleleTokens(wxString tokensTogether, wxString delim);

        void SetDataTypeFromFile(GCParse & parse, gcSpecificDataType type);


    public:
        GCParser(const GCDataStore&);
        virtual ~GCParser();

};

#endif
//GC_PARSER_H
