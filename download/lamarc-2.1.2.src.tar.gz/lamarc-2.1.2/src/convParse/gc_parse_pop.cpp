#include "gc_default.h"
#include "gc_parse_pop.h"

GCParsePop::GCParsePop( const GCParse * parse,
                        size_t          indexInParse,
                        wxString        name)
    :
        m_parse(parse),
        m_indexInParse(indexInParse),
        m_name(name)
{
    assert(m_parse != NULL);
}

GCParsePop::~GCParsePop()
{
}

const GCParse &
GCParsePop::GetParse() const
{
    return *m_parse;
}

size_t
GCParsePop::GetIndexInParse() const
{
    return m_indexInParse;
}

wxString
GCParsePop::GetName() const
{
    return m_name;
}
