#include "gc_default.h"
#include "gc_parse.h"
#include "gc_parse_locus.h"

GCParseLocus::GCParseLocus( const GCParse *     parse,
                            size_t              indexInParse,
                            size_t              numMarkers,
                            wxString            name)
    :
        m_parse(parse),
        m_indexInParse(indexInParse),
        m_numMarkers(numMarkers),
        m_name(name)
{
}

GCParseLocus::~GCParseLocus()
{
}

const GCParse &
GCParseLocus::GetParse() const
{
    return *m_parse;
}

size_t
GCParseLocus::GetIndexInParse() const
{
    return m_indexInParse;
}

size_t
GCParseLocus::GetNumMarkers() const
{
    return m_numMarkers;
}

gcGeneralDataType
GCParseLocus::GetDataType() const
{
    assert(m_parse != NULL);
    return m_parse->GetDataType();
}

/*
gcSpecificDataType
GCParseLocus::GetSpecificDataType() const
{
    assert(m_parse != NULL);
    return m_parse->GetDataTypeSpecFromFile();
}
*/

wxString
GCParseLocus::GetName() const
{
    return m_name;
}
