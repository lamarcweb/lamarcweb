#ifndef GC_SEQUENTIAL_DATA_H
#define GC_SEQUENTIAL_DATA_H

#include "gc_types.h"
#include "wx/arrstr.h"
#include "wx/string.h"

class GCParseBlock;
class GCParser;

class GCSequentialData
{

    private:
        GCParseBlock &          m_block;

    protected:
        GCSequentialData();     // undefined
        GCSequentialData(GCParseBlock &);
        GCParseBlock &    GetParseBlock();

    public:
        virtual ~GCSequentialData();

        virtual void        AddMarker(wxString data) = 0;
                void        CheckMarkerCount();
        virtual size_t      GetNumMarkers()  const = 0;
        virtual wxString    GetData() const = 0;
        virtual wxString    GetData(size_t siteIndex) const = 0;

        void    DebugDump(wxString prefix=wxEmptyString) const;
        const GCParseBlock &    GetParseBlock() const;
};

class GCAllelicData : public GCSequentialData
{
    private:
        wxArrayString           m_data;
    public:
        GCAllelicData();        // undefined
        GCAllelicData(GCParseBlock&);
        virtual ~GCAllelicData();

        void        AddMarker(wxString data);
        size_t      GetNumMarkers() const;
        wxString    GetData() const;
        wxString    GetData(size_t siteIndex) const;

};

class GCNucData : public GCSequentialData
{
    private:
        wxString                m_data;
    public:
        GCNucData();            // undefined
        GCNucData(GCParseBlock&);
        virtual ~GCNucData();

        void        AddMarker(wxString data);
        size_t      GetNumMarkers() const;
        wxString    GetData() const;
        wxString    GetData(size_t siteIndex) const;
};



#endif
//GC_SEQUENTIAL_DATA_H
