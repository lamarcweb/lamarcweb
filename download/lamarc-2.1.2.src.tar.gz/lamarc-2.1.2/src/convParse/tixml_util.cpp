#include "errhandling.h"
#include "tinyxml.h"
#include "tixml_util.h"
#include "cnv_strings.h"




TiXmlElement *
ti_singleElement(TiXmlElement* ancestor, wxString nodeName,bool required)
{
    TiXmlNode * firstChild = ancestor->IterateChildren(nodeName,NULL);
    if(firstChild == NULL)
    {
        if(required)
        {
            wxString msg = wxString::Format(cnvstr::ERR_MISSING_TAG,nodeName.c_str());
            incorrect_xml e(msg.c_str());
            throw e;
        }
        return NULL;
    }
    TiXmlNode * secondChild = ancestor->IterateChildren(nodeName,firstChild);
    if (secondChild != NULL)
    {
        wxString msg = wxString::Format(cnvstr::ERR_EXTRA_TAG,nodeName.c_str());
        incorrect_xml e(msg.c_str());
        throw e;
        return NULL;
    }
    return firstChild->ToElement();
}

TiXmlElement *
ti_optionalChild(TiXmlElement* ancestor, wxString nodeName)
{
    return ti_singleElement(ancestor,nodeName,false);
}


TiXmlElement *
ti_requiredChild(TiXmlElement* ancestor, wxString nodeName)
{
    return ti_singleElement(ancestor,nodeName,true);
}

wxString
ti_nodeText(TiXmlElement * node)
{
    wxString outstring;
    TiXmlNode * child = NULL;
    while((child = node->IterateChildren(child)))
    {
        TiXmlHandle handle(child);
        if(handle.Text())
        {
            outstring += child->Value();
        }
    }
    outstring.Trim(true);
    outstring.Trim(false);
    return outstring;
}


wxString
ti_attributeValue(TiXmlElement * node, wxString attrName)
{
    const char * attrValue = node->Attribute(attrName);
    if(attrValue)
    {
        return wxString(attrValue);
    }
    else
    {
        return "";
    }

}

double
ti_double_from_text(TiXmlElement * node)
{
    wxString nodeText = ti_nodeText(node);
    double value;
    if(!nodeText.ToDouble(&value))
    {
        wxString msg = wxString::Format(cnvstr::ERR_NOT_DOUBLE,nodeText.c_str());
        incorrect_xml e(msg.c_str());
        throw e;
    }
    return value;
}

long
ti_long_from_text(TiXmlElement * node) throw(incorrect_xml)
{
    wxString nodeText = ti_nodeText(node);
    long value;
    if(!nodeText.ToLong(&value))
    {
        wxString msg = wxString::Format(cnvstr::ERR_NOT_LONG,nodeText.c_str());
        incorrect_xml e(msg.c_str());
        throw e;
    }
    return value;
}

size_t
ti_size_t_from_text(TiXmlElement * node) throw(incorrect_xml)
{
    long value = ti_long_from_text(node);
    if(value < 0)
    {
        wxString msg = wxString::Format(cnvstr::ERR_NOT_SIZE_T,value);
        incorrect_xml e(msg.c_str());
        throw e;
    }
    return (size_t)value;
}

std::vector<TiXmlElement *>
ti_optionalChildren(TiXmlElement* ancestor, wxString nodeName)
{
  std::vector<TiXmlElement *> returnVec;
  TiXmlNode * child = NULL;
  while((child = ancestor->IterateChildren(nodeName, child))) {
   returnVec.push_back(child->ToElement());
  }
  return returnVec;
}


std::vector<TiXmlElement *>
ti_requiredChildren(TiXmlElement* ancestor, wxString nodeName)
{
  std::vector<TiXmlElement *> returnVec = ti_optionalChildren(ancestor,nodeName);
  if(returnVec.empty())
  {
    wxString msg = wxString::Format(cnvstr::ERR_MISSING_TAG,nodeName.c_str());
    incorrect_xml e(msg.c_str());
    throw e;
  }
  return returnVec;
}

