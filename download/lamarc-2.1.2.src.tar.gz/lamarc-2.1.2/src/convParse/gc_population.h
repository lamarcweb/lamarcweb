#ifndef GC_POPULATION_H
#define GC_POPULATION_H

#include "gc_quantum.h"
#include "wx/string.h"

class GCStructures;

class GCPopulation : public GCQuantum
{
    friend class GCStructures;

    private:
        bool                    m_blessed;

        void    SetBlessed(bool blessed);
    public:
        GCPopulation();
        virtual ~GCPopulation();

        bool          GetBlessed()        const ;
        void          DebugDump(wxString prefix=wxEmptyString) const;

};

#endif
//GC_POPULATION_H
