#ifndef GC_MIGRATE_H
#define GC_MIGRATE_H

#include "gc_parser.h"
#include "gc_types.h"

class GCFile;


class GCMigrateParser : public GCParser
{
    private:
        GCMigrateParser();  // undefined
    protected:
        void    ParseMigrateFirstLine(  
                                        gcSpecificDataType& dataTypeSpecInFile,
                                        size_t &            numPops,
                                        size_t &            numLoci,
                                        wxString &          populationName);
        void    ParseMigrateFirstLine(  
                                        gcSpecificDataType& dataTypeSpecInFile,
                                        size_t &            numPops,
                                        size_t &            numLoci,
                                        wxString &          delimiter,
                                        wxString &          populationName);

        std::vector<size_t> ParseMigratePopulationInfo(wxString & popName, size_t numLoci);
        std::vector<size_t> ParseMigrateLocusLengths();

        GCParse * NucParse(     GCFile &        fileRef,
                                gcGeneralDataType   dataType,
                                GCInterleaving  interleaving);
        GCParse * AlleleParse(  GCFile &            fileRef,
                                gcGeneralDataType   dataType,
                                GCInterleaving      interleaving);

        bool            IsLegalDelimiter(wxString delimCandidate);
    public:
        GCMigrateParser(const GCDataStore& dataStore);
        virtual ~GCMigrateParser();

        GCParse * Parse(GCFile &            fileRef,
                        gcGeneralDataType   dataType,
                        GCInterleaving      interleaving);
};


#endif
//GC_MIGRATE_H
