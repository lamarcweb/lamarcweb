#ifndef GC_PARSE_POP_H
#define GC_PARSE_POP_H

#include "wx/string.h"

class GCParse;

class GCParsePop
{
    private:
        GCParsePop();           // undefined

        const GCParse *         m_parse;
        const size_t            m_indexInParse;
        const wxString          m_name;
    public:
        GCParsePop(const GCParse * parse, size_t indexInParse, wxString name);
        ~GCParsePop();

        const GCParse & GetParse()          const;
        size_t          GetIndexInParse()   const;
        wxString        GetName()           const;

};

#endif
//GC_PARSE_POP_H
