#include "gc_population.h"
#include "gc_strings_pop.h"
#include "wx/log.h"


GCPopulation::GCPopulation()
    :   
        m_blessed(false)
{
    SetName(wxString::Format(gcstr_pop::internalName,(long)GetId()));
}

GCPopulation::~GCPopulation()
{
}

bool
GCPopulation::GetBlessed() const
{
    return m_blessed;
}

void
GCPopulation::SetBlessed(bool blessed)
{
    m_blessed = blessed;
}

void
GCPopulation::DebugDump(wxString prefix) const
{
    wxLogDebug("%spopulation %s (pop id %ld)",  // EWDUMPOK
                prefix.c_str(),
                GetName().c_str(),
                (long)GetId());
}

