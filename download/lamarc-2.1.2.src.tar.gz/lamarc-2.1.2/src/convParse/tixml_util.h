#ifndef TIXML_UTIL_H
#define TIXML_UTIL_H

#include "errhandling.h"
#include "wx/string.h"

#include <string>
#include <vector>

class TiXmlElement;


TiXmlElement *          ti_singleElement(TiXmlElement* ancestor, wxString nodeName,bool required);
TiXmlElement *          ti_optionalChild(TiXmlElement* ancestor, wxString nodeName);
TiXmlElement *          ti_requiredChild(TiXmlElement* ancestor, wxString nodeName);
wxString                ti_nodeText(TiXmlElement *);
wxString                ti_attributeValue(TiXmlElement*,wxString attributeName);

double                  ti_double_from_text(TiXmlElement *);
long                    ti_long_from_text(TiXmlElement *) throw (incorrect_xml);
size_t                  ti_size_t_from_text(TiXmlElement *) throw (incorrect_xml);

std::vector<TiXmlElement *>  ti_optionalChildren(TiXmlElement* ancestor, wxString nodeName);
std::vector<TiXmlElement *>  ti_requiredChildren(TiXmlElement* ancestor, wxString nodeName);


#endif
// TIXML_UTIL_H
