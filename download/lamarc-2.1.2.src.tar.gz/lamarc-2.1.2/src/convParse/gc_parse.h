#ifndef GC_PARSE_H
#define GC_PARSE_H

#include "gc_phase_info.h"
#include "gc_quantum.h"
#include "gc_structure_maps.h"
#include "gc_types.h"
#include "wx/string.h"
#include <vector>

class GCDataStore;
class GCFile;
class GCParseBlock;
class GCParseLocus;
class GCParsePop;
class GCParser;


typedef std::vector<GCParseBlock*>  GCParseBlocks;
typedef std::vector<GCParsePop*>    GCParsePops;
typedef std::vector<GCParseLocus*>  GCParseLoci;

class GCParse : public GCQuantum
{
    friend class GCParser;
    friend class GCParseVec;
    private:
        const GCFile *      m_filePointer;      // we don't own this
        GCFileFormat        m_format;
        gcGeneralDataType   m_dataType;
        GCInterleaving      m_interleaving;
        wxString            m_delimiter;
        bool                m_multiLineSeenInFile;
        bool                m_hasSpacesInNames;
        GCParsePops         m_pops;             // we own the contents
        GCParseLoci         m_loci;             // we own the contents
        GCParseBlocks       m_blocks;           // we own the contents

        GCParse();      // undefined

    protected:
        GCParseLocus &      GetParseLocus(size_t locusIndex) ;
        void                SetDataTypeFromFile(gcSpecificDataType dtype);
        void                SetHasSpacesInNames();

    public:
        GCParse(    GCFile &            fileRef, 
                    GCFileFormat        format,
                    gcGeneralDataType   dataType,
                    GCInterleaving      interleaving,
                    wxString            delim=wxEmptyString);
        ~GCParse();


        wxString                GetSettings()   const;
        gcGeneralDataType       GetDataType()   const ;
        GCFileFormat            GetFormat()     const ;
        GCInterleaving          GetInterleaving() const ;
        wxString                GetDelimiter()  const ;
        bool                    GetMultiLineSeenInFile() const ;
        virtual wxString        GetName() const;
        const GCParseLocus &    GetParseLocus(size_t locusIndex) const ;
        const GCParsePop   &    GetParsePop  (size_t popIndex)   const;

        constBlockVector        GetBlocks() const;
        const GCParseBlock &    GetBlock(size_t popId, size_t locusId) const;

        const GCFile &          GetFileRef()    const ;
        size_t                  GetPopCount()   const ;
        size_t                  GetLociCount()  const ;
        bool                    GetHasSpacesInNames() const;

        void DebugDump(wxString prefix=wxEmptyString) const;

        gcIdSet     IdsOfAllBlocks() const;

        wxString    GetFormatString() const;
        wxString    GetDataTypeString() const;
        wxString    GetInterleavingString() const;

        gcPhaseInfo *   GetDefaultPhaseRecords() const;
        gcPhaseInfo *   GetPhaseRecordsForAdjacency(size_t adj) const;

        void    SetCannotBeMsat();
};

class GCParseVec : public std::vector<GCParse*>
{
    private:
        bool MungeParses(GCParseVec::iterator,GCParseVec::iterator);
    public:
        GCParseVec();
        virtual ~GCParseVec();
        bool MungeParses();
        void NukeContents();
};

#endif
//GC_PARSE_H
