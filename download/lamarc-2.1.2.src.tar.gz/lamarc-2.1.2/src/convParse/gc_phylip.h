#ifndef GC_PHYLIP_H
#define GC_PHYLIP_H

#include "gc_parser.h"
#include "gc_types.h"

class GCFile;
class GCParse;

class GCPhylipParser : public GCParser
{
    private:
        GCPhylipParser();           // undefined
    protected:
        void ParseTopPhylipLine(size_t              *   numSequences,
                                size_t              *   numSites,
                                bool                *   hasWeights);
        bool ParsePhylipWeightsLine(size_t numSites, wxString fileName);
    public:
        GCPhylipParser(const GCDataStore&);
        virtual ~GCPhylipParser();


        GCParse * Parse(GCFile &            fileRef,
                        gcGeneralDataType   dataType,
                        GCInterleaving      interleaving);

        void BadFirstToken  (wxString token) const;
        void BadSecondToken (wxString token) const;
};

#endif
//GC_PHYLIP_H
