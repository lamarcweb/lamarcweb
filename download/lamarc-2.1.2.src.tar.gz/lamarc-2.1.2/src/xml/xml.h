//$Id: xml.h,v 1.48 2007/02/08 22:25:47 ewalkup Exp $

#ifndef XML_H
#define XML_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "parsetreeschema.h"
#include "tinyxml.h"

using std::string;

/******************************************************************
 This class reads the data file, including both molecular data and
 option settings, and produces a Tiny XML parse tree of the contents.
 It does not process those contents. Instead they are read by
 classes ParseTreeToData and ParseTreeToSettings, which walk the
 TinyXML tree this class generates.

*********************************************************************/


class XmlErrorSupport
{
    protected:
        string m_fileName;
        string m_errorMessage;

        XmlErrorSupport();          // undefined

    public:
        XmlErrorSupport(string fileName);
        virtual ~XmlErrorSupport();

        string      GetFileName();
        void        ThrowDataError(const string& reason);
        void        ThrowDataError(const string& reason, long lineno);
        void        ThrowFileError(const string& reason);
        void        ThrowInternalXMLError(const string& reason);
        void        ThrowXMLError(const string& reason);
        void        ThrowXMLError(const string& reason, long lineno);
};

class FrontEndWarnings;

class XmlParser : public XmlErrorSupport
{
    private:
        XmlParser();        // undefined

        TiXmlDocument       m_document;
        ParseTreeSchema &   m_schema;
        FrontEndWarnings &  m_frontEndWarnings;

    protected:
        void checkAttrAllowed(TiXmlElement * elem, string attrName);
        void checkAttrPresent(TiXmlElement * elem, string attrName);
        void checkElemCount(TiXmlElement * elem, string childName);
        void checkElemPresent(TiXmlElement * elem, string elemName);
        void checkSchema(TiXmlElement *);
        void checkSchema();


    public:
        XmlParser(ParseTreeSchema & schema, FrontEndWarnings & warnings);
        virtual ~XmlParser();
        void ParseFileData(string fileName);   // builds TiXML structures
        TiXmlElement * GetRootElement();
};

#endif /* XML_H */
