//$Id: parsetreewalker.h,v 1.7 2006/03/30 21:50:05 ewalkup Exp $

#ifndef PARSETREEWALKER_H
#define PARSETREEWALKER_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "vectorx.h"    // for StringVec1d
#include "xml.h"

class TiXmlElement;
class ParseTreeSchema;

using std::string;


// class implements methods shared by 
//      ParseTreeToData     -- which parses everything under <data> tag
//      ParseTreeToSettings -- which parses everything else
// methods are utility methods for finding a child tag of a specific
// name, and getting attribute text or text between tags, etc.
class ParseTreeWalker 
{
    private:
        ParseTreeWalker();      // undefined

    protected:
        XmlParser &     m_parser;

        TiXmlElement *  getSingleDescendantElement(TiXmlElement* ancestor, string nodeName,bool required);
 vector<TiXmlElement *> getAllOptionalDescendantElements(TiXmlElement* ancestor,
                                                         string nodeName);
        TiXmlElement *  singleOptionalChild(TiXmlElement* ancestor, string nodeName);
        TiXmlElement *  singleRequiredChild(TiXmlElement* ancestor, string nodeName);
        string          getNodeText(TiXmlElement *);
        StringVec1d     getNodeTextSplitOnWhitespace(TiXmlElement *);
        string          getNodeAttributeValue(TiXmlElement*,string attributeName);

        void            checkSchema(TiXmlElement * topElem, ParseTreeSchema&);
    public:
        ParseTreeWalker(XmlParser & parser);
        virtual ~ParseTreeWalker();
};

#endif /* PARSETREEWALKER_H */
