//$Id: toxml.cpp,v 1.15 2007/05/04 23:47:51 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "toxml.h"
#include "stringx.h"      // for MakeTag/MakeIndent/etc in foo::ToXML()
#include "xml_strings.h"  // for xmlstr::foo in foo::ToXML()
#include "registry.h"     // for GetForceSummary in SampleXML::ToXML()
#include "forcesummary.h" // for GetForceByTag in SampleXML::ToXML()
#include "force.h"        // for PartitionForce in SampleXML::ToXML()
#include "region.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;

//___________________________________________________________________________
//___________________________________________________________________________

PopulationXML::PopulationXML(const Region& region, const string& name)
   : m_name(name)
{
// break out population-specific vector<tipdata>
vector<TipData> popdata;
long loc;
for(loc = 0; loc < region.GetNloci(); ++loc) {
   vector<TipData> locpopdata(region.GetLocus(loc).
      GetPopulationTipData(m_name));
   popdata.insert(popdata.end(),locpopdata.begin(),locpopdata.end());
}

// pass them to Individual ctor
long ind;
for(ind = 0; ind < region.GetNIndividuals(); ++ind)
   if (IndividualIsIn(popdata, ind))
      m_individuals.push_back(IndividualXML(region,popdata,ind));

} /* PopulationXML::ctor */

//___________________________________________________________________________

bool PopulationXML::IndividualIsIn(const vector<TipData>& popdata, long whichind) const
{
vector<TipData>::const_iterator tip;
for(tip = popdata.begin(); tip != popdata.end(); ++tip)
   if (tip->BelongsTo(whichind)) return true;

return false;

} /* PopulationXML::IndividualIsIn */

//___________________________________________________________________________

StringVec1d PopulationXML::ToXML(unsigned long nspaces) const
{
assert(!m_name.empty());
StringVec1d xmllines;

string line = MakeIndent(MakeTagWithName(xmlstr::XML_TAG_POPULATION,m_name),nspaces);
xmllines.push_back(line);

nspaces += INDENT_DEPTH;
vector<IndividualXML>::const_iterator ind;
for(ind = m_individuals.begin(); ind != m_individuals.end(); ++ind) {
   StringVec1d indxml(ind->ToXML(nspaces));
   xmllines.insert(xmllines.end(),indxml.begin(),indxml.end());
}
nspaces -= INDENT_DEPTH;

line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_POPULATION),nspaces);
xmllines.push_back(line);

return xmllines;
} /* PopulationXML::ToXML */

//___________________________________________________________________________
//___________________________________________________________________________

IndividualXML::IndividualXML(const Region& region,
                             const vector<TipData>& popdata, long whichind)
  : m_name(region.GetIndividual(whichind).GetName()),
    m_phases(region.GetIndividual(whichind).GetPhaseSites()),
    m_individual(region.GetIndividual(whichind))
{
  // break out individual-specific vector<tipdata>
  vector<TipData> inddata;
  vector<TipData>::const_iterator tip;
  for(tip = popdata.begin(); tip != popdata.end(); ++tip) {
    if (tip->BelongsTo(whichind)) inddata.push_back(*tip);
  }

  // parse into haplotypes
  long biggest(FLAGLONG);
  vector<TipData>::iterator hap;
  //Find out how many haplotypes there are
  for(hap = inddata.begin(); hap != inddata.end(); ++hap) {
    if (hap->m_hap > biggest) {
      biggest = hap->m_hap;
    }
  }
  vector<vector<TipData> > haps(biggest+1);
  vector<TipData>          traits;
  for(hap = inddata.begin(); hap != inddata.end(); ++hap) {
    if (!hap->m_nodata) {
      //We don't have Samples for m_nodata tips.
      haps[hap->m_hap].push_back(*hap);
    }
  }

  // pass the haplotypes to Sample ctor
  vector<vector<TipData> >::iterator hapit;
  for(hapit = haps.begin(); hapit != haps.end(); ++hapit) {
    m_samples.push_back(SampleXML(region,*hapit));
  }

} /* IndividualXML::ctor */

//___________________________________________________________________________

StringVec1d IndividualXML::ToXML(unsigned long nspaces) const
{
  assert(!m_name.empty() && !m_phases.empty());
  StringVec1d xmllines;

  string line = MakeIndent(MakeTagWithName(xmlstr::XML_TAG_INDIVIDUAL,m_name),nspaces);
  xmllines.push_back(line);

  nspaces += INDENT_DEPTH;

  if (!m_phases.empty()) {
    bool hasAnyPhaseData = false;
    LongVec2d::const_iterator phaseIter;
    for(phaseIter=m_phases.begin(); phaseIter != m_phases.end(); phaseIter++)
    {
      if((*phaseIter).size() > 0)
      {
        hasAnyPhaseData = true;
        break;
      }
    }
    if(hasAnyPhaseData) {
      LongVec2d::const_iterator locus;
      for(locus = m_phases.begin(); locus != m_phases.end(); ++locus) {
        line = MakeIndent(MakeTagWithType(xmlstr::XML_TAG_PHASE,
                                          xmlstr::XML_ATTRVALUE_UNKNOWN),nspaces);
        xmllines.push_back(line);
        nspaces += INDENT_DEPTH;
        line = MakeIndent(ToString(*locus),nspaces);
        xmllines.push_back(line);
        nspaces -= INDENT_DEPTH;
        line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_PHASE),nspaces);
        xmllines.push_back(line);
      }
    }
  }

  StringVec1d traitxml = m_individual.GetTraitXML(nspaces);
  xmllines.insert(xmllines.end(), traitxml.begin(), traitxml.end());
  
  vector<SampleXML>::const_iterator sample;
  for(sample = m_samples.begin(); sample != m_samples.end(); ++sample) {
    StringVec1d samplexml(sample->ToXML(nspaces));
    xmllines.insert(xmllines.end(),samplexml.begin(),samplexml.end());
  }
  nspaces -= INDENT_DEPTH;

  line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_INDIVIDUAL),nspaces);
  xmllines.push_back(line);

  return xmllines;
} /* IndividualXML::ToXML */

//___________________________________________________________________________
//___________________________________________________________________________

SampleXML::SampleXML(const Region& region, const vector<TipData>& loci) :
  m_stati(loci[0].partitions)
{
  vector<TipData>::const_iterator loc;
  for(loc = loci.begin(); loc != loci.end(); ++loc) {
    assert(m_stati == loc->partitions);
    DataType_ptr mydatatype(region.GetLocus(loc->m_locus).GetDataTypePtr());
    m_geneticdatatype.push_back(mydatatype->GetXMLTag());
    m_geneticdata.push_back(loc->GetFormattedData(mydatatype->GetDelimiter()));
  }
  // JDEBUG--is this an appropiate name?
  m_name = loci[0].label;

} /* SampleXML::ctor */

//___________________________________________________________________________

StringVec1d SampleXML::ToXML(unsigned long nspaces) const
{
  assert(!m_name.empty() && !m_geneticdata.empty());
  StringVec1d xmllines;

  string line = MakeIndent(MakeTagWithName(xmlstr::XML_TAG_SAMPLE,m_name),nspaces);
  xmllines.push_back(line);
  nspaces += INDENT_DEPTH;
  StringVec1d::const_iterator gdata, gtype;
  assert(m_geneticdata.size() == m_geneticdatatype.size());
  for(gdata = m_geneticdata.begin(), gtype = m_geneticdatatype.begin();
      gdata != m_geneticdata.end(); ++gdata, ++gtype) {
    line = MakeIndent(MakeTagWithType(xmlstr::XML_TAG_DATABLOCK,*gtype),nspaces);
    xmllines.push_back(line);
    nspaces += INDENT_DEPTH;
    xmllines.push_back(MakeIndent(*gdata,nspaces));
    nspaces -= INDENT_DEPTH;
    line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_DATABLOCK),nspaces);
    xmllines.push_back(line);
  }
  // JDEBUG -- evil kludgy if-code to handle the fact that migration partitions are
  // handled differently from all other partitions in the xml
  if (m_stati.size() > 1 || (m_stati.size() == 1 && m_stati.find(force_MIG) == m_stati.end())) {
    line = MakeIndent(MakeTag(xmlstr::XML_TAG_STATUS),nspaces);
    xmllines.push_back(line);
    nspaces += INDENT_DEPTH;
    map<force_type,string>::const_iterator status;
    for(status = m_stati.begin(); status != m_stati.end(); ++status) {
      line = dynamic_cast<PartitionForce*>
        ( *(registry.GetForceSummary().GetForceByTag(status->first)) )->
        MakeStatusXML(status->second);
      
      if (!line.empty())
        xmllines.push_back(MakeIndent(line,nspaces));
    }
    nspaces -= INDENT_DEPTH;
    line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_STATUS),nspaces);
    xmllines.push_back(line);
  }
  nspaces -= INDENT_DEPTH;
  line = MakeIndent(MakeCloseTag(xmlstr::XML_TAG_SAMPLE),nspaces);
  xmllines.push_back(line);

  return xmllines;
} /* SampleXML::ToXML */

//___________________________________________________________________________
