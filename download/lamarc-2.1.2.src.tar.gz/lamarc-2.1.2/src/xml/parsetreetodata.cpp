//$Id: parsetreetodata.cpp,v 1.37 2007/05/03 20:10:15 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

//#include <iostream>
//#include <limits.h>   // for numeric limits info
#include "datapack.h"
#include "datatype.h" // to set the datatype of a region and to proofread data
#include "errhandling.h"
#include "newick.h"   // for UserTree and subclasses thereof
#include "parsetreetodata.h"
#include "random.h"
#include "region.h"
#include "registry.h"
#include "stringx.h"
#include "timex.h"
#include "types.h"  // for access to DataType's auto_ptr type
#include "xml.h"
#include "xml_strings.h"


using std::string;

//__________________________________________________________

ParseTreeToData::ParseTreeToData(XmlParser& parser, DataPack& dp)
    :
        ParseTreeWalker(parser),
        datapack(dp),
        m_pCurrRegion(NULL),
        m_currpopulation(FLAGLONG),
        m_currindno(FLAGLONG),
        m_randomNameSource(new Random())
{
    m_randomNameSource->Seed(GetTime());
}


ParseTreeToData::~ParseTreeToData()
{
}


string
ParseTreeToData::XmlRandomLongAsString()
{
    return ToString(m_randomNameSource->Long());
}


void
ParseTreeToData::ProcessFileData()
{

  const char * tagValue = m_parser.GetRootElement()->Value();
  string tagString(tagValue);
  bool matches = CaselessStrCmp(xmlstr::XML_TAG_LAMARC,tagValue);
  if(!matches)
  {
      string msg = m_parser.GetFileName() + ": " + xmlstr::XML_ERR_NOT_LAMARC;
      m_parser.ThrowDataError(msg);
  }

  TiXmlElement* format = singleOptionalChild(m_parser.GetRootElement(),xmlstr::XML_TAG_FORMAT);
  if (format != NULL) {
    DoFormat(format);
  }
  DoData(singleRequiredChild(m_parser.GetRootElement(),xmlstr::XML_TAG_DATA));

  // now do some post-analysis of data
  // at the moment this checks if there are multiple pops, and if
  // there aren't it removes population info from the stored tips
  datapack.RemoveUneededPartitions();

} 

void
ParseTreeToData::DoFormat(TiXmlElement * formatElement)
{
  TiXmlElement* convertElement = singleOptionalChild(formatElement, xmlstr::XML_TAG_CONVERT_OUTPUT);
  if (convertElement != NULL) {
    string convert = getNodeText(convertElement);
    registry.SetConvertOutputToEliminateZeroes(ProduceBoolOrBarf(convert));
  }
}

void
ParseTreeToData::DoData(TiXmlElement * dataElement)
{

    TiXmlNode * child = NULL;
    long regionNumber = 0;


    while((child = dataElement->IterateChildren(xmlstr::XML_TAG_REGION,child)))
    {
        TiXmlElement * regionElement = child->ToElement();
        DoRegion(regionElement,regionNumber);
        regionNumber++;
    }

} /* DoData */


void 
ParseTreeToData::DoRegion(TiXmlElement * regionElement, long regionId)
{

    // set up a region 
    string regname = getNodeAttributeValue(regionElement,xmlstr::XML_ATTRTYPE_NAME);
    if (datapack.IsDuplicateRegionName(regname)) {
	    string problem(xmlstr::XML_ERR_DUPLICATE_REGIONNAME_0);
	    problem += regname + xmlstr::XML_ERR_DUPLICATE_REGIONNAME_1;
	    m_parser.ThrowDataError(problem);
    }
    m_pCurrRegion = new Region(regname);
    datapack.SetRegion(m_pCurrRegion);
    m_currindno = 0;

    DoPopulations(regionElement);

    DoSpacing(singleOptionalChild(regionElement,xmlstr::XML_TAG_SPACING));

    DoPhases(regionElement);

    DoEffectivePopSize(
       singleOptionalChild(regionElement,xmlstr::XML_TAG_EFFECTIVE_POPSIZE)
    );

    TiXmlElement * treeElement 
        = singleOptionalChild(regionElement,xmlstr::XML_TAG_TREE);
    if (treeElement != NULL)
    {
        m_pCurrRegion->SetUserTree(DoTree(treeElement));
    }

    string errorString;
    if (!m_pCurrRegion->IsValid(errorString)) 
    { 
        m_parser.ThrowDataError(xmlstr::XML_ERR_INCONSISTENT_REGION + 
                m_pCurrRegion->GetRegionName()
                + xmlstr::XML_STRING_COLON + errorString
                , regionElement->Row());
    }

} // DoRegion



void 
ParseTreeToData::DoPopulations(TiXmlElement* regionElement)
{

    TiXmlNode * child = NULL;
    while((child = regionElement->IterateChildren(xmlstr::XML_TAG_POPULATION,child)))
    {
        TiXmlElement * populationElement = child->ToElement();
        DoPopulation(populationElement);
    }
}

void 
ParseTreeToData::DoPopulation(TiXmlElement * populationElement)
{
    string popname = getNodeAttributeValue(populationElement,xmlstr::XML_ATTRTYPE_NAME);
    m_currpopulation = datapack.AddPartition(force_MIG,popname);

    TiXmlNode * child = NULL;
    while((child = populationElement->IterateChildren(xmlstr::XML_TAG_INDIVIDUAL,child)))
    {
        TiXmlElement * individualElement = child->ToElement();
        DoIndividual(individualElement);
    }
} 


void 
ParseTreeToData::DoIndividual(TiXmlElement * individualElement)
{

  Individual newind;
  m_currIndividual = newind; //barring a .clear() function or the like.
  m_currIndividual.SetId(m_currindno);

  string name = getNodeAttributeValue(individualElement,xmlstr::XML_ATTRTYPE_NAME);
  if (name.empty())
  {
    name = ToString(m_currindno);
  }
  m_currIndividual.SetName(name);

  DoSamples(individualElement);

  DoGenotypeResolutions(individualElement);
  m_pCurrRegion->AddIndividual(m_currIndividual);

  m_currindno++;
}

//__________________________________________________________

void 
ParseTreeToData::DoSamples(TiXmlElement * individualElement) 
{
    long whichhap = 0;
    TiXmlNode * child = NULL;
    vector<TiXmlElement*> samples = getAllOptionalDescendantElements(individualElement, xmlstr::XML_TAG_SAMPLE);
    m_pCurrRegion->AddPloidy(samples.size());
    while((child = individualElement->IterateChildren(xmlstr::XML_TAG_SAMPLE,child)))
    {
        TiXmlElement * sampleElement = child->ToElement();
        string name = getNodeAttributeValue(sampleElement,xmlstr::XML_ATTRTYPE_NAME);
       if (name.empty()) 
            name = m_currIndividual.GetName() + XmlRandomLongAsString();
        if (m_pCurrRegion->IsDuplicateTipName(name)) {
	    string problem(xmlstr::XML_ERR_DUPLICATE_SAMPLENAME_0);
	    problem += name + xmlstr::XML_ERR_DUPLICATE_SAMPLENAME_1;
	    problem += m_pCurrRegion->GetRegionName();
	    m_parser.ThrowDataError(problem);
        }
        m_tipdata.Clear();  // prepare m_tipdata for new data
        m_tipdata.label = name;
        m_tipdata.AddPartition(
           std::make_pair(force_MIG,datapack.GetPartitionName(force_MIG,m_currpopulation))
                                 );
	m_tipdata.m_popname = datapack.GetPartitionName(force_MIG,
           m_currpopulation);  // JDEBUG--we redundantly store this because
       // the partitions of AddPartition are for branch use and don't
       // treat migration specially--this one is for xml output use
       // which currently still does treat migration specially from
       // other partitions (<status> in xml terms).
        m_tipdata.individual = m_currIndividual.GetId();
	m_tipdata.m_hap = whichhap;

        DoStatus(singleOptionalChild(sampleElement,xmlstr::XML_TAG_STATUS));
        DoDataBlocks(sampleElement);	++whichhap;
    }
} /* DoSamples */

//__________________________________________________________

void 
ParseTreeToData::DoStatus(TiXmlElement * statusElement)
{
    if(statusElement != NULL)
    {
        TiXmlNode * child = NULL;
        while((child = statusElement->IterateChildren(xmlstr::XML_TAG_DISEASESTATUS,child)))
        {
            TiXmlElement * diseaseElement = child->ToElement();
            DoDisease(diseaseElement);
        }
    }
} /* DoStatus */

//__________________________________________________________

void 
ParseTreeToData::DoDisease(TiXmlElement * diseaseElement)
{

// remove leading whitespace from dstatus
  string dstatus = getNodeText(diseaseElement);
  string whitespace(" ");
  long firstnonwhite = dstatus.find_first_not_of(whitespace);
  dstatus.assign(dstatus,firstnonwhite,dstatus.length()-firstnonwhite);

  datapack.AddPartition(force_DISEASE,dstatus);
  m_tipdata.AddPartition(std::make_pair(force_DISEASE,dstatus));

} /* DoDisease */

//__________________________________________________________

void 
ParseTreeToData::DoDataBlocks(TiXmlElement * sampleElement) {

    long locus = 0;

    TiXmlNode * child = NULL;
    while((child = sampleElement->IterateChildren(xmlstr::XML_TAG_DATABLOCK,child)))
    {
        TiXmlElement * dataBlockElement = child->ToElement();

        // if this is a new locus, add it to the Region
        if (locus == m_pCurrRegion->GetNloci()) {
          m_pCurrRegion->AddLocus();
        }
        assert(locus < m_pCurrRegion->GetNloci());

        // get block datatype
        string datatype = getNodeAttributeValue(dataBlockElement,xmlstr::XML_TAG_TYPE);
        DataType_ptr dt(CreateDataType(datatype));
        m_pCurrRegion->SetDataType(locus, dt);

        // Read the data
        m_tipdata.data.clear();
        string contents = getNodeText(dataBlockElement);
        string baddata;
        bool good_data = dt->Proofread(contents, m_tipdata.data, baddata);
        if (!good_data) {
          string problem = "Invalid genetic data in population " + ToString(m_currpopulation)
                       + " sample " + m_tipdata.label + "\n";  
          problem += "Offending allele: " + baddata;
          m_parser.ThrowDataError(problem);
        }
        long len = m_tipdata.data.size();

        try 
        {
            m_pCurrRegion->SetNmarkers(locus, len);
        }
        catch (const std::exception& e) 
        { 
            long expectedNmarkers = m_pCurrRegion->GetNmarkers(locus); 
            long localLineNumber = dataBlockElement->Row();
            string tagName = xmlstr::XML_TAG_DATABLOCK;
            string message = string ("Data element \"" + tagName + "\" at input line ") 
                + ToString(localLineNumber) + string( " has ") + ToString(len);
            message += " data elements but previous has " + ToString(expectedNmarkers);
            m_parser.ThrowDataError (message);
        }
	// save info on which locus this tipdata belongs to
	m_tipdata.m_locus = locus;
        // put this info into the storehouse
        m_pCurrRegion->SetTipData(locus, m_tipdata);
        ++locus;
    }
    
} /* DoDataBlocks */


void ParseTreeToData::DoGenotypeResolutions(TiXmlElement * individualElement)
{
  TiXmlNode * child = NULL;
  while((child = individualElement->IterateChildren(xmlstr::XML_TAG_GENOTYPE_RESOLUTIONS,child)))
  {
    TiXmlElement * genotypeResElement = child->ToElement();
    TiXmlElement * traitElement = singleRequiredChild(genotypeResElement, xmlstr::XML_TAG_TRAIT_NAME);
    string tname = getNodeText(traitElement);

    // if this is a new locus, add it to the Region
    if (!(m_pCurrRegion->HasLocus(tname))) {
      m_pCurrRegion->AddLocus(true, tname); //true == movable (for later)
      //Note:  passing 'true' to the locus constructor sets up a locus
      // with a single marker and one site.
    }

    // Copy the vector of TipDatas from an older locus to the new one,
    //  and clear out the data from it.  This is because we don't have
    //  information about the samples here, only when we read in the sample
    //  data (which we already did).
    //
    // We need to do this every time instead of just the first time because
    //  this code gets run once per individual.  Ideally, we'd only run it the
    //  *last* time, but running it every time works.
    //
    // This is, uh, kind of a hack.  Like a lot of this code.  Ideally, *all*
    //  the TipData stuff would just be in the Individuals.
    m_pCurrRegion->CopyTipDataForLocus(tname);
    long locusnum = m_pCurrRegion->GetLocusIndex(tname);
    assert(locusnum < m_pCurrRegion->GetNloci());

    // The datatype must be K-allele (for now)
    // Also, this would be a good thing to move to the constructor
    // eventually.  Because as it is, we have to re-set this for
    // every individual.  But whatever.
    DataType_ptr dt(CreateDataType(lamarcstrings::KALLELE));
    m_pCurrRegion->SetDataType(locusnum, dt);

    // Read the haplotypes

    TiXmlNode * genchild = NULL;

    while ((genchild = genotypeResElement->IterateChildren(xmlstr::XML_TAG_HAPLOTYPES,genchild))) {
      TiXmlElement* haplotypesElement = genchild->ToElement();
      TiXmlElement* penetranceElement = singleOptionalChild(haplotypesElement, xmlstr::XML_TAG_PENETRANCE);
      TiXmlElement* allelesElement    = singleRequiredChild(haplotypesElement, xmlstr::XML_TAG_ALLELES);
      double penetrance = 1.0;
      if (penetranceElement != NULL) {
        penetrance = ProduceDoubleOrBarf(getNodeText(penetranceElement));
      }
      string baddata;
      StringVec1d alleles;
      dt->Proofread(getNodeText(allelesElement), alleles, baddata);
      //Kallele data always returns true;
      m_currIndividual.AddHaplotype(m_pCurrRegion->GetID(), tname, 0, alleles, penetrance);
        
    }
  }
}
//__________________________________________________________

// The following routines are used to establish the map
//__________________________________________________________

void 
ParseTreeToData::DoSpacing(TiXmlElement * spacingElement)
{
  // NB: DoSpacing has to be called *after* DoPopulations
  // because otherwise defaults can't be meaningfully set here
  if (spacingElement == NULL) {
    long locus;
    for (locus = 0; locus < m_pCurrRegion->GetNloci(); ++locus) {
      m_pCurrRegion->SetPositions(locus);  // set to default
      m_pCurrRegion->SetNsites(locus, m_pCurrRegion->GetNmarkers(locus));
    }
    // all other spacing parameters are set by default in constructor
  } else {
    DoBlocks(spacingElement);
  }

} /* DoSpacing */

//__________________________________________________________

void 
ParseTreeToData::DoBlocks(TiXmlElement * spacingElement)
{
    long locus = 0;

    TiXmlNode * child = NULL;
    while((child = spacingElement->IterateChildren(xmlstr::XML_TAG_BLOCK,child)))
    {
        TiXmlElement * blockElement = child->ToElement();

        DoOffset(singleOptionalChild(blockElement,xmlstr::XML_TAG_OFFSET),locus);
        DoMapPosition(singleOptionalChild(blockElement,xmlstr::XML_TAG_MAP_POSITION),locus);
        DoLength(singleOptionalChild(blockElement,xmlstr::XML_TAG_LENGTH),locus);
        DoLocations(singleOptionalChild(blockElement,xmlstr::XML_TAG_LOCATIONS),locus);


        ++locus;
    }
    assert(locus > 0);  // should be assured by schema logic


} /* DoBlocks */

//__________________________________________________________

void 
ParseTreeToData::DoMapPosition(TiXmlElement * mapPositionElement, long locus)
{

    long mapPosition = 1;     // default value if mapPositionElement is Null

    if (mapPositionElement != NULL) // no mapPosition; assume 1
    {
        try {
            mapPosition = ProduceLongOrBarf(getNodeText(mapPositionElement));
        } catch (const data_error& e) {
            m_parser.ThrowDataError(string(e.what()),mapPositionElement->Row());
        }
    }
    m_pCurrRegion->SetGlobalMapposition(locus, mapPosition);

} /* DoMapPosition */

//__________________________________________________________

void 
ParseTreeToData::DoLength(TiXmlElement * lengthElement, long locus)
{
    // default value if lengthElement is Null
    long length = m_pCurrRegion->GetNmarkers(locus);

    if (lengthElement != NULL) // no mapPosition; assume 0
    {
        try {
            length = ProduceLongOrBarf(getNodeText(lengthElement));
        } catch (const data_error& e) {
            m_parser.ThrowDataError(string(e.what()),lengthElement->Row());
        }
    }
    m_pCurrRegion->SetNsites(locus, length);

} /* DoLength */

//__________________________________________________________

void 
ParseTreeToData::DoLocations(TiXmlElement * locationsElement, long locus)
{
  if(locationsElement == NULL)
  {
    m_pCurrRegion->SetPositions(locus);  // to default
  }
  else
  {
      string content = getNodeText(locationsElement);
      vector<long> locations;
      string token;
      long offset = m_pCurrRegion->GetOffset(locus);
      long length = m_pCurrRegion->GetLocusNsites(locus);
      long nmarkers = m_pCurrRegion->GetNmarkers(locus);

      try {
        StringVec1d values = getNodeTextSplitOnWhitespace(locationsElement);
        if (static_cast<size_t>(nmarkers) != values.size()) {
          throw data_error("Incorrect number of locations listed (" + ToString(values.size()) + "); you should have " + ToString(nmarkers) + ".");
        }

        StringVec1d::iterator siter;
        for(siter = values.begin(); siter != values.end(); siter++)
        {
          // we subtract the offset here, making all positions
          // relative to zero
          long pos = ProduceLongOrBarf(*siter) - offset;
          if (pos < 0) {
            throw data_error("One or more location values are lower than " + ToString(offset) + ", the offset for locus " + ToString(locus+1) + ".");
          }
          if (pos >= length) {
            throw data_error("One or more location values are higher than " + ToString(length + offset - 1) + ", the offset plus the length of locus " + ToString(locus+1) + ".");
          }
          // we subtract the offset here, making all positions
          // relative to zero
          locations.push_back(pos);
        }
        m_pCurrRegion->SetPositions(locus, locations);
      }
      catch (const data_error& e) {
        m_parser.ThrowDataError(string(e.what()),locationsElement->Row());
      }
  }


} /* DoLocations */

//__________________________________________________________

void 
ParseTreeToData::DoOffset(TiXmlElement * offsetElement, long locus) 
{
    long offset = 0L;     // default value if offsetElement is Null

    if (offsetElement != NULL) // no offset; assume 0
    {
        try {
            offset = ProduceLongOrBarf(getNodeText(offsetElement));
        } catch (const data_error& e) {
            m_parser.ThrowDataError(string(e.what()),offsetElement->Row());
        }
    }

    m_pCurrRegion->SetOffset(locus, offset);

} // DoOffset

//__________________________________________________________

void 
ParseTreeToData::DoPhases(TiXmlElement * regionElement)
// read information about sites of known/unknown phase
// attribute "unknown" means that this is a list of phase-unknown
// sites (to be stored as-is) whereas attribute "known" means that
// this is a list of phase-known sites (and we store the
// inverse, the phase-unknown sites).
{
  //Because populations have to be done before spacing, and because phases
  // have to be done after spacing, we have to loop over exactly the same
  // things that 'DoPopulations' did, before, to get to the individuals.
  TiXmlNode * pop = NULL;
  long indnum = 0;
  while((pop = regionElement->IterateChildren(xmlstr::XML_TAG_POPULATION,pop)))
  {
    TiXmlElement * populationElement = pop->ToElement();
    TiXmlNode * ind = NULL;
    while((ind = populationElement->IterateChildren(xmlstr::XML_TAG_INDIVIDUAL,ind)))
    {
      TiXmlElement * individualElement = ind->ToElement();
      string token;

      LongVec2d phasesites;

      vector<TiXmlElement *> phaseElements 
        = getAllOptionalDescendantElements (individualElement,xmlstr::XML_TAG_PHASE);
      if(phaseElements.size() == 0)
      {
        // no phase info available; we set empty vectors
        //EWFIX.P5 DIMENSION--needs to be 3d?
        LongVec2d phases(m_pCurrRegion->GetNumFixedLoci());
        phasesites = phases;
      }
      else {

        TiXmlNode * child = NULL;
        long locus = 0;
        while((child = individualElement->IterateChildren(xmlstr::XML_TAG_PHASE,child)))
        {
          TiXmlElement * phaseElement = child->ToElement();

          string content = getNodeText(phaseElement);
          string phasetype = getNodeAttributeValue(phaseElement,xmlstr::XML_ATTRTYPE_TYPE);
          StripLeadingSpaces(phasetype);
          StripTrailingSpaces(phasetype);


          LongVec1d phases = ProduceLongVec1dOrBarf(getNodeText(phaseElement));
          long offset = m_pCurrRegion->GetOffset(locus);
          long length = m_pCurrRegion->GetLocusNsites(locus);
          for (LongVec1d::iterator phase=phases.begin(); phase != phases.end(); phase++)
          {
            *phase -= offset;
            if (*phase < 0) {
              m_parser.ThrowDataError("One or more phase values are lower than " + ToString(offset) + ", the offset for locus " + ToString(locus+1) + ".", phaseElement->Row());
            }
            if (*phase >= length) {
              m_parser.ThrowDataError("One or more phase values are higher than " + ToString(length + offset - 1) + ", the offset plus the length of locus " + ToString(locus+1) + ".", phaseElement->Row());
            }
          }
          std::sort(phases.begin(), phases.end());

          if (phasetype == xmlstr::XML_ATTRVALUE_KNOWN) {
            //We need to reverse the vector, though only for markers.
            LongVec1d all_locations = m_pCurrRegion->GetLocus(locus).GetMarkerLocations();
            for (LongVec1d::iterator knownphase = phases.begin();
                 knownphase != phases.end() ; knownphase++) {
              LongVec1d::iterator known = FindValIn(*knownphase, all_locations);
              if (known == all_locations.end()) {
                m_parser.ThrowDataError("Site " + ToString(*knownphase + offset) + " in locus " + ToString(locus+1) + " does not have a marker associated with it, and may therefore not be set 'phase known'.", phaseElement->Row());
              }
              all_locations.erase(known);
            }
            phases = all_locations;
          }
          else if (!(phasetype == xmlstr::XML_ATTRVALUE_UNKNOWN)) {
            m_parser.ThrowDataError("Unknown type of phase information " + phasetype, phaseElement->Row());
          }
          phasesites.push_back(phases);
          ++locus;
        }
      }

      // Error check for consistency
      if (phasesites.size() != static_cast<unsigned long>(m_pCurrRegion->GetNumFixedLoci())) {
        m_parser.ThrowDataError("Number of phase entries inconsistent with number of segments",individualElement->Row());
      }
      try {
        m_pCurrRegion->SetPhaseMarkers(indnum, phasesites);
      }
      catch (const data_error& e) {
        m_parser.ThrowDataError(e.what(), individualElement->Row());
      }
      indnum++;
    }
  }
} /* DoPhases */

UserTree* 
ParseTreeToData::DoTree(TiXmlElement * treeElement)
{
  string treetype = getNodeAttributeValue(treeElement,xmlstr::XML_ATTRTYPE_TYPE);

  // WARNING:  This should eventually be done with a TreeFactory
  if (treetype != xmlstr::XML_STRING_NEWICK)
  {
    m_parser.ThrowDataError("Encountered input tree of unknown type");
  }

  return new NewickTree(getNodeText(treeElement));

} /* DoTree */


void 
ParseTreeToData::DoEffectivePopSize(TiXmlElement * sizeElement)
{
    // default value if sizeElement is Null
    double size = defaults::effpopsize;

    if (sizeElement != NULL)
    {
        try {
            size = ProduceDoubleOrBarf(getNodeText(sizeElement));
        } catch (const data_error& e) {
            m_parser.ThrowDataError(string(e.what()),sizeElement->Row());
        }
    }
    //LS NOTE:  This sets the effective population size in the actual data
    // pack, but in the menu, there is an effective population size menu
    // where the information is stored in ui_vars_datapackplus.  This means
    // that when the datapackplus is created, it must set those values properly
    // from what we read in here.  This all works for now, but is a bit arcane.
    // If we move to having a front-end datapack as well as a back-end datapack,
    // this would theoretically become a bit simpler.
    if (size <= 0) {
      m_parser.ThrowDataError("All effective population sizes must be positive.");
    }
    m_pCurrRegion->SetEffectivePopSize(size);

} /* DoEffectivePopSize */

LongVec1d::iterator FindValIn(long val, LongVec1d& vec) {
  LongVec1d::iterator found = vec.begin();
  for (; found != vec.end(); found++) {
    if (*found == val) return found;
  }
  return found;
}
