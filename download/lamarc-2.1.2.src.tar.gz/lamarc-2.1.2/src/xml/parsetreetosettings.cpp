//$Id: parsetreetosettings.cpp,v 1.65 2007/04/27 20:06:19 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "constants.h"
#include "errhandling.h"
#include "mathx.h"
#include "parsetreetosettings.h"
#include "parsetreewalker.h"
#include "stringx.h"
#include "ui_constants.h"   // for uiconst::GLOBAL_ID
#include "ui_interface.h"
#include "ui_regid.h"
#include "ui_strings.h"
#include "ui_vars.h"
#include "xml.h"
#include "xml_strings.h"


using std::string;


ParseTreeToSettings::ParseTreeToSettings(XmlParser& parser, UIInterface& ui)
    :
        ParseTreeWalker(parser),
        uiInterface(ui)
{
}

ParseTreeToSettings::~ParseTreeToSettings()
{
}

void
ParseTreeToSettings::ProcessFileSettings()
{
    TiXmlElement * docElement = m_parser.GetRootElement();

    const char * tagValue = docElement->Value();
    string tagString(tagValue);
    bool matches = CaselessStrCmp(xmlstr::XML_TAG_LAMARC,tagValue);
    if(!matches)
    {
        string msg = m_parser.GetFileName() + ": " + xmlstr::XML_ERR_NOT_LAMARC;
        m_parser.ThrowDataError(msg);
    }


    vector<TiXmlElement *> globalModelElements
        = getAllOptionalDescendantElements(docElement,xmlstr::XML_TAG_MODEL);
    for (unsigned long i=0; i<globalModelElements.size(); ++i) {
      DoDLModel(globalModelElements[i],uiconst::GLOBAL_ID);
    }

    DoDataModels(singleRequiredChild(docElement,xmlstr::XML_TAG_DATA));
    DoTraits(singleRequiredChild(docElement,xmlstr::XML_TAG_DATA));

    TiXmlElement * chainsElement 
        = singleOptionalChild(docElement,xmlstr::XML_TAG_CHAINS);
    if(chainsElement != NULL)
    {
        DoChainParams(chainsElement);
    }

    TiXmlElement * formatElement 
        = singleOptionalChild(docElement,xmlstr::XML_TAG_FORMAT);
    if(formatElement != NULL)
    {
        DoUserParams(formatElement);
    }

    TiXmlElement * forcesElement 
        = singleOptionalChild(docElement,xmlstr::XML_TAG_FORCES);
    if(forcesElement != NULL)
    {
        DoForces(forcesElement);
    }

}

void 
ParseTreeToSettings::DoOptionalElement(TiXmlElement* ancestor, string tagName,string uiLabel, UIId id)
{
    TiXmlElement * node = singleOptionalChild(ancestor,tagName);
    if(node == NULL)
    {
        return;
    }
    uiInterface.doSet(uiLabel,getNodeText(node),id);
}

void 
ParseTreeToSettings::DoRequiredElement(TiXmlElement* ancestor, string tagName,string uiLabel, UIId id)
{
    TiXmlElement * node = singleRequiredChild(ancestor,tagName);
    if(node == NULL)
    {
        m_parser.ThrowDataError(xmlstr::XML_ERR_MISSING_TAG_HIER_0
                + tagName
                + xmlstr::XML_ERR_MISSING_TAG_HIER_1
                + ancestor->Value()
                + xmlstr::XML_ERR_MISSING_TAG_HIER_2);
    }
    uiInterface.doSet(uiLabel,getNodeText(node),id);
}

void 
ParseTreeToSettings::DoDataModels(TiXmlElement * dataElement)
{
    TiXmlNode * child = NULL;

    long regionNumber = 0;

    while((child = dataElement->IterateChildren(xmlstr::XML_TAG_REGION,child)))
    {
        TiXmlElement * regionElement = child->ToElement();
        DoRegionDataModels(regionElement,regionNumber);
        regionNumber++;
    }
}


void
ParseTreeToSettings::DoRegionDataModels(TiXmlElement * regionElement, long regionId)
{
    TiXmlNode * child = NULL;

    long maxLoci = uiInterface.GetCurrentVars().datapackplus.GetMaxLoci();
    long locusId = 0;

    while((child = regionElement->IterateChildren(xmlstr::XML_TAG_MODEL,child)))
    {
        TiXmlElement * modelElement = child->ToElement();
        // EWFIX.P4 LOCUS.HACK.HACK.HACK
        // probably making more than we need
        // also need to handle per-locus models later
        // probably does something awful for mismatched types
        //
        //JDEBUG--evil hack
        // we now handle multiple loci, but...ick...sequential implied
	// ordering
	if (locusId >= maxLoci)  // too many loci?
        {
	    std::string errstring("Warning:  More datamodels found"); 
            errstring += " than segments, only the first ";
	    errstring += ToString(locusId);
	    errstring += " datamodels were used.\n";
            uiInterface.AddWarning(errstring);
	    return;
	}

        DoDLModel(modelElement,regionId,locusId);
        ++locusId; 
    }
    // JDEBUG
    // ideally we would now fill out the remaining loci (if any) with
    // default datamodels for their datatype...but this may conflict
    // with registry::InstallDataModel/registry::CreateDataModel and
    // it's use of the single "regional" datamodel
}

void 
ParseTreeToSettings::DoDLModel(TiXmlElement * modelElement, long regionId, long locusId)
{
    string modelName = getNodeAttributeValue(modelElement,xmlstr::XML_ATTRTYPE_NAME);
    //Here is where we change the regionId to the correct flag if it had been
    // set to GLOBAL_ID.  It must be recursive for the KAllele case (for now).
    if (regionId == uiconst::GLOBAL_ID) {
      switch (ProduceModelTypeOrBarf(modelName)) {
      case F84:
      case GTR:
        DoDLModel(modelElement, uiconst::GLOBAL_DATAMODEL_NUC_ID);
        return;
      case Brownian:
      case Stepwise:
      case MixedKS:
        DoDLModel(modelElement, uiconst::GLOBAL_DATAMODEL_MSAT_ID);
        return;
      case KAllele:
        //Here we have to set the global model for *both* the microsat *and*
        // 'kallele' data.
        DoDLModel(modelElement, uiconst::GLOBAL_DATAMODEL_MSAT_ID);
        DoDLModel(modelElement, uiconst::GLOBAL_DATAMODEL_KALLELE_ID);
        return;
      }
      assert(false); //Uncaught model type.
      regionId = uiconst::GLOBAL_DATAMODEL_NUC_ID;
    }
    assert(regionId != uiconst::GLOBAL_ID);

    UIId locusUIId(regionId,locusId);
    
    uiInterface.doSet(uistr::dataModel,modelName,locusUIId);

    // comments below show which models should allow the setting

    // base frequencies -- F84, GTR (but don't allow calculated)
    TiXmlElement * baseFrequenciesElement 
        = singleOptionalChild(modelElement,xmlstr::XML_TAG_BASE_FREQS);
    if(baseFrequenciesElement != NULL)
    {
        DoBaseFrequencies(baseFrequenciesElement,locusUIId);
    }
    // ttratio -- F84
    DoOptionalElement(modelElement,xmlstr::XML_TAG_TTRATIO,uistr::TTRatio,locusUIId);
    // normalize -- F84 GTR Stepwise KAllele
    DoOptionalElement(modelElement,xmlstr::XML_TAG_NORMALIZE,uistr::normalization,locusUIId);
    // gtrrates -- GTR
    TiXmlElement * gtrElement 
        = singleOptionalChild(modelElement,xmlstr::XML_TAG_GTRRATES);
    if(gtrElement != NULL)
    {
        DoGTR(gtrElement,locusUIId);
    }
    // alpha -- mixedKS
    DoOptionalElement(modelElement,xmlstr::XML_TAG_ALPHA,uistr::alpha,locusUIId);
    // optimize -- mixedKS
    DoOptionalElement(modelElement,xmlstr::XML_TAG_ISOPT,uistr::optimizeAlpha,locusUIId);

    // categories F84 GTR Stepwise Brownian KAllele
    TiXmlElement * categoriesElement
        = singleOptionalChild(modelElement,xmlstr::XML_TAG_CATEGORIES);
    if(categoriesElement != NULL)
    {
        DoCategories(categoriesElement,locusUIId);
    }

    // relative mutation rate -- all
    DoOptionalElement(modelElement,xmlstr::XML_TAG_RELATIVE_MURATE,uistr::relativeMuRate,locusUIId);


} // DoDLModel

void
ParseTreeToSettings::DoCategories(TiXmlElement * categoriesElement, UIId locusUIId)
{
    DoOptionalElement(categoriesElement,xmlstr::XML_TAG_NUM_CATEGORIES,uistr::categoryCount,locusUIId);
    DoOptionalElement(categoriesElement,xmlstr::XML_TAG_AUTOCORRELATION,uistr::autoCorrelation,locusUIId);


    TiXmlElement * catRates = singleOptionalChild(categoriesElement,xmlstr::XML_TAG_RATES);
    TiXmlElement * catProbs = singleOptionalChild(categoriesElement,xmlstr::XML_TAG_PROBABILITIES);

    if(catRates != NULL)
    {
        StringVec1d strings = getNodeTextSplitOnWhitespace(catRates);
        long catCount = uiInterface.doGetLong(uistr::categoryCount,locusUIId);
        long numToSet = catCount;
        if((long)strings.size() > catCount)
        {
          uiInterface.AddWarning("Warning:  The number of supplied category rates and/or probabilities is greater than the number of categories.  Discarding the extras.");
        }
        else
        {
            if((long)strings.size() < catCount)
            {
              uiInterface.AddWarning("Warning:  The number of supplied category rates and/or probabilities is less than the number of categories.  Using defaults for the extras.");
                numToSet = strings.size();
            }
        }

        for(long index=0;index < numToSet; index++)
        {
            UIId innerId(locusUIId.GetIndex1(),locusUIId.GetIndex2(),index);
            uiInterface.doSet(uistr::categoryRate,strings[index],innerId);
        }
    }
    if(catProbs != NULL)
    {
        StringVec1d strings = getNodeTextSplitOnWhitespace(catProbs);
        long catCount = uiInterface.doGetLong(uistr::categoryCount,locusUIId);
        long numToSet = catCount;
        if((long)strings.size() > catCount)
        {
          uiInterface.AddWarning("Warning:  The number of supplied category rates and/or probabilities is greater than the number of categories.  Discarding the extras.");
        }
        else
        {
            if((long)strings.size() < catCount)
            {
              uiInterface.AddWarning("Warning:  The number of supplied category rates and/or probabilities is less than the number of categories.  Using defaults for the extras.");
                numToSet = strings.size();
            }
        }

        for(long index=0;index < numToSet; index++)
        {
            UIId innerId(locusUIId.GetIndex1(),locusUIId.GetIndex2(),index);
            uiInterface.doSet(uistr::categoryProbability,strings[index],innerId);
        }
    }

}


void 
ParseTreeToSettings::DoBaseFrequencies(TiXmlElement * baseFreqsElem, UIId thisId)
{

    // kinda grotty, but we want to ignore case differences
    string frequencies = getNodeText(baseFreqsElem);
    string tag = xmlstr::XML_TAG_CALCULATED;
    LowerCase(frequencies);
    LowerCase(tag);
    string::size_type index = frequencies.find(tag);

    if(index != std::string::npos)
    {
        uiInterface.doSet(uistr::freqsFromData,"true",thisId);
    }
    else
    {
        StringVec1d strings;
        bool gotStrings = FromString(frequencies,strings);
        if(gotStrings)
        {
            if(strings.size() == 4)
            {
                uiInterface.doSet(uistr::baseFrequencyA,strings[0],thisId);
                uiInterface.doSet(uistr::baseFrequencyC,strings[1],thisId);
                uiInterface.doSet(uistr::baseFrequencyG,strings[2],thisId);
                uiInterface.doSet(uistr::baseFrequencyT,strings[3],thisId);
            }
            else if (strings.size() == 0) {
              uiInterface.AddWarning("Warning:  no supplied base frequencies; using a set of defaults.");

            }
            else
            {
              uiInterface.AddWarning("Warning:  wrong number of supplied base frequencies; using a set of defaults.");
            }
        }
        else
        {
          uiInterface.AddWarning("Warning:  no supplied base frequencies; using a set of defaults.");
        }
    }
} // DoBaseFrequencies

void 
ParseTreeToSettings::DoGTR(TiXmlElement * gtrElem, UIId thisId)
{
    StringVec1d strings = getNodeTextSplitOnWhitespace(gtrElem);
    if(strings.size() == 6)
    {
        uiInterface.doSet(uistr::gtrRateAC,strings[0],thisId);
        uiInterface.doSet(uistr::gtrRateAG,strings[1],thisId);
        uiInterface.doSet(uistr::gtrRateAT,strings[2],thisId);
        uiInterface.doSet(uistr::gtrRateCG,strings[3],thisId);
        uiInterface.doSet(uistr::gtrRateCT,strings[4],thisId);
        uiInterface.doSet(uistr::gtrRateGT,strings[5],thisId);
    }
    else if (strings.size() == 0)
    {
      uiInterface.AddWarning("Warning:  no GTR rates supplied:  using a set of defaults.");
    }
    else {
      uiInterface.AddWarning("Warning:  incorrect number of GTR rates supplied:  using a set of defaults.");
    }
} // DoGTR

void 
ParseTreeToSettings::DoChainParams(TiXmlElement * chainsElement)
{


    DoOptionalElement(chainsElement,xmlstr::XML_TAG_REPLICATES,uistr::replicates);

    TiXmlElement * initialChainElement 
        = singleOptionalChild(chainsElement,xmlstr::XML_TAG_INITIAL); 
    if(initialChainElement != NULL)
    {
        DoOptionalElement(initialChainElement,xmlstr::XML_TAG_NUMBER,uistr::initialChains);
        DoOptionalElement(initialChainElement,xmlstr::XML_TAG_SAMPLES,uistr::initialSamples);
        DoOptionalElement(initialChainElement,xmlstr::XML_TAG_INTERVAL,uistr::initialInterval);
        DoOptionalElement(initialChainElement,xmlstr::XML_TAG_DISCARD,uistr::initialDiscard);
    }

    TiXmlElement * finalChainElement 
        = singleOptionalChild(chainsElement,xmlstr::XML_TAG_FINAL); 
    if(finalChainElement != NULL)
    {
        DoOptionalElement(finalChainElement,xmlstr::XML_TAG_NUMBER,uistr::finalChains);
        DoOptionalElement(finalChainElement,xmlstr::XML_TAG_SAMPLES,uistr::finalSamples);
        DoOptionalElement(finalChainElement,xmlstr::XML_TAG_INTERVAL,uistr::finalInterval);
        DoOptionalElement(finalChainElement,xmlstr::XML_TAG_DISCARD,uistr::finalDiscard);
    }

    TiXmlElement * heatingElement 
    = singleOptionalChild(chainsElement,xmlstr::XML_TAG_HEATING); 
    if(heatingElement != NULL)
    {
        TiXmlElement * temperatures 
            = singleOptionalChild(heatingElement,xmlstr::XML_TAG_TEMPERATURES); 
        if(temperatures != NULL) DoTemperatures(getNodeTextSplitOnWhitespace(temperatures));

        TiXmlElement * intervals 
            = singleOptionalChild(heatingElement,xmlstr::XML_TAG_SWAP_INTERVAL); 
        if(intervals != NULL) DoSwapInterval(intervals);

        DoOptionalElement(heatingElement,xmlstr::XML_TAG_HEATING_STRATEGY,uistr::tempAdapt);
    }

    // must do processing for XML_TAG_BAYESIAN_ANALYSIS before processing for
    // the XML_TAG_BAYESIAN strategy element because if they are inconsistent
    // we need to throw--the BAYESIAN_ANALYSIS tag takes precedence.
    DoOptionalElement(chainsElement,xmlstr::XML_TAG_BAYESIAN_ANALYSIS,uistr::bayesian);
    TiXmlElement * strategyElement 
        = singleOptionalChild(chainsElement,xmlstr::XML_TAG_STRATEGY); 
    if(strategyElement != NULL)
    {
        DoOptionalElement(strategyElement,xmlstr::XML_TAG_RESIMULATING,uistr::dropArranger);
        uiInterface.GetCurrentVars().chains.RescaleDefaultSizeArranger();
        DoOptionalElement(strategyElement,xmlstr::XML_TAG_TREESIZE,uistr::sizeArranger);
        DoOptionalElement(strategyElement,xmlstr::XML_TAG_HAPLOTYPING,uistr::hapArranger);
        DoOptionalElement(strategyElement,xmlstr::XML_TAG_BAYESIAN,uistr::bayesArranger);
    }
    uiInterface.GetCurrentVars().chains.RescaleArrangersSoDropIsOne();


} /* DoChainParams */

//__________________________________________________________
//__________________________________________________________


void
ParseTreeToSettings::DoTemperatures(StringVec1d temperatures)
{
    if(temperatures.empty())
    {
      uiInterface.AddWarning("Warning:  No supplied temperatures for heated chains:  using a set of defaults.");
    }
    else
    {
        uiInterface.doSet(uistr::heatedChainCount,ToString(temperatures.size()));
        for(long index = 0; index < (long)temperatures.size(); index++)
        {
            uiInterface.doSet(uistr::heatedChain,temperatures[index],UIId(index));
        }
    }
}

//__________________________________________________________

void 
ParseTreeToSettings::DoSwapInterval(TiXmlElement * intervals)
{
    StringVec1d values = getNodeTextSplitOnWhitespace(intervals);
    if(values.size() > 0)
    {
        uiInterface.doSet(uistr::tempInterval,values[values.size()-1]);
    }
    if(values.empty())
    {
      uiInterface.AddWarning("Warning:  empty <" + xmlstr::XML_TAG_SWAP_INTERVAL + "> tag found; using defaults.");
    }

} /* DoSwapInterval */

//__________________________________________________________

void 
ParseTreeToSettings::DoUserParams(TiXmlElement * formatElement)
{
    DoOptionalElement(formatElement,xmlstr::XML_TAG_VERBOSITY,uistr::verbosity);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_PROGRESS_REPORTS,uistr::progress);

    TiXmlElement * plottingElement 
        = singleOptionalChild(formatElement,xmlstr::XML_TAG_PLOTTING); 
    if(plottingElement != NULL)
    {
        DoOptionalElement(plottingElement,xmlstr::XML_TAG_POSTERIOR,uistr::plotPost);
    }

    DoOptionalElement(formatElement,xmlstr::XML_TAG_SEED,uistr::randomSeed);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_RESULTS_FILE,uistr::resultsFileName);
    //LS NOTE:  These are off by default, so we only warn that there's a
    // problem if we turn them off, meaning we should set the filename first.
    DoOptionalElement(formatElement,xmlstr::XML_TAG_OLD_SUMMARY_FILE,uistr::treeSumInFileName);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_IN_SUMMARY_FILE,uistr::treeSumInFileName);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_OUT_SUMMARY_FILE,uistr::treeSumOutFileName);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_USE_IN_SUMMARY,uistr::treeSumInFileEnabled);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_USE_OUT_SUMMARY,uistr::treeSumOutFileEnabled);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_NEWICKTREEFILE_PREFIX,uistr::newickTreeFilePrefix);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_USE_NEWICKTREEFILE,uistr::useNewickTreeFiles);
    //LS NOTE:  And these two are on by default, so we warn only if it's still
    // on when we change the name.
    DoOptionalElement(formatElement,xmlstr::XML_TAG_USE_CURVEFILES,uistr::useCurveFiles);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_CURVEFILE_PREFIX,uistr::curveFilePrefix);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_USE_TRACEFILE,uistr::useTraceFiles);
    DoOptionalElement(formatElement,xmlstr::XML_TAG_TRACEFILE_PREFIX,uistr::traceFilePrefix);
    //LS NOTE:  And this one we always write, so there are no warnings about
    // the setting.
    DoOptionalElement(formatElement,xmlstr::XML_TAG_OUT_XML_FILE,uistr::xmlOutFileName);

} /* DoUserParams */

//__________________________________________________________

//__________________________________________________________


//----------------------------------------------------------
// Force parameter functions
//__________________________________________________________

void 
ParseTreeToSettings::DoForces(TiXmlElement * forcesElement)
{
  DoForceIfPresent(forcesElement,force_COAL,xmlstr::XML_TAG_COALESCENCE);
  DoForceIfPresent(forcesElement,force_MIG,xmlstr::XML_TAG_MIGRATION);
  DoForceIfPresent(forcesElement,force_REC,xmlstr::XML_TAG_RECOMBINATION);
  DoForceIfPresent(forcesElement,force_GROW,xmlstr::XML_TAG_GROWTH);
  DoForceIfPresent(forcesElement,force_LOGISTICSELECTION,
		   xmlstr::XML_TAG_LOGISTICSELECTION);
  DoForceIfPresent(forcesElement,force_DISEASE,xmlstr::XML_TAG_DISEASE);
  DoForceIfPresent(forcesElement,force_REGION_GAMMA,
     xmlstr::XML_TAG_REGION_GAMMA);

} /* DoForces */


//__________________________________________________________

void 
ParseTreeToSettings::DoForceIfPresent(
    TiXmlElement * forcesElement, 
    force_type forcetype,
    const string& forcetag) 
{

    TiXmlElement * forceElement = singleOptionalChild(forcesElement,forcetag);

    if(forceElement != NULL)
    {
        DoForce(forceElement,forcetype);
    }

}

//__________________________________________________________

void 
ParseTreeToSettings::DoForce(TiXmlElement* forceElement, force_type forcetype) 
{

    UIId forceId(forcetype);

    string forceOnOff
        = getNodeAttributeValue(forceElement,xmlstr::XML_ATTRTYPE_VALUE);
    if(!forceOnOff.empty())
    {
        uiInterface.doSet(uistr::forceOnOff,forceOnOff,forceId);
    }
    else
    {
        uiInterface.doSet(uistr::forceOnOff,"on",forceId);
    }

    if(forcetype == force_GROW)
    {
        string growthType = getNodeAttributeValue(forceElement,xmlstr::XML_ATTRTYPE_TYPE);
        if(!growthType.empty())
        {
            uiInterface.doSet(uistr::growthType,growthType);
        }
    }


    if(uiInterface.doGetBool(uistr::forceLegal,forceId))
    {

      DoOptionalElement(forceElement,xmlstr::XML_TAG_MAX_EVENTS,uistr::maxEvents,forceId);
      DoOptionalElement(forceElement,xmlstr::XML_TAG_DISEASELOCATION,uistr::diseaseLocation,forceId);

      //LS NOTE:  Order matters in this next section. First, we do profiles,
      // because if they're done after the groups, the 'none' entries
      // override any (correct) 'on' entries for grouped parameters.  Next
      // we do constraints, then groups, because the groups tags need
      // to override the constraints tags.
      //
      // Then we do the priors, because they will be affected by the groups
      // and constraints.
      //
      // Then we do start values, because they will be affected by the
      // constraints, groups, priors, and methods.  Sadly, we have to do a bit
      // of munging in DoStartValuesAndMethods because the Methods are, in
      // turn, affected by the process of setting the start values.
      DoProfiles(forceElement,forceId);
      DoConstraints(forceElement,forceId);
      DoGroups(forceElement, forceId);
      DoPriors(forceElement, forceId);
      DoStartValuesAndMethods(forceElement,forceId);
      DoTrueValues(forceElement,forceId);

      // LS DEBUG -- we can at least check the zeroes for validity.
      //  Eventually the method to do this will change, so don't copy this
      //  technique elsewhere.
      if (!uiInterface.GetCurrentVars().forces.GetForceZeroesValidity(forcetype))
      {
        string err = "Invalid settings for force ";
        err += ToString(forcetype) + ".  Too many parameters are set invalid or have a start value of 0.0.";
        throw data_error(err);
      }
      uiInterface.GetCurrentVars().forces.FixGroups(forcetype);
    }
}

void
ParseTreeToSettings::DoStartValuesAndMethods(TiXmlElement* forceElement, UIId forceId)
{
    TiXmlElement * methodsElement =
        singleOptionalChild(forceElement,xmlstr::XML_TAG_METHOD);
    TiXmlElement * startValuesElement =
        singleOptionalChild(forceElement,xmlstr::XML_TAG_START_VALUES);

    if(methodsElement == NULL && startValuesElement == NULL)
        // simply return and take the default values
    {
        return;
    }

    force_type thisForce = forceId.GetForceType();
    long expectedNumParameters =
        uiInterface.GetCurrentVars().forces.GetNumParameters(thisForce);
    StringVec1d values;
    StringVec1d methods;

    if(startValuesElement != NULL)
    {
        values = getNodeTextSplitOnWhitespace(startValuesElement);
        if(static_cast<long>(values.size()) != expectedNumParameters)
        {

            m_parser.ThrowDataError(xmlstr::XML_ERR_START_VALUE_COUNT_0
                                    + ToString(expectedNumParameters)
                                    + xmlstr::XML_ERR_START_VALUE_COUNT_1
                                    + ToString(thisForce)
                                    + xmlstr::XML_ERR_START_VALUE_COUNT_2
                                    + ToString(values.size())
                                    + xmlstr::XML_ERR_START_VALUE_COUNT_3
                                    );
        }
    }

    if(methodsElement != NULL)
    {
        methods = getNodeTextSplitOnWhitespace(methodsElement);
        if(static_cast<long>(methods.size()) != expectedNumParameters)
        {
            m_parser.ThrowDataError(xmlstr::XML_ERR_METHOD_TYPE_COUNT_0
                                    + ToString(expectedNumParameters)
                                    + xmlstr::XML_ERR_METHOD_TYPE_COUNT_1
                                    + ToString(thisForce)
                                    + xmlstr::XML_ERR_METHOD_TYPE_COUNT_2
                                    + ToString(methods.size())
                                    + xmlstr::XML_ERR_METHOD_TYPE_COUNT_2
                                    );
        }
    }

    // at this point, we either have a full set of method types or none
    // and we have either a full set of start values or none

    if(methodsElement == NULL)
        // an easy case -- all methods become type USER
    {
        for(long index=0; index < (long)values.size(); index++)
        {
            UIId id(forceId.GetForceType(),index);
            uiInterface.doSet(uistr::startValue,values[index],id);
            uiInterface.doSet(uistr::startValueMethod,ToString(method_USER),id);
        }
        return;
    }

    if(startValuesElement == NULL)
        // OK as long as method isn't USER
    {
        for(long index=0; index < (long)methods.size(); index++)
        {
            UIId id(forceId.GetForceType(),index);
            uiInterface.doSet(uistr::startValueMethod,methods[index],id);

            if(StringMatchesMethodType(methods[index],method_USER))
            {
                double defaultStartVal 
                    = uiInterface.GetCurrentVars().forces.GetStartValue(forceId.GetForceType(),index);
                uiInterface.AddWarning(xmlstr::XML_ERR_METHOD_USER_WITHOUT_VALUE_0
                    +ToString(forceId.GetForceType())
                    +xmlstr::XML_ERR_METHOD_USER_WITHOUT_VALUE_1
                    +ToString(defaultStartVal)
                    +xmlstr::XML_ERR_METHOD_USER_WITHOUT_VALUE_2);
            }
        }
        return;
    }

    // OK. Now we should have a full set of method types and start values
    assert((long)methods.size() == expectedNumParameters);
    assert((long)values.size() == expectedNumParameters);


    for(long index=0; index < (long)values.size(); index++)
    {
        UIId id(forceId.GetForceType(),index);
        uiInterface.doSet(uistr::startValue,values[index],id);
    }
    DoubleVec1d usersStartValues = uiInterface.GetCurrentVars().forces.GetStartValues(forceId.GetForceType());

    for(long index=0; index < (long)values.size(); index++)
    {
        UIId id(forceId.GetForceType(),index);
        uiInterface.doSet(uistr::startValueMethod,methods[index],id);
    }
    DoubleVec1d overriddenStartValues = uiInterface.GetCurrentVars().forces.GetStartValues(forceId.GetForceType());

    assert(usersStartValues.size() == overriddenStartValues.size());
    assert(usersStartValues.size() == methods.size());

    for(long index=0; index < (long)methods.size(); index++)
    {
        double userVal = usersStartValues[index];
        double overriddenValue = overriddenStartValues[index];

        if (fabs(userVal - overriddenValue) > 0.00001)
        {
            method_type culprit 
                = uiInterface.doGetMethodType(uistr::startValueMethod,UIId(thisForce,index));
            uiInterface.AddWarning("Warning:  setting the start method for a " + ToString(forceId.GetForceType()) + " parameter to " + ToString(culprit, true) + " will override the value set in the <" + xmlstr::XML_TAG_START_VALUES + "> tag.");
        }
    }



    /*
    bool someStartValues = false;
    // set start values first since these calls set methods
    if(startValuesElement != NULL)
    {
      someStartValues = true;
        StringVec1d values = getNodeTextSplitOnWhitespace(startValuesElement);
        for(long index=0; index < (long)values.size(); index++)
        {
            UIId id(forceId.GetForceType(),index);
            uiInterface.doSet(uistr::startValue,values[index],id);
        }
        if(values.empty())
        {
          someStartValues = false;
          uiInterface.AddWarning("Warning:  empty <" + xmlstr::XML_TAG_START_VALUES + "> tag found; using defaults.");
        }

    }
    else
    {
      uiInterface.AddWarning("Warning:  missing <" + xmlstr::XML_TAG_START_VALUES + "> tag ; using defaults.");
    }

    DoubleVec1d originalStartValues = uiInterface.GetCurrentVars().forces.GetStartValues(forceId.GetForceType());
    if(methodsElement != NULL)
    {
        StringVec1d methods = getNodeTextSplitOnWhitespace(methodsElement);
        for(long index=0; index < (long)methods.size(); index++)
        {
            UIId id(forceId.GetForceType(),index);
            uiInterface.doSet(uistr::startValueMethod,methods[index],id);
        }
        if(methods.empty())
        {
          uiInterface.AddWarning("Warning:  empty <" + xmlstr::XML_TAG_METHOD + "> tag found; using defaults");
        }
        else {
          if (someStartValues) {
            DoubleVec1d newStartValues = uiInterface.GetCurrentVars().forces.GetStartValues(forceId.GetForceType());
            for (unsigned long i=0; i<originalStartValues.size(); i++) {
              if (fabs(originalStartValues[i] - newStartValues[i]) > 0.00001) {
                method_type culprit = uiInterface.doGetMethodType(uistr::startValueMethod,UIId(forceId.GetForceType(), i));
                uiInterface.AddWarning("Warning:  setting the start method for a " + ToString(forceId.GetForceType()) + " parameter to " + ToString(culprit, true) + " will override the value set in the <" + xmlstr::XML_TAG_START_VALUES + "> tag.");
              }
            }
          }
        }
    }
    */
}

//__________________________________________________________

void
ParseTreeToSettings::DoTrueValues(TiXmlElement* forceElement, UIId forceId)
{
    TiXmlElement * trueValuesElement =
        singleOptionalChild(forceElement,xmlstr::XML_TAG_TRUEVALUE);
    if(trueValuesElement != NULL)
    {
        StringVec1d values = getNodeTextSplitOnWhitespace(trueValuesElement);
        for(unsigned long index=0; index < values.size(); index++)
        {
            UIId id(forceId.GetForceType(),index);
            uiInterface.doSet(uistr::trueValue,values[index],id);
        }
        if(values.empty())
        {
          uiInterface.AddWarning("Warning:  empty <" + xmlstr::XML_TAG_TRUEVALUE + "> tag found; using defaults");
        }
    }
}

//__________________________________________________________
void 
ParseTreeToSettings::DoProfiles(TiXmlElement * forceElement, UIId forceId)
{
    TiXmlElement * profilesElement =
        singleOptionalChild(forceElement,xmlstr::XML_TAG_PROFILES);

    if(profilesElement != NULL)
    {
        string profilesString = getNodeText(profilesElement);
        ProftypeVec1d profiles = ProduceProftypeVec1dOrBarf(profilesString);
        size_t index;
        for(index=0; index < profiles.size(); index++)
        {
            UIId localId(forceId.GetForceType(),index);
            switch(profiles[index])
            {
                case profile_PERCENTILE:
                case profile_FIX:
                    uiInterface.doSet(uistr::profileByForce,ToString(profiles[index]),forceId);
                    uiInterface.doSet(uistr::profileByID,"true",localId);
                    break;
                case profile_NONE:
                    uiInterface.doSet(uistr::profileByID,"false",localId);
                    break;
            }
        }
    }
}
void
ParseTreeToSettings::DoConstraints(TiXmlElement * forceElement, UIId forceId)
{
  TiXmlElement * constraintsElement =
    singleOptionalChild(forceElement,xmlstr::XML_TAG_CONSTRAINTS);

  if(constraintsElement != NULL) {
    string constraintsString = getNodeText(constraintsElement);
    vector < paramstatus > constraints
      = ProduceParamstatusVec1dOrBarf(constraintsString);
    size_t index;
    for(index=0; index < constraints.size(); index++) {
      UIId localID(forceId.GetForceType(),index);
      uiInterface.doSet(uistr::constraintType,ToString(constraints[index]) ,localID);
    }
  }
}

void
ParseTreeToSettings::DoGroups(TiXmlElement * forceElement, UIId forceId)
{
  TiXmlNode * child = NULL;
  size_t index = 0;
  while((child = forceElement->IterateChildren(xmlstr::XML_TAG_GROUP,child)))
  {
    TiXmlElement * groupElement = child->ToElement();
    DoGroup(groupElement, forceId, index);
    index++;
  }
}

void
ParseTreeToSettings::DoGroup(TiXmlElement * groupElement, UIId forceId,
                             size_t index)
{
  string constraintType
    = getNodeAttributeValue(groupElement,xmlstr::XML_ATTRTYPE_CONSTRAINT);
  string indicesString = getNodeText(groupElement);
  
  UIId localID(forceId.GetForceType(),index);
  uiInterface.doSet(uistr::groupParamList, indicesString, localID);
  uiInterface.doSet(uistr::groupConstraintType, constraintType, localID);
}


void
ParseTreeToSettings::DoPriors(TiXmlElement * forceElement, UIId forceId)
{
  TiXmlNode * child = NULL;
  while((child = forceElement->IterateChildren(xmlstr::XML_TAG_PRIOR,child)))
  {
    TiXmlElement * priorElement = child->ToElement();
    DoPrior(priorElement, forceId);
  }
}

void
ParseTreeToSettings::DoPrior(TiXmlElement * priorElement, UIId forceId)
{
  TiXmlElement * parameterElement =
    singleOptionalChild(priorElement,xmlstr::XML_TAG_PARAMINDEX);
  
  long paramID = uiconst::GLOBAL_ID;

  if (parameterElement) {
    string paramName = getNodeText(parameterElement);
    try {
      paramID = ProduceLongOrBarf(paramName);
      paramID--;
    }
    catch (const data_error& e) {
      if ((!CaselessStrCmp(paramName, uistr::defaultStr)) &&
          (!CaselessStrCmp(paramName, uistr::allStr))) {
        m_parser.ThrowDataError("Parameter index must be an integer or 'all'",
                                priorElement->Row());
      }
      paramID = uiconst::GLOBAL_ID;
    }
  }
  UIId localId(forceId.GetForceType(), paramID);

  string priorTypeString
    = getNodeAttributeValue(priorElement,xmlstr::XML_ATTRTYPE_TYPE);
  uiInterface.doSet(uistr::priorType, priorTypeString, localId);

  try {
    TiXmlElement * lowerBoundElement =
      singleRequiredChild(priorElement,xmlstr::XML_TAG_PRIORLOWERBOUND);
    string lowerString = getNodeText(lowerBoundElement);
    uiInterface.doSet(uistr::priorLowerBound, lowerString, localId);

    TiXmlElement * upperBoundElement =
    singleRequiredChild(priorElement,xmlstr::XML_TAG_PRIORUPPERBOUND);
    string upperString = getNodeText(upperBoundElement);
    uiInterface.doSet(uistr::priorUpperBound, upperString, localId);
  }
  catch (const data_error&) {
    //Presumably, the lower bound was higher than the *default* upper
    // bound--try them in the reverse order instead.
    TiXmlElement * upperBoundElement =
      singleRequiredChild(priorElement,xmlstr::XML_TAG_PRIORUPPERBOUND);
    string upperString = getNodeText(upperBoundElement);
    uiInterface.doSet(uistr::priorUpperBound, upperString, localId);
  
    TiXmlElement * lowerBoundElement =
      singleRequiredChild(priorElement,xmlstr::XML_TAG_PRIORLOWERBOUND);
    string lowerString = getNodeText(lowerBoundElement);
    uiInterface.doSet(uistr::priorLowerBound, lowerString, localId);

  }
  
}

void ParseTreeToSettings::DoTraits(TiXmlElement * dataElement)
{
    TiXmlNode * child = NULL;

    long regionNumber = 0;

    while((child = dataElement->IterateChildren(xmlstr::XML_TAG_REGION,child)))
    {
      TiXmlElement * traitsElement = singleOptionalChild(child->ToElement(), xmlstr::XML_TAG_TRAITS);
        
        DoRegionTraits(traitsElement,regionNumber);
        regionNumber++;
    }
}

void ParseTreeToSettings::DoRegionTraits(TiXmlElement * traitsElement, long regionNumber)
{
  if (traitsElement != NULL) {
    TiXmlNode * traitNode = NULL;
    while((traitNode = traitsElement->IterateChildren(xmlstr::XML_TAG_TRAIT,traitNode)))
    {
      TiXmlElement * traitElement = traitNode->ToElement();
      DoRegionTrait(traitElement, regionNumber);
    }
  }
}

void ParseTreeToSettings::DoRegionTrait(TiXmlElement * traitElement, long regionNumber)
{
  TiXmlElement * nameElement = singleRequiredChild(traitElement, xmlstr::XML_TAG_NAME);
  string tname = getNodeText(nameElement);
  if (!uiInterface.GetCurrentVars().datapackplus.HasLocus(regionNumber, tname)){
    throw data_error("Error:  trait settings found for '" + tname + "', but no data was found for this trait.  Check spelling, or delete these settings.");
  }
  long locusNumber = uiInterface.GetCurrentVars().datapackplus.GetLocusIndex(regionNumber, tname);
  
  TiXmlElement * modelElement = singleOptionalChild(traitElement, xmlstr::XML_TAG_MODEL);
  if (modelElement != NULL) {
    DoDLModel(modelElement,regionNumber,locusNumber);
  }

  TiXmlElement * locationsElement = singleOptionalChild(traitElement, xmlstr::XML_TAG_POSSIBLE_LOCATIONS);
  if (locationsElement != NULL) {
    DoLocations(locationsElement, regionNumber, locusNumber);
  }

  //Do this after setting the range (locations) so we can warn/throw
  // appropriately
  TiXmlElement * analysisElement = singleOptionalChild(traitElement, xmlstr::XML_TAG_ANALYSIS);
  if (analysisElement != NULL) {
    DoAnalysis(analysisElement, regionNumber, locusNumber);
  }

  TiXmlElement * phenotypesElement = singleOptionalChild(traitElement, xmlstr::XML_TAG_PHENOTYPES);
  if (phenotypesElement != NULL) {
    DoPhenotypes(phenotypesElement, regionNumber, locusNumber);
  }
}

void ParseTreeToSettings::DoLocations(TiXmlElement* locationsElement, long regionNumber, long locusNumber)
{
  UIRegId locId(regionNumber,locusNumber, uiInterface.GetCurrentVars());
  rangeset rset;

  //Collect the whole range, then set it afterwards.
  TiXmlNode* rangeNode = NULL;
  while ((rangeNode = locationsElement->IterateChildren(xmlstr::XML_TAG_RANGE, rangeNode))) {
    TiXmlElement * rangeElement = rangeNode->ToElement();
    TiXmlElement * startElement = singleRequiredChild(rangeElement, xmlstr::XML_TAG_START);
    TiXmlElement * endElement   = singleRequiredChild(rangeElement, xmlstr::XML_TAG_END);
    long start = ProduceLongOrBarf(getNodeText(startElement));
    long end   = ProduceLongOrBarf(getNodeText(endElement));
    rangepair range = std::make_pair(start, end);
    range.second++;
    rset = AddPairToRange(range, rset);
  }
  uiInterface.GetCurrentVars().traitmodels.SetRange(locId, rset);
}

void ParseTreeToSettings::DoAnalysis(TiXmlElement* analysisElement, long regionNumber, long locusNumber)
{
  UIRegId locId(regionNumber,locusNumber, uiInterface.GetCurrentVars());
  string analysisString = getNodeText(analysisElement);
  mloc_type analysis = ProduceMlocTypeOrBarf(analysisString);
  uiInterface.GetCurrentVars().traitmodels.SetAnalysisType(locId, analysis);
}

void ParseTreeToSettings::DoPhenotypes(TiXmlElement* phenotypesElement, long regionNumber, long locusNumber)
{
  StringVec2d alleles = uiInterface.GetCurrentVars().datapackplus.GetUniqueAlleles(regionNumber, locusNumber);
  size_t nalleles = alleles[0].size(); //Assumes only one marker
  
  std::set<long> ploidies = uiInterface.GetCurrentVars().datapackplus.GetPloidies(regionNumber);
  //Now calculate how many genotypes we need.  For a given number
  // of alleles A, and ploidy P, we need:
  //
  //  (A + P - 1)!
  //  ------------
  //   P!(A - 1)!
  //
  // which is the formula for 'combination with repetition'.  See, for example
  // http://en.wikipedia.org/wiki/Combinatorics
  //
  // That's gotta be some sort of milestone--a URL in a comment!  Wow.
  //
  // At any rate, we need to calculate this formula for each possible ploidy,
  // and add them up.  Normally, there'd be only one, but there are exceptions
  // like if our region is on the X chromosome.

  size_t targetCombs = 0;
  for (std::set<long>::iterator ploid = ploidies.begin(); ploid != ploidies.end();
       ploid++) {
    targetCombs += static_cast<long>(factorial(nalleles + (*ploid) - 1)) /
      (static_cast<long>(factorial(*ploid)) * static_cast<long>(factorial(nalleles - 1)));
  }

  vector<TiXmlElement *> genotypeElements = getAllOptionalDescendantElements(phenotypesElement, xmlstr::XML_TAG_GENOTYPE);
  if (genotypeElements.size() < targetCombs) {
    string msg = "Error:  not enough genotypes listed in your phenotype list.  You must provide a set of phenotypes for every possible combination of alleles (for which you have " + ToString(nalleles) + ")";
    if (ploidies.size() > 1) {
      msg += ".  Also note that you have " + ToString(ploidies.size()) + " different ploidies in your list of individuals, meaning that you must provide a complete list of combinations of alleles for all different possible numbers of genes, too.";
    }
    else {
      msg += ", for the ploidy of your individuals (which are all " + ToString(*ploidies.begin()) + ".)";
    }
    msg += "  All told, you should have " + ToString(targetCombs) + " genotypes, while you currently have " + ToString(genotypeElements.size()) + ".";
    throw data_error(msg);
  }
  if (genotypeElements.size() > targetCombs) {
    string msg = "Error:  You have provided too many genotypes for the number of alleles for your trait (" + ToString(nalleles) + ") for the ploidies of your sampled individuals.  You should have " + ToString(targetCombs) + ", but currently have " + ToString(genotypeElements.size()) + ".  Remember that order doesn't matter for genotypes--being heterozygous should give you the same phenotype regardless of which allele is which.";
    throw data_error(msg);
  }

  for (vector<TiXmlElement* >::iterator genotypeElement = genotypeElements.begin(); genotypeElement != genotypeElements.end(); genotypeElement++) {
    //Get the set of alleles.
    TiXmlElement* alleleElement = singleRequiredChild(*genotypeElement, xmlstr::XML_TAG_ALLELES);
    StringVec1d alleles = getNodeTextSplitOnWhitespace(alleleElement);

    //Get the (potentially many) associated phenotypes.
    TiXmlNode * phenotypeNode = NULL;
    while ((phenotypeNode = (*genotypeElement)->IterateChildren(xmlstr::XML_TAG_PHENOTYPE, phenotypeNode))) {
      TiXmlElement* phenotypeElement = phenotypeNode->ToElement();
      TiXmlElement* phenNameElement = singleRequiredChild(phenotypeElement, xmlstr::XML_TAG_PHENOTYPE_NAME);
      TiXmlElement* penetranceElement = singleRequiredChild(phenotypeElement, xmlstr::XML_TAG_PENETRANCE);

      string phenName = getNodeText(phenNameElement);
      double penetrance = ProduceDoubleOrBarf(getNodeText(penetranceElement));
      UIRegId locId(regionNumber,locusNumber, uiInterface.GetCurrentVars());
      uiInterface.GetCurrentVars().traitmodels.AddPhenotype(locId, alleles, phenName, penetrance);
    }
  }
}

  
