//$Id: xml_strings.h,v 1.59 2007/04/26 21:32:39 ewalkup Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#ifndef XMLSTRINGS_H
#define XMLSTRINGS_H

#include <string>

class xmlstr
{
public:

static const std::string XML_STRING_UNKNOWN_FILE   ;
static const std::string XML_STRING_COLON          ;
static const std::string XML_STRING_DASH           ;
static const std::string XML_STRING_USER           ;
static const std::string XML_STRING_NEWICK         ;

static const std::string XML_ERR_0                 ;
static const std::string XML_ERR_1                 ;
static const std::string XML_ERR_2                 ;
static const std::string XML_ERR_3                 ;
static const std::string XML_ERR_ATTR_MISSING_0    ;
static const std::string XML_ERR_ATTR_MISSING_1    ;
static const std::string XML_ERR_ATTR_MISSING_2    ;
static const std::string XML_ERR_ELEM_MISSING_0    ;
static const std::string XML_ERR_ELEM_MISSING_1    ;
static const std::string XML_ERR_ELEM_MISSING_2    ;
static const std::string XML_ERR_DATA_ERR_0        ;
static const std::string XML_ERR_DATA_ERR_1        ;
static const std::string XML_ERR_DATA_ERR_2        ;
static const std::string XML_ERR_DATA_ERR_3        ;
static const std::string XML_ERR_DUPLICATE_REGIONNAME_0;
static const std::string XML_ERR_DUPLICATE_REGIONNAME_1;
static const std::string XML_ERR_DUPLICATE_SAMPLENAME_0;
static const std::string XML_ERR_DUPLICATE_SAMPLENAME_1;
static const std::string XML_ERR_EXTRA_TAG_0       ;
static const std::string XML_ERR_EXTRA_TAG_1       ;
static const std::string XML_ERR_EXTRA_TAG_2       ;
static const std::string XML_ERR_EXTRA_TAG_TOP_0   ;
static const std::string XML_ERR_EXTRA_TAG_TOP_1   ;
static const std::string XML_ERR_FILE_ERR          ;
static const std::string XML_ERR_FILE_NOT_FOUND_0  ;
static const std::string XML_ERR_FILE_NOT_FOUND_1  ;
static const std::string XML_ERR_INCONSISTENT_REGION;
static const std::string XML_ERR_INTERNAL          ;
static const std::string XML_ERR_INVALID_METHOD_0  ;
static const std::string XML_ERR_INVALID_METHOD_1  ;
static const std::string XML_ERR_METHOD_TYPE_COUNT_0;
static const std::string XML_ERR_METHOD_TYPE_COUNT_1;
static const std::string XML_ERR_METHOD_TYPE_COUNT_2;
static const std::string XML_ERR_METHOD_TYPE_COUNT_3;
static const std::string XML_ERR_METHOD_USER_WITHOUT_VALUE_0;
static const std::string XML_ERR_METHOD_USER_WITHOUT_VALUE_1;
static const std::string XML_ERR_METHOD_USER_WITHOUT_VALUE_2;
static const std::string XML_ERR_MISSING_CONTENT_0 ;
static const std::string XML_ERR_MISSING_CONTENT_1 ;
static const std::string XML_ERR_MISSING_TAG_0     ;
static const std::string XML_ERR_MISSING_TAG_1     ;
static const std::string XML_ERR_MISSING_TAG_HIER_0;
static const std::string XML_ERR_MISSING_TAG_HIER_1;
static const std::string XML_ERR_MISSING_TAG_HIER_2;
static const std::string XML_ERR_NEST_0            ;
static const std::string XML_ERR_NEST_1            ;
static const std::string XML_ERR_NO_SUBTAG_0       ;
static const std::string XML_ERR_NO_SUBTAG_1       ;
static const std::string XML_ERR_NO_SUBTAG_2       ;
static const std::string XML_ERR_NO_TAG_0          ;
static const std::string XML_ERR_NO_TAG_1          ;
static const std::string XML_ERR_NOT_LAMARC        ;
static const std::string XML_ERR_NOT_MAPFILE       ;
static const std::string XML_ERR_NOT_XML           ;
static const std::string XML_ERR_NO_XML_DATA       ;
static const std::string XML_ERR_START_VALUE_COUNT_0;
static const std::string XML_ERR_START_VALUE_COUNT_1;
static const std::string XML_ERR_START_VALUE_COUNT_2;
static const std::string XML_ERR_START_VALUE_COUNT_3;
static const std::string XML_ERR_UNEXPECTED_ATTR_0 ;
static const std::string XML_ERR_UNEXPECTED_ATTR_1 ;
static const std::string XML_ERR_UNEXPECTED_ATTR_2 ;
static const std::string XML_ERR_UNEXPECTED_TAG_0  ;
static const std::string XML_ERR_UNEXPECTED_TAG_1  ;
static const std::string XML_ERR_UNEXPECTED_TAG_2  ;

static const std::string XML_IERR_DUP_ATTR_0       ;
static const std::string XML_IERR_DUP_ATTR_1       ;
static const std::string XML_IERR_DUP_ATTR_2       ;
static const std::string XML_IERR_DUP_CHILD_0      ;
static const std::string XML_IERR_DUP_CHILD_1      ;
static const std::string XML_IERR_DUP_CHILD_2      ;
static const std::string XML_IERR_DUP_TAG_0        ;
static const std::string XML_IERR_DUP_TAG_1        ;
static const std::string XML_IERR_NO_PARENT_TAG_0  ;
static const std::string XML_IERR_NO_PARENT_TAG_1  ;
static const std::string XML_IERR_NO_PARENT_TAG_2  ;
static const std::string XML_IERR_NO_TAG_0         ;
static const std::string XML_IERR_NO_TAG_1         ;
static const std::string XML_IERR_NO_TAG_2         ;


static const std::string XML_ATTRTYPE_CONSTRAINT   ;
static const std::string XML_ATTRTYPE_NAME         ;
static const std::string XML_ATTRTYPE_TYPE         ;
static const std::string XML_ATTRTYPE_VALUE        ;
static const std::string XML_ATTRTYPE_VERSION      ;

static const std::string XML_TAG_ALLELES           ;
static const std::string XML_TAG_ALPHA             ;
static const std::string XML_TAG_ANALYSIS          ;
static const std::string XML_TAG_AUTOCORRELATION   ;
static const std::string XML_TAG_BASE_FREQS        ;
static const std::string XML_TAG_BAYESIAN          ;
static const std::string XML_TAG_BAYESIAN_ANALYSIS ;
static const std::string XML_TAG_BLOCK             ;
static const std::string XML_TAG_CALCULATED        ;
static const std::string XML_TAG_CATEGORIES        ;
static const std::string XML_TAG_CHAINS            ;
static const std::string XML_TAG_COALESCENCE       ;
static const std::string XML_TAG_CONSTRAINTS       ;
static const std::string XML_TAG_CONVERT_OUTPUT    ;
static const std::string XML_TAG_CURVEFILE_PREFIX  ;
static const std::string XML_TAG_DATA              ;
static const std::string XML_TAG_DATABLOCK         ;
static const std::string XML_TAG_DISCARD           ;
static const std::string XML_TAG_DISEASE           ;
static const std::string XML_TAG_DISEASELOCATION   ;
static const std::string XML_TAG_DISEASESTATUS     ;
static const std::string XML_TAG_ECHO              ;
static const std::string XML_TAG_EFFECTIVE_POPSIZE ;
static const std::string XML_TAG_END               ;
static const std::string XML_TAG_FINAL             ;
static const std::string XML_TAG_FORCES            ;
static const std::string XML_TAG_FORMAT            ;
static const std::string XML_TAG_GENOTYPE          ;
static const std::string XML_TAG_GENOTYPE_RESOLUTIONS;
static const std::string XML_TAG_GROUP             ;
static const std::string XML_TAG_GROWTH            ;
static const std::string XML_TAG_GTRRATES          ;
static const std::string XML_TAG_HAPLOTYPES        ;
static const std::string XML_TAG_HAPLOTYPING       ;
static const std::string XML_TAG_HAP_COUNT         ;
static const std::string XML_TAG_HEATING           ;
static const std::string XML_TAG_HEATING_STRATEGY  ;
static const std::string XML_TAG_INDIVIDUAL        ;
static const std::string XML_TAG_INITIAL           ;
static const std::string XML_TAG_INTERVAL          ;
static const std::string XML_TAG_IN_SUMMARY_FILE   ;
static const std::string XML_TAG_ISOPT             ;
static const std::string XML_TAG_LAMARC            ;
static const std::string XML_TAG_LENGTH            ;
static const std::string XML_TAG_LOCATIONS         ;
static const std::string XML_TAG_LOCUSARRANGER     ;
static const std::string XML_TAG_LOGISTICSELECTION ;
static const std::string XML_TAG_MAPFILE           ;
static const std::string XML_TAG_MAP_POSITION      ;
static const std::string XML_TAG_MARKER_WEIGHTS    ;
static const std::string XML_TAG_MAX_EVENTS        ;
static const std::string XML_TAG_METHOD            ;
static const std::string XML_TAG_MIGRATION         ;
static const std::string XML_TAG_MODEL             ;
static const std::string XML_TAG_MU                ;
static const std::string XML_TAG_NAME              ;
static const std::string XML_TAG_NEWICKTREEFILE_PREFIX;
static const std::string XML_TAG_NORMALIZE         ;
static const std::string XML_TAG_NU                ;
static const std::string XML_TAG_NUMBER            ;
static const std::string XML_TAG_NUM_CATEGORIES    ;
static const std::string XML_TAG_NUM_SITES         ;
static const std::string XML_TAG_OFFSET            ;
static const std::string XML_TAG_OLD_SUMMARY_FILE  ;
static const std::string XML_TAG_OUT_SUMMARY_FILE  ;
static const std::string XML_TAG_OUT_XML_FILE      ;
static const std::string XML_TAG_PARAMETER_FILE    ;
static const std::string XML_TAG_PARAMINDEX        ;
static const std::string XML_TAG_PENETRANCE        ;
static const std::string XML_TAG_PHASE             ;
static const std::string XML_TAG_PHENOTYPE         ;
static const std::string XML_TAG_PHENOTYPES        ;
static const std::string XML_TAG_PHENOTYPE_NAME    ;
static const std::string XML_TAG_PLOTTING          ;
static const std::string XML_TAG_POPULATION        ;
static const std::string XML_TAG_POSSIBLE_LOCATIONS;
static const std::string XML_TAG_POSTERIOR         ;
static const std::string XML_TAG_PRIOR             ;
static const std::string XML_TAG_PRIORLOWERBOUND   ;
static const std::string XML_TAG_PRIORUPPERBOUND   ;
static const std::string XML_TAG_PROBABILITIES     ;
static const std::string XML_TAG_PROFILE           ;
static const std::string XML_TAG_PROFILES          ;
static const std::string XML_TAG_PROGRESS_REPORTS  ;
static const std::string XML_TAG_RANGE             ;
static const std::string XML_TAG_RATES             ;
static const std::string XML_TAG_RECOMBINATION     ;
static const std::string XML_TAG_REGION            ;
static const std::string XML_TAG_REGION_GAMMA      ;
static const std::string XML_TAG_RELATIVE_MURATE   ;
static const std::string XML_TAG_REPLICATES        ;
static const std::string XML_TAG_RESIMULATING      ;
static const std::string XML_TAG_RESULTS_FILE      ;
static const std::string XML_TAG_SAMPLE            ;
static const std::string XML_TAG_SAMPLES           ;
static const std::string XML_TAG_SEED              ;
static const std::string XML_TAG_SPACING           ;
static const std::string XML_TAG_START             ;
static const std::string XML_TAG_START_VALUES      ;
static const std::string XML_TAG_STATUS            ;
static const std::string XML_TAG_STRATEGY          ;
static const std::string XML_TAG_SWAP_INTERVAL     ;
static const std::string XML_TAG_TEMPERATURES      ;
static const std::string XML_TAG_TRACEFILE_PREFIX  ;
static const std::string XML_TAG_TRAIT             ;
static const std::string XML_TAG_TRAITS            ;
static const std::string XML_TAG_TRAIT_NAME        ;
static const std::string XML_TAG_TREE              ;
static const std::string XML_TAG_TREESIZE          ;
static const std::string XML_TAG_TRUEVALUE         ;
static const std::string XML_TAG_TTRATIO           ;
static const std::string XML_TAG_TYPE              ;
static const std::string XML_TAG_USE_CURVEFILES    ;
static const std::string XML_TAG_USE_IN_SUMMARY    ;
static const std::string XML_TAG_USE_NEWICKTREEFILE;
static const std::string XML_TAG_USE_OUT_SUMMARY   ;
static const std::string XML_TAG_USE_TRACEFILE     ;
static const std::string XML_TAG_VERBOSITY         ;

  
static const std::string XML_ATTRVALUE_KNOWN   ;
static const std::string XML_ATTRVALUE_OFF     ;
static const std::string XML_ATTRVALUE_UNKNOWN ;
static const std::string XML_ATTRVALUE_STICK   ;
static const std::string XML_ATTRVALUE_STICKEXP;
static const std::string XML_ATTRVALUE_CURVE   ;

static const std::string XML_WARN_DEPRECATED_TAG_0;
static const std::string XML_WARN_DEPRECATED_TAG_1;
static const std::string XML_WARN_DEPRECATED_TAG_2;

static const std::string DATA_MODEL_F84;

//static const std::string WHAT_DOES_VALGRIND_THINK;

};

#endif /* XMLSTRINGS_H */
