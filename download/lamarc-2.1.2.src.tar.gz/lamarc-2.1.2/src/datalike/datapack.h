//$Id: datapack.h,v 1.50 2007/02/01 19:21:47 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// In general, a DataPack owns a container of pointer to Regions, which
// own a container of Locus objects, which own a container of TipData objects.
//
// DataPack--a storage class, with a container of pointers to all
//    Regions programwide.  DataPack owns what the pointers point to.
//    It also tracks some population level data, number of populations
//    and population names.  It does not track any migration specific
//    info (which is handled by class ForceSummary).
//
// Written by Jim Sloan, heavily revised by Jon Yamato
// 2002/01/03 changed Tipdata::data to a vector for generality--Mary Kuhner

// NB  This code distinguishes between "markers" and "sites".  A marker
// is a site for which we have data.  In SNP data, for example, every base
// pair is a site, but only the SNPs are markers.  Data likelihoods are
// calculated on markers; recombination probabilities are calculated on
// sites.  Please keep these straight!

#ifndef DATAPACK_H
#define DATAPACK_H

#include "constants.h"
#include "partition.h"
#include "types.h"
#include "vectorx.h"
#include <assert.h>
#include <memory>
#include <stdlib.h>
#include <string>
#include <vector>

class Region;

class DataPack
{
private:
DataPack(const DataPack&);     // undefined
DataPack& operator=(const DataPack&);  // undefined

vector<Region *> regions;

PartitionNames m_partnames;
StringVec1d m_outputpopnames; // in the single population case
                              // save the MIG partition names here
LongVec1d m_finalcount; // this is set by SetFinalPartitionCount

public:

DataPack() {};
~DataPack();

long GetNTips() const; // return the total number of tips in all regions

long AddPartition(force_type, const string& partname);

long GetNPartitionsByForceType(force_type) const;
string GetPartitionName(force_type, long index) const;
long GetPartitionNumber(force_type, const string& name) const;
StringVec1d GetAllPartitionNames(force_type) const;
StringVec1d GetAllCrossPartitionNames() const;

// this function is provided to interface with tipdata objects
// it's also used by GetAllCrossPartitionNames which needs to pass
// false as an argument (it cares about partition forces with only
// one partition.
std::vector<std::map<force_type,std::string> >
GetCrossPartitionIds(bool ignoresinglepop = true) const;

// this function will return 0 if the membership vector is empty.
// it does this to interface with the BranchBuffer and
// Branch::ScoreEvent?
long GetCrossPartitionIndex(const LongVec1d& membership) const;
LongVec1d GetBranchMembership(long xpartindex) const;
std::map<force_type,string> GetTipId(long xpartindex) const;

long GetNPartitionForces() const;
long GetNCrossPartitions() const;
long GetNPartitions(unsigned long index) const;
LongVec1d GetAllNPartitions() const;

// called by ForceSummary::SummarizeData
void SetFinalPartitionCounts(LongVec1d pcounts);

void SetRegion(Region* r);

long        GetNMaxLoci()             const;
long        GetNRegions()             const {return regions.size();};
vector<Region*>& GetAllRegions()            {return regions;};
const vector<Region*>& GetAllRegions() const {return regions;};
Region&     GetRegion(long n)               {assert(n <
                                             static_cast<long>(regions.size()));
                                             return *regions[n];};
const Region&     GetRegion(long n)   const {assert(n < 
                                             static_cast<long>(regions.size()));
                                             return *regions[n];};
long GetNumMovingLoci(long reg) const;
StringVec1d GetAllRegionNames() const;
StringVec2d GetAllLociNames() const; // dim: region X locus
StringVec2d GetAllLociDataTypes() const; // dim: region X locus
StringVec2d GetAllLociMuRates() const;   // dim: region X locus
// used by XMLOutfile::Display()
StringVec1d ToXML(unsigned long nspaces) const;

// The next function is a helper function for the Menu subclass dealing
// with rearrangement
bool        CanHapArrange()           const;

// true if you have at least two linked markers
bool        CanMeasureRecombination()   const;

//This function is for the reportpage.
bool        AnyMapping()              const;
  
// Helper function for the xml-parser
void        RemoveUneededPartitions();

// Helper function for the F84 data model
DoubleVec1d CountOverallBaseFreqs() const;

// Helper function for lamarc FinishRegistry()
DoubleVec2d CreateParamScalarVector() const;

// Helper function for reportpage filling
DoubleVec1d GetRegionalPopSizeScalars() const;
LongVec1d   GetNumAllLociPerRegion() const;
bool HasMultiLocus() const;

// Helper function for xml parsing
bool IsDuplicateRegionName(const string& newname) const;

//The following two functions are used only when JSIM is defined:
// parallel run of fluctuate.
void WriteFlucFile(const string& outputfilename) const;
// doesn't handle loci or spacing
void WritePopulationXMLFiles(bool seperate_regions) const;

};

#endif /* DATAPACK_H */
