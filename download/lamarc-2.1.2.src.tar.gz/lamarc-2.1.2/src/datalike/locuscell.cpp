//$Id: locuscell.cpp,v 1.7 2006/11/09 18:39:36 lpsmith Exp $
#include "locuscell.h"

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

//_________________________________________________________________________

LocusCell::LocusCell(const vector<Cell_ptr>& src)
{
  DeepCopyCells(src);
} /* LocusCell ctor */

//_________________________________________________________________________

LocusCell::LocusCell(const LocusCell& src)
{
  DeepCopyCells(src.dlcells);
} /* LocusCell copy ctor */

//_________________________________________________________________________

LocusCell::LocusCell(const vector<LocusCell>& src)
{
  //For use when constructing a LocusCell from haplotypes, which come
  // in a marker-by-marker vector, and need to be concatenated.
  vector<Cell_ptr> src_ptrs;
  for (unsigned long marker=0; marker<src.size(); marker++) {
    assert(src.size() == 1);
    src_ptrs.push_back(src[marker][0]);
  }
  DeepCopyCells(src_ptrs);
} /* LocusCell copy ctor */

//_________________________________________________________________________

LocusCell& LocusCell::operator=(const LocusCell& src)
{
  DeepCopyCells(src.dlcells);
  return *this;
} /* operator= */

//_________________________________________________________________________

LocusCell& LocusCell::operator+=(const LocusCell& src)
{
  assert(dlcells.size() == src.dlcells.size());
  for (size_t cell=0; cell<dlcells.size(); cell++) {
    (*dlcells[cell]).AddTo(src.dlcells[cell]);
  }
  return *this;
} /* operator= */

//_________________________________________________________________________

LocusCell& LocusCell::operator*=(double mult)
{
  for (size_t cell=0; cell<dlcells.size(); cell++) {
    (*dlcells[cell]).MultiplyBy(mult);
  }
  return *this;
} /* operator= */

//_________________________________________________________________________

bool LocusCell::operator==(const LocusCell& src) const
{
  unsigned long cell;
  for (cell = 0; cell < dlcells.size(); ++cell) {
    if (dlcells[cell]->DiffersFrom(src.dlcells[cell]) != FLAGLONG) 
      return false;
  } 
  return true;
} /* operator== */

//_________________________________________________________________________

void LocusCell::DeepCopyCells(const vector<Cell_ptr>& src)
{
  dlcells.clear();
  unsigned long cell;
  for (cell = 0; cell < src.size(); ++cell) {
    dlcells.push_back(Cell_ptr(src[cell]->Copy()));
  }

} /* DeepCopyCells */

//_________________________________________________________________________

bool LocusCell::DiffersFrom(const LocusCell& other, long marker) const
{
  return !dlcells[0]->IsSameAs(other.dlcells[0],marker);
} /* DiffersFrom */

void LocusCell::SetAllCategoriesTo(DoubleVec1d& state, long marker)
{
  dlcells[0]->SetAllCategoriesTo(state, marker);
}
