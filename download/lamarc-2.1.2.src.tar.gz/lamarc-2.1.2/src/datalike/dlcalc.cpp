//$Id: dlcalc.cpp,v 1.80 2007/02/15 21:39:01 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include <iostream>
#include "dlcalc.h"
#include "datapack.h"
#include "locus.h"
#include "dlmodel.h"
#include "tree.h"
#include "timelist.h"
#include "registry.h"
#include "random.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

//___________________________________________________________________
//___________________________________________________________________

DLCalculator::DLCalculator(const Locus& locus)
  : m_datamodel(*(locus.GetDataModel())),
    m_markerpos(locus.GetMarkerLocations())
{
// deliberately blank
} /* DLCalculator::DLCalculator */

//___________________________________________________________________

DLCalculator::DLCalculator(const DLCalculator& src)
: m_datamodel(src.m_datamodel),
  m_markerpos(src.m_markerpos)
{
} /* DLCalculator copy constructor */

//___________________________________________________________________

ChildInfo
DLCalculator::GetChildInfo(Branch_ptr branch, long locus, long childindex,
                           long cellindex, long posn, bool moving) const
{
  Branch_ptr child = branch->GetValidChild(branch->Child(childindex), posn);
  double length = branch->HowFarTo(*child);
  return ChildInfo(child->GetDLCell(locus, cellindex, moving), length);
} /* GetChildInfo */

//___________________________________________________________________

ChildInfo DLCalculator::NullChildInfo() const
{
  Cell_ptr nullcell(new NullCell);
  double length = FLAGDOUBLE;
  return ChildInfo(nullcell, length);
} /* NullChildInfo */

//___________________________________________________________________

rangepair DLCalculator::SitePairToMarkerPair(rangepair sites)
{
long firstmrkr = FLAGLONG;
long lastmrkr = FLAGLONG;
long firstsite = sites.first;
long lastsite = sites.second;
long nmarkers = m_markerpos.size();

assert (firstsite < lastsite);

--lastsite;    // calling code assumes half-open intervals

// if we are at the extreme right or left, outside the range
// of markers, return immediately

if (lastsite < m_markerpos.front() || firstsite > m_markerpos.back())
  return(rangepair(FLAGLONG, FLAGLONG));

// find first marker that is within site range, inclusive
long marker;
for (marker = 0; marker < nmarkers; ++marker) {
  if (m_markerpos[marker] > lastsite) {    // we've passed the end
    return(rangepair(FLAGLONG,FLAGLONG));
  }
  if (m_markerpos[marker] >= firstsite) {  // found it
    firstmrkr = marker;
    break;
  }
}

// find first marker past the end of site range (which may be the
// non-existent marker after all markers; this is a half-open
// interval).

for (marker = nmarkers - 1; marker >= 0; --marker) {
  if (m_markerpos[marker] <= lastsite) {     
    lastmrkr = marker + 1;                   // found it; we return the
                                             // next marker for half-open
    break;
  }
}

assert(firstmrkr != FLAGLONG && lastmrkr != FLAGLONG);
assert(lastmrkr > firstmrkr);

return(rangepair(firstmrkr, lastmrkr));

} /* SitePairToMarkerPair */

void DLCalculator::SimulateData(Tree& tree, Locus& locus)
{
  locus.ClearVariability();
  rangepair span = locus.GetSiteSpan();
  DoubleVec1d rates = m_datamodel.ChooseRandomRates(span.second - span.first);
  //Need vector instead of single rate for autocorrelation.

  LongVec1d markers = locus.GetMarkerLocations();
  for (unsigned long marker=0; marker<markers.size(); marker++) {
    long site = markers[marker];
    double rate = rates[site - span.first];

    // reverse iterate through the tree simulating data upwards
    TimeList& timelist = tree.GetTimeList();
    for (Branchconstriter brrit = timelist.RBegin(); brrit != timelist.REnd(); brrit++) {
      if ((*brrit)->Event() == btypeCoal ||
          (*brrit)->Event() == btypeTip) {
        // try to find applicable parent
        Branch_ptr pParent = (*brrit)->GetValidParent(site);

        DoubleVec1d state;
        if (pParent == Branch::NONBRANCH) {
          // if no parent found:
          state = m_datamodel.ChooseAncestralState(marker);
        }
        else {
          double length = pParent->HowFarTo(**brrit);
          state = m_datamodel.SimulateMarker(rate*length, marker, pParent->GetDLCell(locus.GetIndex(), 0, locus.IsMoving())->GetStateFor(marker, 0));
        }
        //Find where to save the information and then save it.
        Cell_ptr childdl = (*brrit)->GetDLCell(locus.GetIndex(), 0, locus.IsMoving());
        childdl->SetAllCategoriesTo(state, marker);
        if ((*brrit)->Event() == btypeTip) {
          //Keep track of the variability of the simulated data.
          locus.SaveState(state, marker, boost::dynamic_pointer_cast<TBranch>(*brrit)->m_label);
          //LS TEST 
          //std::cout << childdl->DLsToString(marker, marker) << std::endl;
        }
      }
    }
  }
} /* SimulateData */

//___________________________________________________________________
//___________________________________________________________________

void DLCalculator::CopyDataFrom(Locus& destloc, Locus& origloc, Tree& tree)
{
  destloc.ClearVariability();
  LongVec1d markers = destloc.GetMarkerLocations();

  for (unsigned long marker=0; marker<markers.size(); marker++) {
    long site = markers[marker];
    assert(origloc.SiteInLocus(site));
  
    TimeList& timelist = tree.GetTimeList();
    DoubleVec2d origstates;
    DoubleVec2d deststates;
    long n_destalleles = (*timelist.Begin())->GetDLCell(destloc.GetIndex(), 0, destloc.IsMoving())->GetStateFor(marker, 0).size();
    DoubleVec1d zeroes(n_destalleles, 0.0);
    for (Branchconstiter brit = timelist.FirstTip(); brit != timelist.End();
         brit = timelist.NextTip(brit)) {
      origstates.push_back((*brit)->GetDLCell(origloc.GetIndex(), 0, origloc.IsMoving())->GetStateFor(origloc.SiteToMarker(site), 0));
      deststates.push_back(zeroes); //Just to be sure.
    }

    //Now.  The trick is that the two loci may have different numbers
    // of possible alleles.  So if the destination locus has an equal number
    // or more alleles than the original, we'll simply overwrite the first X
    // alleles with the new alleles, leaving any extra alleles at zero.
    //
    //When there are 'missing' alleles in the destination that are not
    // in the original, we must punt, and assign multiple original alleles
    // to the same destination allele.  We want to be able to preserve any
    // diversity, however:  it's no good if the only two alleles the original
    // visited are lumped together in the destination.  So.  We first check
    // to see what the most frequent allele is in the original, and assign
    // that to the first allele of the desination.  Then we assign the next
    // most frequent allele to the second allele of the destination.  We keep
    // doing this until we run out of destination alleles.  Then we add
    // any remaining original alleles to the final destination allele.
    //
    //Whew!

    //So, OK.  first:  Sum the originals to figure out who's the greatest.
    DoubleVec1d origsums(origstates[0].size(), 0.0);
    for (unsigned long i=0; i<origstates.size(); i++) {
      std::transform(origstates[i].begin(),
                     origstates[i].end(),
                     origsums.begin(),
                     origsums.begin(),
                     std::plus<double>());
    }

    //Now make a multimap so we can loop over it.
    std::multimap<double, unsigned long> mindexes;
    for (unsigned long i=0; i<origsums.size(); i++) {
      mindexes.insert(std::make_pair(origsums[i], i));
    }
    long destindex = 0;
    for (std::multimap<double, unsigned long>::reverse_iterator mindex=mindexes.rbegin();
         mindex != mindexes.rend(); mindex++) {
      long origindex = mindex->second;
      //We now have the index of the original allele and of the destination
      // allele, so we're good to go.

      if (mindex->first != 0) {
        for (unsigned long tip=0; tip<origstates.size(); tip++) {
          deststates[tip][destindex] += origstates[tip][origindex];
        }
      }

      if (destindex < n_destalleles - 1) {
        destindex++;
      }
    }
    //Now copy everything back into the dlcells of the destination
    unsigned long tip=0;
    for (Branchconstiter brit = timelist.FirstTip(); brit != timelist.End();
         brit = timelist.NextTip(brit), tip++) {
      Cell_ptr childdl = (*brit)->GetDLCell(destloc.GetIndex(), 0, destloc.IsMoving());
      //Copy the information
      childdl->SetAllCategoriesTo(deststates[tip], marker);
      destloc.SaveState(deststates[tip], marker, boost::dynamic_pointer_cast<TBranch>(*brit)->m_label);
    }
  }
}

//___________________________________________________________________
void DLCalculator::Randomize(Locus& destloc, rangeset rset, Tree& tree)
{
  std::cout << "Deleted range: " << ToString(rset) << std::endl;
  // Take all sites in rset and equilibrate their dlcells.
  LongVec1d markers = destloc.GetMarkerLocations();

  for (unsigned long marker=0; marker<markers.size(); marker++) {
    long site = markers[marker];
    if (rset == AddPairToRange(std::make_pair(site, site+1), rset)) {
  
      TimeList& timelist = tree.GetTimeList();
      long n_destalleles = (*timelist.Begin())->GetDLCell(destloc.GetIndex(), 0, destloc.IsMoving())->GetStateFor(marker, 0).size();
      DoubleVec1d ones(n_destalleles, 1.0);
      for (Branchconstiter brit = timelist.FirstTip();
           brit != timelist.End(); brit = timelist.NextTip(brit)) {
        Cell_ptr childdl = (*brit)->GetDLCell(destloc.GetIndex(), 0, destloc.IsMoving());
        //Copy the information
        childdl->SetAllCategoriesTo(ones, marker);
      }
    }
  }
}
//___________________________________________________________________
//___________________________________________________________________

NucCalculator::NucCalculator(const Locus& locus) 
: DLCalculator(locus)
{
  // deliberately blank
} /* NucCalculator ctor */

//___________________________________________________________________

NucCalculator::NucCalculator(const NucCalculator& src)
: DLCalculator(src)
{
// deliberately blank
} /* NucCalculator copy constructor */

//___________________________________________________________________

LongVec1d NucCalculator::CalculateAliasesFromData(const vector<DoubleVec2d>& data) const
{
  // compute aliases, starting at position 1 because 0 can never be aliased.
  // If an alias partner is not found, the marker's alias will remain at the 
  // -1 (no alias) with which it was initialized
  long nmarkers = data.size();
  LongVec1d alias(nmarkers, -1L);
  long partner, marker;
  for (marker = 1; marker < nmarkers; ++marker) {
    for (partner = marker - 1; partner >= 0; --partner) {
      if (data[marker] == data[partner]) {
        // found an alias
        alias[marker] = partner;
        break;
      } 
    } 
  }

  return alias;
  
} /* CalculateAliasesFromData */

//___________________________________________________________________

LongVec1d NucCalculator::RecalculateAliases(const Tree& tree, const Locus& locus) const
{
  const TimeList& timelist = tree.GetTimeList();
  long cell = 0; // we use the primary DLCell for this
  long cat = 0; // we alias based on first category

  long ntips = timelist.GetNTips();
  long nmarkers = locus.GetNmarkers();
  DoubleVec1d basepattern(4,0.0);
  DoubleVec2d tippattern(ntips, basepattern);
  vector<DoubleVec2d> markerpattern(nmarkers, tippattern);

  Branchconstiter brit = timelist.FirstTip();
  long tip, marker, base;
  for (tip = 0; brit != timelist.End(); brit = timelist.NextTip(brit), ++tip) {
    Cell_ptr dlcell = (*brit)->GetDLCell(locus.GetIndex(), cell, locus.IsMoving());
    //Note:  We never worry about aliasing for moving loci.
    for (marker = 0; marker < nmarkers; ++marker) {
      SiteDL siteDLs = dlcell->GetSiteDLs(marker); 
      for (base = 0; base < 4; ++base) {
        markerpattern[marker][tip][base] = siteDLs[cat][base];
      }
    }
  }
  assert(tip == ntips);

  return CalculateAliasesFromData(markerpattern);

} /* RecalculateAliases */

//___________________________________________________________________

LongVec1d NucCalculator::SetupAliases(const Locus& locus) const
{
  long nmarkers = locus.GetNmarkers();

  long cat = 0; // we alias based on the first category

  long ntips = locus.GetNTips();
  const vector<LocusCell>& tipcells = locus.GetTipCells();
  DoubleVec1d basepattern(4,0.0);
  DoubleVec2d tippattern(ntips, basepattern);
  vector<DoubleVec2d> markerpattern(nmarkers, tippattern);

  // dump the data into a usable form
  long marker, tip, base;
  for (tip = 0; tip < ntips; ++tip) {
    Cell_ptr dlcell = tipcells[tip][0]; // the primary Cell
    for (marker = 0; marker < nmarkers; ++marker) {
      SiteDL siteDLs = dlcell->GetSiteDLs(marker);
      for (base = 0; base < 4; ++base) {
        markerpattern[marker][tip][base] = siteDLs[cat][base];
      }
    }
  }

  return CalculateAliasesFromData(markerpattern);

} /* SetupAliases */

//___________________________________________________________________

void NucCalculator::CalculateSite(Cell_ptr child1, Cell_ptr child2,
                                  Cell_ptr newcell, long pos, long alias)
{
SiteDL newsiteDLs;

SiteDL child1DLs = child1->GetSiteDLs(pos);
SiteDL child2DLs = child2->GetSiteDLs(pos);

// if the alias is invalid, calculate; else use the alias
if (alias == -1) {
   newsiteDLs = dynamic_cast<NucModel&>(m_datamodel).
                   ComputeSiteDLs(child1DLs,child2DLs);
   if (m_datamodel.ShouldNormalize()) {
     double newnorm = newcell->Normalize(newsiteDLs) +
       child1->GetNorms(pos) + child2->GetNorms(pos);
     newcell->SetNorms(newnorm, pos);
   }
} else {
   newsiteDLs = newcell->GetSiteDLs(alias);
   newcell->SetNorms(newcell->GetNorms(alias),pos);
}

newcell->SetSiteDLs(pos,newsiteDLs);

} /* NucCalculator::CalculateSite */

//___________________________________________________________________

void NucCalculator::Breakalias(LongVec1d& aliases, const rangevector& subtrees)
{
  long tr;
  long nsubtrees(subtrees.size());

  // skip the first subtree because it can't break any aliases;
  // for all other subtrees, break all aliases that cross the
  // subtree boundary
  for (tr = 1; tr < nsubtrees; ++tr) {
    rangepair marker = SitePairToMarkerPair(subtrees[tr]);
    long pos;
    for (pos = marker.first; pos < marker.second; ++pos) {
      assert(static_cast<unsigned long>(pos) < aliases.size());
      if (aliases[pos] < marker.first) aliases[pos] = -1;
    }
  }

} /* NucCalculator::Breakalias */

//___________________________________________________________________
//___________________________________________________________________

DLCalculator* DNACalculator::Clone() const
{
DNACalculator* pnewcalc = new DNACalculator(*this);

return(pnewcalc);

} /* DNACalculator::Clone */

//___________________________________________________________________

double DNACalculator::Calculate(Tree& tree, const Locus& locus, bool moving)
{
Branch_ptr branch = Branch::NONBRANCH;
Cell_ptr dlcell;
double totallike = 0.0;
long nsubtrees, tr;
NucModel& datmodel = dynamic_cast<NucModel&>(m_datamodel);
ChildInfo child0, child1;
long primarycell = 0;
long curmarker;
long loc = locus.GetIndex();
LongVec1d aliases = tree.GetAliases(locus.GetIndex());

// Find the subtrees
rangepair span = locus.GetSiteSpan();
rangevector subtrees = tree.GetLocusSubtrees(span);
nsubtrees = subtrees.size();

// Update the aliases.
Breakalias(aliases, subtrees);

// Initialize the model categories storage
datmodel.ResetCatCells();

// Step through the subtrees to compute the data likelhoods
TimeList& timelist = tree.GetTimeList();
for (tr = 0; tr < nsubtrees; tr++) {
   rangepair marker = SitePairToMarkerPair(subtrees[tr]);
   // bail out if there are no markers in this subtree
   if (marker.first == FLAGLONG) continue;

   long firstsite = subtrees[tr].first;

   Branchiter brit;
   for (brit = timelist.FirstCoal(); brit != timelist.End();
      brit = timelist.NextCoal(brit)) {
      branch = *brit;
      if (branch->ShouldCalcDL(firstsite)) {
         // Find "real" children and appropriate branch lengths.
         child0 = GetChildInfo(branch, loc, 0, primarycell, firstsite, moving);
         child1 = GetChildInfo(branch, loc, 1, primarycell, firstsite, moving);

         // Precalculate exponential terms
         datmodel.RescaleLengths(child0.m_length, child1.m_length);

         // Calculate the data likelihood at each position.
         dlcell = branch->GetDLCell(loc, primarycell, moving);
         for(curmarker = marker.first; curmarker < marker.second; 
             ++curmarker) {
            CalculateSite(child0.m_cell, child1.m_cell, dlcell, curmarker, 
                          aliases[curmarker]);
         }
      }
   }

   // Check the DLs for the subtree at the root, relies on flow through
   // to be at root.

   bool active0 = branch->Child(0)->m_range.IsSiteActive(firstsite);
   bool active1 = branch->Child(1)->m_range.IsSiteActive(firstsite);

   if (!active0 || !active1) {
     dlcell = branch->GetDLCell(loc, primarycell, moving);
     if (!active0) {
        child0 = NullChildInfo();
        child1 = GetChildInfo(branch, loc, 1, primarycell, firstsite, moving);
     } else {
        child0 = GetChildInfo(branch, loc, 0, primarycell, firstsite, moving);
        child1 = NullChildInfo();
     }
     datmodel.RescaleLengths(child0.m_length, child1.m_length);
     for (curmarker = marker.first; curmarker < marker.second; 
          ++curmarker) {
        CalculateSite(child0.m_cell, child1.m_cell, dlcell, curmarker,
          aliases[curmarker]);
     }
   }

   totallike += datmodel.ComputeSubtreeDL(*dlcell, 
		   dlcell->GetSiteDLs(marker.first),
                   dlcell->GetSiteDLs(marker.second), 
                   marker.first);
}

return totallike;
} /* DNACalculator::Calculate */

//___________________________________________________________________
//___________________________________________________________________

SNPCalculator::SNPCalculator(const Locus& locus)
: NucCalculator(locus),
  m_invarmodel(dynamic_cast<NucModel*>(m_datamodel.Clone()))
{
  assert(m_invarmodel);
  m_invarmodel->SetNmarkers(INVARIANTS); // the invariant model should have
                                       // 1 "marker" for each base-type

} /* SNPCalculator::SNPCalculator */

//___________________________________________________________________

SNPCalculator::SNPCalculator(const SNPCalculator& src)
: NucCalculator(src),
  m_invarmodel(dynamic_cast<NucModel*>(src.m_invarmodel->Clone()))
{
  assert(m_invarmodel);
} /* SNPCalculator::copy ctor */

//___________________________________________________________________

SNPCalculator::~SNPCalculator()
{
  delete m_invarmodel;

} /* SNPCalculator::dtor */

//___________________________________________________________________

DLCalculator* SNPCalculator::Clone() const
{
SNPCalculator* pnewcalc = new SNPCalculator(*this);

return(pnewcalc);

} /* SNPCalculator::Clone */

//___________________________________________________________________

void SNPCalculator::CalculateInvarSite(Cell_ptr child1,
   Cell_ptr child2, Cell_ptr newcell, long pos)
{
SiteDL child1DLs = child1->GetSiteDLs(pos);
SiteDL child2DLs = child2->GetSiteDLs(pos);

// no alias for invariant sites

SiteDL newsiteDLs = m_invarmodel->ComputeSiteDLs(child1DLs,child2DLs);

if (m_invarmodel->ShouldNormalize()) {
  double norm1 = child1->GetNorms(pos);
  double norm2 = child2->GetNorms(pos);
  double newnorm = newcell->Normalize(newsiteDLs) +
    norm1 + norm2;
  newcell->SetNorms(newnorm,pos);
}

newcell->SetSiteDLs(pos,newsiteDLs);

} /* SNPCalculator::CalculateInvarSite */

//___________________________________________________________________

/* A horrible truth to remember about this code:  the storage used
   for invariant site calculations is *re-used*.  You can never assume
   that that information is still around; the next subtree will wipe
   it out.  This is why we recalculate invariant sites throughout the
   whole tree every time, even though, in theory, this is not necessary. 
   There is a possible but very difficult OPTIMIZATION opportunity here.
   Mary June 11 2002
*/

double SNPCalculator::Calculate(Tree& tree, const Locus& locus, bool moving)
{
  if (moving == true) {
    assert(false);
    throw implementation_error("It should be impossible to map a segment that is a SNP.  It's weird enough if it's DNA.");
  }
  Branch_ptr branch = Branch::NONBRANCH;
  Branch_ptr child1 = Branch::NONBRANCH;
  Branch_ptr child2 = Branch::NONBRANCH;
  Cell_ptr dlcell, dlcell1, dlcell2;
  double length1 = 0.0;
  double length2 = 0.0; 
  double totallike = 0.0;
  long tr, curmarker;
  NucModel& datmodel = dynamic_cast<NucModel&>(m_datamodel);
  long loc = locus.GetIndex();
  LongVec1d aliases = tree.GetAliases(locus.GetIndex());

  // determine the subtrees
  rangepair span = locus.GetSiteSpan();
  rangevector subtrees = tree.GetLocusSubtrees(span);
  long nsubtrees = subtrees.size();

  // Update the aliases.
  Breakalias(aliases, subtrees);

  // Initialize the model categories storage
  datmodel.ResetCatCells();
  m_invarmodel->ResetCatCells();

  // Step through the subtrees to compute the data likelhoods
  TimeList& timelist = tree.GetTimeList();
  for (tr = 0; tr < nsubtrees; ++tr) {
    rangepair marker = SitePairToMarkerPair(subtrees[tr]);
    long firstsite = subtrees[tr].first;

    // no markers in this subtree is handled by the rangepair,
    // marker, having the same value in both first and second.
    // Currently that value is FLAGLONG.

    Branchiter brit;
    for (brit = timelist.FirstCoal(); brit != timelist.End();
      brit = timelist.NextCoal(brit)) {
      branch = *brit;
      if (branch->CanCalcDL(firstsite)) {
        // Precalculate the exponential values based on branch length.
        child1 = branch->GetValidChild(branch->Child(0),firstsite);
        length1 = branch->HowFarTo(*child1);
        child2 = branch->GetValidChild(branch->Child(1),firstsite);
        length2 = branch->HowFarTo(*child2);

        // Calculate the data likelihood at each position for variable sites,
        // if appropriate; we skip this if the branch is marked "doesn't need updating"
        if (branch->ShouldCalcDL(firstsite)) {
          dlcell1 = child1->GetDLCell(loc, 0, moving);
          dlcell2 = child2->GetDLCell(loc, 0, moving);
          dlcell = branch->GetDLCell(loc, 0, moving);
          datmodel.RescaleLengths(length1, length2);
          for (curmarker = marker.first; curmarker < marker.second;
               ++curmarker) {
            CalculateSite(dlcell1,dlcell2,dlcell,curmarker,
                          aliases[curmarker]);
          }
        }

        // Calculate the invariant data likelihood for this branch,
        // using baseA for allAs, baseC for allCs, etc.
        dlcell1 = child1->GetDLCell(loc, 1, moving);
        dlcell2 = child2->GetDLCell(loc, 1, moving);
        dlcell = branch->GetDLCell(loc, 1, moving);
        m_invarmodel->RescaleLengths(length1, length2);
        for (curmarker = baseA; curmarker <= baseT; ++curmarker) {
          CalculateInvarSite(dlcell1,dlcell2,dlcell,curmarker);
        }
      }
    }

    // Check the DLs for the subtree at the root, relys on flow through
    // to be at root.
    bool active0 = branch->Child(0)->m_range.IsSiteActive(firstsite);
    bool active1 = branch->Child(1)->m_range.IsSiteActive(firstsite);

    Cell_ptr nullcell(new NullCell);

    if (!active0 || !active1) {
      dlcell = branch->GetDLCell(loc, 0, moving);
      // the root is a one-legged coalescence, was not computed above
      // and must be done here
      assert(active0 || active1);   // a zero-legged coalecence!?
      if (!active0) {
        dlcell1 = nullcell;
        child2 = branch->GetValidChild(branch->Child(1),firstsite);
        dlcell2 = child2->GetDLCell(loc, 0, moving);
        length1 = FLAGDOUBLE;
        length2 = branch->HowFarTo(*child2);
      } else if (!active1) {
        child1 = branch->GetValidChild(branch->Child(0),firstsite);
        length1 = branch->HowFarTo(*child1);
        dlcell1 = child1->GetDLCell(loc, 0, moving);
        length2 = FLAGDOUBLE;
        dlcell2 = nullcell;
      }

      datmodel.RescaleLengths(length1, length2);

      // Calculate the data likelihood at each position.
      for (curmarker = marker.first; curmarker < marker.second; 
           curmarker++) {
        CalculateSite(dlcell1, dlcell2, dlcell,
                      curmarker,aliases[curmarker]);
      }
 
      // Calculate the invariant data likelihood for this branch,
      // using baseA for allAs, baseC for allCs, etc.
      if (active0) dlcell1 = child1->GetDLCell(loc, 1, moving);
      if (active1) dlcell2 = child2->GetDLCell(loc, 1, moving);
      dlcell = branch->GetDLCell(loc, 1, moving);
      m_invarmodel->RescaleLengths(length1, length2);
      for (curmarker = baseA; curmarker <= baseT; ++curmarker)
        CalculateInvarSite(dlcell1,dlcell2,dlcell,
                           curmarker);
    }

    // if the subtree contains no markers skip computing marker datalike
    if (marker.first != FLAGLONG) {
      dlcell = branch->GetDLCell(loc, 0, moving);
      totallike += datmodel.ComputeSubtreeDL(*dlcell,
                                             dlcell->GetSiteDLs(marker.first),
                                             dlcell->GetSiteDLs(marker.second),
                                             marker.first);
    }

    // Calculate the invariant marker likelihood for the subtree,
    // using baseA for allAs, baseC for allCs, etc.
    long ninvarmarkers = subtrees[tr].second - subtrees[tr].first;
    if (marker.first != FLAGLONG) 
      ninvarmarkers -= marker.second - marker.first;

    if (ninvarmarkers > 0) {   // don't bother if no invariants in this subtree

      dlcell = branch->GetDLCell(loc, 1, moving); // switch to invariant cell

      // We are going to use a trick here, and add together the four
      // invariant site likelihoods into the bin normally occupied
      // by the first one.  This is ugly, but necessary to keep 
      // SNP-specific code out of the DataModel class.  The DataModel
      // needs to treat the four invariant markers as one big
      // supermarker, and cannot determine this itself; so we help it
      // out.

      // Changed to sum to "last" bin

      dlcell->SumMarkers(baseA, baseEnd, m_invarmodel->ShouldNormalize());

      //We multiply the log likelihood by the number of invariant markers
      // because this is equivalent to raising the likelihood to the power
      // of the number of invariants.
      totallike += ninvarmarkers * m_invarmodel->
        ComputeSubtreeDL(*dlcell,
                         dlcell->GetSiteDLs(baseEnd), 
                         dlcell->GetSiteDLs(baseEnd+1),    // one past the end
                         baseEnd);
    }
  }

return totallike;

} /* SNPCalculator::Calculate */

//___________________________________________________________________

void SNPCalculator::SimulateData(Tree& tree, Locus& locus)
{
  assert(false);
  //The default data simulator probably doesn't work with SNPs.

} /* SimulateData */

//___________________________________________________________________
//___________________________________________________________________

AlleleCalculator::AlleleCalculator(const Locus& locus)
: DLCalculator(locus)
{
  // blank
} /* AlleleCalculator::AlleleCalculator */

//___________________________________________________________________

AlleleCalculator::AlleleCalculator(const AlleleCalculator& src)
: DLCalculator(src)
{
  // blank
} /* AlleleCalculator::copy ctor, for internal use only */

//___________________________________________________________________

// Similar to DNA case except:
// no aliasing (identical microsats are too rare)
// uses a unique approach to non-marker sites (different from SNPs)

double AlleleCalculator::Calculate(Tree& tree, const Locus& locus, bool moving) 
{
  Branch_ptr branch = Branch::NONBRANCH;
  Cell_ptr dlcell;
  double totallike = 0.0;
  long posn1, posn2, firstsite, nsubtrees, tr, pos;
  AlleleModel& datmodel = dynamic_cast<AlleleModel&>(m_datamodel);
  DoubleVec1d scaled0, scaled1;
  ChildInfo child0, child1;
  if (moving) {
    //We need to recalculate the marker positions
    m_markerpos = locus.GetMarkerLocations();
    //LS DEBUG MAPPING:  we might need a similar thing for DNACalc:Calc,
    // but only if/when we allow mapping something with a DNA model (we
    // currently are restricted to K-Allele models).
  }

  const long primarycell = 0;
  long loc = locus.GetIndex();

  // Initialize the model categories storage
  datmodel.ResetCatCells();

  rangepair span = locus.GetSiteSpan();
  rangevector subtrees = tree.GetLocusSubtrees(span);
  nsubtrees = subtrees.size();

  // Step through the subtrees to compute the data likelhoods
  TimeList& timelist = tree.GetTimeList();
  for (tr = 0; tr < nsubtrees; tr++) {
    rangepair markers = SitePairToMarkerPair(subtrees[tr]);
    if (markers.first == FLAGLONG) continue;  // no markers in this subtree 
    posn1 = markers.first;
    posn2 = markers.second;
    firstsite = subtrees[tr].first;

    Branchiter brit;
    for (brit = timelist.FirstCoal(); brit != timelist.End();
         brit = timelist.NextCoal(brit)) {
      branch = *brit;
      if (branch->ShouldCalcDL(firstsite)) {
        dlcell = branch->GetDLCell(loc, 0, moving);
        // Find "real" children and appropriate branch lengths.
        child0 = GetChildInfo(branch, loc, 0, primarycell, firstsite, moving);
        child1 = GetChildInfo(branch, loc, 1, primarycell, firstsite, moving);

        // Precalculate branchlength terms 
        scaled0 = datmodel.RescaleLength(child0.m_length);
        scaled1 = datmodel.RescaleLength(child1.m_length);

        // Calculate the data likelihood at each position.
        for(pos = posn1; pos < posn2; ++pos) {
          datmodel.ComputeSiteDLs(child0.m_cell,
                                  child1.m_cell, dlcell, scaled0,
                                  scaled1, pos);
        }
      }
    }

    // Check the DLs for the subtree at the root, relies on flow through
    // to be at root.

    bool active0 = branch->Child(0)->m_range.IsSiteActive(firstsite);
    bool active1 = branch->Child(1)->m_range.IsSiteActive(firstsite);

    if (!active0 || !active1) {
      dlcell = branch->GetDLCell(loc, 0, moving);
      Cell_ptr nullcell(new NullCell);
      // the root is a one-legged coalescence, was not done
      // above and must be done now
      if (!active0) {
        child0 = NullChildInfo();
        child1 = GetChildInfo(branch, loc, 1, primarycell, firstsite, moving);
      } else if (!active1) {
        child0 = GetChildInfo(branch, loc, 0, primarycell, firstsite, moving);
        child1 = NullChildInfo();
      }
 
      scaled0 = datmodel.RescaleLength(child0.m_length);
      scaled1 = datmodel.RescaleLength(child1.m_length);

      for (pos = posn1; pos < posn2; pos++) {
        datmodel.ComputeSiteDLs(child0.m_cell,
                                child1.m_cell, dlcell, scaled0,
                                scaled1, pos);
      }
    }

    totallike += datmodel.ComputeSubtreeDLs(*dlcell, dlcell->GetSiteDLs(posn1),
                                            dlcell->GetSiteDLs(posn2), posn1);
  }

  // oddly enough, the microsat likelihood can be 1, and sometimes is, so
  // this assert is inappropriate.
  // assert(totallike != 0);  // this would be a likelihood=1, which is *too* likely

  return totallike;

} /* AlleleCalculator::Calculate */

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
