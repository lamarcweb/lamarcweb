//$Id: tipdata.h,v 1.5 2006/04/01 00:28:41 lpsmith Exp $

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/***************************************************************
 The TipData class holds the linked genetic data for a tip in a tree of
 haplotypes.  It also stores, for the tip, its partition membership,
 individual membership, and name.
 
 In general, TipData is a helper class for locus that stores much of
 the tip specific information in a manner that is useful for tree generation
 and rearrangement.  Each locus owns a container of TipData objects, which
 correspond to the tips in the tree that "belong" to that particular locus.

 TipData written by Jim Sloan, revised by Jon Yamato
 2002/01/03 changed Tipdata::data to a vector for generality--Mary Kuhner
 2004/09/15 split TipData out into its own file--Mary Kuhner
****************************************************************/

#ifndef TIPDATA_H
#define TIPDATA_H

#include <string>
#include <vector>
#include <map>
#include "types.h"
#include "vectorx.h"
#include "datatype.h"    // for DataType_ptr
#include "defaults.h"    // for force_type
#include "toxml.h"       // for SampleXML construction in TipData::ToXML()

//____________________________________________________________________
//____________________________________________________________________

class TipData
{
public:
  std::map<force_type,std::string> partitions; // forcename & partitionname
  long individual;
  long m_locus;
  long m_hap;
  bool m_nodata; //Flag for loci where the data is all in haplotypes
  std::string label;
  std::string m_popname; // we need to keep this because of migration's special
                       // status in the (current) xml
  StringVec1d data;  // one string per marker

TipData();
// we accept the default copy-ctor and operator=

void Clear(); // return tipdata to newly constructed form
              // used by xmlreader, DataFile::DoSamples()

bool BelongsTo(long ind) const;
bool IsInPopulation(const string& popname) const;

std::string GetFormattedData(const std::string& dlm) const;
long GetPartition(force_type partname) const;
LongVec1d GetBranchPartitions() const;

void RemovePartition(force_type);
void AddPartition(std::pair<force_type,std::string> newpart);

bool IsInCrossPartition(std::map<force_type,std::string> xpart) const;

};

#endif /* TIPDATA_H */
