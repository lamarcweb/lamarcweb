//$Id: region.h,v 1.45 2007/05/02 20:51:16 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// Region--a storage class, containing data information that applies
//    to the genetic info of that region (regional quick theta estimate,
//    number of tips, region name).
//
//    In addition, Region serves as the bridge between the data and the
//    tree via Region::CreateTree().  CreateTree() copies the prototype
//    tree and finishes tree construction (creates the tips and individuals,
//    sets the site ranges) and enables data likelihood calculation (creates
//    the data likelihood calculator).  It returns an owning pointer to
//    the newly created tree.
//
// Written by Jim Sloan, heavily revised by Jon Yamato
// 2002/01/03 changed Tipdata::data to a vector for generality--Mary Kuhner
// 2002/07/25 split out Locus class -- Mary Kuhner

#ifndef REGION_H
#define REGION_H

#include <vector>
#include "vectorx.h"
#include <string>
#include "constants.h"
#include "types.h"
#include "individual.h" // for IndVec typedef
#include "locus.h"      // for TipData and for Locus member
#include "newick.h"     // for UserTree member, m_usertree;
#include "forceparam.h" // for return type of GetScalars()

#include <assert.h>

class Tree;
class MapCollector;
class Region
{
private:

Region(const Region& src);             // not defined
Region& operator=(const Region& src);  // not defined

IndVec          m_individuals;
vector<Locus>   m_loci;
vector<Locus>   m_movingloci;    //either 'floating' or 'jumping'.
string          m_regionname;
long            m_id;            // region number
UserTree*       m_usertree;      // we own this!
double          m_effpopsize;
std::set<long>  m_ploidies;    //Phase 1 only.
// utility functions
bool         MultiSampleIndividuals() const;
Individual&  GetIndividual(long n);
bool         ValidLocus(long locus) const;
bool         ValidMovingLocus(long locus) const;
StringVec1d  MakeTraitsXML(unsigned long nspaces) const;
StringVec1d  MakePopXML(unsigned long nspaces) const;

public:

bool         RecombinationCanBeEstimated() const;
Region(std::string rname) : m_regionname(rname), m_usertree(new NullUserTree()),
                            m_effpopsize(1.0) {};
~Region()    { delete m_usertree; };

// Add a new Locus
  void AddLocus(bool movable=false, string name="");

//Save ploidy (used for trait stuff)
void AddPloidy(long ploid) {m_ploidies.insert(ploid);};

// Access
void AddIndividual(const Individual& newind) {m_individuals.push_back(newind);};
void SetID(long newid)                       {m_id = newid; };
void SetUserTree(UserTree* utree)            {delete m_usertree; m_usertree = utree;};

//Phase 1 to Phase 2 functions:
void SetEffectivePopSize(double newsize)     {m_effpopsize = newsize; };
void InitializeRegionalMappositionsUsingGlobalMappositions();
void SetupAndMoveAllLoci();
void MakeAllMovableLociMove();

//Phase 2 to Phase 1 function:
void RevertMovingLoci();

// Forwarders to Locus class; used by xml.cpp
void SetNmarkers(long locus, long n);
void SetGlobalMapposition(long locus, long n); 
void SetOffset(long locus, long n);
void SetPositions(long locus, const LongVec1d& pos);
void SetPositions(long locus); // set to defaults
void SetNsites(long locus, long numsites); 
void SetDataType(long locus, const DataType_ptr dtype);
void SetTipData(long locus, const TipData& td);

//Forwarder to individuals; used by parsetreetodata.cpp
void SetPhaseMarkers(long indnum, LongVec2d& phases);

// Potentially expensive Forces::QuickCalc() helper functions
LongVec1d    CalcNVariableMarkers() const;  // dim: by xpart

//Getter functions
long         GetID()               const {return m_id;};
double       GetEffectivePopSize() const {return m_effpopsize;};
long         GetNIndividuals()     const {return m_individuals.size();};
const Individual& GetIndividual(long n) const {return m_individuals[n];};
string       GetRegionName()       const {return m_regionname;};
Locus&       GetLocus(long locus)        {assert(ValidLocus(locus)); 
	                                  return m_loci[locus]; };
const Locus& GetLocus(long locus)  const {assert(ValidLocus(locus)); 
	                                  return m_loci[locus]; };
const Locus& GetMovingLocus(long mloc) const {assert(ValidMovingLocus(mloc));
                                              return m_movingloci[mloc];}
const IndVec& GetIndividuals() const {return m_individuals;};
bool         HasLocus(string lname)const;
const Locus& GetLocus(string lname)const;
long         GetLocusIndex(string lname) const;
long         GetNloci()            const {return m_loci.size(); };
long         GetNumAllLoci()const;
long         GetNumFixedLoci()const;
long         GetNumMovingLoci()    const {return m_movingloci.size();};
long         GetNumSites() const;
rangepair    GetSiteSpan() const;
void         MakeUserTree(Tree* treetips);
bool         HasUserTree()         const {return m_usertree->Exists();};
StringVec1d  ToXML(unsigned long nspaces) const;
DoubleVec1d  GetMuRatios()         const;
std::set<long> GetPloidies() const {return m_ploidies;};

// Forwarders to Locus class
long         GetNmarkers(long locus)    const {return m_loci[locus].GetNmarkers();};
long         GetMapposition(long locus) const {return m_loci[locus].GetRegionalMapposition();};
long         GetGlobalMapposition(long locus) const {return m_loci[locus].GetGlobalMapposition();};
long         GetOffset(long locus)      const {return m_loci[locus].GetOffset();};
LongVec1d    GetUserMarkerLocations(long locus)   const {return m_loci[locus].GetUserMarkerLocations();};
long         GetLocusNsites(long locus)      const;
StringVec1d  GetAllLociNames()   const;
StringVec1d  GetAllLociDataTypes() const;
StringVec1d  GetAllLociMuRates() const;
DataModel_ptr GetLocusDataModel(long locus)  const {return m_loci[locus].GetDataModel(); };
long         GetNTips()                 const {return m_loci[0].GetNTips();};
long         GetNXTips(long xpart)      const;               
vector<TipData> GetAllTipData(long locus)   const {return m_loci[locus].GetTipData();};
DoubleVec1d  CountNBases() const;

// Factory function
Tree*        CreateTree();

// Genotypic-data support functions
bool         CanHaplotype() const;
void         PruneSamePhaseUnknownSites(IndVec& indivs) const;
bool         AnyPhaseUnknownSites() const;

bool         AnyMapping() const;
bool         AnyJumpingAnalyses() const;
bool         AnySimulatedLoci() const;

bool         AnySNPDataWithDefaultLocations() const;

// Helper function for original use in DataPack::RemoveUneededPartitions
void         RemovePartitionFromLoci(force_type);
void         CopyTipDataForLocus(const string& lname);

// Helper function for ReportPage(DataPage::Show, echoing data)
StringVec2d  GetMarkerDataWithLabels() const;  // dim: locus X tip

// Validity checking
bool         IsValid(string & errorString) const;
   // helper for parsetreetodata
bool         IsDuplicateTipName(const string& newname) const;

  //We save the results of mapping in the appropriate loci.
  void SaveMappingInfo(MapCollector* mapcoll);
  void SaveMappingInfo(std::vector<MapCollector*> mapcolls,
                       DoubleVec1d logweights);
  void ReportMappingInfo();
  StringVec2d CreateAllDataModelReports() const;

  // These are power-user functions, generally used by our lab in writing
  // simulations; they are not called in normal execution.  They are only
  // used when JSIM is defined:

  // Write a Fluctuate format file.
  void         WriteFlucFile(const string& outfilename, bool onlyregion) const;
  // Break up a multi-population data set into single-population ones
  StringVec2d  MakeByPopXML(unsigned long nspaces) const;
  void         WritePopulationXMLFiles() const;
  void         WriteToXMLFileUsing(std::ofstream& ofile, StringVec1d& region_contents) const;
  void         WriteToXMLFileUsing(std::ofstream& ofile, StringVec2d& region_contents, bool produceonepop) const;
  // helpers for XML infile creation
 private:
  std::vector<PopulationXML> MakeVectorOfPopulationXML() const;

};

#endif /* REGION_H */
