// $Id: tipdata.cpp,v 1.4 2006/04/01 00:28:41 lpsmith Exp $

/* 
 Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "tipdata.h"
#include "constants.h"
#include "registry.h"
#include <assert.h>
#include "dlcalc.h"
#include "dlmodel.h"
#include "mathx.h"    // for IsEven

#include "force.h"        // for TipData::GetBranchPartitions()
#include "xml_strings.h"  // for TipData::ToXML()

#include <functional>     // for Locus::CountNNucleotides()


using namespace std;

//___________________________________________________________________________
//___________________________________________________________________________

TipData::TipData()
  : partitions(),
    individual(FLAGLONG),
    m_locus(FLAGLONG),
    m_hap(FLAGLONG),
    m_nodata(false),
    label(""),
    m_popname(""),
    data()
{
// deliberately blank
} /* TipData::TipData */

//___________________________________________________________________________

void TipData::Clear()
{
partitions.erase(partitions.begin(),partitions.end());
individual = FLAGLONG;
m_locus = FLAGLONG;
m_hap = FLAGLONG;
data.clear();

} /* Clear */

//___________________________________________________________________________

bool TipData::BelongsTo(long ind) const
{
return (individual == ind);
} /* BelongsTo */

//___________________________________________________________________________

bool TipData::IsInPopulation(const string& popname) const
{
return (m_popname == popname);
} /* IsInPopulation */

//___________________________________________________________________________

string TipData::GetFormattedData(const string& dlm) const
{
  string result;

  unsigned long i;
  for (i = 0; i < data.size(); ++i) {
    result += data[i] + dlm;
  }

  return result;

} /* GetFormattedData */

//___________________________________________________________________________

long TipData::GetPartition(force_type partname) const
{
string partitionname = partitions.find(partname)->second;
return registry.GetDataPack().GetPartitionNumber(partname,partitionname);
} /* TipData::GetPartition */

//___________________________________________________________________________

LongVec1d TipData::GetBranchPartitions() const
{
LongVec1d parts(partitions.size(),FLAGLONG);
const ForceSummary& forcesum = registry.GetForceSummary();
const DataPack& datapack = registry.GetDataPack();
std::map<force_type,string>::const_iterator pits;
for(pits = partitions.begin(); pits != partitions.end(); ++pits) {
   force_type forcename = pits->first;
   string partname = pits->second;

   PartitionForce* pforce = dynamic_cast<PartitionForce*>
                               (*forcesum.GetForceByTag(forcename));

   parts[pforce->GetPartIndex()] =
                       datapack.GetPartitionNumber(forcename,partname);
}

return parts;

} /* TipData::GetBranchPartitions */

//___________________________________________________________________________

void TipData::RemovePartition(force_type forcename)
{
if (partitions.erase(forcename) == 0)
   assert(false); /* failed to erase something that wasn't there! */

} /* TipData::RemovePartition */

//___________________________________________________________________________

void TipData::AddPartition(pair<force_type,string> newpart)
{
partitions.insert(newpart);
} /* TipData::AddPartition */

//___________________________________________________________________________

bool TipData::IsInCrossPartition(std::map<force_type,string> xpart) const
{
return (xpart == partitions);
} /* TipData::IsInCrossPartition */

//___________________________________________________________________________
