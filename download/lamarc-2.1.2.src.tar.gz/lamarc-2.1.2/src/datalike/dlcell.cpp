//$Id: dlcell.cpp,v 1.28 2007/01/15 19:15:58 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// This file contains the implementation code for the data-likelihood
// storage object.

#include <math.h>
#include "dlcell.h"
#include "dlmodel.h"
#include "errhandling.h"
#include "definitions.h"
#include "registry.h"
#include "cellmanager.h"

#include "stringx.h" // for ToString() use in debug function DLsToString()
//debug
#include <iostream>

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

using namespace std;


//___________________________________________________________________
//-------------------------------------------------------------------
// DLCell
//___________________________________________________________________

DLCell::DLCell(long markers, long cats, long bins)
  : Cell(),
    nmarkers(markers),
    ncats(cats),
    nbins(bins),
    norms(markers, 0.0)
{
  // obtain an internal array from the free store
  identifier.first = nmarkers;
  identifier.second = ncats;
  identifier.third = nbins;

  DLs = registry.GetCellManager().GetArray(identifier, *this);
} /* DLCell constructor */

//__________________________________________________________________

DLCell::~DLCell()
{
  // return the internal array to the free store
  registry.GetCellManager().FreeArray(identifier, DLs);
  DLs = NULL;
} /* DLCell destructor */

//__________________________________________________________________

Cell* DLCell::Copy() const
{
  Cell* pCell = Clone();
  pCell->CopyInitialize(*this);
  return pCell; 

} /* Copy */

//__________________________________________________________________

void DLCell::CopyInitialize(const Cell& src)
{
  const DLCell& srcell = dynamic_cast<const DLCell&>(src);
  norms = srcell.norms;
  // nmarkers+1 because there is an extra cell at the end, to
  // allow an STL-like interface where one past the end is a valid
  // address

  long arraySize = (nmarkers+1) * ncats * nbins;
  //  cout << "arraysize=" << arraySize << endl;
  // memcpy for speed--be careful!
  memcpy(DLs[0][0], srcell.DLs[0][0], arraySize*sizeof(double));

} /* CopyInitialize */

//__________________________________________________________________

bool DLCell::IsValidPos(long pos) const
{
  // for some purposes, pos == nmarkers is in fact valid; this
  // allows "one past the end" logic emulating the STL

  if (0 <= pos && pos <= nmarkers) return true;
  return false;
} /* IsValidPos */

//___________________________________________________________________
// Make a datalikelihood array appropriately sized for this Cell

cellarray DLCell::MakeArray() 
{
  long len = nmarkers + 1; 
         // provide a STL like interface into the DLs array.
         // (i.e. provides a legal reference one past the normal end
         // of the array)

  // set up a 3-dimensional array in which all positions are
  // contiguous, so that memcpy can be used on it (a speed
  // optimization).

  long site, category;
  cellarray dl;

  dl = new double**[len];

  dl[0] = new double*[len * ncats];
  for (site = 0; site < len; ++site) {
    dl[site] = dl[0] + site*ncats;
  }

  dl[0][0] = new double[len * ncats * nbins];
  for (site = 0; site < len; ++site) {
    for (category = 0; category < ncats; ++category) {
      dl[site][category] = dl[0][0] + site*ncats*nbins
        + category*nbins;
    }
  }

  return dl;

} /* MakeArray */

//___________________________________________________________________

void DLCell::SwapDLs(Cell_ptr othercell, long pos)
{

// This creates a 2D array (categories x bins) and uses it to
// swap the information for a single marker between two DLCells.
// All bets are off if they are not the same type!

// WARNING -- Not exception safe due to raw new.

// take pointers to the two things to be swapped
  double** otherDLs = othercell->GetSiteDLs(pos);
  double** myDLs = GetSiteDLs(pos);

// create temporary storage for the swap
  double** newDLs = new double* [ncats];
  newDLs[0] = new double [ncats*nbins];
  long cat;
  for(cat = 1; cat < ncats; ++cat)
     newDLs[cat] = newDLs[0] + cat*nbins;

// memcpy for speed
  memcpy(newDLs[0], myDLs[0], ncats * nbins * sizeof(double));

// swap
  SetSiteDLs(pos, otherDLs);
  othercell->SetSiteDLs(pos, newDLs);

// release temporary storage
  delete [] newDLs[0];
  delete [] newDLs;

} /* SwapDLs */

//___________________________________________________________________

void DLCell::SumMarkers(long startpos, long endpos, bool normalize)
{ 

  long cat, bin, pos;

  if (normalize) {

    for (cat = 0; cat < ncats; ++cat) {
      for (bin = 0; bin < nbins; ++bin) {
        double result = 0.0;
        for (pos = startpos; pos != endpos; ++pos) {
          double markerval = log(DLs[pos][cat][bin]) + GetNorms(pos);
          if (markerval > EXPMIN) result += exp(markerval);
        }
        if (result == 0.0)   // never found a good value?
          DLs[endpos][cat][bin] = exp(EXPMIN);
        else 
          DLs[endpos][cat][bin] = result;
      }
    }

    // renormalize and re-set norms
    double newnorm = Normalize(DLs[endpos]);
    SetNorms(newnorm, endpos);
   
  } else { // no normalization

    for (cat = 0; cat < ncats; ++cat) {
      for (bin = 0; bin < nbins; ++bin) {
        double result = 0.0;
        for (pos = startpos; pos != endpos; ++pos) {
          result += DLs[pos][cat][bin];
        }
        DLs[endpos][cat][bin] = result;
      }
    }
  }

} /* SumMarkers */

//___________________________________________________________________

bool DLCell::IsSameAs(const Cell_ptr othercell, long pos) const
{

double** otherDLs = othercell->GetSiteDLs(pos);
double** myDLs = GetSiteDLs(pos);
long cat, bin;
for(cat = 0; cat < ncats; ++cat)
   for (bin = 0; bin < nbins; ++bin)
      if (myDLs[cat][bin] != otherDLs[cat][bin]) return false;

return true;
      
} /* DLCell::IsSameAs */

//___________________________________________________________________

long DLCell::DiffersFrom(Cell_ptr othercell) const
{
long marker;
for(marker = 0; marker < nmarkers; ++marker)
   if (!IsSameAs(othercell,marker)) return marker;

return FLAGLONG;

} /* DLCell::DiffersFrom */

void DLCell::SetAllCategoriesTo(DoubleVec1d& state, long posn)
{
  for (long cat=0; cat<ncats; cat++) {
    for (unsigned long nstate=0; nstate < state.size(); nstate++) {
      DLs[posn][cat][nstate] = state[nstate];
    }
  }
}

DoubleVec1d DLCell::GetStateFor(long posn, long cat) const
{
  DoubleVec1d state;
  for (long nstate=0; nstate < nbins; nstate++) {
    state.push_back(DLs[posn][cat][nstate]);
  }
  return state;
}

void DLCell::AddTo(const Cell_ptr othercell)
{
  for (long pos=0; pos<nmarkers; pos++) {
    double** otherDLs = othercell->GetSiteDLs(pos);
    double** myDLs = GetSiteDLs(pos);
    long cat, bin;
    for(cat = 0; cat < ncats; ++cat) {
      for (bin = 0; bin < nbins; ++bin) {
        myDLs[cat][bin] += otherDLs[cat][bin];
      }
    }
  }
}

void DLCell::MultiplyBy(double mult)
{
  for (long pos=0; pos<nmarkers; pos++) {
    double** myDLs = GetSiteDLs(pos);
    long cat, bin;
    for(cat = 0; cat < ncats; ++cat) {
      for (bin = 0; bin < nbins; ++bin) {
        myDLs[cat][bin] *= mult;
      }
    }
  }
}


//___________________________________________________________________

LongVec1d DLCell::GetOnes(long marker) const
{
  LongVec1d ones;
  double** dls = GetSiteDLs(marker);
  //Just mess with the first category
  for (long bin = 0; bin<nbins; ++bin) {
    if (dls[0][bin] == 1.0) {
      ones.push_back(bin);
    }
  }
  return ones;
}
//___________________________________________________________________

string DLCell::DLsToString(long start, long end) const
{
string lines;

long line;
for(line = start; line <= end; ++line) {
   lines += "marker " + ToString(line) + ": ";
   double** dls = GetSiteDLs(line);
   long cat;
   for(cat = 0; cat < ncats; ++cat) {
      lines += "{";
      long bin;
      for(bin = 0; bin < nbins; ++bin) {
         lines += ToString(dls[cat][bin]);
         if (bin != nbins-1) lines += ",";
      }
      lines += "}";
      if (cat != ncats-1) lines += ", ";
   }
   lines += "\n";
}

return lines;

} /* DLCell::DLsToString */

//___________________________________________________________________

double DLCell::Normalize(double** siteDLs)
{

  double biggest = NEG_MAX;
  long cat, bin;
  for(cat = 0; cat < ncats; ++cat) {
     for(bin = 0; bin < nbins; ++bin) {
        if (siteDLs[cat][bin] > biggest) biggest = siteDLs[cat][bin];
     }
  }

  for(cat = 0; cat < ncats; ++cat) {
     for(bin = 0; bin < nbins; ++bin) {
        siteDLs[cat][bin] /= biggest;
     }
  }

  return log(biggest);

} /* Normalize */

//___________________________________________________________________


void DLCell::SetSiteDLs(long posn, double **siteDLs)
{
   assert(IsValidPos(posn));
   long siteSize = ncats * nbins;
   memcpy(DLs[posn][0], siteDLs[0], siteSize * sizeof(double));
}

//-------------------------------------------------------------------
// NullCell
//___________________________________________________________________

NullCell::NullCell()
: Cell()
{
// no code here
} /* NullCell constructor */

//___________________________________________________________________

void NullCell::Initialize (const StringVec1d&, const DataModel_ptr)
{

  assert (false); // should never call this!

} /* Initialize */

DoubleVec1d NullCell::GetStateFor(long posn, long cat) const
{
  throw implementation_error("No state for this data likelihood.");
}

//-------------------------------------------------------------------
// NucCell
//___________________________________________________________________

NucCell::NucCell(long markers, long cats)
 : DLCell(markers, cats, BASES)
{
// deliberately left blank
} /* NucCell constructor */

//___________________________________________________________________

void NucCell::Initialize(const StringVec1d &sequence, const DataModel_ptr trans)
{
  long posn, base, cat;

  string postring;
  vector<double> likes;

// could be OPTIMIZED

  for (posn = 0; posn < nmarkers; ++posn) {
    postring = sequence[posn];
    likes = trans->DataToLikes(postring);
    for (cat = 0; cat < ncats; ++cat) {
      for (base = 0; base < nbins; ++base) {
        DLs[posn][cat][base] = likes[base];
      }
    }
  }
 
} /* Initialize */


//-------------------------------------------------------------------
// DNACell
//___________________________________________________________________

DNACell::DNACell(long markers, long cats)
  : NucCell(markers, cats)
{
  // intentionally blank
} /* DNACell constructor */

//___________________________________________________________________

Cell *DNACell::Clone() const
{
  Cell *pDLCell = new DNACell(nmarkers, ncats);
  return pDLCell;
}

//-------------------------------------------------------------------
// SNPCell
//___________________________________________________________________

SNPCell::SNPCell(long markers, long cats)
  : NucCell(markers, cats)
{
// deliberately blank
} /* SNPCell constructor */

//___________________________________________________________________

SNPCell::~SNPCell()
{
// deliberately blank
}

//___________________________________________________________________

Cell *SNPCell::Clone() const
{
  Cell *pDLCell  = new SNPCell(nmarkers, ncats);

  return pDLCell;
}

//___________________________________________________________________

void SNPCell::Initialize(const StringVec1d&, const DataModel_ptr trans)
{
// yes, we do not use our sequence or translator.  They are passed only for
// conformity with the base class interface.

  long categ, invar, base;

  // in the DLs array, set all entries to 0.0 except for the
  // entries where the invariant equals the base, where they are
  // set to 1.0.

  for (invar = 0; invar < INVARIANTS; ++invar) {
    for (categ = 0; categ < ncats; ++categ) {
      for (base = 0; base < nbins; ++base) {
        if (invar == base) DLs[invar][categ][base] = 1.0;
        else DLs[invar][categ][base] = 0.0;
      }
    }
  }
}

//___________________________________________________________________

//-------------------------------------------------------------------
// AlleleCell
//___________________________________________________________________

AlleleCell::AlleleCell(long markers, long cats, long bins)
  : DLCell(markers, cats, bins)
{
  // deliberately blank
} /* AlleleCell constructor */

//___________________________________________________________________

Cell *AlleleCell::Clone() const
{
  Cell *pDLCell  = new AlleleCell(nmarkers, ncats, nbins);

  return pDLCell;
} /* Clone */

//___________________________________________________________________

void AlleleCell::Initialize(const StringVec1d &sequence, const DataModel_ptr trans)
{
  long posn, bin, cat;
  vector<double> likes;

// could be OPTIMIZED

  for (posn = 0; posn < nmarkers; ++posn) {
    likes = trans->DataToLikes(sequence[posn], posn);
    for (cat = 0; cat < ncats; ++cat) {
      for (bin = 0; bin < nbins; ++bin) {
        DLs[posn][cat][bin] = likes[bin];
      }
    }
  }
} /* Initialize */

//___________________________________________________________________
//___________________________________________________________________

triplet::triplet()
 : first(0),
   second(0),
   third(0)
{
  // intentionally blank
} /* triplet default constructor */

//___________________________________________________________________

triplet::triplet(long f, long s, long t)
 : first(f),
   second(s),
   third(t)
{
 // intentionally blank
} /* triplet constructor */

//___________________________________________________________________

bool triplet::operator<(const triplet& rhs) const
{
  if (first != rhs.first) return (first < rhs.first);
  if (second != rhs.second) return (second < rhs.second);
  return (third < rhs.third);
} /* triplet operator< */
