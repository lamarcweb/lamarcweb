//$Id: calculators.h,v 1.11 2006/09/13 23:29:54 ewalkup Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#ifndef CALCULATORS_H
#define CALCULATORS_H

#include <map>
#include <string>
#include <vector>
#include <deque>
#include "defaults.h"
#include "vectorx.h"

class DataModel;
class DataPack;
class Region;
class Locus;

using std::map;
using std::string;
using std::vector;

DoubleVec1d FrequenciesFromData(const Locus& locus, model_type);
DoubleVec1d FrequenciesFromData(long regionId, long locusId, model_type);
void MigFSTLocus(const DataPack& dpack,const Locus& loc, long nmigs,
  DoubleVec1d& estimate, std::deque<bool>& isCalculated); 
// EWFIX.P5 DIMENSIONS -- change to 2d  EWFIX.P5 LOCUS
void MigFSTMultiregion(const DataPack& dpack, const DoubleVec2d& 
  regionalmuratios, DoubleVec1d& perRegionMigsAccumulator, std::deque<bool>&); // EWFIX.P5 DIMENSIONS
void ThetaFSTMultiregion(const DataPack& dpack, const DoubleVec1d& 
  regionalthetascalars, const DoubleVec2d& regionalmuratios, DoubleVec1d& 
  estimates, std::deque<bool>&);
void ThetaFSTLocus(const DataPack& dpack, const Locus& locus, DoubleVec1d& 
  estimates, std::deque<bool>&);
void ThetaWattersonMultiregion(const DataPack& dpack, const DoubleVec1d& 
  regionalthetascalars, const DoubleVec2d& regionalmuratios, 
  DoubleVec1d& estimates, std::deque<bool>&);
void ThetaWattersonLocus(const DataPack&,const Locus&,long numThetas,
                             vector<map<force_type,string> > tipids,
                             DoubleVec1d&,
                             std::deque<bool>&);
void ThetaWattersonRegion(const DataPack&, const Region&, double thetascalar,
  const DoubleVec1d& muratios, DoubleVec1d& estimates, std::deque<bool>&);

#endif /* CALCULATORS_H */
