//$Id: cellmanager.cpp,v 1.1 2007/01/15 19:15:58 mkkuhner Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

// This file contains the implementation code for the manager of data-likelihood
// storage, CellManager

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

#include "cellmanager.h"

//___________________________________________________________________

cellarray CellManager::GetArray(triplet id, DLCell& requester)
{
  FreeStore::iterator it = store.find(id);

  if (it != store.end()) {   // found one
    cellarray result = it->second;
    store.erase(it);
    return result;
  }
  else 
    return requester.MakeArray();

} /* GetArray */

//___________________________________________________________________

void CellManager::FreeArray(triplet id, cellarray array)
{
  store.insert(std::make_pair(id, array));

} /* FreeArray */

//___________________________________________________________________

void CellManager::ClearStore()
{
  // assumes all cells are 3-D contiguous storage gotten with new[]!
  cellarray ar;
  FreeStore::iterator it = store.begin();
  for ( ; it != store.end(); ++it) {
    ar = it->second;
    delete [] ar[0][0];
    delete [] ar[0];
    delete [] ar;
  }
  store.erase(store.begin(), store.end());
} /* ClearStore */

//___________________________________________________________________

