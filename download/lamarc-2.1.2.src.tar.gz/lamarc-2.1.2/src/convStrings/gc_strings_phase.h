#ifndef GC_STRINGS_PHASE_H
#define GC_STRINGS_PHASE_H

#include "wx/string.h"

class gcerr_phase
{
    public:
        static const wxString adjacentPhaseForMultiSample;
        static const wxString badIndMatchAdjacencyValue;
        static const wxString badIndMatchType;
        static const wxString badTopTag;
        static const wxString bothIndividualAndSample;
        static const wxString individualPhenotypeNameRepeat;
        static const wxString markerNotLegal;
        static const wxString matchingConfusion;
        static const wxString mergeMismatch;
        static const wxString noIndividualForSample;
        static const wxString noSampleForIndividual;
        static const wxString notLocation;
        static const wxString tooLarge;
        static const wxString tooSmall;
        static const wxString unevenAdjDivisor;
};

class gcstr_phase
{
    public:
        static const wxString adjacentHaps1;
        static const wxString adjacentHaps2;
        static const wxString known;
        static const wxString unknown;
};

#endif
// GC_STRINGS_PHASE_H
