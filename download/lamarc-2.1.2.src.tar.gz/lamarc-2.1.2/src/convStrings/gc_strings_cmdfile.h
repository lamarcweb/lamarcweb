#ifndef GC_STRINGS_CMDFILE_H
#define GC_STRINGS_CMDFILE_H

#include "wx/string.h"

class gcerr_cmdfile
{
    public:
        static const wxString atRow;

        static const wxString badCmdFile;
        static const wxString badFileFormat;
        static const wxString badGeneralDataType;
        static const wxString badInterleaving;
        static const wxString badProximity;
        static const wxString badSpecificDataType;
        static const wxString badYesNo;

        static const wxString deprecatedGeneralDataType;

        static const wxString inCmdFile;
        static const wxString inFile;

        static const wxString locusMatchByNameNotEmpty;
        static const wxString locusMatchSingleEmpty;
        static const wxString locusMatchUnknown;

        static const wxString messageIs;

        static const wxString popMatchByNameNotEmpty;
        static const wxString popMatchSingleEmpty;
        static const wxString popMatchUnknown;
};

class gcstr_cmdfile
{
    public:
        static const wxString cmdFilesSelect;
};

#endif
//GC_STRINGS_CMDFILE_H
