#include "gc_strings_parse.h"
#include "wx/intl.h"

const wxString gcerr_parse::extraFileData   = wxTRANSLATE("File contains extra data");
const wxString gcerr_parse::ignoringPhylipWeights   = wxTRANSLATE("Ignoring weights information in file %s.");




const wxString gcstr_parse::parsingStarting = wxTRANSLATE("Starting parsing of %s. This can take a while.");
const wxString gcstr_parse::parsingDone     = wxTRANSLATE("Done parsing %s.");
