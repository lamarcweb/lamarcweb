#include "gc_strings_trait.h"
#include "wx/intl.h"

const wxString gcerr_trait::alleleMissing   =   wxTRANSLATE("cannot find trait allele with name %s.");
const wxString gcerr_trait::alleleNameReuse =   wxTRANSLATE("re-use of allele name %s not allowed");
const wxString gcerr_trait::alleleNameSpaces=   wxTRANSLATE("Allele name \"%s\" not allowed because it contains one or more spaces");
const wxString gcerr_trait::alleleTraitMismatch= wxTRANSLATE("Allele %s in phenotype %s does not belong to trait %s.");
const wxString gcerr_trait::hapProbabilityNegative = wxTRANSLATE("Relative penetrance of %f illegal -- must be a non-negative number");
const wxString gcerr_trait::phenoTraitMismatch= wxTRANSLATE("Phenotype %s trait %s differs from enclosing trait %s.");
const wxString gcerr_trait::phenotypeMissing   =   wxTRANSLATE("cannot find phenotype with name %s.");
const wxString gcerr_trait::phenotypeNameReuse =   wxTRANSLATE("re-use of phenotype name %s for trait %s not allowed");



const wxString gcstr_trait::alleleListMember=              ("%s ");
const wxString gcstr_trait::generatedName   =              ("trait_%ld");
const wxString gcstr_trait::internalName    =              ("internalTrait_%ld");
