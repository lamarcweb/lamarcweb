
#ifndef GC_STRINGS_STRUCTURES_H
#define GC_STRINGS_STRUCTURES_H

#include "wx/string.h"

class gcstr_structures
{
    public:
        static const wxString objDict;
        static const wxString traitDict;
};

class gcerr_structures
{
    public:

        static const wxString duplicateFileBaseName;
        static const wxString duplicateFileName;
        static const wxString duplicateName;
        /*
        static const wxString locusMergeFailure;
        static const wxString locusHapMismatch;
        static const wxString locusLengthMismatch;
        static const wxString locusTypeMismatch;
        static const wxString missingLocus;
        */
        static const wxString mismatchAlleleTrait;
        static const wxString mismatchLocusRegion;

        static const wxString missingFile;
        static const wxString missingName;
        static const wxString missingPopulation;
        static const wxString missingRegion;
        static const wxString missingTrait;
        static const wxString nameRepeatAllele;
        static const wxString nameRepeatLocus;
        static const wxString nameRepeatPop;
        static const wxString nameRepeatRegion;
        static const wxString nameRepeatTrait;
        static const wxString regionEffPopSizeClash;
        // static const wxString regionSamplesPerClash;
        static const wxString unparsableFile;
};


#endif
//GC_STRINGS_STRUCTURES_H
