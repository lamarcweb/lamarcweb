#include "gc_strings_region.h"
#include "wx/intl.h"

const wxString gcstr_region::effPopSize     =wxTRANSLATE("Relative effective population size: %.2f");
const wxString gcstr_region::internalName   =           "internalGroup_%ld";
const wxString gcstr_region::locusMapPosition       =   "(%d : %s)";
const wxString gcstr_region::mapPosition            =   "@ %ld";
const wxString gcstr_region::numLoci        =wxTRANSLATE("Number of segments: %d");
// const wxString gcstr_region::samplesPer     =wxTRANSLATE("Samples per individual: %d");
const wxString gcstr_region::tabTitle       =wxTRANSLATE("Properties of %d Regions");
const wxString gcstr_region::traitIndexListMember   =   "%d ";
