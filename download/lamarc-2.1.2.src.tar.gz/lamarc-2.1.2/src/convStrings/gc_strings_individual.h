#ifndef GC_STRINGS_INDIVIDUAL_H
#define GC_STRINGS_INDIVIDUAL_H

#include "wx/string.h"

class gcerr_ind
{
    public:
        static const wxString missingPhaseForLocus;
        static const wxString phaseLocusRepeat;
        static const wxString sampleLocusRepeat;
        static const wxString sampleMissingLocusData;
        static const wxString wrongSampleCount;

};

/*
class gcstr_individual
{
    public:
};
*/

#endif
// GC_STRINGS_INDIVIDUAL_H
