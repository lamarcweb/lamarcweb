#ifndef GC_STRINGS_TRAIT_H
#define GC_STRINGS_TRAIT_H

#include "wx/string.h"

class gcerr_trait
{
    public:
        static const wxString alleleMissing;
        static const wxString alleleNameReuse;
        static const wxString alleleNameSpaces;
        static const wxString alleleTraitMismatch;
        static const wxString hapProbabilityNegative;
        static const wxString phenoTraitMismatch;
        static const wxString phenotypeMissing;
        static const wxString phenotypeNameReuse;

};

class gcstr_trait
{
    public:
        static const wxString alleleListMember;
        static const wxString generatedName;
        static const wxString internalName;
};

#endif
// GC_STRINGS_TRAIT_H
