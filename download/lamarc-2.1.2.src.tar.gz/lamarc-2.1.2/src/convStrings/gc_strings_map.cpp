#include "gc_strings_map.h"
#include "wx/intl.h"

const wxString gcstr_map::notXmlMapFileTryOldFmt    =wxTRANSLATE("%s. Trying to read %s as old map file format.");



const wxString gcerr_map::ERR_BAD_TOP_TAG   =wxTRANSLATE("expected top xml tag of <%s> but got <%s> instead.");
const wxString gcerr_map::fileEmpty         =wxTRANSLATE("File %s empty");
const wxString gcerr_map::fileMissing       =wxTRANSLATE("File %s missing");
const wxString gcerr_map::fileReadErr       =wxTRANSLATE("Unknown error while reading file %s");

