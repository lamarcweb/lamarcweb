#ifndef GC_STRINGS_DATA_H
#define GC_STRINGS_DATA_H

#include "wx/string.h"

class gcerr_data
{
    public:
        static const wxString missingPopLocus;
        static const wxString missingPopRegion;

};

class gcstr_data
{
    public:
};

#endif
// GC_STRINGS_DATA_H
