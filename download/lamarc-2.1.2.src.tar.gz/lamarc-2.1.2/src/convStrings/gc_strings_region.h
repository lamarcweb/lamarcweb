#ifndef GC_STRINGS_REGION_H
#define GC_STRINGS_REGION_H

#include "wx/string.h"

class gcerr_region
{
    public:

};

class gcstr_region
{
    public:
        static const wxString effPopSize;
        static const wxString internalName;
        static const wxString locusMapPosition;
        static const wxString mapPosition;
        static const wxString numLoci;
        // static const wxString samplesPer;
        static const wxString tabTitle;
        static const wxString traitIndexListMember;
};

#endif
// GC_STRINGS_REGION_H
