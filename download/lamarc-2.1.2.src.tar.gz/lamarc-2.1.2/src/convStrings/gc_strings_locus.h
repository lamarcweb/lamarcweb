#ifndef GC_STRINGS_LOCUS_H
#define GC_STRINGS_LOCUS_H

#include "wx/string.h"

class gcerr_locus
{
    public:
        static const wxString dnaBigLengthNeedsLocations;
        static const wxString lengthMismatch;
        static const wxString lengthMissing;
        static const wxString locationsOutOfOrder;
        static const wxString locationTooLarge;
        static const wxString locationTooSmall;
        static const wxString mapPositionMismatch;
        static const wxString mergeFailure;
        static const wxString missing;
        static const wxString numMarkersZero;
        static const wxString offsetMismatch;
        static const wxString offsetMissingMultiSegment;
        static const wxString offsetMissingSnpLocations;
        static const wxString overlap;
        static const wxString setLocs;
        static const wxString siteCountMismatch;
        static const wxString typeMismatch;
        static const wxString unlinkedNuc;
        static const wxString unsetLinkedUserValue;
        static const wxString unsetNumMarkers;
        static const wxString unsetOffset;
        static const wxString userDataTypeMismatch;
        static const wxString wrongLocationCount;
};

#endif
//GC_STRINGS_LOCUS_H
