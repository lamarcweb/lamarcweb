#include "gc_strings_io.h"
#include "wx/intl.h"

const wxString gc_io::eof           =   wxTRANSLATE("possible premature end of file");
const wxString gc_io::fileMissing   =   wxTRANSLATE("File %s missing or unreadable.");
const wxString gc_io::fileReadError =   wxTRANSLATE("Unknown error reading file.");
const wxString gc_io::fileReadErrorWithName =   wxTRANSLATE("Unknown error reading file %s.");
