#ifndef GC_STRINGS_POP_H
#define GC_STRINGS_POP_H

#include "wx/string.h"

class gcstr_pop
{
    public:
        static const wxString internalName;
};


#endif
//GC_STRINGS_POP_H
