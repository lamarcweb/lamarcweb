#ifndef GC_STRINGS_IO_H
#define GC_STRINGS_IO_H

#include "wx/string.h"

class gc_io
{
    public:
        static const wxString eof;
        static const wxString fileMissing;
        static const wxString fileReadError;
        static const wxString fileReadErrorWithName;
};


#endif
// GC_STRINGS_IO_H
