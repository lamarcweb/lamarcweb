#ifndef GC_STRINGS_INFILE_H
#define GC_STRINGS_INFILE_H

#include "wx/string.h"

class gcerr_infile
{
    public:
        static const wxString extraFileData;
        static const wxString fileParseError;
        static const wxString illegalDna;
        static const wxString illegalMsat;
        static const wxString parseDataTypeSpecMismatch;
        static const wxString prematureEndOfFile;
        static const wxString shortSampleName;
        static const wxString tokenCountMismatch;
        static const wxString tooFewMarkersInSample;
        static const wxString tooManyMarkersInSample;
        static const wxString unableToParseBecause;
};

class gcerr_migrate
{
    public:
        static const wxString badDelimiter;
        static const wxString badLocusCount;
        static const wxString badPopCount;
        static const wxString firstToken;
        static const wxString locusLengthNotPositive;
        static const wxString missingMsatDelimiter;
        static const wxString missingSequenceCount;
        static const wxString parseErr;
        static const wxString tooFewSequenceLengths;
};

class gcstr_migrate
{
    public:
        static const char missingData;
};

class gcerr_phylip
{
    public:
        static const wxString badFirstToken;
        static const wxString badSecondToken;
};

#endif
//GC_STRINGS_INFILE_H
