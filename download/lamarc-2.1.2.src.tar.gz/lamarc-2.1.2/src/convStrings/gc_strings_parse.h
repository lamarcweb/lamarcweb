#ifndef GC_STRINGS_PARSE_H
#define GC_STRINGS_PARSE_H

#include "wx/string.h"

class gcerr_parse
{
    public:
        static const wxString extraFileData;
        static const wxString ignoringPhylipWeights;
};

class gcstr_parse
{
    public:
        static const wxString parsingDone;
        static const wxString parsingStarting;
};

#endif
//GC_STRINGS_PARSE_H
