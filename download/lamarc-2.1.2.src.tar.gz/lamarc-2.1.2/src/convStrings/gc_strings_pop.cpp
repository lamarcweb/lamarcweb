#include "gc_strings_pop.h"
#include "wx/intl.h"

const wxString gcstr_pop::internalName = "internalPop_%ld";
