// $Id: outputfile.h,v 1.8 2005/10/13 19:24:46 lpsmith Exp $

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#ifndef OUTPUTFILE_H
#define OUTPUTFILE_H

#include <fstream>
#include <string>
#include "stringx.h"
#include "reportpage.h"
#include "constants.h"

// Class OutputFile is the abstract base class for dealing with file i/o
// at the end of the program.
//
// This class is not default-constructible or copyable.
//
// The class ctor will throw a file_error if ofstream.open() fails
class OutputFile
{

private:
// these are deliberately never implemented
OutputFile();  
OutputFile(const OutputFile &src);
OutputFile &operator=(const OutputFile &src);

protected:
ofstream m_outf;

public:
OutputFile(const string& fname);
virtual ~OutputFile() { m_outf.close(); };

virtual void Display() = 0;

};


// Class ResultsFile manages the collection of report pages that make
// up the final file output for the program.  It is expected to be a
// singleton.
//
// This class is not default-constructible or copyable.
//
// The class ctor does not catch any exceptions thrown by the base class.
class ResultsFile : public OutputFile
{

private:
// these are deliberately never implemented
ResultsFile(const ResultsFile &src);
ResultsFile &operator=(const ResultsFile &src);

std::vector<ReportPage *> m_reports; // this points at local variables of Display()

void AddReport(ReportPage &report);
void ShowReports();

public:
ResultsFile();
virtual ~ResultsFile() {};

virtual void Display();

};


// Class XMLOutfile manages the creation of a correct xml input file from the
// current data structures of the program.
class XMLOutfile : public OutputFile
{

private:
// these are deliberately never implemented
XMLOutfile(const XMLOutfile &src);
XMLOutfile &operator=(const XMLOutfile &src);

public:
XMLOutfile();
XMLOutfile(std::string outfileName);
virtual ~XMLOutfile() {};

virtual void Display();

};

#endif /* OUTPUTFILE_H */
