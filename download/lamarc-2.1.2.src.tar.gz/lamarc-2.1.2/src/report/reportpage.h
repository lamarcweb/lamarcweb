// $Id: reportpage.h,v 1.33 2006/10/17 02:10:59 erynes Exp $

#ifndef REPORTPAGE_H
#define REPORTPAGE_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************
 The base class ReportPage represents a single page of the output
 report; subclasses produce specific pages.
 
 Written by Jon Yamato
*******************************************************************/

#include "types.h"
#include <map>
#include <string>
#include <vector>

using std::map;
using std::ofstream;
using std::string;
class PlotStruct;
class Parameter;
class RegionGammaInfo;

const long DEFLENGTH = 60;
const char DEFDLM='=';

typedef std::map<string, string> Strmap;
typedef std::map<string, string>::iterator Strmapiter;
typedef std::vector< std::pair < string, string> > StrPairVec;
typedef std::vector< std::pair < string, string> >::iterator StrPairVecIter;


//__________________________________________________

class ReportPage
{

private:
ReportPage();  // deliberately undefined

protected:
ofstream &outf;
vector<string> pagetitle;
char titledlm;
unsigned long pagelength, pagewidth, current_length;
verbosity_type verbosity;
bool m_bayesanalysis;
string m_MLE;

string MakeLineOf(const char ch, long length=DEFLINELENGTH,
   long indent=DEFINDENT);
string MakePageBreak();
string MakeBlankLine();
vector<string> MakeTitle();
virtual vector<string> MakeTableTitle(const string &title);
virtual vector<string> MakeTableTitle(const char *title);
StringVec1d GetOneRow(const StringVec2d table, const long rownum);
virtual string MakeSimpleRow(vector<long>& colwdth, vector<string>& contents);
virtual string MakeTwoCol(const vector<long>& colwdth, const string& col1,
   const string& col2);
virtual string MakeTwoCol(const vector<long>& colwdth, const string& col1,
   const char* col2);
virtual string MakeTwoCol(const vector<long>& colwdth, const char* col1,
   const string& col2);
virtual string MakeTwoCol(const vector<long>& colwdth, const char* col1,
   const char* col2);

virtual string MakeSectionBreak(const char dlm=DEFDLM, 
   long width=DEFLINELENGTH, long indent=DEFINDENT);
virtual vector<string> MakeTable(vector<string> &colhdr, StringVec2d &rowhdr,
   vector<long>& colwdth, StringVec3d &innards);

void PrintTitle();
void PrintLineOf(const char ch, long length=DEFLINELENGTH,
   long indent=DEFINDENT);
void PrintPageBreak();
void PrintBlankLine();

virtual void PrintSimpleRow(vector<long> &colwdth, vector<string> &contents);
virtual void PrintTwoCol(const vector<long> &colwdth, const string &col1,
   const string &col2);
virtual void PrintTwoCol(const vector<long> &colwdth, const char *col1,
   const string &col2);
virtual void PrintTwoCol(const vector<long> &colwdth, const string &col1,
   const char *col2);
virtual void PrintTwoCol(const vector<long> &colwdth, const char *col1,
   const char *col2);
virtual void PrintCenteredString(const string &str, long width=DEFLINELENGTH,
   long indent=DEFINDENT, bool trunc = true);
virtual void PrintWrapped(const string &line);
virtual void PrintWrapped(const StringVec1d& line);
virtual void PrintCenteredString(const char *str, long width=DEFLINELENGTH,
   long indent=DEFINDENT, bool trunc = true);
virtual void PrintTableTitle(const string &title);
virtual void PrintTableTitle(const char *title);
virtual void PrintSectionBreak(const char dlm=DEFDLM, 
   long width=DEFLINELENGTH, long indent=DEFINDENT);
virtual void PrintTable(vector<string> &colhdr, StringVec2d &rowhdr,
                        vector<long> &colwdth,  StringVec3d &innards);

// helper functions for the MlePage and ProfPage
  virtual double GetCentile(const vector<centilepair>& centiles,
			    double pcent);
  virtual double GetReverseCentile(const vector<centilepair>& centiles,
                                   double pcent);
  StringVec2d SortTable(StringVec2d intable, unsigned long sortcol,
			unsigned long headerrows);
  void TrimString(string& title);
  bool MakeItShorter(string& title, const unsigned long width);

public:
ReportPage(ofstream& pf, long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
  //  We accept the default for these and other ReportPage objects.
  //ReportPage(const ReportPage &src);
  //virtual ReportPage &operator=(const ReportPage &src);
virtual ~ReportPage() {};

virtual void Setup(vector<string> &title, long pglength=DEFLENGTH,
   long pgwidth=DEFLINELENGTH, char tdlm=DEFDLM);
virtual void Setup(string &title, long pglength=DEFLENGTH,
   long pgwidth=DEFLINELENGTH, char tdlm=DEFDLM);
virtual void Setup(const char *title, long pglength=DEFLENGTH,
   long pgwidth=DEFLINELENGTH, char tdlm=DEFDLM);
virtual void Show() = 0;

};

//__________________________________________________
//__________________________________________________

class MlePage : public ReportPage
{
protected:
  const long hdrindent;
  long npops;
  unsigned long colwidth;
  long label_colwidth;
  StringVec3d allforcetable;

  //  virtual void CopyMembers(const MlePage &src);
  void WritePriors();
  void WriteBody();
  StringVec1d DoPercentiles(long region,
			    vector<Parameter>::const_iterator param,
			    const DoubleVec1d& modifiers,
			    Strmap& namemap);
  StringVec1d MakeLabels(const StringVec1d subtypes, const DoubleVec1d modifiers, const bool usepercentile);
  StringVec1d MakeColumn(const string& forcename, const string& paramname,
			 const string& regionname, const double MLE,
			 const StringVec1d& percentiles, const bool usepercentiles);
  void DoRegionGammaInfo(StringVec3d& allforcetable, Strmap& namemap,
			 const RegionGammaInfo *pRegionGammaInfo);
  void AddForceToOutput(StringVec3d& allforcetable, StringVec2d forcetable);
  bool DoColumnsMatch(const StringVec1d col1, const StringVec1d col2);
  void WrapOutput(StringVec3d& allforcetable);
  void WriteOutput(StringVec3d& allforcetable, Strmap namemap);
  void NixRedundancy(StringVec1d& row, StrPairVec& legend, Strmap namemap,
		     vector<bool>& breaks);
  void WriteLine(const StringVec1d line);

// simulation specific code--to print something easily machine parsible
  void WriteSimMles();

public:
MlePage(ofstream& pf, long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
  MlePage(const MlePage &src); //Undefined
virtual ~MlePage() {};
virtual void Show();

};

class MapPage : public ReportPage
{
 public:
  MapPage(ofstream& pf, long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
  virtual ~MapPage() {};

  virtual void Show();
};

//__________________________________________________
//__________________________________________________

class ProfPage : public ReportPage
{
protected:
  unsigned long colwidth;

  //  virtual void CopyAllMembers(const ProfPage& src);
  virtual void DisplayParameters(const ParamVector& params, long region);
  StringVec1d MakeColumn(const string& name, const string& mle,
			 const StringVec1d mod_strings, const bool mixedmult);
  StringVec1d MakeGrowFixedColumn();
  DoubleVec1d MakeGrowFixedModifiers(double mle);
  StringVec1d MakeLogisticSelectionFixedColumn();
  DoubleVec1d MakeLogisticSelectionFixedModifiers(double mle);
  StringVec1d MakeModColFrom(const vector<centilepair>& numbers,
			     const DoubleVec1d modifiers,
			     vector<bool> badLnLs,
                             bool bayesfixed = false);
  StringVec1d MakeLnLColFrom(const vector<centilepair>& numbers,
			     const DoubleVec1d modifiers,
			     vector<bool>& badLnLs);
  void TradeValsForPercs(DoubleVec1d& modifiers, vector<centilepair> CIvec);
  StringVec3d WrapTable(StringVec2d& forcetable);
  void PrintTable(StringVec3d& wrappedtable);
  void PrintProfileLine(StringVec1d& line);

public:
  ProfPage(ofstream& pf, long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);

  virtual void Show();
};

//__________________________________________________
//__________________________________________________

class UsrPage : public ReportPage
{
protected:
long npops;
vector<long> m_colwidths;

  //virtual void CopyMembers(const UsrPage &src);

public:
UsrPage(ofstream& pf, long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
virtual ~UsrPage() {};

virtual void Show();
};

//__________________________________________________
//__________________________________________________

class DataPage : public ReportPage
{

private:
const long table1, table2;
long nxparts;
vector<long> m_colwidths;

protected:
  //virtual void CopyMembers(const DataPage &src);
virtual vector<string> SetupColhdr(long whichtable);
virtual StringVec2d SetupRowhdr(long whichtable);
virtual StringVec3d SetupInnards(long whichtable);

public:
DataPage(ofstream& pf, long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
virtual ~DataPage() {};

virtual void Show();
};

//__________________________________________________
//__________________________________________________

class RunPage : public ReportPage
{

private:
vector<long> m_colwidths;

public:
RunPage(ofstream& pf, long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
virtual ~RunPage() {};

virtual void Show();
};

//__________________________________________________
//__________________________________________________

class LikePage : public ReportPage
{
private:
bool Divides(long x, long y);
bool EmptyPlot(PlotStruct& plot);

public:
LikePage(ofstream& pf, long pglngth=DEFLENGTH, long pgwdth=DEFLINELENGTH);
virtual ~LikePage() {};

string MakeBorder(long points, long breaks = 4);
vector<string> MakeInnards(const DoubleVec2d& likes);
vector<string> MakeLikePlot(const StringVec1d& innards,
   const Parameter& paramX, const Parameter& paramY, long breaks = 4);
DoubleVec2d AddGraphs(const DoubleVec2d& a, const DoubleVec2d& b);

virtual void Show();
};

#endif /* REPORTPAGE_H */
