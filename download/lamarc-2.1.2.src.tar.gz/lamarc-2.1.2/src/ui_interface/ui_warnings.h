//$Id: ui_warnings.h,v 1.1 2006/04/03 21:28:18 ewalkup Exp $

/* 
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *     
 */

#ifndef UI_WARNINGS_H
#define UI_WARNINGS_H

#include <string>

using std::string;

class uiwarn
{
 public: 
  static const string calcFST_0;
  static const string calcFST_1;
};


#endif /* UI_WARNINGS_H */
