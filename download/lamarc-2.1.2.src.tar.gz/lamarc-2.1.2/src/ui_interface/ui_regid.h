//$Id: ui_regid.h,v 1.3 2005/10/13 19:26:34 lpsmith Exp $

/* 
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *     
 */

//This is not much more than a struct right now, but has some complexity in
// the constructors.  If you give it a region, locus, and the UIVars, it uses
// the UIVars to look up the data type for that region and locus.  If you just
// give it a datatype, it uses the GLOBAL_ID value for the region and locus.
// If you give it a UIId and the UIVars, it grabs the region and locus from
// Index1 and Index2, then looks up the appropriate data type in UIVars.  If
// Index1 is one of three global variables (one for each data type), it sets
// the region and locus to GLOBAL_ID, and sets the appropriate datatype.
//  --Lucian


#ifndef UIREGID_H
#define UIREGID_H

#include "datatype.h"       // for data_type

class UIVars;
class UIId;

class UIRegId
{
private:
  UIRegId(); //undefined
  long      m_region;
  long      m_locus;
  data_type m_dtype;

public:
  UIRegId(long reg, long loc, const UIVars& uivars);
  UIRegId(data_type dtype);
  UIRegId(UIId id, const UIVars& uivars);
  ~UIRegId() {};
  bool operator<(const UIRegId other) const;
  long      GetRegion()   {return m_region;};
  long      GetLocus()    {return m_locus;};
  data_type GetDataType() {return m_dtype;};
};


#endif  /* UIREGID_H */


