//$Id: data_interface.cpp,v 1.30 2005/10/27 00:01:27 lpsmith Exp $

/* 
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *     
 */

#include "data_interface.h"
#include "setget.h"
#include "ui_vars.h"
#include "ui_strings.h"
#include "vectorx.h"

#include <iostream>


////////////////////////////////////

long uiCrossPartitionCount::Get(UIVars& vars, UIId id)
{
    return vars.datapackplus.GetNCrossPartitions();
}

uiCrossPartitionCount::uiCrossPartitionCount()
    : GetLong(uistr::crossPartitionCount)
{
}

uiCrossPartitionCount::~uiCrossPartitionCount()
{
}

////////////////////////////////////

long uiMigPartitionCount::Get(UIVars& vars, UIId id)
{
    return vars.datapackplus.GetNPartitionsByForceType(force_MIG);
}

uiMigPartitionCount::uiMigPartitionCount()
    : GetLong(uistr::migrationPartitionCount)
{
}

uiMigPartitionCount::~uiMigPartitionCount()
{
}

////////////////////////////////////

string uiMigPartitionName::Get(UIVars& vars, UIId id)
{
    return vars.datapackplus.GetForcePartitionName(force_MIG,id.GetIndex1());
}

uiMigPartitionName::uiMigPartitionName()
    : GetString(uistr::migrationPartitionName)
{
}

uiMigPartitionName::~uiMigPartitionName()
{
}

////////////////////////////////////


long uiDiseasePartitionCount::Get(UIVars& vars, UIId id)
{
    return vars.datapackplus.GetNPartitionsByForceType(force_DISEASE);
}

uiDiseasePartitionCount::uiDiseasePartitionCount()
    : GetLong(uistr::diseasePartitionCount)
{
}

uiDiseasePartitionCount::~uiDiseasePartitionCount()
{
}

////////////////////////////////////


string uiDiseasePartitionName::Get(UIVars& vars, UIId id)
{
    return vars.datapackplus.GetForcePartitionName(force_DISEASE,id.GetIndex1());
}

uiDiseasePartitionName::uiDiseasePartitionName()
    : GetString(uistr::diseasePartitionName)
{
}

uiDiseasePartitionName::~uiDiseasePartitionName()
{
}

////////////////////////////////////
LongVec1d uiLociNumbers::Get(UIVars& vars, UIId id)
{
    long count = vars.datapackplus.GetNumLoci(id.GetIndex1());
    LongVec1d longVec;
    for(long i= 0; i< count; i++)
    {
        longVec.push_back(i);
    }
    return longVec;
}

uiLociNumbers::uiLociNumbers()
    : GetLongVec1d(uistr::lociNumbers)
{
}

uiLociNumbers::~uiLociNumbers()
{
}

////////////////////////////////////
LongVec1d uiRegionNumbers::Get(UIVars& vars, UIId id)
{
    long count = vars.datapackplus.GetNumRegions();
    LongVec1d longVec;
    for(long i= 0; i< count; i++)
    {
        longVec.push_back(i);
    }
    return longVec;
}

uiRegionNumbers::uiRegionNumbers()
    : GetLongVec1d(uistr::regionNumbers)
{
}

uiRegionNumbers::~uiRegionNumbers()
{
}

////////////////////////////////////
uiRegionEffectivePopSize::uiRegionEffectivePopSize()
    : SetGetDouble(uistr::effectivePopSize)
{
}

uiRegionEffectivePopSize::~uiRegionEffectivePopSize()
{
}

double uiRegionEffectivePopSize::Get(UIVars& vars, UIId id)
{
    return vars.datapackplus.GetEffectivePopSize(id.GetIndex1());
}

void uiRegionEffectivePopSize::Set(UIVars& vars, UIId id, double size)
{
    vars.datapackplus.SetEffectivePopSize(id.GetIndex1(), size);
}

////////////////////////////////////
uiSimulateData::uiSimulateData()
    : SetGetBool(uistr::simulateData)
{
}

uiSimulateData::~uiSimulateData()
{
}

bool uiSimulateData::Get(UIVars& vars, UIId id)
{
  return vars.datapackplus.GetSimulateData(id.GetIndex1(), id.GetIndex2());
}

void uiSimulateData::Set(UIVars& vars, UIId id, bool sim)
{
  vars.datapackplus.SetSimulateData(id.GetIndex1(), id.GetIndex2(), sim);
}

