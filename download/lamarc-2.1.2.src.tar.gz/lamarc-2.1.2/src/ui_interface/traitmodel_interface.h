//$Id: traitmodel_interface.h,v 1.3 2006/04/25 17:56:49 lpsmith Exp $

/* 
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *     
 */

#ifndef TRAITMODEL_INTERFACE_H
#define TRAITMODEL_INTERFACE_H

#include <string>
#include "setget.h"
#include "rangex.h"

class UIVars;

class uiTraitModelName : public GetString
{
 public:
  uiTraitModelName();
  virtual ~uiTraitModelName();
  virtual std::string Get(UIVars& vars, UIId id);
};

class SetRangepair : public SetGetTemplate<rangepair>
{
 public:
  SetRangepair(const string& key);
  virtual ~SetRangepair();
  virtual rangepair Get(UIVars& vars, UIId id); //throws
  virtual rangepair GetValFromString(UIVars& vars, string val);
};

class uiAddRangeForTraitModel : public SetRangepair
{
 public:
  uiAddRangeForTraitModel();
  virtual ~uiAddRangeForTraitModel();
  virtual void Set(UIVars& vars, UIId id, rangepair val);
};

class uiRemoveRangeForTraitModel : public SetRangepair
{
 public:
  uiRemoveRangeForTraitModel();
  virtual ~uiRemoveRangeForTraitModel();
  virtual void Set(UIVars& vars, UIId id, rangepair val);
};

class uiSetTraitModelRangeToPoint : public SetGetLong
{
 public:
  uiSetTraitModelRangeToPoint();
  virtual ~uiSetTraitModelRangeToPoint();
  virtual void Set(UIVars& vars, UIId id, long val);
  virtual long Get(UIVars& vars, UIId id); //throws!
};

class uiValidMovingLoci : public GetUIIdVec1d
{
 public:
  uiValidMovingLoci();
  virtual ~uiValidMovingLoci();
  virtual UIIdVec1d Get(UIVars& vars, UIId id);
};

class uiTraitModelFloat : public SetGetNoval
{
 public:
  uiTraitModelFloat();
  virtual ~uiTraitModelFloat();
  virtual void Set(UIVars& vars, UIId id, noval val); 
};

class uiTraitModelJump : public SetGetNoval
{
 public:
  uiTraitModelJump();
  virtual ~uiTraitModelJump();
  virtual void Set(UIVars& vars, UIId id, noval val); 
};

class uiTraitModelData : public SetGetNoval
{
 public:
  uiTraitModelData();
  virtual ~uiTraitModelData();
  virtual void Set(UIVars& vars, UIId id, noval val); 
};

class uiTraitModelPartition : public SetGetNoval
{
 public:
  uiTraitModelPartition();
  virtual ~uiTraitModelPartition();
  virtual void Set(UIVars& vars, UIId id, noval val); 
};







#endif  /* DATAMODEL_INTERFACE_H */
