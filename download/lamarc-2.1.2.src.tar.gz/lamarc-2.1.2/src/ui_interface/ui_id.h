//$Id: ui_id.h,v 1.7 2005/08/31 23:52:48 ewalkup Exp $

/* 
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *     
 */

#ifndef UIID_H
#define UIID_H

#include "constants.h"       // for force_type
#include "ui_constants.h"    // for uiconst::NO_ID

class UIId
{
    private:
                  // note -- would like to make these const members as
                  // they really shouldn't change, but we're using
                  // vectors of them (not vectors of pointers) so
                  // we have to allow the assignment operator
        bool          m_hasForce;
        force_type    m_forceType;
        long          m_index1;
        long          m_index2;
        long          m_index3;
        bool IndexesAreOkay() const;
    public:
        // note -- we are accepting the default copy constructor
        UIId(long index1=uiconst::NO_ID, long index2=uiconst::NO_ID, long index3=uiconst::NO_ID);
        UIId(force_type force, long index1=uiconst::NO_ID, long index2=uiconst::NO_ID, long index3=uiconst::NO_ID);
        force_type GetForceType() const;
        long GetIndex1() const;
        long GetIndex2() const;
        long GetIndex3() const;

        bool operator==(const UIId& id) const;
        bool HasForce() const;
        bool HasIndex1() const;
        bool HasIndex2() const;
        bool HasIndex3() const;
};


UIId & NO_ID();
UIId & GLOBAL_ID();

#endif  /* UIID_H */


