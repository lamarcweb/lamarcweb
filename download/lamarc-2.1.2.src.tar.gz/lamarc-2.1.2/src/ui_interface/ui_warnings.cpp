// $Id: ui_warnings.cpp,v 1.1 2006/04/03 21:28:18 ewalkup Exp $

#include "ui_warnings.h"
#include <string>

using std::string;

const string uiwarn::calcFST_0      = "Warning: calculating FST estimates for ";
const string uiwarn::calcFST_1      = "and their reciprocal rates is impossible due to the data for the populations involved.  If the FST method is invoked to obtain starting values for those parameters, defaults will be used instead.";
