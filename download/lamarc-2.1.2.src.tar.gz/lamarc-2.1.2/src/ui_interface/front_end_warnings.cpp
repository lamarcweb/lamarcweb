
#include "front_end_warnings.h"
#include "vectorx.h"

FrontEndWarnings::FrontEndWarnings()
{
}

FrontEndWarnings::~FrontEndWarnings()
{
}

StringVec1d
FrontEndWarnings::GetAndClearWarnings()
{
    StringVec1d warnings = m_warnings;
    m_warnings.clear();
    return warnings;
}

void
FrontEndWarnings::AddWarning(std::string warnmsg)
{
    for (unsigned long wnum=0; wnum<m_warnings.size(); wnum++)
    {
        if (m_warnings[wnum]==warnmsg) return;
    }
    m_warnings.push_back(warnmsg);
}

