//$Id: ui_constants.h,v 1.10 2005/02/19 00:14:42 lpsmith Exp $

/* 
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *     
 */

#ifndef UI_CONSTANTS_H
#define UI_CONSTANTS_H

enum ui_param_class { uipsingle, untouched, global };

class uiconst
{
    public: 
        static const long NO_ID;
        static const long GLOBAL_ID;
        static const long GLOBAL_DATAMODEL_NUC_ID;
        static const long GLOBAL_DATAMODEL_MSAT_ID;
        static const long GLOBAL_DATAMODEL_KALLELE_ID;
        static const long diseaseColumns;
        static const long migColumns;
};


#endif /* UI_CONSTANTS_H */
