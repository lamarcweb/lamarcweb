//$Id: prior_interface.h,v 1.4 2006/07/05 19:05:52 ewalkup Exp $
/* 
 *  Copyright 2004  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *     
 */

#ifndef PRIOR_INTERFACE_H
#define PRIOR_INTERFACE_H

#include <string>
#include "setget.h"

class UIVars;

class uiParameterUseDefaultPrior : public SetGetBool
{
public:
  uiParameterUseDefaultPrior();
  virtual ~uiParameterUseDefaultPrior();
  virtual bool     Get(UIVars& vars, UIId id);
  virtual void     Set(UIVars& vars, UIId id, bool val);
};

class uiParameterPriorType : public SetGetPriorType
{
public:
  uiParameterPriorType();
  virtual ~uiParameterPriorType();
  virtual priortype   Get(UIVars& vars, UIId id);
  virtual void        Set(UIVars& vars, UIId id, priortype val);
};

//-----------------------------------------------------------------
class uiParameterLowerBound : public SetGetDouble
{
public:
  uiParameterLowerBound();
  virtual ~uiParameterLowerBound();
  virtual double      Get(UIVars& vars, UIId id);
  virtual void        Set(UIVars& vars, UIId id, double val);
  virtual string      Min(UIVars& vars, UIId id);
  virtual string      Max(UIVars& vars, UIId id);
};

//-----------------------------------------------------------------
class uiParameterUpperBound : public SetGetDouble
{
public:
  uiParameterUpperBound();
  virtual ~uiParameterUpperBound();
  virtual double      Get(UIVars& vars, UIId id);
  virtual void        Set(UIVars& vars, UIId id, double val);
  virtual string      Min(UIVars& vars, UIId id);
  virtual string      Max(UIVars& vars, UIId id);
};

class uiPriorByForce : public SetGetNoval
{
public:
  uiPriorByForce();
  virtual ~uiPriorByForce();
  string Description(UIVars& vars, UIId id);
  string GetPrintString(UIVars& vars, UIId id);
  void Set(UIVars& vars, UIId id, noval val) {};
};

class uiPriorById : public SetGetNoval
{
public:
  uiPriorById();
  virtual ~uiPriorById();
  string Description(UIVars& vars, UIId id);
  string GetPrintString(UIVars& vars, UIId id);
  void Set(UIVars& vars, UIId id, noval val) {};
};

class uiUseDefaultPriorsForForce : public SetGetNoval
{
 public:
  uiUseDefaultPriorsForForce();
  virtual ~uiUseDefaultPriorsForForce();
  void Set(UIVars& vars, UIId id, noval val);
  string Description(UIVars& vars, UIId id);
};

#endif  /* PRIOR_INTERFACE_H */
