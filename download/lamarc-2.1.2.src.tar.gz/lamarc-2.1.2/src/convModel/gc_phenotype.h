#ifndef GC_PHENOTYPE_H
#define GC_PHENOTYPE_H

#include "gc_quantum.h"
#include "gc_set_util.h"
#include <vector>
#include "wx/string.h"

class GCStructures;

class gcHapProbability 
{

    private:
        bool            m_hasPenetrance;
        double          m_penetrance;
        gcIdVec         m_alleleIds;



    public:
        gcHapProbability();
        virtual ~gcHapProbability();

        bool    HasPenetrance() const;
        double  GetPenetrance() const;
        void    SetPenetrance(double penetrance);
        void    UnsetPenetrance();

        void    AddAlleleId(size_t alleleId);
        const gcIdVec & GetAlleleIds() const;

        void    DebugDump(wxString prefix=wxEmptyString) const;
};

class gcPhenotype : public GCQuantum
{
    friend class GCStructures;

    private:
        bool                            m_hasTraitId;
        size_t                          m_traitId;
        bool                            m_hasExplicitName;

        std::vector<gcHapProbability>   m_hapProbabilities;


        void    SetTraitId(size_t traitId);
        void    UnsetTraitId();


    public:
        gcPhenotype();
        virtual ~gcPhenotype();

        void    AddHapProbability(const gcHapProbability &);

        bool    HasExplicitName() const;

        const std::vector<gcHapProbability> & GetHapProbabilities() const;
        bool    HasTraitId() const;
        size_t  GetTraitId() const;

        void    SetHasExplicitName();

        void    DebugDump(wxString prefix=wxEmptyString) const;
};


#endif
//GC_PHENOTYPE_H
