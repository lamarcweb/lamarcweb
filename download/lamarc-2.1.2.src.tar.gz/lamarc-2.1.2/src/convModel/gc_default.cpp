#include "gc_default.h"
#include "wx/string.h"

const long       gcdefault::badDisplayIndex = -999;
const size_t     gcdefault::badIndex        = 999;
const size_t     gcdefault::badLength       = 9999;
const long       gcdefault::badLocation     = -9999;
const long       gcdefault::badMapPosition  = -9999;
const wxString   gcdefault::createdIndividualPrefix = "createdIndividual";
const wxString   gcdefault::delimiter       = ".";
const wxString   gcdefault::emptyBlock      = "<empty>";
const wxString   gcdefault::locusName       = "<unnamed segment>";
const size_t     gcdefault::migrateSequenceNameLength   = 10;
const double     gcdefault::penetrance      = 0.0;
const size_t     gcdefault::numSites        = 0;
const wxString   gcdefault::popName         = "<unnamed population>";
const wxString   gcdefault::regionName      = "<unnamed region>";
const wxString   gcdefault::unnamedObject   = "<unnamed object>";
