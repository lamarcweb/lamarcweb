#ifndef GC_DICTIONARY_H
#define GC_DICTIONARY_H

#include "wx/string.h"
#include <set>


class gcDictionary : private std::set<wxString>
{
    private:
    protected:
        // tells you what types of things are in this dictionary
        virtual const wxString &    infoString() const = 0;
    public:
        gcDictionary();
        virtual ~gcDictionary();

        bool        HasName     (const wxString & name) const;
        void        FreeName    (const wxString & name);
        void        ReserveName (const wxString & name);
        wxString    ReserveOrMakeName(  wxString useIfNotEmpty,
                                        wxString prefixIfCreatingName=wxEmptyString);
        
};

#endif
//GC_DICTIONARY_H
