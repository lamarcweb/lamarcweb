#include "gc_errhandling.h"
#include "gc_exportable.h"
#include "gc_individual.h"
#include "gc_population.h"
#include "gc_region.h"
#include "gc_strings.h"
#include "wx/log.h"
#include "wx/string.h"

gcPopRegionPair::gcPopRegionPair(const GCPopulation * p, const gcRegion * r)
    :
        std::pair<const GCPopulation *,const gcRegion *>(p,r)
{
}

gcPopRegionPair::~gcPopRegionPair()
{
}

void
gcPopRegionPair::DebugDump(wxString prefix) const
{
    wxString pname = (*first).GetName();
    wxString rname = (*second).GetName();
    wxLogDebug("%spop/region:(%s,%s)",prefix.c_str(),pname.c_str(),rname.c_str());  // EWDUMPOK
}


////////////////////////////////////////////////////

gcNameResolvedInfo::gcNameResolvedInfo(const GCPopulation & pop, const gcRegion & reg)
    :
        m_populationRef(pop),
        m_regionRef(reg)
{
}

gcNameResolvedInfo::~gcNameResolvedInfo()
{
    for(std::vector<GCIndividual*>::iterator i = m_individuals.begin();
        i != m_individuals.end(); i++)
    {
        delete *i;
    }
}

void
gcNameResolvedInfo::AddIndividual(GCIndividual * ind)
{
    m_individuals.push_back(ind);
}

const GCPopulation &
gcNameResolvedInfo::GetPopRef() const
{
    return m_populationRef;
}

const gcRegion &
gcNameResolvedInfo::GetRegionRef() const
{
    return m_regionRef;
}

std::vector<const GCIndividual*>
gcNameResolvedInfo::GetIndividuals() const
{
    std::vector<const GCIndividual*> inds;
    for(size_t index=0; index < m_individuals.size(); index++)
    {
        inds.push_back(m_individuals[index]);
    }
    return inds;
}

void
gcNameResolvedInfo::DebugDump(wxString prefix) const
{
    wxLogDebug("%svector of %d individuals",prefix.c_str(),(int)m_individuals.size());  // EWDUMPOK
}

////////////////////////////////////////////////////

gcExportable::gcExportable()
{
}

gcExportable::~gcExportable()
{
    for(iterator i=begin(); i != end(); i++)
    {
        delete (*i).second;
    }
}

const gcNameResolvedInfo &
gcExportable::GetInfo(const GCPopulation & pop, const gcRegion & region) const
{
    gcPopRegionPair pair(&pop,&region);
    const_iterator i = find(pair);
    if(i == end())
    {
        wxString popName = pop.GetName();
        wxString regionName = region.GetName();
        gui_error g(wxString::Format(gcerr::nameResolutionPairMissing,popName.c_str(),regionName.c_str()));
        throw g;
    }
    return *((*i).second);
}

void
gcExportable::DebugDump(wxString prefix) const
{
    wxLogDebug("%sgcExportable:",prefix.c_str());   // EWDUMPOK
    for(const_iterator i=begin(); i!=end(); i++)
    {
        gcPopRegionPair pair = (*i).first;
        const gcNameResolvedInfo * info = (*i).second;
        pair.DebugDump(wxString::Format("%s    ",prefix.c_str()));
        info->DebugDump(wxString::Format("%s    ",prefix.c_str()));
    }
}
