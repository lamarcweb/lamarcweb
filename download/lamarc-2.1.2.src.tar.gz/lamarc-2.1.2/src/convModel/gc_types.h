#ifndef GC_TYPES_H
#define GC_TYPES_H

#include <map>
#include <list>
#include <set>
#include <string>
#include "Converter_types.h"

enum GCFileFormat   {
    // should include each type of file converter can read
        format_NONE_SET,
        format_PHYLIP, 
        format_MIGRATE
    };

enum gcSpecificDataType {
    //  data types as used in lamarc
        sdatatype_NONE_SET,
        sdatatype_DNA,
        sdatatype_SNP,
        sdatatype_KALLELE,
        sdatatype_MICROSAT
    };

class gcGeneralDataType : public std::set<gcSpecificDataType>
{
    public:
        gcGeneralDataType();
        virtual ~gcGeneralDataType();
        bool HasAllelic() const;
        bool HasNucleic() const;
        bool CompatibleWith(const gcGeneralDataType&) const;
        void Disallow(const gcSpecificDataType);
        void Intersect(const gcGeneralDataType&);
        void Union(const gcGeneralDataType&);
        void Union(const gcSpecificDataType);
        gcGeneralDataType & operator=(const gcSpecificDataType);
};

enum GCInterleaving {
    // are data sequences presented all at once or for interleaved comparison
        interleaving_NONE_SET,
        interleaving_SEQUENTIAL,
        interleaving_INTERLEAVED,
        interleaving_MOOT
    };

enum gcPhaseSource  {
    phaseSource_NONE_SET,
    phaseSource_PHASE_FILE,
    phaseSource_MULTI_PHASE_SAMPLE,
    phaseSource_FILE_ADJACENCY,
    phaseSource_COUNT
    };

enum loc_match  {   locmatch_DEFAULT,
                    locmatch_SINGLE,
                    locmatch_VECTOR
                };

enum pop_match  {   popmatch_DEFAULT,
                    popmatch_NAME,
                    popmatch_SINGLE,
                    popmatch_VECTOR };


#endif
//GC_TYPES_H
