#include "gc_default.h"
#include "gc_trait_allele.h"
#include "gc_trait_err.h"

gcTraitAllele::gcTraitAllele()
    :
        m_hasTraitId(false),
        m_traitId(gcdefault::badIndex)
{
}

gcTraitAllele::~gcTraitAllele()
{
}

bool
gcTraitAllele::HasTraitId() const
{
    return m_hasTraitId;
}

size_t
gcTraitAllele::GetTraitId() const
{
    assert(HasTraitId());
    return m_traitId;
}

void
gcTraitAllele::SetTraitId(size_t traitId)
{
    m_hasTraitId = true;
    m_traitId = traitId;
}

void
gcTraitAllele::UnsetTraitId()
{
    m_hasTraitId = false;
}

void
gcTraitAllele::SetName(wxString alleleName)
{
    if(alleleName.Find(' ') != wxNOT_FOUND)
    {
        throw gc_trait_allele_name_spaces(alleleName);
    }
    GCQuantum::SetName(alleleName);
}
