#ifndef GC_FILE_H
#define GC_FILE_H

#include "gc_parse.h"
#include "gc_quantum.h"
#include "gc_structure_maps.h"
#include "gc_types.h"
#include "wx/string.h"

class GCDataStore;
class GCFileLines;

class GCFile : public GCQuantum
{
    friend class GCDataStore;   // EWFIX.P3 -- think about making a
                                // separate object that has access
                                // to the SetParses method -- it
                                // should only be necessary at GCFile
                                // creation time
    private:
        GCDataStore &       m_dataStore;
        wxString            m_fullPathFileName;
        GCParseVec *        m_parses;   // we own this

        GCFile();       // undefined
        GCFile( GCDataStore & dataStoreRef, wxString name);
    protected:
        void SetParses(GCParseVec * parses);
        static std::map<wxString,wxString> s_fileNameMap;
    public:
        virtual ~GCFile();
        
        wxString            GetDataTypeString()     const;
        wxString            GetFormatString()       const;
        wxString            GetInterleavingString() const;
        wxString            GetName()               const;
        bool                GetNeedsSettings()      const;
        wxString            GetShortName()          const;
        const GCParse &     GetParse(size_t choice) const;
        const GCParse &     GetParse(GCFileFormat,gcGeneralDataType,GCInterleaving) const;
        size_t              GetParseCount()         const;

        void DebugDump(wxString prefix=wxEmptyString) const;

        wxArrayString   PossibleSettings() const;

        gcIdSet         IdsOfAllParses() const;
        gcIdSet         IdsOfAllBlocks() const;

        GCFileFormat        GetFormat()             const; 
        gcGeneralDataType   GetGeneralDataType()    const; 
        GCInterleaving      GetInterleaving()       const;


};


struct GCFileCompare
{
    bool operator()(const GCFile*,const GCFile*);
};

typedef std::set<GCFile*,GCFileCompare>         dataFileSet;
typedef std::set<const GCFile*,GCFileCompare>   constDataFileSet;



#endif
//GC_FILE_H
