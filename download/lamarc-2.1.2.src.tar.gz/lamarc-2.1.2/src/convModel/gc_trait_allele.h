#ifndef GC_TRAIT_ALLELE_H
#define GC_TRAIT_ALLELE_H

#include "gc_quantum.h"
#include "wx/string.h"


class gcTraitAllele : public GCQuantum
{
    friend class GCStructures;

    private:
        bool                            m_hasTraitId;
        size_t                          m_traitId;

        void    SetTraitId(size_t traitId);
        void    UnsetTraitId();

    protected:
    public:

        gcTraitAllele();
        virtual ~gcTraitAllele();

        bool    HasTraitId()    const;
        size_t  GetTraitId()    const;

        virtual void    SetName(wxString name); // overrides gc_quantum version
                                                // so name can be checked for
                                                // spaces

};


#endif
//GC_TRAIT_ALLELE_H
