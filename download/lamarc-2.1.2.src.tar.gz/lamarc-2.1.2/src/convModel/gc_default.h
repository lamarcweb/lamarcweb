#ifndef GC_DEFAULT_H
#define GC_DEFAULT_H

#include "gc_types.h"
#include "wx/string.h"

class gcdefault
{
    public:
        static const long       badDisplayIndex;
        static const size_t     badIndex;
        static const size_t     badLength;
        static const long       badLocation;
        static const long       badMapPosition;
        static const wxString   createdIndividualPrefix;
        static const wxString   delimiter;
        static const wxString   emptyBlock;
        static const wxString   locusName;
        static const double     penetrance;
        static const size_t     migrateSequenceNameLength;
        static const size_t     numSites;
        static const wxString   popName;
        static const wxString   regionName;
        static const wxString   unnamedObject;
};
#endif
//GC_DEFAULT_H
