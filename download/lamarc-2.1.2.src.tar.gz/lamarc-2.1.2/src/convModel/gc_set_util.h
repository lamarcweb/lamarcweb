#ifndef GC_SET_UTIL_H
#define GC_SET_UTIL_H

#include "wx/string.h"

#include <set>
#include <vector>



class gcIdSet : public std::set<size_t>
{
    public:
        gcIdSet() ;
        ~gcIdSet() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
        wxString AsString() const;
};

class gcIdVec : public std::vector<size_t>
{
    public:
        gcIdVec() ;
        ~gcIdVec() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
        wxString AsString() const;
};

#endif
// GC_SET_UTIL_H
