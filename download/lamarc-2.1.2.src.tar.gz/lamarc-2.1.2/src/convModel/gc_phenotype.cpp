#include "gc_default.h"
#include "gc_phenotype.h"
#include "gc_strings.h"
#include "gc_trait_err.h"
#include "wx/log.h"
#include "wx/string.h"

gcHapProbability::gcHapProbability()
    :   m_hasPenetrance(false), 
        m_penetrance(gcdefault::penetrance)
{
}

gcHapProbability::~gcHapProbability()
{
}

bool
gcHapProbability::HasPenetrance() const
{
    return m_hasPenetrance;
}

double
gcHapProbability::GetPenetrance() const
{
    assert(HasPenetrance());
    return m_penetrance;
}

void
gcHapProbability::SetPenetrance(double penetrance)
{
    if(penetrance < 0)
    {
        throw gc_haplotype_probability_negative(penetrance);
    }
    m_hasPenetrance = true;
    m_penetrance = penetrance;
}

void
gcHapProbability::UnsetPenetrance()
{
    m_hasPenetrance = false;
}

void
gcHapProbability::AddAlleleId(size_t alleleId)
{
    m_alleleIds.push_back(alleleId);
}

const gcIdVec &
gcHapProbability::GetAlleleIds() const
{
    return m_alleleIds;
}

void
gcHapProbability::DebugDump(wxString prefix) const
{
    wxLogDebug("%shap probability %lf for alleles %s",   // EWDUMPOK
        prefix.c_str(),
        GetPenetrance(),
        GetAlleleIds().AsString().c_str());
}


/////////////////////////////////////////////////////


gcPhenotype::gcPhenotype()
    :   m_hasTraitId(false),
        m_traitId(gcdefault::badIndex),
        m_hasExplicitName(false)
{
}

gcPhenotype::~gcPhenotype()
{
}

void
gcPhenotype::AddHapProbability(const gcHapProbability & hp)
{
    m_hapProbabilities.push_back(hp);
}

const std::vector<gcHapProbability> &
gcPhenotype::GetHapProbabilities() const
{
    return m_hapProbabilities;
}

bool
gcPhenotype::HasTraitId() const
{
    return m_hasTraitId;
}

size_t
gcPhenotype::GetTraitId() const
{
    assert(HasTraitId());
    return m_traitId;
}

void
gcPhenotype::SetTraitId(size_t traitId)
{
    m_hasTraitId = true;
    m_traitId = traitId;
}

bool
gcPhenotype::HasExplicitName() const
{
    return m_hasExplicitName;
}

void
gcPhenotype::SetHasExplicitName()
{
    m_hasExplicitName = true;
}

void
gcPhenotype::DebugDump(wxString prefix) const
{
    wxLogDebug("%sphenotype %s of trait %d",   // EWDUMPOK
        prefix.c_str(),
        GetName().c_str(),
        GetTraitId());
    for(size_t i = 0; i < m_hapProbabilities.size(); i++)
    {
        const gcHapProbability & hp = m_hapProbabilities[i];
        hp.DebugDump(prefix+gcstr::indent);
    }
}


