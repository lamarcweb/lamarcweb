#include "gc_data.h"
#include "gc_default.h"
#include "gc_region.h"
#include "gc_population.h"
#include "gc_locus.h"
#include "gc_strings.h"
#include "gc_structure_maps.h"
#include "gc_trait.h"
#include "wx/log.h"
#include "wx/string.h"

gcDisplayOrder::gcDisplayOrder()
{
}

gcDisplayOrder::~gcDisplayOrder()
{
}

wxString
gcDisplayOrder::AsString() const
{
    wxString ids="";
    for(const_iterator i=begin(); i != end(); i++)
    {
        size_t blockId = *i;
        ids += wxString::Format("%d ",(int)blockId);
    }
    return ids;
}

void
gcDisplayOrder::DebugDump(wxString prefix) const
{
    wxLogDebug("%s%s", prefix.c_str(), AsString().c_str()); // EWDUMPOK
}

gcPopLocusIdPair::gcPopLocusIdPair()
{
}

gcPopLocusIdPair::gcPopLocusIdPair(size_t popId, size_t locId)
    : std::pair<size_t,size_t>(popId,locId)
{
}

gcPopLocusIdPair::~gcPopLocusIdPair()
{
}

void
gcPopLocusIdPair::DebugDump(wxString prefix) const
{
    wxLogDebug("%s<%d,%d>", // EWDUMPOK
        prefix.c_str(),
        (int)first,
        (int)second);
}

gcBlockSetMap::gcBlockSetMap()
{
}

gcBlockSetMap::~gcBlockSetMap()
{
}

void
gcBlockSetMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%sblock from:",prefix.c_str()); // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        gcPopLocusIdPair idP = (*i).first;
        gcIdSet set = (*i).second;
        wxLogDebug("%s<%d,%d> -> %s",   // EWDUMPOK
            (prefix+gcstr::indent).c_str(),
            (int)(idP.first),
            (int)(idP.second),
            set.AsString().c_str());
    }
}

gcRegionMap::gcRegionMap()
{
}

gcRegionMap::~gcRegionMap()
{
}

void
gcRegionMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%sregions:",prefix.c_str()); // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        const gcRegion & region = (*i).second;
        region.DebugDump(prefix+gcstr::indent);
    }
}

gcLocusMap::gcLocusMap()
{
}

gcLocusMap::~gcLocusMap()
{
}

void
gcLocusMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%ssegments:",prefix.c_str());   // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        const gcLocus & locus = (*i).second;
        locus.DebugDump(prefix+gcstr::indent);
    }
}

gcPopMap::gcPopMap()
{
}

gcPopMap::~gcPopMap()
{
}

void
gcPopMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%spopulations:",prefix.c_str());    // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        const GCPopulation & pop = (*i).second;
        pop.DebugDump(prefix+gcstr::indent);
    }
}

gcPopMultiMap::gcPopMultiMap()
{
}

gcPopMultiMap::~gcPopMultiMap()
{
}

void
gcPopMultiMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%spop correspondence:",prefix.c_str()); // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        wxLogDebug("%spop %d file %d parsePop %d",  // EWDUMPOK
            (prefix+gcstr::indent).c_str(),(int)((*i).first),(int)((*i).second.first),(int)((*i).second.second));
    }
}

///////////////////////////////////////

gcTraitMap::gcTraitMap()
{
}

gcTraitMap::~gcTraitMap()
{
}

void
gcTraitMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%strait classes:",prefix.c_str());  // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        const GCTraitInfo & trait = (*i).second;
        trait.DebugDump(prefix+gcstr::indent);
    }
}

///////////////////////////////////////

gcAlleleMap::gcAlleleMap()
{
}

gcAlleleMap::~gcAlleleMap()
{
}

void
gcAlleleMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%salleles:",prefix.c_str());  // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        const gcTraitAllele & allele = (*i).second;
        allele.DebugDump(prefix+gcstr::indent);
    }
}

///////////////////////////////////////

gcPhenoMap::gcPhenoMap()
{
}

gcPhenoMap::~gcPhenoMap()
{
}

void
gcPhenoMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%sphenotypes:",prefix.c_str());  // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        const gcPhenotype & pheno = (*i).second;
        pheno.DebugDump(prefix+gcstr::indent);
    }
}

///////////////////////////////////////

gcStringMap::gcStringMap()
{
}

gcStringMap::~gcStringMap()
{
}

void
gcStringMap::DebugDump(wxString prefix) const
{
    wxLogDebug("%sstring map:",prefix.c_str()); // EWDUMPOK
    for(const_iterator i=begin(); i != end(); i++)
    {
        wxLogDebug("%s%d:%s",   // EWDUMPOK
                        (prefix+gcstr::indent).c_str(),
                        (int)((*i).first),
                        (*i).second.c_str());
    }
}


constBlockVector::constBlockVector()
{
}

constBlockVector::~constBlockVector()
{
}

popVector::popVector()
{
}

popVector::~popVector()
{
}


locVector::locVector()
{
}

locVector::~locVector()
{
}

