#ifndef GC_PHASE_INFO
#define GC_PHASE_INFO

#include "gc_genotype_resolution.h"
#include "gc_phase.h"       // for gcUnphasedMarkers
#include "gc_phase_err.h"
#include "gc_set_util.h"
#include "gc_types.h"
#include "wx/arrstr.h"
#include "wx/string.h"
#include <map>
#include <set>


class gcPhaseInfo;

typedef std::map<wxString,gcUnphasedMarkers>    gcIndPhaseInfo;
typedef std::set<wxString>                      gcPhenotypeNames;

class gcPhaseRecord
{
    friend class gcPhaseInfo;

    private:
        gcPhaseSource       m_phaseSource;
        wxString            m_fileName;
        wxString            m_individual;
        size_t              m_sampleCountIfNoSamples;
        wxArrayString       m_samples;
        gcIndPhaseInfo      m_unphasedInfo;
        gcIdSet             m_phenotypeIds;
    protected:

    public:
        // best created with static methods below
        gcPhaseRecord();

        // not a virtual destructor -- we don't want these things
        // polymorphic
        // EWFIX.P3 -- WHY ???
        ~gcPhaseRecord();

        void                    AddPhenotypeId (size_t phenoId);
        const gcIdSet &         GetPhenotypeIds() const;
        void                    MergePhenotypeIds(const gcPhaseRecord&);

        gcPhaseSource           GetPhaseSource()    const;

        bool                    HasFileName()       const;
        const wxString &        GetFileName()       const;

        bool                    HasIndividual()     const;
        const wxString &        GetIndividual()     const;

        bool                    HasSamples()        const;
        const wxArrayString &   GetSamples()        const;
        size_t                  GetSampleCount()    const;

        bool                    HasAnyZeroes()      const;


        void        AddUnphased(wxString locusName, const gcUnphasedMarkers & );
        bool                        HasUnphased(const wxString locusName) const;
        const gcUnphasedMarkers &   GetUnphased(const wxString locusName) const;
        wxArrayString               GetUnphasedLocusNames() const;

        bool operator==(const gcPhaseRecord&)       const;
        bool operator!=(const gcPhaseRecord&)       const;

        void    DebugDump(wxString prefix=wxEmptyString) const;

        static gcPhaseRecord MakeAdjacentPhaseRecord(   wxString        fileName,
                                                        wxArrayString   samples);
        static gcPhaseRecord MakeAllelicPhaseRecord(    wxString        fileName,
                                                        wxString        individualName,
                                                        size_t          numSamples);

        // ARGH! only this one is a pointer because in cmdParseIndividual
        // we need to make a bunch of them and then choose whether to use
        // or lose them all at once
        static gcPhaseRecord * MakeFullPhaseRecord(     wxString        fileName,
                                                        wxString        individualName,
                                                        wxArrayString   sampleNames);
};

typedef std::pair<wxString,gcPhaseRecord>       recordPair;
typedef std::map<wxString,gcPhaseRecord>        stringToRecord;

class gcPhaseInfo
{
    private:
        stringToRecord      m_fromIndividual;
        stringToRecord      m_fromSample;
    protected:
        // returns true if new record was added
        bool    AddRecordIndividual (const gcPhaseRecord &);
        // returns true if new record was added
        bool    AddRecordSample     (const gcPhaseRecord &);

        // returns true if old record was replaced by new
        bool    MergeIndividualRecs (const gcPhaseRecord & curRec,
                                     const gcPhaseRecord & newRec);
    public:
        gcPhaseInfo();
        virtual ~gcPhaseInfo();

        void    AddRecord(const gcPhaseRecord&);
        void    AddRecords(const gcPhaseInfo &);

        void    RemoveRecord(const gcPhaseRecord&);

        bool                    HasIndividualRecord(wxString name)  const;
        const gcPhaseRecord &   GetIndividualRecord(wxString name)  const;

        bool                    HasSampleRecord(wxString name)      const;
        const gcPhaseRecord &   GetSampleRecord(wxString name)      const;

        void    DebugDump(wxString prefix=wxEmptyString) const;

        const stringToRecord &  GetIndividualRecords() const;

        bool    HasAnyZeroes() const;

};


#endif
//GC_PHASE_INFO
