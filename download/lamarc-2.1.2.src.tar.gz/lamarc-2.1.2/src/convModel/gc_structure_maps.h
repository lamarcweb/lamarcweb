#ifndef GC_STRUCTURE_MAPS_H
#define GC_STRUCTURE_MAPS_H

#include <list>
#include <map>
#include <set>

#include "gc_locus.h"
#include "gc_population.h"
#include "gc_quantum.h"
#include "gc_region.h"
#include "gc_phenotype.h"
#include "gc_set_util.h"
#include "gc_trait.h"
#include "gc_trait_allele.h"

#include "gc_loci_match.h"
#include "gc_pop_match.h"

#include "wx/string.h"

class GCParseBlock;

class gcDisplayOrder :  public std::list<size_t>
{
    public:
        gcDisplayOrder() ;
        ~gcDisplayOrder() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
        wxString AsString() const;
};

class gcPopLocusIdPair : public std::pair<size_t, size_t>
{
    public:
        gcPopLocusIdPair() ;
        gcPopLocusIdPair(size_t i,size_t j);
        ~gcPopLocusIdPair() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcBlockSetMap : public std::map<gcPopLocusIdPair,gcIdSet>
{
    public:
        gcBlockSetMap() ;
        ~gcBlockSetMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcRegionMap : public std::map<size_t,gcRegion>
{
    public:
        gcRegionMap() ;
        virtual ~gcRegionMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcPopMap : public std::map<size_t,GCPopulation>
{
    public:
        gcPopMap() ;
        virtual ~gcPopMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcPopMultiMap : public std::multimap<size_t, std::pair< size_t, size_t> >
{
    public:
        gcPopMultiMap() ;
        virtual ~gcPopMultiMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcLocusMap : public std::map<size_t,gcLocus>
{
    public:
        gcLocusMap() ;
        virtual ~gcLocusMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcTraitMap : public std::map<size_t,GCTraitInfo>
{
    public:
        gcTraitMap() ;
        virtual ~gcTraitMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcAlleleMap : public std::map<size_t,gcTraitAllele>
{
    public:
        gcAlleleMap() ;
        virtual ~gcAlleleMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcPhenoMap : public std::map<size_t,gcPhenotype>
{
    public:
        gcPhenoMap() ;
        virtual ~gcPhenoMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};



class gcStringMap : public std::map<size_t,wxString>
{
    public:
        gcStringMap() ;
        virtual ~gcStringMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

typedef std::vector<GCQuantum *>        objVector;
typedef std::vector<const GCQuantum *>  constObjVector;

class constBlockVector : public std::vector<const GCParseBlock *>
{
    public:
        constBlockVector() ;
        virtual ~constBlockVector() ;
        //void DebugDump(wxString prefix=wxEmptyString) const;
};

class popVector : public std::vector<GCPopulation *>
{
    public:
        popVector() ;
        virtual ~popVector() ;
};

class locVector : public std::vector<gcLocus *>
{
    public:
        locVector() ;
        virtual ~locVector() ;
};

#endif
//GC_STRUCTURE_MAPS_H
