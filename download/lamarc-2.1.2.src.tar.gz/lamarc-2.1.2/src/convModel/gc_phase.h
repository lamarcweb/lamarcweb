#ifndef GC_PHASE_H
#define GC_PHASE_H

#include "wx/string.h"
#include <set>

class gcLocus;

class gcUnphasedMarkers : private std::set<long>
    // represents the markers which 
{
    private:
    protected:
    public:
        gcUnphasedMarkers();
        virtual ~gcUnphasedMarkers();
        
        wxString        AsString()      const;
        size_t          NumMarkers()    const;

        long            Smallest()      const;
        long            Largest ()      const;

        void            AddMarker(long marker);
        void            Merge(const gcUnphasedMarkers& );
        void            ReadFromString(wxString line);

        void            DebugDump(wxString prefix=wxEmptyString) const;

        bool            operator!=(const gcUnphasedMarkers&) const;
        bool            HasZero() const;

        void            ShiftNegsUp();
        void            CheckAgainstLocations(const gcLocus&) const;
};

#endif
//GC_PHASE_H
