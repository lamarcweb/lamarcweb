#include "gc_default.h"
#include "gc_genotype_resolution.h"
#include "gc_phenotype.h"
#include "gc_strings_trait.h"
#include "gc_trait.h"
#include "gc_trait_allele.h"
#include "gc_trait_err.h"
#include "wx/log.h"

GCTraitInfo::GCTraitInfo()
    :
        m_hasRegion(false),
        m_regionId(gcdefault::badIndex)
{
}

GCTraitInfo::~GCTraitInfo()
{
}

void
GCTraitInfo::AddAllele(const gcTraitAllele& allele)
{
    if(m_alleleIds.find(allele.GetId()) != m_alleleIds.end())
    {
        throw gc_trait_allele_name_reuse(allele.GetName());
    }
    m_alleleIds.insert(allele.GetId());
}

void
GCTraitInfo::RemoveAllele(const gcTraitAllele& allele)
{
    gcIdSet::iterator iter = m_alleleIds.find(allele.GetId());
    assert(iter != m_alleleIds.end());
    m_alleleIds.erase(iter);
}

bool
GCTraitInfo::HasAlleleId(size_t alleleId) const
{
    return (!(m_alleleIds.find(alleleId) == m_alleleIds.end()));
}

void
GCTraitInfo::AddPhenotype(const gcPhenotype& pheno)
{
    if(m_phenotypeIds.find(pheno.GetId()) != m_phenotypeIds.end())
    {
        throw gc_trait_phenotype_name_reuse(pheno.GetName(),GetName());
    }
    m_phenotypeIds.insert(pheno.GetId());
}

void
GCTraitInfo::RemovePhenotype(const gcPhenotype& pheno)
{
    gcIdSet::iterator iter = m_phenotypeIds.find(pheno.GetId());
    assert(iter != m_phenotypeIds.end());
    m_phenotypeIds.erase(iter);
}

bool
GCTraitInfo::HasPhenotype(const gcPhenotype & phenotype) const
{
    return (!(m_phenotypeIds.find(phenotype.GetId()) == m_phenotypeIds.end()));
}

const gcIdSet &
GCTraitInfo::GetAlleleIds() const
{
    return m_alleleIds;
}

const gcIdSet &
GCTraitInfo::GetPhenotypeIds() const
{
    return m_phenotypeIds;
}

size_t
GCTraitInfo::GetRegionId() const
{
    return m_regionId;
}

bool
GCTraitInfo::HasRegionId() const
{
    return m_hasRegion;
}

void
GCTraitInfo::SetRegionId(size_t id)
{
    m_hasRegion = true;
    m_regionId = id;
}

void
GCTraitInfo::UnsetRegionId()
{
    m_hasRegion = false;
}

void
GCTraitInfo::DebugDump(wxString prefix) const
{
    wxLogDebug("%strait \"%s\" has alleles: %s, phenotypes: %s",    // EWDUMPOK
                    prefix.c_str(),
                    GetName().c_str(),
                    m_alleleIds.AsString().c_str(),
                    m_phenotypeIds.AsString().c_str());
}
