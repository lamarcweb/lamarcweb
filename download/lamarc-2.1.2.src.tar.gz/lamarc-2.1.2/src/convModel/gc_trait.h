#ifndef GC_TRAIT_H
#define GC_TRAIT_H

#include <map>
#include <set>
#include "gc_quantum.h"
#include "gc_set_util.h"
#include "wx/string.h"

class GCGenotypeResolution;
class gcPhenotype;
class GCStructures;
class gcTraitAllele;


class GCTraitInfo : public GCQuantum
{
    friend class GCStructures;

    private:
        bool                    m_hasRegion;
        size_t                  m_regionId;

        gcIdSet                 m_alleleIds;
        gcIdSet                 m_phenotypeIds;

        void SetRegionId(size_t id);
        void UnsetRegionId();

        void AddAllele(const gcTraitAllele &);
        void RemoveAllele(const gcTraitAllele &);

        void AddPhenotype(const gcPhenotype&);
        void RemovePhenotype(const gcPhenotype&);
    public:
        GCTraitInfo();
        ~GCTraitInfo();

        const gcIdSet & GetAlleleIds() const;
        bool            HasAlleleId(size_t alleleId) const;

        const gcIdSet & GetPhenotypeIds() const;
        bool            HasPhenotype(const gcPhenotype &)const;


        size_t      GetRegionId()       const   ;
        bool        HasRegionId()       const   ;

        void        DebugDump(wxString prefix=wxEmptyString) const;
};

#endif
//GC_TRAIT_H
