#include "gc_set_util.h"
#include "wx/log.h"

gcIdSet::gcIdSet()
{
}

gcIdSet::~gcIdSet()
{
}

void
gcIdSet::DebugDump(wxString prefix) const
{
    wxString ids="";
    for(const_iterator i=begin(); i != end(); i++)
    {
        size_t id = *i;
        ids += wxString::Format("%d ",(int)id);
    }
    wxLogDebug("%s%s", prefix.c_str(), ids.c_str());    // EWDUMPOK
}

wxString
gcIdSet::AsString() const
{
    wxString ids="";
    for(const_iterator i=begin(); i != end(); i++)
    {
        size_t blockId = *i;
        ids += wxString::Format("%d ",(int)blockId);
    }
    return ids;
}

gcIdVec::gcIdVec()
{
}

gcIdVec::~gcIdVec()
{
}

void
gcIdVec::DebugDump(wxString prefix) const
{
    wxString ids="";
    for(const_iterator i=begin(); i != end(); i++)
    {
        size_t id = *i;
        ids += wxString::Format("%d ",(int)id);
    }
    wxLogDebug("%s%s", prefix.c_str(), ids.c_str());    // EWDUMPOK
}

wxString
gcIdVec::AsString() const
{
    wxString ids="";
    for(const_iterator i=begin(); i != end(); i++)
    {
        size_t blockId = *i;
        ids += wxString::Format("%d ",(int)blockId);
    }
    return ids;
}
