#include "cmdfileschema.h"
#include "cnv_strings.h"
#include <iostream>

CmdFileSchema::CmdFileSchema()
{
  const bool required = true;
  const bool optional = false;
  const bool onlyone = true;
  const bool many = false;
  AddTag(cnvstr::TAG_CONVERTER_CMD);
  AddAttribute(optional,cnvstr::TAG_CONVERTER_CMD,cnvstr::ATTR_VERSION);
  AddSubtag(optional, onlyone,cnvstr::TAG_CONVERTER_CMD,cnvstr::TAG_TRAITS);
  AddSubtag(optional, onlyone,cnvstr::TAG_CONVERTER_CMD,cnvstr::TAG_REGIONS);
  AddSubtag(optional, onlyone,cnvstr::TAG_CONVERTER_CMD,cnvstr::TAG_POPULATIONS);
  AddSubtag(optional, onlyone,cnvstr::TAG_CONVERTER_CMD,cnvstr::TAG_INDIVIDUALS);
  AddSubtag(optional, onlyone,cnvstr::TAG_CONVERTER_CMD,cnvstr::TAG_INFILES);
  AddSubtag(optional, onlyone,cnvstr::TAG_CONVERTER_CMD,cnvstr::TAG_OUTFILE);
  AddSubtag(optional, onlyone,cnvstr::TAG_CONVERTER_CMD,cnvstr::TAG_ADDCOMMENT);


  AddSubtag(optional, many,   cnvstr::TAG_TRAITS,cnvstr::TAG_TRAIT_INFO);
  AddSubtag(required, onlyone,cnvstr::TAG_TRAIT_INFO,cnvstr::TAG_NAME);
  AddSubtag(required, many,   cnvstr::TAG_TRAIT_INFO,cnvstr::TAG_ALLELE);
  AddSubtag(optional, many,   cnvstr::TAG_TRAITS,cnvstr::TAG_PHENOTYPE);
  AddSubtag(required, onlyone,cnvstr::TAG_PHENOTYPE,cnvstr::TAG_NAME);
  AddSubtag(required, many   ,cnvstr::TAG_PHENOTYPE,cnvstr::TAG_GENO_RESOLUTIONS);
  AddSubtag(required, onlyone,cnvstr::TAG_GENO_RESOLUTIONS,cnvstr::TAG_TRAIT_NAME);
  AddSubtag(required, many,   cnvstr::TAG_GENO_RESOLUTIONS,cnvstr::TAG_HAPLOTYPES);
  AddSubtag(required, onlyone,cnvstr::TAG_HAPLOTYPES,cnvstr::TAG_ALLELES);
  AddSubtag(required, onlyone,cnvstr::TAG_HAPLOTYPES,cnvstr::TAG_PENETRANCE);

  AddSubtag(required, many,cnvstr::TAG_REGIONS,cnvstr::TAG_REGION);

  AddSubtag(required, onlyone,cnvstr::TAG_REGION,cnvstr::TAG_NAME);
  AddSubtag(optional, onlyone,cnvstr::TAG_REGION,cnvstr::TAG_EFFECTIVE_POPSIZE);
  AddSubtag(required, onlyone,cnvstr::TAG_REGION,cnvstr::TAG_SEGMENTS);

  AddSubtag(optional, many,   cnvstr::TAG_REGION,cnvstr::TAG_TRAIT_LOCATION);
  AddSubtag(required, onlyone,cnvstr::TAG_TRAIT_LOCATION,cnvstr::TAG_TRAIT_NAME);

  AddSubtag(required, many,cnvstr::TAG_SEGMENTS,cnvstr::TAG_SEGMENT);

  AddAttribute(required,cnvstr::TAG_SEGMENT,cnvstr::ATTR_DATATYPE);
  AddAttribute(optional,cnvstr::TAG_SEGMENT,cnvstr::ATTR_PROXIMITY);
  AddSubtag(required, onlyone,cnvstr::TAG_SEGMENT,cnvstr::TAG_NAME);
  AddSubtag(required, onlyone,cnvstr::TAG_SEGMENT,cnvstr::TAG_MARKERS);
  AddSubtag(optional, onlyone,cnvstr::TAG_SEGMENT,cnvstr::TAG_MAP_POSITION);
  //For SNP data:
  AddSubtag(optional, onlyone,cnvstr::TAG_SEGMENT,cnvstr::TAG_SCANNED_LENGTH);
  AddSubtag(optional, onlyone,cnvstr::TAG_SEGMENT,cnvstr::TAG_SCANNED_DATA_POSITIONS);
  AddSubtag(optional, onlyone,cnvstr::TAG_SEGMENT,cnvstr::TAG_FIRST_POSITION_SCANNED);
  AddSubtag(optional, onlyone,cnvstr::TAG_SEGMENT,cnvstr::TAG_UNRESOLVED_MARKERS);

  AddSubtag(required, many,cnvstr::TAG_POPULATIONS,cnvstr::TAG_POPULATION);

  AddSubtag(optional, many    ,cnvstr::TAG_INDIVIDUALS,cnvstr::TAG_INDIVIDUAL);
  AddSubtag(required, onlyone ,cnvstr::TAG_INDIVIDUAL,cnvstr::TAG_NAME);
  AddSubtag(required, many    ,cnvstr::TAG_INDIVIDUAL,cnvstr::TAG_SAMPLE);
  AddSubtag(required, onlyone ,cnvstr::TAG_SAMPLE,cnvstr::TAG_NAME);
  AddSubtag(optional, many    ,cnvstr::TAG_INDIVIDUAL,cnvstr::TAG_PHASE);
  AddSubtag(required, onlyone ,cnvstr::TAG_PHASE,cnvstr::TAG_SEGMENT_NAME);
  AddSubtag(required, onlyone ,cnvstr::TAG_PHASE,cnvstr::TAG_UNRESOLVED_MARKERS);
  AddSubtag(optional, many    ,cnvstr::TAG_INDIVIDUAL,cnvstr::TAG_HAS_PHENOTYPE);
  AddSubtag(optional, many    ,cnvstr::TAG_INDIVIDUAL,cnvstr::TAG_GENO_RESOLUTIONS);

  AddSubtag(required, many,cnvstr::TAG_INFILES,cnvstr::TAG_INFILE);
  AddAttribute(required,cnvstr::TAG_INFILE,cnvstr::ATTR_DATATYPE);
  AddAttribute(required,cnvstr::TAG_INFILE,cnvstr::ATTR_FORMAT);
  AddAttribute(required,cnvstr::TAG_INFILE,cnvstr::ATTR_SEQUENCEALIGNMENT);
  AddSubtag(required, onlyone,cnvstr::TAG_INFILE,cnvstr::TAG_NAME);
  AddSubtag(required, onlyone,cnvstr::TAG_INFILE,cnvstr::TAG_SEGMENTS_MATCHING);
  AddSubtag(required, onlyone,cnvstr::TAG_INFILE,cnvstr::TAG_POP_MATCHING);
  AddSubtag(optional, onlyone,cnvstr::TAG_INFILE,cnvstr::TAG_INDIVIDUALS_FROM_SAMPLES);
  AddAttribute(required,cnvstr::TAG_INDIVIDUALS_FROM_SAMPLES,cnvstr::ATTR_TYPE);

  AddAttribute(required,cnvstr::TAG_SEGMENTS_MATCHING,cnvstr::ATTR_TYPE);
  AddAttribute(required,cnvstr::TAG_POP_MATCHING,cnvstr::ATTR_TYPE);

  AddSubtag(optional, many,cnvstr::TAG_SEGMENTS_MATCHING,cnvstr::TAG_SEGMENT_NAME);
  AddSubtag(optional, many,cnvstr::TAG_POP_MATCHING,cnvstr::TAG_POP_NAME);


}

CmdFileSchema::~CmdFileSchema()
{
}

void
CmdFileSchema::AddAttribute(bool required, wxString tagName, wxString attrName)
{
    ParseTreeSchema::AddAttribute(required,tagName.c_str(),attrName.c_str());
}


void
CmdFileSchema::AddTag(wxString tag)
{
    ParseTreeSchema::AddTag(tag.c_str());
}

void
CmdFileSchema::AddSubtag(bool required, bool onlyOne, wxString parentTag, wxString childTag)
{
    ParseTreeSchema::AddSubtag(required,onlyOne,parentTag.c_str(),childTag.c_str());
}
