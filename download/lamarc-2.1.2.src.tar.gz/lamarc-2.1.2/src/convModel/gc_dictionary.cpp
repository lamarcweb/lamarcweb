#include "gc_dictionary.h"
#include "gc_strings.h" // EWFIX.P4 -- move to own file ?
#include "gc_structures_err.h"

gcDictionary::gcDictionary()
{
}

gcDictionary::~gcDictionary()
{
}


bool
gcDictionary::HasName(const wxString & name) const
{
    return (! (find(name) == end()) );
}

void
gcDictionary::ReserveName(const wxString & name)
{
    if(!name.IsEmpty())
    {
        if(HasName(name))
        {
            duplicate_name_error e(name,infoString());
            throw e;
        }
        insert(name);
    }
    else
    {
        empty_name_error e(infoString());
        throw e;
    }
}

void
gcDictionary::FreeName(const wxString & name)
{
    if(!name.IsEmpty())
    {
        iterator nameIter = find(name);
        if(nameIter == end())
        {
            missing_name_error e(name,infoString());
            throw e;
        }
        erase(nameIter);
    }
    else
    {
        empty_name_error e(infoString());
        throw e;
    }
}

wxString
gcDictionary::ReserveOrMakeName(wxString name,
                                wxString prefixToUseIfNameEmpty)
{
    if(!name.IsEmpty())
    {
        ReserveName(name);
        return name;
    }
    wxString prefix = prefixToUseIfNameEmpty;
    if(prefix.IsEmpty())
    {
        prefix = gcstr::object;
    }
    for(int i=0; true; i++)
    {
        wxString nameCandidate = wxString::Format(gcstr::nameCandidate,prefix.c_str(),i);
        try
        {
            ReserveName(nameCandidate);
            return nameCandidate;
        }
        catch(duplicate_name_error& e)
        {
            // do nothing -- we just keep trying
        }
        catch(empty_name_error& f)
        {
            // do nothing -- we just keep trying
        }
    }
    assert(false);
    return gcstr::badName;
}

