#ifndef GC_EXPORTABLE_H
#define GC_EXPORTABLE_H

#include <map>
#include <vector>

class GCIndividual;
class GCPopulation;
class gcRegion;

class gcPopRegionPair : public std::pair<const GCPopulation *, const gcRegion *>
{
    public:
        gcPopRegionPair(const GCPopulation *, const gcRegion *);
        virtual ~gcPopRegionPair();
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcNameResolvedInfo
{
    private:
        const GCPopulation &        m_populationRef;
        const gcRegion &            m_regionRef;
        std::vector<GCIndividual*>  m_individuals;
    public:
        gcNameResolvedInfo(const GCPopulation &, const gcRegion &);
        virtual ~gcNameResolvedInfo();

        void                                AddIndividual(GCIndividual*);
        const GCPopulation &                GetPopRef() const;
        const gcRegion &                    GetRegionRef() const;
        std::vector<const GCIndividual*>    GetIndividuals() const;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

class gcExportable : public std::map<gcPopRegionPair,gcNameResolvedInfo *>
{
    public:
        gcExportable();
        ~gcExportable();
        const gcNameResolvedInfo &  GetInfo(const GCPopulation &, const gcRegion &) const;
        void DebugDump(wxString prefix=wxEmptyString) const;
};

#endif
// GC_EXPORTABLE_H
