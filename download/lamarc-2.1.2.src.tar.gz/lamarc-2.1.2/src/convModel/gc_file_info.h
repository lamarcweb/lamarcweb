#ifndef GC_FILE_INFO_H
#define GC_FILE_INFO_H

#include <list>
#include <map>
#include <set>

#include "gc_locus.h"
#include "gc_population.h"
#include "gc_quantum.h"
#include "gc_region.h"
#include "gc_trait.h"

#include "gc_loci_match.h"
#include "gc_pop_match.h"

#include "wx/string.h"


class gcFileInfo
{
    private:
        bool            m_selected;
        bool            m_hasParse;
        size_t          m_parseId;
        GCPopMatcher    m_popMatch;
        GCLocusMatcher  m_locMatch;
        bool            m_hasAdjacentHapAssignment;
        size_t          m_adjacentHapAssignment;
        bool            m_hasGenoFile;
        size_t          m_genoFileId;
    public:
        gcFileInfo();
        virtual ~gcFileInfo()               ;
        bool    GetSelected() const         ;
        bool    HasParse() const            ;
        size_t  GetParse() const            ;
        void    SetSelected(bool selected)  ;
        void    SetParse(size_t parseId)    ;
        void    UnsetParse()                ;
        void    DebugDump(wxString prefix=wxEmptyString) const;

        bool    HasAdjacentHapAssignment()  const ;
        size_t  GetAdjacentHapAssignment()  const;
        void    SetAdjacentHapAssignment(size_t numAdj);
        void    UnsetAdjacentHapAssignment();

        bool    HasGenoFile() const;
        void    UnsetGenoFile();

        const GCPopMatcher &    GetPopMatcher() const;
        const GCLocusMatcher &  GetLocMatcher() const;
        void    SetPopMatcher(const GCPopMatcher & p);
        void    SetLocMatcher(const GCLocusMatcher & l);
};

class gcFileMap : public std::map<size_t,gcFileInfo>
{
    public:
        gcFileMap() ;
        virtual ~gcFileMap() ;
        void DebugDump(wxString prefix=wxEmptyString) const;
};


#endif
//GC_FILE_INFO_H
