#ifndef GC_STRUCTURES_H
#define GC_STRUCTURES_H

#include "gc_dictionary.h"
#include "gc_file_info.h"
#include "gc_locus.h"
#include "gc_phase_info.h"
#include "gc_population.h"
#include "gc_structure_maps.h"
#include "gc_region.h"
#include "gc_trait.h"
#include "wx/string.h"
#include <set>
#include <map>
#include <vector>

class gcTraitAllele;

class gcNameSet : public gcDictionary
{
    protected:
        virtual const wxString &    infoString() const;
    public:
        gcNameSet();
        virtual ~gcNameSet();
};

class gcTraitNameSet : public gcDictionary
{
    protected:
        virtual const wxString &    infoString() const;
    public:
        gcTraitNameSet();
        virtual ~gcTraitNameSet();
};



class GCStructures
{
    private:
        const GCDataStore * m_dataStoreP;
        gcNameSet           m_names;
        gcTraitNameSet      m_traitNames;
        gcBlockSetMap       m_blocks;
        gcRegionMap         m_regions;
        gcLocusMap          m_loci;
        gcPopMap            m_pops;
        gcTraitMap          m_traitClasses;
        gcAlleleMap         m_alleles;
        gcPhenoMap          m_phenotypes;
        gcFileMap           m_files;


        gcDisplayOrder  m_popDisplay;
        gcDisplayOrder  m_regionDisplay;

    protected:
        bool                HaveBlocksForRegion(size_t regionId) const;
        bool                HaveBlocksForLocus(size_t locusId) const;
        bool                HaveBlocksForPop(size_t popId) const;
        bool                IsBlessedRegion(size_t locusId) const;
        bool                IsBlessedLocus(size_t locusId) const;
        bool                IsBlessedPop(size_t popId) const;

    public:
        GCStructures(const GCDataStore *);
        ~GCStructures();

        bool AnyZeroes() const;


        void AssignBlockToPop(size_t blockId, size_t popId);
        void AssignBlockToLocus(size_t blockId, size_t locusId);

        void AssignBlock(size_t blockId, size_t popId, size_t locusId);
        void AssignLocus(size_t locusId, size_t regionId);
        void AssignTrait(size_t traitId, size_t regionId);

        void AssignAllele(gcTraitAllele &, GCTraitInfo &);
        void AssignLocus(gcLocus &, gcRegion &);
        void AssignPhenotype(gcPhenotype &, GCTraitInfo &);
        void AssignTrait(GCTraitInfo &, gcRegion &);

        void RemoveBlockAssignment(size_t blockId);


        void DebugDump(wxString prefix=wxEmptyString) const;

        gcIdSet     GetBlockIds(size_t popId, size_t locusId) const;
        gcIdSet     GetBlocksForLocus(size_t locusId) const;

        gcDisplayOrder  GetDisplayableLocusIds() const;
        gcDisplayOrder  GetDisplayablePopIds() const;
        gcDisplayOrder  GetDisplayableRegionIds() const;

        objVector   GetDisplayableRegions() ;                 
        objVector   GetDisplayableLoci() ;                 
        objVector   GetDisplayableLociFor(size_t regionId) ;                 
        objVector   GetDisplayablePops() ;                 

        constObjVector  GetConstDisplayableRegions()   const;                 
        constObjVector  GetConstDisplayableLoci()     const;                 
        /*
        constObjVector  GetConstDisplayableLociFor(size_t regionId) const ;                 
        */
        constObjVector  GetConstDisplayableLociInMapOrderFor(size_t regionId) const ;                 
        constObjVector  GetConstDisplayableLinkedLociInMapOrderFor(size_t regionId) const ;                 
        constObjVector  GetConstDisplayablePops()     const;                 

        constObjVector  GetConstTraits() const;

        gcIdVec         GetLocusIdsForRegionByCreation(size_t regionId) const;
        gcIdVec         GetLocusIdsForRegionByMapPosition(size_t regionId) const;

        gcTraitAllele &     GetAllele(size_t id);
        gcRegion &          GetRegion(size_t id);
        gcLocus &           GetLocus(size_t id);
        gcPhenotype &       GetPhenotype(size_t id);
        GCPopulation &      GetPop(size_t id);
        GCTraitInfo &       GetTrait(size_t id);

        const gcTraitAllele &   GetAllele(size_t id) const;
        const gcRegion &        GetRegion(size_t id) const;
        const gcLocus &         GetLocus(size_t id) const;
        const gcPhenotype &     GetPhenotype(size_t id) const;
        const GCPopulation &    GetPop(size_t id) const;
        const GCTraitInfo &     GetTrait(size_t id) const;

        gcTraitAllele &             GetAllele(GCTraitInfo&,wxString name);
        gcTraitAllele &             GetAllele(wxString name);
        gcRegion &                  GetRegion(wxString name);
        gcLocus &                   GetLocus(gcRegion&,wxString name);
        gcLocus &                   GetLocus(wxString name);
        gcPhenotype &               GetPhenotype(wxString name);
        GCPopulation &              GetPop(wxString name);
        GCTraitInfo &               GetTrait(wxString name);

        const gcTraitAllele &       GetAllele(wxString name) const;
        const gcRegion &            GetRegion(wxString name) const;
        const gcLocus &             GetLocus(wxString name) const;
        const gcPhenotype &         GetPhenotype(wxString name) const;
        const GCPopulation &        GetPop(wxString name) const;
        const GCTraitInfo &         GetTrait(wxString name) const;

        const GCPopMatcher &        GetPopMatcher(const GCFile&) const;
        const GCLocusMatcher &      GetLocusMatcher(const GCFile&) const;
        void                        SetPopMatcher(const GCFile&, const GCPopMatcher &);
        void                        SetLocusMatcher(const GCFile&, const GCLocusMatcher &);

        const gcPhenoMap &          GetPhenotypeMap() const;

        bool                    HasAllele(wxString name) const;
        bool                    HasLocus(wxString name) const;
        bool                    HasPop(wxString name) const;
        bool                    HasRegion(wxString name) const;
        bool                    HasTrait(wxString name) const;

        long GetPopDisplayIndexOf(size_t popId) const;
        long GetLocusDisplayIndexOf(size_t locusId) const;

        size_t              GetPopForBlock(size_t blockId) const;
        size_t              GetLocusForBlock(size_t blockId) const;

        gcTraitAllele & FetchOrMakeAllele(GCTraitInfo&, wxString name);
        gcLocus &       FetchOrMakeLocus(gcRegion&, wxString name);
        //gcPhenotype &   FetchOrMakePhenotype();
        GCPopulation &  FetchOrMakePop(wxString name);
        gcRegion &      FetchOrMakeRegion(wxString name);
        GCTraitInfo &   FetchOrMakeTrait(wxString name);

        gcTraitAllele & MakeAllele(wxString name);
        gcRegion &      MakeRegion(wxString name=wxEmptyString,bool blessed=false);
        gcLocus &       MakeLocus(size_t regionId, wxString name=wxEmptyString, bool blessed=false);
        gcLocus &       MakeLocus(gcRegion &, wxString name=wxEmptyString, bool blessed=false);
        gcPhenotype &   MakePhenotype(wxString name=wxEmptyString);
        GCPopulation &  MakePop(wxString name=wxEmptyString, bool blessed=false);
        GCTraitInfo &   MakeTrait(wxString name);

        void Rename(GCQuantum & object, wxString newName);

        bool RegionHasAnyLinkedLoci(size_t regionId) const;
        bool RegionHasAnyUnLinkedLoci(size_t regionId) const;


        void MergeLoci(gcIdVec locusIds);
        void MergePops(gcIdVec popIds);
        void MergeRegions(gcIdVec regionIds);

        void RemoveBlocks(gcIdSet blockIds);
        void RemoveBlocksForLocus(size_t locusId);
        void RemoveBlocksForPop(size_t popId);
        void RemoveRegion(gcRegion & region);
        void RemoveLocus(gcLocus & locus);
        void RemovePop(GCPopulation & pop);
        void RemoveRegions(objVector regions);
        void RemoveLoci(objVector loci);
        void RemovePops(objVector pops);
        void RemoveFile(size_t fileId);

        bool    GetFileSelection(size_t fileId) const;
        void    SetFileSelection(size_t fileId, bool selected);
        size_t  SelectedFileCount() const;
        void    AllFileSelectionsTo(bool selectValue);



        void AddFile(const GCFile &);
        bool HasUnparsedFiles() const;

        void SetParse(const GCParse & parse);
        void UnsetParse(const GCParse & parse);

        bool            HasParse(const GCFile &) const;
        const GCParse & GetParse(const GCFile &) const;
        const GCParse & GetParse(size_t fileId ) const;

        void    SetHapFileAdjacent( size_t fileId, size_t numHaps);
        bool    HasHapFileAdjacent(size_t fileId) const;
        size_t  GetHapFileAdjacent(size_t fileId) const;
        void    UnsetHapFileAdjacent(size_t fileId);

        bool    HasGenoFile(size_t fileId) const;
        void    UnsetGenoFile(size_t fileId);

        void    VerifyLocusSeparations(const gcRegion&) const;    // throws if not separated
};
#endif
//GC_STRUCTURES_H
