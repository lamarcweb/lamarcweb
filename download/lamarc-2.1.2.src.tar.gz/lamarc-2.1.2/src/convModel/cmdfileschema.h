//$Id: cmdfileschema.h,v 1.2 2006/06/12 17:16:56 ewalkup Exp $

#ifndef CMDFILESCHEMA_H
#define CMDFILESCHEMA_H

/* 
 Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

 This software is distributed free of charge for non-commercial use
 and is copyrighted.  Of course, we do not guarantee that the software
 works, and are not responsible for any damage you may cause or have.
*/

#include "parsetreeschema.h"
#include "wx/string.h"

class CmdFileSchema : public ParseTreeSchema
    // specialization of ParseTreeSchema to apply to command
    // files used for batch version of converter
{
    private:
    protected:
            // these methods allow us to pass wxStrings in as
            // arguments instead of std::string
        void AddTag(wxString tag);
        void AddAttribute(bool required,
                        wxString tagName,
                        wxString attrName);
        void AddSubtag(bool required, bool onlyOne, 
                        wxString parentTag,
                        wxString childTag);
    public:
        CmdFileSchema();            // modify this method to update schema
        virtual ~CmdFileSchema();
};

#endif /* CMDFILESCHEMA_H */
