#ifndef GC_FRAME_H
#define GC_FRAME_H

#include "wx/wx.h"

class wxSplitterWindow;
class GCLogic;
class gcInfoPane ;

class GCFrame : public wxFrame
    // outer-most frame in the converter application
{
    private:
        GCLogic         &   m_logic;    // interface with back end storage

        wxSplitterWindow    *   m_logSplitter;
        wxSplitterWindow    *   m_mainWindow;
        wxPanel             *   m_logPanel;
        wxTextCtrl          *   m_logText;
        wxLog               *   m_oldLog;

        gcInfoPane          *   m_filePanel;
        gcInfoPane          *   m_gridPanel;

        wxMenu          *   m_fileMenu;
        wxMenu          *   m_insertMenu;
        wxMenu          *   m_viewMenu;

        wxMenuItem      *   m_verbose;


        void DispatchDataEvent              (wxCommandEvent& event);
        void DispatchMenuEvent              (wxCommandEvent& event);
        void DispatchScreenEvent            (wxCommandEvent& event);

        void SetUpMenus                     ();
        void EnableMenus                    ();

    protected:

    public:
        GCFrame();
        GCFrame(const wxString& title, GCLogic & logic);
        virtual ~GCFrame();


        void UpdateUserCues                 ();

        DECLARE_EVENT_TABLE()


};

#endif
// GC_FRAME_H
