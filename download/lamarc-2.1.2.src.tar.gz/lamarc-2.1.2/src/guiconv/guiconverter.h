#ifndef GUICONVERTER_H
#define GUICONVERTER_H

#include "wx/wx.h"
#include "gc_cmdline.h"
#include "gc_logic.h"

class wxCmdLineParser;
class GCFrame;

class GuiConverterApp: public wxApp, public GCCmdLineManager
    // main gui converter application
{
    protected:
        GCLogic         m_logic;
        GCFrame     *   m_mainFrame;

    public:
        GuiConverterApp();
        virtual ~GuiConverterApp();

        virtual bool    OnCmdLineParsed(wxCmdLineParser&);
        virtual int     OnExit();
        virtual bool    OnInit();
        virtual void    OnInitCmdLine(wxCmdLineParser&);
        virtual int     OnRun();
};

#endif
// GUICONVERTER_H
