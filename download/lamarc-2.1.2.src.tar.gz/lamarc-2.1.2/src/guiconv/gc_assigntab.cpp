
#include "gc_assigntab.h"
#include "gc_block_dialogs.h"
#include "gc_clickpanel.h"
#include "gc_data_display.h"
#include "gc_default.h"
#include "gc_event_publisher.h"
#include "gc_file_list.h"   // EWFIX.P3 for GCExclaimBitmap
#include "gc_locus_dialogs.h"
#include "gc_logic.h"
#include "gc_parse_block.h"
#include "gc_population_dialogs.h"
#include "gc_region_dialogs.h"
#include "gc_strings.h"
#include "gc_strings_region.h"

#include "wx/statline.h"

/////////////////////////////////////////////////////////////////

gcBlockCell::gcBlockCell(wxWindow * parent, const GCParseBlock & blockRef)
    :   gcClickCell(parent,gcstr::dataBlocks),
        m_blockId(blockRef.GetId())
{
    AddText(wxString::Format(gcstr::blockInfo1,
                (int)(blockRef.GetSamples().size()),
                blockRef.GetParse().GetDataTypeString().c_str()));
    AddText(wxString::Format(gcstr::blockInfo2,
                blockRef.GetParse().GetFileRef().GetShortName().c_str()));
    FinishSizing();
}

gcBlockCell::~gcBlockCell()
{
}

void
gcBlockCell::NotifyLeftDClick()
{
    gcEventActor * blockEditActor = new gcActor_BlockEdit(m_blockId);
    PublishScreenEvent(GetEventHandler(),blockEditActor);
}

/////////////////////////////////////////////////////////////////

gcPopCell::gcPopCell(wxWindow * parent, const GCPopulation & popRef)
    :   gcClickCell(parent,gcstr::population),
        m_popId(popRef.GetId())
{
    AddText(wxString::Format(gcstr::popLabelName,popRef.GetName().c_str()));
    FinishSizing();
}

gcPopCell::~gcPopCell()
{
}

void
gcPopCell::NotifyLeftDClick()
{
    gcEventActor * popEditActor = new gcActor_Pop_Edit(m_popId);
    PublishScreenEvent(GetEventHandler(),popEditActor);
}

/////////////////////////////////////////////////////////////////

gcRegionCell::gcRegionCell(wxWindow * parent, const gcRegion & regRef)
    :   gcClickCell(parent,gcstr::region),
        m_regionId(regRef.GetId())
{
    AddText(wxString::Format(gcstr::regionLabelName,regRef.GetName().c_str()));
    if(regRef.HasEffectivePopulationSize())
    {
        AddText(wxString::Format(gcstr_region::effPopSize,regRef.GetEffectivePopulationSize()));
    }
    FinishSizing();
}

gcRegionCell::~gcRegionCell()
{
}

void
gcRegionCell::NotifyLeftDClick()
{
    gcEventActor * regionEditActor = new gcActor_RegionEdit(m_regionId);
    PublishScreenEvent(GetEventHandler(),regionEditActor);
}

/////////////////////////////////////////////////////////////////


gcLocusCell::gcLocusCell(wxWindow * parent, const gcLocus & locusRef)
    :   gcClickCell(parent,locusRef.GetLinked() ? gcstr::locus : gcstr::locusUnlinked),
        m_locusId(locusRef.GetId())
{
    AddText(wxString::Format(gcstr::locusLabelName,locusRef.GetName().c_str()));
    AddText(wxString::Format(gcstr::locusLabelDataType,locusRef.GetDataTypeString().c_str()));
    AddText(wxString::Format(gcstr::locusLabelSites,locusRef.GetNumMarkersString().c_str()));

    FinishSizing();
}

gcLocusCell::~gcLocusCell()
{
}

void
gcLocusCell::NotifyLeftDClick()
{
    gcEventActor * locusEditActor = new gcActor_LocusEdit(m_locusId);
    PublishScreenEvent(GetEventHandler(),locusEditActor);
}

/////////////////////////////////////////////////////////////////

wxPanel *
GCAssignmentTab::blockControl(wxWindow * window, constBlockVector & blocks)
{
    wxPanel * unitPanel = new wxPanel(window);
    if(blocks.empty())
    {
        wxBoxSizer * statBox = new wxBoxSizer(wxHORIZONTAL);
        statBox->AddStretchSpacer(1);
        statBox->Add(new wxStaticBitmap(unitPanel,-1,GCExclaimBitmap::exclBitmap()),0,wxALIGN_CENTRE_VERTICAL);
        statBox->Add(new wxStaticText(unitPanel,-1,gcdefault::emptyBlock),0,wxALIGN_CENTRE_VERTICAL);
        statBox->AddStretchSpacer(1);
        unitPanel->SetSizerAndFit(statBox);
        return unitPanel;
    }
    else
    {
        wxBoxSizer * statBox = new wxBoxSizer(wxVERTICAL);
        for(constBlockVector::const_iterator iter = blocks.begin();
            iter != blocks.end(); iter++)
        {
            const GCParseBlock * blockP = *iter;
            assert(blockP != NULL);
            statBox->Add(new gcBlockCell(unitPanel,*blockP),1,wxEXPAND);
        }
        unitPanel->SetSizerAndFit(statBox);
        return unitPanel;
    }
    assert(false);
    return NULL;
}


GCAssignmentTab::GCAssignmentTab( wxWindow * parent, GCLogic & logic)
    :
        gcInfoPane(parent, logic, gcstr::assignTabTitle)
{
}

GCAssignmentTab::~GCAssignmentTab()
{
}

wxPanel *
GCAssignmentTab::MakeContent()
{

    wxPanel * newPanel = new wxPanel(   m_scrolled,
                                        -1,
                                        wxDefaultPosition,
                                        wxDefaultSize,
                                        wxTAB_TRAVERSAL);
    GCDataDisplaySizer * dds = new GCDataDisplaySizer();
    const GCStructures & st = m_logic.GetStructures();

    size_t popIndex = 0;
    constObjVector popsToDisplay   =   st.GetConstDisplayablePops();
    constObjVector regionsToDisplay =  st.GetConstDisplayableRegions();

    for(    constObjVector::const_iterator piter=popsToDisplay.begin();
            piter != popsToDisplay.end();
            piter++, popIndex++)
    {
        size_t popId = (*piter)->GetId();
        const GCPopulation & pop = st.GetPop(popId);
        dds->AddPop(new gcPopCell(newPanel,pop),popIndex);
    }

    size_t locusIndex = 0;
    for(    constObjVector::const_iterator giter=regionsToDisplay.begin();
            giter != regionsToDisplay.end();
            giter++)
    {
        size_t regionId = (*giter)->GetId();
        const gcRegion & group = st.GetRegion(regionId);
        constObjVector loci = st.GetConstDisplayableLociInMapOrderFor(regionId);

        if(loci.size() == 0)
        {
            dds->AddRegion(new gcRegionCell(newPanel,group),
                        locusIndex,locusIndex);
                            
            locusIndex++;
        }
        else
        {
            if(st.RegionHasAnyLinkedLoci(regionId))
            {
                dds->AddRegion(new gcRegionCell(newPanel,group),
                            locusIndex,locusIndex+loci.size()-1);
            }

            for(constObjVector::const_iterator liter=loci.begin(); liter != loci.end(); liter++)
            {

                size_t locusId = (*liter)->GetId();

                // display locus
                const gcLocus & locus = st.GetLocus(locusId);
                dds->AddLocus(new gcLocusCell(newPanel,locus),locusIndex);

                // display blocks for locus
                popIndex = 0;
                for(constObjVector::const_iterator piter=popsToDisplay.begin();
                    piter != popsToDisplay.end();
                    piter++,popIndex++)
                {
                    size_t popId = (*piter)->GetId();
                    constBlockVector blockVec = m_logic.GetBlocks(popId,locusId);
                    dds->AddData(blockControl(newPanel,blockVec),
                        popIndex,locusIndex);
                }

                locusIndex++;
            }
        }
    }

    newPanel->SetSizerAndFit(dds);
    return newPanel;
}

wxString
GCAssignmentTab::MakeLabel()
{
    return m_panelLabelFmt;
}
