#ifndef GC_ASSIGNTAB_H
#define GC_ASSIGNTAB_H

#include "gc_clickpanel.h"
#include "gc_gridpanel.h"

class wxPanel;
class wxWindow;
class constBlockVector;
class gcLocus;
class GCParseBlock;
class GCPopulation;
class gcRegion;
class GCStructures;

class gcBlockCell : public gcClickCell
{
    private:
    protected:
        size_t      m_blockId;
    public:
        gcBlockCell(wxWindow * parent, const GCParseBlock &);
        virtual ~gcBlockCell();
        void NotifyLeftDClick();
};

class gcPopCell : public gcClickCell
{
    private:
    protected:
        size_t      m_popId;
    public:
        gcPopCell(wxWindow * parent, const GCPopulation &);
        virtual ~gcPopCell();

        void    NotifyLeftDClick();
};

class gcRegionCell : public gcClickCell
{
    private:
    protected:
        size_t      m_regionId;
    public:
        gcRegionCell(wxWindow * parent, const gcRegion &);
        virtual ~gcRegionCell();

        void    NotifyLeftDClick();
};

class gcLocusCell : public gcClickCell
{
    private:
    protected:
        size_t      m_locusId;
    public:
        gcLocusCell(wxWindow * parent, const gcLocus &);
        virtual ~gcLocusCell();

        void    NotifyLeftDClick();
};



class GCAssignmentTab : public gcInfoPane
{
    private:
        GCAssignmentTab();        // undefined

    protected:
        wxPanel *   MakeContent();
        wxString    MakeLabel();
        wxPanel *   blockControl(wxWindow *, constBlockVector &);

    public:
        GCAssignmentTab(wxWindow * parent, GCLogic & logic);
        virtual ~GCAssignmentTab();
};


#endif
// GC_ASSIGNTAB_H
