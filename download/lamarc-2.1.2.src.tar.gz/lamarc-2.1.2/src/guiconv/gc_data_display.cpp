#include "gc_data_display.h"
#include "gc_layout.h"
//#include "wx/log.h"

GCDataDisplaySizer::GCDataDisplaySizer()
    : wxGridBagSizer(gclayout::borderSize,gclayout::borderSize)
{
}

GCDataDisplaySizer::~GCDataDisplaySizer()
{
}

void
GCDataDisplaySizer::AddPop(wxWindow * header, size_t popIndex)
{
    Add(header,wxGBPosition(popIndex+2,0),wxDefaultSpan,wxALL | wxEXPAND);
}

void
GCDataDisplaySizer::AddRegion(wxWindow * header, size_t firstLocus, size_t lastLocus)
{
    Add(header,wxGBPosition(0,firstLocus+1),wxGBSpan(1,lastLocus-firstLocus+1),wxALL | wxEXPAND);
}

void
GCDataDisplaySizer::AddLocus(wxWindow * header, size_t locusIndex)
{
    Add(header,wxGBPosition(1,locusIndex+1),wxDefaultSpan,wxALL | wxEXPAND);
}

void 
GCDataDisplaySizer::AddData(wxWindow * header, size_t popIndex, size_t locusIndex)
{
    Add(header,wxGBPosition(popIndex+2,locusIndex+1),wxDefaultSpan,wxALL | wxEXPAND);
}
