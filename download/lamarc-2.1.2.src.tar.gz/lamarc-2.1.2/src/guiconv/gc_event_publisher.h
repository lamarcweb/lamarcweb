#ifndef GC_EVENT_PUBLISHER_H
#define GC_EVENT_PUBLISHER_H

#include <map>

#include "wx/event.h"       // for wxEventType

class GCQuantum;
class gcEventActor;

// defines events signalling a change in values in the 
// datastore. These events are intended to be subscribed
// to by GUI elements which need to update their appearance
// when data changes.
extern const wxEventType DATA_2_SCREEN;
// event table entry capable of dispatching a DATA_2_SCREEN
// event to the method which handles it
#define EVT_D2S(ev,fn) \
    DECLARE_EVENT_TABLE_ENTRY( \
        DATA_2_SCREEN, ev, wxID_ANY, \
        (wxObjectEventFunction)(wxEventFunction)&fn, \
        (wxObject *) NULL \
    ),


// defines events signalling a change created from the GUI
extern const wxEventType SCREEN_2_DATA;
// event table entry capable of dispatching a SCREEN_2_DATA
// event to the method which handles it
#define EVT_S2D(ev,fn) \
    DECLARE_EVENT_TABLE_ENTRY( \
        SCREEN_2_DATA, ev, wxID_ANY, \
        (wxObjectEventFunction)(wxEventFunction)&fn, \
        (wxObject *) NULL \
    ),

void PublishDataEvent(wxEvtHandler*,int eventId);

void PublishScreenEvent(wxEvtHandler*, gcEventActor *);

/*
void PublishScreenEvent(wxEvtHandler*,int eventId);
void PublishScreenEvent(wxEvtHandler*,int eventId,int);
void PublishScreenEvent(wxEvtHandler*,int eventId,wxString);
void PublishScreenEvent(wxEvtHandler*,int eventId,const GCQuantum*);
void PublishScreenEvent(wxEvtHandler*,int eventId,const GCQuantum*,int);
void PublishScreenEvent(wxEvtHandler*,int eventId,const GCQuantum*,wxString);
*/


// we need these so we can build a multimap to represent a
// wxEvtHandler that wants to be notified about events of
// a certain type and id. A complication is that the event
// id (an integer -- second member of the GCEventDescriptor
// pair) can legally be wxID_ANY -- meaning I want to know
// about *all* events of a given type
typedef std::pair<wxEventType,int> GCEventDescriptor;
typedef std::pair<GCEventDescriptor, wxEvtHandler *> GCSubscriberPair;
typedef std::multimap<GCEventDescriptor, wxEvtHandler *> GCSubscriberMap;
typedef GCSubscriberMap::iterator GCSubscriberMapIter;
typedef std::pair<GCSubscriberMapIter,GCSubscriberMapIter> GCSubscriberMapIterPair;



#endif
//GC_EVENT_PUBLISHER_H
