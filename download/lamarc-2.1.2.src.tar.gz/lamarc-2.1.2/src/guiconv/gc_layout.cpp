#include "gc_layout.h"

const long      gclayout::appHeight                  = 800;
const long      gclayout::appHeightPercent           = 90;
const long      gclayout::appWidth                   = 800;
const long      gclayout::appWidthPercent            = 90;
const int       gclayout::borderSize                 = 10;
const int       gclayout::borderSizeNone             = 0;
const int       gclayout::borderSizeSmall            = 4;
const int       gclayout::boxBorderSize              = 2;
const long      gclayout::maxDataFiles               = 3;
const int       gclayout::tabIconHeight              = 32;
const int       gclayout::tabIconWidth               = 32;
const int       gclayout::warningImageNeedsInput     = 0;
const int       gclayout::warningImageOK             = -1;

