#ifndef GC_POPULATION_DIALOGS_H
#define GC_POPULATION_DIALOGS_H

#include "gc_quantum.h"
#include "gc_dialog.h"

class GCDataStore;
class GCPopulation;
class wxWindow;

class gcPopMergeChoice : public gcChoiceObject
{
    private:
        gcPopMergeChoice();         // undefined
        size_t                      m_popId;
        wxCheckBox *                m_box;
    protected:
    public:
        gcPopMergeChoice(size_t popId);
        ~gcPopMergeChoice();

        /*
        wxString    GetLabel(GCDataStore &);
        bool        GetEnabled(GCDataStore &);
        bool        GetSelected(GCDataStore &);
        void        SetSelected(GCDataStore &, bool value);
        */

        void        UpdateDisplayInitial    (GCDataStore &) ;
        void        UpdateDisplayInterim    (GCDataStore &) ;
        void        UpdateDataInterim       (GCDataStore &) ;
        void        UpdateDataFinal         (GCDataStore &) ;

        wxWindow *  MakeWindow(wxWindow * parent);
        wxWindow *  FetchWindow();

        size_t      GetRelevantId();

};

class gcPopMerge : public gcUpdatingChooseMulti
{
    protected:
        size_t          m_popId;
    public:
        gcPopMerge( wxWindow *                      parent,
                    size_t                          popId,
                    std::vector<gcChoiceObject*>    choices);
        virtual ~gcPopMerge();

        void DoFinalForMulti(GCDataStore & dataStore, gcIdVec chosenPops);
        wxString    NoChoicesText() const;
};

class gcPopRename : public gcTextHelper
{
    private:
    protected:
        size_t          m_popId;
    public:
        gcPopRename(size_t popId);
        ~gcPopRename();

        wxString    FromDataStore(GCDataStore &);
        void        ToDataStore(GCDataStore &, wxString newText);
};

class gcPopEditDialog : public gcUpdatingDialog
{
    private:
    protected:
        size_t          m_popId;
        void DoDelete();
    public:
        gcPopEditDialog(wxWindow *      parentWindow,
                        GCDataStore &   dataStore,
                        size_t          popId,
                        bool            forJustCreatedObj);
        virtual ~gcPopEditDialog();
                        

};

bool DoDialogEditPop(   wxWindow *      parentWindow,
                        GCDataStore &   dataStore,
                        size_t          popId,
                        bool            forJustCreatedObj);


class gcActor_PopAdd : public gcEventActor
{
    public:
        gcActor_PopAdd() {};
        virtual ~gcActor_PopAdd() {};
        virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

class gcActor_Pop_Edit : public gcEventActor
{
    private:
        gcActor_Pop_Edit();     // undefined
        size_t                  m_popId;
    public:
        gcActor_Pop_Edit(size_t popId) : m_popId(popId) {};
        virtual ~gcActor_Pop_Edit() {};
        virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

#endif
//GC_POPULATION_DIALOGS_H
