#include "gc_datastore.h"
#include "gc_strings.h"
#include "gc_structures_err.h"
#include "gc_trait_dialogs.h"

#include "wx/textdlg.h"

void
DoDialogAddTrait(wxWindow * parentWindow, GCDataStore & dataStore)
{
    wxString newTraitName 
        = wxGetTextFromUser(gcstr::traitEnterNewName,
                            gcstr::traitEnterNewName,  // EWFIX.P3 LATER
                            wxEmptyString,
                            parentWindow);
    if(!(newTraitName.IsEmpty()))
    {
        try
        {
            dataStore.AddNewTrait(newTraitName);
        }
        catch(const duplicate_name_error& e)
        {
            dataStore.GCInfo(e.what());
        }
    }
}
