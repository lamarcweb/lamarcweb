#include "gc_event_ids.h"
#include "gc_event_publisher.h"
#include "gc_quantum.h"
#include <set>
#include "wx/clntdata.h"
#include "wx/event.h"

const wxEventType DATA_2_SCREEN = wxNewEventType();
const wxEventType SCREEN_2_DATA = wxNewEventType();


void PublishDataEvent(wxEvtHandler* handler,int eventId)
{
    wxCommandEvent myEvent(DATA_2_SCREEN,eventId);
    wxPostEvent(handler,myEvent);
}

/*
void PublishDataEvent(wxEvtHandler* handler,int eventId, const GCQuantum* obj)
{
    wxCommandEvent myEvent(DATA_2_SCREEN,eventId);
    wxClientData * clientP = new GCClientData(obj);
    myEvent.SetClientObject(clientP);
    wxPostEvent(handler,myEvent);
}

void PublishScreenEvent(wxEvtHandler* handler,int eventId)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    wxPostEvent(handler,myEvent);
}

void PublishScreenEvent(wxEvtHandler* handler,int eventId,int intData)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    myEvent.SetInt(intData);
    wxPostEvent(handler,myEvent);
}

void PublishScreenEvent(wxEvtHandler* handler,int eventId,wxString stringData)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    myEvent.SetString(stringData);
    wxPostEvent(handler,myEvent);
}
*/

void PublishScreenEvent(wxEvtHandler* handler, gcEventActor * obj)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,gcEvent_Generic);
    wxClientData * clientP = new GCClientData(obj);
    myEvent.SetClientObject(clientP);
    wxPostEvent(handler,myEvent);
}

/*
void PublishScreenEvent(wxEvtHandler* handler,int eventId, const GCQuantum* obj,int intData)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    wxClientData * clientP = new GCClientData(obj);
    myEvent.SetClientObject(clientP);
    myEvent.SetInt(intData);
    wxPostEvent(handler,myEvent);
}

void PublishScreenEvent(wxEvtHandler* handler,int eventId, const GCQuantum* obj,wxString stringData)
{
    wxCommandEvent myEvent(SCREEN_2_DATA,eventId);
    wxClientData * clientP = new GCClientData(obj);
    myEvent.SetClientObject(clientP);
    myEvent.SetString(stringData);
    wxPostEvent(handler,myEvent);
}
*/



