#include "errhandling.h"
#include "gc_assigntab.h"
#include "gc_data.h"
#include "gc_errhandling.h"
#include "gc_event_ids.h"
#include "gc_event_publisher.h"
#include "gc_file_list.h"
#include "gc_frame.h"
#include "gc_layout.h"
#include "gc_file_dialogs.h"
#include "gc_loci_match.h"
#include "gc_locus_dialogs.h"
#include "gc_logic.h"
#include "gc_menu_actors.h"
#include "gc_pop_match.h"
#include "gc_population_dialogs.h"
#include "gc_region_dialogs.h"
#include "gc_strings.h"

#include "wx/artprov.h"
#include "wx/imaglist.h"
#include "wx/log.h"
#include "wx/sizer.h"
#include "wx/splitter.h"
#include "wx/textctrl.h"


// events the bottom level construct should respond to
BEGIN_EVENT_TABLE(GCFrame,wxFrame)
    EVT_MENU        (wxID_ANY,              GCFrame::DispatchMenuEvent)
    EVT_D2S         (wxID_ANY,              GCFrame::DispatchDataEvent)
    EVT_S2D         (wxID_ANY,              GCFrame::DispatchScreenEvent)
END_EVENT_TABLE()

void
GCFrame::EnableMenus()
{


    ///////////////////
    m_fileMenu->Enable( gcEvent_File_Export, true);     // EWFIX.P3 -- disable when not exportable
    m_fileMenu->Enable( gcEvent_Batch_Export, true);    // EWFIX.P3 -- disable when not exportable

    m_verbose->Check(wxLog::GetVerbose());

}

void 
GCFrame::SetUpMenus()
{

    // Setting up menu items within File Menu
    m_fileMenu = new wxMenu;
    m_fileMenu->Append( gcEvent_File_Add,       "Read &Data File\tCTRL-O");
    m_fileMenu->Append( gcEvent_CmdFile_Read,   "Read &Command File\tCTRL+SHIFT-O");
    m_fileMenu->AppendSeparator();              //////////////////////////
    m_fileMenu->Append( gcEvent_File_Export,    "Write &Lamarc File\tCTRL-L");
    m_fileMenu->Append( gcEvent_Batch_Export,   "Write &Batch Command File (alpha test -- use with caution)\tCTRL-B");
    m_fileMenu->AppendSeparator();              //////////////////////////
    m_fileMenu->Append( wxID_EXIT,              "&Quit" );

    m_insertMenu    = new wxMenu;
    m_insertMenu->Append( gcEvent_LinkG_Add,    "New &Region");
    m_insertMenu->Append( gcEvent_Locus_Add,    "New &Segment");
    m_insertMenu->Append( gcEvent_Pop_Add,      "New &Population");

    m_viewMenu      = new wxMenu;
    m_verbose = m_viewMenu->AppendCheckItem(    gcEvent_ToggleVerbose, "&Log Verbosely");
    m_verbose->Check(wxLog::GetVerbose());

    // Setting up menu items within Help menu
    wxMenu * GCHelpMenu = new wxMenu;
    GCHelpMenu->Append( wxID_ABOUT,         "&About..." );

    // Setting up menu items within Debug menu
    wxMenu * GCDebugMenu = new wxMenu;
    GCDebugMenu->Append(gcEvent_Debug_Dump, "&Dump" );


    // Placing top-level items on Menu Bar
    wxMenuBar *GCMenuBar = new wxMenuBar;
    GCMenuBar->Append( m_fileMenu,      "&File" );
    GCMenuBar->Append( m_insertMenu,    "&Insert" );
    GCMenuBar->Append( m_viewMenu,      "&View" );
    GCMenuBar->Append( GCHelpMenu,      "&Help" );
#ifndef NDEBUG
    GCMenuBar->Append( GCDebugMenu,     "&Debug" );
#endif

    EnableMenus();

    // Installing Menu Bar
    SetMenuBar( GCMenuBar );
}



GCFrame::GCFrame(   const wxString& title, GCLogic & logic)
    :   wxFrame(    NULL,
                    -1,
                    title,
                    wxDefaultPosition,
                    wxDefaultSize,
                    wxTAB_TRAVERSAL | wxDEFAULT_FRAME_STYLE
                ),
        m_logic(logic),
        m_logSplitter(NULL),
        m_mainWindow(NULL),
        m_logPanel(NULL),
        m_logText(NULL),
        m_filePanel(NULL),
        m_gridPanel(NULL),
        m_fileMenu(NULL),
        m_insertMenu(NULL),
        m_viewMenu(NULL)
{


    m_logSplitter= new wxSplitterWindow(this,-1);
    m_mainWindow = new wxSplitterWindow(m_logSplitter,-1);
    m_logPanel = new wxPanel(m_logSplitter,-1);

    m_logText   = new wxTextCtrl(m_logPanel,wxID_ANY,wxEmptyString,
                                    wxDefaultPosition,wxDefaultSize,
                                    wxTE_MULTILINE);
    m_logText->SetEditable(false);
    m_oldLog = wxLog::SetActiveTarget(new wxLogTextCtrl(m_logText));
    wxLogMessage(gcstr::logWindowHeader);

    wxBoxSizer * pSizer = new wxBoxSizer(wxVERTICAL);
    m_logPanel->SetSizer(pSizer);
    pSizer->Add(m_logText,1,wxEXPAND);

    m_filePanel = new GCFileList(m_mainWindow,m_logic);
    m_gridPanel = new GCAssignmentTab(m_mainWindow,m_logic);

    m_logSplitter->SplitHorizontally(m_mainWindow,m_logPanel,-100);
    m_mainWindow->SplitHorizontally(m_filePanel,m_gridPanel);

    SetUpMenus();
    UpdateUserCues();
    UpdateUserCues();
}

GCFrame::~GCFrame()
{
}


void
GCFrame::UpdateUserCues()
{
    m_filePanel->UpdateUserCues();
    m_gridPanel->UpdateUserCues();

    EnableMenus();
    Layout();

}

void
GCFrame::DispatchMenuEvent( wxCommandEvent& event)
    // wxWidgets can be a little tempermental about performing
    // time-consuming actions while in the middle of dispatching
    // a menu or control event. To overcome this, issuing a menu
    // command dispatches a home-grown event. We will get these
    // events after the menu display portion is done.
{
    gcEventActor * actor = NULL;
    switch(event.GetId())
        // stuff handled in the non-default changes the frame
        // (this object) but not the datastore
    {
        case wxID_EXIT:
            Close(TRUE);
            break;
        default:
            actor = MakeMenuActor(event.GetId());
            PublishScreenEvent(GetEventHandler(),actor);
    }
    UpdateUserCues();
}

void
GCFrame::DispatchDataEvent( wxCommandEvent& event)
{
    switch(event.GetId())
    {
        case D2S_UserInteractionPhaseEnd:
            // EWFIX.P3 UNDO -- insert undo/redo phase here, not inside UpdateUserCues
            UpdateUserCues();
            break;
        default:
            m_logic.GCWarning("unimplemented data event");
            assert(false);
            break;
    }
    
}



void
GCFrame::DispatchScreenEvent(wxCommandEvent& event)
{
    try
    {
        wxClientData * cd = event.GetClientObject();
        GCClientData * gc = dynamic_cast<GCClientData*>(cd);
        assert(gc != NULL);


        GCLogic logicCopy(m_logic);
        gcEventActor * actor = gc->GetActor();

        bool takeResult = false;
        try
        {
            takeResult = actor->OperateOn(this,m_logic);
        }
        catch(const gc_data_error& e)
        {
            // EWFIX.P4 -- add wrapper
            m_logic.GCWarning(e.what());
        }
        catch(const incorrect_xml& g)
        {
            // EWFIX.P4 -- add wrapper
            m_logic.GCWarning(g.what());
        }
        catch(const gc_implementation_error& f)
        {
            // EWFIX.P4 -- add wrapper
            m_logic.GCWarning(f.what());
        }

        if(!takeResult)
        {
            m_logic = logicCopy;
        }

        delete gc;  // EWFIX.P4 -- hate that we have to do this
    }
    catch (const gc_data_error& e)
    {
        m_logic.GCFatal(wxString("uncaught data error: ")+e.what());
    }
    catch (const gc_implementation_error& e)
    {
        m_logic.GCFatalUnlessDebug(wxString("implementation error: ")+e.what());
    }
    catch (const gc_ex& e)
    {
        m_logic.GCFatal(wxString("gc exception: ")+e.what());
    }
    catch (const std::exception& e)
    {
        m_logic.GCFatal(wxString("unexpected exception: ")+e.what());
    }
    // each of the above method calls might result in the publishing
    // of one or more DATA_2_SCREEN events. We now publish this event
    // to indicate that we've finished publishing all the events
    // for a single user action
    PublishDataEvent(GetEventHandler(),D2S_UserInteractionPhaseEnd);
}
