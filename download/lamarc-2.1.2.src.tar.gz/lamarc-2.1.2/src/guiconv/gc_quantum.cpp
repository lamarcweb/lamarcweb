#include "gc_default.h"
#include "gc_quantum.h"
#include "wx/log.h"

size_t GCQuantum::s_objCount = 0;

GCQuantum::GCQuantum()
    :
        m_objId(s_objCount++),
        m_name(gcdefault::unnamedObject),
        m_selected(false)
{
}

/*
GCQuantum::GCQuantum(wxString name)
    :
        m_objId(s_objCount++),
        m_name(name),
        m_selected(false)
{
}
*/

GCQuantum::~GCQuantum()
{
}

size_t
GCQuantum::GetId() const
{
    return m_objId;
}

/*
bool
GCQuantum::GetSelected() const
{
    return m_selected;
}

void
GCQuantum::SetSelected(bool selected)
{
    m_selected=selected;
}
*/

void
GCQuantum::DebugDump(wxString prefix) const
{
    wxLogDebug("%sid:%d",prefix.c_str(),(int)m_objId);  // EWDUMPOK
}

wxString
GCQuantum::GetName() const
{
    return m_name;
}

void
GCQuantum::SetName(wxString name)
{
    m_name = name;
}

void
GCQuantum::ReportMax()
{
    wxLogDebug("created %d numbered objects",(int)s_objCount);  // EWDUMPOK
}

//////////////////////////////////////////


GCClientData::GCClientData(gcEventActor * myActor)
    :   m_myActor(myActor)
{
}

GCClientData::~GCClientData()
{
    delete m_myActor;
}

gcEventActor *
GCClientData::GetActor()
{
    return m_myActor;
}

