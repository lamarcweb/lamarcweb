#include "gc_dialog.h"
#include "gc_logic.h"
#include "gc_strings.h"

#include "wx/string.h"
#include "wx/utils.h"

#include <vector>

GCLogic::GCLogic()
    : m_displayParent(NULL)
{
}

GCLogic::~GCLogic()
{
}

void
GCLogic::SetDisplayParent(wxWindow * win)
{
    m_displayParent = win;
}

void
GCLogic::GCFatalBatchWarnGUI(wxString msg) const
{
    if(m_displayParent == NULL)
    {
        GCFatal(msg);
    }
    else
    {
        GCWarning(msg);
    }
}

void
GCLogic::GCError(wxString msg) const
{
    if(m_displayParent != NULL)
    {
        wxMessageDialog dialog(m_displayParent,msg,gcstr::error,wxOK|wxICON_ERROR);
        dialog.ShowModal();
    }
    else
    {
        GCDataStore::GCError(msg);
    }
}

void
GCLogic::GCInfo(wxString msg) const
{
    if(m_displayParent != NULL)
    {
        wxMessageDialog dialog(m_displayParent,msg,gcstr::information,wxOK|wxICON_INFORMATION);
        dialog.ShowModal();
    }
    else
    {
        GCDataStore::GCInfo(msg);
    }
}

void
GCLogic::GCWarning(wxString msg) const
{
    if(m_displayParent != NULL)
    {
        wxMessageDialog dialog(m_displayParent,msg,gcstr::warning,wxOK|wxICON_EXCLAMATION);
        dialog.ShowModal();
    }
    else
    {
        GCDataStore::GCWarning(msg);
    }
}

void
GCLogic::batchFileRejectGuiLog(wxString msg, size_t lineNo) const
{
    warnLog(msg,lineNo);
}

bool
GCLogic::guiQuestionBatchLog(wxString msg, wxString stopButton, wxString continueButton) const
{
    if(m_displayParent != NULL)
    {
        wxMessageDialog md(m_displayParent,
                            msg,
                            gcstr::questionHeader,
                            wxYES_NO | wxNO_DEFAULT | wxICON_EXCLAMATION
                            );
        int returnVal = md.ShowModal();
        return(returnVal == wxID_YES);

    }
    else
    {
        GCDataStore::guiQuestionBatchLog(msg,stopButton,continueButton);
    }
    return true;
}

void
GCLogic::GettingBusy(const wxString& msg) const
{
    GCDataStore::GettingBusy(msg);
    wxBeginBusyCursor();
}

void
GCLogic::LessBusy(const wxString& msg) const
{
    wxEndBusyCursor();
    GCDataStore::LessBusy(msg);
}
