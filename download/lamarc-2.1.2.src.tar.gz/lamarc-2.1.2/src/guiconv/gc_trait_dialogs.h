#ifndef GC_TRAIT_DIALOGS_H
#define GC_TRAIT_DIALOGS_H

class GCDataStore;
class wxWindow;

void DoDialogAddTrait(wxWindow * parentWindow, GCDataStore & dataStore);

#endif
//GC_TRAIT_DIALOGS_H
