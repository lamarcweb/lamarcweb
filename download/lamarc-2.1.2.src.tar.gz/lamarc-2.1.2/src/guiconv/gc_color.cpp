#include "gc_color.h"

#include "wx/colour.h"
#include "wx/gdicmn.h"
#include "wx/settings.h"

const wxColour & gccolor::selectedFile()
{
    static wxColour selectedFileColor = wxTheColourDatabase->Find("LIGHT BLUE");
    return selectedFileColor;
}

const wxColour & gccolor::enteredObject()
{
    static wxColour enteredObjectColor = wxSystemSettings::GetColour(wxSYS_COLOUR_HIGHLIGHT);
    return enteredObjectColor;
}

const wxColour & gccolor::activeObject()
{
    static wxColour activeObjectColor = wxTheColourDatabase->Find("YELLOW");
    return activeObjectColor;
}
