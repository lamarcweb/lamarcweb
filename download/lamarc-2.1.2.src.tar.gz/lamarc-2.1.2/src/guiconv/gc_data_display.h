#ifndef GC_DATA_DISPLAY_H
#define GC_DATA_DISPLAY_H

#include "wx/gbsizer.h"

class GCDataDisplaySizer : public wxGridBagSizer
{
    private:

    public:
        GCDataDisplaySizer();
        virtual ~GCDataDisplaySizer();

        void AddPop(wxWindow * header,size_t popIndex);
        void AddData(wxWindow * data, size_t popIndex, size_t locusIndex);
        void AddLocus(wxWindow * header, size_t locusIndex);
        void AddRegion(wxWindow * header,size_t firstLocus, size_t lastLocus);
};

#endif
//GC_DATA_DISPLAY_H
