#ifndef GC_LAYOUT_H
#define GC_LAYOUT_H

#include "wx/gdicmn.h"

class gclayout
{
    public:
        static const long   appHeight;
        static const long   appHeightPercent;
        static const long   appWidth;
        static const long   appWidthPercent;
        static const int    borderSize;
        static const int    borderSizeNone;
        static const int    borderSizeSmall;
        static const int    boxBorderSize;
        static const long   maxDataFiles;
        static const int    tabIconHeight;
        static const int    tabIconWidth;
        static const int    warningImageNeedsInput;
        static const int    warningImageOK;



};

#endif
//GC_LAYOUT_H
