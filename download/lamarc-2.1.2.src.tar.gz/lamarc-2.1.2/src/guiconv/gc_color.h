#ifndef GC_COLOR_H
#define GC_COLOR_H

class wxColour;

class gccolor
{
    public:
        static const wxColour & selectedFile();
        static const wxColour & enteredObject();
        static const wxColour & activeObject();
};


#endif
//GC_COLOR_H

