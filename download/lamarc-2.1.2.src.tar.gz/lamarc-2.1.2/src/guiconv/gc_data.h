#ifndef GC_DATA_H
#define GC_DATA_H

#include "gc_types.h"
#include "wx/arrstr.h"
#include "wx/list.h"

class gcdata
{
    public:
        static const wxArrayString fileFormatChoices();
        static const wxArrayString specificDataTypeChoices();
        static const wxArrayString interleavingChoices();
        static const wxArrayString genericLocusChoices();
        static const wxArrayString genericPopulationChoices();
        static const wxArrayString genericRegionChoices();
        static const wxArrayString integerList();
        static const wxArrayString integerListWithSpaces();
        static const wxArrayString nonNegativeIntegerList();
        static const wxArrayString positiveFloatChars();

        static const size_t defaultHapCount;

        static const long defaultMapPosition;
        static const long defaultOffset;
        static const long noLengthSet;
        static const long noMapPositionSet;
        static const long noMarkerCountSet;
        static const long noOffsetSet;
        static const long noStyle;


        static const GCFileFormat   defaultFileFormat;

        static const gcGeneralDataType  allDataTypes();
        static const gcGeneralDataType  allelicDataTypes();
        static const gcGeneralDataType  nucDataTypes();

        static wxString getPloidyString(size_t ploidy);
};


bool                ProduceBoolFromProximityOrBarf(wxString string);
bool                ProduceBoolFromYesNoOrBarf(wxString string);
GCFileFormat        ProduceGCFileFormatOrBarf(wxString string, bool allowUnknown=true);
gcGeneralDataType   ProduceGeneralDataTypeOrBarf(wxString string, bool allowUnknown=true);
gcSpecificDataType  ProduceSpecificDataTypeOrBarf(wxString string, bool allowUnknown=true);
GCInterleaving      ProduceGCInterleavingOrBarf(wxString string, bool allowUnknown=true);
wxString        ToWxString(bool);
wxString        ToWxStringLinked(bool);
wxString        ToWxString(gcGeneralDataType);
wxString        ToWxString(gcSpecificDataType);
wxString        ToWxString(GCFileFormat);
wxString        ToWxString(GCInterleaving);
wxString        ToWxString(gcPhaseSource);
wxString        ToWxString(loc_match);
wxString        ToWxString(pop_match);

#endif
//GC_DATA_H

