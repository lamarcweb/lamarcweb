Copy 'lam_conv' (or lam_conv.exe, depending on your system) into this 
directory, then run:

    ./lam_conv -b -c sample-conv-cmd.xml

This data isn't meant to be runable with Lamarc. However, if you read the
comments in sample-conv-cmd.xml you should be able to produce your own
lamarc input file.  From there, you should be able to run lamarc on the 
produced file.

You can also omit the '-b' option to pull the data into the converter, and
further manipulate it with the GUI.
