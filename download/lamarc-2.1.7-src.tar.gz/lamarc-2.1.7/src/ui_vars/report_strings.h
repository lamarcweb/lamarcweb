// $Id: report_strings.h,v 1.7 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef REPORT_STRINGS_H
#define REPORT_STRINGS_H

#include <string>

class reportstr
{
  public:
    static const std::string    header;

    static const std::string    categoryHeader;
    static const std::string    categoryRate;
    static const std::string    categoryRelativeProb;

    static const std::string    baseFreqs;
    static const std::string    baseFreqSeparator;

    static const std::string    TTratio;

    static const std::string    GTRRates;
    static const std::string    GTRRateSeparator;
    static const std::string    GTRRatesFromA;
    static const std::string    GTRRatesFromC;
    static const std::string    GTRRatesFromG;

    static const std::string    numberOfBins;

    static const std::string    brownian;

    static const std::string    alpha;
    static const std::string    optimizeAlpha;

    static const std::string    relativeMutationRate;

    static const std::string    perBaseErrorRate;
};

#endif // REPORT_STRINGS_H

//____________________________________________________________________________________
