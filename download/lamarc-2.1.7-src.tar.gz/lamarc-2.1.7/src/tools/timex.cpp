// $Id: timex.cpp,v 1.6 2011/03/07 06:08:51 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "timex.h"

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

/*===============================================
  timer utilities <Peter Beerli>

  ts = "%c" -> time + full date (see man strftime)
  = "%H:%M:%S" -> time hours:minutes:seconds

  This is C masquerading as C++, since it has to interface
  with C utilities.  --Mary

  WARNING!  Make sure that time_t.h exists before calling these!
*/

string PrintTime (const time_t mytime, const string format)
{
    const int arraylength = 80;

#ifdef NOTIME_FUNC
    // The system does not provide a clock so we return blanks.
    string tempstring;
    tempstring.assign(format.size,' ');
    return(tempstring);
#endif

    struct tm *nowstruct;
    char temparray[arraylength];
    if (mytime != (time_t) - 1)  // invalid time marked as -1
    {
        nowstruct = localtime (&mytime);
        strftime (temparray, arraylength, format.c_str(), nowstruct);
        return string(temparray);
    }
    else
    {                                   // time returned is invalid
        string tempstring;              // so we return blanks
        tempstring.assign(format.size(),' ');
        return(tempstring);
    }
} // PrintTime

//------------------------------------------------------------------------------------

time_t GetTime ()
{
#ifdef NOTIME_FUNC
    // The system does not provide a clock.
    return((time_t)-1);
#else
    // Return the "real" time.
    return(time(NULL));
#endif
} // GetTime

//____________________________________________________________________________________
