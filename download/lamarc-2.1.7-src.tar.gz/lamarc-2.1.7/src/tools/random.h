// $Id: random.h,v 1.17 2011/03/07 06:08:51 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef RANDOM_H
#define RANDOM_H

#include <string>
#include <boost/random.hpp>
#include <boost/random/mersenne_twister.hpp>

#define MAX_RANDOM  4294967296.0        // 2^32

class Random
{
    Random(const Random&);          // undefined
    Random operator=(Random);       // undefined

    long num0, num1, num2, num3;
    long n0, n1, n2, n3;
    long m0, m1, m2, m3;

    boost::mt19937 m_rng;

  public:
    // The default ctor seeds the RNG from the system clock.  Warning:  if you
    // call it twice in quick succession the answer will probably be the same!
    // It is using *seconds*, not milliseconds.
    Random();
    Random(long seed);
    void Seed(long seed);
    void Read(char*);
    void Write(char*);
    long Long(long range);
    double Float();
    char Base();
    bool Bool();
    std::string Name();
    double Normal();
};

#endif // RANDOM_H

//____________________________________________________________________________________
