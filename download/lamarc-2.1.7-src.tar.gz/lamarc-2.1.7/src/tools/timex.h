// $Id: timex.h,v 1.7 2011/04/23 02:02:49 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef TIMEX_H
#define TIMEX_H

#include <cmath>
#include <ctime>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "vectorx.h"
#include "stringx.h"

/*****************************************************************
 These functions handle time information.  GetTime retrieves the
 current time as a time_t (seconds since the epoch).  PrintTime
 turns a time_t into a formatted string.
 Mary Kuhner (based on code of Peter Beerli) October 2000
*****************************************************************/

string PrintTime(const time_t mytime, const string format = "%H:%M:%S");

time_t GetTime();

#endif // TIMEX_H

//____________________________________________________________________________________
