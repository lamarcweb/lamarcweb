// $Id: tools.h,v 1.4 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

// This is just a catch-all include file for all of the program
//    specific extensions to the standard library

#ifndef TOOLS_H
#define TOOLS_H

#include "stringx.h"
#include "vectorx.h"

#endif // TOOLS_H

//____________________________________________________________________________________
