// $Id: cellmanager.cpp,v 1.5 2011/03/07 06:08:48 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

// This file contains the implementation code for the manager of data-likelihood
// storage, CellManager

#ifdef DMALLOC_FUNC_CHECK
#include "/usr/local/include/dmalloc.h"
#endif

#include "cellmanager.h"

//------------------------------------------------------------------------------------

cellarray CellManager::GetArray(triplet id, DLCell& requester)
{
    FreeStore::iterator it = m_store.find(id);

    if (it != m_store.end())            // found one
    {
        cellarray result = it->second;
        m_store.erase(it);
        return result;
    }
    else
        return requester.MakeArray();

} // GetArray

//------------------------------------------------------------------------------------

void CellManager::FreeArray(triplet id, cellarray array)
{
    m_store.insert(std::make_pair(id, array));

} // FreeArray

//------------------------------------------------------------------------------------

void CellManager::ClearStore()
{
    // assumes all cells are 3-D contiguous storage gotten with new[]!
    cellarray ar;
    FreeStore::iterator it = m_store.begin();
    for ( ; it != m_store.end(); ++it)
    {
        ar = it->second;
        delete [] ar[0][0];
        delete [] ar[0];
        delete [] ar;
    }
    m_store.erase(m_store.begin(), m_store.end());
} // ClearStore

//____________________________________________________________________________________
