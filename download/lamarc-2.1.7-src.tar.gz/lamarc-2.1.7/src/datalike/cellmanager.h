// $Id: cellmanager.h,v 1.3 2011/02/20 04:14:09 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

/******************************************************************

The CellManager maintains a private internal store of the arrays
used by class DLCell and its children.  This is a speedup; we avoid
allocating and deallocating these arrays and reuse them instead.
This functionality was originally static in DLCell but that design
suffered order-of-static-deallocation issues especially on
Macs.  Here it is a Singleton which is abandoned on the heap, producing
the appearance of a memory leak, but at least no crashes.  DO NOT
give this class a destructor, as destroying it will reintroduce the
order-of-deallocation bug!

After each Region you should call ClearStore to get rid of old
arrays; they are unlikely to be useful in the new Region and will
eat up space.

The CellManager code assumes that all of the data-likelihood
arrays are three-dimensional contiguous allocation using new[].  If you
write one that isn't, do not use this code to manage it.

********************************************************************/

#ifndef CELLMANAGER_H
#define CELLMANAGER_H

#include "types.h"  // for definition of cellarray and FreeStore
#include "dlcell.h" // for definition of triplet and DLCell

class CellManager
{
  private:
    FreeStore     m_store;  // multimap of triplet and cellarray
    cellarray     MakeArray();

    // disabled functionality follows
    ~CellManager();  // undefined to prevent destruction
    CellManager(const CellManager&);
    CellManager&  operator=(const CellManager&);

  public:
    CellManager() {};
    cellarray     GetArray(triplet dimensions, DLCell& requester);
    void          FreeArray(triplet dimensions, cellarray array);
    void          ClearStore();
};

#endif // CELLMANAGER_H

//____________________________________________________________________________________
