// $Id: xml_report.h,v 1.7 2011/03/07 06:08:51 bobgian Exp $

/*
  Copyright 2008  Peeter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef XML_REPORT_H
#define XML_REPORT_H

#include <string>
#include "tinyxml.h"

class ChainManager;
class Parameter;

/******************************************************************
This class produces an XML version of the outfile.txt
At initial writing, it is not a complete version, just
what I need to evaluate simulations of the new lamarc
data uncertainty model

Elizabeth Walkup  December 2008

******************************************************************/

class ChainOut;

class XMLReport
{
  private:
    std::string     m_filename;
    TiXmlDocument   m_doc;

  protected:
    void            AddSlicesTo(TiXmlElement *,
                                const Parameter&,
                                force_type,
                                long regNo,
                                bool doOverall);
    TiXmlElement *  MakeParameter(const Parameter&, const force_type);
    TiXmlElement *  MakeParameters();
    TiXmlElement *  MakeChainReport(const   ChainOut&,
                                    size_t  regNo,
                                    size_t  repNo,
                                    size_t  chainNo);
    TiXmlElement *  MakeWarnings();

    void            AddRangeElements(TiXmlElement *, rangeset sites, std::string label);

  public:
    XMLReport(std::string filename);
    virtual ~XMLReport();
    TiXmlElement * Write(const ChainManager&);
};

#endif // XML_REPORT_H

//____________________________________________________________________________________
