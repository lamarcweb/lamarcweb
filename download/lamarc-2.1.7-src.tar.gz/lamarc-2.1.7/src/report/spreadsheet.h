// $Id: spreadsheet.h,v 1.2 2010/03/02 23:12:29 bobgian Exp $

/*
  Copyright 2008  Peeter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef SPREADSHEET_H
#define SPREADSHEET_H

#include <string>
#include "vectorx.h"

class Force;
class Parameter;
class TiXmlElement;

/******************************************************************
Classes for writing spreadsheet-ready versions of data from
outfile.txt

Elizabeth Walkup  September 2009

******************************************************************/

std::string makeFileName(   std::string     filePrefix,
                            std::string     paramName);
size_t      getNumSlices(   TiXmlElement *  estimateElem);
void        addFirstCol(    StringVec2d &   table,
                            TiXmlElement *  esitmateElem,
                            std::string &   profileTypeOut,
                            std::string &   analysisTypeOut);
void        addEstimate(    StringVec2d &   table,
                            size_t          estimateIndex,
                            TiXmlElement *  esitmateElem,
                            std::string     paramName,
                            std::string     regionName,
                            std::string     expectedProfileType,
                            std::string     expectedAnalysisType);

void        reorderEstimates(   std::vector<TiXmlElement*> &    estimates);

void WriteOneProfileSpread( std::string     filePrefix,
                            TiXmlElement *  forceElem,
                            TiXmlElement *  paramElem);

void WriteProfileSpreads(   std::string     filePrefix,
                            TiXmlElement *  reportTop);

#endif // SPREADSHEET_H

//____________________________________________________________________________________
