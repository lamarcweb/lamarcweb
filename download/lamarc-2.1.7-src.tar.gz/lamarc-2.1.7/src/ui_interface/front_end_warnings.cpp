// $Id: front_end_warnings.cpp,v 1.3 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "front_end_warnings.h"
#include "vectorx.h"

FrontEndWarnings::FrontEndWarnings()
{
}

FrontEndWarnings::~FrontEndWarnings()
{
}

StringVec1d
FrontEndWarnings::GetAndClearWarnings()
{
    StringVec1d warnings = m_warnings;
    m_warnings.clear();
    return warnings;
}

void
FrontEndWarnings::AddWarning(std::string warnmsg)
{
    for (unsigned long wnum=0; wnum<m_warnings.size(); wnum++)
    {
        if (m_warnings[wnum]==warnmsg) return;
    }
    m_warnings.push_back(warnmsg);
}

//____________________________________________________________________________________
