// $Id: ui_regid.cpp,v 1.7 2011/03/07 06:08:53 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#include <cassert>

#include "ui_regid.h"
#include "ui_vars.h"
#include "ui_id.h"
#include "ui_constants.h"

//------------------------------------------------------------------------------------

UIRegId::UIRegId(long reg, long loc, const UIVars& uivars)
    : m_region(reg),
      m_locus(loc),
      m_dtype(uivars.datapackplus.GetDataType(m_region, m_locus))
{
}

UIRegId::UIRegId(data_type dtype)
    : m_region(uiconst::GLOBAL_ID),
      m_locus(uiconst::GLOBAL_ID),
      m_dtype(dtype)
{
}

UIRegId::UIRegId(UIId id, const UIVars& uivars)
{
    if (id.GetIndex1()==uiconst::GLOBAL_ID)
    {
        assert(false); //We should be using the DATAMODEL flag values, below.
        m_region = uiconst::GLOBAL_ID;
        m_locus = uiconst::GLOBAL_ID;
        m_dtype = dtype_DNA; //default value
    }
    else if (id.GetIndex1()==uiconst::GLOBAL_DATAMODEL_NUC_ID)
    {
        m_region = uiconst::GLOBAL_ID;
        m_locus = uiconst::GLOBAL_ID;
        m_dtype = dtype_DNA;
    }
    else if (id.GetIndex1()==uiconst::GLOBAL_DATAMODEL_MSAT_ID)
    {
        m_region = uiconst::GLOBAL_ID;
        m_locus = uiconst::GLOBAL_ID;
        m_dtype = dtype_msat;
    }
    else if (id.GetIndex1()==uiconst::GLOBAL_DATAMODEL_KALLELE_ID)
    {
        m_region = uiconst::GLOBAL_ID;
        m_locus = uiconst::GLOBAL_ID;
        m_dtype = dtype_kallele;
    }
    else
    {
        m_region = id.GetIndex1();
        m_locus = id.GetIndex2();
        m_dtype = uivars.datapackplus.GetDataType(m_region, m_locus);
    }
}

bool UIRegId::operator<(const UIRegId other) const
{
    if (m_region == other.m_region)
    {
        return (m_locus < other.m_locus);
    }
    return (m_region < other.m_region);
}

//____________________________________________________________________________________
