// $Id: data_interface.h,v 1.23 2012/02/15 18:13:42 jmcgill Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef DATA_INTERFACE_H
#define DATA_INTERFACE_H

#include "setget.h"
#include "vectorx.h"

class UIVars;

class uiCrossPartitionCount : public GetLong
{
  public:
    uiCrossPartitionCount();
    virtual ~uiCrossPartitionCount();
    virtual long Get(UIVars& vars, UIId id);
};

//------------------------------------------------------------------------------------

class uiDivMigPartitionCount : public GetLong
{
  public:
    uiDivMigPartitionCount();
    virtual ~uiDivMigPartitionCount();
    virtual long Get(UIVars& vars, UIId id);
};

class uiDivMigPartitionName : public GetString
{
  public:
    uiDivMigPartitionName();
    virtual ~uiDivMigPartitionName();
    virtual std::string Get(UIVars& vars, UIId id);
};

//------------------------------------------------------------------------------------

class uiMigPartitionCount : public GetLong
{
  public:
    uiMigPartitionCount();
    virtual ~uiMigPartitionCount();
    virtual long Get(UIVars& vars, UIId id);
};

class uiMigPartitionName : public GetString
{
  public:
    uiMigPartitionName();
    virtual ~uiMigPartitionName();
    virtual std::string Get(UIVars& vars, UIId id);
};

//------------------------------------------------------------------------------------

class uiDiseasePartitionCount : public GetLong
{
  public:
    uiDiseasePartitionCount();
    virtual ~uiDiseasePartitionCount();
    virtual long Get(UIVars& vars, UIId id);
};

class uiDiseasePartitionName : public GetString
{
  public:
    uiDiseasePartitionName();
    virtual ~uiDiseasePartitionName();
    virtual std::string Get(UIVars& vars, UIId id);
};

class uiLociNumbers : public GetLongVec1d
{
  public:
    uiLociNumbers();
    virtual ~uiLociNumbers();
    virtual LongVec1d Get(UIVars& vars, UIId id);
};

class uiRegionNumbers : public GetLongVec1d
{
  public:
    uiRegionNumbers();
    virtual ~uiRegionNumbers();
    virtual LongVec1d Get(UIVars& vars, UIId id);
};

class uiRegionEffectivePopSize : public SetGetDouble
{
  public:
    uiRegionEffectivePopSize();
    virtual ~uiRegionEffectivePopSize();
    virtual double Get(UIVars& vars, UIId id);
    virtual void   Set(UIVars& vars, UIId id, double size);
};

class uiSimulateData : public SetGetBool
{
  public:
    uiSimulateData();
    virtual ~uiSimulateData();
    virtual bool Get(UIVars& vars, UIId id);
    virtual void Set(UIVars& vars, UIId id, bool sim);
};

#endif // DATA_INTERFACE_H

//____________________________________________________________________________________
