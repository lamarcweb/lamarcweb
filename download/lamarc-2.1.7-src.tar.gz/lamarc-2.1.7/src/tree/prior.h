// $Id: prior.h,v 1.7 2011/10/31 22:04:51 ewalkup Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

//A prior is a shape.  Currently, we have two possible shapes:  a rectangle
// in linear space, and a rectangle in log space.  Those are simple enough
// that we don't really need a class for them, but if we want more complex
// priors in the future (say, a gaussian curve) we will probably want this.
// RandomDraw() encapsulates the usefulness of a prior--it picks a random
// number within its shape, with the chance based on volume.

//------------------------------------------------------------------------------------

#ifndef PRIOR_H
#define PRIOR_H

#include "constants.h"

class UIVarsPrior;
class ParamStatus;

class Prior
{

  private:
    Prior();                            // undefined
    priortype  m_priortype;
    double     m_lowerbound;
    double     m_upperbound;
    double     m_lnlower; //speed optimization--precalculated.
    double     m_lnupper;
    double     m_binwidth;
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
    long        m_samplingRate;
#endif
    

  public:
    Prior(UIVarsPrior uiprior);
    Prior(ParamStatus shouldBeInvalid);
    //Use the default copy constructor.
    virtual ~Prior();
    bool      operator==(const Prior src) const; // compare priors

    virtual priortype GetPriorType()  const { return m_priortype; };
    virtual double    GetLowerBound() const { return m_lowerbound; };
    virtual double    GetUpperBound() const { return m_upperbound; };
    virtual double    GetBinwidth()   const { return m_binwidth; };
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
    virtual long      GetSamplingRate()   const { return m_samplingRate; };
#endif

    virtual std::pair<double, double> RandomDraw() const;
};

#endif // PRIOR_H

//____________________________________________________________________________________
