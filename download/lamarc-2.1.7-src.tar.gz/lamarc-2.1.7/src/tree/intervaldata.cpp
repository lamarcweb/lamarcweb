// $Id: intervaldata.cpp,v 1.24 2011/04/23 02:02:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "intervaldata.h"
#include "summary.h"
#include "stringx.h"
#include "runreport.h"
#include "force.h"
#include "xmlsum_strings.h" // for xml sumfile strings
#include <iostream>
#include <fstream>

using namespace std;

//------------------------------------------------------------------------------------

Interval* IntervalData::AddInterval(Interval* prev, double time, const
                                    LongVec2d& pk, const LongVec1d& xk, long s, xpart_t ostat, xpart_t nstat,
                                    long recsite, const LongVec1d& picks, force_type type)
{
    // Intervals are assumed to be in time-sorted order
    Interval interval(time, pk, xk, s, ostat, nstat, recsite, picks, type);
    intervals.push_back(interval);
    Interval* thisinterval = &(intervals.back());
    if (prev)
    {
        prev->next = thisinterval;
    }
    return thisinterval;
} // AddInterval

//------------------------------------------------------------------------------------

Interval* IntervalData::AddDummyInterval(Interval* prev,
                                         long s, xpart_t ostat,
                                         xpart_t nstat, long recsite,
                                         force_type type)
{
    // We will construct some dummy vectors of appropriate size
    // NB:  All previous code made them gratuitously big

    // xk is number of lineages per crosspartition
    xpart_t nxparts = registry.GetDataPack().GetNCrossPartitions();
    LongVec1d fake_xk(nxparts, 0L);

    // pk is partition-forces x number of lineages per partition
    LongVec2d fake_pk;
    const ForceVec& partforces = registry.GetForceSummary().GetPartitionForces();
    unsigned long i;

    for (i = 0; i < partforces.size(); ++i)
    {
        xpart_t nparts = partforces[i]->GetNParams();
        LongVec1d fake_partlines(nparts, 0L);
        fake_pk.push_back(fake_partlines);
    }

    // MDEBUG:  should this have real info in it??
    // picks is number of local partition-forces
    long npicks = registry.GetForceSummary().GetNLocalPartitionForces();
    LongVec1d fake_picks(npicks, 0L);

    return AddInterval(prev, 0.0, fake_pk, fake_xk, s, ostat, nstat,
                       recsite, fake_picks, type);
} // AddDummyInteral

//------------------------------------------------------------------------------------

void IntervalData::PrintIntervalData() const
{
    list<Interval>::const_iterator it;

    for (it = intervals.begin(); it != intervals.end(); ++it)
    {
        const Interval& inter = *it;
        cout << "time " << inter.endtime << " activesites " <<
            inter.activesites << " old status " << inter.oldstatus <<
            " new status " << inter.newstatus << " recsite " << inter.recsite <<
            endl;
        cout << "xpartition lines are ";
        unsigned long i;
        for (i = 0; i < inter.xpartlines.size(); ++i)
            cout << inter.xpartlines[i] << " ";
        cout << endl;
        cout << "partition lines are ";
        for (i = 0; i < inter.partlines.size(); ++i)
        {
            unsigned long j;
            for(j = 0; j < inter.partlines[i].size(); ++j)
                cout << inter.partlines[i][j] << " ";
            cout << endl;
        }
        cout << "Next is " << inter.next << endl;
    }
} // PrintIntervalData

//WriteIntervalData is used when writing tree summaries and growth
// has been turned on, since the tree summaries cannot be summarized.

//------------------------------------------------------------------------------------

void IntervalData::WriteIntervalData(ofstream& sumout) const
{
    list<Interval>::const_iterator it;
    string error;

    for (it = intervals.begin(); it != intervals.end(); ++it)
    {
        const Interval& inter = *it;

        force_type type = inter.type;

        //All forces have a type and an endtime.

        sumout << "\t\t" << xmlsum::FORCE_START << " " << ToString(type) << " "
               << xmlsum::FORCE_END << endl;
        sumout << "\t\t\t" << xmlsum::ENDTIME_START << " "
               << inter.endtime << " " << xmlsum::ENDTIME_END << endl;

        //For clarity, we'll do a big if/else loop here for the member
        // variables that are only used for certain forces.

        switch (type)
        {
            case force_COAL:
                //Oldstatus is used for all partition forces and coalescence,
                // not recombination
                sumout << "\t\t\t" << xmlsum::OLDSTATUS_START << " "
                       << inter.oldstatus << " " << xmlsum::OLDSTATUS_END << endl;
                break;

            case force_MIG:
            case force_DIVMIG:
            case force_DISEASE:
                //Oldstatus is used for all partition forces and coalescence,
                // not recombination
                sumout << "\t\t\t" << xmlsum::OLDSTATUS_START << " "
                       << inter.oldstatus << " " << xmlsum::OLDSTATUS_END << endl;

                //Newstatus is used for all partition forces (and not coalescence)
                sumout << "\t\t\t" << xmlsum::NEWSTATUS_START << " "
                       << inter.newstatus << " " << xmlsum::NEWSTATUS_END << endl;
                break;

            case force_REC:
                //Activesites and Recsite are only used for recombination.
                sumout << "\t\t\t" << xmlsum::ACTIVESITES_START << " "
                       << inter.activesites << " " << xmlsum::ACTIVESITES_END << endl;
                sumout << "\t\t\t" << xmlsum::RECSITE_START << " "
                       << inter.recsite << " " << xmlsum::RECSITE_END << endl;
                //partnerpicks is only used for recombination, this vector will be
                //empty if no local partition force is also active
                if (!inter.partnerpicks.empty())
                {
                    sumout << "\t\t\t" << xmlsum::PARTNERPICKS_START << " ";
                    for (unsigned long i = 0; i < inter.partnerpicks.size(); ++i)
                        sumout << inter.partnerpicks[i] << " ";
                    sumout << xmlsum::PARTNERPICKS_END << endl;
                }
                break;

            case force_GROW:
                error = "Error:  No interval of type " + lamarcstrings::GROW
                    + " should be possible.  Exiting IntervalData::WriteIntervalData.";
                throw implementation_error(error);
                break;

            default:
                error = "Error:  unknown interval type '" + ToString(type)
                    + "' encountered.  Exiting IntervalData::WriteIntervalData.";
                throw implementation_error(error);
                break;
        }

        //All forces have xpartlines.
        sumout << "\t\t\t" << xmlsum::XPARTLINES_START << " ";
        for (unsigned long i = 0; i < inter.xpartlines.size(); ++i)
            sumout << inter.xpartlines[i] << " ";
        sumout << xmlsum::XPARTLINES_END << endl;

        //Partlines can be tested vs. their size, so we don't need to check the force type.
        if (inter.partlines.size())
        {
            sumout << "\t\t\t" << xmlsum::PARTLINES_START << " ";
            for (unsigned long i = 0; i < inter.partlines.size(); ++i)
            {
                for(unsigned long j = 0; j < inter.partlines[i].size(); ++j)
                    sumout << inter.partlines[i][j] << " ";
                sumout << ". ";
            }
            sumout << xmlsum::PARTLINES_END << endl;
        }
    }
} // WriteIntervalData

//____________________________________________________________________________________
