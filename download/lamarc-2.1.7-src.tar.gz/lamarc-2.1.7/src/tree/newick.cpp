// $Id: newick.cpp,v 1.29 2012/03/29 22:03:34 jmcgill Exp $

#include <cassert>
#include <utility>                     // for make_pair in recombinant
                                       // LamarcTreeToNewickString

#include "local_build.h"

#include "newick.h"
#include "tree.h"
#include "stringx.h"
#include "constants.h"                  // for FLAGDOUBLE
#include "branch.h"
#include "timelist.h"                   // to build the tree
#include "registry.h"
#include "force.h"                      // for Force::GetMaximum()
#include "runreport.h"                  // for ReportUrgent() in NewickConverter::
                                        //   LamarcTreeToNewickString()

//------------------------------------------------------------------------------------

const double DEFAULTLENGTH = 0.01;

// DEBUG Comments, including migration nodes, are ignored
// DEBUG Nested comments do not work yet (need to fix ProcessComments)
// NB No provision is made for recombination

//------------------------------------------------------------------------------------

NewickTree::NewickTree(const string& tree)
    : m_newicktree(tree),
      m_curr_char(0),
      m_numbers("0123456789.-+eE"),     // things found in numbers
      m_terminators(":,)[")             // things terminating names
{
    // intentionally blank
} // NewickTree constructor

//------------------------------------------------------------------------------------

void NewickTree::ToLamarcTree(Tree& stump)
{
    // create a holder structure to store ongoing info about the tree
    NewickNode base(stump);

    // create a working pointer into the holder
    NewickNode* current = &base;

    // begin at start of tree string
    m_curr_char = 0;

    while (m_newicktree[m_curr_char] != ';') // semicolon is end of tree
    {
        switch(m_newicktree[m_curr_char])
        {
            case '(':
                ++m_curr_char;
                // create first daughter
                current = current->AddChild();
                break;
            case ',':
                ++m_curr_char;
                // create additional daughter
                current = current->GetParent()->AddChild();
                break;
            case ')':
                ++m_curr_char;
                // coalesce daughters
                current = current->GetParent()->Terminate();
                break;
            case ' ':
            case '\n':
            case '\t':
            case '\r':
                ++m_curr_char;
            // skip whitespace
            break;
            case ':':
                current->SetLength(ProcessLength());
                break;
            case '[':
                ProcessComment();
                break;
            default:
                // Anything unrecognized must be a tip name
                current->AddBranch(ProcessName(stump));
                break;
        }
    }

    // hookup the lamarc tree
    base.Coalesce();

    stump.AttachBase(base.GetBranch());

} // ToLamarcTree

//------------------------------------------------------------------------------------

double NewickTree::ProcessLength()
{
    ++m_curr_char;  // skip the colon
    unsigned long endpos = m_newicktree.find_first_not_of(m_numbers, m_curr_char);
    unsigned long ndigits = endpos - m_curr_char;
    string lengthstr = m_newicktree.substr(m_curr_char, ndigits);
    double length;
    if (FromString(lengthstr,length))
    {
        m_curr_char = endpos;
        return length;
    }
    else
    { // error handling
        assert(false); // bad newick tree, not handled yet
        return FLAGDOUBLE;
    }

} // ProcessLength

//------------------------------------------------------------------------------------

Branch_ptr NewickTree::ProcessName(const Tree& stump)
{
    unsigned long endpos = m_newicktree.find_first_of(m_terminators, m_curr_char);
    unsigned long nchars = endpos - m_curr_char;
    string name = m_newicktree.substr(m_curr_char, nchars);
    m_curr_char = endpos;
    return stump.GetTip(name);
} // ProcessName

//------------------------------------------------------------------------------------

void NewickTree::ProcessComment()
// NB: We don't do anything with the contents of the comment yet
{
    unsigned long endpos = m_newicktree.find(']', m_curr_char);
    // comment parsing would go in here
    m_curr_char = endpos;
} // ProcessComment

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

NewickNode::NewickNode(Tree& stump)
    : m_tree(stump),
      m_parent(NULL),
      m_length(0.0)
{
    // deliberately blank
} // NewickTree constructor

//------------------------------------------------------------------------------------

NewickNode::~NewickNode()
{
    vector<NewickNode*>::iterator it;

    for (it = m_children.begin(); it != m_children.end(); ++it)
    {
        delete *it;
    }
} // NewickNode dtor

//------------------------------------------------------------------------------------

NewickNode* NewickNode::AddChild()
{
    NewickNode* newnode = new NewickNode(m_tree);
    m_children.push_back(newnode);
    newnode->m_parent = this;
    return newnode;
} // AddChild

//------------------------------------------------------------------------------------

NewickNode* NewickNode::Terminate()
{
    assert(m_children.size() > 1);

    return this;
} // Terminate

//------------------------------------------------------------------------------------

NewickNode* NewickNode::GetParent() const
{
    return m_parent;
} // GetParent

//------------------------------------------------------------------------------------

Branch_ptr NewickNode::GetBranch() const
{
    return m_branch;
} // GetBranch

//------------------------------------------------------------------------------------

void NewickNode::AddBranch(Branch_ptr br)
{
    m_branch = br;
} // AddBranch

//------------------------------------------------------------------------------------

void NewickNode::SetLength(double newlength)
{
    m_length = newlength;
} // SetLength

//------------------------------------------------------------------------------------

double NewickNode::Coalesce()
{
    if (m_children.empty())             // we're at a tip
    {
        return m_length;
    }

    double eventtime = FLAGDOUBLE;      // initialized to invalid value

    vector<NewickNode*>::const_iterator kid;
    for(kid = m_children.begin(); kid != m_children.end(); ++kid)
    {
        eventtime = (*kid)->Coalesce(); // These should all be the same.
                                        // There may be differences due to
                                        // rounding, but we ignore them.
    }

    assert(m_children[0]->m_branch && m_children[1]->m_branch);
    assert(eventtime != FLAGDOUBLE);

    rangeset fcsites;                   // No sites are fc, so this is empty.
    m_branch = m_tree.Coalesce(m_children[0]->m_branch, m_children[1]->m_branch, eventtime, fcsites);

    return eventtime + m_length;
} // Coalesce

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

string NewickConverter::LamarcTreeToNewickString(const Tree& tree) const
{
    string newick;

    if (registry.GetForceSummary().CheckForce(force_REC))
    {
      rangepair span(std::make_pair(0L,tree.GetNsites()));
      rangevector subtrees(tree.GetLocusSubtrees(span));
      long nsubtrees(subtrees.size());
      long tr;
      for(tr = 0; tr < nsubtrees; ++tr)
      {
         // print the range
         newick += "[" + ToString(subtrees[tr].first);
         long endval(subtrees[tr].second);
         --endval; // to deal with open ended ranges
         newick += "," + ToString(endval) + "]\n";
         // print the rangetree
         RecurseWriteIntervalTreeNewick(newick,endval,tree.GetTimeList().Root());
         newick += ":0.0;\n";
      }
    } else {
      if (tree.GetTimeList().ContainsOnlyTipsAndCoals())
      {
        RecurseWriteNewick(newick,tree.GetTimeList().Root());
        newick += ":0.0;\n";
      } else {
        string msg("WARNING--tried to make a newick tree from an ");
        msg += "enhanced coalescent tree.  Newick formatting failed.\n";
        registry.GetRunReport().ReportUrgent(msg);
      }
    }

    return newick;
} // LamarcTreeToNewickString

//------------------------------------------------------------------------------------

double NewickConverter::RecurseWriteNewick(string& newick, Branch_ptr pBranch) const
{
    // NB This code makes some simplifying assumptions:
    // no recombination; mutation and disease are ignored;
    // no more than 2 children per branch; no "one-legged
    // coalescence nodes".

    double time, newtime;

    // skip a disease or migration branch
    if (pBranch->Event() == btypeMig || pBranch->Event() == btypeDisease)
    {
        time = RecurseWriteNewick(newick, pBranch->Child(0));
        return time + (pBranch->m_eventTime - pBranch->Child(0)->m_eventTime);
    }

    // terminate on a tip branch
    if (pBranch->BranchGroup() == bgroupTip)
    {
        // write tip name
        newick += boost::dynamic_pointer_cast<TBranch>(pBranch)->m_label;
        return 0.0;
    }

    // process a coalescence branch and recurse
    assert(pBranch->Event() == btypeCoal);
    assert(pBranch->Child(0));
    assert(pBranch->Child(1));

    newick += '(';

    // recurse left
    time = RecurseWriteNewick(newick, pBranch->Child(0));
    newick += ':';
    newtime = time + pBranch->m_eventTime - pBranch->Child(0)->m_eventTime;
    newick += ToString(newtime);
    newick += ',';

    // recurse right
    time = RecurseWriteNewick(newick, pBranch->Child(1));
    newick += ':';
    newtime = time + pBranch->m_eventTime - pBranch->Child(1)->m_eventTime;
    newick += ToString(newtime) + ')';

    // return newtime;  this return value will lead to node times being printed
    return 0.0;  // return zero if not trying to accumulate lengths

} // RecurseWriteNewick

//____________________________________________________________________________________


double NewickConverter::RecurseWriteIntervalTreeNewick(string& newick,
  long site, Branch_ptr pBranch) const
{
    // NB This code makes some simplifying assumptions:
    // mutation and disease are legal but ignored
    // no more than 2 children per branch.

    double time, newtime;

    // skip a disease or migration branch or recombination branch
    if (pBranch->Event() == btypeMig || pBranch->Event() == btypeDisease ||
        pBranch->Event() == btypeRec)
    {
        time = RecurseWriteIntervalTreeNewick(newick, site, pBranch->Child(0));
        return time + (pBranch->m_eventTime - pBranch->Child(0)->m_eventTime);
    }

    // terminate on a tip branch
    if (pBranch->BranchGroup() == bgroupTip)
    {
        // write tip name
        newick += boost::dynamic_pointer_cast<TBranch>(pBranch)->m_label;
        return 0.0;
    }

    // process a coalescence branch and recurse
    assert(pBranch->Event() == btypeCoal);
    assert(pBranch->Child(0));
    assert(pBranch->Child(1));

    // deal with a "one-legged" coalescence for site "site"
    if (!pBranch->Child(0)->m_rangePtr->IsSiteLive_Rg(site)) {
        time = RecurseWriteIntervalTreeNewick(newick, site, pBranch->Child(1));
        return time + (pBranch->m_eventTime - pBranch->Child(1)->m_eventTime);
    }

    if (!pBranch->Child(1)->m_rangePtr->IsSiteLive_Rg(site)) {
        time = RecurseWriteIntervalTreeNewick(newick, site, pBranch->Child(0));
        return time + (pBranch->m_eventTime - pBranch->Child(0)->m_eventTime);
    }

    // we must have a normal "two-legged" coalescence here
    newick += '(';

    time = RecurseWriteIntervalTreeNewick(newick, site, pBranch->Child(0));
    newick += ':';
    newtime = time + pBranch->m_eventTime - pBranch->Child(0)->m_eventTime;
    newick += ToDecimalString(newtime);
    newick += ',';

    time = RecurseWriteIntervalTreeNewick(newick, site, pBranch->Child(1));
    newick += ':';
    newtime = time + pBranch->m_eventTime - pBranch->Child(1)->m_eventTime;
    newick += ToDecimalString(newtime) + ')';

    // return newtime;  this return value will lead to node times being printed
    return 0.0;  // return zero if not trying to accumulate lengths

} // RecurseWriteIntervalTreeNewick

//____________________________________________________________________________________
