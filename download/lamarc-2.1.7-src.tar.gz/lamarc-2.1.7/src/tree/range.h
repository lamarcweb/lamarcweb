// $Id: range.h,v 1.43 2011/06/28 00:07:46 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

// Range and RecRange implement an ordered set of half-open site ranges (open at the end).  RecRange
// is meant to be embedded within a branch to allow for the possibility of recombination events.
// Range (the base class) handles non-recombination-only events.
//
// They track two different ranges, the active sites and the newly-active sites; plus the derived quantities:
// number of active links and number of newly-active links.  Finally, for a recombinant branch, RecRange notes
// which site is associated with the recombination event (i.e. the site before the cut link).
//
// They provide getter/setter pairs for all of their internal variables.
//
// Range provides IsSiteActive() which answers whether the passed site is active on the owning branch.
//
// Range and RecRange also provide a set of virtual functions (1 per force) for handling active
// and newly-active site management during rearrangement.  These functions are currently:
//    UpdateCRange_Rg(), UpdateOneLeggedCRange_Rg(), UpdateMRange_Rg(), UpdateRootRange_Rg(),
//    UpdateOneLeggedRootRange_Rg(), and UpdateRRange_Rg().
//
// A "rangeset" is an ordered set of pairs.  In each pair, the first element is the start of a group of sites,
// and the second element is one past the end of that group.  So for example, you could express the idea that
// sites 1 - 10 and 15 - 19 are active with a rangeset containing (1 - 11), (15 - 20).

#ifndef RANGE_H
#define RANGE_H

#include <cassert>
#include <algorithm>
#include <iostream>
#include <stdlib.h>

#include "constants.h"
#include "rangex.h"

// Note that most functions/variables defined here have "_Rg" (for "Range") as a suffix in their name.
// This is to distinguish them from functions/variables in class Branch ("_Br") or class Tree ("_Tr") of the same name.
// Exceptions are Clone and the constructors.

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
// Base class used to represent non-recombinant Ranges and as superclass for RecRange class.

class Range
{
  private:
    Range();                              // Default ctor is undefined.
    Range & operator=(const Range & src); // Assignment operator is undefined.

    // No processing is done by Range except to present totalsites.
    // This is used when there is no recombination.

  protected:
    // Information about permanent state (they are data-dependent and never change).
    // In a non-recombinant Range, ALL sites are LIVE sites; they pass through every node and reach every tip.
    long int m_numTotalSites_Rg;        // Length of sequence.

    Range(const Range & src);           // Copy ctor is callable only by Range::Clone and RecRange copy ctor.
    long int CountLinksFromLinks_Rg(const rangeset & links) const;

    rangeset GetAllSites_Rg() const { return MakeRangeset(0, m_numTotalSites_Rg); };
    rangeset GetAllLinks_Rg() const { return MakeRangeset(0, m_numTotalSites_Rg - 1); };

  public:
    // The "real" constructor.
    Range(long int nsites);

    // Destructor
    // We accept the default destructor, which does nothing other than to call the destructor for each
    // element needing deallocation (the STL objects).  Even though it is empty, we need to declare it
    // so we can make it VIRTUAL (the compiler default dtor is NON-virtual).
    virtual ~Range() {};

    // Clone serves as a polymorphic copy constructor (handles memory allocation and returns a pointer).
    virtual Range * Clone() const;

    // Tests.
    virtual bool     SameLiveSites_Rg(const rangeset & src) const { return true; };
    virtual bool     operator==(const Range & other) const;

    // Getters.
    // Functions which ASSERT here are defined to return a rangeset simply to satisfy the compiler on return type.
    // They should never be called; hence we don't care what the rangeset they "return" contains.
    virtual bool     LiveSitesOnly_Rg()           const { return true; };
    virtual bool     IsSiteLive_Rg(long int site) const { return true; };
    virtual rangeset GetLiveSites_Rg()            const { return GetAllSites_Rg(); };
    virtual rangeset GetDiseaseSites_Rg()         const { assert(false); return rangeset(); };
    virtual rangeset GetTargetLinks_Rg()          const { assert(false); return rangeset(); };
    virtual long int GetFirstTargetLink_Rg()      const { assert(false); return FLAGLONG; };
    virtual long int NumTargetLinks_Rg()          const { assert(false); return FLAGLONG; };
    virtual rangeset GetNewTargetLinks_Rg()       const { assert(false); return rangeset(); };
    virtual long int NumNewTargetLinks_Rg()       const { assert(false); return FLAGLONG; };
    long int         NumTotalSites_Rg()           const { return m_numTotalSites_Rg; };

    // Getters for use in the factory functions in Branch; also used in debug functions, Branch::RevalidateRange.
    // Ditto above about functions here which ASSERT returning rangesets.
    virtual rangeset GetOldTargetLinks_Rg()       const { assert(false); return rangeset(); }; // Maybe shouldn't ASSERT.
    virtual rangeset GetOldTargetSites_Rg()       const { assert(false); return rangeset(); };
    virtual rangeset GetOldLiveSites_Rg()         const { assert(false); return rangeset(); };
    virtual rangeset GetTransmittedSites_Rg()     const { assert(false); return rangeset(); };
    virtual long int GetRecSite_Rg()              const;

    // Updaters.
    // The following six functions all are NO-OPs on Range objects.
    // They change member variables only on RecRange objects.
    virtual void UpdateCRange_Rg(const Range * const child1rangeptr, const Range * const child2rangeptr,
                                 const rangeset & fcsites, bool dofc);
    virtual void UpdateRootRange_Rg(const Range * const child1rangeptr, const Range * const child2rangeptr,
                                    const rangeset & fcsites, bool dofc);
    virtual void UpdateOneLeggedCRange_Rg(const Range * const childrangeptr);
    virtual void UpdateOneLeggedRootRange_Rg(const Range * const childrangeptr);
    virtual void UpdateMRange_Rg(const Range * const childrangeptr);
    virtual void UpdateRRange_Rg(const Range * const childrangeptr, const rangeset & fcsites, bool dofc);

    // When placing an inactive (hidden passages) recombination, should the branch that remains
    // in the residual tree carry the low-numbered sites (as opposed to the high-numbered sites)?
    virtual bool AreLowSitesOnInactiveBranch_Rg(long int recsite) const;
    virtual bool IsDiseaseSiteTransmitted_Rg() const;

    // Used by RecTree::Prune and Branch::ResetBuffersForNextRearrangement.
    virtual void ClearNewTargetLinks_Rg();
    virtual void SetOldInfoToCurrent_Rg();
    virtual void ResetOldTargetSites_Rg(const rangeset & fcsites);

    // Used by RBranch::IsRemovableRecombinationLeg (ASSERTs on Range object).
    virtual bool AreChildTargetSitesTransmitted_Rg(const Range * const childrangeptr, const rangeset & fcsites) const;

    // Debugging functions for Range and RecRange (virtual).
    virtual void PrintLive_Rg()              const;
    virtual void PrintInfo_Rg()              const;
    virtual void PrintNewTargets_Rg()        const;
    virtual bool NoLiveAndNoTransmittedDiseaseSites_Rg() const { return false; };
    virtual bool DifferentTargetLinks_Rg(const rangeset & src) const { return false; };
    virtual bool DifferentNewTargetLinks_Rg(const rangeset & src) const { return false; };

    // Used in revalidation to compare a branch to its child.
    virtual bool SameAsChild_Rg(const Range * const childrangeptr) const;

#if 0 // Called only in diked-out section of debugging function.
    virtual bool IsLinkTargettable_Rg(long int link) const { assert(false); return false; };
#endif
};

//------------------------------------------------------------------------------------
// Derived class used to represent recombinant Ranges.
// Full recombinant processing is done by RecRange.

class RecRange : public Range
{
  private:
    RecRange();                         // Default ctor is undefined.
    RecRange(const RecRange & src);     // Copy ctor is callable only by RecRange::Clone.
    RecRange & operator=(const RecRange & src); // Assignment operator is undefined.

    // LIVE sites pass through the branch holding this RecRange and reach one or more tips.
    rangeset m_liveSites_Rg;            // Sites currently live (transmitted from here all the way to a tip).

    // TARGETLINKS links are legal targets for recombination (variable during life of a RecRange object).
    rangeset m_diseaseSites_Rg;         // Locations of all disease traits.
    rangeset m_transmittedSites_Rg;     // Sites transmitted through this branch.
    rangeset m_targetLinks_Rg;          // Links currently targettable.
    long int m_numTargetLinks_Rg;       // Number of links currently targettable.

    // Stored so that recombinations that result from NEWTARGETLINKS can be handled reversibly.
    // Modified by recombinations in RecRange.
    rangeset m_oldTargetSites_Rg;       // Sites that framed targettable links when tree last created/modified.
    rangeset m_oldLiveSites_Rg;         // Sites that were live when this tree was last created/modified.

    // OLDTARGETLINKS were targettable before rearrangement began
    // Modified in by recombinations in RecRange.
    rangeset m_oldTargetLinks_Rg;       // Links previously targettable.

    // NEWTARGETLINKS were not legal targets before rearrangement began, but have become legal.
    rangeset m_newTargetLinks_Rg;       // Links newly targettable; m_targetLinks_Rg - m_oldTargetLinks_Rg.
    long int m_numNewTargetLinks_Rg;    // Number of links newly targettable.

  public:
    // The "real" constructor.
    RecRange(long int nsites, const rangeset & diseasesites, const rangeset & transmittedsites,
             const rangeset & livesites, const rangeset & targetlinks, const rangeset & oldtargetlinks,
             const rangeset & oldtargetsites, const rangeset & oldlivesites);

    // Destructor
    // We accept the default destructor, which does nothing other than to call the destructor for each
    // element needing deallocation (the STL objects).

    // Clone serves as a polymorphic copy constructor (handles memory allocation and returns a pointer).
    virtual Range * Clone() const;
    virtual ~RecRange() {};             // See note about dtor ~Range() above.

    // Tests.
    virtual bool     SameLiveSites_Rg(const rangeset & src) const { return m_liveSites_Rg == src; };
    virtual bool     operator==(const Range & other) const;

    // Getters.
    virtual bool     LiveSitesOnly_Rg()           const { return false; };
    virtual bool     IsSiteLive_Rg(long int site) const { return IsInRangeset(m_liveSites_Rg, site); };
    virtual rangeset GetLiveSites_Rg()            const { return m_liveSites_Rg; };
    virtual rangeset GetDiseaseSites_Rg()         const { return m_diseaseSites_Rg; };
    virtual rangeset GetTargetLinks_Rg()          const { return m_targetLinks_Rg; };
    virtual long int GetFirstTargetLink_Rg()      const { return m_targetLinks_Rg.begin()->first; };
    virtual long int NumTargetLinks_Rg()          const { return m_numTargetLinks_Rg; };

    // Getters for use in the factory functions in Branch; also used in debug functions, Branch::RevalidateRange.
    virtual rangeset GetOldTargetLinks_Rg()       const { return m_oldTargetLinks_Rg; };
    virtual rangeset GetOldTargetSites_Rg()       const { return m_oldTargetSites_Rg; };
    virtual rangeset GetOldLiveSites_Rg()         const { return m_oldLiveSites_Rg; };
    virtual rangeset GetTransmittedSites_Rg()     const { return m_transmittedSites_Rg; };
    virtual long int GetRecSite_Rg()              const;

    // Getters.
    virtual rangeset GetNewTargetLinks_Rg()       const { return m_newTargetLinks_Rg; };
    virtual long int NumNewTargetLinks_Rg()       const { return m_numNewTargetLinks_Rg; };

    // Updaters.
    // The following six functions modify a RecRange to reflect tipward changes during rearrangement,
    // including modifying m_liveSites_Rg, m_targetLinks_Rg, and m_newTargetLinks_Rg plus their respective counts.
    virtual void UpdateCRange_Rg(const Range * const child1rangeptr, const Range * const child2rangeptr,
                                 const rangeset & fcsites, bool dofc);
    virtual void UpdateRootRange_Rg(const Range * const child1rangeptr, const Range * const child2rangeptr,
                                    const rangeset & fcsites, bool dofc);
    virtual void UpdateOneLeggedCRange_Rg(const Range * const childrangeptr);
    virtual void UpdateOneLeggedRootRange_Rg(const Range * const childrangeptr);
    virtual void UpdateMRange_Rg(const Range * const childrangeptr);
    virtual void UpdateRRange_Rg(const Range * const childrangeptr, const rangeset & fcsites, bool dofc);

    // When placing an inactive (hidden passages) recombination, should the branch that remains
    // in the residual tree carry the low-numbered sites (as opposed to the high-numbered sites)?
    virtual bool AreLowSitesOnInactiveBranch_Rg(long int recsite) const;
    virtual bool IsDiseaseSiteTransmitted_Rg() const;

    // Used by RecTree::Prune and Branch::ResetBuffersForNextRearrangement.
    virtual void ClearNewTargetLinks_Rg();
    virtual void SetOldInfoToCurrent_Rg();
    virtual void ResetOldTargetSites_Rg(const rangeset & fcsites);

    // Used in RBranch::IsRemovableRecombinationLeg (recombinant case only).
    virtual bool AreChildTargetSitesTransmitted_Rg(const Range * const childrangeptr, const rangeset & fcsites) const;

    // Debugging functions for Range and RecRange (virtual).
    virtual void PrintLive_Rg()              const;
    virtual void PrintInfo_Rg()              const;
    virtual void PrintNewTargets_Rg()        const;

    virtual bool NoLiveAndNoTransmittedDiseaseSites_Rg() const
    { return (m_liveSites_Rg.empty() && !IsDiseaseSiteTransmitted_Rg()); };

    virtual bool DifferentTargetLinks_Rg(const rangeset & src) const { return m_targetLinks_Rg != src; };
    virtual bool DifferentNewTargetLinks_Rg(const rangeset & src) const { return m_newTargetLinks_Rg != src; };

    // Debugging functions for RecRange only.
    void         PrintDiseaseSites_Rg()      const;
    void         PrintRightOrLeft_Rg()       const;
    void         TestInvariants_Rg()         const;

    // Used in revalidation to compare a branch to its child; does not require m_transmittedSites_Rg to match.
    virtual bool SameAsChild_Rg(const Range * const childrangeptr) const;

#if 0 // Called only in diked-out section of debugging function.
    virtual bool IsLinkTargettable_Rg(long int link) const { return IsInRangeset(m_targetLinks_Rg, link); };
#endif
};

//------------------------------------------------------------------------------------

#endif // RANGE_H

//____________________________________________________________________________________
