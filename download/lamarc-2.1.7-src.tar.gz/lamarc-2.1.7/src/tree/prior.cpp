// $Id: prior.cpp,v 1.11 2011/10/31 22:04:51 ewalkup Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <cassert>

#include "local_build.h"

#include "prior.h"
#include "random.h"
#include "registry.h"
#include "stringx.h"
#include "ui_vars_prior.h"
#include "mathx.h"
#include "paramstat.h"
#include "defaults.h"

//------------------------------------------------------------------------------------

Prior::Prior(UIVarsPrior uiprior)
    : m_priortype(uiprior.GetPriorType()),
      m_lowerbound(uiprior.GetLowerBound()),
      m_upperbound(uiprior.GetUpperBound()),
      m_binwidth(uiprior.GetBinwidth())
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
      , m_samplingRate(uiprior.GetRelativeSampling())
#endif
{
    //We don't worry about growth, since those are constrained to not have log priors.
    m_lnlower = SafeLog(m_upperbound);
    m_lnupper = SafeLog(m_lowerbound);
}

//------------------------------------------------------------------------------------

Prior::Prior(ParamStatus shouldBeInvalid)
    : m_priortype(LINEAR),
      m_lowerbound(0),
      m_upperbound(0),
      m_lnlower(0),
      m_lnupper(0),
      m_binwidth(1)
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
      , m_samplingRate(defaults::samplingRate)
#endif
      
{
    assert(shouldBeInvalid.Status() == pstat_invalid);
}

//------------------------------------------------------------------------------------

Prior::~Prior()
{
    // intentionally blank
}

//------------------------------------------------------------------------------------

bool Prior::operator==(const Prior src) const
{
    if (m_priortype != src.m_priortype) return false;
    if (m_lowerbound != src.m_lowerbound) return false;
    if (m_upperbound != src.m_upperbound) return false;
#ifdef LAMARC_NEW_FEATURE_RELATIVE_SAMPLING
    if (m_samplingRate != src.m_samplingRate) return false;
#endif
    return true;
}

//------------------------------------------------------------------------------------

std::pair<double, double> Prior::RandomDraw() const
{
    Random& rnd = registry.GetRandom();
    double newparam, newlnparam;
    switch (m_priortype)
    {
        case LINEAR:
            newparam = rnd.Float() * (m_upperbound - m_lowerbound) + m_lowerbound;
            newlnparam = log(newparam);
            return std::make_pair<double, double>(newparam, newlnparam);
            break;
        case LOGARITHMIC:
            newlnparam = rnd.Float() * (m_lnupper - m_lnlower) + m_lnlower;
            newparam = exp(newlnparam);
            return std::make_pair<double, double>(newparam, newlnparam);
            break;
    }
    string e = "Unknown prior type " + ToString(m_priortype) +
        " in Parameter::DrawFromPrior";
    throw implementation_error(e);
} // DrawFromPrior

//____________________________________________________________________________________
