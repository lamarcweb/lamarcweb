// $Id: undoredochain.cpp,v 1.24 2011/03/07 06:08:53 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#include <stack>
#include <iostream>
#include "errhandling.h"
#include "undoredochain.h"
#include "ui_vars.h"

UndoRedoChain::UndoRedoChain(DataPack& datapack,string fileName,UIInterface* ui)
    : defaultVars(datapack,fileName,ui)
{
}

UndoRedoChain::~UndoRedoChain()
{
    DeleteDoneItems();
    DeleteUndoneItems();
}

void UndoRedoChain::StartNewFrame()
{
    UIVars * nextVars = new UIVars(GetCurrentVars());
    done.push(nextVars);
}

void UndoRedoChain::RejectNewFrame()
{
    UIVars * clobberMe = done.top();
    done.pop();
    delete clobberMe;
}

void UndoRedoChain::AcceptNewFrame()
{
    DeleteUndoneItems();
}

void UndoRedoChain::Undo()
{
    if(CanUndo())
    {
        UIVars * vars = done.top();
        done.pop();
        undone.push(vars);
    }
    else
    {
        // well, we could throw an error here if
        // ever we try to undo when we can't,
        // but it seems reasonable to just do
        // nothing.
    }
}

void UndoRedoChain::Redo()
{
    if(CanRedo())
    {
        UIVars * vars = undone.top();
        undone.pop();
        done.push(vars);
    }
    else
    {
        // well, we could throw an error here if
        // ever we try to redo when we can't,
        // but it seems reasonable to just do
        // nothing.
    }
}

bool UndoRedoChain::CanUndo()
{
    return (!(done.empty()));
}

bool UndoRedoChain::CanRedo()
{
    return (!(undone.empty()));
}

std::string UndoRedoChain::GetUndoDescription()
{
    if(CanUndo())
    {
#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
        UndoRedo * action = done.top();
        return action->GetUndoDescription();
#endif
        return "UNDO LAST CHANGE";
    }
    else
    {
        throw UndoRedoCannotUndo();
    }
}

std::string UndoRedoChain::GetRedoDescription()
{
    if(CanRedo())
    {
#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
        UndoRedo * action = undone.top();
        return action->GetRedoDescription();
#endif
        return "REDO LAST CHANGE";
    }
    else
    {
        throw UndoRedoCannotRedo();
    }
}

void UndoRedoChain::DeleteDoneItems()
{
    while(!(done.empty()))
    {
        UIVars * clobberMe = done.top();
        done.pop();
        delete clobberMe;
    }
}

void UndoRedoChain::DeleteUndoneItems()
{
    while(!(undone.empty()))
    {
        UIVars * clobberMe = undone.top();
        undone.pop();
        delete clobberMe;
    }
}

UIVars & UndoRedoChain::GetCurrentVars()
{
    if(!(done.empty()))
        return *(done.top());
    else
        return defaultVars;
}

//____________________________________________________________________________________
