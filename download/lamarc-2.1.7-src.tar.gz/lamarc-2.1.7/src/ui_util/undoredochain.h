// $Id: undoredochain.h,v 1.19 2011/03/07 06:08:53 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef UNDOREDOCHAIN_H
#define UNDOREDOCHAIN_H

#include <stack>
#include <stdexcept>
#include <string>

#include "errhandling.h"
#include "ui_vars.h"

class DataPack;
class UIInterface;

/// stores stacks of done and undone changes
class UndoRedoChain
{
  private:
    UIVars defaultVars;           /// factory settings
    std::stack<UIVars*> done;     /// actions we've done
    std::stack<UIVars*> undone;   /// actions we've done & undone

    UndoRedoChain();

  protected:
    void DeleteUndoneItems();           /// remove items from undone stack
    /// and delete them
    void DeleteDoneItems();             /// remove items from done stack
    /// and delete them

  public:
    UndoRedoChain(DataPack& datapack,std::string fileName,UIInterface* ui);
    ~UndoRedoChain();
    void StartNewFrame();               /// start next undo-able action
    void AcceptNewFrame();              /// commit to action in last StartNewFrame()
    void RejectNewFrame();              /// back out of action in last StartNewFrame()
    void Undo();                        /// Undo last action done
    void Redo();                        /// Redo last action done
    bool CanUndo();
    bool CanRedo();
    std::string GetUndoDescription();
    std::string GetRedoDescription();
    UIVars & GetCurrentVars();
};

class UndoRedoCannotUndo : public std::exception
{
  private:
    std::string _what;
  public:
    UndoRedoCannotUndo(): _what ("Nothing to undo") {};
    virtual ~UndoRedoCannotUndo() throw() {};
    virtual const char* what () const throw() { return _what.c_str (); };
};

class UndoRedoCannotRedo : public std::exception
{
  private:
    std::string _what;
  public:
    UndoRedoCannotRedo(): _what ("Nothing to redo") {};
    virtual ~UndoRedoCannotRedo() throw() {};
    virtual const char* what () const throw() { return _what.c_str (); };
};

#endif  // UNDOREDOCHAIN_H

//____________________________________________________________________________________
