// $Id: batchconverter.cpp,v 1.22 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "batchconverter.h"
#include "gc_cmdline.h"
#include "gc_data.h"
#include "gc_datastore.h"
#include "gc_errhandling.h"
#include "gc_strings.h"
#include "tinyxml.h"
#include "wx/cmdline.h"

BatchConverterApp::BatchConverterApp()
    : GCCmdLineManager()
{
}

BatchConverterApp::~BatchConverterApp()
{
}

IMPLEMENT_APP(BatchConverterApp)

void
BatchConverterApp::OnInitCmdLine(wxCmdLineParser& parser)
{
    wxAppConsole::OnInitCmdLine(parser);
    GCCmdLineManager::AddOptions(parser);
}

bool
BatchConverterApp::OnCmdLineParsed(wxCmdLineParser& parser)
{
    bool parentReturned = wxAppConsole::OnCmdLineParsed(parser);
    GCCmdLineManager::ExtractValues(parser);
    return parentReturned;
}

bool
BatchConverterApp::OnInit()
{
    return wxAppConsole::OnInit();
}

int
BatchConverterApp::OnRun()
{
    try
    {
        // EWFIX.P4 LATER -- break up command line and command file processing
        int exitCode = GCCmdLineManager::ProcessCommandLineAndCommandFile(m_dataStore);
        if(exitCode == 0)
        {
            exitCode = GCCmdLineManager::DoExport(m_dataStore);
        }
        if(exitCode == 0)
        {
            wxLogMessage(gcstr::batchSafeFinish);
        }
        return exitCode;
    }
    catch(const gc_fatal_error& e)
    {
        wxLogError(wxString::Format(gcerr::fatalError));
        return 2;
    }
    catch(const std::exception& f)
    {
        wxLogError(wxString::Format(gcerr::uncaughtException,f.what()));
        return 2;
    }

    return 3;       // EWFIX.P3 -- what should this be?
}

int
BatchConverterApp::OnExit()
{
    if(m_doDebugDump)
    {
        m_dataStore.DebugDump();
    }
    if(! m_batchOutName.IsEmpty())
    {
        TiXmlDocument * doc = m_dataStore.ExportBatch();
        m_dataStore.WriteBatchFile(doc,m_batchOutName);
        delete doc;
    }

    m_dataStore.NukeContents();
    return wxAppConsole::OnExit();
}

//____________________________________________________________________________________
