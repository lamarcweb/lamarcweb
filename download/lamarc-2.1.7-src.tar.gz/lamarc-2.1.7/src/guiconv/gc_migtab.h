// $Id: gc_migtab.h,v 1.2 2011/12/07 21:08:48 ewalkup Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_MIGTAB_H
#define GC_MIGTAB_H

#include "gc_clickpanel.h"
#include "gc_gridpanel.h"

class wxWindow;


class gcMigCell : public gcClickCell
{
  private:
    gcMigCell();            // undefined
    size_t                  m_cellId;
    matrix_cell_type        m_cellType;

  protected:
  public:
    gcMigCell(wxWindow * parent, GCStructures & st_var, const size_t cellId, matrix_cell_type cellType);
    ~gcMigCell();

    void        ToDataStore(GCStructures & st_var, wxString newText);

    size_t       GetCellId();
    matrix_cell_type   GetCellType();

    void    NotifyLeftDClick();
};

class gcDivCell : public gcClickCell
{
  private:
    gcDivCell();            // undefined
    size_t                  m_cellId;
    matrix_cell_type        m_cellType;

  protected:
  public:
    gcDivCell(wxWindow * parent, GCStructures & st_var, const size_t cellId, bool isParent, matrix_cell_type cellType);
    ~gcDivCell();

    void        ToDataStore(GCStructures & st_var, wxString newText);

    size_t       GetCellId();
    matrix_cell_type   GetCellType();

    void    NotifyLeftDClick();
};

class gcMigTab : public gcInfoPane
{
  private:
    gcMigTab();        // undefined
    wxWindow *         m_parent;

  protected:
    wxPanel *   MakeContent();
    wxString    MakeLabel();

  public:
    gcMigTab(wxWindow * parent, GCLogic & logic);
    virtual ~gcMigTab();
};

#endif  // GC_MIGTAB_H

//____________________________________________________________________________________
