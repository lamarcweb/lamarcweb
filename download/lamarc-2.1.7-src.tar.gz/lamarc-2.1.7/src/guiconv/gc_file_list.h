// $Id: gc_file_list.h,v 1.13 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_FILELIST_H
#define GC_FILELIST_H

#include "gc_gridpanel.h"
#include "wx/button.h"
#include "wx/checkbox.h"
#include "wx/choice.h"
#include "wx/radiobox.h"

class GCFile;
class GCParse;
class wxBitmap;
class wxWindow;

class GCExclaimBitmap : public wxStaticBitmap
{
  private:
    GCExclaimBitmap();    // undefined
  protected:
  public:
    static const wxBitmap & emptyBitmap();
    static const wxBitmap & exclBitmap();

    GCExclaimBitmap(wxPanel * panel, bool hasExclaim);
    virtual ~GCExclaimBitmap();
};

class gcFilePane : public gcGridPane
{
  private:
    gcFilePane();           // undefined
  protected:
  public:
    gcFilePane(wxWindow * parent);
    virtual ~gcFilePane();
    virtual void NotifyLeftDClick(size_t row, size_t col);

};

class GCFileList : public gcInfoPane
{
  private:
    GCFileList();        // undefined

  protected:
    wxPanel * MakeContent();
    wxString  MakeLabel();

  public:
    GCFileList(wxWindow * parent, GCLogic & logic);
    virtual ~GCFileList();
};

#endif  // GC_FILELIST_H

//____________________________________________________________________________________
