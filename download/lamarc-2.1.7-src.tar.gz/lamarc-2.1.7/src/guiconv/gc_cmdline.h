// $Id: gc_cmdline.h,v 1.13 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_CMDLINE_H
#define GC_CMDLINE_H

#include "wx/string.h"

class wxCmdLineParser;
class GCDataStore;

class GCCmdLineManager
{
  protected:
    wxString        m_commandFileName;
    wxString        m_outputFileName;
    wxArrayString   m_inputFileNames;
    bool            m_batchOnly;
    bool            m_doDebugDump;
    wxString        m_batchOutName;

    void AddOptions(wxCmdLineParser& parser);
    void ExtractValues(wxCmdLineParser& parser);
    int  ProcessCommandLineAndCommandFile(  GCDataStore& dataStore);
    int  DoExport(GCDataStore& dataStore);

  public:
    GCCmdLineManager();
    virtual ~GCCmdLineManager();
};

#endif  // GC_CMDLINE_H

//____________________________________________________________________________________
