// $Id: gc_frame.h,v 1.55 2012/02/15 18:13:41 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_FRAME_H
#define GC_FRAME_H

#include "wx/wx.h"
#include "wx/notebook.h"

class wxSplitterWindow;
class GCLogic;
class gcInfoPane ;
class GCAssignmentTab ;
class gcMigTab;

class GCFrame : public wxFrame
// outer-most frame in the converter application
{
  private:
    GCLogic         &   m_logic;    // interface with back end storage

    wxPanel             * m_logPanel;
    wxTextCtrl          * m_logText;
    wxLog               * m_oldLog;
    wxPanel             * m_basePanel;
    wxBookCtrlBase      * m_bookCtrl;
    wxBoxSizer          * m_sizerFrame;

    gcInfoPane          * m_filePanel;
    GCAssignmentTab     * m_gridPanel;
    gcMigTab            * m_migPanel;
    
    wxWindow *m_topLogWin;
    wxWindow *m_botLogWin;

    wxMenu          *   m_fileMenu;
    wxMenu          *   m_insertMenu;
    wxMenu          *   m_viewMenu;

    wxMenuItem      *   m_verbose;

    void DispatchDataEvent              (wxCommandEvent& event);
    void DispatchMenuEvent              (wxCommandEvent& event);
    void DispatchScreenEvent            (wxCommandEvent& event);

    void SetUpMenus                     ();
    void EnableMenus                    ();

  protected:

  public:
    GCFrame();
    GCFrame(const wxString& title, GCLogic & logic);
    virtual ~GCFrame();

    void UpdateUserCues                 ();
    void OnNotebookCtrl(wxNotebookEvent& event);

    DECLARE_EVENT_TABLE()
};

// name for each notebook page
#define DATA_FILES        wxT("Data Files")
#define DATA_PARTITIONS   wxT("Data Partitions")
#define MIGRATION_MATRIX  wxT("Migration Matrix")
#define LOG_TEXT          wxT("Debug Log")

#endif  // GC_FRAME_H

//____________________________________________________________________________________
