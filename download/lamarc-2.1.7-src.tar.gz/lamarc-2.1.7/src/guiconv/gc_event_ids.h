// $Id: gc_event_ids.h,v 1.60 2011/12/01 22:32:42 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_EVENT_IDS_H
#define GC_EVENT_IDS_H

// It's safer to put all these in a single header file,
// thus ensuring all event ids get a different value.
// However, it does mean that a single change in the
// GUI events means nearly everything needs to be recompiled.
// If this gets to be a problem, we should consider breaking
// this enum up. One likely possibility would be to put the
// GC_*, S2D_* and D2S_* events in different enums. At this
// writing (10/14/2004) S2D_* event id's are only generated
// by events of type SCREEN_2_DATA (and similar for D2S_* and
// DATA_2_SCREEN) so a number collision with other events would
// likely not cause confusion.

enum GCEventId
{
    gcEvent_Generic    = 1,

    gcEvent_Debug_Dump,

    gcEvent_CmdFile_Read,

    gcEvent_File_Add,
    gcEvent_File_Edit,
    gcEvent_File_Export,
    gcEvent_Batch_Export,

    gcEvent_LinkG_Add,

    gcEvent_Locus_Add,

    gcEvent_Pop_Add,
    gcEvent_Pop_Edit,

    gcEvent_ToggleVerbose,

    gcEvent_ViewToggle_InputFiles,
    gcEvent_ViewToggle_Partitions,

    //////////////////

    GC_EditCancel,
    GC_EditDelete,
    GC_EditOK,
    //
    //
    GC_LinkGMerge,
    GC_LinkGRemove,
    GC_LinkGRename,
    //
    //
    GC_TraitAdd,
    GC_TraitRemove,
    GC_TraitRename,
    //

    // injected into event space by GCFrame after dispatching any
    // S2D event. This event marks the end of a possible series
    // of other D2S events that cause screen updates to be cached
    D2S_UserInteractionPhaseEnd,

    // dialog buttons
    GC_MigParseTakeFile,
    GC_MigParseTakeUser,
    GC_ExportCancel,
    GC_ExportContinue,
    GC_ExportEdit,

    GC_SelectAll,
    GC_UnselectAll,
    
    // divergence button
    GC_Divergence
};

#endif  // GC_EVENT_IDS_H

//____________________________________________________________________________________
