// $Id: gc_assigntab.h,v 1.15 2012/02/15 18:13:41 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_ASSIGNTAB_H
#define GC_ASSIGNTAB_H

#include "gc_clickpanel.h"
#include "gc_gridpanel.h"
#include "gc_quantum.h"
//#include "wx/notebook.h"

class wxPanel;
class wxWindow;
class constBlockVector;
class gcLocus;
class gcPanel;
class GCParseBlock;
class gcPopulation;
class gcRegion;
class gcParent;
class GCStructures;

class gcBlockCell : public gcClickCell
{
  private:
  protected:
    size_t      m_blockId;
  public:
    gcBlockCell(wxWindow * parent, const GCParseBlock &);
    virtual ~gcBlockCell();
    void NotifyLeftDClick();
};

class gcPopCell : public gcClickCell
{
  private:
  protected:
    size_t      m_popId;
  public:
    gcPopCell(wxWindow * parent, const gcPopulation &);
    virtual ~gcPopCell();

    void    NotifyLeftDClick();
};

class gcRegionCell : public gcClickCell
{
  private:
  protected:
    size_t      m_regionId;
  public:
    gcRegionCell(wxWindow * parent, const gcRegion &);
    virtual ~gcRegionCell();

    void    NotifyLeftDClick();
};

class gcLocusCell : public gcClickCell
{
  private:
  protected:
    size_t      m_locusId;
  public:
    gcLocusCell(wxWindow * parent, const gcLocus &);
    virtual ~gcLocusCell();

    void    NotifyLeftDClick();
};

class gcPanelCell : public gcClickCell
{
  private:
  protected:
    size_t      m_panelId;
  public:
    gcPanelCell(wxWindow * parent, const gcPanel &);
    virtual ~gcPanelCell();

    void    NotifyLeftDClick();
};

class gcEmptyCell : public wxPanel
{
  private:
  protected:
    wxStaticBoxSizer * m_sizer;
    
  public:
    gcEmptyCell(wxWindow * parent);
    virtual ~gcEmptyCell();
};

class gcDivergenceToggleCell : public gcClickCell
{
  private:
    bool m_divergenceOn;
  public:
    gcDivergenceToggleCell(wxWindow * parent, bool divergenceOn, int unused);
    virtual ~gcDivergenceToggleCell();

    void    NotifyLeftDClick();
};

class gcPanelsToggleCell : public gcClickCell
{
  private:
    bool m_panelsOn;
  public:
    gcPanelsToggleCell(wxWindow * parent, bool panelsOn);
    virtual ~gcPanelsToggleCell();

    void    NotifyLeftDClick();
};

class gcActor_PanelsToggle : public gcEventActor
{
  public:
    gcActor_PanelsToggle() {};
    virtual ~gcActor_PanelsToggle() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};


class gcParentCell : public gcClickCell
{
  private:
  protected:
    size_t      m_parentId;
  public:
    gcParentCell(wxWindow * parent, const gcParent &);
    virtual ~gcParentCell();

    void    NotifyLeftDClick();
};

class GCAssignmentTab : public gcInfoPane
{
  private:
    GCAssignmentTab();        // undefined

  protected:
    wxPanel *   MakeContent();
    wxString    MakeLabel();
    wxPanel *   blockControl(wxWindow *, constBlockVector &);

  public:
    GCAssignmentTab(wxWindow * parent, GCLogic & logic);
    //GCAssignmentTab(wxBookCtrlBase * parent, GCLogic & logic);
    virtual ~GCAssignmentTab();
};

#endif  // GC_ASSIGNTAB_H

//____________________________________________________________________________________
