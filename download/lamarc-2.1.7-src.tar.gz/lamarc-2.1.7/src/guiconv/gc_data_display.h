// $Id: gc_data_display.h,v 1.8 2012/02/15 18:13:41 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_DATA_DISPLAY_H
#define GC_DATA_DISPLAY_H

#include "wx/gbsizer.h"

class GCDataDisplaySizer : public wxGridBagSizer
{
  private: 
    int m_offset;
  public:
    GCDataDisplaySizer();
    virtual ~GCDataDisplaySizer();
    void SetOffset(int offset);
    int  GetOffset();
    
    void AddPop(wxWindow * header,int rowIndex, int length);
    void AddRegion(wxWindow * header,size_t firstLocus, size_t lastLocus);
    void AddLocus(wxWindow * header, size_t locusIndex);
    void AddData(wxWindow * header, int rowIndex, int colIndex);
    void AddPanel(wxWindow * header, int rowIndex, int colIndex, int lastCol);
    void AddDivergenceToggleCell(wxWindow * header);
    void AddPanelsToggleCell(wxWindow * header);
    void AddParent(wxWindow * header,size_t parIndex, int parLevel, int parSpan);
};

#endif  // GC_DATA_DISPLAY_H

//____________________________________________________________________________________
