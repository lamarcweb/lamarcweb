// $Id: gc_quantum.cpp,v 1.14 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_default.h"
#include "gc_quantum.h"
#include "wx/log.h"

size_t GCQuantum::s_objCount = 0;

GCQuantum::GCQuantum()
    :
    m_objId(s_objCount++),
    m_name(gcdefault::unnamedObject),
    m_selected(false)
{
}

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)
GCQuantum::GCQuantum(wxString name)
    :
    m_objId(s_objCount++),
    m_name(name),
    m_selected(false)
{
}
#endif

GCQuantum::~GCQuantum()
{
}

size_t
GCQuantum::GetId() const
{
    return m_objId;
}

#if 0  // Potentially DEAD CODE (bobgian, Feb 2010)

bool
GCQuantum::GetSelected() const
{
    return m_selected;
}

void
GCQuantum::SetSelected(bool selected)
{
    m_selected=selected;
}

#endif

void
GCQuantum::DebugDump(wxString prefix) const
{
    wxLogDebug("%sid:%d",prefix.c_str(),(int)m_objId);  // EWDUMPOK
}

wxString
GCQuantum::GetName() const
{
    return m_name;
}

void
GCQuantum::SetName(wxString name)
{
    m_name = name;
}

void
GCQuantum::ReportMax()
{
    wxLogDebug("created %d numbered objects",(int)s_objCount);  // EWDUMPOK
}

//------------------------------------------------------------------------------------

GCClientData::GCClientData(gcEventActor * myActor)
    :   m_myActor(myActor)
{
}

GCClientData::~GCClientData()
{
    delete m_myActor;
}

gcEventActor *
GCClientData::GetActor()
{
    return m_myActor;
}

//____________________________________________________________________________________
