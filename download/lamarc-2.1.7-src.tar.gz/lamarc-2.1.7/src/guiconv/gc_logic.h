// $Id: gc_logic.h,v 1.43 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_LOGIC_H
#define GC_LOGIC_H

#include <vector>
#include "wx/wx.h"
#include "gc_datastore.h"
#include "gc_types.h"

class GuiConverterApp;
class wxWindow;

class GCLogic   : public GCDataStore
{
    friend class GuiConverterApp;               // for SetDisplayParent()

  private:
    wxWindow        *   m_displayParent;    // for centering windows

  protected:

    void SetDisplayParent(wxWindow * win);

  public:
    GCLogic();
    ~GCLogic();

    void        GCFatalBatchWarnGUI(wxString msg) const;
    void        GCError  (wxString msg) const;
    void        GCInfo   (wxString msg) const;
    void        GCWarning(wxString msg) const;

    void    batchFileRejectGuiLog(wxString msg,size_t lineNo) const;
    bool    guiQuestionBatchLog(wxString msg,wxString stopButton, wxString continueButton) const;

    void    GettingBusy(const wxString& msg) const;
    void    LessBusy(const wxString& msg) const;
};

#endif  // GC_LOGIC_H

//____________________________________________________________________________________
