// $Id: guiconverter.h,v 1.13 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GUICONVERTER_H
#define GUICONVERTER_H

#include "wx/wx.h"
#include "gc_cmdline.h"
#include "gc_logic.h"

class wxCmdLineParser;
class GCFrame;

class GuiConverterApp: public wxApp, public GCCmdLineManager
                       // main gui converter application
{
  protected:
    GCLogic         m_logic;
    GCFrame     *   m_mainFrame;

  public:
    GuiConverterApp();
    virtual ~GuiConverterApp();

    virtual bool    OnCmdLineParsed(wxCmdLineParser&);
    virtual int     OnExit();
    virtual bool    OnInit();
    virtual void    OnInitCmdLine(wxCmdLineParser&);
    virtual int     OnRun();
};

#endif  // GUICONVERTER_H

//____________________________________________________________________________________
