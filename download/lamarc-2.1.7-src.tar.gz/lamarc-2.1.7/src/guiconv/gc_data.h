// $Id: gc_data.h,v 1.31 2011/12/01 22:32:42 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_DATA_H
#define GC_DATA_H

#include "gc_types.h"
#include "gc_strings_mig.h"
#include "wx/arrstr.h"
#include "wx/list.h"

class gcdata
{
  public:
    static const wxArrayString fileFormatChoices();
    static const wxArrayString specificDataTypeChoices();
    static const wxArrayString interleavingChoices();
    static const wxArrayString genericLocusChoices();
    static const wxArrayString genericPopulationChoices();
    static const wxArrayString genericRegionChoices();
    static const wxArrayString integerList();
    static const wxArrayString integerListWithSpaces();
    static const wxArrayString nonNegativeIntegerList();
    static const wxArrayString positiveFloatChars();
    
    static const wxArrayString migrationConstraints();
    static const wxArrayString migrationMethods();
    static const wxArrayString migrationProfiles();

    static const size_t defaultHapCount;

    static const long defaultMapPosition;
    static const long defaultOffset;
    static const long noLengthSet;
    static const long noMapPositionSet;
    static const long noMarkerCountSet;
    static const long noOffsetSet;
    static const long noStyle;

    static const GCFileFormat   defaultFileFormat;

    static const gcGeneralDataType  allDataTypes();
    static const gcGeneralDataType  allelicDataTypes();
    static const gcGeneralDataType  nucDataTypes();

    static wxString getPloidyString(size_t ploidy);
};

bool                 ProduceBoolFromProximityOrBarf(wxString string);
bool                 ProduceBoolFromYesNoOrBarf(wxString string);
GCFileFormat         ProduceGCFileFormatOrBarf(wxString string, bool allowUnknown=true);
gcGeneralDataType    ProduceGeneralDataTypeOrBarf(wxString string, bool allowUnknown=true);
gcSpecificDataType   ProduceSpecificDataTypeOrBarf(wxString string, bool allowUnknown=true);
GCInterleaving       ProduceGCInterleavingOrBarf(wxString string, bool allowUnknown=true);
migration_method     ProduceMigMethodOrBarf(wxString string);
migration_profile    ProduceMigProfileOrBarf(wxString string);
migration_constraint ProduceMigConstraintOrBarf(wxString string);

wxString        ToWxString(bool);
wxString        ToWxStringLinked(bool);
wxString        ToWxString(gcGeneralDataType);
wxString        ToWxString(gcSpecificDataType);
wxString        ToWxString(GCFileFormat);
wxString        ToWxString(GCInterleaving);
wxString        ToWxString(gcPhaseSource);
wxString        ToWxString(loc_match);
wxString        ToWxString(pop_match);
wxString        ToWxString(migration_method);
wxString        ToWxString(migration_profile);
wxString        ToWxString(migration_constraint);

#endif  // GC_DATA_H

//____________________________________________________________________________________
