// $Id: gc_matrix_display.cpp,v 1.1 2011/12/01 22:32:42 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_matrix_display.h"
#include "gc_layout.h"
#include "wx/log.h"

GCMatrixDisplaySizer::GCMatrixDisplaySizer()
    : wxGridBagSizer(gclayout::borderSize,gclayout::borderSize)
{
}

GCMatrixDisplaySizer::~GCMatrixDisplaySizer()
{
}

void
GCMatrixDisplaySizer::AddCell(wxWindow * matrix, size_t xpos, size_t ypos)
{
    Add(matrix,wxGBPosition(xpos, ypos),wxGBSpan(1,1),wxALL | wxEXPAND);
    //wxLogMessage(wxT("xpos %i ypos %i"), xpos, ypos);
}


//____________________________________________________________________________________
