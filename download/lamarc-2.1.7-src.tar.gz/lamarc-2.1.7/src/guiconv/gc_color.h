// $Id: gc_color.h,v 1.5 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_COLOR_H
#define GC_COLOR_H

class wxColour;

class gccolor
{
  public:
    static const wxColour & selectedFile();
    static const wxColour & enteredObject();
    static const wxColour & activeObject();
};

#endif  // GC_COLOR_H

//____________________________________________________________________________________
