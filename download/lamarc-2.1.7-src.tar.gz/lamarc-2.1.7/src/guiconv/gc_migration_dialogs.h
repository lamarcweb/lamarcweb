// $Id: gc_migration_dialogs.h,v 1.2 2011/12/30 22:50:10 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_MIGRATION_DIALOGS_H
#define GC_MIGRATION_DIALOGS_H

#include "gc_dialog.h"
#include "gc_quantum.h"
#include "gc_validators.h"

class GCDataStore;
class wxWindow;

//------------------------------------------------------------------------------------

class gcMigrationRate : public gcTextHelper
{
  private:
    gcMigrationRate();       // undefined
    size_t                  m_migrationId;
  protected:
  public:
    gcMigrationRate(size_t migrationId);
    ~gcMigrationRate();

    wxString    FromDataStore(GCDataStore &);
    void        ToDataStore(GCDataStore &, wxString newText);
};

//------------------------------------------------------------------------------------

class gcMigrationMethodChoice : public gcChoiceObject
{
  private:
    gcMigrationMethodChoice();        // undefined
    size_t                          m_migrationId;
    migration_method                m_type;
    wxCheckBox *                    m_box;
  protected:
  public:
    gcMigrationMethodChoice(size_t forThisId, migration_method type);
    ~gcMigrationMethodChoice();

    void        UpdateDisplayInitial    (GCDataStore &) ;
    void        UpdateDisplayInterim    (GCDataStore &) ;
    void        UpdateDataInterim       (GCDataStore &) ;
    void        UpdateDataFinal         (GCDataStore &) ;

    wxWindow *  MakeWindow(wxWindow * parent)           ;
    wxWindow *  FetchWindow()                           ;

    size_t      GetRelevantId();
};

//------------------------------------------------------------------------------------

class gcMigrationProfileChoice : public gcChoiceObject
{
  private:
    gcMigrationProfileChoice();        // undefined
    size_t                          m_migrationId;
    migration_profile               m_type;
    wxCheckBox *                    m_box;
  protected:
  public:
    gcMigrationProfileChoice(size_t forThisId, migration_profile type);
    ~gcMigrationProfileChoice();

    void        UpdateDisplayInitial    (GCDataStore &) ;
    void        UpdateDisplayInterim    (GCDataStore &) ;
    void        UpdateDataInterim       (GCDataStore &) ;
    void        UpdateDataFinal         (GCDataStore &) ;

    wxWindow *  MakeWindow(wxWindow * parent)           ;
    wxWindow *  FetchWindow()                           ;

    size_t      GetRelevantId();
};

//------------------------------------------------------------------------------------

class gcMigrationConstraintChoice : public gcChoiceObject
{
  private:
    gcMigrationConstraintChoice();        // undefined
    size_t                          m_migrationId;
    migration_constraint            m_type;
    wxCheckBox *                    m_box;
  protected:
  public:
    gcMigrationConstraintChoice(size_t forThisId, migration_constraint type);
    ~gcMigrationConstraintChoice();

    void        UpdateDisplayInitial    (GCDataStore &) ;
    void        UpdateDisplayInterim    (GCDataStore &) ;
    void        UpdateDataInterim       (GCDataStore &) ;
    void        UpdateDataFinal         (GCDataStore &) ;

    wxWindow *  MakeWindow(wxWindow * parent)           ;
    wxWindow *  FetchWindow()                           ;

    size_t      GetRelevantId();
};

//------------------------------------------------------------------------------------

class gcMigrationEditDialog : public gcUpdatingDialog
{
  private:
  protected:
    size_t          m_migrationId;
    void    DoDelete() {};  // satisfy compiler, now does the same as cancel
  public:
    gcMigrationEditDialog(  wxWindow *      parentWindow,
                            GCDataStore &   dataStore,
                            size_t          migrationId,
                            wxString        fromName,
                            wxString        toName,
                            bool            forJustCreatedObj);
    virtual ~gcMigrationEditDialog();
};

//------------------------------------------------------------------------------------

bool DoDialogEditMigration( wxWindow *      parentWindow,
                            GCDataStore &   dataStore,
                            size_t          migrationId,
                            bool            forJustCreatedObj);



//------------------------------------------------------------------------------------

class gcActor_MigrationEdit : public gcEventActor
{
  private:
    gcActor_MigrationEdit();       // undefined
    size_t                      m_migrationId;

  public:
    gcActor_MigrationEdit(size_t migrationId) : m_migrationId(migrationId) {};
    virtual ~gcActor_MigrationEdit() {};
    virtual bool OperateOn(wxWindow * parent, GCDataStore & dataStore);
};

#endif  // GC_MIGRATION_DIALOGS_H
//____________________________________________________________________________________
