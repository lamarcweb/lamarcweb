// $Id: gc_loci_match.h,v 1.11 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_LOCI_MATCH_H
#define GC_LOCI_MATCH_H

#include "gc_types.h"
#include "wx/arrstr.h"

class GCParse;

class GCLocusSpec
{
  private:
    bool            m_blessedLocus;
    bool            m_blessedRegion;
    wxString        m_locusName;
    wxString        m_regionName;
    GCLocusSpec();    // undefined

  public:
    GCLocusSpec(bool blessedLocus, bool blessedRegion, wxString locusName, wxString regionName);
    virtual ~GCLocusSpec();

    bool        GetBlessedLocus()   const ;
    bool        GetBlessedRegion()  const ;
    wxString    GetLocusName()      const ;
    wxString    GetRegionName()     const ;
};

class GCLocusMatcher
{
  protected:
    loc_match       m_locMatchType;
    wxArrayString   m_locNames;

  public:
    GCLocusMatcher();
    GCLocusMatcher(loc_match locMatchType);
    GCLocusMatcher(loc_match locMatchType, wxString name);
    GCLocusMatcher(loc_match locMatchType, wxArrayString names);
    ~GCLocusMatcher();
    GCLocusSpec GetLocSpec(size_t index, const GCParse & parse) const ;
    bool        HandlesThisManyLoci(size_t count) const ;
    loc_match   GetLocMatchType() const ;

    const wxArrayString &   GetLociNames()  const;
};

#endif  // GC_LOCI_MATCH_H

//____________________________________________________________________________________
