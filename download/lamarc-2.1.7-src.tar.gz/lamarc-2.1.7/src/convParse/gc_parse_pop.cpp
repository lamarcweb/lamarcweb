// $Id: gc_parse_pop.cpp,v 1.5 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <cassert>

#include "gc_default.h"
#include "gc_parse_pop.h"

//------------------------------------------------------------------------------------

GCParsePop::GCParsePop( const GCParse * parse,
                        size_t          indexInParse,
                        wxString        name)
    :
    m_parse(parse),
    m_indexInParse(indexInParse),
    m_name(name)
{
    assert(m_parse != NULL);
}

GCParsePop::~GCParsePop()
{
}

const GCParse &
GCParsePop::GetParse() const
{
    return *m_parse;
}

size_t
GCParsePop::GetIndexInParse() const
{
    return m_indexInParse;
}

wxString
GCParsePop::GetName() const
{
    return m_name;
}

//____________________________________________________________________________________
