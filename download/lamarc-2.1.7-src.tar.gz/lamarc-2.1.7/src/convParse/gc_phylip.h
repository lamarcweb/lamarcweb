// $Id: gc_phylip.h,v 1.16 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_PHYLIP_H
#define GC_PHYLIP_H

#include "gc_parser.h"
#include "gc_types.h"

class GCFile;
class GCParse;

class GCPhylipParser : public GCParser
{
  private:
    GCPhylipParser();           // undefined

  protected:
    void ParseTopPhylipLine(size_t              *   numSequences,
                            size_t              *   numSites,
                            bool                *   hasWeights);
    bool ParsePhylipWeightsLine(size_t numSites, wxString fileName);
    bool CompleteParse  (GCParse&);

  public:
    GCPhylipParser(const GCDataStore&);
    virtual ~GCPhylipParser();

    GCParse * Parse(GCFile &            fileRef,
                    gcGeneralDataType   dataType,
                    GCInterleaving      interleaving);

    void BadFirstToken  (wxString token) const;
    void BadSecondToken (wxString token) const;
};

#endif  // GC_PHYLIP_H

//____________________________________________________________________________________
