// $Id: gc_population.h,v 1.14 2012/02/15 18:13:41 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_POPULATION_H
#define GC_POPULATION_H

#include "gc_quantum.h"
#include "wx/string.h"

class GCStructures;

class gcPopulation : public GCQuantum
{
    friend class GCStructures;

  private:
    bool    m_blessed;
    size_t  m_parentID;      // used by divergence
    int     m_displayOrder;  // used by divergence
    int     m_index;         // used by lam_conv

    void    SetBlessed(bool blessed);

  public:
    gcPopulation();
    virtual ~gcPopulation();
    bool    GetBlessed() const ;
    
    int     GetDispIndex()          const;
    void    SetDispIndex(int index);
    
    void    SetParentId(size_t id);
    void    ClearParent();  
    size_t  GetParentId() const;
    bool    HasParent() const;
    
    void    SetDispOrder(int order);
    int     GetDispOrder() const; 
    bool    HasDispOrder() const;
    
    void    DebugDump(wxString prefix=wxEmptyString) const;
};

#endif  // GC_POPULATION_H

//____________________________________________________________________________________
