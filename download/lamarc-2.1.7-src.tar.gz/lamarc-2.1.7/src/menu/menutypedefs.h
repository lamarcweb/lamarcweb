// $Id: menutypedefs.h,v 1.4 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef MENUTYPEDEFS_H
#define MENUTYPEDEFS_H

#include <memory>

class NewMenu;
//typedef boost::shared_ptr<NewMenu> NewMenu_ptr;

typedef std::auto_ptr<NewMenu> NewMenu_ptr;

class MenuInteraction;

//typedef boost::shared_ptr<MenuInteraction> MenuInteraction_ptr;

typedef std::auto_ptr<MenuInteraction> MenuInteraction_ptr;

#endif // MENUTYPEDEFS_H

//____________________________________________________________________________________
