// $Id: menuinteraction.h,v 1.9 2011/03/07 06:08:51 bobgian Exp $

/*
  Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef MENUINTERACTION_H
#define MENUINTERACTION_H

#include "menudefs.h" // for menu_return_type

class Display;

class MenuInteraction
{
  public:
    MenuInteraction();
    virtual ~MenuInteraction();
    virtual menu_return_type InvokeMe(Display& display) = 0;
};

#endif // MENUINTERACTION_H

//____________________________________________________________________________________
