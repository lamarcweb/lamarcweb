// $Id: menu_strings.h,v 1.16 2011/03/07 06:08:51 bobgian Exp $

/*
 *  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein
 *
 *  This software is distributed free of charge for non-commercial use
 *  and is copyrighted.  Of course, we do not guarantee that the software
 *  works, and are not responsible for any damage you may cause or have.
 *
 */

#ifndef MENU_STRINGS_H
#define MENU_STRINGS_H

#include <string>

class key
{
  public:
    static const std::string dot;
    static const std::string R;
    static const std::string Q;
};

class menustr
{
  public:
    static const std::string acknowledge;
    static const std::string bottomLine;
    static const std::string bottomLineAtTop;
    static const std::string divider;
    static const std::string carriageReturn;
    static const std::string emptyString;
    static const std::string inconsistencies;
    static const std::string space;
    static const std::string initial;
    static const std::string final;
    static const std::string chains;
    static const std::string discard;
    static const std::string interval;
    static const std::string samples;
};

#endif // MENU_STRINGS_H

//____________________________________________________________________________________
