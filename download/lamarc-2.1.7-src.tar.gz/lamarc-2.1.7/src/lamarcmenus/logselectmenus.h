// $Id: logselectmenus.h,v 1.4 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef LOGSELECTMENUS_H
#define LOGSELECTMENUS_H

#include <string>
#include "newmenuitems.h"
#include "setmenuitem.h"

class UIInterface;

class LogisticSelectionCoefficientMenuItem : public SetMenuItemId
{
  public:
    LogisticSelectionCoefficientMenuItem(std::string myKey, UIInterface & myui);
    ~LogisticSelectionCoefficientMenuItem();
    bool IsVisible();
};

class LogisticSelectionMenu : public NewMenu
{
  public:
    LogisticSelectionMenu(UIInterface & myui);
    virtual ~LogisticSelectionMenu();
};

class LogisticSelectionMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    LogisticSelectionMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~LogisticSelectionMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new LogisticSelectionMenu(ui));};
};

#endif  // LOGSELECTMENUS_H

//____________________________________________________________________________________
