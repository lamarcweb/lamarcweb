// $Id: traitmodelmenu.h,v 1.5 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef TRAITMODELMENU_H
#define TRAITMODELMENU_H

#include "newmenuitems.h"
#include "setmenuitem.h"
#include "ui_regid.h"

class TraitModelItem : public SubMenuItem
{
  public:
    TraitModelItem(string key, UIInterface& ui);
    ~TraitModelItem();
    virtual bool IsVisible();
    virtual std::string GetVariableText();
};

class TraitModelsMenu : public NewMenu
{
  public:
    TraitModelsMenu(UIInterface & myui);
    ~TraitModelsMenu();
};

class TraitModelsMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    TraitModelsMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~TraitModelsMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new TraitModelsMenu(ui));};
};

class SubMenuItemsTraitModels : public MenuDisplayGroupBaseImplementation
{
  public:
    SubMenuItemsTraitModels(UIInterface & myui);
    virtual ~SubMenuItemsTraitModels();
    virtual vector<UIId> GetVisibleIds();
    virtual MenuInteraction_ptr GetHandler(std::string input);
    virtual MenuInteraction_ptr MakeOneHandler(UIId id);
    virtual string GetText(UIId id);
    virtual string GetKey(UIId id);
    virtual string GetVariableText(UIId id);
};

class SingleTraitModelMenu : public NewMenu
{
  private:
    UIId m_id;
  public:
    SingleTraitModelMenu(UIInterface& ui, UIId id);
    virtual ~SingleTraitModelMenu();
    string Title();
};

class MenuDisplayTraitAnalysisType : public MenuDisplayLine
{
  private:
    MenuDisplayTraitAnalysisType();
    UIRegId m_regId;
    UIInterface & m_ui;
  protected:
    UIId& GetId();
  public:
    MenuDisplayTraitAnalysisType(UIInterface& ui, UIId id);
    virtual ~MenuDisplayTraitAnalysisType();
    virtual std::string GetKey();
    virtual std::string GetText();
    virtual std::string GetVariableText();
    virtual bool Handles(std::string) {return false;};
};

class MenuDisplayTraitRange : public MenuDisplayLine
{
  private:
    MenuDisplayTraitRange();
    UIRegId m_regId;
    UIInterface & m_ui;
  protected:
    UIId& GetId();
  public:
    MenuDisplayTraitRange(UIInterface& ui, UIId id);
    virtual ~MenuDisplayTraitRange();
    virtual std::string GetKey();
    virtual std::string GetText();
    virtual std::string GetVariableText();
    virtual bool Handles(std::string) {return false;};
};

class AddRangeToTraitModel : public SetMenuItemId
{
  public:
    AddRangeToTraitModel(string key, UIInterface& ui, UIId id);
    virtual ~AddRangeToTraitModel();
    virtual string GetVariableText();
    virtual MenuInteraction_ptr GetHandler(std::string key);
};

class SetAddRangeDialog  : public SetDialog
{
  public:
    SetAddRangeDialog(UIInterface& ui, string key, UIId id);
    virtual ~SetAddRangeDialog();
    virtual string inLoopOutputString();
};

class RemoveRangeFromTraitModel : public SetMenuItemId
{
  public:
    RemoveRangeFromTraitModel(string key, UIInterface& ui, UIId id);
    virtual ~RemoveRangeFromTraitModel();
    virtual string GetVariableText();
    virtual MenuInteraction_ptr GetHandler(std::string key);
};

class TraitModelRangeToPointMenu : public SetMenuItemId
{
  public:
    TraitModelRangeToPointMenu(string key, UIInterface& ui, UIId id);
    virtual ~TraitModelRangeToPointMenu();
    virtual string GetVariableText();
};

class SetRemoveRangeDialog  : public SetDialog
{
  public:
    SetRemoveRangeDialog(UIInterface& ui, string key, UIId id);
    virtual ~SetRemoveRangeDialog();
    virtual string inLoopOutputString();
};

#endif  // TRAITMODELMENU_H

//____________________________________________________________________________________
