// $Id: popsizemenu.cpp,v 1.5 2010/03/17 17:25:59 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "lamarc_strings.h"
#include "popsizemenu.h"
#include "ui_interface.h"
#include "ui_strings.h"

using std::string;

EffectivePopSizeMenu::EffectivePopSizeMenu(UIInterface & myui)
    : NewMenu(myui,lamarcmenu::effectivePopSizeTitle,
              lamarcmenu::effectivePopSizeInfo)
{
    AddMenuItem(new EffectivePopSizeGroup(ui));
}

EffectivePopSizeMenu::~EffectivePopSizeMenu()
{
}

EffectivePopSizeGroup::EffectivePopSizeGroup(UIInterface& myui)
    : SetMenuItemGroup(myui,uistr::effectivePopSize)
{
}

EffectivePopSizeGroup::~EffectivePopSizeGroup()
{
}

UIIdVec1d
EffectivePopSizeGroup::GetVisibleIds()
{
    vector<UIId> visibleIds;
    LongVec1d regionNumbers = ui.doGetLongVec1d(uistr::regionNumbers);
    LongVec1d::iterator i;
    for(i=regionNumbers.begin(); i != regionNumbers.end(); i++)
    {
        visibleIds.push_back(UIId(*i));
    }
    return visibleIds;
}

string EffectivePopSizeGroup::GetText(UIId id)
{
    return lamarcmenu::effectivePopSizeFor + ui.doGetString(uistr::regionName,id);
}

//____________________________________________________________________________________
