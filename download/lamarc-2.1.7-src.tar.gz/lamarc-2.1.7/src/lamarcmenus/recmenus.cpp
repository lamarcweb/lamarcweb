// $Id: recmenus.cpp,v 1.11 2010/03/17 17:25:59 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "constraintmenus.h"
#include "lamarc_strings.h"
#include "newmenuitems.h"
#include "priormenus.h"
#include "recmenus.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "profilemenus.h"

RecombineMaxEventsMenuItem::RecombineMaxEventsMenuItem(string myKey, UIInterface & myui)
    : SetMenuItemNoId(myKey,myui,uistr::recombinationMaxEvents)
{
}

RecombineMaxEventsMenuItem::~RecombineMaxEventsMenuItem()
{
}

bool RecombineMaxEventsMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::recombination);
}

RecombineRateMenuItem::RecombineRateMenuItem(string myKey, UIInterface & myui)
    : SetMenuItemId(myKey,myui,uistr::recombinationRate, UIId(force_REC, uiconst::GLOBAL_ID))
{
}

RecombineRateMenuItem::~RecombineRateMenuItem()
{
}

bool RecombineRateMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::recombination);
}

RecombinationMenu::RecombinationMenu (UIInterface & myui )
    : NewMenu (myui,lamarcmenu::recTitle,lamarcmenu::recInfo)
{
    AddMenuItem(new ToggleMenuItemNoId("X",ui,uistr::recombination));
    UIId id(force_REC);
    AddMenuItem(new SubMenuConstraintsForOneForce("C",ui,id));
    AddMenuItem(new SubMenuProfileForOneForce("P",ui,id));
    AddMenuItem(new SubMenuPriorForOneForce("B",ui,id));
    AddMenuItem(new RecombineRateMenuItem("S",ui));
    AddMenuItem(new RecombineMaxEventsMenuItem("M",ui));
}

RecombinationMenu::~RecombinationMenu ()
{
}

//____________________________________________________________________________________
