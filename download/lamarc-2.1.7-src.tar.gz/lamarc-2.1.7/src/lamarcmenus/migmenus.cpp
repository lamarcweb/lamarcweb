// $Id: migmenus.cpp,v 1.13 2010/03/17 17:25:58 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "constraintmenus.h"
#include "lamarc_strings.h"
#include "menu_strings.h"
#include "matrixitem.h"
#include "migmenus.h"
#include "newmenuitems.h"
#include "priormenus.h"
#include "setmenuitem.h"
#include "ui_constants.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "overviewmenus.h"
#include "profilemenus.h"

using std::string;

//------------------------------------------------------------------------------------

SetAllMigrationsMenuItem::SetAllMigrationsMenuItem(string myKey, UIInterface & myui)
    : SetMenuItemId(myKey,myui,uistr::globalMigration, UIId(force_MIG, uiconst::GLOBAL_ID))
{
}

SetAllMigrationsMenuItem::~SetAllMigrationsMenuItem()
{
}

bool SetAllMigrationsMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::migration);
}

string SetAllMigrationsMenuItem::GetVariableText()
{
    return "";
}

//------------------------------------------------------------------------------------

SetMigrationsFstMenuItem::SetMigrationsFstMenuItem(string key,UIInterface & ui)
    : ToggleMenuItemNoId(key,ui,uistr::fstSetMigration)
{
}

SetMigrationsFstMenuItem::~SetMigrationsFstMenuItem()
{
}

bool SetMigrationsFstMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::migration);
}

//------------------------------------------------------------------------------------

MigrationMaxEventsMenuItem::MigrationMaxEventsMenuItem(string myKey,UIInterface & myui)
    : SetMenuItemNoId(myKey,myui,uistr::migrationMaxEvents)
{
}

MigrationMaxEventsMenuItem::~MigrationMaxEventsMenuItem()
{
}

bool MigrationMaxEventsMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::migration);
}

///

MigrationMenu::MigrationMenu (UIInterface & myui )
    : NewMenu (myui,lamarcmenu::migTitle,lamarcmenu::migInfo)
{
    AddMenuItem(new DisplayOnlyMenuItem(uistr::migration, ui));
    UIId id(force_MIG);
    AddMenuItem(new SubMenuConstraintsForOneForce("C",ui,id));
    AddMenuItem(new SubMenuProfileForOneForce("P",ui,id));
    AddMenuItem(new SubMenuPriorForOneForce("B",ui,id));
    AddMenuItem(new SetAllMigrationsMenuItem("G",ui));
    AddMenuItem(new SetMigrationsFstMenuItem("F",ui));
    AddMenuItem(new MatrixSetMenuItem(ui,
                                      uistr::migrationInto,
                                      uistr::migrationUser,
                                      uistr::migrationPartitionCount,
                                      uistr::migration,
                                      force_MIG));

    AddMenuItem(new MigrationMaxEventsMenuItem("M",ui));
}

MigrationMenu::~MigrationMenu ()
{
}

//____________________________________________________________________________________
