// $Id: treesummenus.h,v 1.13 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef TREESUMMENUS_H
#define TREESUMMENUS_H

#include <string>
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"

class UIInterface;

class SetMenuItemTreeSumInFileName : public SetMenuItemNoId
{
  public:
    SetMenuItemTreeSumInFileName(std::string myKey, UIInterface & myui);
    virtual ~SetMenuItemTreeSumInFileName();
    virtual bool IsVisible();
};

class SetMenuItemTreeSumOutFileName : public SetMenuItemNoId
{
  public:
    SetMenuItemTreeSumOutFileName(std::string myKey, UIInterface & myui);
    virtual ~SetMenuItemTreeSumOutFileName();
    virtual bool IsVisible();
};

class TreeSumInMenu : public NewMenu
{
  public:
    TreeSumInMenu(UIInterface & myui);
    ~TreeSumInMenu();
};

class TreeSumOutMenu : public NewMenu
{
  public:
    TreeSumOutMenu(UIInterface & myui);
    ~TreeSumOutMenu();
};

class TreeSumInMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    TreeSumInMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~TreeSumInMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new TreeSumInMenu(ui));};
};

class TreeSumOutMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    TreeSumOutMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~TreeSumOutMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new TreeSumOutMenu(ui));};
};

class TreeSumInSubMenuItem : public SubMenuItem
{
  public:
    TreeSumInSubMenuItem(std::string myKey, UIInterface & myUI);
    virtual std::string GetVariableText();
};

class TreeSumOutSubMenuItem : public SubMenuItem
{
  public:
    TreeSumOutSubMenuItem(std::string myKey, UIInterface & myUI);
    virtual std::string GetVariableText();
};

#endif  // TREESUMMENUS_H

//____________________________________________________________________________________
