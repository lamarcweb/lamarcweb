// $Id: divmigmenus.cpp,v 1.1 2012/02/15 18:13:42 jmcgill Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "constraintmenus.h"
#include "lamarc_strings.h"
#include "menu_strings.h"
#include "matrixitem.h"
#include "divmigmenus.h"
#include "newmenuitems.h"
#include "priormenus.h"
#include "setmenuitem.h"
#include "ui_constants.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "overviewmenus.h"
#include "profilemenus.h"

using std::string;

//------------------------------------------------------------------------------------

SetAllDivMigsMenuItem::SetAllDivMigsMenuItem(string myKey, UIInterface & myui)
    : SetMenuItemId(myKey,myui,uistr::globalDivMigration, UIId(force_DIVMIG, uiconst::GLOBAL_ID))
{
}

SetAllDivMigsMenuItem::~SetAllDivMigsMenuItem()
{
}

bool SetAllDivMigsMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::divmigration);
}

string SetAllDivMigsMenuItem::GetVariableText()
{
    return "";
}
/* // don't know how to do this with divergence yet
//------------------------------------------------------------------------------------

SetDivMigsFstMenuItem::SetDivMigsFstMenuItem(string key,UIInterface & ui)
    : ToggleMenuItemNoId(key,ui,uistr::fstSetMigration)
{
}

SetDivMigsFstMenuItem::~SetDivMigsFstMenuItem()
{
}

bool SetDivMigsFstMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::divmigration);
}
*/
//------------------------------------------------------------------------------------

DivMigMaxEventsMenuItem::DivMigMaxEventsMenuItem(string myKey,UIInterface & myui)
    : SetMenuItemNoId(myKey,myui,uistr::divmigrationMaxEvents)
{
}

DivMigMaxEventsMenuItem::~DivMigMaxEventsMenuItem()
{
}

bool DivMigMaxEventsMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::divmigration);
}

///

DivMigMenu::DivMigMenu (UIInterface & myui )
    : NewMenu (myui,lamarcmenu::divMigTitle,lamarcmenu::divMigInfo)
{
    AddMenuItem(new DisplayOnlyMenuItem(uistr::divmigration, ui));
    UIId id(force_DIVMIG);
    
    AddMenuItem(new SubMenuConstraintsForOneForce("C",ui,id));
    AddMenuItem(new SubMenuProfileForOneForce("P",ui,id));
    AddMenuItem(new SubMenuPriorForOneForce("B",ui,id));
    AddMenuItem(new SetAllDivMigsMenuItem("G",ui));
    //AddMenuItem(new SetDivMigsFstMenuItem("F",ui)); // not currently functional
    
    AddMenuItem(new MatrixSetMenuItem(ui,
                                      uistr::divmigrationInto,
                                      uistr::divmigrationUser,
                                      uistr::divmigrationPartitionCount,
                                      uistr::divmigration,
                                      force_DIVMIG));
    
    AddMenuItem(new DivMigMaxEventsMenuItem("M",ui));
    
    
}

DivMigMenu::~DivMigMenu ()
{
}

//____________________________________________________________________________________
