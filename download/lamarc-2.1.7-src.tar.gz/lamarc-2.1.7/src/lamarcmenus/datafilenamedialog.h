// $Id: datafilenamedialog.h,v 1.7 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef DATAFILENAMEDIALOG_H
#define DATAFILENAMEDIALOG_H

#include "dialogrepeat.h"
#include <string>

class XmlParser;

class DataFileNameDialog : public DialogRepeat
{
  private:
    std::string    m_dataFileName;
    XmlParser &    m_parser;
    std::string    m_errmsg;

  protected:
    virtual long maxTries();
    virtual std::string beforeLoopOutputString();
    virtual std::string inLoopOutputString();
    virtual std::string inLoopFailureOutputString();
    virtual std::string afterLoopSuccessOutputString();
    virtual std::string afterLoopFailureOutputString();
    virtual bool handleInput(std::string input);
    virtual std::string displayFileName();
    virtual void doFailure();

  public:
    DataFileNameDialog(XmlParser &);
    virtual ~DataFileNameDialog();
};

#endif // DATAFILENAMEDIALOG_H

//____________________________________________________________________________________
