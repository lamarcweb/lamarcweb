// $Id: lamarcheaderdialog.h,v 1.7 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2003  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef LAMARCHEADERDIALOG_H
#define LAMARCHEADERDIALOG_H

#include "dialognoinput.h"
#include <string>

class LamarcHeaderDialog : public DialogNoInput
{
  protected:
    virtual std::string outputString();
  public:
    LamarcHeaderDialog();
    virtual ~LamarcHeaderDialog();
};

#endif // LAMARCHEADERDIALOG_H

//____________________________________________________________________________________
