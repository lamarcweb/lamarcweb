// $Id: diseasemenus.h,v 1.14 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef DISEASEMENUS_H
#define DISEASEMENUS_H

#include <string>
#include <vector>
#include "newmenuitems.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"

class UIInterface;

class SetAllDiseaseRatesMenuItem : public SetMenuItemId
{
  public:
    SetAllDiseaseRatesMenuItem(std::string myKey, UIInterface & myui);
    virtual ~SetAllDiseaseRatesMenuItem();
    virtual bool IsVisible();
    virtual std::string GetVariableText();
};

// Specializes SetMenuItemNoId to be visible only when the
// disease force is turned on
class DiseaseMaxEventsMenuItem : public SetMenuItemNoId
{
  public:
    DiseaseMaxEventsMenuItem(std::string myKey, UIInterface & myui);
    virtual ~DiseaseMaxEventsMenuItem();
    virtual bool IsVisible();
};

// Specializes SetMenuItemNoId to be visible only when the
// disease force is turned on
class DiseaseLocationMenuItem : public SetMenuItemNoId
{
  public:
    DiseaseLocationMenuItem(std::string myKey, UIInterface & myui);
    virtual ~DiseaseLocationMenuItem();
    virtual bool IsVisible();
};

class DiseaseMenu : public NewMenu
{
  public:
    DiseaseMenu(UIInterface & myui);
    virtual ~DiseaseMenu();
};

class DiseaseMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    DiseaseMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~DiseaseMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new DiseaseMenu(ui));};
};

#endif  // DISEASEMENUS_H

//____________________________________________________________________________________
