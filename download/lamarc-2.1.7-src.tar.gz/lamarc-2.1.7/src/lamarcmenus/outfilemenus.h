// $Id: outfilemenus.h,v 1.15 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef OUTFILEMENUS_H
#define OUTFILEMENUS_H

#include <string>
#include "newmenuitems.h"

class UIInterface;

class OutfileMenu : public NewMenu
{
  public:
    OutfileMenu(UIInterface & myui);
    ~OutfileMenu();
};

class OutfileMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    OutfileMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~OutfileMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new OutfileMenu(ui));};
};

// menu line giving access to OutfileMenu
class OutfileSubMenuItem : public SubMenuItem
{
  public:
    OutfileSubMenuItem(std::string myKey,UIInterface & myUI);
    virtual std::string GetVariableText();
};

#endif  // OUTFILEMENUS_H

//____________________________________________________________________________________
