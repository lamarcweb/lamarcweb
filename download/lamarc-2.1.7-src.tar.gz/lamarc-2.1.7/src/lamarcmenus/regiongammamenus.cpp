// $Id: regiongammamenus.cpp,v 1.3 2010/03/17 17:25:59 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include <string>
#include "constants.h"
#include "constraintmenus.h"
#include "lamarc_strings.h"
#include "newmenuitems.h"
#include "forcesmenus.h"
#include "regiongammamenus.h"
#include "setmenuitem.h"
#include "togglemenuitem.h"
#include "ui_interface.h"
#include "ui_strings.h"
#include "profilemenus.h"

RegionGammaShapeParameterMenuItem::RegionGammaShapeParameterMenuItem(string myKey, UIInterface & myui)
    : SetMenuItemId(myKey,myui,uistr::regionGammaShape, UIId(force_REGION_GAMMA, uiconst::GLOBAL_ID))
{
}

RegionGammaShapeParameterMenuItem::~RegionGammaShapeParameterMenuItem()
{
}

bool RegionGammaShapeParameterMenuItem::IsVisible()
{
    return ui.doGetBool(uistr::regionGamma);
}

RegionGammaMenu::RegionGammaMenu (UIInterface & myui )
    : NewMenu (myui,lamarcmenu::regionGammaTitle,lamarcmenu::regionGammaInfo)
{
    AddMenuItem(new ToggleMenuItemNoId("X",ui,uistr::regionGamma));
    UIId id(force_REGION_GAMMA);
    AddMenuItem(new SubMenuConstraintsForOneForce("C",ui,id));
    AddMenuItem(new SubMenuProfileForOneForce("P",ui,id));
    AddMenuItem(new RegionGammaShapeParameterMenuItem("S",ui));
}

RegionGammaMenu::~RegionGammaMenu ()
{
}

//____________________________________________________________________________________
