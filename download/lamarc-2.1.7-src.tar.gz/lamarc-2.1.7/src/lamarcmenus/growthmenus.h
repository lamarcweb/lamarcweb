// $Id: growthmenus.h,v 1.16 2011/03/07 06:08:50 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GROWTHMENUS_H
#define GROWTHMENUS_H

#include <string>
#include <vector>
#include "newmenu.h"
#include "setmenuitem.h"
#include "newmenuitems.h"

class UIInterface;

class SetAllGrowthMenuItem : public SetMenuItemId
{
  public:
    SetAllGrowthMenuItem(std::string myKey, UIInterface & myui);
    virtual ~SetAllGrowthMenuItem();
    virtual bool IsVisible();
    virtual std::string GetVariableText();
};

class SetMenuItemGrowths : public SetMenuItemGroup
{
  public:
    SetMenuItemGrowths(UIInterface & ui);
    virtual ~SetMenuItemGrowths();
    virtual std::vector<UIId> GetVisibleIds();
};

class ToggleMenuItemGrowthScheme : public ToggleMenuItemNoId
{
  public:
    ToggleMenuItemGrowthScheme(std::string myKey, UIInterface& myui);
    virtual ~ToggleMenuItemGrowthScheme();
    virtual bool IsVisible();
};

class ToggleMenuItemGrowthType : public ToggleMenuItemNoId
{
  public:
    ToggleMenuItemGrowthType(std::string myKey, UIInterface& myui);
    virtual ~ToggleMenuItemGrowthType();
    virtual bool IsVisible();
};

class GrowthMenu : public NewMenu
{
  public:
    GrowthMenu(UIInterface & myui);
    virtual ~GrowthMenu();
};

class GrowthMenuCreator : public NewMenuCreator
{
  protected:
    UIInterface & ui;
  public:
    GrowthMenuCreator(UIInterface & myui) : ui(myui) {};
    virtual ~GrowthMenuCreator() {};
    NewMenu_ptr Create() { return NewMenu_ptr(new GrowthMenu(ui));};
};

#endif  // GROWTHMENUS_H

//____________________________________________________________________________________
