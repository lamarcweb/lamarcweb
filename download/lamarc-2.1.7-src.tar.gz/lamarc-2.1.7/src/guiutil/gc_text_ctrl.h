// $Id: gc_text_ctrl.h,v 1.6 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_TEXT_CTRL_H
#define GC_TEXT_CTRL_H

#include "wx/textctrl.h"

class GCTextInput : public wxTextCtrl
{

  private:
    GCTextInput();       // undefined
  public:
    GCTextInput(wxWindow * parentWindow,const wxValidator& validator);
    virtual ~GCTextInput();
};

class GCIntegerInput : public GCTextInput
{
  private:
    GCIntegerInput();       // undefined
  public:
    GCIntegerInput(wxWindow * parentWindow);
    virtual ~GCIntegerInput();
};

class GCNonNegativeIntegerInput : public GCTextInput
{
  private:
    GCNonNegativeIntegerInput();       // undefined
  public:
    GCNonNegativeIntegerInput(wxWindow * parentWindow);
    virtual ~GCNonNegativeIntegerInput();
};

#endif  // GC_TEXT_CTRL_H

//____________________________________________________________________________________
