// $Id: gc_clickpanel.h,v 1.7 2012/05/02 19:20:18 ewalkup Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_CLICKPANEL_H
#define GC_CLICKPANEL_H

#include "wx/sizer.h"
#include "wx/stattext.h"
#include "wx/wx.h"

class gcClickCell;

class gcClickPanel : public wxPanel
{
  private:
  protected:
    wxBoxSizer *        m_sizer;
  public:
    gcClickPanel(gcClickCell * parent);
    virtual ~gcClickPanel();

    void AddText(wxString text);
    void CenterText(wxString text);
    void OnMouse(wxMouseEvent & event);
    void RecursiveSetColour(wxColour c);

    void        FinishSizing();

    DECLARE_EVENT_TABLE()
};

class gcClickCell : public wxPanel
{
  private:
    gcClickCell();         // undefined
  protected:
    wxStaticBoxSizer *      m_sizer;
    gcClickPanel *          m_clickPanel;
    bool                    m_mouseInCell;
#ifdef LAMARC_COMPILE_MACOSX
    int                     m_clickCount;  // HACK.HACK.HACK - 10.7 counts things wrong apparently
#endif
    
    void        FinishSizing();
  public:
    gcClickCell(wxWindow * parent, wxString label);
    virtual ~gcClickCell();

    void OnMouse(wxMouseEvent & event);
    void RecursiveSetColour(wxColour c);

    virtual void NotifyEntering     ();
    virtual void NotifyLeaving      ();
    virtual void NotifyLeftDClick   ();
    virtual void NotifyLeftDown     ();
    virtual void NotifyLeftUp       ();

    void AddText(wxString text);
    void CenterText(wxString text);

    DECLARE_EVENT_TABLE()
};

class gcClickText : public wxStaticText
{
  private:
    gcClickText();       // undefined
  protected:
    gcClickPanel *     m_parent;
  public:
    gcClickText(gcClickPanel * parent,wxString label);
    virtual ~gcClickText();

    void OnMouse(wxMouseEvent & event);

    DECLARE_EVENT_TABLE()
};

#endif  // GC_CLICKPANEL_H

//____________________________________________________________________________________
