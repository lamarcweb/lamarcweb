// $Id: gc_validators.cpp,v 1.6 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_data.h"
#include "gc_validators.h"

//------------------------------------------------------------------------------------

GCIntegerValidator::GCIntegerValidator()
    :
    wxTextValidator(wxFILTER_INCLUDE_CHAR_LIST)
{
    SetIncludes(gcdata::integerList());
}

GCIntegerValidator::~GCIntegerValidator()
{
}

//------------------------------------------------------------------------------------

GCIntegerListValidator::GCIntegerListValidator()
    :
    wxTextValidator(wxFILTER_INCLUDE_CHAR_LIST)
{
    SetIncludes(gcdata::integerListWithSpaces());
}

GCIntegerListValidator::~GCIntegerListValidator()
{
}

//------------------------------------------------------------------------------------

GCNonNegativeIntegerValidator::GCNonNegativeIntegerValidator()
    :
    wxTextValidator(wxFILTER_INCLUDE_CHAR_LIST)
{
    SetIncludes(gcdata::nonNegativeIntegerList());
}

GCNonNegativeIntegerValidator::~GCNonNegativeIntegerValidator()
{
}

//------------------------------------------------------------------------------------

GCPositiveFloatValidator::GCPositiveFloatValidator()
    :
    wxTextValidator(wxFILTER_INCLUDE_CHAR_LIST)
{
    SetIncludes(gcdata::positiveFloatChars());
}

GCPositiveFloatValidator::~GCPositiveFloatValidator()
{
}

//____________________________________________________________________________________
