// $Id: gc_strings_parse.h,v 1.6 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_STRINGS_PARSE_H
#define GC_STRINGS_PARSE_H

#include "wx/string.h"

class gcerr_parse
{
  public:
    static const wxString extraFileData;
    static const wxString ignoringPhylipWeights;
};

class gcstr_parse
{
  public:
    static const wxString parsingDone;
    static const wxString parsingStarting;
};

#endif  // GC_STRINGS_PARSE_H

//____________________________________________________________________________________
