// $Id: gc_strings_mig.h,v 1.2 2011/12/30 22:50:10 jmcgill Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_STRINGS_MIG_H
#define GC_STRINGS_MIG_H

#include "wx/string.h"

class gcstr_mig
{
  public:
    static const wxString internalName;
    static const wxString migmethodUser;
    static const wxString migmethodFST;
    static const wxString migprofileNone;
    static const wxString migprofileFixed;
    static const wxString migprofilePercentile;
    static const wxString migconstraintInvalid;
    static const wxString migconstraintConstant;
    static const wxString migconstraintSymmetric;
    static const wxString migconstraintUnconstained;
};

#endif  //GC_STRINGS_MIG_H

//____________________________________________________________________________________
