// $Id: gc_strings_trait.h,v 1.7 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef GC_STRINGS_TRAIT_H
#define GC_STRINGS_TRAIT_H

#include "wx/string.h"

class gcerr_trait
{
  public:
    static const wxString alleleMissing;
    static const wxString alleleNameReuse;
    static const wxString alleleNameSpaces;
    static const wxString alleleTraitMismatch;
    static const wxString hapProbabilityNegative;
    static const wxString phenoTraitMismatch;
    static const wxString phenotypeMissing;
    static const wxString phenotypeNameReuse;
};

class gcstr_trait
{
  public:
    static const wxString alleleListMember;
    static const wxString generatedName;
    static const wxString internalName;
};

#endif  // GC_STRINGS_TRAIT_H

//____________________________________________________________________________________
