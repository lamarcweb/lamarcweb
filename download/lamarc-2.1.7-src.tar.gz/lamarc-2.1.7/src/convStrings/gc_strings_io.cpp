// $Id: gc_strings_io.cpp,v 1.5 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "gc_strings_io.h"
#include "wx/intl.h"

const wxString gc_io::eof           =   wxTRANSLATE("possible premature end of file");
const wxString gc_io::fileMissing   =   wxTRANSLATE("File %s missing or unreadable.");
const wxString gc_io::fileReadError =   wxTRANSLATE("Unknown error reading file.");
const wxString gc_io::fileReadErrorWithName =   wxTRANSLATE("Unknown error reading file %s.");

//____________________________________________________________________________________
