// $Id: tixml_base.cpp,v 1.7 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "errhandling.h"
#include "stringx.h"
#include "tinyxml.h"
#include "tixml_base.h"

const std::string tibasestr::EXTRA_TAG_0     =   "incorrect xml: extra tag \"";
const std::string tibasestr::EXTRA_TAG_1     =   "\".";
const std::string tibasestr::MISSING_TAG_0   =   "incorrect xml: missing tag \"";
const std::string tibasestr::MISSING_TAG_1   =   "\".";
const std::string tibasestr::NOT_DOUBLE_0    =   "incorrect xml: tag \"";
const std::string tibasestr::NOT_DOUBLE_1    =   "\" is not a double.";
const std::string tibasestr::NOT_LONG_0      =   "incorrect xml: tag \"";
const std::string tibasestr::NOT_LONG_1      =   "\" is not an integer.";
const std::string tibasestr::NOT_SIZE_T_0    =   "incorrect xml: tag \"";
const std::string tibasestr::NOT_SIZE_T_1    =   "\" is not a non-negative integer.";

TiXmlElement *
ti_singleElement(TiXmlElement* ancestor, std::string nodeName,bool required)
{
    TiXmlNode * firstChild = ancestor->IterateChildren(nodeName,NULL);
    if(firstChild == NULL)
    {
        if(required)
        {
            incorrect_xml_missing_tag e(tibasestr::MISSING_TAG_0+nodeName+tibasestr::MISSING_TAG_1,nodeName);
            throw e;
        }
        return NULL;
    }
    TiXmlNode * secondChild = ancestor->IterateChildren(nodeName,firstChild);
    if (secondChild != NULL)
    {
        incorrect_xml_extra_tag e(tibasestr::EXTRA_TAG_0+nodeName+tibasestr::EXTRA_TAG_1,nodeName);
        throw e;
        return NULL;
    }
    return firstChild->ToElement();
}

TiXmlElement *
ti_optionalChild(TiXmlElement* ancestor, std::string nodeName)
{
    return ti_singleElement(ancestor,nodeName,false);
}

TiXmlElement *
ti_requiredChild(TiXmlElement* ancestor, std::string nodeName)
{
    return ti_singleElement(ancestor,nodeName,true);
}

std::string
ti_nodeText(TiXmlElement * node)
{
    std::string outstring;
    TiXmlNode * child = NULL;
    while((child = node->IterateChildren(child)))
    {
        TiXmlHandle handle(child);
        if(handle.Text())
        {
            outstring += child->Value();
        }
    }
    StripLeadingSpaces(outstring);
    StripTrailingSpaces(outstring);
    return outstring;
}

bool
ti_hasAttribute(TiXmlElement * node, std::string attrName)
{
    const std::string * attrValue = node->Attribute(attrName);
    return (attrValue != NULL);
}

std::string
ti_attributeValue(TiXmlElement * node, std::string attrName)
{
    const std::string * attrValue = node->Attribute(attrName);
    if(attrValue == NULL) return std::string("");
    return (*attrValue);
}

double
ti_double_from_text(TiXmlElement * node)
{
    std::string nodeText = ti_nodeText(node);
    double value = DBL_BIG;
    try
    {
        value = ProduceDoubleOrBarf(nodeText);
    }
    catch(data_error f)
    {
        incorrect_xml_not_double e(tibasestr::NOT_DOUBLE_0+nodeText+tibasestr::NOT_DOUBLE_1,nodeText);
        throw e;
    }
    return value;
}

long
ti_long_from_text(TiXmlElement * node) throw(incorrect_xml)
{
    std::string nodeText = ti_nodeText(node);
    long value = LONG_MAX;
    try
    {
        value = ProduceLongOrBarf(nodeText);
    }
    catch(data_error f)
    {
        incorrect_xml_not_long e(tibasestr::NOT_LONG_0+nodeText+tibasestr::NOT_LONG_1,nodeText);
        throw e;
    }
    return value;
}

size_t
ti_size_t_from_text(TiXmlElement * node) throw(incorrect_xml)
{
    long value = ti_long_from_text(node);
    if(value < 0)
    {
        std::string nodeText = ti_nodeText(node);
        incorrect_xml_not_size_t e(tibasestr::NOT_SIZE_T_0+nodeText+tibasestr::NOT_SIZE_T_1,nodeText);
        throw e;
    }
    return (size_t)value;
}

std::vector<TiXmlElement *>
ti_optionalChildren(TiXmlElement* ancestor, std::string nodeName)
{
    std::vector<TiXmlElement *> returnVec;
    TiXmlNode * child = NULL;
    while((child = ancestor->IterateChildren(nodeName, child)))
    {
        returnVec.push_back(child->ToElement());
    }
    return returnVec;
}

std::vector<TiXmlElement *>
ti_requiredChildren(TiXmlElement* ancestor, std::string nodeName)
{
    std::vector<TiXmlElement *> returnVec = ti_optionalChildren(ancestor,nodeName);
    if(returnVec.empty())
    {
        incorrect_xml_missing_tag e(tibasestr::MISSING_TAG_0+nodeName+tibasestr::MISSING_TAG_1,nodeName);
        throw e;
    }
    return returnVec;
}

//____________________________________________________________________________________
