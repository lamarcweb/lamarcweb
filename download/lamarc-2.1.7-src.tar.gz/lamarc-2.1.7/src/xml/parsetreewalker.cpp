// $Id: parsetreewalker.cpp,v 1.10 2011/03/07 06:08:54 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "menu_strings.h"   // for menustr::emptyString
#include "parsetreewalker.h"
#include "stringx.h"        // for StripLeadingSpaces and similar
#include "tinyxml.h"
#include "vectorx.h"        // for StringVec1d
#include "xml.h"
#include "xml_strings.h"

using std::string;

ParseTreeWalker::ParseTreeWalker(XmlParser & parser)
    :
    m_parser(parser)
{
}

ParseTreeWalker::~ParseTreeWalker()
{
}

TiXmlElement *
ParseTreeWalker::getSingleDescendantElement(TiXmlElement* ancestor,
                                            string nodeName,bool required)
{
    TiXmlNode * firstChild = ancestor->IterateChildren(nodeName,NULL);
    if(firstChild == NULL)
    {
        if(required)
        {
            m_parser.ThrowInternalXMLError(xmlstr::XML_ERR_MISSING_TAG_0+nodeName+xmlstr::XML_ERR_MISSING_TAG_1);
        }
        return NULL;
    }
    TiXmlNode * secondChild = ancestor->IterateChildren(nodeName,firstChild);
    if (secondChild != NULL)
    {
        m_parser.ThrowInternalXMLError(
            xmlstr::XML_ERR_EXTRA_TAG_0
            +nodeName
            +xmlstr::XML_ERR_EXTRA_TAG_1
            +ancestor->Value()
            +xmlstr::XML_ERR_EXTRA_TAG_2
            +ToString(ancestor->Row()));
        return NULL;
    }
    return firstChild->ToElement();
}

vector<TiXmlElement *>
ParseTreeWalker::getAllOptionalDescendantElements(TiXmlElement* ancestor,
                                                  string nodeName)
{
    vector<TiXmlElement *> returnVec;
    TiXmlNode * child = NULL;
    while((child = ancestor->IterateChildren(nodeName, child)))
    {
        returnVec.push_back(child->ToElement());
    }
    return returnVec;
}

TiXmlElement *
ParseTreeWalker::singleOptionalChild(TiXmlElement* ancestor, string nodeName)
{
    return getSingleDescendantElement(ancestor,nodeName,false);
}

TiXmlElement *
ParseTreeWalker::singleRequiredChild(TiXmlElement* ancestor, string nodeName)
{
    return getSingleDescendantElement(ancestor,nodeName,true);
}

string
ParseTreeWalker::getNodeText(TiXmlElement * node)
{
    string outstring = "";
    TiXmlNode * child = NULL;
    while((child = node->IterateChildren(child)))
    {
        TiXmlHandle handle(child);
        if(handle.Text())
        {
            outstring += child->Value();
        }
    }
    StripLeadingSpaces(outstring);
    StripTrailingSpaces(outstring);
    return outstring;
}

StringVec1d
ParseTreeWalker::getNodeTextSplitOnWhitespace(TiXmlElement * node)
{
    string allText = getNodeText(node);
    StringVec1d strings;
    FromString(allText,strings);
    return strings;
}

string
ParseTreeWalker::getNodeAttributeValue(TiXmlElement * node, string attrName)
{
    const std::string * attrValue = node->Attribute(attrName);
    if(attrValue)
    {
        return *attrValue;
    }
    else
    {
        return menustr::emptyString;
    }

}

//____________________________________________________________________________________
