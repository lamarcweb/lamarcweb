// $Id: tixml_base.h,v 1.4 2011/03/08 19:22:01 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#ifndef TIXML_BASE_H
#define TIXML_BASE_H

#include "errhandling.h"

#include <string>
#include <vector>

class TiXmlElement;

class tibasestr
{
  public:
    static const std::string EXTRA_TAG_0 ;
    static const std::string EXTRA_TAG_1 ;
    static const std::string MISSING_TAG_0 ;
    static const std::string MISSING_TAG_1 ;
    static const std::string NOT_DOUBLE_0 ;
    static const std::string NOT_DOUBLE_1 ;
    static const std::string NOT_LONG_0 ;
    static const std::string NOT_LONG_1 ;
    static const std::string NOT_SIZE_T_0 ;
    static const std::string NOT_SIZE_T_1 ;
};

TiXmlElement *          ti_singleElement(TiXmlElement* ancestor, std::string nodeName,bool required);
TiXmlElement *          ti_optionalChild(TiXmlElement* ancestor, std::string nodeName);
TiXmlElement *          ti_requiredChild(TiXmlElement* ancestor, std::string nodeName);
std::string             ti_nodeText(TiXmlElement *);
std::string             ti_attributeValue(TiXmlElement*,std::string attributeName);
bool                    ti_hasAttribute(TiXmlElement*,std::string attributeName);

double                  ti_double_from_text(TiXmlElement *);
long                    ti_long_from_text(TiXmlElement *) throw (incorrect_xml);
size_t                  ti_size_t_from_text(TiXmlElement *) throw (incorrect_xml);

std::vector<TiXmlElement *>  ti_optionalChildren(TiXmlElement* ancestor, std::string nodeName);
std::vector<TiXmlElement *>  ti_requiredChildren(TiXmlElement* ancestor, std::string nodeName);

#endif  // TIXML_BASE_H

//____________________________________________________________________________________
