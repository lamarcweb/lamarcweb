// $Id: epoch.cpp,v 1.4 2011/04/23 02:02:48 bobgian Exp $

/*
  Copyright 2002  Mary Kuhner, Jon Yamato, and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

//------------------------------------------------------------------------------------

#include "epoch.h"
#include "vectorx.h"

//------------------------------------------------------------------------------------

Epoch::Epoch(const LongVec1d& here, const LongVec1d& departing, long arriving)
    : m_here(here),
      m_departing(departing),
      m_arriving(arriving)
{
    // deliberately blank
} // Epoch ctor

//____________________________________________________________________________________
