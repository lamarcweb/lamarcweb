// $Id: priorreport.h,v 1.3 2011/03/07 06:08:49 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

/********************************************************************
 PriorReport is a collection class that creates an output report on
 the priors used during a Lamarc run.

 Currently the report takes the form of a StringVec1d, dimension is
 the number of lines of character output.

 Written by Jon Yamato
********************************************************************/

#ifndef PRIORREPORT_H
#define PRIORREPORT_H

#include "vectorx.h"
#include "constants.h"
#include "defaults.h"

class Force;
class Prior;

class PriorReport
{
  private:
    PriorReport(); //undefined

    std::string m_forcename;

    // all dim: # unique priors for force
    StringVec2d m_whichparams;
    vector<Prior> m_priors;

  public:
    // we accept default copy-ctor and operator=
    PriorReport(const Force& theforce);

    void WriteTo(std::ofstream& out) const;
};

#endif // PRIORREPORT_H

//____________________________________________________________________________________
