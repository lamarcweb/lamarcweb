// $Id: stair.cpp,v 1.3 2011/03/08 19:22:00 bobgian Exp $

/*
  Copyright 2002  Peter Beerli, Mary Kuhner, Jon Yamato and Joseph Felsenstein

  This software is distributed free of charge for non-commercial use
  and is copyrighted.  Of course, we do not guarantee that the software
  works, and are not responsible for any damage you may cause or have.
*/

#include "stair.h"

//------------------------------------------------------------------------------------

StairRiser::StairRiser(const DoubleVec1d& thetas, double tiptime,
                       double roottime) : m_thetas(thetas), m_tiptime(tiptime),
                                          m_roottime(roottime)
{
    // deliberately blank
} // StairRiser ctor

//------------------------------------------------------------------------------------

bool StairRiser::operator<(const StairRiser& other) const
{
    return (m_tiptime < other.m_tiptime);
} // StairRiser::operator<

//------------------------------------------------------------------------------------

void StairRiser::SetThetas(const DoubleVec1d& thetas)
{
    m_thetas = thetas;
} // StairRiser::SetThetas

//------------------------------------------------------------------------------------

void StairRiser::SetTipendTime(double newtime)
{
    m_tiptime = newtime;
} // StairRiser::SetTipendTime

//------------------------------------------------------------------------------------

void StairRiser::SetRootendTime(double newtime)
{
    m_roottime = newtime;
} // StairRiser::SetRootendTime

//------------------------------------------------------------------------------------

DoubleVec1d StairRiser::GetThetas() const
{
    return m_thetas;
} // StairRiser::GetThetas

//------------------------------------------------------------------------------------

double StairRiser::GetTipendTime() const
{
    return m_tiptime;
} // StairRiser::GetTipendTime

//------------------------------------------------------------------------------------

double StairRiser::GetRootendTime() const
{
    return m_roottime;
} // StairRiser::GetRootendTime

//____________________________________________________________________________________
